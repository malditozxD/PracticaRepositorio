// servicios buscar uuoo y colaborador
var buscarUUOOService = null;

var buscarUUOOInputService = null;

var buscarColaboradorService = null;

var buscarColaboradorInputService = null;

// éste módulo requiere definir estadosReembolsoViatico y errorMessageRevisarReembolsoBandeja
function initElementsRevisarReembolsoBandeja() {
	removeDuplicateComponents();
	setInitElementsRevisarReembolsoBandeja();
	setInitPlanillaTable();
}

function setInitElementsRevisarReembolsoBandeja() {
	
	disabledElement("btnExportarExcelReembolso");
	setValueInputText("selEstadoReembolso", "");
	setValueInputText("selAnioReembolso", getValueInputText("hidAnioActual"));

	setValueInputText("hidFechaMaximaAnioActual", getValueInputText("hidAnioActual") + "/12/31");
	modificarRangoFechaReembolsoBandeja(getValueInputText("hidAnioActual"));
	addEventElement("selEstadoReembolso", "change", changeSelEstadoReembolso);
	addEventElement("selAnioReembolso", "change", changeSelAnioReembolso);

	addEventElement("btnConsultarReembolso", "click", clickBtnConsultarReembolso);
	addEventElement("btnBuscarUUOOReembolso", "click", clickBtnBuscarUUOOReembolso);
	addEventElement("btnBuscarColaboradorReembolso", "click", clickBtnBuscarColaboradorReembolso);
	addEventElement("btnExportarExcelReembolso", "click", clickBtnExportarExcelReembolso);
	addEventElement("etiquetaFechaInicioReembolso", "change", changeEtiquetaFechaInicioReembolso);
	addEventElement("etiquetaFechaFinReembolso", "change", changeEtiquetaFechaFinReembolso);
	initDateTimePickerWithMaxDate("etiquetaFechaInicioReembolsoDiv", "dp.change", "changeDate", changeDateEtiquetaFechaInicioReembolsoDiv, getValueInputText("hidFechaMaximaAnioActual"));
	initDateTimePickerWithMaxDate("etiquetaFechaFinReembolsoDiv", "dp.change", "changeDate", changeDateEtiquetaFechaFinReembolsoDiv, getValueInputText("hidFechaMaximaAnioActual"));
	
	
	// si viene seteado código de planilla, realizar la búsqueda automáticamente
	/*var txtCodigoPlanilla = getTrimValue( '#txtCodigoPlanilla' );
	if ( txtCodigoPlanilla != '' ) {
		$( '#btnConsultarReembolso' ).trigger( 'click' );
	}*/
	
}

function setInitPlanillaTable() {
	
	var planillaTable = $("#tblPlanilla");
	var heightJqGrid = 190;
	setStyleElement("divPlanillaTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 1, true));
	if (planillaTable) {
		var planillaTableDiv = $("#divPlanillaTable");
		var widthTable = planillaTableDiv.width();
		planillaTable.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			datatype: "local",
			rowNum: 10,
			rowList: [10, 20],
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
			    "N&deg; Solicitud",
			    "Fec. de registro de Solicitud",
			    "Nombre Colaborador",
			    "Total d&iacute;as de la comisi&oacute;n",
			    "nomTipoViatico",
			    "Total Gasto",
			    
			    "Plazo para Rendir",
			    "Estado Solicitud", 
			    "Nombre del Autorizador",
			    "",
			    "Acci&oacute;n", 
			    "",
			    "",				// hidden
			    "codPlanViaje",      		// hidden			    
			    "numArchivo",        		// hidden
			    "numExpSolic",       		// hidden
			    "obsSolicitud",      		// hidden
			    "codEstadoSolic",     		// hidden
			    "nomUuOoCom",     			// hidden
			    "numeroRegistroAlterno",    // hidden
				"indicadorTraslape",     	// hidden
				"indicadorAutorizacion",    // hidden
				"codPlanilla",			    // hidden
				"numArchivo"
			],
			colModel: [
				{name:'codPlanillaLink',index:'codPlanillaLink', width:(2*widthTable/20), fixed: true, align:'center',
					formatter: function(cellvalue, options, rowObject) {
						
						  var codPlanilla = $.trim( rowObject.codPlanilla );
						  
						  if($.trim( rowObject.codEstadoSolic ) == estadosReembolsoViatico.ELABORADO ||
							$.trim( rowObject.codEstadoSolic ) == estadosReembolsoViatico.OBSERVADO ||
							$.trim( rowObject.codEstadoSolic ) == estadosReembolsoViatico.OBSERVADO_FINANCIERA){
							return "<a class=\"jqGridViaticoLinkClass\" href=\"javascript:void(0);\" onclick=\"javascript:clickBtnModificaPlanilla('"+codPlanilla+"');\">" + codPlanilla + "</a>";}
						  else if($.trim( rowObject.codEstadoSolic ) == estadosReembolsoViatico.POR_AUTORIZAR ||
									$.trim( rowObject.codEstadoSolic ) == estadosReembolsoViatico.AUTORIZADO || 
									$.trim( rowObject.codEstadoSolic ) == estadosReembolsoViatico.ANULADO ){
							  
							return "<a class=\"jqGridViaticoLinkClass\" href=\"javascript:void(0);\" onclick=\"javascript:clickBtnConsultaPlanilla('"+codPlanilla+"');\">" + codPlanilla + "</a>";}
						  else{
							return codPlanilla;
						  }
		
					}
				},
				{name:'fecRegistro',index:'fecRegistro',width:(2*widthTable/20), fixed: true, align:'center'},
				{name:'nomColaborador',index:'nomColaborador', width:(4*widthTable/20),  fixed: true},
				{name:'numeroDias',index:'numeroDias', width:(2*widthTable/20), fixed: true, align: 'center'},
				{name:'nomTipoViatico',index:'nomTipoViatico', width:(2*widthTable/20), fixed: true, align: 'center', hidden: true},
				
				{name:'mtoTotal',index:'mtoTotal', width:(2*widthTable/20),align:'right',  fixed: true},
				
				{name:'fecMaxRend',index:'fecMaxRend', width:(0.9*widthTable/20),align: 'center',  fixed: true, hidden: true},
				{name:'nomEstSolic',index:'nomEstSolic', width:(2*widthTable/20),align:'center', fixed: true,
					formatter: function(cellvalue, options, rowObject) {
						
						// ESTADO PLANILLA
					    var nomEstSolic = $.trim( rowObject.nomEstSolic ).toUpperCase();
					    var motivoObservacion  = $.trim( rowObject.obsSolicitud );	// motivo de la observación
					    var codEstadoSolic  = $.trim( rowObject.codEstadoSolic );
						
//						var estaObservado = codEstadoSolic == estadosReembolsoViatico.OBSERVADO || 
//											codEstadoSolic == estadosReembolsoViatico.OBSERVADO_CAJA_CHICA || 
//											codEstadoSolic == estadosReembolsoViatico.OBSERVADO_FINANCIERA;
					    
					    var estaObservado = codEstadoSolic == estadosReembolsoViatico.OBSERVADO || codEstadoSolic == estadosReembolsoViatico.OBSERVADO_FINANCIERA;
						
						// si esta observado, mostrar el motivo de la observación en el title
					    var title = estaObservado? motivoObservacion : nomEstSolic;
						
						return '<span title="' + title + '">' + nomEstSolic + '</span>';
					}
				},
				{name:'nombreAutorizador',index:'nombreAutorizador', width:(4*widthTable/20),align:'right',  fixed: true},
				{name:'detalle',index:'detalle', width:(1*widthTable/20), align:'center',  fixed: true,
					formatter: function(cellvalue, options, rowObject) {
						
					    var codPlanViaje = $.trim( rowObject.codPlanViaje );
					    
					    return "<a class=\"jqGridViaticoLinkClass\" href=\"javascript:void(0);\" onclick=\"javascript:clickVerDetalle('"+codPlanViaje+"')\">DETALLE</a>"; 
					}
				},
				{name:'seguimiento',index:'seguimiento', width:(2*widthTable/20),align:'center', fixed: true,
					formatter: function (cellvalue, options, rowObject) {
						
						var codPlanViaje = $.trim( rowObject.codPlanViaje );
						
					    return "<a class=\"jqGridViaticoLinkClass\" href=\"javascript:void(0);\" onclick=\"javascript:clickVerSeguimiento('"+codPlanViaje+"');\">SEGUIMIENTO</a>";					    
					}
				},
				{name:'anular',index:'anular', width:(1*widthTable/20),align:'center', fixed: true,
					formatter: function (cellvalue, options, rowObject) {

						var codPlanViaje = $.trim( rowObject.codPlanViaje );
						var codEstadoSolic  = $.trim( rowObject.codEstadoSolic );
						
						if ( codEstadoSolic == estadosReembolsoViatico.ELABORADO || codEstadoSolic == estadosReembolsoViatico.OBSERVADO ||
								codEstadoSolic == estadosReembolsoViatico.OBSERVADO_FINANCIERA) { 
							return "<a class=\"jqGridViaticoLinkClass\" href=\"javascript:void(0);\" onclick=\"javascript:clickVerAnular('"+codPlanViaje+"');\">ANULAR</a>";
						}
						
						return ' ';
					}
				},
				{name:'ver',index:'ver', width:(1*widthTable/20),align:'center', fixed: true,
					formatter: function (cellvalue, options, rowObject) {
						
						var codPlanViaje = $.trim( rowObject.codPlanViaje );
						var numRegistro = $.trim( rowObject.numeroRegistroAlterno );
						
						return "<a class=\"jqGridViaticoLinkClass\" href=\"javascript:void(0);\" onclick=\"javascript:clickVerArchivo('"+codPlanViaje+"','"+numRegistro+"');\">VER</a>";
					}
				},
				{name:'codPlanilla',index:'codPlanilla', width:(0.1*widthTable/12),hidden: true,  fixed: true},
				{name:'codPlanViaje',index:'codPlanViaje', width:(0.1*widthTable/12),hidden: true,  fixed: true},				
				{name:'numArchivo',index:'numArchivo', width:(0.1*widthTable/12),hidden: true,  fixed: true},
				{name:'numExpSolic', index:'numExpSolic', width:(0.1*widthTable/12), hidden: true,  fixed: true},
				{name:'obsSolicitud', index:'obsSolicitud', width:(0.1*widthTable/12), hidden: true,  fixed: true},
				{name:'codEstadoSolic', index:'codEstadoSolic', width:(0.1*widthTable/12), hidden: true,  fixed: true},
				{name:'nomUuOoCom', index:'nomUuOoCom', width:(0.1*widthTable/12), hidden: true,  fixed: true},
				{name:'numeroRegistroAlterno', index:'numeroRegistroAlterno', width:(0.1*widthTable/12), hidden: true,  fixed: true},
				{name:'indicadorTraslape', index:'indicadorTraslape', width:(0.1*widthTable/12), hidden: true,  fixed: true},
				{name:'indicadorAutorizacion', index:'indicadorAutorizacion', width:(0.1*widthTable/12), hidden: true,  fixed: true},	
				{name:'numArchivo',index:'numArchivo', width:(0.1*widthTable/12),hidden: true}
			],
			rowattr: function(dataTable) {				

				var codEstadoSolic  = $.trim( dataTable.codEstadoSolic );
				var indicadorTraslape  = $.trim( dataTable.indicadorTraslape );
					
				if ( codEstadoSolic == estadosReembolsoViatico.ANULADO || codEstadoSolic == estadosReembolsoViatico.ANULACION_AUTOMATICA ) {										
					return {"class": "colorFontRedTableClass"};		
				}
				
//				var estaObservado = codEstadoSolic == estadosReembolsoViatico.OBSERVADO || 
//									codEstadoSolic == estadosReembolsoViatico.OBSERVADO_CAJA_CHICA || 
//									codEstadoSolic == estadosReembolsoViatico.OBSERVADO_FINANCIERA;
				
				
				var estaObservado = codEstadoSolic == estadosReembolsoViatico.OBSERVADO || codEstadoSolic == estadosReembolsoViatico.OBSERVADO_FINANCIERA;
				
				if ( estaObservado ) {
					return {"class": "colorFontOrangeTableClass"};
				}

				if (indicadorTraslape == "1") {					
					return {"class": "colorFontCelesteTableClass"};
				}
				
			},
			/*caption: "Planillas",*/
			pager: "#divPlanillaPagerTable",
			loadui: "disable"
		});
		planillaTable.clearGridData();
		addEventElementBySelector("#divPlanillaTable .ui-pg-button.ui-corner-all", "click", clickPagerPlanillaTable);
		addEventElementBySelector("#divPlanillaTable input.ui-pg-input", "keypress", keypressPagerPlanillaTable);
		addEventElementBySelector("#divPlanillaTable select.ui-pg-selbox", "change", changePagerPlanillaTable);
	}
}

function changeSelEstadoReembolso() {
	clearPlanillaTableReembolsoBandeja();
}

function changeSelAnioReembolso() {
	
	var anioSeleccionado = getValueInputText("selAnioReembolso");
	hideElement("divErrorRevisionReembolsoBandeja");
	modificarRangoFechaReembolsoBandeja(anioSeleccionado);
	clearPlanillaTableReembolsoBandeja();
}
/*
function changeSelCanalAtencionSolicitud() {
	clearPlanillaTableReembolsoBandeja();
}*/

function changeEtiquetaFechaInicioReembolso() {
	if (isBrowserInternetExplorer()) {
		if (trimText(getValueInputText("etiquetaFechaInicioReembolso")) != "" && isValidoFormatDate(getValueInputText("etiquetaFechaInicioReembolso"))) {
			if (isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaInicioReembolso")), getValueInputText("hidFechaMaximaAnioActual"))) {
				setValueInputText("etiquetaFechaInicioReembolso", "");
			}
		}
		else {
			setValueInputText("etiquetaFechaInicioReembolso", "");
		}
		changeDateEtiquetaFechaInicioReembolsoDiv();
	}
}

function changeEtiquetaFechaFinReembolso() {
	if (isBrowserInternetExplorer()) {
		if (trimText(getValueInputText("etiquetaFechaFinReembolso")) != "" && isValidoFormatDate(getValueInputText("etiquetaFechaFinReembolso"))) {
			if (isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaFinReembolso")), getValueInputText("hidFechaMaximaAnioActual"))) {
				setValueInputText("etiquetaFechaFinReembolso", "");
			}
		}
		else {
			setValueInputText("etiquetaFechaFinReembolso", "");
		}
		changeDateEtiquetaFechaFinReembolsoDiv();
	}
}

function changeDateEtiquetaFechaInicioReembolsoDiv() {
	validarFechaInicioRevisarReembolsoBandeja();
	clearPlanillaTableReembolsoBandeja();
}

function changeDateEtiquetaFechaFinReembolsoDiv() {
	validarFechaFinalRevisarReembolsoBandeja();
	clearPlanillaTableReembolsoBandeja();
}

function clickBtnConsultarReembolso() {
	
	var flagValidacionFormulario = true;
	var errorMessage = "";
	hideElement("divErrorRevisionReembolsoBandeja");
	setHtmlElement("divPlanillaPagerTable_left", "");
	disabledElement("btnConsultarReembolso");
	clearPlanillaTableReembolsoBandeja();

	// cuando no ingresa ni uuoo ni número de registro (validación agregada por observación)
	if (flagValidacionFormulario && trimText(getValueInputText("hidCodigoColaborador")).length == 0 && trimText(getValueInputText("hidCodigoDependencia")).length == 0) {
		flagValidacionFormulario = false;
		errorMessage = errorMessageRevisarReembolsoBandeja.numeroRegistroUUOOInvalido;
		darFoco( '#txtUUOO' );
	}	
	
	// cuando no ingresa una uuoo válida
	if (flagValidacionFormulario && trimText(getValueInputText("hidCodigoDependencia")).length == 0) {
		flagValidacionFormulario = false;
		errorMessage = errorMessageRevisarReembolsoBandeja.UUOOInvalido;
		darFoco( '#txtUUOO' );
	}
	
	// cuando no ingresa un número de registro válido
	if (flagValidacionFormulario && trimText(getValueInputText("txtNroRegistro")).length != 0 && trimText(getValueInputText("hidCodigoColaborador")).length == 0  ) { 
		flagValidacionFormulario = false;
		errorMessage = errorMessageRevisarReembolsoBandeja.numeroRegistroInvalido;
		darFoco( '#txtNroRegistro' );
	}	
		
	
	// fechas ingresadas
	var fechaFin = getTrimValue( '#etiquetaFechaFinReembolso' );
	var fechaInicio = getTrimValue( '#etiquetaFechaInicioReembolso' );

	// cuando no ingresa fecha de inicio
	if (flagValidacionFormulario && fechaInicio == '' ) { 
		flagValidacionFormulario = false;
		errorMessage = errorMessageRevisarReembolsoBandeja.fechaInicioVacio;
		darFoco( '#etiquetaFechaInicioReembolso' ); 
	}

	// cuando no ingresa fecha de fin
	if (flagValidacionFormulario && fechaFin == '' ) { 
		flagValidacionFormulario = false;
		errorMessage = errorMessageRevisarReembolsoBandeja.fechaFinalVacio;
		darFoco( '#etiquetaFechaFinReembolso' );
	}		

	// validar que la fecha fin debe ser mayor o igual a la fecha de inicio
	if (flagValidacionFormulario && esFechaValida(fechaInicio) && esFechaValida(fechaFin) ) {
		if ( !esFechaMayorIgual( fechaFin, fechaInicio ) ) {
			flagValidacionFormulario = false;
			errorMessage = errorMessageRevisarReembolsoBandeja.fechaFinalMenorFechaInicial;
			darFoco( '#etiquetaFechaFinReembolso' );
		}
	}
	
	// cuando no ingresa una fecha de inicio válida
	if (flagValidacionFormulario && getValueInputText("hidFlagFechaInicioValida") != "") {
		flagValidacionFormulario = false;
		errorMessage = getValueInputText("hidFlagFechaInicioValida");
		darFoco( '#etiquetaFechaInicioReembolso' );
	}
	
	// cuando no ingresa una fecha de final válida
	if (flagValidacionFormulario && getValueInputText("hidFlagFechaFinalValida") != "") {
		flagValidacionFormulario = false;
		errorMessage = getValueInputText("hidFlagFechaFinalValida");
		darFoco( '#etiquetaFechaFinReembolso' );
	}
	
	if (flagValidacionFormulario) {
		callBuscarPlanillasBandeja();
	}
	else {
		showMessageErrorRevisionReembolsoBandeja(errorMessage);
		enabledElement("btnConsultarReembolso");
	}
}


// BUSCAR UUOO
function clickBtnBuscarUUOOReembolso() {

	var dataParametrosBuscarUUOO = new Object();

	dataParametrosBuscarUUOO.idCodigoRegistrador = "hidCodigoRegistrador";
	dataParametrosBuscarUUOO.idCodigoTipoUUOOViatico = getTrimValue( '#hidCodigoTipoUUOOViatico' );
	dataParametrosBuscarUUOO.idDivScreenBlock = "divScreenBlock";
	
	buscarUUOOService = new BuscarUUOOService(dataParametrosBuscarUUOO, buscarUUOOBeforeMethod, buscarUUOOAfterMethod);
	
	initElementsBuscarUUOO("divPlanillaTable");
	$("#divBuscarUUOO").modal("show");	
	triggerResizeEvent();
}

function buscarUUOOBeforeMethod() {
	
	// limpiar datos de la uuoo
	setValueInputText("hidCodigoDependencia", '');
	setValueInputText("txtDescripcionDependencia", '');
	setValueInputText("hidTxtNroRegistro", "");
	// limpiar datos del colaborador
	setValueInputText('txtNroRegistro', '');
	setValueInputText('txtNombreColaborador', '');
	setValueInputText('hidCodigoColaborador', '');
	setValueInputText('hidCodigoEstadoColaborador', '');	
	
	// limpiar label y ocultar div de mensaje de error
	setHtmlElement('etiquetaErrorRevisionReembolsoBandeja', '');
	hideElement('divErrorRevisionReembolsoBandeja');

	// limpiar grilla
	clearPlanillaTableReembolsoBandeja();		
	
}

function buscarUUOOAfterMethod(rowData) {
	/*setValueInputText('txtNroRegistro', '');
	setValueInputText('txtNombreColaborador', '');
	setValueInputText('hidCodigoColaborador', '');
	setValueInputText('hidCodigoEstadoColaborador', '');	
	setValueInputText("hidCodigoDependencia", '');
	setValueInputText("txtDescripcionDependencia", '');
	setValueInputText("hidTxtNroRegistro", "");*/
	// limpiar label y ocultar div de mensaje de error
//	setHtmlElement('etiquetaErrorRevisionReembolsoBandeja', '');
	//hideElement('divErrorRevisionReembolsoBandeja');
	
	// setear datos de la uuoo
	setValueInputText("txtUUOO", rowData["uuoo"]);
	setValueInputText("hidCodigoDependencia", rowData["codigoDependencia"]);
	setValueInputText("txtDescripcionDependencia", rowData["descripcionUUOO"]);
	setValueInputText("hidTxtUUOO", rowData["uuoo"]);
	//clearPlanillaTableRendicionBandeja();
}

// BUSCAR UUOO INPUT
function initElementsBuscarUUOOInputService( errorMessageBuscarUUOOInput ) {

	var dataParametros = new Object();
	
	dataParametros.idNumeroUUOO = "txtUUOO";
	dataParametros.idCodigoRegistrador = "hidCodigoRegistrador";
	dataParametros.idCodigoTipoUUOOViatico = getTrimValue( '#hidCodigoTipoUUOOViatico' );
	dataParametros.idDivLoading = "divLoadingRevisionReembolsoBandejaInput";
	dataParametros.idDivError = "divErrorRevisionReembolsoBandeja";	
	dataParametros.idEtiquetaError = "etiquetaErrorRevisionReembolsoBandeja";
	dataParametros.idDivScreenBlock = "divScreenBlock";
	dataParametros.errorMessage = errorMessageBuscarUUOOInput;
	
	this.idNumeroUUOO = dataParametros.idNumeroUUOO;

	buscarUUOOInputService = new BuscarUUOOInputService( dataParametros, buscarUUOOInputBeforeMethod, buscarUUOOInputAfterMethod );
}

function buscarUUOOInputBeforeMethod() {
 
	// limpiar datos de la uuoo
	setValueInputText("hidCodigoDependencia", '');
	setValueInputText("txtDescripcionDependencia", '');	
	setValueInputText("hidTxtUUOO", "");
	// limpiar datos del colaborador
	setValueInputText('txtNroRegistro', '');
	setValueInputText('txtNombreColaborador', '');
	setValueInputText('hidCodigoColaborador', '');
	setValueInputText('hidCodigoEstadoColaborador', '');	
	setValueInputText("hidTxtNroRegistro", "");
	
	// limpiar label y ocultar div de mensaje de error
	setHtmlElement('etiquetaErrorRevisionReembolsoBandeja', '');
	hideElement('divErrorRevisionReembolsoBandeja');
	
	// limpiar grilla
	clearPlanillaTableReembolsoBandeja();	
}

function buscarUUOOInputAfterMethod(uuooList) {
	
	if (uuooList != null && uuooList.length > 0) {
		
		for ( var i = 0; i < uuooList.length; i++) {
			
			var uuoo = uuooList[i];
			var datarow = {
				codigoDependencia : uuoo.cod_dep,
				uuoo : uuoo.uuoo,
				uuooDetalle : uuoo.nom_largo
			};
			
			// setear datos de la uuoo
			setValueInputText("txtUUOO", datarow.uuoo);
			setValueInputText("hidCodigoDependencia", datarow.codigoDependencia);
			setValueInputText("txtDescripcionDependencia", datarow.uuooDetalle);
			setValueInputText("hidTxtUUOO", datarow.uuoo);
			break;
		}
		
	} else {		
		setHtmlElement('etiquetaErrorRevisionReembolsoBandeja', errorMessageBuscarUUOOInput.sinRegistrosBusqueda);
		showElement("divErrorRevisionReembolsoBandeja");
	}
}

// BUSCAR COLABORADOR
function clickBtnBuscarColaboradorReembolso() {
 
	var dataParametrosBuscarColaborador = new Object();
	
	dataParametrosBuscarColaborador.idCodigoRegistrador = "hidCodigoRegistrador";
	dataParametrosBuscarColaborador.idNumeroRegistroRegistrador = "hidNumeroRegistroRegistrador";
	dataParametrosBuscarColaborador.idCodigoTipoUsuarioViatico = getTrimValue( '#hidCodigoTipoUsuarioViatico' );
	dataParametrosBuscarColaborador.idDivScreenBlock = "divScreenBlock";
	dataParametrosBuscarColaborador.estadoLlamada = "B";
	
	buscarColaboradorService = new BuscarColaboradorService( dataParametrosBuscarColaborador, buscarColaboradorBeforeMethod, buscarColaboradorAfterMethod );
	
	var flagAsociarUUOOBuscarColaborador = false;
	initElementsBuscarColaborador("divPlanillaTable",flagAsociarUUOOBuscarColaborador);
	$("#divBuscarColaborador").modal("show");
	triggerResizeEvent();
}

function buscarColaboradorBeforeMethod() {
	
	// limpiar datos del colaborador
	setValueInputText('txtNombreColaborador', '');
	setValueInputText('hidCodigoColaborador', '');
	setValueInputText('hidCodigoEstadoColaborador', '');	
	
	// limpiar datos de la uuoo
	// setValueInputText("txtUUOO", '');
	// setValueInputText("hidCodigoDependencia", '');
	// setValueInputText("txtDescripcionDependencia", '');		
	
	// limpiar label y ocultar div de mensaje de error
	setHtmlElement('etiquetaErrorRevisionReembolsoBandeja', '');
	hideElement('divErrorRevisionReembolsoBandeja');
	
	// limpiar grilla
	clearPlanillaTableReembolsoBandeja();
}

function buscarColaboradorAfterMethod(rowData) {
	
	// setear datos del colaborador
	setValueInputText("txtNroRegistro", $.trim(rowData["numeroRegistro"]));
	setValueInputText("hidCodigoColaborador", $.trim(rowData["codigoEmpleado"]));
	setValueInputText("txtNombreColaborador", $.trim(rowData["nombreCompleto"]));
	setValueInputText("hidCodigoEstadoColaborador", $.trim(rowData["codigoEstado"]));
	setValueInputText("hidTxtNroRegistro", rowData["numeroRegistro"]);
	// setear datos de la uuoo
	 setValueInputText("txtUUOO", $.trim(rowData["uuoo"]));
	 setValueInputText("hidTxtUUOO", rowData["uuoo"]);
	 setValueInputText("txtDescripcionDependencia", $.trim(rowData["uuooDetalle"]));
	 setValueInputText("hidCodigoDependencia", $.trim(rowData["codigoDependencia"]));
}

// BUSCAR COLABORADOR INPUT
function initElementsBuscarColaboradorInputService( errorMessageBuscarColaboradorInput ) {

	var dataParametros = new Object();
	
	dataParametros.idCodigoDependencia = "hidCodigoDependencia";
	dataParametros.idNumeroRegistroColaborador = "txtNroRegistro";
	dataParametros.idCodigoRegistrador = "hidCodigoRegistrador";
	dataParametros.idNumeroRegistroRegistrador = "hidNumeroRegistroRegistrador";
	dataParametros.idCodigoTipoUsuarioViatico = getTrimValue( '#hidCodigoTipoUsuarioViatico' );
	dataParametros.idDivLoading = "divLoadingRevisionReembolsoBandejaInput";
	dataParametros.idDivError = "divErrorRevisionReembolsoBandeja";	
	dataParametros.idEtiquetaError = "etiquetaErrorRevisionReembolsoBandeja";
	dataParametros.idDivScreenBlock = "divScreenBlock";
	dataParametros.estadoLlamada = "B";	
	dataParametros.errorMessage = errorMessageBuscarColaboradorInput;

	buscarColaboradorInputService = new BuscarColaboradorInputService( dataParametros, buscarColaboradorInputBeforeMethod, buscarColaboradorInputAfterMethod );
}

function buscarColaboradorInputBeforeMethod() {
	
	// limpiar datos del colaborador
	setValueInputText('txtNombreColaborador', '');
	setValueInputText('hidCodigoColaborador', '');
	setValueInputText('hidCodigoEstadoColaborador', '');	
	setValueInputText("hidTxtNroRegistro", "");
	// limpiar datos de la uuoo
	// setValueInputText("txtUUOO", '');
	// setValueInputText("hidCodigoDependencia", '');
	// setValueInputText("txtDescripcionDependencia", '');

	// limpiar label y ocultar div de mensaje de error
	setHtmlElement('etiquetaErrorRevisionReembolsoBandeja', '');
	hideElement('divErrorRevisionReembolsoBandeja');
	
	// limpiar grilla
	clearPlanillaTableReembolsoBandeja();		
}

function buscarColaboradorInputAfterMethod(colaboradorList) {
	
	if (colaboradorList != null && colaboradorList.length > 0) {
		
		for ( var i = 0; i < colaboradorList.length; i++) {
			var colaborador = colaboradorList[i];
			var datarow = {
				numeroRegistro : colaborador.numero_registro,
				nombreCompleto : colaborador.nombre_completo,
				uuoo : colaborador.uuoo,
				codigoDependencia : colaborador.codigoDependencia,
				uuooDetalle : colaborador.dependencia,
				codigoEmpleado : colaborador.codigoEmpleado,
				codigoEstado : colaborador.codigoEstado,
				estadoDetalle : colaborador.estado
			};
			
			// setear datos del colaborador
			setValueInputText("txtNroRegistro", $.trim(datarow.numeroRegistro));
			setValueInputText("hidCodigoColaborador", $.trim(datarow.codigoEmpleado));
			setValueInputText("txtNombreColaborador", $.trim(datarow.nombreCompleto));
			setValueInputText("hidCodigoEstadoColaborador", $.trim(datarow.codigoEstado));			
			setValueInputText("hidTxtNroRegistro", datarow.numeroRegistro);
			// setear datos de la uuoo
			setValueInputText("txtUUOO", $.trim(datarow.uuoo));
			setValueInputText("hidCodigoDependencia",  $.trim(datarow.codigoDependencia));
			setValueInputText("txtDescripcionDependencia", $.trim(datarow.uuooDetalle));
			setValueInputText("hidTxtUUOO", datarow.uuoo);
			break;
		}

		
	} else {

		setHtmlElement('etiquetaErrorRevisionReembolsoBandeja', errorMessageBuscarColaboradorInput.sinRegistrosBusqueda);
		showElement("divErrorRevisionReembolsoBandeja");
	}
}

function clickBtnExportarExcelReembolso() {
 
	var params = {
		"codDependencia"	:	getTrimValue( '#hidCodigoDependencia' ),
		"codColaborador"	:	getTrimValue( '#hidCodigoColaborador' ),
		"codRegistrador"	:	getTrimValue( '#hidCodigoRegistrador' ),
		"codEstado"			: 	getTrimValue( '#selEstadoReembolso' ),
		"fechaDesde"	 	:	getTrimValue( '#etiquetaFechaInicioReembolso' ),
		"fechaHasta"	 	:	getTrimValue( '#etiquetaFechaFinReembolso' ),
		"numPlanilla"	 	:	getUpperCaseValueInputText( 'txtCodigoPlanilla' )
	};	
	
	$(location).prop( 'href', contextPathUrl + '/reembolso.htm?action=exportadoExcel&' + $.param( params ) );
}

function clickPagerPlanillaTable() {
	showTooltip();
}

function keypressPagerPlanillaTable(event) {
	var keyCode = window.event ? event.keyCode : event.which;
	if (keyCode == 13) {
		showTooltip();
	}
}

function changePagerPlanillaTable() {
	showTooltip();
}

function modificarRangoFechaReembolsoBandeja(anioSeleccionado) {
	
	setValueInputText("hidFechaInicialRangoFecha", "01/01/" + anioSeleccionado);
	setValueInputText("hidFechaFinalRangoFecha", "31/12/" + anioSeleccionado);
	setValueInputText("etiquetaFechaInicioReembolso", getValueInputText("hidFechaInicialRangoFecha"));
	setValueInputText("etiquetaFechaFinReembolso", getValueInputText("hidFechaFinalRangoFecha"));
	setValueInputText("hidFlagFechaInicioValida", "");
	setValueInputText("hidFlagFechaFinalValida", "");
}

function validarFechaInicioRevisarReembolsoBandeja() {
	
/*	var flagFechaValida = true;
	var errorMessage = "";
	hideElement("divErrorRevisionReembolsoBandeja");
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("hidFechaInicialRangoFecha")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaInicioReembolso")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRevisarReembolsoBandeja.fechaInicioMenorFechaRango + getValueInputText("hidFechaInicialRangoFecha") + ".";
	}
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaInicioReembolso")), formatEspDateToEngFormatDate(getValueInputText("hidFechaFinalRangoFecha")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRevisarReembolsoBandeja.fechaInicioMayorFechaRango + getValueInputText("hidFechaFinalRangoFecha") + ".";
	}
	
	if (!flagFechaValida) {
		setValueInputText("hidFlagFechaInicioValida", errorMessage);
		showMessageErrorRevisionReembolsoBandeja(errorMessage);
	}
	else {
		if (trimText(getValueInputText("etiquetaFechaInicioReembolso")) != "") {
			setValueInputText("hidFlagFechaInicioValida", "");
			if (trimText(getValueInputText("etiquetaFechaFinReembolso")) != "") {
				validarFechaFinalMayorIgualFechaInicioRevisarReembolsoBandeja();
			}
		}
		else {
			setValueInputText("hidFlagFechaInicioValida", errorMessageRevisarReembolsoBandeja.fechaInicioVacio );
		}
	}
	*/
	
	var errorMessage = '';
	var flagFechaValida = true;

	hideElement("divErrorRevisionReembolsoBandeja");

	// fechas ingresadas
	var fechaFin = getTrimValue( '#etiquetaFechaFinReembolso' );
	var fechaInicio = getTrimValue( '#etiquetaFechaInicioReembolso' );

	// fechas de rango (combo anio)
	var rangoFin = getTrimValue( '#hidFechaFinalRangoFecha' );
	var rangoInicio = getTrimValue( '#hidFechaInicialRangoFecha' );
	
	// valida que fecha de inicio este dentro del rango del anio
	if (flagFechaValida && esFechaValida(fechaInicio)) {
		if ( !( esFechaMayorIgual( fechaInicio, rangoInicio ) && esFechaMenorIgual( fechaInicio, rangoFin ) ) ) {
			flagFechaValida = false;
			errorMessage = errorMessageRevisarReembolsoBandeja.fechaInicioFueraRango + ".";
			darFoco( '#etiquetaFechaInicioReembolso' );
		}
	}

	// validar que la fecha fin debe ser mayor o igual a la fecha de inicio
	if (flagFechaValida && esFechaValida(fechaInicio) && esFechaValida(fechaFin) ) {
		if ( !esFechaMayorIgual( fechaFin, fechaInicio ) ) {
			flagFechaValida = false;
			errorMessage = errorMessageRevisarReembolsoBandeja.fechaFinalMenorFechaInicial;
			darFoco( '#etiquetaFechaFinReembolso' );
		}
	}
	
	if (!flagFechaValida) {
		setValueInputText("hidFlagFechaInicioValida", errorMessage);
		showMessageErrorRevisionReembolsoBandeja(errorMessage);
	} else {
		setValueInputText("hidFlagFechaInicioValida", "");
	}
	
}

function validarFechaFinalRevisarReembolsoBandeja() {
	
	/*var flagFechaValida = true;
	var errorMessage = "";
	hideElement("divErrorRevisionReembolsoBandeja");
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("hidFechaInicialRangoFecha")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaFinReembolso")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRevisarReembolsoBandeja.fechaFinalMenorFechaRango + getValueInputText("hidFechaInicialRangoFecha") + ".";
	}
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaFinReembolso")), formatEspDateToEngFormatDate(getValueInputText("hidFechaFinalRangoFecha")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRevisarReembolsoBandeja.fechaFinalMayorFechaRango + getValueInputText("hidFechaFinalRangoFecha") + ".";
	}
	
	if (!flagFechaValida) {
		setValueInputText("hidFlagFechaFinalValida", errorMessage);
		showMessageErrorRevisionReembolsoBandeja(errorMessage);
	}
	else {
		if (trimText(getValueInputText("etiquetaFechaFinReembolso")) != "") {
			setValueInputText("hidFlagFechaFinalValida", "");
			if (trimText(getValueInputText("etiquetaFechaInicioReembolso")) != "") {
				validarFechaFinalMayorIgualFechaInicioRevisarReembolsoBandeja();
			}
		}
		else {
			setValueInputText("hidFlagFechaFinalValida", errorMessageRevisarReembolsoBandeja.fechaFinalVacio );
		}
	}
	
	*/
	
	
	
	var errorMessage = '';
	var flagFechaValida = true;

	hideElement("divErrorRevisionReembolsoBandeja");

	// fechas ingresadas
	var fechaFin = getTrimValue( '#etiquetaFechaFinReembolso' );
	var fechaInicio = getTrimValue( '#etiquetaFechaInicioReembolso' );

	// fechas de rango (combo anio)
	var rangoFin = getTrimValue( '#hidFechaFinalRangoFecha' );
	var rangoInicio = getTrimValue( '#hidFechaInicialRangoFecha' );
	
	// valida que fecha de fin este dentro del rango del anio
	if (flagFechaValida && esFechaValida(fechaFin)) {
		if ( !( esFechaMayorIgual( fechaFin, rangoInicio ) && esFechaMenorIgual( fechaFin, rangoFin ) ) ) {
			flagFechaValida = false;
			errorMessage = errorMessageRevisarReembolsoBandeja.fechaFinFueraRango + ".";
			darFoco( '#etiquetaFechaFinReembolso' );
		}
	}

	// validar que la fecha fin debe ser mayor o igual a la fecha de inicio
	if (flagFechaValida && esFechaValida(fechaInicio) && esFechaValida(fechaFin) ) {
		if ( !esFechaMayorIgual( fechaFin, fechaInicio ) ) {
			flagFechaValida = false;
			errorMessage = errorMessageRevisarReembolsoBandeja.fechaFinalMenorFechaInicial;
			darFoco( '#etiquetaFechaFinReembolso' );
		}
	}
	
	if (!flagFechaValida) {
		setValueInputText("hidFlagFechaFinalValida", errorMessage);
		showMessageErrorRevisionReembolsoBandeja(errorMessage);
	} else {
		setValueInputText("hidFlagFechaFinalValida", "");
	}
	
}
/*
function validarFechaFinalMayorIgualFechaInicioRevisarReembolsoBandeja() {
	
	var flagFechaValida = true;
	var errorMessage = "";
	hideElement("divErrorRevisionReembolsoBandeja");
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaInicioReembolso")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaFinReembolso")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRevisarReembolsoBandeja.fechaFinalMenorFechaInicial;
	}
	
	if (!flagFechaValida) {
		setValueInputText("hidFlagFechaFinalValida", errorMessage);
		showMessageErrorRevisionReembolsoBandeja(errorMessage);
	}
	else {
		setValueInputText("hidFlagFechaFinalValida", "");
	}
}*/

function callBuscarPlanillasBandeja() {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/reembolso.htm?action=buscarReembolsosBandejaRevision",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codDependencia"	:	getTrimValue( '#hidCodigoDependencia' ),
				"codColaborador"	:	getTrimValue( '#hidCodigoColaborador' ),
				"codRegistrador"	:	getTrimValue( '#hidCodigoRegistrador' ),
				"codEstado"			: 	getTrimValue( '#selEstadoReembolso' ),
				"codCanal"			: 	getTrimValue( '#selCanalAtencionSolicitud' ),
				"numPlanilla"	 	:	getUpperCaseValueInputText( 'txtCodigoPlanilla' ),
				"fechaDesde"	 	:	getTrimValue( '#etiquetaFechaInicioReembolso' ),
				"fechaHasta"	 	:	getTrimValue( '#etiquetaFechaFinReembolso' )
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showElement("divLoadingReembolso");
			},
			complete: function() {
				enabledElement("btnConsultarReembolso");
				hideElement("divLoadingReembolso");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				
				// error inesperado ajax app
				if ( huboErrorAjax( result ) ) {
					handleErrorAjax( result );
					return;
				}
				
				// existen validaciones de app
				if ( result.hayValidacion == 'si' ) {
					
					showMessageErrorRevisionReembolsoBandeja(result.msgValidacion);
					darFoco( '#txtCodigoPlanilla' );
								
					return;
				}	
				
				showPlanillasRevisarReembolsoBandeja(result.listSolicitudes);

			},
			error: function( error ) {
				handleError( error );
			}
		});
	}, 5);
}

function showMessageErrorRevisionReembolsoBandeja(errorMessage) {
	setHtmlElement("etiquetaErrorRevisionReembolsoBandeja", errorMessage);
	showElement("divErrorRevisionReembolsoBandeja");
}


function showPlanillasRevisarReembolsoBandeja(planillaArray) {
	
	if (planillaArray != null && planillaArray.length > 0) {
		
		var planillaTable = $("#tblPlanilla");
		planillaTable.clearGridData();
		
		for (var i = 0; i < planillaArray.length; i++) {
			
			var planilla= planillaArray[i];
			
			var datarow = {
				codPlanilla: planilla.codPlanilla,
				fecRegistro: planilla.fecRegistro,
				nomColaborador: planilla.nomColaborador,
				numeroDias: planilla.numDias,
				nomTipoViatico: planilla.nomTipoViatico,
				mtoTotal: planilla.mtoTotal,
				canalAtencion: planilla.canalAtencion,
				fecMaxRend: planilla.fecMaxRend, 
				nomEstSolic: planilla.nomEstSolic,
				codPlanViaje: planilla.codPlanViaje,
				numArchivo: $.trim(planilla.numArchivo),
				numExpSolic: $.trim(planilla.numExpSolic),
				obsSolicitud: planilla.obsSolicitud,
				codEstadoSolic: planilla.codEstadoSolic,
				nomUuOoCom: planilla.nomUuOoCom,
				nombreAutorizador: planilla.nomAutorizador,
				numeroRegistroAlterno: planilla.numeroRegistroAlterno,
				indicadorTraslape: planilla.indicadorTraslape,
				indicadorAutorizacion: planilla.indicadorAutorizacion
			};
			
			planillaTable.jqGrid('addRowData', datarow.codPlanViaje, datarow);
		}		
		
		planillaTable.trigger("reloadGrid");
		enabledElement("btnExportarExcelReembolso");
		showTooltip();
		
	} else {
		setHtmlElement("divPlanillaPagerTable_left", errorMessageRevisarReembolsoBandeja.sinRegistrosBusqueda);
	}
}

function clearPlanillaTableReembolsoBandeja() {
	var planillaTable = $("#tblPlanilla");
	planillaTable.clearGridData();
	disabledElement("btnExportarExcelReembolso");
	setHtmlElement("divPlanillaPagerTable_left", "");
}
 
function clickBtnConsultaPlanilla(codPlanilla){
	
	// si el usuario que ingresa a session es registrador
	var esRegistrador = toNumero( getTrimValue('#hidFlagRegistrador') ) > 0 || toNumero( getTrimValue('#hidFlagRegistradorUniversal') ) > 0;
	
	// mostrar popup consultar solicitud
	// initElementsConsultarReembolso( codPlanilla, esRegistrador );	
	// showModalElement( 'divConsultarReembolsoModal' );
	// triggerResizeEvent();

	var dataObject = {
			'UUOO': getTrimValue( '#txtUUOO' ),
			'nombreDependencia' : getTrimValue( '#txtDescripcionDependencia' ),
			'codigoDependencia' : getTrimValue( '#hidCodigoDependencia' ),		
			'selAnioReembolsotUUOO': getTrimValue( '#selAnioReembolso' ),
			'etiquetaFechaInicioReembolso': getTrimValue( '#etiquetaFechaInicioReembolso' ),
			'etiquetaFechaFinReembolso': getTrimValue( '#etiquetaFechaFinReembolso' ),
			'codigoPlanilla': getUpperCaseValueInputText( 'txtCodigoPlanilla' ),
			'selEstadoReembolso': getTrimValue( '#selEstadoReembolso' ),		
			'nroRegistro': getTrimValue( '#txtNroRegistro' ),
			'codigoColaborador' : getTrimValue( '#hidCodigoColaborador' ),		
			'nombreColaborador' : getTrimValue( '#txtNombreColaborador' ),
			'codigoRegistrador' : getTrimValue( '#hidCodigoRegistrador' )
	};
	
	var params = {
		"codPlanilla" : codPlanilla,
		"paginaConsultaCaller" : '01',  // 01: bandeja revision reembolso, 02: bandeja consulta reembolso
		"dataJSON" : JSON.stringify( dataObject )
	};	
	
	$(location).prop( 'href', contextPathUrl + '/registrarReembolso.htm?action=mostrarConsultarViatico&' + $.param( params ) );
}


function clickBtnModificaPlanilla(codPlanilla){
	
	// si el usuario que ingresa a session es registrador
	var esRegistrador = toNumero( getTrimValue('#hidFlagRegistrador') ) > 0 || toNumero( getTrimValue('#hidFlagRegistradorUniversal') ) > 0;
	
	// mostrar popup consultar solicitud
	// initElementsConsultarReembolso( codPlanilla, esRegistrador );	
	// showModalElement( 'divConsultarReembolsoModal' );
	// triggerResizeEvent();

	var dataObject = {
			'UUOO': getTrimValue( '#txtUUOO' ),
			'nombreDependencia' : getTrimValue( '#txtDescripcionDependencia' ),
			'codigoDependencia' : getTrimValue( '#hidCodigoDependencia' ),		
			'selAnioReembolsotUUOO': getTrimValue( '#selAnioReembolso' ),
			'etiquetaFechaInicioReembolso': getTrimValue( '#etiquetaFechaInicioReembolso' ),
			'etiquetaFechaFinReembolso': getTrimValue( '#etiquetaFechaFinReembolso' ),
			'codigoPlanilla': getUpperCaseValueInputText( 'txtCodigoPlanilla' ),
			'selEstadoReembolso': getTrimValue( '#selEstadoReembolso' ),		
			'nroRegistro': getTrimValue( '#txtNroRegistro' ),
			'codigoColaborador' : getTrimValue( '#hidCodigoColaborador' ),		
			'nombreColaborador' : getTrimValue( '#txtNombreColaborador' ),
			'codigoRegistrador' : getTrimValue( '#hidCodigoRegistrador' )
	};
	
	var params = {
		"codPlanilla" : codPlanilla,
		"paginaConsultaCaller" : '01',  // 01: bandeja revision reembolso, 02: bandeja consulta reembolso
		"dataJSON" : JSON.stringify( dataObject )
	};	
	
	$(location).prop( 'href', contextPathUrl + '/registrarReembolso.htm?action=mostrarModificarViatico&' + $.param( params ) );
}


function clickBtnModificarPlanilla(codPlanilla){
	
	var formPost = $( '#formPost' );	
	formPost.find( 'input[name="action"]' ).val( 'mostrarModificarViatico' );
	formPost.find( 'input[name="codPlanilla"]' ).val( codPlanilla );
	formPost.submit();
	
}

function clickVerDetalle(codPlanViaje) {
	
	initElementsConsultarReembolsoDetalle("divPlanillaTable", codPlanViaje);
	showModalElement("divConsultarReembolsoDetalle");
	triggerResizeEvent();	
}


function clickVerSeguimiento(codPlanViaje){
	
	var planillaTable = $("#tblPlanilla");
	var rowData = planillaTable.getRowData(codPlanViaje);	
	
	var dataParametrosConsultarSeguimiento = new Object();
	dataParametrosConsultarSeguimiento.codPlanViaje = codPlanViaje;
	dataParametrosConsultarSeguimiento.numeroExpediente = $.trim( rowData.numExpSolic );;
	dataParametrosConsultarSeguimiento.idElementCallModal = "divPlanillaTable";
	dataParametrosConsultarSeguimiento.codigoPaginaCaller = "02"; //"01": Bandejas solicitud y rendicion -- "02": Bandejas reembolso
	initElementsConsultarSeguimiento(dataParametrosConsultarSeguimiento);
	showModalElement("divConsultarSeguimiento");
	triggerResizeEvent();
	triggerResizeEventSlow();	
}

function clickVerAnular(codPlanViaje){
	
	var planillaTable = $("#tblPlanilla");
	var rowData = planillaTable.getRowData(codPlanViaje);
	var dataParametrosAnularDocumento = new Object();
	dataParametrosAnularDocumento.codPlanViaje = codPlanViaje; 
	dataParametrosAnularDocumento.codPlanilla = rowData.codPlanilla; 
	dataParametrosAnularDocumento.nomColaborador = rowData.numeroRegistroAlterno + " - " + rowData.nomColaborador;
	dataParametrosAnularDocumento.descripcionDependencia = rowData.nomUuOoCom;
	dataParametrosAnularDocumento.montoTotal = rowData.mtoTotal;
	dataParametrosAnularDocumento.codigoColaborador = getValueInputText('hidCodigoRegistrador');
	dataParametrosAnularDocumento.codigoSedeColaborador = '';
	dataParametrosAnularDocumento.expedientePlanViaje = rowData.numExpSolic;
	dataParametrosAnularDocumento.codigoPaginaCaller = '03';	// colaborador
	initElementsAnularDocumento(dataParametrosAnularDocumento);
	
	showModalElement("divAnularDocumento");
}

function clickVerArchivo(codPlanViaje, nroRegistro) {
	
	
	var dataParametrosArchivo = new Object();
	var planillaTable = $( "#tblPlanilla" );
	var rowData = planillaTable.getRowData(codPlanViaje);
	var codPlanilla = $.trim( rowData.codPlanilla );
	var numArchivo = $.trim( rowData.numArchivo );
	if ( numArchivo == '' ) {

		showMensaje( 'No existen archivos adjuntos a esta Solicitud de Reembolsos: ' + codPlanilla );

	} else {
	dataParametrosArchivo.codigoBoleto = ''; 	  				// codigo vaucher 00000901
	dataParametrosArchivo.estadoOrigen = 'R';			  		// V: viatico
	dataParametrosArchivo.estadoLLamada = 'C'; 			   		// C: consulta, R: registro	
	dataParametrosArchivo.numeroRegistroColaborador = nroRegistro;
	dataParametrosArchivo.planViajeId = codPlanViaje;
	dataParametrosArchivo.paginaOrigen = 'PRINCIPAL';			// PRINCIPAL O SECUNDARIA(VAUCHER) 
	
	initElementsConsultarRegistrarEliminarArchivo(dataParametrosArchivo);
	$("#divAdjuntarDocumento").modal("show");
	triggerResizeEvent();
	}
}

$(window).on("resize", function() {
	resizeTable("tblPlanilla");
	resizeTable("tblSeguimiento");
	resizeTable("tblArchivo");
	resizeTable("tblUUOO");
	resizeTable("tblDetalleSolicitud");
	resizeTable("tblDetalleSolicitud2");
	resizeTable("tblDetalleViatico");
	resizeTable("tblDetalleGasto");
});
