function initElementsBuscarConceptoViatico(idElementCallModal, nacionalInternacional, listaConceptosExcluirJSON) {
	// nacionalInternacional: parametro adicional  ({ nacional, internacional })
	// listaConceptosExcluirJSON: la lista de codigos de concepto de las asignaciones en formato JSON
	
	setInitElementsBuscarConceptoViatico(nacionalInternacional, listaConceptosExcluirJSON);
	setInitConceptoViaticoTable(idElementCallModal);
}

function setInitElementsBuscarConceptoViatico(nacionalInternacional, listaConceptosExcluirJSON) {
	
	setValueInputText("hidNacionalInternacional", $.trim( nacionalInternacional ) );	    // nacional, internacional o vacio
	setValueInputText("hidListaCodigosExcluirJSON", $.trim( listaConceptosExcluirJSON ) );	// cadena JSON, o vacio
	setValueInputText("selTipoBusquedaBuscarConceptoViatico", "00");
	setValueInputText("txtConceptoViaticoDetalle", "");
	setHtmlElement("divConceptoViaticoPagerTable_left", "");
	hideElement("divErrorBuscarConceptoViatico");
	disabledElement("txtConceptoViaticoDetalle");
	disabledElement("btnBuscarConceptoViatico");
	disabledElement("btnAceptarBuscarConceptoViatico");
	addEventElement("btnBuscarConceptoViatico", "click", clickBtnBuscarConceptoViatico);
	addEventElement("btnBuscarTodosConceptoViatico", "click", clickBtnBuscarTodosConceptoViatico);
	addEventElement("btnAceptarBuscarConceptoViatico", "click", clickBtnAceptarBuscarConceptoViatico);
	addEventElement("btnCancelarBuscarConceptoViatico", "click", clickBtnCancelarBuscarConceptoViatico);
	addEventElement("selTipoBusquedaBuscarConceptoViatico", "change", changeselTipoBusquedaBuscarConceptoViatico);
}

function removeEventElementsBuscarConceptoViatico() {
	
	removeAllEventsElement("btnAceptarBuscarConceptoViatico");
	removeAllEventsElement("btnCancelarBuscarConceptoViatico");
	removeAllEventsElement("btnBuscarConceptoViatico");
	removeAllEventsElement("btnBuscarTodosConceptoViatico");
	removeAllEventsElement("selTipoBusquedaBuscarConceptoViatico");
}

function removeConceptoViaticoTable() {
	var htmlElement = "<table id=\"tblConceptoViatico\"></table>";
	htmlElement += "<div id=\"divConceptoViaticoPagerTable\" class=\"jqGridViaticoPagerClass\"></div>";
	setHtmlElement("divConceptoViatico", htmlElement);
} 
		
function setInitConceptoViaticoTable(idElementCallModal) {
	
	var conceptoViaticoTable = $("#tblConceptoViatico");
	
	if (conceptoViaticoTable) {
		
		var conceptoViaticoTableDiv = $("#" + idElementCallModal);
		var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.viaticoModalContainer", ".viaticoModalContainerAuxiliar", "width"))/100);
		var widthTable = factorRedimensionamiento*conceptoViaticoTableDiv.width();
  	
		conceptoViaticoTable.jqGrid({
			width: widthTable,
			height: 200,
			datatype: "local",
			rowNum: 10,
			rowList: [10, 20],
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames:[
				"Secuencial", 			// hidden
				"C&oacute;d",
				"Nombre Concepto",
				"clasificadorGasto", 	// hidden
				"conceptoCantidadPVI", 	// hidden
				"tipoFijoPVI" 	        // hidden
			],
			colModel:[
				{name: "numSecuencial", index: "numSecuencial", width: (1.2*widthTable/12), hidden: true},
				{name: "codigoConcepto", index: "codigoConcepto", width: (1.2*widthTable/12), align: 'center'},
				{name: "nombreConcepto", index: "nombreConcepto", width: (4.5*widthTable/12)},
				{name: "clasificadorGasto", index: "clasificadorGasto", width: (1*widthTable/12), hidden: true},
				{name: "conceptoCantidadPVI", index: "conceptoCantidadPVI", width: (1*widthTable/12), hidden: true},				
				{name: "tipoFijoPVI", index: "tipoFijoPVI", width: (1*widthTable/12), hidden: true}
			],
			pager : "#divConceptoViaticoPagerTable",
			loadui: "disable"
		});
	}
}

function clickBtnAceptarBuscarConceptoViatico() {
	
	var conceptoViaticoTable = $("#tblConceptoViatico");
	var rowId = conceptoViaticoTable.jqGrid("getGridParam", "selrow");
	
	if (rowId == null) {
		setHtmlElement("divConceptoViaticoPagerTable_left", errorMessageBuscarConceptoViatico.seleccionarRegistro);
	} else {
		
		var rowData = conceptoViaticoTable.getRowData(rowId);
		
		// si el evento after esta definido en el servicio
		if (typeof buscarConceptoViaticoService != "undefined" &&  typeof buscarConceptoViaticoService.eventos != "undefined" && typeof buscarConceptoViaticoService.eventos.eventoAfter != "undefined") {
			
			buscarConceptoViaticoService.eventos.eventoAfter(rowData);
			
		} 
		
		removeEventElementsBuscarConceptoViatico();
		removeConceptoViaticoTable();		
		$('#divBuscarConceptoViatico').modal('hide');
	}
}

function clickBtnCancelarBuscarConceptoViatico() {
	removeEventElementsBuscarConceptoViatico();
	removeConceptoViaticoTable();
	$('#divBuscarConceptoViatico').modal('hide');
}

function clickBtnBuscarConceptoViatico() {
	
	var flagParametrosValidos = true;
	var errorMessage = "";
	setHtmlElement("divConceptoViaticoPagerTable_left", "");
	hideElement("divErrorBuscarConceptoViatico");
	
	if (flagParametrosValidos && getValueInputText("selTipoBusquedaBuscarConceptoViatico") == "00") {
		errorMessage = errorMessageBuscarConceptoViatico.seleccionarTipoBusqueda;
		flagParametrosValidos = false;
	}
	
	if (flagParametrosValidos && trimText(getValueInputText("txtConceptoViaticoDetalle")) == "") {
		errorMessage = errorMessageBuscarConceptoViatico.completarDescripcion;
		flagParametrosValidos = false;
	}
	
	if (flagParametrosValidos && trimText(getValueInputText("txtConceptoViaticoDetalle")).length < 2) {
		errorMessage = errorMessageBuscarConceptoViatico.cantidadMinimaDescripcion;
		flagParametrosValidos = false;
	}
	
	if (flagParametrosValidos) {
		callObtenerConceptoViaticoByDescripcion("0");
	}
	else {
		showMessageErrorBuscarConceptoViatico(errorMessage);
	}
}

function clickBtnBuscarTodosConceptoViatico() {
	
	setValueInputText("selTipoBusquedaBuscarConceptoViatico", "00");
	setValueInputText("txtConceptoViaticoDetalle", "");
	setHtmlElement("divConceptoViaticoPagerTable_left", "");
	hideElement("divErrorBuscarConceptoViatico");
	disabledElement("txtConceptoViaticoDetalle");
	disabledElement("btnBuscarConceptoViatico");
	callObtenerConceptoViaticoByDescripcion("1");
}

function changeselTipoBusquedaBuscarConceptoViatico() {
	
	var conceptoViaticoTable = $("#tblConceptoViatico");
	conceptoViaticoTable.clearGridData();
	setValueInputText("txtConceptoViaticoDetalle", "");
	setHtmlElement("divConceptoViaticoPagerTable_left", "");
	hideElement("divErrorBuscarConceptoViatico");
	disabledElement("btnAceptarBuscarConceptoViatico");
	
	if (getValueInputText("selTipoBusquedaBuscarConceptoViatico") == "00") {
		disabledElement("txtConceptoViaticoDetalle");
		disabledElement("btnBuscarConceptoViatico");
	}
	else {
		enabledElement("txtConceptoViaticoDetalle");
		enabledElement("btnBuscarConceptoViatico");
	}
}

function callObtenerConceptoViaticoByDescripcion(indicadorBotonBuscar) {
	
	setTimeout(function(){
		
		var conceptoViaticoTable = $("#tblConceptoViatico");
		conceptoViaticoTable.clearGridData();
		setHtmlElement("divConceptoViaticoPagerTable_left", "");
		disabledElement("btnAceptarBuscarConceptoViatico");
		$.ajax({
			url: contextPathUrl + "/viatico.htm?action=obtenerConceptosByDescripcion",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"nacionalInternacional": getValueInputText("hidNacionalInternacional"),
				"listaConceptosExcluirJSON": getValueInputText("hidListaCodigosExcluirJSON"),				
				"codigoTipoBusqueda": getValueInputText("selTipoBusquedaBuscarConceptoViatico"),
				"descripcionConceptoViatico": getUpperCaseValueInputText("txtConceptoViaticoDetalle"),
				"indicadorBotonBuscar": indicadorBotonBuscar								
			},
			beforeSend: function() {
				showElement("divLoadingBuscarConceptoViatico");
			},
			complete: function() {
				hideElement("divLoadingBuscarConceptoViatico");
			},
			success: function(result) {
				
				var conceptoList = result.conceptoList;
				
				if (conceptoList != null && conceptoList.length > 0) {
					
					for (var i = 0; i < conceptoList.length; i++) {
						
						var concepto = conceptoList[i]; 
						
						var datarow = {
							numSecuencial: (i + 1),
							codigoConcepto: concepto.codigoConcepto,
							nombreConcepto: concepto.descripcionConcepto,
							clasificadorGasto: concepto.clasificadorGasto,
							conceptoCantidadPVI: concepto.conceptoCantidadPVI,
							tipoFijoPVI: concepto.tipoFijoPVI
						};
						
						conceptoViaticoTable.jqGrid("addRowData", datarow.numSecuencial, datarow);
					}
					
					conceptoViaticoTable.trigger("reloadGrid");
					enabledElement("btnAceptarBuscarConceptoViatico");
					
				} else {
					setHtmlElement("divConceptoViaticoPagerTable_left", errorMessageBuscarConceptoViatico.sinRegistrosBusqueda);
				}
			},
			error: function() {
				consoleLog("Error callObtenerConceptoViaticoByDescripcion");
			}
		});
	}, 500);
} 

function showMessageErrorBuscarConceptoViatico(errorMessage) {
	setHtmlElement("etiquetaErrorBuscarConceptoViatico", errorMessage);
	showElement("divErrorBuscarConceptoViatico");
}