/// <reference path="../general/common.js" />
/// <reference path="../../WEB-INF/jsp/solicitud/revisarSolicitudBandeja.jsp" />
/// <reference path="D:\jcfr\data\ts-definitions\DefinitelyTyped-master\jquery\jquery.d.ts" />

// servicios buscar uuoo y colaborador
var buscarUUOOService = null;

var buscarUUOOInputService = null;

var buscarColaboradorService = null;

var buscarColaboradorInputService = null;

// éste módulo requiere definir estadosSolicitudViatico y errorMessageRevisarSolicitudBandeja
function initElementsRevisarSolicitudBandeja( dataJSON ) {
	removeDuplicateComponents();
	setInitElementsRevisarSolicitudBandeja( dataJSON );
	setInitPlanillaTable();
}

function setInitElementsRevisarSolicitudBandeja() {
	
	disabledElement("btnExportarExcelSolicitud");
	setValueInputText("selEstadoSolicitud", "");
	setValueInputText("selAnioSolicitud", getValueInputText("hidAnioActual"));
	setValueInputText("selCanalAtencionSolicitud", "");
	setValueInputText("hidFechaMaximaAnioActual", getValueInputText("hidAnioActual") + "/12/31");
	modificarRangoFechaSolicitudBandeja(getValueInputText("hidAnioActual"));
	addEventElement("selEstadoSolicitud", "change", changeSelEstadoSolicitud);
	addEventElement("selAnioSolicitud", "change", changeSelAnioSolicitud);
	addEventElement("selCanalAtencionSolicitud", "change", changeSelCanalAtencionSolicitud);
	addEventElement("btnConsultarSolicitud", "click", clickBtnConsultarSolicitud);
	addEventElement("btnBuscarUUOOSolicitud", "click", clickBtnBuscarUUOOSolicitud);
	addEventElement("btnBuscarColaboradorSolicitud", "click", clickBtnBuscarColaboradorSolicitud);
	addEventElement("btnExportarExcelSolicitud", "click", clickBtnExportarExcelSolicitud);
	addEventElement("etiquetaFechaInicioSolicitud", "change", changeEtiquetaFechaInicioSolicitud);
	addEventElement("etiquetaFechaFinSolicitud", "change", changeEtiquetaFechaFinSolicitud);
	initDateTimePickerWithMaxDate("etiquetaFechaInicioSolicitudDiv", "dp.change", "changeDate", changeDateEtiquetaFechaInicioSolicitudDiv, getValueInputText("hidFechaMaximaAnioActual"));
	initDateTimePickerWithMaxDate("etiquetaFechaFinSolicitudDiv", "dp.change", "changeDate", changeDateEtiquetaFechaFinSolicitudDiv, getValueInputText("hidFechaMaximaAnioActual"));
	
	// si viene la data JSON para restaurar la pantalla de busqueda
	restaurarEstadoBandeja( dataJSON );
}

function restaurarEstadoBandeja( dataJSON ) {

	// si hay data para restaurar
	if ( estaDefinido( dataJSON ) && dataJSON != '' ) {

		var dataJSON = $.parseJSON( dataJSON );

		if ( estaDefinido( dataJSON ) ) {

			// retaurar vista
			for( var propiedad in dataJSON ) {
				$( '#' + propiedad ).val( dataJSON[ propiedad ] );
			}
			
			// $( '#btnConsultarSolicitud' ).trigger( 'click' );
		}

	}
 
}

function setInitPlanillaTable() {
	
	var planillaTable = $("#tblPlanilla");
	var heightJqGrid = 190;
	setStyleElement("divPlanillaTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 2, false));
	if (planillaTable) {
		var planillaTableDiv = $("#divPlanillaTable");
		var widthTable = planillaTableDiv.width();
		planillaTable.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			datatype: "local",
			rowNum: 10,
			rowList: [10, 20],
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
			    "N&deg; Planilla",
			    "Fecha de registro",
			    "Nombre Colaborador",
			    "Tipo de Vi&aacute;ticos",
			    "Total Otorgado",
			    "Canal de Atenci&oacute;n",
			    "Plazo para Rendir",
			    "Estado Planilla", 
			    "",
			    "Acci&oacute;n", 
			    "",
			    "",				// hidden
			    "codPlanViaje",      		// hidden
			    "tipoDestino",      		// hidden
			    "indicadorHoras",      		// hidden
			    "numArchivo",        		// hidden
			    "numExpSolic",       		// hidden
			    "obsSolicitud",      		// hidden
			    "codEstadoSolic",     		// hidden
			    "nomUuOoCom",     			// hidden
			    "numeroRegistroAlterno",    // hidden
				"indicadorTraslape",     	// hidden
				"indicadorAutorizacion",    // hidden
				"codPlanilla"			    // hidden
			],
			colModel: [
				{name:'codPlanillaLink',index:'codPlanillaLink', width:(1.15*widthTable/12),align:'center',
					formatter: function(cellvalue, options, rowObject) {
						
						var codPlanilla = $.trim( rowObject.codPlanilla );
						var codEstadoSolic  = $.trim( rowObject.codEstadoSolic );
						
						// solo los elaborados y observados se pueden modificar
						var accion = 'consultar';

						var estaObservado = codEstadoSolic == estadosSolicitudViatico.OBSERVADO || 
											codEstadoSolic == estadosSolicitudViatico.OBSERVADO_CAJA_CHICA || 
											codEstadoSolic == estadosSolicitudViatico.OBSERVADO_FINANCIERA;

						if (codEstadoSolic == estadosSolicitudViatico.ELABORADO || estaObservado) {
							accion = 'modificar';
						}
						
						// ejecuta la acción						
						if ( accion == 'modificar' ) {
						
							return "<a class=\"jqGridViaticoLinkClass\" href=\"javascript:void(0);\" onclick=\"javascript:clickBtnModificarPlanilla('"+codPlanilla+"');\">" + codPlanilla + "</a>";
							
						} else if ( accion == 'consultar' ) {
							
							return "<a class=\"jqGridViaticoLinkClass\" href=\"javascript:void(0);\" onclick=\"javascript:clickBtnConsultaPlanilla('"+codPlanilla+"');\">" + codPlanilla + "</a>";	
						}
						
						return ' ';
					}
				},
				{name:'fecRegistro',index:'fecRegistro',width:(0.75*widthTable/12),align:'center'},
				{name:'nomColaborador',index:'nomColaborador', width:(1.6*widthTable/12)},
				{name:'nomTipoViatico',index:'nomTipoViatico', width:(0.95*widthTable/12),align: 'center'},
				{name:'mtoTotal',index:'mtoTotal', width:(1*widthTable/12),align:'right'},
				{name:'canalAtencion',index:'canalAtencion', width:(1.1*widthTable/12),align:'center'},
				{name:'fecMaxRend',index:'fecMaxRend', width:(0.9*widthTable/12),align: 'center'},
				{name:'nomEstSolic',index:'nomEstSolic', width:(1*widthTable/12),align:'center',
					formatter: function(cellvalue, options, rowObject) {
						
						// ESTADO PLANILLA
					    var nomEstSolic = $.trim( rowObject.nomEstSolic ).toUpperCase();
					    var motivoObservacion  = $.trim( rowObject.obsSolicitud );	// motivo de la observación
					    var codEstadoSolic  = $.trim( rowObject.codEstadoSolic );
						
						var estaObservado = codEstadoSolic == estadosSolicitudViatico.OBSERVADO || 
											codEstadoSolic == estadosSolicitudViatico.OBSERVADO_CAJA_CHICA || 
											codEstadoSolic == estadosSolicitudViatico.OBSERVADO_FINANCIERA;
						
						// si esta observado, mostrar el motivo de la observación en el title
					    var title = estaObservado? motivoObservacion : nomEstSolic;
						
						return '<span title="' + title + '">' + nomEstSolic + '</span>';
					}
				},
				{name:'detalle',index:'detalle', width:(0.6*widthTable/12), align:'center', 
					formatter: function(cellvalue, options, rowObject) {
					    var codPlanViaje = $.trim( rowObject.codPlanViaje );
					    return "<a class=\"jqGridViaticoLinkClass\" href=\"javascript:void(0);\" onclick=\"javascript:clickVerDetalle('"+codPlanViaje+"');\">DETALLE</a>"; 
					}
				},
				{name:'seguimiento',index:'seguimiento', width:(0.9*widthTable/12),align:'center',
					formatter: function (cellvalue, options, rowObject) {
						
						var codPlanViaje = $.trim( rowObject.codPlanViaje );
						
					    return "<a class=\"jqGridViaticoLinkClass\" href=\"javascript:void(0);\" onclick=\"javascript:clickVerSeguimiento('"+codPlanViaje+"');\">SEGUIMIENTO</a>";					    
					}
				},
				{name:'anular',index:'anular', width:(0.55*widthTable/12),align:'center',
					formatter: function (cellvalue, options, rowObject) {

						var codPlanViaje = $.trim( rowObject.codPlanViaje );
						var codEstadoSolic  = $.trim( rowObject.codEstadoSolic );
						
						// puede anular solo si esta en estado elaborado u algun observado
						var puedeAnular = codEstadoSolic == estadosSolicitudViatico.ELABORADO || 
										  codEstadoSolic == estadosSolicitudViatico.OBSERVADO || codEstadoSolic == estadosSolicitudViatico.OBSERVADO_CAJA_CHICA || codEstadoSolic == estadosSolicitudViatico.OBSERVADO_FINANCIERA;
										  
						if ( puedeAnular ) { 
							return "<a class=\"jqGridViaticoLinkClass\" href=\"javascript:void(0);\" onclick=\"javascript:clickVerAnular('"+codPlanViaje+"');\">ANULAR</a>";
						}
						
						return ' ';
					}
				},
				{name:'ver',index:'ver', width:(0.4*widthTable/12),align:'center',
					formatter: function (cellvalue, options, rowObject) {
						
						var codPlanViaje = $.trim( rowObject.codPlanViaje );
						
						return "<a class=\"jqGridViaticoLinkClass\" href=\"javascript:void(0);\" onclick=\"javascript:clickVerArchivo('"+codPlanViaje+"');\">VER</a>";
					}
				},
				{name:'codPlanilla',index:'codPlanilla', width:(0.1*widthTable/12),hidden: true},
				{name:'tipoDestino',index:'tipoDestino', width:(0.1*widthTable/12),hidden: true},
				{name:'indicadorHoras',index:'indicadorHoras', width:(0.1*widthTable/12),hidden: true},
				{name:'codPlanViaje',index:'codPlanViaje', width:(0.1*widthTable/12),hidden: true},				
				{name:'numArchivo',index:'numArchivo', width:(0.1*widthTable/12),hidden: true},
				{name:'numExpSolic', index:'numExpSolic', width:(0.1*widthTable/12), hidden: true},
				{name:'obsSolicitud', index:'obsSolicitud', width:(0.1*widthTable/12), hidden: true},
				{name:'codEstadoSolic', index:'codEstadoSolic', width:(0.1*widthTable/12), hidden: true},
				{name:'nomUuOoCom', index:'nomUuOoCom', width:(0.1*widthTable/12), hidden: true},
				{name:'numeroRegistroAlterno', index:'numeroRegistroAlterno', width:(0.1*widthTable/12), hidden: true},
				{name:'indicadorTraslape', index:'indicadorTraslape', width:(0.1*widthTable/12), hidden: true},
				{name:'indicadorAutorizacion', index:'indicadorAutorizacion', width:(0.1*widthTable/12), hidden: true},				
			],
			rowattr: function(dataTable) {				

				var codEstadoSolic  = $.trim( dataTable.codEstadoSolic );
				var indicadorTraslape  = $.trim( dataTable.indicadorTraslape );
					
				if ( codEstadoSolic == estadosSolicitudViatico.ANULADO ) {										
					return {"class": "colorFontRedTableClass"};		
				}
				
				var estaObservado = codEstadoSolic == estadosSolicitudViatico.OBSERVADO || 
									codEstadoSolic == estadosSolicitudViatico.OBSERVADO_CAJA_CHICA || 
									codEstadoSolic == estadosSolicitudViatico.OBSERVADO_FINANCIERA;
				
				if ( estaObservado ) {
					return {"class": "colorFontOrangeTableClass"};
				}

				if (indicadorTraslape == "1") {					
					return {"class": "colorFontCelesteTableClass"};
				}
				
			},
			//caption: "Planillas",
			pager: "#divPlanillaPagerTable",
			loadui: "disable"
		});
		planillaTable.clearGridData();
		addEventElementBySelector("#divPlanillaTable .ui-pg-button.ui-corner-all", "click", clickPagerPlanillaTable);
		addEventElementBySelector("#divPlanillaTable input.ui-pg-input", "keypress", keypressPagerPlanillaTable);
		addEventElementBySelector("#divPlanillaTable select.ui-pg-selbox", "change", changePagerPlanillaTable);
	}
}

function changeSelEstadoSolicitud() {
	clearPlanillaTableSolicitudBandeja();
}

function changeSelAnioSolicitud() {
	
	var anioSeleccionado = getValueInputText("selAnioSolicitud");
	hideElement("divErrorRevisionSolicitudBandeja");
	modificarRangoFechaSolicitudBandeja(anioSeleccionado);
	clearPlanillaTableSolicitudBandeja();
}

function changeSelCanalAtencionSolicitud() {
	clearPlanillaTableSolicitudBandeja();
}

function changeEtiquetaFechaInicioSolicitud() {
	if (isBrowserInternetExplorer()) {
		if (trimText(getValueInputText("etiquetaFechaInicioSolicitud")) != "" && isValidoFormatDate(getValueInputText("etiquetaFechaInicioSolicitud"))) {
			if (isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaInicioSolicitud")), getValueInputText("hidFechaMaximaAnioActual"))) {
				setValueInputText("etiquetaFechaInicioSolicitud", "");
			}
		}
		else {
			setValueInputText("etiquetaFechaInicioSolicitud", "");
		}
		changeDateEtiquetaFechaInicioSolicitudDiv();
	}
}

function changeEtiquetaFechaFinSolicitud() {
	if (isBrowserInternetExplorer()) {
		if (trimText(getValueInputText("etiquetaFechaFinSolicitud")) != "" && isValidoFormatDate(getValueInputText("etiquetaFechaFinSolicitud"))) {
			if (isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaFinSolicitud")), getValueInputText("hidFechaMaximaAnioActual"))) {
				setValueInputText("etiquetaFechaFinSolicitud", "");
			}
		}
		else {
			setValueInputText("etiquetaFechaFinSolicitud", "");
		}
		changeDateEtiquetaFechaFinSolicitudDiv();
	}
}

function changeDateEtiquetaFechaInicioSolicitudDiv() {
	clearPlanillaTableSolicitudBandeja();
	validarFechaInicioRevisarSolicitudBandeja();
}

function changeDateEtiquetaFechaFinSolicitudDiv() {
	clearPlanillaTableSolicitudBandeja();
	validarFechaFinalRevisarSolicitudBandeja();
}

function clickBtnConsultarSolicitud() {
	
	var flagValidacionFormulario = true;
	var errorMessage = "";
	hideElement("divErrorRevisionSolicitudBandeja");
	setHtmlElement("divPlanillaPagerTable_left", "");
	disabledElement("btnConsultarSolicitud");
	clearPlanillaTableSolicitudBandeja();
	
	// cuando no ingresa ni uuoo ni número de registro (validación agregada por observación)
	if (flagValidacionFormulario && trimText(getValueInputText("hidCodigoColaborador")).length == 0 && trimText(getValueInputText("hidCodigoDependencia")).length == 0) {
		flagValidacionFormulario = false;
		errorMessage = errorMessageRevisarSolicitudBandeja.numeroRegistroUUOOInvalido;
		darFoco( '#txtUUOO' );
	}	
	
	// cuando no ingresa un número de registro válido
	if (flagValidacionFormulario && trimText(getValueInputText("txtNroRegistro")).length != 0 && trimText(getValueInputText("hidCodigoColaborador")).length == 0  ) { 
		flagValidacionFormulario = false;
		errorMessage = errorMessageRevisarSolicitudBandeja.numeroRegistroInvalido;
		darFoco( '#txtNroRegistro' );
	}

	// fechas ingresadas
	var fechaFin = getTrimValue( '#etiquetaFechaFinSolicitud' );
	var fechaInicio = getTrimValue( '#etiquetaFechaInicioSolicitud' );

	// fechas de rango (combo anio)
	var rangoFin = getTrimValue( '#hidFechaFinalRangoFecha' );
	var rangoInicio = getTrimValue( '#hidFechaInicialRangoFecha' );

	// cuando no ingresa fecha de inicio
	if (flagValidacionFormulario && fechaInicio == '' ) { 
		flagValidacionFormulario = false;
		errorMessage = errorMessageRevisarSolicitudBandeja.fechaInicioVacio;
		darFoco( '#etiquetaFechaInicioSolicitud' ); 
	}

	// cuando no ingresa fecha de fin
	if (flagValidacionFormulario && fechaFin == '' ) { 
		flagValidacionFormulario = false;
		errorMessage = errorMessageRevisarSolicitudBandeja.fechaFinalVacio;
		darFoco( '#etiquetaFechaFinSolicitud' );
	}		

	// validar que la fecha fin debe ser mayor o igual a la fecha de inicio
	if (flagValidacionFormulario && esFechaValida(fechaInicio) && esFechaValida(fechaFin) ) {
		if ( !esFechaMayorIgual( fechaFin, fechaInicio ) ) {
			flagValidacionFormulario = false;
			errorMessage = errorMessageRevisarSolicitudBandeja.fechaFinalMenorFechaInicial;
			darFoco( '#etiquetaFechaFinSolicitud' );
		}
	}
	
	// valida que fecha de inicio este dentro del rango del anio
	if (flagValidacionFormulario && esFechaValida(fechaInicio)) {
		if ( !( esFechaMayorIgual( fechaInicio, rangoInicio ) && esFechaMenorIgual( fechaInicio, rangoFin ) ) ) {
			flagValidacionFormulario = false;
			errorMessage = errorMessageRevisarSolicitudBandeja.fechaInicioFueraRango + ".";
			darFoco( '#etiquetaFechaInicioSolicitud' );
		}
	}

	// valida que fecha de fin este dentro del rango del anio
	if (flagValidacionFormulario && esFechaValida(fechaFin)) {
		if ( !( esFechaMayorIgual( fechaFin, rangoInicio ) && esFechaMenorIgual( fechaFin, rangoFin ) ) ) {
			flagValidacionFormulario = false;
			errorMessage = errorMessageRevisarSolicitudBandeja.fechaFinFueraRango + ".";
			darFoco( '#etiquetaFechaFinSolicitud' );
		}
	}	

	if (flagValidacionFormulario) {
		callBuscarPlanillasBandeja();
	}
	else {
		showMessageErrorRevisionSolicitudBandeja(errorMessage);
		enabledElement("btnConsultarSolicitud");
	}
}


// BUSCAR UUOO
function clickBtnBuscarUUOOSolicitud() {

	var dataParametrosBuscarUUOO = new Object();

	dataParametrosBuscarUUOO.idCodigoRegistrador = "hidCodigoRegistrador";
	dataParametrosBuscarUUOO.idCodigoTipoUUOOViatico = getTrimValue( '#hidCodigoTipoUUOOViatico' );
	dataParametrosBuscarUUOO.idDivScreenBlock = "divScreenBlock";
	
	buscarUUOOService = new BuscarUUOOService(dataParametrosBuscarUUOO, buscarUUOOBeforeMethod, buscarUUOOAfterMethod);
	
	initElementsBuscarUUOO("divPlanillaTable");
	$("#divBuscarUUOO").modal("show");	
	triggerResizeEvent();

	setTimeout(function() {
		resizeTable( "tblUUOO" );
	}, 700);
}

function buscarUUOOBeforeMethod() {
	
	// limpiar datos de la uuoo
	setValueInputText("hidCodigoDependencia", '');
	setValueInputText("txtDescripcionDependencia", '');
	
	// limpiar datos del colaborador
	setValueInputText('txtNroRegistro', '');
	setValueInputText('hidTxtNroRegistro', '');
	setValueInputText('txtNombreColaborador', '');
	setValueInputText('hidCodigoColaborador', '');
	setValueInputText('hidCodigoEstadoColaborador', '');	
	
	// limpiar label y ocultar div de mensaje de error
	setHtmlElement('etiquetaErrorRevisionSolicitudBandeja', '');
	hideElement('divErrorRevisionSolicitudBandeja');

	// limpiar grilla
	clearPlanillaTableSolicitudBandeja();		
	
}

function buscarUUOOAfterMethod(rowData) {
	
	// setear datos de la uuoo
	setValueInputText("txtUUOO", rowData["uuoo"]);
	setValueInputText("hidTxtUUOO", rowData["uuoo"]);
	setValueInputText("hidCodigoDependencia", rowData["codigoDependencia"]);
	setValueInputText("txtDescripcionDependencia", rowData["descripcionUUOO"]);
}

// BUSCAR UUOO INPUT
function initElementsBuscarUUOOInputService( errorMessageBuscarUUOOInput ) {

	var dataParametros = new Object();
	
	dataParametros.idNumeroUUOO = "txtUUOO";
	dataParametros.idCodigoRegistrador = "hidCodigoRegistrador";
	dataParametros.idCodigoTipoUUOOViatico = getTrimValue( '#hidCodigoTipoUUOOViatico' );
	dataParametros.idDivLoading = "divLoadingRevisionSolicitudBandejaInput";
	dataParametros.idDivError = "divErrorRevisionSolicitudBandeja";	
	dataParametros.idEtiquetaError = "etiquetaErrorRevisionSolicitudBandeja";
	dataParametros.idDivScreenBlock = "divScreenBlock";
	dataParametros.errorMessage = errorMessageBuscarUUOOInput;
	
	this.idNumeroUUOO = dataParametros.idNumeroUUOO;

	buscarUUOOInputService = new BuscarUUOOInputService( dataParametros, buscarUUOOInputBeforeMethod, buscarUUOOInputAfterMethod );
}

function buscarUUOOInputBeforeMethod() {
 
	// limpiar datos de la uuoo
	setValueInputText("hidTxtUUOO", '');
	setValueInputText("hidCodigoDependencia", '');
	setValueInputText("txtDescripcionDependencia", '');	
	
	// limpiar datos del colaborador
	setValueInputText('txtNroRegistro', '');
	setValueInputText('hidTxtNroRegistro', '');
	setValueInputText('txtNombreColaborador', '');
	setValueInputText('hidCodigoColaborador', '');
	setValueInputText('hidCodigoEstadoColaborador', '');	
	
	// limpiar label y ocultar div de mensaje de error
	setHtmlElement('etiquetaErrorRevisionSolicitudBandeja', '');
	hideElement('divErrorRevisionSolicitudBandeja');
	
	// limpiar grilla
	clearPlanillaTableSolicitudBandeja();	
}

function buscarUUOOInputAfterMethod(uuooList) {
	
	if (uuooList != null && uuooList.length > 0) {
		
		for ( var i = 0; i < uuooList.length; i++) {
			
			var uuoo = uuooList[i];
			var datarow = {
				codigoDependencia : uuoo.cod_dep,
				uuoo : uuoo.uuoo,
				uuooDetalle : uuoo.nom_largo
			};
			
			// setear datos de la uuoo
			setValueInputText("txtUUOO", datarow.uuoo);
			setValueInputText("hidTxtUUOO", datarow.uuoo);
			setValueInputText("hidCodigoDependencia", datarow.codigoDependencia);
			setValueInputText("txtDescripcionDependencia", datarow.uuooDetalle);
			
			break;
		}
		
	} else {		
		setHtmlElement('etiquetaErrorRevisionSolicitudBandeja', errorMessageBuscarUUOOInput.sinRegistrosBusqueda);
		showElement("divErrorRevisionSolicitudBandeja");
	}
}

// BUSCAR COLABORADOR
function clickBtnBuscarColaboradorSolicitud() {
 
	var dataParametrosBuscarColaborador = new Object();
	
	dataParametrosBuscarColaborador.idCodigoRegistrador = "hidCodigoRegistrador";
	dataParametrosBuscarColaborador.idNumeroRegistroRegistrador = "hidNumeroRegistroRegistrador";
	dataParametrosBuscarColaborador.idCodigoTipoUsuarioViatico = getTrimValue( '#hidCodigoTipoUsuarioViatico' );
	dataParametrosBuscarColaborador.idDivScreenBlock = "divScreenBlock";
	dataParametrosBuscarColaborador.estadoLlamada = "B";
	
	buscarColaboradorService = new BuscarColaboradorService( dataParametrosBuscarColaborador, buscarColaboradorBeforeMethod, buscarColaboradorAfterMethod );
	
	var flagAsociarUUOOBuscarColaborador = false;
	initElementsBuscarColaborador("divPlanillaTable",flagAsociarUUOOBuscarColaborador);
	$("#divBuscarColaborador").modal("show");
	triggerResizeEvent();

	setTimeout(function() {
		resizeTable( "tblColaborador" );
	}, 700);	
}

function buscarColaboradorBeforeMethod() {
	
	// limpiar datos del colaborador
	setValueInputText('txtNombreColaborador', '');
	setValueInputText('hidCodigoColaborador', '');
	setValueInputText('hidCodigoEstadoColaborador', '');	
	
	// limpiar datos de la uuoo
	// setValueInputText("txtUUOO", '');
	// setValueInputText("hidTxtUUOO", '');
	// setValueInputText("hidCodigoDependencia", '');
	// setValueInputText("txtDescripcionDependencia", '');		
	
	// limpiar label y ocultar div de mensaje de error
	setHtmlElement('etiquetaErrorRevisionSolicitudBandeja', '');
	hideElement('divErrorRevisionSolicitudBandeja');
	
	// limpiar grilla
	clearPlanillaTableSolicitudBandeja();
}

function buscarColaboradorAfterMethod(rowData) {
	
	// setear datos del colaborador
	setValueInputText("txtNroRegistro", $.trim(rowData["numeroRegistro"]));
	setValueInputText("hidTxtNroRegistro", $.trim(rowData["numeroRegistro"]));
	setValueInputText("hidCodigoColaborador", $.trim(rowData["codigoEmpleado"]));
	setValueInputText("txtNombreColaborador", $.trim(rowData["nombreCompleto"]));
	setValueInputText("hidCodigoEstadoColaborador", $.trim(rowData["codigoEstado"]));
	
	// setear datos de la uuoo
	setValueInputText("txtUUOO", $.trim(rowData["uuoo"]));
	setValueInputText("hidTxtUUOO", $.trim(rowData["uuoo"]));
	setValueInputText("txtDescripcionDependencia", $.trim(rowData["uuooDetalle"]));
	setValueInputText("hidCodigoDependencia", $.trim(rowData["codigoDependencia"]));
}

// BUSCAR COLABORADOR INPUT
function initElementsBuscarColaboradorInputService( errorMessageBuscarColaboradorInput ) {

	var dataParametros = new Object();
	
	dataParametros.idCodigoDependencia = "hidCodigoDependencia";
	dataParametros.idNumeroRegistroColaborador = "txtNroRegistro";
	dataParametros.idCodigoRegistrador = "hidCodigoRegistrador";
	dataParametros.idNumeroRegistroRegistrador = "hidNumeroRegistroRegistrador";
	dataParametros.idCodigoTipoUsuarioViatico = getTrimValue( '#hidCodigoTipoUsuarioViatico' );
	dataParametros.idDivLoading = "divLoadingRevisionSolicitudBandejaInput";
	dataParametros.idDivError = "divErrorRevisionSolicitudBandeja";	
	dataParametros.idEtiquetaError = "etiquetaErrorRevisionSolicitudBandeja";
	dataParametros.idDivScreenBlock = "divScreenBlock";
	dataParametros.estadoLlamada = "B";	
	dataParametros.errorMessage = errorMessageBuscarColaboradorInput;

	buscarColaboradorInputService = new BuscarColaboradorInputService( dataParametros, buscarColaboradorInputBeforeMethod, buscarColaboradorInputAfterMethod );
}

function buscarColaboradorInputBeforeMethod() {
	
	// limpiar datos del colaborador
	setValueInputText('txtNombreColaborador', '');
	setValueInputText('hidTxtNroRegistro', '');
	setValueInputText('hidCodigoColaborador', '');
	setValueInputText('hidCodigoEstadoColaborador', '');	

	// limpiar datos de la uuoo
	// setValueInputText("txtUUOO", '');
	// setValueInputText("hidTxtUUOO", '');
	// setValueInputText("hidCodigoDependencia", '');
	// setValueInputText("txtDescripcionDependencia", '');

	// limpiar label y ocultar div de mensaje de error
	setHtmlElement('etiquetaErrorRevisionSolicitudBandeja', '');
	hideElement('divErrorRevisionSolicitudBandeja');
	
	// limpiar grilla
	clearPlanillaTableSolicitudBandeja();		
}

function buscarColaboradorInputAfterMethod(colaboradorList) {
	
	if (colaboradorList != null && colaboradorList.length > 0) {
		
		for ( var i = 0; i < colaboradorList.length; i++) {
			var colaborador = colaboradorList[i];
			var datarow = {
				numeroRegistro : colaborador.numero_registro,
				nombreCompleto : colaborador.nombre_completo,
				uuoo : colaborador.uuoo,
				codigoDependencia : colaborador.codigoDependencia,
				uuooDetalle : colaborador.dependencia,
				codigoEmpleado : colaborador.codigoEmpleado,
				codigoEstado : colaborador.codigoEstado,
				estadoDetalle : colaborador.estado
			};
			
			// setear datos del colaborador
			setValueInputText("txtNroRegistro", $.trim(datarow.numeroRegistro));
			setValueInputText("hidTxtNroRegistro", $.trim(datarow.numeroRegistro));
			setValueInputText("hidCodigoColaborador", $.trim(datarow.codigoEmpleado));
			setValueInputText("txtNombreColaborador", $.trim(datarow.nombreCompleto));
			setValueInputText("hidCodigoEstadoColaborador", $.trim(datarow.codigoEstado));			
			
			// setear datos de la uuoo
			setValueInputText("txtUUOO", $.trim(datarow.uuoo));
			setValueInputText("hidTxtUUOO", $.trim(datarow.uuoo));
			setValueInputText("hidCodigoDependencia",  $.trim(datarow.codigoDependencia));
			setValueInputText("txtDescripcionDependencia", $.trim(datarow.uuooDetalle));
			
			break;
		}

		
	} else {

		setHtmlElement('etiquetaErrorRevisionSolicitudBandeja', errorMessageBuscarColaboradorInput.sinRegistrosBusqueda);
		showElement("divErrorRevisionSolicitudBandeja");
	}
}

function clickBtnExportarExcelSolicitud() {
 
	var params = {
		"codUUOO"			:	getTrimValue( '#txtUUOO' ),
		"codDependencia"	:	getTrimValue( '#hidCodigoDependencia' ),
		"codColaborador"	:	getTrimValue( '#hidCodigoColaborador' ),
		"codRegistrador"	:	getTrimValue( '#hidCodigoRegistrador' ),
		"codEstado"			: 	getTrimValue( '#selEstadoSolicitud' ),
		"codCanal"			: 	getTrimValue( '#selCanalAtencionSolicitud' ),
		"fechaDesde"	 	:	getTrimValue( '#etiquetaFechaInicioSolicitud' ),
		"fechaHasta"	 	:	getTrimValue( '#etiquetaFechaFinSolicitud' ),
		"numPlanilla"	 	:	getTrimValue( '#txtCodigoPlanilla' ).toUpperCase(),
		"tipoBandeja"	 	:	'01'
	};	
	
	$(location).prop( 'href', contextPathUrl + '/solicitud.htm?action=exportadoExcel&' + $.param( params ) );
}

function clickPagerPlanillaTable() {
	showTooltip();
}

function keypressPagerPlanillaTable(event) {
	var keyCode = window.event ? event.keyCode : event.which;
	if (keyCode == 13) {
		showTooltip();
	}
}

function changePagerPlanillaTable() {
	showTooltip();
}

function modificarRangoFechaSolicitudBandeja(anioSeleccionado) {
	
	setValueInputText("hidFechaInicialRangoFecha", "01/01/" + anioSeleccionado);
	setValueInputText("hidFechaFinalRangoFecha", "31/12/" + anioSeleccionado);
	setValueInputText("etiquetaFechaInicioSolicitud", getValueInputText("hidFechaInicialRangoFecha"));
	setValueInputText("etiquetaFechaFinSolicitud", getValueInputText("hidFechaFinalRangoFecha"));
	setValueInputText("hidFlagFechaInicioValida", "");
	setValueInputText("hidFlagFechaFinalValida", "");
}

function validarFechaInicioRevisarSolicitudBandeja() {
	
	var errorMessage = '';
	var flagFechaValida = true;

	hideElement("divErrorRevisionSolicitudBandeja");

	// fechas ingresadas
	var fechaFin = getTrimValue( '#etiquetaFechaFinSolicitud' );
	var fechaInicio = getTrimValue( '#etiquetaFechaInicioSolicitud' );

	// fechas de rango (combo anio)
	var rangoFin = getTrimValue( '#hidFechaFinalRangoFecha' );
	var rangoInicio = getTrimValue( '#hidFechaInicialRangoFecha' );
	
	// valida que fecha de inicio este dentro del rango del anio
	if (flagFechaValida && esFechaValida(fechaInicio)) {
		if ( !( esFechaMayorIgual( fechaInicio, rangoInicio ) && esFechaMenorIgual( fechaInicio, rangoFin ) ) ) {
			flagFechaValida = false;
			errorMessage = errorMessageRevisarSolicitudBandeja.fechaInicioFueraRango + ".";
			darFoco( '#etiquetaFechaInicioSolicitud' );
		}
	}

	// validar que la fecha fin debe ser mayor o igual a la fecha de inicio
	if (flagFechaValida && esFechaValida(fechaInicio) && esFechaValida(fechaFin) ) {
		if ( !esFechaMayorIgual( fechaFin, fechaInicio ) ) {
			flagFechaValida = false;
			errorMessage = errorMessageRevisarSolicitudBandeja.fechaFinalMenorFechaInicial;
			darFoco( '#etiquetaFechaFinSolicitud' );
		}
	}
	
	if (!flagFechaValida) {
		setValueInputText("hidFlagFechaInicioValida", errorMessage);
		showMessageErrorRevisionSolicitudBandeja(errorMessage);
	} else {
		setValueInputText("hidFlagFechaInicioValida", "");
	}
	
}

function validarFechaFinalRevisarSolicitudBandeja() {
	
	var errorMessage = '';
	var flagFechaValida = true;

	hideElement("divErrorRevisionSolicitudBandeja");

	// fechas ingresadas
	var fechaFin = getTrimValue( '#etiquetaFechaFinSolicitud' );
	var fechaInicio = getTrimValue( '#etiquetaFechaInicioSolicitud' );

	// fechas de rango (combo anio)
	var rangoFin = getTrimValue( '#hidFechaFinalRangoFecha' );
	var rangoInicio = getTrimValue( '#hidFechaInicialRangoFecha' );
	
	// valida que fecha de fin este dentro del rango del anio
	if (flagFechaValida && esFechaValida(fechaFin)) {
		if ( !( esFechaMayorIgual( fechaFin, rangoInicio ) && esFechaMenorIgual( fechaFin, rangoFin ) ) ) {
			flagFechaValida = false;
			errorMessage = errorMessageRevisarSolicitudBandeja.fechaFinFueraRango + ".";
			darFoco( '#etiquetaFechaFinSolicitud' );
		}
	}

	// validar que la fecha fin debe ser mayor o igual a la fecha de inicio
	if (flagFechaValida && esFechaValida(fechaInicio) && esFechaValida(fechaFin) ) {
		if ( !esFechaMayorIgual( fechaFin, fechaInicio ) ) {
			flagFechaValida = false;
			errorMessage = errorMessageRevisarSolicitudBandeja.fechaFinalMenorFechaInicial;
			darFoco( '#etiquetaFechaFinSolicitud' );
		}
	}
	
	if (!flagFechaValida) {
		setValueInputText("hidFlagFechaFinalValida", errorMessage);
		showMessageErrorRevisionSolicitudBandeja(errorMessage);
	} else {
		setValueInputText("hidFlagFechaFinalValida", "");
	}
}

function callBuscarPlanillasBandeja() {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/solicitud.htm?action=buscarSolicitudesBandejaRevision",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codDependencia"	:	getTrimValue( '#hidCodigoDependencia' ),
				"codColaborador"	:	getTrimValue( '#hidCodigoColaborador' ),
				"codRegistrador"	:	getTrimValue( '#hidCodigoRegistrador' ),
				"codEstado"			: 	getTrimValue( '#selEstadoSolicitud' ),
				"codCanal"			: 	getTrimValue( '#selCanalAtencionSolicitud' ),
				"numPlanilla"	 	:	getTrimValue( '#txtCodigoPlanilla' ).toUpperCase(),
				"fechaDesde"	 	:	getTrimValue( '#etiquetaFechaInicioSolicitud' ),
				"fechaHasta"	 	:	getTrimValue( '#etiquetaFechaFinSolicitud' )
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showElement("divLoadingSolicitud");
			},
			complete: function() {
				enabledElement("btnConsultarSolicitud");
				hideElement("divLoadingSolicitud");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				
				// error inesperado ajax app
				if ( huboErrorAjax( result ) ) {
					handleErrorAjax( result );
					return;
				}
				
				// existen validaciones de app
				if ( result.hayValidacion == 'si' ) {
					
					showMessageErrorRevisionSolicitudBandeja(result.msgValidacion);
					darFoco( '#txtCodigoPlanilla' );
								
					return;
				}	
				
				showPlanillasRevisarSolicitudBandeja(result.listSolicitudes);

			},
			error: function( error ) {
				handleError( error );
			}
		});
	}, 5);
}

function showMessageErrorRevisionSolicitudBandeja(errorMessage) {
	setHtmlElement("etiquetaErrorRevisionSolicitudBandeja", errorMessage);
	showElement("divErrorRevisionSolicitudBandeja");
}


function showPlanillasRevisarSolicitudBandeja(planillaArray) {
	
	if (planillaArray != null && planillaArray.length > 0) {
		
		var planillaTable = $("#tblPlanilla");
		planillaTable.clearGridData();
		
		for (var i = 0; i < planillaArray.length; i++) {
			
			var planilla= planillaArray[i];
			
			var datarow = {
				codPlanilla: planilla.codPlanilla,
				fecRegistro: planilla.fecRegistro,
				nomColaborador: planilla.nomColaborador,
				nomTipoViatico: planilla.nomTipoViatico,
				tipoDestino: planilla.tipoDestino,
				mtoTotal: planilla.mtoTotal,
				canalAtencion: planilla.canalAtencion,
				fecMaxRend: planilla.fecMaxRend, 
				nomEstSolic: planilla.nomEstSolic,
				codPlanViaje: planilla.codPlanViaje,
				numArchivo: $.trim(planilla.numArchivo),
				numExpSolic: $.trim(planilla.numExpSolic),
				obsSolicitud: planilla.obsSolicitud,
				codEstadoSolic: planilla.codEstadoSolic,
				nomUuOoCom: planilla.nomUuOoCom,
				numeroRegistroAlterno: planilla.numeroRegistroAlterno,
				indicadorTraslape: planilla.indicadorTraslape,
				indicadorAutorizacion: planilla.indicadorAutorizacion,
				indicadorHoras: planilla.indicadorHoras
			};
			
			planillaTable.jqGrid('addRowData', datarow.codPlanViaje, datarow);
		}		
		
		planillaTable.trigger("reloadGrid");
		enabledElement("btnExportarExcelSolicitud");
		showTooltip();
		
	} else {
		setHtmlElement("divPlanillaPagerTable_left", errorMessageRevisarSolicitudBandeja.sinRegistrosBusqueda);
	}
}

function clearPlanillaTableSolicitudBandeja() {
	var planillaTable = $("#tblPlanilla");
	planillaTable.clearGridData();
	disabledElement("btnExportarExcelSolicitud");
	setHtmlElement("divPlanillaPagerTable_left", "");
}
 
function clickBtnConsultaPlanilla(codPlanilla){
	
	// si el usuario que ingresa a session es registrador
	var esRegistrador = toNumero( getTrimValue('#hidFlagRegistrador') ) > 0 || toNumero( getTrimValue('#hidFlagRegistradorUniversal') ) > 0;		
	
	// mostrar popup consultar solicitud
	var paginaOrigen = 'bandeja-revision-solicitud'; // parametro opcional
	initElementsConsultarSolicitud( codPlanilla, esRegistrador, paginaOrigen );	
	showModalElement( 'divConsultarSolicitudModal' );
	triggerResizeEvent();
}


function clickBtnModificarPlanilla(codPlanilla){
	
	var dataObject = {
		'txtUUOO': getTrimValue( '#txtUUOO' ),
		'txtDescripcionDependencia' : getTrimValue( '#txtDescripcionDependencia' ),
		'hidCodigoDependencia' : getTrimValue( '#hidCodigoDependencia' ),
		'txtCodigoPlanilla': getTrimValue( '#txtCodigoPlanilla' ),
		'txtNroRegistro': getTrimValue( '#txtNroRegistro' ),
		'txtNombreColaborador' : getTrimValue( '#txtNombreColaborador' ),
		'hidCodigoColaborador' : getTrimValue( '#hidCodigoColaborador' ),
		'hidCodigoEstadoColaborador' : getTrimValue( '#hidCodigoEstadoColaborador' ),
		'selAnioSolicitud': getTrimValue( '#selAnioSolicitud' ),
		'etiquetaFechaInicioSolicitud': getTrimValue( '#etiquetaFechaInicioSolicitud' ),
		'etiquetaFechaFinSolicitud': getTrimValue( '#etiquetaFechaFinSolicitud' ),
		'selCanalAtencionSolicitud': $( '#selCanalAtencionSolicitud' ).val(),
		'selEstadoSolicitud': getTrimValue( '#selEstadoSolicitud' ),
		'hidFechaInicialRangoFecha': getTrimValue( '#hidFechaInicialRangoFecha' ),
		'hidFechaFinalRangoFecha': getTrimValue( '#hidFechaFinalRangoFecha' )
	};

	var formPost = $( '#formPost' );	
	formPost.find( 'input[name="action"]' ).val( 'mostrarModificarViatico' );
	formPost.find( 'input[name="codPlanilla"]' ).val( codPlanilla );
	formPost.find( 'input[name="dataJSON"]' ).val( JSON.stringify( dataObject ) );
	formPost.submit();
	
}

var clickVerDetalle = function(codPlanViaje) {
	var planillaTable = $( "#tblPlanilla" );
	var rowData = planillaTable.getRowData(codPlanViaje);	
	var tipoDestino = $.trim( rowData.tipoDestino );
	var indicadorHoras = $.trim( rowData.indicadorHoras );
	initElementsConsultarSolicitudDetalle("divPlanillaTable", codPlanViaje,tipoDestino,indicadorHoras);
	showModalElement("divConsultarSolicitudDetalle");
	triggerResizeEvent();

	setTimeout(function() {

		resizeTable("tblSeguimiento");
		resizeTable("tblDetalleSolicitud");
		resizeTable("tblDetalleSolicitud2");
		resizeTable("tblDetalleViatico");
		resizeTable("tblDetalleGasto");

	}, 700);
 
};


function clickVerSeguimiento(codPlanViaje){
	
	var planillaTable = $("#tblPlanilla");
	var rowData = planillaTable.getRowData(codPlanViaje);	
	
	var dataParametrosConsultarSeguimiento = new Object();
	dataParametrosConsultarSeguimiento.codPlanViaje = codPlanViaje;
	dataParametrosConsultarSeguimiento.numeroExpediente = $.trim( rowData.numExpSolic );;
	dataParametrosConsultarSeguimiento.idElementCallModal = "divPlanillaTable";
	dataParametrosConsultarSeguimiento.codigoPaginaCaller = "01"; //"01": Bandejas solicitud y rendicion -- "02": Bandejas reembolso
	initElementsConsultarSeguimiento(dataParametrosConsultarSeguimiento);
	showModalElement("divConsultarSeguimiento");
	triggerResizeEvent();
	triggerResizeEventSlow();

	setTimeout(function() {
		resizeTable("tblSeguimiento");
	}, 700);

}

function clickVerAnular(codPlanViaje){
	
	var planillaTable = $("#tblPlanilla");
	var rowData = planillaTable.getRowData(codPlanViaje);
	var dataParametrosAnularDocumento = new Object();
	dataParametrosAnularDocumento.codPlanViaje = codPlanViaje; 
	dataParametrosAnularDocumento.codPlanilla = rowData.codPlanilla; 
	dataParametrosAnularDocumento.nomColaborador = rowData.numeroRegistroAlterno + " - " + rowData.nomColaborador;
	dataParametrosAnularDocumento.descripcionDependencia = rowData.nomUuOoCom;
	dataParametrosAnularDocumento.montoTotal = rowData.mtoTotal;
	dataParametrosAnularDocumento.codigoColaborador = getValueInputText('hidCodigoRegistrador');
	dataParametrosAnularDocumento.codigoSedeColaborador = '';
	dataParametrosAnularDocumento.expedientePlanViaje = rowData.numExpSolic;
	dataParametrosAnularDocumento.codigoPaginaCaller = '01';	// colaborador
	initElementsAnularDocumento(dataParametrosAnularDocumento);
	
	showModalElement("divAnularDocumento");
}



function clickVerArchivo(codPlanViaje) {
	
	var planillaTable = $( "#tblPlanilla" );
	var rowData = planillaTable.getRowData(codPlanViaje);
	
	var numArchivo = $.trim( rowData.numArchivo );
	var codPlanilla = $.trim( rowData.codPlanilla );
	var nroRegistro = $.trim( rowData.numeroRegistroAlterno );
	
	var dataParametrosArchivo = new Object();
	
	dataParametrosArchivo.codigoBoleto = ''; 	  				// codigo vaucher 00000901
	dataParametrosArchivo.estadoOrigen = 'V';			  		// V: viatico
	dataParametrosArchivo.estadoLLamada = 'C'; 			   		// C: consulta, R: registro	
	dataParametrosArchivo.numeroRegistroColaborador = nroRegistro;
	dataParametrosArchivo.planViajeId = codPlanViaje;
	dataParametrosArchivo.codPlanilla = codPlanilla;
	dataParametrosArchivo.paginaOrigen = 'PRINCIPAL';			// PRINCIPAL O SECUNDARIA(VAUCHER)
	
	existenArchivosAdjuntos(dataParametrosArchivo, function(){
		
		initElementsConsultarRegistrarEliminarArchivo(dataParametrosArchivo);
		$("#divAdjuntarDocumento").modal("show");
		triggerResizeEvent();

		setTimeout(function() {
			resizeTable( "tblArchivo" );
		}, 700);		
		
	});

 
}

$(window).on("resize", function() {
	resizeTable("tblPlanilla");
	resizeTable("tblSeguimiento");
	resizeTable("tblArchivo");
	resizeTable("tblUUOO");
	resizeTable("tblDetalleSolicitud");
	resizeTable("tblDetalleSolicitud2");
	resizeTable("tblDetalleViatico");
	resizeTable("tblDetalleGasto");
});


