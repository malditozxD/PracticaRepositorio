/// <reference path="../general/common.js" />
/// <reference path="../../WEB-INF/jsp/reembolso/consultar/consultarReembolso.jsp" />
/// <reference path="D:\jcfr\data\ts-definitions\DefinitelyTyped-master\jquery\jquery.d.ts" />

// servicio adjuntar archivo
var adjuntarDocumentoService = null;

// init del módulo
function initElementsConsultarReembolso() {

	removeDuplicateComponents();

	// inicializacion comun a registrar y modificar
	setInitElementsConsultarReembolso();

	// post inicializaciones solo para registrar/modificar segun caso
	setInitElementsVerReembolso();

}

// init para registrar y modificar
function setInitElementsConsultarReembolso() {
	
	$( '#divHiddenPost' ).hide();
	
	// eventos: botones
	addEventElement("btnConsultarAsistenciaNacMay4h", "click", clickBtnConsultarAsistencia);	// nacional > 4h
	addEventElement("btnConsultarAsistenciaNacMen4h", "click", clickBtnConsultarAsistencia);	// nacional <= 4h
	addEventElement("btnConsultarAsistenciaInt", "click", clickBtnConsultarAsistencia);			// internacional
	addEventElement("btnAdjuntarViatico", "click", clickBtnAdjuntarViatico);
	addEventElement("btnImprimirViatico", "click", clickBtnImprimirViatico);
	addEventElement("btnSustentarGasto", "click", clickBtnSustentarGasto);
	addEventElement("btnSalirRetornarViatico", "click", clickBtnSalirRetornarViatico);

	// eventos: otros
	addEventElement("montoResolucionInter", "focusout", blurMontoResolucionInter);

	updateDivsDetalleViatico();
	updateSelMotivoAmpliacion();

	setTimeout(function() {
		updateEstructuraTablaDesplazamientos();
	}, 300);

}

// init particular para ver
function setInitElementsVerReembolso() {

	// inicializar las grillas con los desplazamientos del viatico
	setInitDesplazamientoTableRSV();

	limpiarLabelsError();

	// deshabilitar controles
	$( '#formViatico' ).find( 'button, select, input' ).prop( 'disabled', true );

	// haailitar los controles
	$( '#btnAdjuntarViatico' ).prop( 'disabled', false );

	$( '#btnSustentarGasto' ).prop( 'disabled', false );
	$( '#btnImprimirViatico' ).prop( 'disabled', false );
	$( '#btnSalirRetornarViatico' ).prop( 'disabled', false );

	// solo para formatear el monto
	$('#montoResolucionInter').trigger( 'focusout' );

	var esRegistrador = configRSV.flagPerfilRegistrador == configRSV.constantes.SI || configRSV.flagPerfilRegistradorUniversal == configRSV.constantes.SI;
	var esConfiguracionAutomatica = configRSV.tipoConfiguracion == '02';

	var mostrarImprimir = true;
	/*if ( esConfiguracionAutomatica && !esRegistrador ) {
		mostrarImprimir = false;
	}*/

	if ( mostrarImprimir ) {

		$('#divImprimirViaticoWrapper').show();
		$('#divImprimirViaticoWrapper').addClass( 'col-md-offset-3 noLeftPadding col-sm-offset-3 noLeftPadding' );
			
	} else {

		$('#divImprimirViaticoWrapper').hide();
		$('#divSustentoGastoWrapper').addClass( 'col-md-offset-4 noLeftPadding col-sm-offset-4 noLeftPadding' );
	}
	
	// cargar los datos de la planilla asociada
	updateSelPlanillaAsociada();

	// al final volver a invocar el resize de las tablas mostradas al inicio
	setTimeout( function() {

		resizeTable("tblDesplazamientoRSV");

	}, 800 );

}

// métodos creados para mejor legilidad 
function getDesplazamientosList() {
	return configRSV.desplazamientos;
}

function getArchivosAdjuntosList() {
	return configRSV.archivosAdjuntos;
}

function esRegistrar() {
	return getValueInputText('hidFlagDoAction') == 'registrar';
}

function esTarifarioRegional() {
	return configRSV.tipoTarifario == configRSV.constantes.TARIFARIO_NACIONAL;
}

function esTarifarioNacional() {
	return configRSV.tipoTarifario == configRSV.constantes.TARIFARIO_REGIONAL;
}

function esConfiguracionManual() {
	return configRSV.tipoConfiguracion == configRSV.constantes.CONFIGURACION_MANUAL;
}

function esConfiguracionAutomatica() {
	return configRSV.tipoConfiguracion == configRSV.constantes.CONFIGURACION_AUTOMATICA;
}

function esModificar() {
	return getValueInputText('hidFlagDoAction') == 'modificar';
}

function esNacional() {
	var selTipoViatico = $('#selTipoViatico').val();
	return selTipoViatico == 'nacional';
}

function esInternacional() {
	var selTipoViatico = $('#selTipoViatico').val();
	return selTipoViatico == 'internacional';
}

function esMayor4h() {
	var selDuracionComision = $('#selDuracionComision').val();
	return selDuracionComision == 'may4h';
}

function esMenorIgual4h() {
	var selDuracionComision = $('#selDuracionComision').val();
	return selDuracionComision == 'men4h';
}

// muestra el mensaje de error para las fechas
function showMensajeLabelDetalleViatico(errorMessage) {

	if ( esNacional() ) {

		if ( esMayor4h() ) {
			$( '#lblErrorMay4h' ).html( errorMessage );
			$( '#divErrorMay4h' ).show();
		} else {
			$( '#lblErrorMen4h' ).html( errorMessage );
			$( '#divErrorMen4h' ).show();
		}

	} else { // si es internacional

		$( '#lblErrorInt' ).html( errorMessage );
		$( '#divErrorInt' ).show();

	}
}

// oculta el mensaje de error para las fechas
function hideMensajeLabelDetalleViatico() {

	if ( esNacional() ) {

		if ( esMayor4h() ) {
			$( '#lblErrorMay4h' ).html( '' );
			$( '#divErrorMay4h' ).hide();
		} else {
			$( '#lblErrorMen4h' ).html( '' );
			$( '#divErrorMen4h' ).hide();
		}

	} else { // si es internacional

		$( '#lblErrorInt' ).html( '' );
		$( '#divErrorInt' ).hide();

	}
}

// limpia lista de desplazamientos
function clearGridDesplazamientos() {
	$( '#tblDesplazamientoRSV' ).clearGridData();
	configRSV.desplazamientos = [];
}

// creación de grilla de desplazamientos
function setInitDesplazamientoTableRSV() {

	var table = $( '#tblDesplazamientoRSV' );
	if (table) {
		
		var heightJqGrid = 150;
		setStyleElement("divDesplazamientoTableRSV", "height", obtenerHeightJqGridDiv(heightJqGrid, 1, true));		
		
		var tableDiv = $("#divDesplazamientoTableRSV");
		var widthTable = tableDiv.width();
		table.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			autowidth: true,
			datatype: "local",
			cmTemplate: {sortable: false},
			colNames: [
				"N&deg;",							// todos
				"Medio de transporte",				// todos
				"Departamento",						// nacional
				"Provincia",						// nacional
				"Lugar del destino",				// internacional						(hidden condicional)
				"D&iacute;as de vi&aacute;tico",	// nacional > 4 horas, e internacional	(hidden condicional)
				"Horas de vi&aacute;tico",			// nacional <= 4horas					(hidden condicional)
				"Importe diario",					// todos
				"Importe vi&aacute;tico",			// todos
				"D&iacute;as de traslado",			// internacional			(hidden condicional)
				"Viaje Ext/Gto. Trasl.",			// internacional			(hidden condicional)
				"Total otorgado",					// internacional			(hidden condicional)
				"<a href='javascript:void(0);'><img border='0' title='eliminar' width='15' height='15' src='/a/imagenes/sigad/acciones/delete.png'></a>",
				"codigoMedioTransporte", 			// todos hidden
				"codigoProvincia",					// nacional hidden
				"codigoDepartamento",				// nacional hidden
				"codigoLugar",						// nacional hidden
				"codigoLugarDestino", 				// internacional hidden
				"importeDiarioTope",				// todos hidden
				"diasTrasladoTope",                 // internacional hidden
				"codigoTarifario",                  // internacional hidden
				"porcentajeTarifario",              // internacional hidden
				"viajeExtGtoTrasTope"               // internacional hidden
			],
			colModel: [
				{name: "nro", index: "nro", width: (0.5*widthTable/12), align: "center"},										// todos
				{name: "medioTransporte", index: "medioTransporte", width: (1.5*widthTable/12), align: "center"},				// todos
				{name: "departamento", index: "departamento", width: (1.6*widthTable/12)},										// nacional
				{name: "provincia", index: "provincia", width: (1.6*widthTable/12)},											// nacional
				{name: "lugarDestino", index: "lugarDestino", width: (1.6*widthTable/12), hidden: true},						// internacional
				{name: "diasViatico", index: "diasViatico", width: (1.1*widthTable/12), align: "center",
					formatter: function(cellvalue, options, rowData) {
						var nro = rowData.nro;
						var dias = toNumero( rowData.diasViatico );
						var rowJSON = JSON.stringify( rowData );

						var htmlElement = '<input id="diasViatico_' + nro + '" value="' + dias + '" data-info=\'' + rowJSON + '\' maxlength="3" style="padding: 3px; margin: 3px; text-align:right; width: 90%;" >';

						return htmlElement;
					}
				},		// nacional > 4 horas, e internacional
				{name: "horasViatico", index: "horasViatico", width: (1.1*widthTable/12), align: "center", hidden: true,
					formatter: function(cellvalue, options, rowData) {

						var nro = rowData.nro;
						var horas = $.trim( rowData.horasViatico );

						// solo por moneria, si tiene digito decimal mostrarlo formatear a 1  decimal
						if ( horas.indexOf( '.' ) >= 0 ) {
							horas = roundString( toNumero( rowData.horasViatico ), 1 );	// formatear a 1 digito decimal
						}

						var rowJSON = JSON.stringify( rowData );

						var htmlElement = '<input id="horasViatico_' + nro + '" value="' + horas + '" data-info=\'' + rowJSON + '\' maxlength="4" style="padding: 3px; margin: 3px; text-align:right; width: 90%;" >';

						return htmlElement;
					}

				},		// nacional <= 4horas
				{name: "importeDiario", index: "importeDiario", width: (1.2*widthTable/12), align: "right",
					formatter: function(cellvalue, options, rowData) {
						var nro = rowData.nro;
						var importe = toNumero( rowData.importeDiario );
						var monto = roundComasMilesString( importe, 2 );
						var rowJSON = JSON.stringify( rowData );

						var htmlElement = '<input id="importeDiario_' + nro + '" value="' + monto + '" data-info=\'' + rowJSON + '\' maxlength="10" style="padding: 3px; margin: 3px; text-align:right; width: 90%;" >';

						return htmlElement;
					}
				},		// todos
				{name: "importeViatico", index: "importeViatico", width: (1.2*widthTable/12), align: "right",
					formatter: function(cellvalue, options, rowData) {
						var importe = toNumero( rowData.importeViatico );
						return roundComasMilesString( importe, 2 );
					}
				},		// todos
				{name: "diasTraslado", index: "diasTraslado", width: (1.1*widthTable/12), align: "center", hidden: true,
					formatter: function(cellvalue, options, rowData) {
						var nro = rowData.nro;
						var dias = toNumero( rowData.diasTraslado );
						var rowJSON = JSON.stringify( rowData );

						var htmlElement = '<input id="diasTraslado_' + nro + '" value="' + dias + '" data-info=\'' + rowJSON + '\' maxlength="2" style="padding: 3px; margin: 3px; text-align:right; width: 90%;" >';

						return htmlElement;
					}
				},		// internacional
				{name: "viajeExtGtoTras", index: "viajeExtGtoTras", width: (1.1*widthTable/12), align: "right", hidden: true,

					formatter: function(cellvalue, options, rowData) {
						var nro = rowData.nro;
						var importe = toNumero( rowData.viajeExtGtoTras );
						var monto = roundComasMilesString( importe, 2 );
						var rowJSON = JSON.stringify( rowData );

						var htmlElement = '<input id="viajeExtGtoTras_' + nro + '" value="' + monto + '" data-info=\'' + rowJSON + '\' maxlength="10" style="padding: 3px; margin: 3px; text-align:right; width: 90%;" >';

						return htmlElement;
					}
				},		// internacional
				{name: "totalOtorgado", index: "totalOtorgado", width: (1.1*widthTable/12), align: "right", hidden: true,
					formatter: function(cellvalue, options, rowData) {
						var importe = toNumero( rowData.totalOtorgado );
						return roundComasMilesString( importe, 2 );
					}
				}, 		// internacional
				{name: "eliminar", index: "eliminar", width: (0.5*widthTable/12), align: "center",								// todos
					formatter: function(cellValue, options, rowData) {
						var nro = rowData.nro;
						var rowJSON = JSON.stringify( rowData );
						var htmlElement = '<input id="chkJqGridDesplazamiento' + nro + '" name="chkDesplazamientos" type="checkbox" value=\'' + rowJSON + '\'>';
						return htmlElement;
					}
				},
				{name: "codigoMedioTransporte", index: "codigoMedioTransporte", width: (1.0*widthTable/12), hidden: true},		// todos hidden
				{name: "codigoProvincia", index: "codigoProvincia", width: (1.0*widthTable/12), hidden: true},					// nacional hidden
				{name: "codigoDepartamento", index: "codigoDepartamento", width: (1.0*widthTable/12), hidden: true},			// nacional hidden
				{name: "codigoLugar", index: "codigoLugar", width: (1.0*widthTable/12), hidden: true},							// nacional hidden
				{name: "codigoLugarDestino", index: "codigoLugarDestino", width: (1.0*widthTable/12), hidden: true},			// internacional hidden
				{name: "importeDiarioTope", index: "importeDiarioTope", width: (1.0*widthTable/12), hidden: true},	     	    // todos hidden
				{name: "diasTrasladoTope", index: "diasTrasladoTope", width: (1.0*widthTable/12), hidden: true},		   	    // internacional hidden
				{name: "codigoTarifario", index: "codigoTarifario", width: (1.0*widthTable/12), hidden: true},		   	        // internacional hidden
				{name: "porcentajeTarifario", index: "porcentajeTarifario", width: (1.0*widthTable/12), hidden: true},		  	// internacional hidden
				{name: "viajeExtGtoTrasTope", index: "viajeExtGtoTrasTope", width: (1.0*widthTable/12), hidden: true}		  	// internacional hidden
			],
			pager : "#divDesplazamientoPagerTableRSV",
			loadui: "disable"
		});

		// actualizar lista de desplazamientos
		fillGrilla( '#tblDesplazamientoRSV', getDesplazamientosList() );
		updateTotalDesplazamientos();

	}
}


function esMotivoAmpliacion() {
	var selMotivoAmpliacion = $('#selMotivoAmpliacion').val();
	return selMotivoAmpliacion == configRSV.constantes.MOTIVO_AMPLIACION_AMPLIACION_COMISION;
}

function esMotivoAmpliacionOtros() {
	var selMotivoAmpliacion = $('#selMotivoAmpliacion').val();
	return selMotivoAmpliacion == configRSV.constantes.MOTIVO_AMPLIACION_OTROS;
}

function esMotivoAmpliacionNoCobrado() {
	var selMotivoAmpliacion = $('#selMotivoAmpliacion').val();
	return selMotivoAmpliacion == configRSV.constantes.MOTIVO_AMPLIACION_VIATICO_NO_COBRADO;
}


//oculta y muestra controles según tipo de viático y duración de comisión
function updateDivsDetalleViatico() {

	// oculta o muestra los divs correspondientes a tipo de viatico nacional/internacional, y si es nacional mayor a 4horas o menor igual a 4horas
	if ( esNacional() ) {

		// cambia la moneda por defecto a soles
		configRSV.moneda = configRSV.constantes.MONEDA_SOLES;
		// $('.lblMoneda').html( configRSV.moneda );
		$('.lblMonedaDesplazamientos').html( 'S/.' );

		// ocultar/visualizar divs
		$('#divTipoDesplazamientoWrapper').show();
		$('#divNacionalWrapper').show();

		if ( esMayor4h() ) {

			// ocultar/visualizar divs
			$('#divInternacionalWrapper').hide();
			$('#divNacionalMayor4Wrapper').show();
			$('#divNacionalMenorIgual4Wrapper').hide();

		} else {	// si es menor o igual a 4 horas

			$('#divInternacionalWrapper').hide();
			$('#divNacionalMayor4Wrapper').hide();
			$('#divNacionalMenorIgual4Wrapper').show();
		}

	} else { // si es internacional

		// cambia la moneda por defecto a soles
		configRSV.moneda = configRSV.constantes.MONEDA_DOLARES;
		// $('.lblMoneda').html( configRSV.moneda );
		$('.lblMonedaDesplazamientos').html( '($)' );

		$('#divTipoDesplazamientoWrapper').hide();
		$('#divNacionalWrapper').hide();

		$('#divInternacionalWrapper').show();
		$('#divNacionalMayor4Wrapper').hide();
		$('#divNacionalMenorIgual4Wrapper').hide();

	}

	updateEstructuraTablaDesplazamientos();
}


//configura los campos en la grilla de desplazamientos (oculta y muestra campos según el tipo de viático y duración de comisión)
function updateEstructuraTablaDesplazamientos() {

	// actualiza la estructura de columnas de la tabla desplazamientos
	// segun el tipo de viatico (nacional, internacional) y duracion de comision (> 4horas, <= 4horas)
	var table = $('#tblDesplazamientoRSV');

	if ( esNacional() ) {

		// ocultar
		table.jqGrid("hideCol", "lugarDestino");
		table.jqGrid("hideCol", "diasTraslado");
		table.jqGrid("hideCol", "viajeExtGtoTras");
		table.jqGrid("hideCol", "totalOtorgado");

		// mostrar
		table.jqGrid("showCol", "departamento");
		table.jqGrid("showCol", "provincia");


		if ( esMayor4h() ) {

			table.jqGrid("hideCol", "horasViatico");
			table.jqGrid("showCol", "diasViatico");

		} else {	// si es menor o igual a 4 horas

			table.jqGrid("hideCol", "diasViatico");
			table.jqGrid("showCol", "horasViatico");
		}


	} else { // si es internacional

		// ocultar
		table.jqGrid("hideCol", "departamento");
		table.jqGrid("hideCol", "provincia");
		table.jqGrid("hideCol", "horasViatico");

		// mostrar
		table.jqGrid("showCol", "lugarDestino");
		table.jqGrid("showCol", "diasTraslado");
		table.jqGrid("showCol", "viajeExtGtoTras");
		table.jqGrid("showCol", "totalOtorgado");
		table.jqGrid("showCol", "diasViatico");

	}

	triggerResizeEvent();
}

function updateSelMotivoAmpliacion() {
	
	if ( esMotivoAmpliacion() ) {
		$('#divPlanillaAsociada').show();
	} else {
		$('#divPlanillaAsociada').hide();
	}
	
}
 
// actualiza la caja de texto con el total de desplazamiento
function updateTotalDesplazamientos() {

	var lista = getDesplazamientosList();

	if ( !estaDefinido( lista ) || lista.length == 0 ) {
		
		$('#txtTotalDesplazamientos').val('');
		
	} else {
		
		var total = calcularTotalDesplazamientos();
		$('#txtTotalDesplazamientos').val( roundComasMilesString( total, 2 ) );
	}
}

function calcularTotalDesplazamientos() {

	var acumulador = 0;
	var desplazamientos = getDesplazamientosList();

	$.each(desplazamientos, function(i, item) {

		if ( esNacional() ) {
			acumulador = toNumero( item.importeViatico ) + acumulador;
		} else { // si es internacional
			acumulador = toNumero( item.totalOtorgado ) + acumulador;
		}

	});

	return roundNumero( acumulador, 2 );
}

function limpiarLabelsError() {
	$( '#lblErrorMay4h' ).html( '' );
	$( '#divErrorMay4h' ).hide();
	$( '#lblErrorMen4h' ).html( '' );
	$( '#divErrorMen4h' ).hide();
	$( '#lblErrorInt' ).html( '' );
	$( '#divErrorInt' ).hide();
}
 

function clickBtnConsultarAsistencia() {

	var fechaFinal = '';
	var fechaInicial = '';
	var numeroRegistroText = getTrimValue( '#txtNroRegistro' );
	var txtNombreColaborador = getTrimValue( '#txtNombreColaborador' );

	// validacion adicional
	if ( numeroRegistroText == '' ) {
		showMensaje( 'Por favor ingresar un colaborador', function() {
			darFoco( '#txtNroRegistro' );
		});
		return;
	}

	if ( esNacional() ) {

		if ( esMayor4h() ) {

			fechaInicial = getTrimValue( '#fechaSalidaNacMay4h' );
			fechaFinal = getTrimValue( '#fechaRetornoNacMay4h' );

		} else {	// si es menor o igual a 4 horas

			// la fecha inicial y final es el mismo dia
			fechaInicial = getTrimValue( '#fechaNacMen4h' );
			fechaFinal = getTrimValue( '#fechaNacMen4h' );
		}

	} else { // si es internacional

		// en primera instancia, toma las fechas de itinerario/ejecucion (así dicen el F2)
		if ( esFechaValida( getTrimValue( '#fechaItinerarioInicioInter' ) ) && esFechaValida( getTrimValue( '#fechaItinerarioFinInter' ) ) ) {

			fechaInicial = getTrimValue( '#fechaItinerarioInicioInter' );
			fechaFinal = getTrimValue( '#fechaItinerarioFinInter' );

		} else {
			
			// dado que son las fechas de itinetario/ejecución son opcionales.
			// en otro caso toma las fechas de programacion/evento

			fechaInicial = getTrimValue( '#fechaEventoInicioInter' );
			fechaFinal = getTrimValue( '#fechaEventoFinInter' );
		}

	}

	initElementsReportarAsistencia("divDesplazamientoTableRSV", numeroRegistroText, fechaInicial, fechaFinal, txtNombreColaborador);
	showModalElement("divReporteAsistencia");
	triggerResizeEvent();

	// actualizar el estado de visualizacion de consulta de asistencia
	configRSV.consultaAsistencia.visualizo = configRSV.constantes.SI;
	configRSV.consultaAsistencia.fecha = configRSV.fechaToday;
	configRSV.consultaAsistencia.hora = new Date().getHours() + ':' + new Date().getMinutes();
}


// ADJUNTAR ARCHIVO
function clickBtnAdjuntarViatico() {
	
	var dataParametrosArchivo = new Object();
	
	dataParametrosArchivo.codigoBoleto = ''; 	  				// codigo vaucher 00000901
	dataParametrosArchivo.estadoOrigen = 'V';			  		// V: viatico
	dataParametrosArchivo.estadoLLamada = 'R'; 			   		// C: consulta, R: registro	
	dataParametrosArchivo.numeroRegistroColaborador = getTrimValue( '#txtNroRegistro' );
	dataParametrosArchivo.planViajeId = getTrimValue( '#hidCodPlanViaje' );
	dataParametrosArchivo.paginaOrigen = 'PRINCIPAL';			// PRINCIPAL O SECUNDARIA(VAUCHER) 
	
	adjuntarDocumentoService = new AdjuntarDocumentoService(adjuntarDocumnetoBeforeMethod, adjuntarDocumnetoAfterMethod);
	
	initElementsConsultarRegistrarEliminarArchivo(dataParametrosArchivo);
	$("#divAdjuntarDocumento").modal("show");
	triggerResizeEvent();
}

function adjuntarDocumnetoBeforeMethod() {

}

function adjuntarDocumnetoAfterMethod(archivos) {
	
}

function clickBtnImprimirViatico() {
	
	var formPost = $( '#formImprimirPost' );	
	formPost.find( 'input[name="action"]' ).val( 'imprimirReembolsoViatico' );
	formPost.find( 'input[name="codPlanilla"]' ).val( getTrimValue( '#txtCodPlanilla' ) );
	formPost.submit();	
}

function clickBtnSustentarGasto() {
	
	var formPost = $( '#formSustentoGastoPost' );	
	formPost.find( 'input[name="action"]' ).val( 'mostrarConsultarGastoReembolso' );
	formPost.find( 'input[name="codPlanViaje"]' ).val( getTrimValue( '#hidCodPlanViaje' ) );
	formPost.find( 'input[name="dataJSON"]' ).val( configRSV.dataJSON );
	formPost.find( 'input[name="paginaConsultaCaller"]' ).val( getTrimValue( '#hidPaginaConsultaCaller' ) );
	formPost.submit();	
}


function clickBtnSalirRetornarViatico() {

	var hidPaginaConsultaCaller = getTrimValue( '#hidPaginaConsultaCaller' );

	var action = '';
	var flagConsultaModificacionReembolso = true;

	if ( hidPaginaConsultaCaller == '01' )  {

		action = 'generarBandejaRevisionReembolso';

	} else if ( hidPaginaConsultaCaller == '02' )  {

		action = 'generarBandejaConsultaReembolso';

	} else if ( hidPaginaConsultaCaller == '03' )  {

		action = 'mostrarBandejaReembolsoAutorizador';
		flagConsultaModificacionReembolso = false;

	} else {

		// default
		action = 'generarBandejaConsultaReembolso';
	}
	
	if (flagConsultaModificacionReembolso) {
		var formPost = $( '#formBandejaPost' );
		formPost.find( 'input[name="action"]' ).val( action );
		formPost.find( 'input[name="codPlanilla"]' ).val( getTrimValue( '#txtCodPlanilla' ) );
		formPost.find( 'input[name="codPlanViaje"]' ).val( getTrimValue( '#hidCodPlanViaje' ) );
		formPost.find( 'input[name="dataJSON"]' ).val( configRSV.dataJSON );
		formPost.submit();
	}
	else {
		var formPost = $( '#formBandejaAutorizadorPost' );
		formPost.find( 'input[name="action"]' ).val( action );
		formPost.submit();
	}
}

// eventos sobre las caja de texto
function blurMontoResolucionInter() {

	// recoge el valor ingresado, lo formatea
	var control = $( '#montoResolucionInter' );
	var controlValue = $.trim( control.val() );

	controlValue = controlValue.replace(/,/g , '');

	// blanquear si no es numero
	if ( !esNumero( controlValue ) ) {
		control.val( '' );
		return;
	}

	if ( controlValue != '' ) {

		// en bd es 10,2
		controlValue = recortarDigitosEnteros( controlValue, 8 );

		var controlValueSinComas = controlValue.replace(/,/g , '');
		control.val( roundComasMilesString( controlValueSinComas, 2 )  );
	}
}

// llena una grilla
function fillGrilla( tableID, lista ) {

	// que tableID y lista esten definidos
	if ( !estaDefinido( tableID ) || !estaDefinido( lista ) ) return;

	var table = $( tableID );
	if ( table ) {

		table.clearGridData();

		if (lista != null && lista.length > 0) {

			for (var i = 0; i < lista.length; i++) {

				var datarow = lista[i];

				// agrega el campo nro con una secuencia
				datarow.nro = String(i + 1);

				table.jqGrid("addRowData", datarow.nro, datarow);
			}

			table.trigger("reloadGrid");

		}

	}

}

function updateSelPlanillaAsociada() {
	
	ocultarControlesPlanillaAsociada();
	updateLabelImportePlanillaAsociada();
	
	// que haya seleccionado algo en la planilla asociada
	if ( $( '#selPlanillaAsociada' ).val() != '' ) {
	
		// recoger los datos adicionales del option (planilla) seleccionado
		var dataInfo = obtenerDatosPlanillaAsociada();

		// actualizar controles con los datos adicionales de la planilla
	 	updateControlesPlanillaAsociada( dataInfo );
		
	} else {
		
		// si no escogio planilla asociada, muestra por default el bloque de viatico mayor 4 horas
		if ( esNacional() ) {

			$( '#divPlanillaAsociadaMayor4Wrapper' ).show();
			$( '#divPlanillaAsociadaMenorIgual4Wrapper' ).hide();
			$( '#divPlanillaAsociadaInternacionalWrapper' ).hide();

		} else {

			$( '#divPlanillaAsociadaMayor4Wrapper' ).hide();
			$( '#divPlanillaAsociadaMenorIgual4Wrapper' ).hide();
			$( '#divPlanillaAsociadaInternacionalWrapper' ).show();
		}
	}
	
}

function obtenerDatosPlanillaAsociada() {
	
	// que haya seleccionado algo en la planilla asociada
	if ( $( '#selPlanillaAsociada' ).val() != '' ) {
		
		// seleccionar el option (planilla) seleccionado
		var planillaSelected =  $( '#selPlanillaAsociada option:selected' );
		
		// recoger los datos adicionales del option (planilla) seleccionado
		var dataInfo = planillaSelected.data( 'info' );
		
		return dataInfo;
	}
	
	return null;
}

function ocultarControlesPlanillaAsociada() {
	
	$( '#divPlanillaAsociadaMayor4Wrapper' ).hide();
	$( '#divPlanillaAsociadaMenorIgual4Wrapper' ).hide();
	$( '#divPlanillaAsociadaInternacionalWrapper' ).hide();
		
}

function updateLabelImportePlanillaAsociada() {

	if ( esNacional() ) {
		$('#lblImportePlanillaAsociada').html( 'Importe S/.' );
	} else {
		$('#lblImportePlanillaAsociada').html( 'Importe $' );
	}

}

function updateControlesPlanillaAsociada( dataInfo ) {
	
	// dataInfo es un objeto JS con la data de las fechas, horas e importes a mostrar cuando cambiar una planilla asociada
	if ( !estaDefinido( dataInfo ) ) return null;
	
	var dataInfoEsNacional = $.trim( dataInfo.esNacional ) == configRSV.constantes.SI;
	var dataInfoEsMayor4h =  $.trim( dataInfo.esMayor4h ) == configRSV.constantes.SI;
		
	if ( dataInfoEsNacional ) {
		
		if ( dataInfoEsMayor4h ) {
			
			$('#divPlanillaAsociadaMayor4Wrapper').show();
			$('#divPlanillaAsociadaMenorIgual4Wrapper').hide();
			$('#divPlanillaAsociadaInternacionalWrapper').hide();
			
			// datos adicionales: dataInfo.codPlanViaje, dataInfo.codPlanilla, dataInfo.numeroDias
			$( '#txtAsociadaImporte' ).val( roundComasMilesString( dataInfo.importe, 2 ) );
			$( '#txtAsociadaFechaSalidaNacMay4h' ).val( dataInfo.fechaSalida );
			$( '#txtAsociadaFechaRetornoNacMay4h' ).val( dataInfo.fechaRetorno );			
			
		} else { // si es menor o igual a 4h
			
			$('#divPlanillaAsociadaMayor4Wrapper').hide();
			$('#divPlanillaAsociadaMenorIgual4Wrapper').show();
			$('#divPlanillaAsociadaInternacionalWrapper').hide();
			
			// datos adicionales: dataInfo.codPlanViaje, dataInfo.codPlanilla, dataInfo.numeroHoras
			$( '#txtAsociadaImporte' ).val( roundComasMilesString( dataInfo.importe, 2 ) );
			$( '#asociadaFechaNacMen4h' ).val( dataInfo.fecha );
			$( '#asociadaSalidaNacMen4h' ).val( dataInfo.horaSalida );
			$( '#asociadaRetornoNacMen4h' ).val( dataInfo.horaRetorno );			
			
		}
		
	} else { // si es internacional
		
		$('#divPlanillaAsociadaMayor4Wrapper').hide();
		$('#divPlanillaAsociadaMenorIgual4Wrapper').hide();
		$('#divPlanillaAsociadaInternacionalWrapper').show();
		
		// datos adicionales: dataInfo.codPlanViaje, dataInfo.codPlanilla, dataInfo.numeroDias
		$( '#txtAsociadaImporte' ).val( roundComasMilesString( dataInfo.importe, 2 ) );
		$( '#asociadaFechaEventoInicioInter' ).val( dataInfo.fechaEventoInicio );
		$( '#asociadaFechaEventoFinInter' ).val( dataInfo.fechaEventoFin );		
		
	}
	
}

$(window).on("resize", function() {

	resizeTable("tblDesplazamientoRSV");

	// inicializando las tablas de sustento de gasto
	resizeTable("tblComprobantesRSV");
	resizeTable("tblGastosViaticosRSV");
	resizeTable("tblGastosPasajesRSV");
	resizeTable("tblResumenGastosRSV");
	
	// Inicializando las tablas de los modales
	resizeTable("tblDestino");
	resizeTable("tblColaborador");
	resizeTable("tblCadenaPresupuestal");
	resizeTable("tblVacaciones");
	resizeTable("tblCompensaciones");
	resizeTable("tblLicencias");
	resizeTable("tblArchivo");
});