function initElementsAnularDocumento(dataParametrosAnularDocumento) {
	setInitElementsAnularDocumento(dataParametrosAnularDocumento);
}

function setInitElementsAnularDocumento(dataParametrosAnularDocumento) {
	
	hideElement("divErrorAnularDocumento");
	if (dataParametrosAnularDocumento.codigoPaginaCaller != "01" && dataParametrosAnularDocumento.codigoPaginaCaller != "02") {
		setTextLabel("lblNumeroPlanillaAnularDocumento", propertyMessageAnularDocumento.nroSolicitudReembolso);
	}
	setValueInputText("hidCodPlanViajeAnularDocumento", dataParametrosAnularDocumento.codPlanViaje);
	setValueInputText("hidCodigoColaboradorAnularDocumento", dataParametrosAnularDocumento.codigoColaborador);
	setValueInputText("hidCodigoSedeColaboradorAnularDocumento", dataParametrosAnularDocumento.codigoSedeColaborador);
	setValueInputText("hidExpedientePlanViajeAnularDocumento", dataParametrosAnularDocumento.expedientePlanViaje);
	setValueInputText("hidCodigoPaginaCallerAnularDocumento", dataParametrosAnularDocumento.codigoPaginaCaller);
	setValueInputText("txtNombreColaboradorAnularDocumento", dataParametrosAnularDocumento.nomColaborador);
	setValueInputText("txtDescripcionDependenciaAnularDocumento", dataParametrosAnularDocumento.descripcionDependencia);
	setValueInputText("txtNumeroPlanillaAnularDocumento", dataParametrosAnularDocumento.codPlanilla);
	setValueInputText("txtImporteAnularDocumento", dataParametrosAnularDocumento.montoTotal);
	setValueInputText("etiquetaFechaAnulacionAnularDocumento", getCurrentDateFormatEsp());
	setValueInputText("elementoMotivoAnularDocumento", "");
	
	addEventElement("btnAceptarAnularDocumento", "click", clickBtnAceptarAnularDocumento);
	addEventElement("btnCancelarAnularDocumento", "click", clickBtnCancelarAnularDocumento);
	addEventElement("btnSiAnularSolicitudAnularDocumento", "click", clickBtnSiAnularSolicitudAnularDocumento);
	addEventElement("btnNoAnularSolicitudAnularDocumento", "click", clickBtnNoAnularSolicitudAnularDocumento);
	addEventElement("btnAceptarAnulacionExitosaAnularDocumento", "click", clickBtnAceptarAnulacionExitosaAnularDocumento);
	addEventElement("btnAceptarMensajeConfirmacionErrorAnularDocumento", "click", clickBtnAceptarMensajeConfirmacionErrorAnularDocumento);
}

function removeEventElementsAnularDocumento() {
	
	removeAllEventsElement("elementoMotivoAnularDocumento");
	removeAllEventsElement("btnAceptarAnularDocumento");
	removeAllEventsElement("btnCancelarAnularDocumento");
	removeAllEventsElement("btnSiAnularSolicitudAnularDocumento");
	removeAllEventsElement("btnNoAnularSolicitudAnularDocumento");
	removeAllEventsElement("btnAceptarAnulacionExitosaAnularDocumento");
	removeAllEventsElement("btnAceptarMensajeConfirmacionErrorAnularDocumento");
}

function clickBtnAceptarAnularDocumento() {
	if (validarAnularDocumento()) {
		var titulo1 = propertyMessageAnularDocumento.anularSolicitudTitulo1Solicitud;
		if (getValueInputText("hidCodigoPaginaCallerAnularDocumento") != "01" && getValueInputText("hidCodigoPaginaCallerAnularDocumento") != "02") {
			titulo1 = propertyMessageAnularDocumento.anularSolicitudTitulo1Reembolso;
		}
		setHtmlElement("divTituloPanelAnularSolicitudAnularDocumento", titulo1 + getValueInputText("txtNumeroPlanillaAnularDocumento") + propertyMessageAnularDocumento.anularSolicitudTitulo2);
		enabledElement("btnSiAnularSolicitudAnularDocumento");
		showModalElement("divMensajeConfirmacionAnularSolicitudAnularDocumento");
	}
}

function clickBtnCancelarAnularDocumento() {
	removeEventElementsAnularDocumento();
	hideModalElement("divAnularDocumento");
}

function clickBtnSiAnularSolicitudAnularDocumento() {
	disabledElement("btnSiAnularSolicitudAnularDocumento");
	hideModalElement("divAnularDocumento");
	hideModalElement("divMensajeConfirmacionAnularSolicitudAnularDocumento");
	callAnularDocumento();
}

function clickBtnNoAnularSolicitudAnularDocumento() {
	hideModalElement("divMensajeConfirmacionAnularSolicitudAnularDocumento");
}

function clickBtnAceptarAnulacionExitosaAnularDocumento() {
	removeEventElementsAnularDocumento();
	if (getValueInputText("hidCodigoPaginaCallerAnularDocumento") == "01") {
		$("#btnConsultarSolicitud").trigger("click");
	}
	else if (getValueInputText("hidCodigoPaginaCallerAnularDocumento") == "02") {
		$("#btnConsultarSolicitud").trigger("click");
	}
	else if (getValueInputText("hidCodigoPaginaCallerAnularDocumento") == "03") {
		$("#btnConsultarReembolso").trigger("click"); // cambiar a btnConsultarReembolso
	}
	else if (getValueInputText("hidCodigoPaginaCallerAnularDocumento") == "04") {
		$("#btnConsultarReembolso").trigger("click");
	}
	hideModalElement("divMensajeConfirmacionAnulacionExitosaAnularDocumento");
}

function clickBtnAceptarMensajeConfirmacionErrorAnularDocumento() {
	hideModalElement("divMensajeConfirmacionErrorAnularDocumento");
}

function validarAnularDocumento() {
	
	var dataValidacion;
	hideElement("divErrorAnularDocumento");
	
	dataValidacion = validarCamposNoVaciosAnularDocumento();
	if (!dataValidacion.flagCamposNoVacios) {
		showMessageErrorAnularDocumento(dataValidacion.errorMessage);
		return false;
	}
	
	dataValidacion = validarMotivoAnulacionCorrecto();
	if (!dataValidacion.flagMotivoAnulacionCorrecto) {
		showMessageErrorAnularDocumento(dataValidacion.errorMessage);
		return false;
	}
	
	return true;
}

function validarCamposNoVaciosAnularDocumento() {
	
	var flagCamposNoVacios = true;
	var errorMessage = "";
	
	if (flagCamposNoVacios && trimText(getValueInputText("elementoMotivoAnularDocumento")) == "") {
		flagCamposNoVacios = false;
		errorMessage = errorMessageAnularDocumento.completarMotivo;
	}
	
	var dataValidacion = {
		flagCamposNoVacios: flagCamposNoVacios,
		errorMessage: errorMessage
	};
	return dataValidacion;
}

function validarMotivoAnulacionCorrecto() {
	
	var flagMotivoAnulacionCorrecto = true;
	var errorMessage = "";
	
	if (flagMotivoAnulacionCorrecto && getValueInputText("elementoMotivoAnularDocumento").length > 1000) {
		flagMotivoAnulacionCorrecto = false;
		errorMessage = errorMessageAnularDocumento.maximoCaracteresMotivo;
	}
	
	var dataValidacion = {
		flagMotivoAnulacionCorrecto: flagMotivoAnulacionCorrecto,
		errorMessage: errorMessage
	};
	return dataValidacion;
}

function callAnularDocumento() {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/revisionGeneral.htm?action=anularDocumento",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codPlanViaje": getValueInputText("hidCodPlanViajeAnularDocumento"),
				"codigoPlanilla": getValueInputText("txtNumeroPlanillaAnularDocumento"),
				"observacionAnulacion": getUpperCaseValueInputText("elementoMotivoAnularDocumento"),
				"codigoColaborador": getUpperCaseValueInputText("hidCodigoColaboradorAnularDocumento"),
				"codigoSedeColaborador": getUpperCaseValueInputText("hidCodigoSedeColaboradorAnularDocumento"),
				"expedientePlanViaje": getUpperCaseValueInputText("hidExpedientePlanViajeAnularDocumento"),
				"codigoPaginaCaller": getValueInputText("hidCodigoPaginaCallerAnularDocumento")
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showModalElement("divMensajeConfirmacionLoadingAnularDocumento");
			},
			complete: function() {
				hideModalElement("divMensajeConfirmacionLoadingAnularDocumento");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var codigoOperacion = result.codigoOperacion;
				var errorMessage = result.errorMessage;
				var successMessage = result.successMessage;
				if (codigoOperacion != null && codigoOperacion == "00") {
					showModalElement("divMensajeConfirmacionAnulacionExitosaAnularDocumento");
				}
				else {
					showMensajeConfirmacionErrorAnularDocumento(errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callAnularDocumento");
			}
		});
	}, 500);
}

function showMessageErrorAnularDocumento(errorMessage) {
	setHtmlElement("etiquetaErrorAnularDocumento", errorMessage);
	showElement("divErrorAnularDocumento");
}

function showMensajeConfirmacionErrorAnularDocumento(messageTitulo) {
	hideElement("divBodyPanelMensajeConfirmacionErrorAnularDocumento");
	setHtmlElement("divTituloPanelMensajeConfirmacionErrorAnularDocumento", messageTitulo);
	showModalElement("divMensajeConfirmacionErrorAnularDocumento");
}