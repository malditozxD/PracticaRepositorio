function initElementsArchivo(numArchivo,codPlanViaje,numRegistro,nomColaborador,nomDependencia,codPlanilla,importe,codUUOO, functionAfterCerrar){
	hideElement("divMensajeArchivo");
	$("#cabArchivo1").html(cabeceraArchivo1(numRegistro,nomColaborador,nomDependencia,codUUOO));
	$("#cabArchivo2").html(cabeceraArchivo2(codPlanilla,importe));
	setInitElementsArchivo(functionAfterCerrar);
	setInitArchivoTable();
	getInitArchivoTable(numArchivo,codPlanViaje);
}

function setInitElementsArchivo(functionAfterCerrar) {
	addEventElement("btnEliminarArchivo", "click", clickBtnEliminarArchivo);
	addEventElement("btnOkMensajeAdvertenciaRegistrar", "click", clickBtnOkMensajeAdvertenciaRegistrar);
	addEventElement("btnSiMensajeConfirmarEliminar", "click", clickBtnSiMensajeConfirmarEliminar);
	addEventElement("btnNoMensajeConfirmarEliminar", "click", clickBtnNoMensajeConfirmarEliminar);
	addEventElement("btnOkMensajeConfirmarEliminar", "click", clickBtnOkMensajeConfirmarEliminar);
	
	// customizar el salir, agregando un functionAfterCerrar
	addEventElement("btnSalirArchivo", "click", function() {
		
		removeEventElementsRegistrarArchivo();	
		$("#divConsultarArchivo").modal("hide");

		// si el evento after esta definido en el servicio
		if ((typeof functionAfterCerrar != "undefined") && functionAfterCerrar != null ) {
			functionAfterCerrar();
		}		
	});	
}

function cabeceraArchivo1(numRegistro,nomColaborador,nomDependencia,codUUOO) {
	var str="";
	str += "	<div class=\"col-xs-12 col-sm-3 col-md-2 col-lg-2\">";
	str += "		<label for=\"txtNombreColaborador\" class=\"text-muted alineartext\">Comisionado:<\/label>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-9 col-md-4 col-lg-4\">";
	str += "		<input class=\"form-control input-sm margen-input\" type=\"text\"";
	str += "			id=\"txtNombreColaborador\" name=\"txtNombreColaborador\" readonly=\"readonly\" value=\""+numRegistro +" - "+ nomColaborador+"\"><\/input>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-3 col-md-2 col-lg-2\">";
	str += "		<label for=\"txtNumUUOO\" class=\"text-muted alineartext\">UUOO:<\/label>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-9 col-md-4 col-lg-4\">";
	str += "		<input class=\"form-control input-sm margen-input\"  type=\"text\"";
	str += "			id=\"txtNumUUOO\" name=\"txtNumUUOO\"  readonly=\"readonly\" value=\""+ codUUOO +" - "+ nomDependencia+"\"><\/input>";
	str += "	<\/div>";
	return str;
} 

function cabeceraArchivo2(codPlanilla,importe) {
	var str="";
	str += "	<div class=\"col-xs-12 col-sm-3 col-md-2 col-lg-2\">";
	str += "		<label for=\"txtNumPlanilla\" class=\"text-muted alineartext\">N&deg; Planilla:<\/label>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-9 col-md-4 col-lg-4\">";
	str += "		<input class=\"form-control input-sm margen-input\" type=\"text\"";
	str += "			id=\"txtNumPlanilla\" name=\"txtNumPlanilla\" readonly=\"readonly\" value=\""+codPlanilla +"\"><\/input>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-3 col-md-2 col-lg-2\">";
	str += "		<label for=\"txtImporte\" class=\"text-muted alineartext\">Monto:<\/label>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-9 col-md-4 col-lg-4\">";
	str += "		<input class=\"form-control input-sm margen-input\"  type=\"text\"";
	str += "			id=\"txtImporte\" name=\"txtImporte\"  readonly=\"readonly\" value=\""+ importe +"\"><\/input>";
	str += "	<\/div>";	
	return str;
} 

function clickBtnAgregarArchivo() {
	$('#divAgregarArchivo').modal('show');	
}

function clickBtnOkMensajeAdvertenciaRegistrar(){
	$("#divMensajeAdvertenciaRegistrar").modal('hide');
}

function clickBtnSiMensajeConfirmarEliminar(){
	ejecutarEliminarArchivo();
}

function clickBtnNoMensajeConfirmarEliminar(){
	$("#divMensajeConfirmarEliminar").modal('hide');
}

function buscarNumeroArchivo(){	
	var check = $('input:checkbox[name=chkGridArchivo]:checked');
	return check.attr("id");
}

function actulizarGrilla(respuesta) {
	var listArchivosAdj=respuesta.listArchivosAdj;
	
	$("#tblArchivo").jqGrid('clearGridData');
	for(var i=0;i<listArchivosAdj.length;i++){
		var archivo= listArchivosAdj[i];
		var datarow = {
				sec_reg:archivo.sec_reg,
				file_name:archivo.file_name,
				tipo_doc:archivo.tipo_doc,
				size_tag:archivo.size_tag,
				fec_carga_tag:archivo.fec_carga_tag,
				seleccion:'0'
					};
		var su=jQuery("#tblArchivo").jqGrid('addRowData',archivo.sec_reg,datarow);
	}			
	$("#tblArchivos").trigger("reloadGrid");
}

function clickBtnOkMensajeConfirmarEliminar(){
	$("#divMensajeOkConfirmarEliminar").modal('hide');
	$("#divMensajeConfirmarEliminar").modal('hide');
	$("#divMensajeAdvertenciaRegistrar").modal('hide');
	actulizarGrilla(rpt);
}
var rpt="";
function ejecutarEliminarArchivo(){
	var sec_reg = buscarNumeroArchivo();
	var numeroRegitroArchivo =  $("#hidNumArchivo").val();
	var ajax_data ={
			"numeroRegitroArchivo"		:	numeroRegitroArchivo,
			"sec_reg"   : sec_reg};
	
	$.ajax({	
	    url: contextPathUrl+"/archivos.htm?action=eliminarArchivoFisico",				
		data: ajax_data,
		type: "post",
		dataType: "json",
		
		success: function(respuesta) { 
			
			if(respuesta.mensaje =="Ok"){			
				rpt=respuesta;
				$("#divMensajeOkConfirmarEliminar").modal('show');
			}else{
				
			}
			},
			complete: function (data, status) {},
		error:function (xhr, ajaxOptions, thrownError) {}			 
	    });
}

function clickBtnEliminarArchivo(){
	var sec_reg = buscarNumeroArchivo();

	if(sec_reg == undefined){
		$("#divMensajeAdvertenciaRegistrar").modal('show');
	}else{
		$("#divMensajeConfirmarEliminar").modal('show');
	}
}

 
function removeEventElementsRegistrarArchivo() {
	removeAllEventsElement("btnAgregarArchivo");
	removeAllEventsElement("btnEliminarArchivo");
	removeAllEventsElement("btnSalirArchivo");
	removeAllEventsElement("btnSiMensajeConfirmarEliminar");
	removeAllEventsElement("btnOkMensajeAdvertenciaRegistrar");
	removeAllEventsElement("btnNoMensajeConfirmarEliminar");
}

var formatterCheckBox = function (cellvalue, options, rowObject){
	var sec_reg =   rowObject.sec_reg;
        return '<input name="chkGridArchivo"  id="'+sec_reg+'"  class="chk'+sec_reg+' chkGridArchivo" type="checkbox" disabled onclick="javascript:clickSecuenciaRegistro(\'' + sec_reg+ '\');"/>';
}

function disableCheck(chk, estado){	
	if(estado){
		chk.attr('checked','checked');
		var check = $('input:checkbox[name=chkGridArchivo]:not(:checked)');
		$(check).each(function(){ $(this).attr("disabled","disabled");});
	}else{
		chk.removeAttr('checked','checked');
		var check = $('input:checkbox[name=chkGridArchivo]:not(:checked)');
		$(check).each(function(){ $(this).removeAttr("disabled","disabled");});
	}		
}

function clickSecuenciaRegistro(sec_reg){
	var chk = $(".chk"+sec_reg);		
	 if(chk.is(':checked')) {
		 disableCheck(chk,true);}
	 else { disableCheck(chk,false);}
}

function setInitArchivoTable(){
	$("#tblArchivo").jqGrid('clearGridData');	
	var declaracionTable = $("#tblArchivo");
	if (declaracionTable) {
		var declaracionTableDiv = $("#divBandejaRendicionTable");
		var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.viaticoModalContainer", ".viaticoModalContainerAuxiliar", "width"))/100);
		var widthTable = factorRedimensionamiento*declaracionTableDiv.width();
		//var widthTable = declaracionTableDiv.width();
		declaracionTable.jqGrid({
			width: widthTable,
			height: 250,			
			autowidth: true,
			datatype : "local",
			cmTemplate: { sortable: false },
			colNames:['N&uacute;mero','Nombre del Archivo','Tipo de Documento','Tama&ntilde;o','Fecha de Registro','Selecci&oacute;n'],
			colModel:[
			          	{name:'sec_reg',key: true,index:'sec_reg', width:50, align:'center',hidden: true},
						//{name:'file_name',index:'file_name', width:(4*widthTable/12),align:'center', formatter:'showlink',formatoptions:{baseLinkUrl:'archivos.htm', addParam: '&action=descargarArchivo', idName:'sec_reg'}},
			          	{name:'file_name',index:'file_name', width:(4*widthTable/12),align:'center',formatter:linkFormatterNombre},
						{name:'tipo_doc',index:'tipo_doc', width:(2*widthTable/12),align:'center'},
						{name:'size_tag',index:'size_tag',  width:(2*widthTable/12) ,align:'center'},
						{name:'fec_carga_tag',index:'fec_carga_tag',  width:(2*widthTable/12) ,align:'center'},
						{name:'seleccion',index:'seleccion',  width:(2*widthTable/12) ,align:'center', formatter: formatterCheckBox }
			],
			viewrecords : true,
			//loadtext:'Buscando...',
			//loadui:'enable',
			recordpos:'left',
			pagerpos:'center',
			altRows: true,
			multiselect: false,
			multiboxonly: true,
			headertitles: true,
			hidegrid: false,
			rowNum:10,
			rowList:[10,20,30],
			pager : "#divArchivoPagerTable",
			caption: "   "
		
		});
	}
}

var linkFormatterNombre = function(cellvalue, options, rowObject) {
	var idName = rowObject.sec_reg;
	var file_name = rowObject.file_name;
	var url = contextPathUrl + "/archivos.htm?action=descargarArchivo&sec_reg="+idName;
	return "<a class=\"jqGridViaticoLinkClass\" href=\""+url+"\">"+file_name+"</a>";
	//location.href = url;
}

function getInitArchivoTable(numArchivo,codPlanViaje){
	var ajax_data ={
			"numeroRegitroArchivo"		:	numArchivo
	};
		
	$.ajax({	
	    url: contextPathUrl+"/archivos.htm?action=getCargaArchivosAdjuntos",				
		data: ajax_data,
		type: "post",
		dataType: "json",               
		success: function(respuesta) { 
			var listArchivosAdj=respuesta.listArchivosAdj;
			//alert(listArchivosAdj.length);
			if (listArchivosAdj.length==0) {showMessageArchivo("No existen archivos adjuntos en la solicitud de vi&aacute;ticos "+ codPlanViaje);}
			
			$("#tblArchivo").jqGrid('clearGridData');
			for(var i=0;i<listArchivosAdj.length;i++){	
				var archivo= listArchivosAdj[i];
				var datarow = {
						sec_reg:archivo.sec_reg,
						file_name:archivo.file_name,
						tipo_doc:archivo.tipo_doc,
						size_tag:archivo.size_tag,
						fec_carga_tag:archivo.fec_carga_tag,
						seleccion:'0'
							};
				var su=jQuery("#tblArchivo").jqGrid('addRowData',archivo.sec_reg,datarow);
			}			
			$("#tblArchivos").trigger("reloadGrid");			
			},
			complete: function (data, status) {},
		error:function (xhr, ajaxOptions, thrownError) {}			 
	    });	
}

function showMessageArchivo(message) {
	setHtmlElement("etiquetaMensajeArchivo", message);
	showElement("divMensajeArchivo");
}

$(window).on("resize", function () {
	resizeTable("tblArchivo");
});