
var parametros = new Object();
var validaEstadoGeneral = 0;
var tituloRendicion = " ";
var validaEstadoFechaGeneral = 0;

function initElementsRegistrarModificarComprobanteRendicion(dataParametrosComprobante) {
	
	parametros.planViajeId = dataParametrosComprobante.planViajeId;
	parametros.secuencial = dataParametrosComprobante.secuencial;
	parametros.estadoLlamada = dataParametrosComprobante.estadoLlamada;
	parametros.origenLlamada = dataParametrosComprobante.origenLlamada;
	parametros.saldoRendir = dataParametrosComprobante.saldoRendir;
	parametros.numeroRegistroColaborador = dataParametrosComprobante.numeroRegistroColaborador;
	removeDuplicateComponents();
	setInitDatosRendicionTable();
	setInitDatosComprobantePagoTable();
	setInitElementsRegistrarModificarComprobanteRendicion();
	callObtenerDocumentoSustentario(parametros);

	$("#divDatosRendicionTable").attr("style", "height: 135px;");
	$("#containerDocumentoSustentario").attr("style", "margin-top: 0px;");
			
}

function setInitElementsRegistrarModificarComprobanteRendicion() {	
	addEventElement("btnCerrarComprobante", "click", clickBtnCerrarComprobante);
	addEventElement("btnGrabarComprobante", "click", clickBtnGrabarComprobante);
	addEventElement("btnGrabarAuxComprobante", "click", clickBtnGrabarAuxComprobante);
	addEventElement("btnCerrarAuxComprobante", "click", clickBtnCerrarAuxComprobante);
	addEventElement("btnSiMensajeComprobante", "click", clickBtnSiMensajeComprobante);
	addEventElement("btnNoMensajeComprobante", "click", clickBtnNoMensajeComprobante);
	addEventElement("btnAceptarMensajeComprobante", "click", clickBtnAceptarMensajeComprobante);
	addEventElement("btnAceptarMensajeWarningComprobante", "click", clickBtnAceptarMensajeWarningComprobante);
	addEventElement("btnAceptarMensajeErrorComprobante", "click",  clickBtnAceptarMensajeErrorComprobante);
	
	addEventElement("selTipoDocumentoComprobante", "change", changeSelTipoDocumentoComprobante);
	addEventElement("selTipoConceptoComprobante", "change", changeSelTipoConceptoComprobante);
	initDateTimePicker("etiquetaFechaDocumentoComprobanteDiv", "dp.change", "changeDate", changeDateEtiquetaFechaDocumentoComprobanteDiv);
	setValueInputText("txtSecuenciaComprobante","");
	setValueInputText("etiquetaFechaDocumentoComprobante","");
	setTextValueTipoDocumentoComprobante();
	
}

function changeDateEtiquetaFechaDocumentoComprobanteDiv(){
	validarFechaTipoDocumento();
}


function removeEventElementsRegistrarModificarComprobanteRendicion() {
	removeAllEventsElement("btnCerrarComprobante");
	removeAllEventsElement("btnGrabarComprobante");
	removeAllEventsElement("btnGrabarAuxComprobante");
	removeAllEventsElement("btnCerrarAuxComprobante");
	removeAllEventsElement("btnSiMensajeComprobante");
	removeAllEventsElement("btnNoMensajeComprobante");
	removeAllEventsElement("btnAceptarMensajeComprobante");
	removeAllEventsElement("btnAceptarMensajeWarningComprobante");
	removeAllEventsElement("btnAceptarMensajeErrorComprobante");
}

function removeTablesRegistrarModificarComprobanteRendicion() {
	var htmlElement = "<table id=\"tblDatosRendicion\"></table>";
	htmlElement += "<div id=\"divDatosRendicionPagerTable\"></div>";
	setHtmlElement("divDatosRendicionTable", htmlElement);
	
	var htmlElement = "<table id=\"tblDatosComprobantePago\"></table>";
	htmlElement += "<div id=\"divDatosComprobantePagoPagerTable\"></div>";
	setHtmlElement("divDatosComprobantePagoTable", htmlElement);
}

function ocultarMostrarColumna(idTabla, hideShowCol, columnaTabla){
	var table = $('#'+idTabla);
		table.jqGrid(hideShowCol,columnaTabla);
}

function setInitDatosRendicionTable() {
	var datosRendicionTable = $("#tblDatosRendicion");
	var heightJqGrid = 60;
	setStyleElement("divDatosRendicionTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 1, true));
	if (datosRendicionTable) {
		var datosRendicionTableDiv = $("#divDatosRendicionTable");
		var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.viaticoModalContainer", ".viaticoModalContainerAuxiliar", "width"))/100);
		var widthTable = factorRedimensionamiento*datosRendicionTableDiv.width();
		datosRendicionTable.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			datatype: "local",
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
			    "indice",
				"Moneda",
				"Valor Venta",
				"Monto Base",
				"I.G.V.",
				"-",
				"Exoneraci&oacute;n I.G.V.",
				"-",
				"Otros Gastos",
				"Valor Total",
				"Monto Total",
				"indAfectoIgv"
			],
			colModel: [
			    {name: "indice", index: "indice", width: (1*widthTable/20), hidden: true},
				{name: "moneda", index: "moneda", width: (2*widthTable/20), align: 'center',
			    	formatter:function(cellvalue, options, rowData){
			    		var moneda=rowData.moneda;
			    		var htmlElement ='<span  id="monedaRendicion">'+moneda+'</span>';
			    		return htmlElement;
			    	}
			    },
				{name: "valorVenta", index: "valorVenta", width: (4*widthTable/20),align: 'right',
					formatter:function(cellvalue, options, rowData){
						var valorVenta=rowData.valorVenta;
						var htmlElement = '<input oncopy="return false" oncut="return false" onpaste="return false" style="text-align: right;" id="valorVenta" onkeypress="return validarCharacterCurrency(event);"  onChange="javascript:onBlurMonto(this);" data-tipo="VV" value="'+valorVenta+'"/ >';
						return htmlElement;
					}	
				},
				{name: "montoBase", index: "montoBase", width: (4*widthTable/20),align: 'right',
					formatter:function(cellvalue, options, rowData){
						var montoBase=rowData.montoBase;
						var htmlElement = '<input oncopy="return false" oncut="return false" onpaste="return false" style="text-align: right; " id="montoBase" onkeypress="return validarCharacterCurrency(event);"  onChange="javascript:onBlurMonto(this);" data-tipo="MB" value="'+montoBase+'"/ >';
						return htmlElement;
					}	
				},
				{name: "igv", index: "igv", width: (3*widthTable/20), align: 'right',
					formatter:function(cellvalue, options, rowData){
						var igv = rowData.igv;
						var htmlElement = '<span id="igv">'+igv+'</span>';
						return htmlElement;
					}
				},
				{name: "cero", index: "cero", width: (3*widthTable/20), align: 'right',
					formatter:function(cellvalue, options, rowData){
						var cero = rowData.cero;
						var htmlElement = '<span id="cero">'+cero+'</span>';
						return htmlElement;
					}
				},
				{name: "exoneracionIgv", index: "exoneracionIgv", width: (4*widthTable/20),align: 'center',
					formatter:function(cellvalue, options, rowData){
						var htmlElement = '<select id="exoneracionIgv"  onchange="cambioIgv();">';							
							for(var i = 0; i< rowData.exoneracionIgv.length ; i++){
								var codigoArgumento = $.trim(rowData.exoneracionIgv[i].cod_argumento);
								var nombreCorto = $.trim(rowData.exoneracionIgv[i].nom_corto);
									htmlElement = htmlElement + '<option  value="'+codigoArgumento+'">'+nombreCorto+'</option>';
							}						
							htmlElement=htmlElement+'</select>';
							
						return htmlElement;
					}		
				},
				{name: "exoneracionFija", index: "exoneracionFija", width: (4*widthTable/20),align: 'center',
					formatter:function(cellvalue, options, rowData){
						var indAfectoIgv = "I"
						var htmlElement = '<select id="exoneracionFija" disabled>';							
							for(var i = 0; i< rowData.exoneracionIgv.length ; i++){
								var codigoArgumento = $.trim(rowData.exoneracionIgv[i].cod_argumento);
								var nombreCorto = $.trim(rowData.exoneracionIgv[i].nom_corto);
								if (codigoArgumento == indAfectoIgv)
									htmlElement = htmlElement + '<option   value="'+codigoArgumento+'">'+nombreCorto+'</option>';
							}						
							htmlElement=htmlElement+'</select>';
							
						return htmlElement;
					}
				},
				{name: "otroGasto", index: "otroGasto", width: (4*widthTable/20),align: 'right',
					formatter:function(cellvalue, options, rowData){
						var otroGasto=rowData.otroGasto;
						var htmlElement = '<input oncopy="return false" oncut="return false" onpaste="return false" style="text-align: right;" id="otroGasto" onkeypress="return validarCharacterCurrency(event);"  onChange="javascript:onBlurMonto(this);" data-tipo="OG" value="' + otroGasto + '"/ >';
						return htmlElement;
					}	},
				{name: "valorTotal", index: "valorTotal", width: (4*widthTable/20), align: 'center',
					formatter:function(cellvalue, options, rowData){
					var valorTotal=rowData.valorTotal;
					var htmlElement = '<input oncopy="return false" oncut="return false" onpaste="return false" style="text-align: right;" id="valorTotal" onkeypress="return validarCharacterCurrency(event);"  onChange="javascript:onBlurMonto(this);" data-tipo="VT" style="font-align :right;" value="' + valorTotal + '"/ >';
					return htmlElement;
					}	
				},
				{name: "montoTotal", index: "montoTotal", width: (4*widthTable/20), align: 'center',
						formatter:function(cellvalue, options, rowData){
							var montoTotal=rowData.montoTotal;
							var htmlElement = '<input oncopy="return false" oncut="return false" onpaste="return false" style="text-align: right;" id="montoTotal" onkeypress="return validarCharacterCurrency(event);"  onChange="javascript:onBlurMonto(this);" style="font-align :right;" data-tipo="MT"  value="' + montoTotal + '"/ >';
							return htmlElement;
						}	
				},
				{name: "indAfectoIgv", index: "indAfectoIgv", width: (5*widthTable/20), align: 'center', hidden:true}
				
					
			],
			
			caption: "Datos de la rendici&oacute;n",
			//pager: "#divDatosRendicionPagerTable",
			loadui: "disable"
		});
		//datosRendicionTable.clearGridData();
	}
}

function setInitDatosComprobantePagoTable() {
	var datosComprobantePagoTable = $("#tblDatosComprobantePago");
	var heightJqGrid = 97;
	setStyleElement("divDatosComprobantePagoTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 1, true));
	if (datosComprobantePagoTable) {
		var datosComprobantePagoTableDiv = $("#divDatosComprobantePagoTable");
		var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.viaticoModalContainer", ".viaticoModalContainerAuxiliar", "width"))/100);
		var widthTable = factorRedimensionamiento*datosComprobantePagoTableDiv.width();
		datosComprobantePagoTable.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			datatype: "local",
			autowidth: true,
			rowNum:360,
			cmTemplate: {sortable: false},
			colNames: [
			    "indice",
				"Fecha",
				"Alimentaci&oacute;n",
				"Hospedaje",
				"Movilidad",
				"Traslado",
				"Total",
				"fechaDDMMYYYY",
				"rendicionFechaRendicion",
				"rendicionFechaRendicionSinFormato"
			],
			colModel: [
			    {name: "indice", index: "indice", width: (4*widthTable/20), hidden: true},
				{name: "fechaViatico", index: "fechaViatico", width: (4*widthTable/20), align: 'center',
			    	formatter:function(cellvalue, options, rowData){
						var fechaViatico = rowData.fechaViatico;
						var fechaDDMMYYYY = rowData.fechaDDMMYYYY;
						var rendicionFechaRendicion = rowData.rendicionFechaRendicion;
						var rendicionFechaRendicionSinFormato = rowData.rendicionFechaRendicionSinFormato;
						var htmlElement = '<span  id="fechaViatico_'+fechaDDMMYYYY+'" class="fechaViatico">'+fechaViatico+'</span><span style=" color: rgb(68, 157, 165); display: block;" id="rendicionFechaRendicion_'+fechaDDMMYYYY+'"  class="rendicionFechaRendicion" data-montofechaformater="'+rendicionFechaRendicion+'" data-montofechasinformater="'+rendicionFechaRendicionSinFormato+'" >Mto m&aacute;x por D&iacute;a ('+rendicionFechaRendicion+')</span>';
						return htmlElement;
					}
			    },
				{name: "alimentacion", index: "alimentacion", width: (3*widthTable/20), align: 'center',
					formatter:function(cellvalue, options, rowData){
						var alimentacion = rowData.alimentacion;
						var fechaViatico = rowData.fechaDDMMYYYY;
						var htmlElement = '<input oncopy="return false" oncut="return false" onpaste="return false" style="text-align: right; width: 95%;" onkeypress="return validarCharacterCurrency(event);"  onChange="javascript:onBlurGastoItinerario(this);" id="alimentacion_'+fechaViatico+'" class="alimentacion" value="'+alimentacion+'"/ >';
						return htmlElement;
					}				
				},
				{name: "hospedaje", index: "hospedaje", width: (3*widthTable/20), align: 'center',
					formatter:function(cellvalue, options, rowData){
						var hospedaje = rowData.hospedaje;
						var fechaViatico = rowData.fechaDDMMYYYY;
						var htmlElement = '<input oncopy="return false" oncut="return false" onpaste="return false" style="text-align: right; width: 95%;" onkeypress="return validarCharacterCurrency(event);"  onChange="javascript:onBlurGastoItinerario(this);" id="hospedaje_'+fechaViatico+'" class="hospedaje" value="'+hospedaje+'"/ >';
						return htmlElement;
					}
				},
				{name: "movilidad", index: "movilidad", width: (3*widthTable/20), align: 'center',
					formatter:function(cellvalue, options, rowData){
						var movilidad = rowData.movilidad;
						var fechaViatico = rowData.fechaDDMMYYYY;
						var htmlElement = '<input oncopy="return false" oncut="return false" onpaste="return false" style="text-align: right; width: 95%;"  onkeypress="return validarCharacterCurrency(event);"  onChange="javascript:onBlurGastoItinerario(this);" id="movilidad_'+fechaViatico+'" class="movilidad" value="'+movilidad+'"/ >';
						return htmlElement;
					}				
				},
				{name: "translado", index: "translado", width: (3*widthTable/20), align: 'center',
					formatter:function(cellvalue, options, rowData){
						var translado = rowData.translado;
						var fechaViatico = rowData.fechaDDMMYYYY;
						var htmlElement = '<input oncopy="return false" oncut="return false" onpaste="return false" style="text-align: right; width: 95%;"  onkeypress="return validarCharacterCurrency(event);"  onChange="javascript:onBlurGastoItinerario(this);" id="translado_'+fechaViatico+'" class="translado"  value="'+translado+'"/ >';
						return htmlElement;
					}
				},
				{name: "total", index: "total", width: (3*widthTable/20), align: 'right',
					formatter:function(cellvalue, options, rowData){
						var total = rowData.total;
						var fechaViatico = rowData.fechaDDMMYYYY;
						var htmlElement = '<span  id="total_'+fechaViatico+'" class="total">'+total+'</span>';
						return htmlElement;
					}
				},
				{name: "fechaDDMMYYYY", index: "fechaDDMMYYYY", width: (4*widthTable/20), align: 'center', hidden:true},
				{name: "rendicionFechaRendicion", index: "rendicionFechaRendicion", width: (5*widthTable/20), align: 'center', hidden:true},
				{name: "rendicionFechaRendicionSinFormato", index: "rendicionFechaRendicionSinFormato", width: (5*widthTable/20), align: 'center', hidden:true}
			],
			caption: "Datos del comprobante de pago",
			
			loadui: "disable",
			
			footerrow: true,
			loadComplete: function () {
			    $(this).jqGrid('footerData','set',
			        {fechaViatico:'Total', alimentacion:'' , hospedaje:'', movilidad:'',
			    	translado:'', total:''});
			}
			
		});
		datosComprobantePagoTable.clearGridData();
	}
}

function clickBtnCerrarComprobante() {
	removeEventElementsRegistrarModificarComprobanteRendicion();
	removeTablesRegistrarModificarComprobanteRendicion();
    hideModalElement("divRegistrarModificarComprobanteRendicion");
}
function clickBtnCerrarAuxComprobante(){
	removeEventElementsRegistrarModificarComprobanteRendicion();
	removeTablesRegistrarModificarComprobanteRendicion();
    hideModalElement("divRegistrarModificarComprobanteRendicion");
}


function bloqueoParametrosDocumentoComprobante(){
	disabledElement("selTipoDocumentoComprobante");
	disabledElement("txtRucComprobante");
	disabledElement("txtRazonSocialComprobante");
	disabledElement("txtSecuenciaComprobante");
	disabledElement("txtSerieDocumentoComprobante");
	disabledElement("txtNumeroDocumentoComprobante");
	disabledElement("etiquetaFechaDocumentoComprobante");
	disabledElement("selTipoConceptoComprobante");
	disabledElement("txtClasificadorGastoComprobante");
	disabledElement("txtSustentoLugarReferenciaComprobante");	
	disabledElement("montoBase");
	disabledElement("valorVenta");
	disabledElement("exoneracionIgv");
	disabledElement("otroGasto");
	disabledElement("valorTotal");
	disabledElement("montoTotal");
	disabledElementForClass("alimentacion");
	disabledElementForClass("hospedaje");
	disabledElementForClass("movilidad");
	disabledElementForClass("translado");
}


function bloqueoParametrosDocumentoComprobanteXAdventencia(){
	disabledElement("txtRucComprobante");
	disabledElement("txtRazonSocialComprobante");
	disabledElement("txtSecuenciaComprobante");
	disabledElement("txtSerieDocumentoComprobante");
	disabledElement("txtNumeroDocumentoComprobante");
	disabledElement("etiquetaFechaDocumentoComprobante");
	disabledElement("selTipoConceptoComprobante");
	disabledElement("txtClasificadorGastoComprobante");
	disabledElement("txtSustentoLugarReferenciaComprobante");	
	disabledElement("montoBase");
	disabledElement("valorVenta");
	disabledElement("exoneracionIgv");
	disabledElement("otroGasto");
	disabledElement("valorTotal");
	disabledElement("montoTotal");
	disabledElementForClass("alimentacion");
	disabledElementForClass("hospedaje");
	disabledElementForClass("movilidad");
	disabledElementForClass("translado");
}


function changeSelTipoDocumentoComprobante() {
	selTipoDocumentoComprobante();
    setTextValueTipoDocumentoComprobante();    	
}

function bloqueoEdicionDocumentoSustentatorio(){
	disabledElement("selTipoDocumentoComprobante");
	disabledElement("etiquetaFechaDocumentoComprobante");
	disabledElement("selTipoConceptoComprobante");
}

function setTextValueTipoDocumentoComprobante(){

	//DECLARACION JURADA - COMPROBANTE DE PAGO / DECLARACION JURADA - VIATICOS
    if (getValueInputText("selTipoDocumentoComprobante") == "907" || getValueInputText("selTipoDocumentoComprobante") == "906") {
 		setValueInputText("txtRucComprobante", "");
 		setValueInputText("txtRazonSocialComprobante", "");
 		setValueInputText("txtSerieDocumentoComprobante", "0000");
 		setValueInputText("txtNumeroDocumentoComprobante", "00000000");
 		setValueInputText("txtClasificadorGastoComprobante", "");
 		initSelectOption("selTipoConceptoComprobante",0);
 		tituloRendicion = "Datos de la rendici&oacute;n";
 		$("#gview_tblDatosRendicion .ui-jqgrid-title").html(tituloRendicion);
    }//COMPROBANTE DEL EXTERIOR
    else if (getValueInputText("selTipoDocumentoComprobante") == "916") {
    	setValueInputText("txtSerieDocumentoComprobante", "0000");
 		setValueInputText("txtNumeroDocumentoComprobante", "00000000");
 		setValueInputText("txtRucComprobante", "");
 		setValueInputText("txtRazonSocialComprobante", "");
 		setValueInputText("txtClasificadorGastoComprobante", "");
 		initSelectOption("selTipoConceptoComprobante",0);
 		tituloRendicion = "Datos de la rendici&oacute;n";
 		$("#gview_tblDatosRendicion .ui-jqgrid-title").html(tituloRendicion);
    }//BOLETO DE VIAJE
    else if (getValueInputText("selTipoDocumentoComprobante") == "915" || getValueInputText("selTipoDocumentoComprobante") == "067") {
    	setValueInputText("txtSerieDocumentoComprobante", "");
 		setValueInputText("txtNumeroDocumentoComprobante", "");
 		setValueInputText("txtRucComprobante", "");
 		setValueInputText("txtRazonSocialComprobante", "");
 		setValueInputText("txtClasificadorGastoComprobante", "");
 		initSelectOption("selTipoConceptoComprobante",0);
 		tituloRendicion = "Datos de la rendici&oacute;n";
 		$("#gview_tblDatosRendicion .ui-jqgrid-title").html(tituloRendicion);
    }//SELECCIONE
	else if(getValueInputText("selTipoDocumentoComprobante") == "000"){
		setValueInputText("txtSerieDocumentoComprobante", "");
 		setValueInputText("txtNumeroDocumentoComprobante", "");
 		setValueInputText("txtClasificadorGastoComprobante", "");
 		initSelectOption("selTipoConceptoComprobante",0);
 		setValueInputText("txtRucComprobante", "");
 		setValueInputText("txtRazonSocialComprobante", "");
 		setValueInputText("txtSecuenciaComprobante","");
 		
	}
	else {//OTROS
		tituloRendicion = " ";
		setValueInputText("txtSerieDocumentoComprobante", "");
 		setValueInputText("txtNumeroDocumentoComprobante", "");
 		setValueInputText("txtRucComprobante", "");
 		setValueInputText("txtRazonSocialComprobante", "");
 		setValueInputText("txtClasificadorGastoComprobante", "");
 		initSelectOption("selTipoConceptoComprobante",0);
 		$("#gview_tblDatosRendicion .ui-jqgrid-title").html(tituloRendicion);
	}
    setValueInputText("montoBase", "0.00");
    setValueInputText("valorVenta", "0.00");
    setValueInputText("otroGasto", "0.00");
    setValueInputText("valorTotal", "0.00");
    setValueInputText("montoTotal", "0.00");
	setValueInputTextClass("alimentacion", "0.00");
	setValueInputTextClass("hospedaje", "0.00");
	setValueInputTextClass("movilidad", "0.00");
	setValueInputTextClass("translado", "0.00");
	setHtmlElementClass("total", "0.00");
	setHtmlElement("igv","0.00");
    setValueInputText("txtSustentoLugarReferenciaComprobante", "");
}

function selTipoDocumentoComprobante(){
	//DECLARACION JURADA - COMPROBANTE DE PAGO / DECLARACION JURADA - VIATICOS
	consoleLog("codigoDocumentoComprobante: " + getValueInputText("selTipoDocumentoComprobante"));
	var estadoDDJJ = getValueInputText("estadoDDJJ");
	if (getValueInputText("selTipoDocumentoComprobante") == "907" || getValueInputText("selTipoDocumentoComprobante") == "906") {
    	
		     	var tipoDestino = getValueInputText("tipoDestino");
				if(tipoDestino=="01"){
					
					if(getValueInputText("selTipoDocumentoComprobante") == "907"){
		
						if(estadoDDJJ=="true" || (parametros.estadoLlamada == "E" || parametros.estadoLlamada == "C")){
								setTextLabel("lblSustentoLugarReferenciaComprobante", "Sustento/Lugar:");
								showElement("divDatosComprobantePagoTable");
								if (getValueInputText("selTipoDocumentoComprobante") == "907" ){
									enabledElement("txtSustentoLugarReferenciaComprobante");}
								else if(getValueInputText("selTipoDocumentoComprobante") == "906"){
									disabledElement("txtSustentoLugarReferenciaComprobante");
								}	
								
								disabledElement("txtRucComprobante");
								disabledElement("txtRazonSocialComprobante");
								disabledElement("txtSecuenciaComprobante");
								disabledElement("txtSerieDocumentoComprobante");
								disabledElement("txtNumeroDocumentoComprobante");
								enabledElement("etiquetaFechaDocumentoComprobante");
								enabledElement("selTipoConceptoComprobante");
								disabledElement("txtClasificadorGastoComprobante");
								enabledElement("btnGrabarComprobante");	

								enabledElement("montoBase");
								enabledElement("valorVenta");
								enabledElement("exoneracionIgv");
								enabledElement("otroGasto");
								enabledElement("valorTotal");
								enabledElement("montoTotal");

								consoleLog("bloquedo");
								ocultarMostrarColumna("tblDatosRendicion", "showCol", "moneda");
								ocultarMostrarColumna("tblDatosRendicion", "hideCol", "valorVenta");
								ocultarMostrarColumna("tblDatosRendicion", "showCol", "montoBase");
								ocultarMostrarColumna("tblDatosRendicion", "hideCol", "igv");
								ocultarMostrarColumna("tblDatosRendicion", "showCol", "cero");
								ocultarMostrarColumna("tblDatosRendicion", "hideCol", "exoneracionIgv");
								ocultarMostrarColumna("tblDatosRendicion", "showCol", "exoneracionFija");
								ocultarMostrarColumna("tblDatosRendicion", "showCol", "otroGasto");
								ocultarMostrarColumna("tblDatosRendicion", "hideCol", "valorTotal");
								ocultarMostrarColumna("tblDatosRendicion", "showCol", "montoTotal");	
						
						}else
		
							if(estadoDDJJ=="false" && parametros.estadoLlamada == "N"){
		
							var mensaje = (errorMessageRegistrarComprobante.unoDDJJ).replace("DOCUMENTO", getUpperCaseTextSelect("selTipoDocumentoComprobante"))
							setHtmlElement("spaMensajeAdvertenciaComprobante", mensaje);	
							$("#divMensajeAdvertenciaComprobante").modal("show");
							bloqueoParametrosDocumentoComprobanteXAdventencia();
						}
						
					}else if(getValueInputText("selTipoDocumentoComprobante") == "906"){
							 	
							setTextLabel("lblSustentoLugarReferenciaComprobante", "Sustento/Lugar:");
							showElement("divDatosComprobantePagoTable");
							if (getValueInputText("selTipoDocumentoComprobante") == "907" ){
								enabledElement("txtSustentoLugarReferenciaComprobante");}
							else if(getValueInputText("selTipoDocumentoComprobante") == "906"){
								disabledElement("txtSustentoLugarReferenciaComprobante");
							}	
							
							disabledElement("txtRucComprobante");
							disabledElement("txtRazonSocialComprobante");
							disabledElement("txtSecuenciaComprobante");
							disabledElement("txtSerieDocumentoComprobante");
							disabledElement("txtNumeroDocumentoComprobante");
							enabledElement("etiquetaFechaDocumentoComprobante");
							enabledElement("selTipoConceptoComprobante");
							disabledElement("txtClasificadorGastoComprobante");
							enabledElement("btnGrabarComprobante");	

							enabledElement("montoBase");
							enabledElement("valorVenta");
							enabledElement("exoneracionIgv");
							enabledElement("otroGasto");
							enabledElement("valorTotal");
							enabledElement("montoTotal");

							ocultarMostrarColumna("tblDatosRendicion", "showCol", "moneda");
							ocultarMostrarColumna("tblDatosRendicion", "hideCol", "valorVenta");
							ocultarMostrarColumna("tblDatosRendicion", "showCol", "montoBase");
							ocultarMostrarColumna("tblDatosRendicion", "hideCol", "igv");
							ocultarMostrarColumna("tblDatosRendicion", "showCol", "cero");
							ocultarMostrarColumna("tblDatosRendicion", "hideCol", "exoneracionIgv");
							ocultarMostrarColumna("tblDatosRendicion", "showCol", "exoneracionFija");
							ocultarMostrarColumna("tblDatosRendicion", "showCol", "otroGasto");
							ocultarMostrarColumna("tblDatosRendicion", "hideCol", "valorTotal");
							ocultarMostrarColumna("tblDatosRendicion", "showCol", "montoTotal");	
					
					}
					
				}else if(tipoDestino=="02"){
					if(getValueInputText("selTipoDocumentoComprobante") == "907"){
								   
						if(estadoDDJJ=="true" || (parametros.estadoLlamada == "E" || parametros.estadoLlamada == "C")){
						 	
										setTextLabel("lblSustentoLugarReferenciaComprobante", "Sustento/Lugar:");
										showElement("divDatosComprobantePagoTable");
										if (getValueInputText("selTipoDocumentoComprobante") == "907" ){
											enabledElement("txtSustentoLugarReferenciaComprobante");}
										else if(getValueInputText("selTipoDocumentoComprobante") == "906"){
											disabledElement("txtSustentoLugarReferenciaComprobante");
										}	
										
										disabledElement("txtRucComprobante");
										disabledElement("txtRazonSocialComprobante");
										disabledElement("txtSecuenciaComprobante");
										disabledElement("txtSerieDocumentoComprobante");
										disabledElement("txtNumeroDocumentoComprobante");
										enabledElement("etiquetaFechaDocumentoComprobante");
										enabledElement("selTipoConceptoComprobante");
										disabledElement("txtClasificadorGastoComprobante");
										enabledElement("btnGrabarComprobante");	

										enabledElement("montoBase");
										enabledElement("valorVenta");
										enabledElement("exoneracionIgv");
										enabledElement("otroGasto");
										enabledElement("valorTotal");
										enabledElement("montoTotal");

										ocultarMostrarColumna("tblDatosRendicion", "showCol", "moneda");
										ocultarMostrarColumna("tblDatosRendicion", "hideCol", "valorVenta");
										ocultarMostrarColumna("tblDatosRendicion", "showCol", "montoBase");
										ocultarMostrarColumna("tblDatosRendicion", "hideCol", "igv");
										ocultarMostrarColumna("tblDatosRendicion", "showCol", "cero");
										ocultarMostrarColumna("tblDatosRendicion", "hideCol", "exoneracionIgv");
										ocultarMostrarColumna("tblDatosRendicion", "showCol", "exoneracionFija");
										ocultarMostrarColumna("tblDatosRendicion", "showCol", "otroGasto");
										ocultarMostrarColumna("tblDatosRendicion", "hideCol", "valorTotal");
										ocultarMostrarColumna("tblDatosRendicion", "showCol", "montoTotal");	
								
								}else if(estadoDDJJ=="false" && parametros.estadoLlamada == "N"){
									var mensaje = (errorMessageRegistrarComprobante.unoDDJJ).replace("DOCUMENTO", getUpperCaseTextSelect("selTipoDocumentoComprobante"))
									setHtmlElement("spaMensajeAdvertenciaComprobante", mensaje);	
									$("#divMensajeAdvertenciaComprobante").modal("show");
									bloqueoParametrosDocumentoComprobanteXAdventencia();
								}
						
								
							}else if(getValueInputText("selTipoDocumentoComprobante") == "906"){
								
								
								setTextLabel("lblSustentoLugarReferenciaComprobante", "Sustento/Lugar:");
								showElement("divDatosComprobantePagoTable");
								if (getValueInputText("selTipoDocumentoComprobante") == "907" ){
									enabledElement("txtSustentoLugarReferenciaComprobante");}
								else if(getValueInputText("selTipoDocumentoComprobante") == "906"){
									disabledElement("txtSustentoLugarReferenciaComprobante");
								}	
								
								disabledElement("txtRucComprobante");
								disabledElement("txtRazonSocialComprobante");
								disabledElement("txtSecuenciaComprobante");
								disabledElement("txtSerieDocumentoComprobante");
								disabledElement("txtNumeroDocumentoComprobante");
								enabledElement("etiquetaFechaDocumentoComprobante");
								enabledElement("selTipoConceptoComprobante");
								disabledElement("txtClasificadorGastoComprobante");
								enabledElement("btnGrabarComprobante");	

								enabledElement("montoBase");
								enabledElement("valorVenta");
								enabledElement("exoneracionIgv");
								enabledElement("otroGasto");
								enabledElement("valorTotal");
								enabledElement("montoTotal");

								ocultarMostrarColumna("tblDatosRendicion", "showCol", "moneda");
								ocultarMostrarColumna("tblDatosRendicion", "hideCol", "valorVenta");
								ocultarMostrarColumna("tblDatosRendicion", "showCol", "montoBase");
								ocultarMostrarColumna("tblDatosRendicion", "hideCol", "igv");
								ocultarMostrarColumna("tblDatosRendicion", "showCol", "cero");
								ocultarMostrarColumna("tblDatosRendicion", "hideCol", "exoneracionIgv");
								ocultarMostrarColumna("tblDatosRendicion", "showCol", "exoneracionFija");
								ocultarMostrarColumna("tblDatosRendicion", "showCol", "otroGasto");
								ocultarMostrarColumna("tblDatosRendicion", "hideCol", "valorTotal");
								ocultarMostrarColumna("tblDatosRendicion", "showCol", "montoTotal");					
								
							}	
				} 
			
		
	}//COMPROBANTE DEL EXTERIOR
    else if (getValueInputText("selTipoDocumentoComprobante") == "916" ) {

				setTextLabel("lblSustentoLugarReferenciaComprobante", "Referencias:");
				showElement("divDatosComprobantePagoTable");
				disabledElement("txtSustentoLugarReferenciaComprobante");
				disabledElement("txtRucComprobante");
				disabledElement("txtRazonSocialComprobante");
				disabledElement("txtSecuenciaComprobante");
				disabledElement("txtSerieDocumentoComprobante");
				disabledElement("txtNumeroDocumentoComprobante");
				enabledElement("etiquetaFechaDocumentoComprobante");
				enabledElement("selTipoConceptoComprobante");
				disabledElement("txtClasificadorGastoComprobante");
				enabledElement("btnGrabarComprobante");	

				enabledElement("montoBase");
				enabledElement("valorVenta");
				enabledElement("exoneracionIgv");
				enabledElement("otroGasto");
				enabledElement("valorTotal");
				enabledElement("montoTotal");

				ocultarMostrarColumna("tblDatosRendicion", "showCol", "moneda");
				ocultarMostrarColumna("tblDatosRendicion", "hideCol", "valorVenta");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "montoBase");
				ocultarMostrarColumna("tblDatosRendicion", "hideCol", "igv");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "cero");
				ocultarMostrarColumna("tblDatosRendicion", "hideCol", "exoneracionIgv");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "exoneracionFija");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "otroGasto");
				ocultarMostrarColumna("tblDatosRendicion", "hideCol", "valorTotal");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "montoTotal");

	}//BOLETO DE VIAJE
    else if (getValueInputText("selTipoDocumentoComprobante") == "915" ||  getValueInputText("selTipoDocumentoComprobante") == "067") {

				setTextLabel("lblSustentoLugarReferenciaComprobante", "Lugar:");
				hideElement("divDatosComprobantePagoTable");
				enabledElement("txtSustentoLugarReferenciaComprobante");
				if(getValueInputText("tipoDestino")=="01"){
					enabledElement("txtRucComprobante");}
				else if(getValueInputText("tipoDestino")=="02"){
					disabledElement("txtRucComprobante");
				}
				
				disabledElement("txtRazonSocialComprobante");
				disabledElement("txtSecuenciaComprobante");
				enabledElement("txtSerieDocumentoComprobante");
				enabledElement("txtNumeroDocumentoComprobante");
				enabledElement("etiquetaFechaDocumentoComprobante");
				enabledElement("selTipoConceptoComprobante");
				disabledElement("txtClasificadorGastoComprobante");
				enabledElement("btnGrabarComprobante");

				enabledElement("montoBase");
				enabledElement("valorVenta");
				enabledElement("exoneracionIgv");
				enabledElement("otroGasto");
				enabledElement("valorTotal");
				enabledElement("montoTotal");

				ocultarMostrarColumna("tblDatosRendicion", "showCol", "moneda");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "valorVenta");
				ocultarMostrarColumna("tblDatosRendicion", "hideCol", "montoBase");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "igv");
				ocultarMostrarColumna("tblDatosRendicion", "hideCol", "cero");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "exoneracionIgv");
				ocultarMostrarColumna("tblDatosRendicion", "hideCol", "exoneracionFija");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "otroGasto");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "valorTotal");
				ocultarMostrarColumna("tblDatosRendicion", "hideCol", "montoTotal");

		//SELECCIONE
	}else if(getValueInputText("selTipoDocumentoComprobante") == "000"){
		setTextLabel("lblSustentoLugarReferenciaComprobante", "Sustento de cambio de monto:");
		disabledElement("txtRucComprobante");
		disabledElement("txtRazonSocialComprobante");
		disabledElement("txtSecuenciaComprobante");
		disabledElement("txtSerieDocumentoComprobante");
		disabledElement("txtNumeroDocumentoComprobante");
		disabledElement("etiquetaFechaDocumentoComprobante");
		disabledElement("selTipoConceptoComprobante");
		disabledElement("txtClasificadorGastoComprobante");
		disabledElement("txtSustentoLugarReferenciaComprobante");
		disabledElement("btnGrabarComprobante");
		disabledElement("btnGrabarAuxComprobante");
		enabledElement("selTipoDocumentoComprobante");
		disabledElement("montoBase");
		disabledElement("valorVenta");
		disabledElement("exoneracionIgv");
		disabledElement("otroGasto");
		disabledElement("valorTotal");
		disabledElement("montoTotal");
		hideElementByClass("rendicionFechaRendicion");
		disabledElementForClass("alimentacion");
		disabledElementForClass("hospedaje");
		disabledElementForClass("movilidad");
		disabledElementForClass("translado");
		ocultarMostrarColumna("tblDatosRendicion", "showCol", "moneda");
		ocultarMostrarColumna("tblDatosRendicion", "showCol", "valorVenta");
		ocultarMostrarColumna("tblDatosRendicion", "hideCol", "montoBase");
		ocultarMostrarColumna("tblDatosRendicion", "showCol", "igv");
		ocultarMostrarColumna("tblDatosRendicion", "hideCol", "cero");
		ocultarMostrarColumna("tblDatosRendicion", "showCol", "exoneracionIgv");
		ocultarMostrarColumna("tblDatosRendicion", "hideCol", "exoneracionFija");
		ocultarMostrarColumna("tblDatosRendicion", "showCol", "otroGasto");
		ocultarMostrarColumna("tblDatosRendicion", "showCol", "valorTotal");
		ocultarMostrarColumna("tblDatosRendicion", "hideCol", "montoTotal");	
	}
	else {//OTROS		

			$("#divMensajeAdvertenciaComprobante").modal("hide");
				setTextLabel("lblSustentoLugarReferenciaComprobante", "Sustento de cambio de monto:");
				showElement("divDatosRendicionTable");
				showElement("divSustentoLugarReferenciaComprobante");
				showElement("divDatosComprobantePagoTable");
				disabledElement("txtSustentoLugarReferenciaComprobante");
				disabledElement("txtSecuenciaComprobante");
				enabledElement("txtSerieDocumentoComprobante");
				enabledElement("txtNumeroDocumentoComprobante");
				enabledElement("txtRucComprobante");
				enabledElement("selTipoConceptoComprobante");
				enabledElement("btnGrabarComprobante");
				enabledElement("etiquetaFechaDocumentoComprobante");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "moneda");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "valorVenta");
				ocultarMostrarColumna("tblDatosRendicion", "hideCol", "montoBase");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "igv");
				ocultarMostrarColumna("tblDatosRendicion", "hideCol", "cero");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "exoneracionIgv");
				ocultarMostrarColumna("tblDatosRendicion", "hideCol", "exoneracionFija");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "otroGasto");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "valorTotal");
				ocultarMostrarColumna("tblDatosRendicion", "hideCol", "montoTotal");
				enabledElement("montoBase");
				enabledElement("valorVenta");
				enabledElement("exoneracionIgv");
				enabledElement("otroGasto");
				enabledElement("valorTotal");
				enabledElement("montoTotal");

	}
    
    disabledElement("btnGrabarComprobante");
	disabledElement("btnGrabarAuxComprobante");
    disabledElement("alimentacion_undefined");
    disabledElement("hospedaje_undefined");
    disabledElement("movilidad_undefined");
    disabledElement("translado_undefined");
    setHtmlElement("rendicionFechaRendicion_undefined","");
    removeElement("idMensaje");
    hideElement("divErrorRUC");
    hideElement("divErrorNumeroDocumento");
    hideElement("divErrorFechaDocumento");
    hideElement("divErrorSustentoLugar");
    hideElement("divErrorDatosComprobantePago"); 
    hideElement("divErrorDatosComprobantePagoDistrib");
    hideElement("divErrorDatosComprobantePagoxAsignacion");
    
    validaEstadoGeneral = 0;
    resizeTable("tblDatosRendicion");
}


function changeSelTipoConceptoComprobante() {
	var clasificadorGasto = getDataAttributeSelect("selTipoConceptoComprobante", "data-clasificadorgasto");
	var monto = getDataAttributeSelect("selTipoConceptoComprobante", "data-monto");
	setValueInputText("txtClasificadorGastoComprobante", clasificadorGasto);
	var idSelectorConcepto = getValueInputText("selTipoConceptoComprobante");
	
	if($.trim(idSelectorConcepto) != ""){
		if(idSelectorConcepto == "01" || idSelectorConcepto == "12"){
			showElementByClass("rendicionFechaRendicion");
			var estadoSumaGeneralDistribucion = sumaGeneralDistribucion();
			if(estadoSumaGeneralDistribucion==1){
				var indExtDDJJ =  getValueInputText("indExtDDJJ");
				
				if(indExtDDJJ=="0"){
					if (getValueInputText("selTipoDocumentoComprobante") == "907" || getValueInputText("selTipoDocumentoComprobante") == "906"){
						validarMontoxAsignacionDeclaracion();
					}else{
						validarMontoxAsignacion();
					}
				}else if(indExtDDJJ=="1"){
					validarMontoxAsignacion();
				}
			}
			
		}else if(idSelectorConcepto == "00"){
			setValueInputTextClass("alimentacion", "0.00");
			setValueInputTextClass("hospedaje", "0.00");
			setValueInputTextClass("movilidad", "0.00");
			setValueInputTextClass("translado", "0.00");
			setHtmlElementClass("total", "0.00");
			hideElementByClass("rendicionFechaRendicion");
			hideElement("divErrorDatosComprobantePagoDistrib");
			hideElement("divErrorDatosComprobantePago");
			hideElement("divErrorDatosComprobantePagoxAsignacion");
		} else{
				hideElementByClass("rendicionFechaRendicion");
				validarMontoxAsignacion();
		}
		
		if($.trim(idSelectorConcepto) != ""){
			enabledElementForClass("alimentacion");
			enabledElementForClass("hospedaje");
			enabledElementForClass("movilidad");
			enabledElementForClass("translado");
			disabledElement("alimentacion_undefined");
			disabledElement("hospedaje_undefined");
			disabledElement("movilidad_undefined");
			disabledElement("translado_undefined");
		}
		
	}else{
		hideElementByClass("rendicionFechaRendicion");
	}
	
	
	validaFormulario();
}

function callObtenerConceptoPlanillaViaticosToComprobante(parametrosConcepto) {
	
	//setTimeout(function() {
		var tipoConceptoComprobanteSel = $("#selTipoConceptoComprobante");
		tipoConceptoComprobanteSel.empty();
		$.ajax({
			url: contextPathUrl + "/viatico.htm?action=obtenerConceptoPlanillaViaticosToComprobante",
			data: {
				"idPlanViaje": parametrosConcepto.planViajeId
			},
			type: "post",
			dataType: "json",
			cache: false,
			beforeSend: function() {
				//showElement("divLoadingConsultarComision");
			},
			complete: function() {
				//hideElement("divLoadingConsultarComision");
			},
			success: function(result) {
				var conceptoPlanillaViaticosList = result.conceptoPlanillaViaticosList;
				var optionSelect = $("<option></option>").attr("value", "00").attr("data-clasificadorgasto", "").attr("data-monto", "").text("--Seleccione--");
				tipoConceptoComprobanteSel.append(optionSelect);
				if (conceptoPlanillaViaticosList != null && conceptoPlanillaViaticosList.length > 0) {
					for (var i = 0; i < conceptoPlanillaViaticosList.length; i++) {
						var conceptoPlanillaViaticos = conceptoPlanillaViaticosList[i];
						optionSelect = $("<option></option>").attr("value", conceptoPlanillaViaticos.codigoConcepto).attr("data-clasificadorgasto", conceptoPlanillaViaticos.clasificadorGasto).attr("data-monto", conceptoPlanillaViaticos.monto).text(conceptoPlanillaViaticos.descripcionConcepto+" - " +conceptoPlanillaViaticos.monto);
						tipoConceptoComprobanteSel.append(optionSelect);
					}
				}
				else {
					consoleLog("Error callObtenerConceptoPlanillaViaticosToComprobante");
				}
			},
			error: function() {
				consoleLog("Error callObtenerConceptoPlanillaViaticosToComprobante");
			}
		});

}

function callObtenerDocumentoSustentario(parametrosConsulta) {

			var datosRendicionTable = $("#tblDatosRendicion");
			datosRendicionTable.clearGridData();
			var datosComprobantePagoTable = $("#tblDatosComprobantePago");
			datosComprobantePagoTable.clearGridData();
			$.ajax({
				url: contextPathUrl + "/viatico.htm?action=obtenerDocumentoSustentario",
				data: {
					"idPlanViaje": parametrosConsulta.planViajeId,
					"secuencia": parametrosConsulta.secuencial
				},
				type: "post",
				dataType: "json",
				cache: false,
				beforeSend: function() {
					showModalElement("divScreenBlock");
				},
				complete: function() {
					hideModalElement("divScreenBlock");
				},
				success: function(result) {
					if(result.documentoSustentarioVO.mensajeRepuesta == "OK"){						
						consoleLog(result.documentoSustentarioVO);
						//estado de edicion/nuevo (true)/(false)
						setValueInputText("porcentajeDeclaracion",result.documentoSustentarioVO.porcentajeDeclaracion);
						var montoEditarRendicion = result.documentoSustentarioVO.montoTotalRendicion;
						setValueInputText("montoEditarRendicion", montoEditarRendicion);
						/*
						if($.trim(result.documentoSustentarioVO.listaPlanViajeRendicion[0].conceptoId) == "915" || $.trim(result.documentoSustentarioVO.listaPlanViajeRendicion[0].conceptoId) == "067" ){
							montoEditarRendicion = (result.documentoSustentarioVO.listaPlanViajeRendicion[0].montoDocumento).toFixed(2);}		
						*/
						
						var tipoDocumentoComprobanteSel = $("#selTipoDocumentoComprobante");
						tipoDocumentoComprobanteSel.empty();
						var tipoDocumentoList = result.documentoSustentarioVO.tipoDocumentoList;
						var optionSelect = $("<option></option>").attr("value", "000").text("--Seleccione--");
						tipoDocumentoComprobanteSel.append(optionSelect);
						if (tipoDocumentoList != null && tipoDocumentoList.length > 0) {
							for (var i = 0; i < tipoDocumentoList.length; i++) {
								var tipoDocumento = tipoDocumentoList[i];
								optionSelect = $("<option></option>").attr("value", tipoDocumento.codigoTipoDocumento).text(tipoDocumento.descripcionTipoDocumento);
								tipoDocumentoComprobanteSel.append(optionSelect);
							}					
						}				
						else {
							consoleLog("Error callObtenerTipoDocumentoToComprobante");
						}
						
						if(parametrosConsulta.estadoLlamada == "C" || parametrosConsulta.estadoLlamada == "N"){
										var tipoConceptoComprobanteSel = $("#selTipoConceptoComprobante");
										tipoConceptoComprobanteSel.empty();						
										var conceptoPlanillaViaticosList = result.documentoSustentarioVO.planViajeConceptoList;
										var optionSelect = $("<option></option>").attr("value", "00").attr("data-clasificadorgasto", "").attr("data-monto", "").attr("data-montoDeclaracion","").text("--Seleccione--");
										tipoConceptoComprobanteSel.append(optionSelect);
										if (conceptoPlanillaViaticosList != null && conceptoPlanillaViaticosList.length > 0) {
											for (var i = 0; i < conceptoPlanillaViaticosList.length; i++) {
												var conceptoPlanillaViaticos = conceptoPlanillaViaticosList[i];
												optionSelect = $("<option></option>").attr("value", conceptoPlanillaViaticos.conceptoID).attr("data-clasificadorgasto", conceptoPlanillaViaticos.clasificadorGasto).attr("data-montoDeclaracion", conceptoPlanillaViaticos.monto).attr("data-monto", conceptoPlanillaViaticos.montoDevolver).text(
														conceptoPlanillaViaticos.descripcionConcepto + 
														($.trim(conceptoPlanillaViaticos.montoDevolver) == "" ? ""  :   " - "+ $.trim(result.documentoSustentarioVO.moneda)+ " "+(conceptoPlanillaViaticos.montoDevolver).toFixed(2) )  );
												tipoConceptoComprobanteSel.append(optionSelect);
											}
										}
										else {
											consoleLog("Error callObtenerConceptoPlanillaViaticosToComprobante");
										}
						}else if(parametrosConsulta.estadoLlamada == "E"){
							var tipoConceptoComprobanteSel = $("#selTipoConceptoComprobante");
							tipoConceptoComprobanteSel.empty();						
							var conceptoPlanillaViaticosList = result.documentoSustentarioVO.planViajeConceptoList;
							var optionSelect = $("<option></option>").attr("value", "00").attr("data-clasificadorgasto", "").attr("data-monto", "").attr("data-montoDeclaracion","").text("--Seleccione--");
							tipoConceptoComprobanteSel.append(optionSelect);
							
														
							if (conceptoPlanillaViaticosList != null && conceptoPlanillaViaticosList.length > 0) {
								for (var i = 0; i < conceptoPlanillaViaticosList.length; i++) {
									var conceptoPlanillaViaticos = conceptoPlanillaViaticosList[i];
									optionSelect = $("<option></option>").attr("value", conceptoPlanillaViaticos.conceptoID).attr("data-clasificadorgasto", conceptoPlanillaViaticos.clasificadorGasto).attr("data-montoDeclaracion", conceptoPlanillaViaticos.monto).attr("data-monto", conceptoPlanillaViaticos.montoDevolver  + (montoEditarRendicion)).text(conceptoPlanillaViaticos.descripcionConcepto + 
											($.trim(conceptoPlanillaViaticos.montoDevolver) == "" ? ""  :   " - "+ $.trim(result.documentoSustentarioVO.moneda)+ " "+(conceptoPlanillaViaticos.montoDevolver + (montoEditarRendicion)).toFixed(2))											
									);
									tipoConceptoComprobanteSel.append(optionSelect);
								}
							}
							else {
								consoleLog("Error callObtenerConceptoPlanillaViaticosToComprobante");
							}
						}
									
						
						if(result.documentoSustentarioVO.estadoDocumentoSustentario){
							
							initSelectValue("selTipoDocumentoComprobante",result.documentoSustentarioVO.listaPlanViajeRendicion[0].tipoDocumento);
							setValueInputText("txtSecuenciaComprobante", result.documentoSustentarioVO.listaPlanViajeRendicion[0].secuencial);
							setValueInputText("txtRucComprobante", result.documentoSustentarioVO.listaPlanViajeRendicion[0].ruc);
							setValueInputText("txtRazonSocialComprobante", result.documentoSustentarioVO.listaPlanViajeRendicion[0].razoSociPro);					
							setValueInputText("txtSerieDocumentoComprobante", result.documentoSustentarioVO.listaPlanViajeRendicion[0].serie);
							setValueInputText("txtNumeroDocumentoComprobante", result.documentoSustentarioVO.listaPlanViajeRendicion[0].numeroDocumento);
							setValueInputText("etiquetaFechaDocumentoComprobante", result.documentoSustentarioVO.listaPlanViajeRendicion[0].fechaDocumento);
							initSelectValue("selTipoConceptoComprobante", result.documentoSustentarioVO.listaPlanViajeRendicion[0].conceptoId);
							setValueInputText("txtClasificadorGastoComprobante",result.documentoSustentarioVO.listaPlanViajeRendicion[0].clasificadorGasto); 
							setValueInputText("txtSustentoLugarReferenciaComprobante", result.documentoSustentarioVO.listaPlanViajeRendicion[0].lugarGasto);		
							
							setValueInputText("tipoDestino", result.documentoSustentarioVO.planViajeBean.tipoDestino);
							setValueInputText("fechaHoraProgSalida", result.documentoSustentarioVO.planViajeBean.fechaHoraProgSalida);
							setValueInputText("fechaHoraProgRetorno", result.documentoSustentarioVO.planViajeBean.fechaHoraProgRetorno);						
							setValueInputText("fechaHoraEjeSalida", result.documentoSustentarioVO.planViajeBean.fechaHoraEjeSalida);
							setValueInputText("fechaHoraEjeRetorno", result.documentoSustentarioVO.planViajeBean.fechaHoraEjeRetorno);
							setValueInputText("igvActual", result.documentoSustentarioVO.igv);
							setValueInputText("indExtDDJJ", result.documentoSustentarioVO.planViajeBean.indicadorExtDdjj);
							setValueInputText("estadoDDJJ", result.documentoSustentarioVO.estadoDDJJ);							
							
							var datarow = {
									indice: "1",
									moneda: $.trim(result.documentoSustentarioVO.moneda),
									valorVenta: (result.documentoSustentarioVO.listaPlanViajeRendicion[0].valorVenta).toFixed(2),
									montoBase: (result.documentoSustentarioVO.listaPlanViajeRendicion[0].valorVenta).toFixed(2),
									igv: (result.documentoSustentarioVO.listaPlanViajeRendicion[0].montoIgv).toFixed(2),
									exoneracionIgv: result.documentoSustentarioVO.listaExoneracion,
									cero:"0.00",
									otroGasto: (result.documentoSustentarioVO.listaPlanViajeRendicion[0].mtoOtrosGastos).toFixed(2),
									valorTotal: (result.documentoSustentarioVO.listaPlanViajeRendicion[0].montoDocumento).toFixed(2),
									montoTotal: (result.documentoSustentarioVO.listaPlanViajeRendicion[0].montoDocumento).toFixed(2),
									indAfectoIgv: result.documentoSustentarioVO.listaPlanViajeRendicion[0].indAfectoIgv,
								};
							consoleLog("datarow.valorTotal: " + datarow.valorTotal + " datarow.montoTotal: "+ datarow.montoTotal);
							setValueInputText("montoTotalEditar",datarow.valorTotal);
							datosRendicionTable.jqGrid("addRowData", datarow.indice, datarow);
							datosRendicionTable.trigger("reloadGrid");
							initSelectValue("exoneracionIgv",$.trim(result.documentoSustentarioVO.listaPlanViajeRendicion[0].indAfectoIgv));
							
							if(result.documentoSustentarioVO.listaPlanViajeInformeDitrib != null){
								for(i = 0; i< result.documentoSustentarioVO.listaPlanViajeInformeDitrib.length; i++){
									var listaPlanViajeInformeDitrib = result.documentoSustentarioVO.listaPlanViajeInformeDitrib[i];
									var montoAlimentacion = parseFloat(( $.trim(listaPlanViajeInformeDitrib.montoDocumentoAlimentacion) == "" ) ? "0.00" : listaPlanViajeInformeDitrib.montoDocumentoAlimentacion);
									var montoHospedaje = parseFloat(($.trim(listaPlanViajeInformeDitrib.montoDocumentoHospedaje) == "" ) ? "0.00" : listaPlanViajeInformeDitrib.montoDocumentoHospedaje);
									var montoMovilidad = parseFloat(($.trim(listaPlanViajeInformeDitrib.montoDocumentoMovilidad) == "" ) ? "0.00" : listaPlanViajeInformeDitrib.montoDocumentoMovilidad);
									var montoTranslado = parseFloat(($.trim(listaPlanViajeInformeDitrib.montoDocumentoTranslado) == "" ) ? "0.00" : listaPlanViajeInformeDitrib.montoDocumentoTranslado);
									var montoRendicionXFecha = parseFloat(($.trim(listaPlanViajeInformeDitrib.montoDestionFecha) == "" ) ? "0.00" : listaPlanViajeInformeDitrib.montoDestionFecha);
									var dataRowComprobantePago = {
											indice: i,
											fechaViatico: listaPlanViajeInformeDitrib.fecViatico,
											alimentacion: montoAlimentacion.toFixed(2),
											hospedaje: montoHospedaje.toFixed(2),
											movilidad: montoMovilidad.toFixed(2),
											translado: montoTranslado.toFixed(2),
											total: (montoAlimentacion + montoHospedaje + montoMovilidad + montoTranslado).toFixed(2),
											fechaDDMMYYYY : $.trim(listaPlanViajeInformeDitrib.fecViatico).replace("/","").replace("/",""),
											rendicionFechaRendicion : $.trim(result.documentoSustentarioVO.moneda) + " " +(montoRendicionXFecha + montoAlimentacion + montoHospedaje + montoMovilidad + montoTranslado).toFixed(2),
											rendicionFechaRendicionSinFormato: (montoRendicionXFecha + montoAlimentacion + montoHospedaje + montoMovilidad + montoTranslado).toFixed(2)
										};	
									datosComprobantePagoTable.jqGrid("addRowData", dataRowComprobantePago.indice, dataRowComprobantePago);
								}						
							
							datosComprobantePagoTable.trigger("reloadGrid");
							}							
							
							if(parametrosConsulta.estadoLlamada == "C"){
								selTipoDocumentoComprobante();
								bloqueoParametrosDocumentoComprobante();
								sumaValoresIteracionFooter();
							}else if(parametrosConsulta.estadoLlamada == "E"){
								selTipoDocumentoComprobante();
								bloqueoEdicionDocumentoSustentatorio();
								sumaValoresIteracionFooter();								
							}							
						}			
					else{
						
						setValueInputText("tipoDestino", result.documentoSustentarioVO.planViajeBean.tipoDestino);
						setValueInputText("fechaHoraProgSalida", result.documentoSustentarioVO.planViajeBean.fechaHoraProgSalida);
						setValueInputText("fechaHoraProgRetorno", result.documentoSustentarioVO.planViajeBean.fechaHoraProgRetorno);						
						setValueInputText("fechaHoraEjeSalida", result.documentoSustentarioVO.planViajeBean.fechaHoraEjeSalida);
						setValueInputText("fechaHoraEjeRetorno", result.documentoSustentarioVO.planViajeBean.fechaHoraEjeRetorno);
						setValueInputText("igvActual", result.documentoSustentarioVO.igv);
						setValueInputText("indExtDDJJ", result.documentoSustentarioVO.planViajeBean.indicadorExtDdjj);
						setValueInputText("estadoDDJJ", result.documentoSustentarioVO.estadoDDJJ);
						setValueInputText("montoTotalRendicion", result.documentoSustentarioVO.montoTotalRendicion);						
						
						var datarow = {
								indice: "1",
								moneda: $.trim(result.documentoSustentarioVO.moneda),
								valorVenta: "0.00",
								montoBase:"0.00",
								igv:"0.00",
								exoneracionIgv: result.documentoSustentarioVO.listaExoneracion,
								cero:"0.00",
								otroGasto:"0.00",
								valorTotal:"0.00",
								montoTotal:"0.00"							
							};
						datosRendicionTable.jqGrid("addRowData", datarow.indice, datarow);
						datosRendicionTable.trigger("reloadGrid");
						
						for(i = 0; i< result.documentoSustentarioVO.listaPlanViajeInformeDitrib.length; i++){
							var listaPlanViajeInformeDitrib = result.documentoSustentarioVO.listaPlanViajeInformeDitrib[i];
							var montoAlimentacion = parseFloat(( $.trim(listaPlanViajeInformeDitrib.montoDocumentoAlimentacion) == "" ) ? "0.00" : listaPlanViajeInformeDitrib.montoDocumentoAlimentacion);
							var montoHospedaje = parseFloat(($.trim(listaPlanViajeInformeDitrib.montoDocumentoHospedaje) == "" ) ? "0.00" : listaPlanViajeInformeDitrib.montoDocumentoHospedaje);
							var montoMovilidad = parseFloat(($.trim(listaPlanViajeInformeDitrib.montoDocumentoMovilidad) == "" ) ? "0.00" : listaPlanViajeInformeDitrib.montoDocumentoMovilidad);
							var montoTranslado = parseFloat(($.trim(listaPlanViajeInformeDitrib.montoDocumentoTranslado) == "" ) ? "0.00" : listaPlanViajeInformeDitrib.montoDocumentoTranslado);
							var montoRendicionXFecha = parseFloat(($.trim(listaPlanViajeInformeDitrib.montoDestionFecha) == "" ) ? "0.00" : listaPlanViajeInformeDitrib.montoDestionFecha);
							var dataRowComprobantePago = {
									indice: i,
									fechaViatico: listaPlanViajeInformeDitrib.fecViatico,
									alimentacion: montoAlimentacion.toFixed(2),
									hospedaje: montoHospedaje.toFixed(2),
									movilidad: montoMovilidad.toFixed(2),
									translado: montoTranslado.toFixed(2),
									total: (montoAlimentacion + montoHospedaje + montoMovilidad + montoTranslado).toFixed(2),
									fechaDDMMYYYY : $.trim(listaPlanViajeInformeDitrib.fecViatico).replace("/","").replace("/",""),
									rendicionFechaRendicion : result.documentoSustentarioVO.moneda + " " +(montoRendicionXFecha + montoAlimentacion + montoHospedaje + montoMovilidad + montoTranslado).toFixed(2),
									rendicionFechaRendicionSinFormato: (montoRendicionXFecha + montoAlimentacion + montoHospedaje + montoMovilidad + montoTranslado).toFixed(2)
							};	
							datosComprobantePagoTable.jqGrid("addRowData", dataRowComprobantePago.indice, dataRowComprobantePago);
						}						
						
						datosComprobantePagoTable.trigger("reloadGrid");							
						selTipoDocumentoComprobante();
						
					}						
						
					}					
				},
				error: function() {
					consoleLog("Error callObtenerConceptoPlanillaViaticosToComprobante");
				}
			});
}

function clickBtnGrabarComprobante(){
	var tipoConcepto = getValueInputText("selTipoConceptoComprobante");
	var clasificadorGasto =  getValueInputText("txtClasificadorGastoComprobante");
	var ruc =  getValueInputText("txtRucComprobante");
	var numeroDocumento =  getValueInputText("txtNumeroDocumentoComprobante");
	var serie =  getValueInputText("txtSerieDocumentoComprobante");
	var fecha =  getValueInputText("etiquetaFechaDocumentoComprobante");	
	var valorVenta = getValueInputText("valorVenta");
	var valorTotal = getValueInputText("valorTotal");
	var montoBase = getValueInputText("montoBase");
	var montoTotal = getValueInputText("montoTotal");
	var tipoDestino = getValueInputText("tipoDestino");	
	var sustentoLugar = getValueInputText("txtSustentoLugarReferenciaComprobante");
	
	var tipoDocumentoComprobante = getValueInputText("selTipoDocumentoComprobante");
	var fechaDocumentoComprobante = getValueInputText("etiquetaFechaDocumentoComprobante");
	var fechaHoraProgSalida = getValueInputText("fechaHoraProgSalida");
	var fechaHoraProgRetorno = getValueInputText("fechaHoraProgRetorno");
	var fechaHoraEjeSalida = getValueInputText("fechaHoraEjeSalida");
	var fechaHoraEjeRetorno = getValueInputText("fechaHoraEjeRetorno");
	var tipoDestino = getValueInputText("tipoDestino");
	var indExtDDJJ = getValueInputText("indExtDDJJ");
	var estadoDDJJ = getValueInputText("estadoDDJJ");
	var saldoRendir = parametros.saldoRendir;
	
	var total_undefined = getValueText("total_undefined");
		total_undefined = total_undefined.replace(/,/g , '');
		total_undefined  = parseFloat(total_undefined);	
    
	var valorTotal = getValueInputText("valorTotal");
	 	valorTotal = valorTotal.replace(/,/g , '');
	 	valorTotal  = parseFloat(valorTotal);
	 	 
	var montoTotal = getValueInputText("montoTotal");
		montoTotal = montoTotal.replace(/,/g , '');
		montoTotal  = parseFloat(montoTotal);
				
		if (getValueInputText("selTipoDocumentoComprobante") == "907" || getValueInputText("selTipoDocumentoComprobante") == "906"){
			
			if(getValueInputText("selTipoDocumentoComprobante") == "907" ){
				if($.trim(clasificadorGasto)==""){
					setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.concepto);
					$("#divMensajeAdvertenciaComprobante").modal("show");
				}else if ($.trim(montoTotal)=="0.00"){	
					setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.montoTotalMayorCero);
					$("#divMensajeAdvertenciaComprobante").modal("show");
				}else if (total_undefined > montoTotal){
			    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.distribuido);
					$("#divMensajeAdvertenciaComprobante").modal("show");
			    }else if(total_undefined==0){
			    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.messageTotalDistribucion);
					$("#divMensajeAdvertenciaComprobante").modal("show");
			    }else{
			    	setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
	    			$("#divMensajeConfirmacionComprobante").modal("show");
			    }
				
			}else if(getValueInputText("selTipoDocumentoComprobante") == "906" ){
				if($.trim(clasificadorGasto)==""){
	    			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.concepto);
	    			$("#divMensajeAdvertenciaComprobante").modal("show");
	    		}else if ($.trim(montoTotal)=="0.00"){		
	    			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.montoTotalMayorCero);
	    			$("#divMensajeAdvertenciaComprobante").modal("show");
	    		}else if (total_undefined > montoTotal){
	    	    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.distribuido);
	    			$("#divMensajeAdvertenciaComprobante").modal("show");  	    
	    	    	
	    	    }else if(total_undefined==0){
			    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.messageTotalDistribucion);
					$("#divMensajeAdvertenciaComprobante").modal("show");
			    }else{
			    	setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
	    			$("#divMensajeConfirmacionComprobante").modal("show");
			    }
			}
			
		}else if (getValueInputText("selTipoDocumentoComprobante") == "916") {
			if($.trim(clasificadorGasto)==""){
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.concepto);
				$("#divMensajeAdvertenciaComprobante").modal("show");
			}else if ($.trim(montoTotal)=="0.00"){		
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.montoTotalMayorCero);
				$("#divMensajeAdvertenciaComprobante").modal("show");
			}else if (total_undefined > montoTotal){
		    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.distribuido);
				$("#divMensajeAdvertenciaComprobante").modal("show");
		    }else if(total_undefined==0){
		    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.messageTotalDistribucion);
				$("#divMensajeAdvertenciaComprobante").modal("show");
		    } else{
		    	setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
    			$("#divMensajeConfirmacionComprobante").modal("show");
		    }
		}else if (getValueInputText("selTipoDocumentoComprobante") == "915" ||  getValueInputText("selTipoDocumentoComprobante") == "067") {
			if($.trim(clasificadorGasto)==""){
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.concepto);
				$("#divMensajeAdvertenciaComprobante").modal("show");
			}else if ($.trim(montoTotal)=="0.00"){		
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.mayorCeroTotal);
				$("#divMensajeAdvertenciaComprobante").modal("show");
			}if ($.trim(sustentoLugar)==""){
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.sustentoLugar);
				$("#divMensajeAdvertenciaComprobante").modal("show");
			}else if (total_undefined > montoTotal){
		    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.distribuido);
				$("#divMensajeAdvertenciaComprobante").modal("show");
		    }else{
		    	setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
    			$("#divMensajeConfirmacionComprobante").modal("show");
		    }
		}else if (getValueInputText("selTipoDocumentoComprobante") == "000"){
			
		}else{
			if($.trim(serie)==""){
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.serie);
				$("#divMensajeAdvertenciaComprobante").modal("show");
			}else if($.trim(numeroDocumento)==""){
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.numeroDocumento);
				$("#divMensajeAdvertenciaComprobante").modal("show");
			}else if($.trim(clasificadorGasto)==""){
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.concepto);
				$("#divMensajeAdvertenciaComprobante").modal("show");
			}else if ($.trim(valorTotal)=="0.00"){		
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.mayorCeroTotal);
				$("#divMensajeAdvertenciaComprobante").modal("show");
			}else if (total_undefined > valorTotal){
		    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.distribuido);
				$("#divMensajeAdvertenciaComprobante").modal("show");
		    }else if(total_undefined==0){
		    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.messageTotalDistribucion);
				$("#divMensajeAdvertenciaComprobante").modal("show");
		    }else{
		    	setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
    			$("#divMensajeConfirmacionComprobante").modal("show");
		    }
		}
		
		
		
	
}

/*
function clickBtnGrabarComprobanteCambair(){
	//callGrabarEditarComprobantePago(parametros);
	//DECLARACION JURADA - COMPROBANTE DE PAGO / DECLARACION JURADA - VIATICOS
	
	
	var tipoConcepto = getValueInputText("selTipoConceptoComprobante");
	var clasificadorGasto =  getValueInputText("txtClasificadorGastoComprobante");
	var ruc =  getValueInputText("txtRucComprobante");
	var numeroDocumento =  getValueInputText("txtNumeroDocumentoComprobante");
	var serie =  getValueInputText("txtSerieDocumentoComprobante");
	var fecha =  getValueInputText("etiquetaFechaDocumentoComprobante");	
	var valorVenta = getValueInputText("valorVenta");
	var valorTotal = getValueInputText("valorTotal");
	var montoBase = getValueInputText("montoBase");
	var montoTotal = getValueInputText("montoTotal");
	var tipoDestino = getValueInputText("tipoDestino");	
	var sustentoLugar = getValueInputText("txtSustentoLugarReferenciaComprobante");
	
	var tipoDocumentoComprobante = getValueInputText("selTipoDocumentoComprobante");
	var fechaDocumentoComprobante = getValueInputText("etiquetaFechaDocumentoComprobante");
	var fechaHoraProgSalida = getValueInputText("fechaHoraProgSalida");
	var fechaHoraProgRetorno = getValueInputText("fechaHoraProgRetorno");
	var fechaHoraEjeSalida = getValueInputText("fechaHoraEjeSalida");
	var fechaHoraEjeRetorno = getValueInputText("fechaHoraEjeRetorno");
	var tipoDestino = getValueInputText("tipoDestino");
	var indExtDDJJ = getValueInputText("indExtDDJJ");
	var montoTotalRendicion = getValueInputText("montoTotalRendicion");
	var estadoDDJJ = getValueInputText("estadoDDJJ");
	var saldoRendir = parametros.saldoRendir;
	
	
	var total_undefined = getValueText("total_undefined");
	total_undefined = total_undefined.replace(/,/g , '');
	total_undefined  = parseFloat(total_undefined);	
    
	 var valorTotal = getValueInputText("valorTotal");
	 	 valorTotal = valorTotal.replace(/,/g , '');
	 	 valorTotal  = parseFloat(valorTotal);
	 	 
	 var montoTotal = getValueInputText("montoTotal");
	 montoTotal = montoTotal.replace(/,/g , '');
	 montoTotal  = parseFloat(montoTotal);
	
	consoleLog("total_undefined: --> "+total_undefined);
	 
    if (getValueInputText("selTipoDocumentoComprobante") == "907" || getValueInputText("selTipoDocumentoComprobante") == "906"){
 	
    	if(getValueInputText("selTipoDocumentoComprobante") == "907"){
    		
		    	if($.trim(clasificadorGasto)==""){
					setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.concepto);
					$("#divMensajeAdvertenciaComprobante").modal("show");
				}else if ($.trim(montoTotal)=="0.00"){		
					setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.montoTotalMayorCero);
					$("#divMensajeAdvertenciaComprobante").modal("show");
				}else if (total_undefined > montoTotal){
			    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.distribuido);
					$("#divMensajeAdvertenciaComprobante").modal("show");
			    }else if(total_undefined==0){
			    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.messageTotalDistribucion);
					$("#divMensajeAdvertenciaComprobante").modal("show");
			    } else if(validaEstadoFechaGeneral == 0 || $.trim(fecha) == "" ){	
					
					if(tipoDestino == "01"){
						var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
						var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
						var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
						consoleLog("fechaInicio: " + fechaInicio.getTime()+ " fechaDocumentoComprobante: " + fechaDocumentoComprobante.getTime());
						if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
							consoleLog("angel");
							var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteDeclaracion;
							//showMessageErrorComprobante("etiquetaErrorFechaDocumento", mensajeReplaceFin,"divErrorFechaDocumento");
							setHtmlElement("spaMensajeAdvertenciaComprobante", mensajeReplaceFin);
							$("#divMensajeAdvertenciaComprobante").modal("show");	
						}
					
						var mensajeAdvertencia = "";
						if(indExtDDJJ == "0"){
							saldoRendir = parseFloat(saldoRendir) * 0.3;
							mensajeAdvertencia = (errorMessageRegistrarComprobante.porcentajeDDJJ).replace("MONEDA",getValueText("monedaRendicion")).replace("PORCENTAJEXMONTO",parseFloat(montoTotal));
							
						}
						
						if(parseFloat(montoTotal) > saldoRendir){
							
							setHtmlElement("spaMensajeAdvertenciaComprobante", mensajeAdvertencia);
							$("#divMensajeAdvertenciaComprobante").modal("show");
						}else{
							setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
							$("#divMensajeConfirmacionComprobante").modal("show");
						}
						
						
					}else if (tipoDestino == "02"){
						var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
						var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
						var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
							if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
								var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteDeclaracion;								
								setHtmlElement("spaMensajeAdvertenciaComprobante", mensajeReplaceFin);
								$("#divMensajeAdvertenciaComprobante").modal("show");	
							}
							
						
							var mensajeAdvertencia = "";
							if(indExtDDJJ == "0"){
								saldoRendir = parseFloat(saldoRendir) * 0.2;
								mensajeAdvertencia = (errorMessageRegistrarComprobante.porcentajeDDJJ).replace("MONEDA",getValueText("monedaRendicion")).replace("PORCENTAJEXMONTO",parseFloat(montoTotal));
							}
							else if(indExtDDJJ == "1"){
								saldoRendir = parseFloat(saldoRendir);
								mensajeAdvertencia = (errorMessageRegistrarComprobante.mayorSaldoRendir).replace("MONEDA",getValueText("monedaRendicion")).replace("MONTO_REGISTRADO",parseFloat(montoTotal));
							}
							
							if(parseFloat(montoTotal) > saldoRendir){
								setHtmlElement("spaMensajeAdvertenciaComprobante", mensajeAdvertencia);
								
								$("#divMensajeAdvertenciaComprobante").modal("show");	
							}else{
								setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
								$("#divMensajeConfirmacionComprobante").modal("show");
							}
							
							
					}			
					
				}else{
					setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
					$("#divMensajeConfirmacionComprobante").modal("show");
				}
	    	
    	}else if(getValueInputText("selTipoDocumentoComprobante") == "906"){
    		if($.trim(clasificadorGasto)==""){
    			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.concepto);
    			$("#divMensajeAdvertenciaComprobante").modal("show");
    		}else if ($.trim(montoTotal)=="0.00"){		
    			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.montoTotalMayorCero);
    			$("#divMensajeAdvertenciaComprobante").modal("show");
    		}else if (total_undefined > montoTotal){
    	    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.distribuido);
    			$("#divMensajeAdvertenciaComprobante").modal("show");  	    
    	    	
    	    }else if(total_undefined==0){
		    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.messageTotalDistribucion);
				$("#divMensajeAdvertenciaComprobante").modal("show");
		    } else if(validaEstadoFechaGeneral == 0 || $.trim(fecha) == "" ){	
    			
    			if(tipoDestino == "01"){
    				var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
    				var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
    				var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
    				
    				if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
    					var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteDeclaracion;
    					showMessageErrorComprobante("etiquetaErrorFechaDocumento", mensajeReplaceFin,"divErrorFechaDocumento");
    					setHtmlElement("spaMensajeAdvertenciaComprobante", mensajeReplaceFin);
    					$("#divMensajeAdvertenciaComprobante").modal("show");
    				}else{
    					setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
    					$("#divMensajeConfirmacionComprobante").modal("show");
    				}
    				   				
    				
    			}else if (tipoDestino == "02"){
    				
    				var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
    				var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
    				var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
    					if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
    						var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteDeclaracion;	    						
    						setHtmlElement("spaMensajeAdvertenciaComprobante", mensajeReplaceFin);
    						$("#divMensajeAdvertenciaComprobante").modal("show");
    					} else{
    						setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
    						$("#divMensajeConfirmacionComprobante").modal("show");
    					} 					
    			}    			
    		} 	    
    	    else{   	    	 	  
    	
    	    	if(tipoDestino == "01"){
    	    		var mensajeAdvertencia = "";
    				saldoRendir = parseFloat(saldoRendir) * 0.3;
    				if(parseFloat(montoTotalRendicion)+ parseFloat(montoTotal) > parseFloat(saldoRendir)){
    					mensajeAdvertencia = (errorMessageRegistrarComprobante.DDJJComprobantePago).replace("PORCENTAJE","30%");
    					setHtmlElement("spaMensajeAdvertenciaComprobante", mensajeAdvertencia);
    					$("#divMensajeAdvertenciaComprobante").modal("show");
    				}else {
    					setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
    	    			$("#divMensajeConfirmacionComprobante").modal("show");
    				} 
    				
    	    	}else if (tipoDestino == "02"){
    	    		var mensajeAdvertencia = "";
					saldoRendir = parseFloat(saldoRendir) * 0.2;
					
					if(parseFloat(montoTotalRendicion)+ montoTotal > parseFloat(saldoRendir)){
    					mensajeAdvertencia = (errorMessageRegistrarComprobante.DDJJComprobantePago).replace("PORCENTAJE","20%");
    					setHtmlElement("spaMensajeAdvertenciaComprobante", mensajeAdvertencia);
    					$("#divMensajeAdvertenciaComprobante").modal("show");
    				}else {
    					setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
    	    			$("#divMensajeConfirmacionComprobante").modal("show");
    				}   	
    	    	}   			
    		}
    	}
    	
    }//COMPROBANTE DEL EXTERIOR
    else if (getValueInputText("selTipoDocumentoComprobante") == "916") {
    	if($.trim(clasificadorGasto)==""){
			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.concepto);
			$("#divMensajeAdvertenciaComprobante").modal("show");
		}else if ($.trim(montoTotal)=="0.00"){		
			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.montoTotalMayorCero);
			$("#divMensajeAdvertenciaComprobante").modal("show");
		}else if (total_undefined > montoTotal){
	    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.distribuido);
			$("#divMensajeAdvertenciaComprobante").modal("show");
	    }else if(total_undefined==0){
	    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.messageTotalDistribucion);
			$("#divMensajeAdvertenciaComprobante").modal("show");
	    } else if(validaEstadoFechaGeneral == 0 || $.trim(fecha) == "" ){	
			
			if(tipoDestino == "01"){
				var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
				var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
				var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
				
				if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
					var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteDeclaracion;
					//showMessageErrorComprobante("etiquetaErrorFechaDocumento", mensajeReplaceFin,"divErrorFechaDocumento");
					setHtmlElement("spaMensajeAdvertenciaComprobante", mensajeReplaceFin);
					$("#divMensajeAdvertenciaComprobante").modal("show");	
				}else{
					setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
					$("#divMensajeConfirmacionComprobante").modal("show");
				}
			}else if (tipoDestino == "02"){
				var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
				var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
				var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
					if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
						var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteDeclaracion;				
						
						setHtmlElement("spaMensajeAdvertenciaComprobante", mensajeReplaceFin);
						$("#divMensajeAdvertenciaComprobante").modal("show");	
					}else{
						setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
						$("#divMensajeConfirmacionComprobante").modal("show");
					}
			}			
						
			
		}else{
			setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
			$("#divMensajeConfirmacionComprobante").modal("show");
		}
    }//BOLETO DE VIAJE
    else if (getValueInputText("selTipoDocumentoComprobante") == "915") {
    	
    	if($.trim(clasificadorGasto)==""){
			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.concepto);
			$("#divMensajeAdvertenciaComprobante").modal("show");
		}else if ($.trim(montoTotal)=="0.00"){		
			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.mayorCeroTotal);
			$("#divMensajeAdvertenciaComprobante").modal("show");
		}if ($.trim(sustentoLugar)==""){
			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.sustentoLugar);
			$("#divMensajeAdvertenciaComprobante").modal("show");
		}else if (total_undefined > montoTotal){
	    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.distribuido);
			$("#divMensajeAdvertenciaComprobante").modal("show");
	    }else if(validaEstadoFechaGeneral == 0 || $.trim(fecha) == "" ){					
			
			if(tipoDestino == "01"){
				var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
				var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
				var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
				if (fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
					var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteBoletoViaje;
					setHtmlElement("spaMensajeAdvertenciaComprobante", mensajeReplaceFin);
					$("#divMensajeAdvertenciaComprobante").modal("show");	
				}else{
					setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
					$("#divMensajeConfirmacionComprobante").modal("show");
				}
			}else if (tipoDestino == "02"){
				var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
				var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
				var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
					if (fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
						var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteBoletoViaje;				
						setHtmlElement("spaMensajeAdvertenciaComprobante", mensajeReplaceFin);
						$("#divMensajeAdvertenciaComprobante").modal("show");	
					}else{
						setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
						$("#divMensajeConfirmacionComprobante").modal("show");
					}
			}			
						
			
		}else {
			setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
			$("#divMensajeConfirmacionComprobante").modal("show");
		}
    	
    	
    }//SELECCIONE
	else if(getValueInputText("selTipoDocumentoComprobante") == "000"){
	
		
	}
	else {//OTROS
		if($.trim(serie)==""){
			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.serie);
			$("#divMensajeAdvertenciaComprobante").modal("show");
		}
		else if($.trim(numeroDocumento)==""){
			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.numeroDocumento);
			$("#divMensajeAdvertenciaComprobante").modal("show");
		}else if($.trim(clasificadorGasto)==""){
			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.concepto);
			$("#divMensajeAdvertenciaComprobante").modal("show");
		}else if ($.trim(valorTotal)=="0.00"){		
			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.mayorCeroTotal);
			$("#divMensajeAdvertenciaComprobante").modal("show");
		}else if (total_undefined > valorTotal){
	    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.distribuido);
			$("#divMensajeAdvertenciaComprobante").modal("show");
	    }else if(total_undefined==0){
	    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.messageTotalDistribucion);
			$("#divMensajeAdvertenciaComprobante").modal("show");
	    } else if(validaEstadoFechaGeneral == 0 || $.trim(fecha) == "" ){					
			if(tipoDestino == "01"){
				var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
				var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
				var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
				if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime() || fechaFin.getTime() < fechaDocumentoComprobante.getTime()){
					var mensajeReplaceOne = (errorMessageRegistrarComprobante.fechaComprobanteOtros).replace("fechaInicio", fechaHoraProgSalida);
					var mensajeReplaceFin = mensajeReplaceOne.replace("fechaFin", fechaHoraProgRetorno);					
					setHtmlElement("spaMensajeAdvertenciaComprobante", mensajeReplaceFin);
					$("#divMensajeAdvertenciaComprobante").modal("show");
				}	else{
					setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
					$("#divMensajeConfirmacionComprobante").modal("show");
				}			
			}else if (tipoDestino == "02"){
				var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
				var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
				var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
					if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime() || fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
						var mensajeReplaceOne = (errorMessageRegistrarComprobante.fechaComprobanteOtros).replace("fechaInicio", fechaHoraEjeSalida);
						var mensajeReplaceFin = mensajeReplaceOne.replace("fechaFin", fechaHoraEjeRetorno);
						setHtmlElement("spaMensajeAdvertenciaComprobante", mensajeReplaceFin);
						$("#divMensajeAdvertenciaComprobante").modal("show");
					}else{
						setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
						$("#divMensajeConfirmacionComprobante").modal("show");
					}	
			}				
			
				
			
		}else{
			setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
			$("#divMensajeConfirmacionComprobante").modal("show");
		}
	}
    
    //setHtmlElement("spaMensajeConfirmacionTitulo", errorMessageRegistrarComprobante.mensajeConfirmacion);
	//$("#divMensajeConfirmacion").modal("show");
    
}*/
//SI actualizar
function clickBtnGrabarAuxComprobante(){
	//callGrabarEditarComprobantePago(parametros);
	//DECLARACION JURADA - COMPROBANTE DE PAGO / DECLARACION JURADA - VIATICOS
	
	
	var tipoConcepto = getValueInputText("selTipoConceptoComprobante");
	var clasificadorGasto =  getValueInputText("txtClasificadorGastoComprobante");
	var ruc =  getValueInputText("txtRucComprobante");
	var numeroDocumento =  getValueInputText("txtNumeroDocumentoComprobante");
	var serie =  getValueInputText("txtSerieDocumentoComprobante");
	var fecha =  getValueInputText("etiquetaFechaDocumentoComprobante");	
	var valorVenta = getValueInputText("valorVenta");
	var valorTotal = getValueInputText("valorTotal");
	var montoBase = getValueInputText("montoBase");
	var montoTotal = getValueInputText("montoTotal");
	var tipoDestino = getValueInputText("tipoDestino");	
	var sustentoLugar = getValueInputText("txtSustentoLugarReferenciaComprobante");
	
	var tipoDocumentoComprobante = getValueInputText("selTipoDocumentoComprobante");
	var fechaDocumentoComprobante = getValueInputText("etiquetaFechaDocumentoComprobante");
	var fechaHoraProgSalida = getValueInputText("fechaHoraProgSalida");
	var fechaHoraProgRetorno = getValueInputText("fechaHoraProgRetorno");
	var fechaHoraEjeSalida = getValueInputText("fechaHoraEjeSalida");
	var fechaHoraEjeRetorno = getValueInputText("fechaHoraEjeRetorno");
	var tipoDestino = getValueInputText("tipoDestino");
	
	
	var total_undefined = getValueText("total_undefined");
	total_undefined = total_undefined.replace(/,/g , '');
	total_undefined  = parseFloat(total_undefined);	
    
	 var valorTotal = getValueInputText("valorTotal");
	 	 valorTotal = valorTotal.replace(/,/g , '');
	 	 valorTotal  = parseFloat(valorTotal);
	 	 
	 var montoTotal = getValueInputText("montoTotal");
	 montoTotal = montoTotal.replace(/,/g , '');
	 montoTotal  = parseFloat(montoTotal);
	
    if (getValueInputText("selTipoDocumentoComprobante") == "907" || getValueInputText("selTipoDocumentoComprobante") == "906") {
 	
    	if($.trim(clasificadorGasto)==""){
			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.concepto);
			$("#divMensajeAdvertenciaComprobante").modal("show");
		}else if ($.trim(montoTotal)=="0.00"){		
			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.montoTotalMayorCero);
			$("#divMensajeAdvertenciaComprobante").modal("show");
		}else if (total_undefined > montoTotal){
	    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.distribuido);
			$("#divMensajeAdvertenciaComprobante").modal("show");
	    }else if(validaEstadoFechaGeneral == 0 || $.trim(fecha) == "" ){	
			
			if(tipoDestino == "01"){
				var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
				var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
				var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
				
				if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
					var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteDeclaracion;
					showMessageErrorComprobante("etiquetaErrorFechaDocumento", mensajeReplaceFin,"divErrorFechaDocumento");
					setHtmlElement("spaMensajeAdvertenciaComprobante", mensajeReplaceFin);
				}
			}else if (tipoDestino == "02"){
				var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
				var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
				var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
					if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
						var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteDeclaracion;				
						
						setHtmlElement("spaMensajeAdvertenciaComprobante", mensajeReplaceFin);
					}
			}			
			$("#divMensajeAdvertenciaComprobante").modal("show");				
			
		}else{
			setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
			$("#divMensajeConfirmacionComprobante").modal("show");
		}
    	
    	
    }//COMPROBANTE DEL EXTERIOR
    else if (getValueInputText("selTipoDocumentoComprobante") == "916") {
    	if($.trim(clasificadorGasto)==""){
			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.concepto);
			$("#divMensajeAdvertenciaComprobante").modal("show");
		}else if ($.trim(montoTotal)=="0.00"){		
			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.montoTotalMayorCero);
			$("#divMensajeAdvertenciaComprobante").modal("show");
		}else if (total_undefined > montoTotal){
	    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.distribuido);
			$("#divMensajeAdvertenciaComprobante").modal("show");
	    }else if(validaEstadoFechaGeneral == 0 || $.trim(fecha) == "" ){	
			
			if(tipoDestino == "01"){
				var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
				var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
				var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
				
				if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
					var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteDeclaracion;
					showMessageErrorComprobante("etiquetaErrorFechaDocumento", mensajeReplaceFin,"divErrorFechaDocumento");
					setHtmlElement("spaMensajeAdvertenciaComprobante", mensajeReplaceFin);
				}
			}else if (tipoDestino == "02"){
				var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
				var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
				var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
					if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
						var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteDeclaracion;				
						
						setHtmlElement("spaMensajeAdvertenciaComprobante", mensajeReplaceFin);
					}
			}			
			$("#divMensajeAdvertenciaComprobante").modal("show");				
			
		}else{
			setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
			$("#divMensajeConfirmacionComprobante").modal("show");
		}
    }//BOLETO DE VIAJE
    else if (getValueInputText("selTipoDocumentoComprobante") == "915" ||  getValueInputText("selTipoDocumentoComprobante") == "067") {
    	
    	if($.trim(clasificadorGasto)==""){
			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.concepto);
			$("#divMensajeAdvertenciaComprobante").modal("show");
		}else if ($.trim(montoTotal)=="0.00"){		
			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.mayorCeroTotal);
			$("#divMensajeAdvertenciaComprobante").modal("show");
		}if ($.trim(sustentoLugar)==""){
			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.sustentoLugar);
			$("#divMensajeAdvertenciaComprobante").modal("show");
		}else if(validaEstadoFechaGeneral == 0 || $.trim(fecha) == "" ){					
			
			if(tipoDestino == "01"){
				var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
				var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
				var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
				if (fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
					var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteBoletoViaje;
					setHtmlElement("spaMensajeAdvertenciaComprobante", mensajeReplaceFin);
				}
			}else if (tipoDestino == "02"){
				var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
				var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
				var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
					if (fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
						var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteBoletoViaje;				
						setHtmlElement("spaMensajeAdvertenciaComprobante", mensajeReplaceFin);
					}
			}			
			$("#divMensajeAdvertenciaComprobante").modal("show");				
			
		}else{
			setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
			$("#divMensajeConfirmacionComprobante").modal("show");
		}
    	
    	
    }//SELECCIONE
	else if(getValueInputText("selTipoDocumentoComprobante") == "000"){		
	}
	else {//OTROS
		if($.trim(serie)==""){
			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.serie);
			$("#divMensajeAdvertenciaComprobante").modal("show");
		}
		else if($.trim(numeroDocumento)==""){
			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.numeroDocumento);
			$("#divMensajeAdvertenciaComprobante").modal("show");
		}else if($.trim(clasificadorGasto)==""){
			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.concepto);
			$("#divMensajeAdvertenciaComprobante").modal("show");
		}else if ($.trim(valorTotal)=="0.00"){		
			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.mayorCeroTotal);
			$("#divMensajeAdvertenciaComprobante").modal("show");
		}else if(validaEstadoFechaGeneral == 0 || $.trim(fecha) == "" ){					
			if(tipoDestino == "01"){
				var fechaInicio = new Date(fechaHoraEjeSalida.split("/")[2],fechaHoraEjeSalida.split("/")[1], fechaHoraEjeSalida.split("/")[0]); 
				var fechaFin = new Date(fechaHoraEjeRetorno.split("/")[2], fechaHoraEjeRetorno.split("/")[1], fechaHoraEjeRetorno.split("/")[0]);
				var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
				if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime() || fechaFin.getTime() < fechaDocumentoComprobante.getTime()){
					var mensajeReplaceOne = (errorMessageRegistrarComprobante.fechaComprobanteOtros).replace("fechaInicio", fechaHoraEjeSalida);
					var mensajeReplaceFin = mensajeReplaceOne.replace("fechaFin", fechaHoraProgRetorno);
					
					setHtmlElement("spaMensajeAdvertenciaComprobante", mensajeReplaceFin);
				}				
			}else if (tipoDestino == "02"){
				var fechaInicio = new Date(fechaHoraEjeSalida.split("/")[2],fechaHoraEjeSalida.split("/")[1], fechaHoraEjeSalida.split("/")[0]); 
				var fechaFin = new Date(fechaHoraEjeRetorno.split("/")[2], fechaHoraEjeRetorno.split("/")[1], fechaHoraEjeRetorno.split("/")[0]);
				var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
					if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime() || fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
						var mensajeReplaceOne = (errorMessageRegistrarComprobante.fechaComprobanteOtros).replace("fechaInicio", fechaHoraEjeSalida);
						var mensajeReplaceFin = mensajeReplaceOne.replace("fechaFin", fechaHoraEjeRetorno);
						setHtmlElement("spaMensajeAdvertenciaComprobante", mensajeReplaceFin);
					}			
			}				
			$("#divMensajeAdvertenciaComprobante").modal("show");
				
			
		}else{
			setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
			$("#divMensajeConfirmacionComprobante").modal("show");
		}
	}

}

function clickBtnSiMensajeComprobante(){
	callGrabarEditarComprobantePago(parametros);
}

function clickBtnNoMensajeComprobante(){
	$("#divMensajeConfirmacionComprobante").modal("hide");
}

function clickBtnAceptarMensajeWarningComprobante(){
	$("#divMensajeAdvertenciaComprobante").modal("hide");
}

function clickBtnAceptarMensajeComprobante(){	
	$("#divRegistrarModificarComprobanteRendicion").modal("hide");
	$("#divMensajeInfomativoComprobante").modal("hide");
	removeEventElementsRegistrarModificarComprobanteRendicion();
}

function clickBtnAceptarMensajeErrorComprobante(){
	$("#divMensajeErrorComprobante").modal("hide");	
}

//SI 
function callGrabarEditarComprobantePago(parametrosEntrada){
	var estadoNumeroDocumento = false;
	if(parametros.estadoLlamada == "N"){
		estadoNumeroDocumento = validarNumeroDocumentoRepetido();
		consoleLog(" estadoNumeroDocumento--->" +  estadoNumeroDocumento);
	}
	else{
		estadoNumeroDocumento = true;
	}	
							if(estadoNumeroDocumento == "true" || estadoNumeroDocumento==true){
										var arrayListaPlanRendicion = new Array();
										var objetoPlanRendicion = new Object();
										objetoPlanRendicion.tipoDocumento = getValueInputText("selTipoDocumentoComprobante");
										objetoPlanRendicion.ruc = getValueInputText("txtRucComprobante");
										objetoPlanRendicion.razoSociPro = getValueInputText("txtRazonSocialComprobante");	
										objetoPlanRendicion.serie = getValueInputText("txtSerieDocumentoComprobante");	
										objetoPlanRendicion.numeroDocumento = getValueInputText("txtNumeroDocumentoComprobante");
										objetoPlanRendicion.fechaDocumento = getValueInputText("etiquetaFechaDocumentoComprobante");
										objetoPlanRendicion.conceptoId = getValueInputText("selTipoConceptoComprobante");
										objetoPlanRendicion.clasificadorGasto = getValueInputText("txtClasificadorGastoComprobante");
										objetoPlanRendicion.lugarGasto = getValueInputText("txtSustentoLugarReferenciaComprobante");
										
										//DECLARACION JURADA - COMPROBANTE DE PAGO / DECLARACION JURADA - VIATICOS
									    if (getValueInputText("selTipoDocumentoComprobante") == "907" || 
									    	getValueInputText("selTipoDocumentoComprobante") == "906" || getValueInputText("selTipoDocumentoComprobante") == "916" ) {
									    	var montoTotal = $.trim(getValueInputText("montoTotal"));
									    	montoTotal = montoTotal.replace(/,/g , '');
									    	montoTotal  = parseFloat(montoTotal);
										 	objetoPlanRendicion.montoDocumento  =  montoTotal;
									    	objetoPlanRendicion.montoIgv = "0.00";
									    	objetoPlanRendicion.indAfectoIgv = "I";
									    	objetoPlanRendicion.anio = getValueInputText("etiquetaFechaDocumentoComprobante").split("/")[2];
									    	var montoRendicion = getValueText("total_undefined");
									    	montoRendicion = montoRendicion.replace(/,/g , '');
									    	montoRendicion  = parseFloat(montoRendicion);
									    	objetoPlanRendicion.montoRendicion =  montoRendicion;
									    }
									    else{
									    	var valorTotal = $.trim(getValueInputText("valorTotal"));
									    	valorTotal = valorTotal.replace(/,/g , '');
									    	valorTotal  = parseFloat(valorTotal);   	
									    	objetoPlanRendicion.montoDocumento = valorTotal;
									    	
									    	var igv = $.trim(getValueText("igv"));
									    	igv = igv.replace(/,/g , '');
									    	igv  = parseFloat(igv);    	
									    	objetoPlanRendicion.montoIgv = igv;
									    	objetoPlanRendicion.indAfectoIgv = getValueInputText("exoneracionIgv");
									    	
									    	
									    	if (getValueInputText("selTipoDocumentoComprobante") == "915" || getValueInputText("selTipoDocumentoComprobante") == "067"){
									    		objetoPlanRendicion.montoRendicion =  valorTotal;	
									    	}else{
									    		var montoRendicion = getValueText("total_undefined");
										    	montoRendicion = montoRendicion.replace(/,/g , '');
										    	montoRendicion  = parseFloat(montoRendicion);
									    		objetoPlanRendicion.montoRendicion =  montoRendicion;	
									    	}
									    }
									    
									    var otroGasto = $.trim(getValueInputText("otroGasto"));
									    otroGasto = otroGasto.replace(/,/g , '');
									    otroGasto  = parseFloat(otroGasto);
									    objetoPlanRendicion.mtoOtrosGastos = otroGasto;
									    
										arrayListaPlanRendicion.push(objetoPlanRendicion);
										
									
										var arrayListaPlanInformeDistrib = new Array();
										
										var planInformeDistribTable = $("#tblDatosComprobantePago");	
										var planInformeDistribArray = planInformeDistribTable.jqGrid("getRowData");	
										
										if (getValueInputText("selTipoDocumentoComprobante") != "915" && getValueInputText("selTipoDocumentoComprobante") != "067"){
											for(i = 0; i < planInformeDistribArray.length; i++){
												var objetoPlanInformeDistrib = new Object();
												objetoPlanInformeDistrib.fechaViaticoEntrada = getValueText("fechaViatico_"+planInformeDistribArray[i].fechaDDMMYYYY);		
												objetoPlanInformeDistrib.montoDocumentoAlimentacion = getValueInputText("alimentacion_" + planInformeDistribArray[i].fechaDDMMYYYY);
												objetoPlanInformeDistrib.montoDocumentoHospedaje = getValueInputText("hospedaje_"+planInformeDistribArray[i].fechaDDMMYYYY);
												objetoPlanInformeDistrib.montoDocumentoMovilidad = getValueInputText("movilidad_"+planInformeDistribArray[i].fechaDDMMYYYY);
												objetoPlanInformeDistrib.montoDocumentoTranslado = getValueInputText("translado_"+planInformeDistribArray[i].fechaDDMMYYYY);
												objetoPlanInformeDistrib.codConceptoOri = getValueInputText("selTipoConceptoComprobante");
												arrayListaPlanInformeDistrib.push(objetoPlanInformeDistrib);
											}
												
										}else{
											arrayListaPlanInformeDistrib = new Array();
										}

										$.ajax({
											url: contextPathUrl + "/registroGeneral.htm?action=registrarComprobantePago",
											data: {
												"planViajeId": parametrosEntrada.planViajeId,
												"secuencial": parametrosEntrada.secuencial,
												"fechaDocumento": objetoPlanRendicion.fechaDocumento,
												"numeroRegistroColaborador" : parametrosEntrada.numeroRegistroColaborador,			
												"listaPlanViajeRendicion": JSON.stringify(arrayListaPlanRendicion),
												"listaPlanViajeInformeDistrib": JSON.stringify(arrayListaPlanInformeDistrib)
											},
											type: "post",
											dataType: "json",
											cache: false,
											async: true,
											beforeSend: function() {
												showModalElement("divScreenBlock");
											},
											complete: function() {
												$("#divMensajeConfirmacionComprobante").modal("hide");
												hideModalElement("divScreenBlock");
											},
											success: function(result) {	
												
												 if(result.documentoSustentarioDTO.mensajeOut==0){
													 setValueInputText("txtNumeroDocumentoComprobante", result.documentoSustentarioDTO.planViajeRendicionBean.numeroDocumento);
													 setValueInputText("txtSecuenciaComprobante", result.documentoSustentarioDTO.planViajeRendicionBean.secuencial);
														 comprobantePagoService.comprobantePagoAfter(parametrosEntrada.planViajeId);					 
														 setHtmlElement("spaMensajeInformativoTituloComprobante", errorMessageRegistrarComprobante.mensajeExito);
														 $("#divMensajeInfomativoComprobante").modal("show");
												 }else if(result.documentoSustentarioDTO.mensajeOut==-1){
													 comprobantePagoService.comprobantePagoAfter("");
													 setHtmlElement("spaMensajeErrorComprobante", errorMessageRegistrarComprobante.mensajeErrorGenerico);
													 $("#divMensajeErrorComprobante").modal("show");
												 }else{
													 comprobantePagoService.comprobantePagoAfter(""); 
													 setHtmlElement("spaMensajeErrorComprobante", errorMessageRegistrarComprobante.mensajeErrorGenerico);
													 $("#divMensajeErrorComprobante").modal("show");
												 }
											},
											error: function() {
												setHtmlElement("spaMensajeErrorComprobante", errorMessageRegistrarComprobante.mensajeErrorGenerico);
												 $("#divMensajeErrorComprobante").modal("show");
												consoleLog("Error callObtenerConceptoPlanillaViaticosToComprobante");
											}
										});
								}	
}

//SI 
function onBlurMonto( objRef ) {
	var control = $( objRef );
	var igv = 0.00;
	
		if($.trim(control.val()) == ""){
			control.val("0.00");		
		}		
			var importeDiario = control.val().replace(/,/g , '');
		
			if($.isNumeric(importeDiario)){
				var estado = control.data("tipo");									
				importeDiario = recortarDigitosEnteros( importeDiario, 8 );				
				control.val( roundComasMilesString( importeDiario, 2 )  );
				
				var valorVenta = getValueInputText("valorVenta");
				var montoBase = getValueInputText("montoBase");				
				var otroGasto = getValueInputText("otroGasto");
				var valorTotal = getValueInputText("valorTotal");
				var montoTotal = getValueInputText("montoTotal");
				var porcentajeIgv =  getValueInputText("igvActual");
				var estadoIgv = obtenerIgv();
				
					valorVenta = valorVenta.replace(/,/g , '');
					montoBase = montoBase.replace(/,/g , '');					
					otroGasto = otroGasto.replace(/,/g , '');
					valorTotal = valorTotal.replace(/,/g , '');
					montoTotal = montoTotal.replace(/,/g , '');
					
					if($.trim(estado) != ""){
						
							if(estadoIgv == "I" || estadoIgv == "E"){
								 igv = 0.00;			
								 
								 if(estado == "VV" || estado == "MB" || estado == "OG"){		
									 
									 var valorTotal = parseFloat(valorVenta) + parseFloat(otroGasto);
									 var montoTotal = parseFloat(montoBase) + parseFloat(otroGasto);
									 setValueInputText("valorTotal", roundComasMilesString(valorTotal, 2));
									 setValueInputText("montoTotal", roundComasMilesString(montoTotal, 2));
								 }else if(estado == "VT" || estado == "MT"){
									 validarOtroGastoMayorMontoTotal();
									 setValueInputText("otroGasto",roundComasMilesString(0.00, 2));
									 var montoBase  = parseFloat(montoTotal) - parseFloat(otroGasto);	
									 var valorVenta = parseFloat(valorTotal) - parseFloat(otroGasto);
									 setValueInputText("montoBase",roundComasMilesString(montoBase, 2));
									 setValueInputText("valorVenta",roundComasMilesString(valorVenta, 2));
								 }	
								 if(estado != "OG")
								 	validarMontoBaseValorVenta();
							}else if(estadoIgv == "A" ){
								
								 if(estado == "VV" || estado == "OG" ){									 
									 igv = parseFloat(valorVenta) * porcentajeIgv;	
									 var valorTotal = parseFloat(valorVenta) + parseFloat(otroGasto) + igv;
									 setValueInputText("valorTotal", roundComasMilesString(valorTotal, 2))
								 }else	if(estado == "VT"){
									 validarOtroGastoMayorMontoTotal();
									 var valorVenta  = parseFloat(valorTotal/(parseFloat(porcentajeIgv)+1));
									 igv = roundComasMilesString(porcentajeIgv*valorVenta, 2);		
									 igv = igv.replace(/,/g , '');
									 setValueInputText("valorVenta",roundComasMilesString(valorVenta, 2));
									 setValueInputText("otroGasto",roundComasMilesString(0.00, 2));
								}
								 if(estado != "OG")
									 	validarMontoBaseValorVenta();
							}						
							setHtmlElement("igv", roundComasMilesString(igv, 2 ));
							
					}	
							
			}else{
				control.val("0.00");
			}
			
			var indExtDDJJ = getValueInputText("indExtDDJJ");
			
			if($.trim("indExtDDJJ") != ""){
				if(indExtDDJJ == "0"){
					if(getValueInputText("selTipoDocumentoComprobante") == "906" || getValueInputText("selTipoDocumentoComprobante") == "907" ){
						
						var estadoValidaComprobantePago = validaComprobantePago();
						var idSelectorConcepto = getValueInputText("selTipoConceptoComprobante");
							if(estadoValidaComprobantePago == 1 && (idSelectorConcepto == "01" || idSelectorConcepto == "12")){					
							 var estadoSumaGeneralDistribucion = sumaGeneralDistribucion();
							 consoleLog("estadoSumaGeneralDistribucion:  " + estadoSumaGeneralDistribucion);
									if(estadoSumaGeneralDistribucion == 1)
										validarMontoxAsignacionDeclaracion();
							}
							if(estadoValidaComprobantePago == 1 && idSelectorConcepto != "01" && idSelectorConcepto != "12"){
								validarMontoxAsignacion();
							}
											
					}else{
						var estadoValidaComprobantePago = validaComprobantePago();
						var idSelectorConcepto = getValueInputText("selTipoConceptoComprobante");
							if(estadoValidaComprobantePago == 1 && (idSelectorConcepto == "01" || idSelectorConcepto == "12")){					
								 var estadoSumaGeneralDistribucion = sumaGeneralDistribucion();
								if(estadoSumaGeneralDistribucion == 1)
									validarMontoxAsignacion();
							}
							if(estadoValidaComprobantePago == 1 && idSelectorConcepto != "01" && idSelectorConcepto != "12"){
								validarMontoxAsignacion();
							}
					}
								
				}else if(indExtDDJJ == "1"){
					if(getValueInputText("selTipoDocumentoComprobante") == "906" ||getValueInputText("selTipoDocumentoComprobante") == "907" ){
						var estadoValidaComprobantePago = validaComprobantePago();
						var idSelectorConcepto = getValueInputText("selTipoConceptoComprobante");
							if(estadoValidaComprobantePago == 1 && (idSelectorConcepto == "01" || idSelectorConcepto == "12")){					
								sumaGeneralDistribucion();
							}
							if(estadoValidaComprobantePago == 1 && idSelectorConcepto != "01" && idSelectorConcepto != "12"){
								validarMontoxAsignacion();
							}
							
					}else{
						var estadoValidaComprobantePago = validaComprobantePago();
						var idSelectorConcepto = getValueInputText("selTipoConceptoComprobante");
							if(estadoValidaComprobantePago == 1 && (idSelectorConcepto == "01" || idSelectorConcepto == "12")){					
								sumaGeneralDistribucion();
							}
							if(estadoValidaComprobantePago == 1 && idSelectorConcepto != "01" && idSelectorConcepto != "12"){
								validarMontoxAsignacion();
							}
					}
				}
			}				
			validaFormulario();
}
//SI 
function obtenerIgv(){	
	var igv="";
	if (getValueInputText("selTipoDocumentoComprobante") == "907" || getValueInputText("selTipoDocumentoComprobante") == "906" || getValueInputText("selTipoDocumentoComprobante") == "916" ){
		igv = getValueInputText("exoneracionFija");	
	}else{
		igv = getValueInputText("exoneracionIgv");
	}
	return igv;
}
//SI 
function validarMontoBaseValorVenta(){
	//remove
	var valorVenta = getValueInputText("valorVenta");
	var montoBase = getValueInputText("montoBase");	
	valorVenta = valorVenta.replace(/,/g , '');
	montoBase = montoBase.replace(/,/g , '');		
	
	if (getValueInputText("selTipoDocumentoComprobante") == "907" || 
	    	getValueInputText("selTipoDocumentoComprobante") == "906" || getValueInputText("selTipoDocumentoComprobante") == "916" ){
		removeElement("idMensaje");
		if(parseFloat(montoBase)==0.00){
		  var mensaje = '<div id="idMensaje" class="colorFontRedTableClass">'+errorMessageRegistrarComprobante.mayorCero+'</div>';
		  validarDatosRendicion(mensaje);
		  validaEstadoGeneral = 0;
		}else{
			validaEstadoGeneral = 1;
		}
	}else{
		removeElement("idMensaje");
		if(valorVenta==0.00){
			  var mensaje = '<div id="idMensaje" class="colorFontRedTableClass">'+errorMessageRegistrarComprobante.mayorCero+'</div>';
			  validarDatosRendicion(mensaje);
			  validaEstadoGeneral = 0;
		}else{
			validaEstadoGeneral = 1;
		}
	}
	
}
//SI 
function validarOtroGastoMayorMontoTotal(){
	var otroGasto = getValueInputText("otroGasto");
	var valorTotal = getValueInputText("valorTotal");
	var montoTotal = getValueInputText("montoTotal");
	valorTotal = valorTotal.replace(/,/g , '');	
	montoTotal = montoTotal.replace(/,/g , '');	
	otroGasto = otroGasto.replace(/,/g , '');

	if (getValueInputText("selTipoDocumentoComprobante") == "907" || 
	    	getValueInputText("selTipoDocumentoComprobante") == "906" || getValueInputText("selTipoDocumentoComprobante") == "916" ){
		 if(parseFloat(otroGasto) > parseFloat(montoTotal)){
			  var mensaje = '<div id="idMensaje" class="colorFontOrangeClass">'+errorMessageRegistrarComprobante.datosRendicion+'</div>';
			  validarDatosRendicion(mensaje);
		 }
	}
	else{
		if(parseFloat(otroGasto) > parseFloat(valorTotal)){
			  var mensaje = '<div id="idMensaje" class="colorFontOrangeClass">'+errorMessageRegistrarComprobante.datosRendicion+'</div>';
			  validarDatosRendicion(mensaje);
		 } 
	}
}

function validarMontoxAsignacion(){	
		var montoxTotalAsignacion = getDataAttributeSelect("selTipoConceptoComprobante", "data-monto");
		montoxTotalAsignacion = parseFloat(montoxTotalAsignacion);
		var montoTotalDistribucion = getValueText("total_undefined");
		montoTotalDistribucion = montoTotalDistribucion.replace(/,/g , '');	
		montoTotalDistribucion =  parseFloat(montoTotalDistribucion);
		hideElement("divErrorDatosComprobantePagoDistrib");
		hideElement("divErrorDatosComprobantePago");
		
		var montoRendicion = getValueInputText("valorTotal");
		montoRendicion = montoRendicion.replace(/,/g , '');	
		montoRendicion =  parseFloat(montoRendicion);

		if(getValueInputText("selTipoDocumentoComprobante") == "915" || getValueInputText("selTipoDocumentoComprobante")== "067"){
			montoTotalDistribucion = montoRendicion;
		}
		
		
		if((montoxTotalAsignacion < montoTotalDistribucion) && (parametros.origenLlamada == "V" || (parametros.origenLlamada == "R" && (getValueInputText("selTipoConceptoComprobante") == "01" || getValueInputText("selTipoConceptoComprobante") == "12" ))) ){
			  removeElement("idMensaje");
			  var mensaje = '<div id="idMensaje" class="colorFontRedTableClass">'+errorMessageRegistrarComprobante.distribuidoxAsignacion+'</div>';
			  showMessageErrorComprobante("etiquetaErrorDatosComprobantePagoxAsignacion", mensaje, "divErrorDatosComprobantePagoxAsignacion");
			  validaEstadoGeneral = 0;
		}else{
			hideElement("divErrorDatosComprobantePagoxAsignacion");
			validaEstadoGeneral = 1;
		}
		
		if(getValueInputText("selTipoDocumentoComprobante") == "907"){
			var montoRendicion = getValueInputText("montoTotal");
			montoRendicion = montoRendicion.replace(/,/g , '');	
			montoRendicion =  parseFloat(montoRendicion);
			removeElement("idMensaje");
				if((montoxTotalAsignacion < montoRendicion) && (parametros.origenLlamada == "V" || (parametros.origenLlamada == "R" && (getValueInputText("selTipoConceptoComprobante") == "01" || getValueInputText("selTipoConceptoComprobante") == "12" ))) ){
					var mensaje = '<div id="idMensaje" class="colorFontRedTableClass">'+errorMessageRegistrarComprobante.montoOtorgadoxMontoTotalDocumento+'</div>';
					validarDatosRendicion(mensaje);
					validaEstadoGeneral = 0;
				}else{				
					validaEstadoGeneral = 1;
				}
		}

}

function validarMontoxAsignacionDeclaracion(){
	
		var porcentajeDeclaracion = getValueInputText("porcentajeDeclaracion");
		porcentajeDeclaracion = parseFloat(porcentajeDeclaracion);
		var montoxTotalAsignacion = getDataAttributeSelect("selTipoConceptoComprobante", "data-montodeclaracion");
		montoxTotalAsignacion = parseFloat(montoxTotalAsignacion);
		var montoTotalDistribucion = getValueText("total_undefined");
		montoTotalDistribucion = montoTotalDistribucion.replace(/,/g , '');	
		montoTotalDistribucion =  parseFloat(montoTotalDistribucion);
		
		var montoRendicion = getValueInputText("valorTotal");
		montoRendicion = montoRendicion.replace(/,/g , '');	
		montoRendicion =  parseFloat(montoRendicion);

		if(getValueInputText("selTipoDocumentoComprobante") == "915" || getValueInputText("selTipoDocumentoComprobante")== "067"){
			montoTotalDistribucion = montoRendicion;
		}
		
		hideElement("divErrorDatosComprobantePagoDistrib");
		hideElement("divErrorDatosComprobantePago");
		var porcentaje = "";
		if(porcentajeDeclaracion == 0.3){
			porcentaje = "30%";
		}else if(porcentajeDeclaracion == 0.2){
			porcentaje = "20%";
		}
		consoleLog("validarMontoxAsignacionDeclaracion: " + (montoxTotalAsignacion*porcentajeDeclaracion) + "  :  " + montoTotalDistribucion);
		if(((montoxTotalAsignacion*porcentajeDeclaracion) < montoTotalDistribucion) && (  (parametros.origenLlamada == "V" &&  getValueInputText("selTipoDocumentoComprobante") == "907") || (parametros.origenLlamada == "R" && (getValueInputText("selTipoConceptoComprobante") == "01" || getValueInputText("selTipoConceptoComprobante") == "12" ) && getValueInputText("selTipoDocumentoComprobante") == "907"))){
			  removeElement("idMensaje");
			  var mensaje = '<div id="idMensaje" class="colorFontRedTableClass">'+(errorMessageRegistrarComprobante.distribuidoxAsignacionDeclaracion).replace("PORCENTAJE", porcentaje)+'</div>';
			  showMessageErrorComprobante("etiquetaErrorDatosComprobantePagoxAsignacion", mensaje, "divErrorDatosComprobantePagoxAsignacion");
			  validaEstadoGeneral = 0;
		}else{
			hideElement("divErrorDatosComprobantePagoxAsignacion");
			validaEstadoGeneral = 1;
		}
		
		if(getValueInputText("selTipoDocumentoComprobante") == "907"){
			var montoRendicion = getValueInputText("montoTotal");
			montoRendicion = montoRendicion.replace(/,/g , '');	
			montoRendicion =  parseFloat(montoRendicion);
			removeElement("idMensaje");
				if(((montoxTotalAsignacion*porcentajeDeclaracion ) < montoRendicion) && (parametros.origenLlamada == "V" || (parametros.origenLlamada == "R" && (getValueInputText("selTipoConceptoComprobante") == "01" || getValueInputText("selTipoConceptoComprobante") == "12" ))) ){
					
					var mensaje = '<div id="idMensaje" class="colorFontRedTableClass">'+errorMessageRegistrarComprobante.montoOtorgadoxMontoTotalDocumento+'</div>';
		  			validarDatosRendicion(mensaje);
					validaEstadoGeneral = 0;
				}else{					
					validaEstadoGeneral = 1;
				}
		}
}

//SI 
function recortarDigitosEnteros( numeroString, maxDigEnteros ) {	
	if ( isNullOrUndefined( numeroString )  ) return numeroString;	
	var num = (numeroString + '').replace(/,/g , '');	
	var posComa = num.indexOf( '.' );	
	if ( posComa >= 0 ) {	
		var izq = num.substring( 0, posComa );
		var der = num.substring( posComa + 1, num.length );	
		if ( izq.length > maxDigEnteros ) {
			izq = izq.substring( 0, maxDigEnteros );
		}		
		num = izq + '.' + der;		
	} else {	
		if ( num.length > maxDigEnteros ) {
			num = num.substring( 0, maxDigEnteros );
		}			
	}	
	return num;
} 

//SI 
function isNullOrUndefined( valor ) {
	return valor == null || ( typeof valor == 'undefined' );
}
//SI 
function roundComasMilesString( valor, digitos ) {
	var val = roundString( valor, digitos );
	var parts = val.toString().split(".");
	return parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",") + (parts[1] ? "." + parts[1] : "");
}
//SI 
function roundString( valor, digitos ) {
	// redondear
	var round = redondearNumeros( digitos, parseFloat( valor ) );
	// formatear completando el nro de digitos en los decimales
	var result = round.toFixed( digitos ) + '';
	return result;
}

//SI
function onBlurGastoItinerario( objRef ) {
	// recoge el valor ingresado, lo formatea y actualiza en el modelo/asignaciones
	var control = $( objRef );
	var fecha =  control.attr("id").split('_');
		if($.trim(control.val()) != ""){
			var importeDiario = control.val().replace(/,/g , '');
		}else{
			control.val("0.00");
			importeDiario = 0.00;		}	
			if($.isNumeric(importeDiario)){
				var estado = control.data("tipo");
				// en bd es 10,2												
				importeDiario = recortarDigitosEnteros( importeDiario, 8 );				
				control.val( roundComasMilesString( importeDiario, 2 ));				
				var alimentacion = getValueInputText("alimentacion_" + fecha[1]);
				var hospedaje = getValueInputText("hospedaje_" +  fecha[1]);				
				var movilidad = getValueInputText("movilidad_" + fecha[1]);
				var translado = getValueInputText("translado_" + fecha[1]);				
				alimentacion = alimentacion.replace(/,/g , '');
				hospedaje = hospedaje.replace(/,/g , '');					
				movilidad = movilidad.replace(/,/g , '');
				translado = translado.replace(/,/g , '');			
					sumaValoresIteracion(fecha[1], alimentacion, hospedaje, movilidad, translado);
					sumaValoresIteracionFooter();
			}else{
				control.val("0.00");
			}
		
		var total  = parseFloat(alimentacion) + parseFloat(hospedaje) + parseFloat(movilidad) + parseFloat(translado);		
		var idSelectorConcepto = getValueInputText("selTipoConceptoComprobante");		
		if(idSelectorConcepto == "01" || idSelectorConcepto == "12"){
			if(validaComprobantePago()==1){
				var estadoValidarMontoxFecha =  validarMontoxFecha(total, fecha[1]);
				if(estadoValidarMontoxFecha == 1){
					var indExtDDJJ = getValueInputText("indExtDDJJ");
					if(indExtDDJJ == "0"){
						if (getValueInputText("selTipoDocumentoComprobante") == "907" || getValueInputText("selTipoDocumentoComprobante") == "906"){
							validarMontoxAsignacionDeclaracion();
						}else{
							validarMontoxAsignacion();
						}			
					}else if(indExtDDJJ == "1"){
						validarMontoxAsignacion();
					}
				}
			}			
		}else{
			var estadoValidaComprobantePago = validaComprobantePago();
			if(estadoValidaComprobantePago == 1){			
						validarMontoxAsignacion();			
			}
		}
		validaSustentoLugar();
}

//SI 
function sumaValoresIteracionFooter(){
	var alimentacionSum = 0;
	var hospedajeSum = 0;
	var movilidadSum = 0;
	var transladoSum = 0;
	
	$(".fechaViatico").each(function(){
		var fecha = $(this).attr("id").split('_'); 
			if(fecha[1] != "undefined"){
				var alimentacion =  getValueInputText("alimentacion_" + fecha[1]);
				var hospedaje = getValueInputText("hospedaje_" +  fecha[1]);				
				var movilidad =  getValueInputText("movilidad_" + fecha[1]);
				var translado =  getValueInputText("translado_" + fecha[1]);				
				alimentacion = alimentacion.replace(/,/g , '');
				hospedaje = hospedaje.replace(/,/g , '');					
				movilidad = movilidad.replace(/,/g , '');
				translado = translado.replace(/,/g , '');				
				alimentacionSum = alimentacionSum + parseFloat(alimentacion);		
				hospedajeSum = hospedajeSum + parseFloat(hospedaje);		
				movilidadSum = movilidadSum + parseFloat(movilidad);		
				transladoSum = transladoSum + parseFloat(translado);
			}		
	});
	
	var total = alimentacionSum + hospedajeSum + movilidadSum + transladoSum;
	
	setValueInputText("alimentacion_undefined", roundComasMilesString(alimentacionSum, 2));
	setValueInputText("hospedaje_undefined", roundComasMilesString(hospedajeSum, 2));
	setValueInputText("movilidad_undefined", roundComasMilesString(movilidadSum, 2));
	setValueInputText("translado_undefined", roundComasMilesString(transladoSum, 2));
	setHtmlElement("total_undefined", roundComasMilesString(total, 2));
	//validaFormulario();
}

function sumaValoresIteracion (fecha, alimentacion, hospedaje, movilidad, translado){	
	var total  = parseFloat(alimentacion) + parseFloat(hospedaje) + parseFloat(movilidad) + parseFloat(translado);	
	//validarMontoxFecha(total, fecha);
	setHtmlElement("total_"+fecha, roundComasMilesString(total, 2));
}

//SI
function validarMontoxFecha(totalxFecha, fecha){
	//if(validaComprobantePago()=="1"){
		hideElement("divErrorDatosComprobantePago");
		hideElement("divErrorDatosComprobantePagoxAsignacion");
		var montoRendicionFechaFormater = $("#rendicionFechaRendicion_"+fecha).data("montofechaformater");
		var montoRendicionFechaSinFormater = $("#rendicionFechaRendicion_"+fecha).data("montofechasinformater");
		var fechaFormater = getValueText("fechaViatico_"+fecha);
		consoleLog("samuel: " + totalxFecha + " montoRendicionFechaSinFormater: " + montoRendicionFechaSinFormater);
		if(parseFloat(montoRendicionFechaSinFormater) < parseFloat(totalxFecha)){
				var mensaje = errorMessageRegistrarComprobante.montoFecha;
				mensaje = mensaje.replace("FECHA_TOPE", fechaFormater).replace("MONEDA_MONTO", montoRendicionFechaFormater);
				showMessageErrorComprobante("etiquetaErrorDatosComprobantePagoDistrib", mensaje, "divErrorDatosComprobantePagoDistrib");
				validaEstadoGeneral = 0;
		}else{			
				validaEstadoGeneral = 1;
				hideElement("divErrorDatosComprobantePagoDistrib");		
			}

		return validaEstadoGeneral;
}

function sumaGeneralDistribucion(){
	hideElement("divErrorDatosComprobantePago");
	hideElement("divErrorDatosComprobantePagoxAsignacion");
	var fechas = new Array();
	var sumaTotal = 0;
	
	$(".total").each(function(){
		var ids = $(this).attr("id");
		ids = ids.split("_")[1];
		if(ids != "undefined")
			fechas.push(ids);
	});
		
		for(i=0; i < fechas.length; i++){
			var total = getValueText("total_"+fechas[i]);//monto total por fecha
			var montoXfecha = $("#rendicionFechaRendicion_"+fechas[i]).data("montofechasinformater");	//monto tope x fecha		
			var montoRendicionFechaFormater = $("#rendicionFechaRendicion_"+fechas[i]).data("montofechaformater");
			var fechaFormater = getValueText("fechaViatico_"+fechas[i]);			
			
			total =  total.replace(/,/g , '');
			//montoXfecha = montoXfecha.replace(/,/g , '');
			if(parseFloat(montoXfecha) < parseFloat(total)){
				var mensaje = errorMessageRegistrarComprobante.montoFecha;
				mensaje = mensaje.replace("FECHA_TOPE", fechaFormater).replace("MONEDA_MONTO", montoRendicionFechaFormater);
				showMessageErrorComprobante("etiquetaErrorDatosComprobantePagoDistrib", mensaje, "divErrorDatosComprobantePagoDistrib");
				validaEstadoGeneral = 0;
				break;
			}
			else{
				validaEstadoGeneral = 1;
				hideElement("divErrorDatosComprobantePagoDistrib");
			}
		}
	return validaEstadoGeneral;
}

//SI VALIDAR DONDE SE LLAMA MAS

function validaComprobantePago(){
	hideElement("divErrorDatosComprobantePagoDistrib");	
	hideElement("divErrorDatosComprobantePagoxAsignacion");
	var total_undefined = getValueText("total_undefined");
	total_undefined = total_undefined.replace(/,/g , '');
	total_undefined  = parseFloat(total_undefined);	
    
	 var valorTotal = getValueInputText("valorTotal");
	 	 valorTotal = valorTotal.replace(/,/g , '');
	 	 valorTotal  = parseFloat(valorTotal);
	 	 
	 var montoTotal = getValueInputText("montoTotal");
	 	montoTotal = montoTotal.replace(/,/g , '');
	 	montoTotal  = parseFloat(montoTotal);
	 	consoleLog("valorTotal: " + valorTotal + " total_undefined: " + total_undefined) ;
    
	if (getValueInputText("selTipoDocumentoComprobante") == "907" || getValueInputText("selTipoDocumentoComprobante") == "906" || getValueInputText("selTipoDocumentoComprobante") == "916") {
		if(total_undefined > montoTotal){    	
	    	showMessageErrorComprobante('etiquetaErrorDatosComprobantePago', errorMessageRegistrarComprobante.distribuido, 'divErrorDatosComprobantePago');
	    	validaEstadoGeneral = 0;
	    }else {
	    	hideElement("divErrorDatosComprobantePago");
	    	validaEstadoGeneral = 1;
	    }
	}else {
		if(total_undefined > valorTotal){    	
	    	showMessageErrorComprobante('etiquetaErrorDatosComprobantePago', errorMessageRegistrarComprobante.distribuido, 'divErrorDatosComprobantePago');
	    	validaEstadoGeneral = 0;
	    }else {
	    	hideElement("divErrorDatosComprobantePago");
	    	validaEstadoGeneral = 1;
	    }
	}	
	return validaEstadoGeneral; 		
}

//SI 
//VALIDAR FECHA DOCUMENTO
function validarFechaTipoDocumento(){
	var tipoDocumentoComprobante = getValueInputText("selTipoDocumentoComprobante");
	var fechaDocumentoComprobante = getValueInputText("etiquetaFechaDocumentoComprobante");
	var fechaHoraProgSalida = getValueInputText("fechaHoraProgSalida");
	var fechaHoraProgRetorno = getValueInputText("fechaHoraProgRetorno");
	var fechaHoraEjeSalida = getValueInputText("fechaHoraEjeSalida");
	var fechaHoraEjeRetorno = getValueInputText("fechaHoraEjeRetorno");
	var tipoDestino = getValueInputText("tipoDestino");
	//DECLARACION JURADA	
	
	if(tipoDocumentoComprobante == "906" || tipoDocumentoComprobante == "907" || tipoDocumentoComprobante == "916"){		
		if(tipoDestino == "01"){
			var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
			var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
			var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
			
			if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
				var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteDeclaracion;
				showMessageErrorComprobante("etiquetaErrorFechaDocumento", mensajeReplaceFin,"divErrorFechaDocumento");
				validaEstadoGeneral = 0;
				validaEstadoFechaGeneral = 0;
			}	
			else{
				hideElement("divErrorFechaDocumento");
				validaEstadoGeneral = 1;
				validaEstadoFechaGeneral = 1;
			}
		}else if (tipoDestino == "02"){
			var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
			var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
			var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
				if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
					var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteDeclaracion;				
					showMessageErrorComprobante("etiquetaErrorFechaDocumento", mensajeReplaceFin,"divErrorFechaDocumento");
					validaEstadoGeneral = 0;
					validaEstadoFechaGeneral = 0;
				}	
				else{
					validaEstadoGeneral = 1;
					validaEstadoFechaGeneral = 1;
					hideElement("divErrorFechaDocumento");
				}
		}
		
	}else if (tipoDocumentoComprobante == "915" || getValueInputText("selTipoDocumentoComprobante") == "067"){//BOLETO DE VIAJE
		if(tipoDestino == "01"){
			var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
			var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
			var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
			
			if (fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
				var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteBoletoViaje;
				showMessageErrorComprobante("etiquetaErrorFechaDocumento", mensajeReplaceFin,"divErrorFechaDocumento");
				validaEstadoGeneral = 0;
				validaEstadoFechaGeneral = 0;
			}	
			else{
				validaEstadoGeneral = 1;
				validaEstadoFechaGeneral = 1;
				hideElement("divErrorFechaDocumento");
			}
		}else if (tipoDestino == "02"){
			var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
			var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
			var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
				if (fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
					var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteBoletoViaje;				
					showMessageErrorComprobante("etiquetaErrorFechaDocumento", mensajeReplaceFin,"divErrorFechaDocumento");
					validaEstadoGeneral = 0;
					validaEstadoFechaGeneral = 0;
				}	
				else{
					validaEstadoGeneral = 1;
					validaEstadoFechaGeneral = 1;
					hideElement("divErrorFechaDocumento");
				}
		}
	}else {		
		if(tipoDestino == "01"){
			var fechaInicio = new Date(fechaHoraEjeSalida.split("/")[2],fechaHoraEjeSalida.split("/")[1], fechaHoraEjeSalida.split("/")[0]); 
			var fechaFin = new Date(fechaHoraEjeRetorno.split("/")[2], fechaHoraEjeRetorno.split("/")[1], fechaHoraEjeRetorno.split("/")[0]);
			var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
			if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime() || fechaFin.getTime() < fechaDocumentoComprobante.getTime()){
				var mensajeReplaceOne = (errorMessageRegistrarComprobante.fechaComprobanteOtros).replace("fechaInicio", fechaHoraEjeSalida);
				var mensajeReplaceFin = mensajeReplaceOne.replace("fechaFin", fechaHoraEjeRetorno);
				showMessageErrorComprobante("etiquetaErrorFechaDocumento", mensajeReplaceFin,"divErrorFechaDocumento");
				validaEstadoGeneral = 0;
				validaEstadoFechaGeneral = 0;
			}
			else {
				validaEstadoGeneral = 1;
				validaEstadoFechaGeneral = 1;
				hideElement("divErrorFechaDocumento");
			}
		}else if (tipoDestino == "02"){
			var fechaInicio = new Date(fechaHoraEjeSalida.split("/")[2],fechaHoraEjeSalida.split("/")[1], fechaHoraEjeSalida.split("/")[0]); 
			var fechaFin = new Date(fechaHoraEjeRetorno.split("/")[2], fechaHoraEjeRetorno.split("/")[1], fechaHoraEjeRetorno.split("/")[0]);
			var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
				if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime() || fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
					var mensajeReplaceOne = (errorMessageRegistrarComprobante.fechaComprobanteOtros).replace("fechaInicio", fechaHoraEjeSalida);
					var mensajeReplaceFin = mensajeReplaceOne.replace("fechaFin", fechaHoraEjeRetorno);
					showMessageErrorComprobante("etiquetaErrorFechaDocumento", mensajeReplaceFin,"divErrorFechaDocumento");
					validaEstadoGeneral = 0;
					validaEstadoFechaGeneral = 0;
				}	
				else{
					validaEstadoGeneral = 1;
					validaEstadoFechaGeneral = 1;
					hideElement("divErrorFechaDocumento");
				}
		}
	}
	validaFormulario();
}

//SI 
function showMessageErrorComprobante(etiquetaError, errorMessage, divError) {
	setHtmlElement(etiquetaError, errorMessage);
	showElement(divError);
}
//SI 
//VALIDA GRILLA DATO DE RENDICION
function validarDatosRendicion(mensaje){
	var mensajeError = mensaje;
	afterElement("tblDatosRendicion", mensajeError);
}

//SI valida RUC
function validaRUC(){

	var ruc = getValueInputText("txtRucComprobante");
	var tipoDocumento = getValueInputText("selTipoDocumentoComprobante");
	var descripcionTipoDocumento = getTextSelect("selTipoDocumentoComprobante");
	if($.trim(ruc) != ""){
		if($.trim(ruc).length==11){
			$.ajax({
	            url: contextPathUrl + "/viatico.htm?action=consultarRuc",
	            data: {
					"ruc": $.trim(ruc)
				},
				type: "post",
				dataType: "json",
				cache: false,
				beforeSend: function() {
					showElement("divLoadingComprobante");
				},
				complete: function() {
					hideElement("divLoadingComprobante");
				},
	            success: function (data) {	            	
	            	if(data.estado){
	            		hideElement("divErrorRUC");	            		
	            		setValueInputText("txtRazonSocialComprobante", data.razonSocial);	      
	            		validaEstadoGeneral = 1;
	            		if(tipoDocumento=="002"){
	            			if(!(data.flagBoleta)){
	            				hideElement("divErrorRUC");
	            				var mensaje = (errorMessageRegistrarComprobante.RUC).replace("XXXXXXXXXXXX", $.trim(ruc)).replace("TIPO_COMPROBANTE",descripcionTipoDocumento);
	            				showMessageErrorComprobante("etiquetaErrorRUC", mensaje, "divErrorRUC");
		        				validaEstadoGeneral = 0; 
	            			}
	            		}
	            		if(tipoDocumento=="001"){
	            			if(!(data.flagFactura)){
	            				hideElement("divErrorRUC");
	            				var mensaje = (errorMessageRegistrarComprobante.RUC).replace("XXXXXXXXXXXX", $.trim(ruc)).replace("TIPO_COMPROBANTE",descripcionTipoDocumento);
	            				showMessageErrorComprobante("etiquetaErrorRUC", mensaje, "divErrorRUC");
		        				validaEstadoGeneral = 0; 
	            			}
	            		}    	            	
	            	}else { 	            		
	            		showMessageErrorComprobante("etiquetaErrorRUC", data.mensaje, "divErrorRUC");
	            		setValueInputText("txtRazonSocialComprobante", data.razonSocial); 
	            		validaEstadoGeneral = 0;
	            	}
	            },
	            error: function (xhr, textStatus, errorMessage) {	            	
	            }                
	        });
		}else{
			setValueInputText("txtRazonSocialComprobante", "");
			showMessageErrorComprobante("etiquetaErrorRUC", errorMessageRegistrarComprobante.rucMenorOnceDigitos, "divErrorRUC");
			validaEstadoGeneral = 0;
		}
	}else{
		setValueInputText("txtRazonSocialComprobante", "");
		showMessageErrorComprobante("etiquetaErrorRUC", "Debe colocar RUC", "divErrorRUC");
		validaEstadoGeneral = 0;
	}
	validaFormulario();
	
}
//NO quitar el JSP el onblur
function validarNumeroDocumento(){
	validaFormulario();
}

//SI implementar en el grabar
function validarNumeroDocumentoRepetido(){
	var estadoRespuesta;
	var tipoDocumento = getValueInputText("selTipoDocumentoComprobante");
	var serie = getValueInputText("txtSerieDocumentoComprobante");
	var numeroDocumento = getValueInputText("txtNumeroDocumentoComprobante");
	var numeroRuc = getValueInputText("txtRucComprobante");
	if($.trim(tipoDocumento) != "907" && $.trim(tipoDocumento) != "906" && $.trim(tipoDocumento) != "916"){
		if($.trim(tipoDocumento) != "" && $.trim(serie) !=  "" && $.trim(numeroDocumento) != "" && $.trim(numeroRuc) != ""){
			$.ajax({
				url: contextPathUrl + "/viatico.htm?action=validarTipoDocumento",
				data: {
					"tipoDocumento": $.trim(tipoDocumento),
					"serie": $.trim(serie),
					"numeroDocumento": $.trim(numeroDocumento),
					"numeroRuc" :  $.trim(numeroRuc)
				},
				type: "post",
				dataType: "json",
				cache: false,
				async: false,
				beforeSend: function() {
					showElement("divLoadingNumeroDocumento");
				},
				complete: function() {
					hideElement("divLoadingNumeroDocumento");
				},
				success: function(result) {		
					$("#divMensajeConfirmacionComprobante").modal("hide");
					if(!result.estadoNumeroDocumento){	
						 var mensaje = (errorMessageRegistrarComprobante.numeroDocumento).replace('SERIE',$.trim(serie.toUpperCase())).replace('NRO_DOCUMENTO',$.trim(numeroDocumento.toUpperCase()));
						 setHtmlElement("spaMensajeAdvertenciaComprobante", mensaje);
						 $("#divMensajeAdvertenciaComprobante").modal("show");						 
						 estadoRespuesta = false;
						
					}else{						
						estadoRespuesta = true;
					}
				},
				error: function() {
					consoleLog("Error callObtenerConceptoPlanillaViaticosToComprobante");
				}
			});
		}
	}else{
		estadoRespuesta = true;
	}
	consoleLog("estadoRespuesta: " +  estadoRespuesta);
	 return estadoRespuesta;
}

//SI
function cambioIgv(){
	var estadoIgv = getValueInputText("exoneracionIgv");
	 if(estadoIgv == "A"){		 
		 	var porcentajeIgv = getValueInputText("igvActual");		
			var valorVenta = getValueInputText("valorVenta");
			valorVenta = valorVenta.replace(/,/g , '');
			valorVenta  = parseFloat(valorVenta);				
			var otroGasto = getValueInputText("otroGasto");
			otroGasto = otroGasto.replace(/,/g , '');
			otroGasto  = parseFloat(otroGasto);			
			setHtmlElement("igv", roundComasMilesString(porcentajeIgv*valorVenta, 2));			
			setValueInputText("valorTotal", roundComasMilesString(otroGasto + (porcentajeIgv*valorVenta) + valorVenta, 2));						
	 }else if(estadoIgv == "E"){		
			var valorVenta = getValueInputText("valorVenta");
			valorVenta = valorVenta.replace(/,/g , '');
			valorVenta  = parseFloat(valorVenta);			
			var otroGasto = getValueInputText("otroGasto");
			otroGasto = otroGasto.replace(/,/g , '');
			otroGasto  = parseFloat(otroGasto);
			setHtmlElement("igv","0.00");			
			setValueInputText("valorTotal", roundComasMilesString(otroGasto + valorVenta, 2));
			
	 }else if (estadoIgv == "I"){
		 	var valorVenta = getValueInputText("valorVenta");
			valorVenta = valorVenta.replace(/,/g , '');
			valorVenta  = parseFloat(valorVenta);			
			var otroGasto = getValueInputText("otroGasto");
			otroGasto = otroGasto.replace(/,/g , '');
			otroGasto  = parseFloat(otroGasto);
			setHtmlElement("igv","0.00");			
			setValueInputText("valorTotal", roundComasMilesString(otroGasto + valorVenta, 2));
	 }
}

//SI
function validaSustentoLugar(){

	if (getValueInputText("selTipoDocumentoComprobante") == "915" || getValueInputText("selTipoDocumentoComprobante") == "067") {
		if($.trim(getValueInputText("txtSustentoLugarReferenciaComprobante")) == ""){
			showMessageErrorComprobante('etiquetaErrorSustentoLugar', errorMessageRegistrarComprobante.sustentoLugar, 'divErrorSustentoLugar');
			validaEstadoGeneral=0;
		}else{
			hideElement("divErrorSustentoLugar");
			validaEstadoGeneral=1;
		}
	}else if (getValueInputText("selTipoDocumentoComprobante") == "907"){

		var valorAlimentacion = 0;
		var valorHospedaje = 0;
		$(".alimentacion").each(function(){
			valorAlimentacion = valorAlimentacion + parseFloat(($(this).val()).replace(/,/g , ''));			
		});
		
		$(".hospedaje").each(function(){
			valorHospedaje = valorHospedaje + parseFloat(($(this).val()).replace(/,/g , ''));
		});
		
		if( (valorAlimentacion > 0 || valorHospedaje > 0 ) && $.trim(getValueInputText("txtSustentoLugarReferenciaComprobante")) == ""){
			showMessageErrorComprobante('etiquetaErrorSustentoLugar', errorMessageRegistrarComprobante.sustento, 'divErrorSustentoLugar');
			validaEstadoGeneral=0;
		}else{
			hideElement("divErrorSustentoLugar");
			validaEstadoGeneral=1;
		}		
	}
	validaFormulario();
}

//SI
function validaFormulario(){
	consoleLog("validaEstadoGeneral: " + validaEstadoGeneral);
	var tipoConcepto = getValueInputText("selTipoConceptoComprobante");
	var clasificadorGasto =  getValueInputText("txtClasificadorGastoComprobante");
	var ruc =  getValueInputText("txtRucComprobante");
	var numeroDocumento =  getValueInputText("txtNumeroDocumentoComprobante");
	var serie =  getValueInputText("txtSerieDocumentoComprobante");
	var fecha =  getValueInputText("etiquetaFechaDocumentoComprobante");	
	var valorVenta = getValueInputText("valorVenta");
	var valorTotal = getValueInputText("valorTotal");
	var montoBase = getValueInputText("montoBase");
	var montoTotal = getValueInputText("montoTotal");
	var tipoDestino = getValueInputText("tipoDestino");	
	var sustentoLugar = getValueInputText("txtSustentoLugarReferenciaComprobante");
	//DECLARACION JURADA - COMPROBANTE DE PAGO / DECLARACION JURADA - VIATICOS	
	
	var tipoDocumentoComprobante = getValueInputText("selTipoDocumentoComprobante");
	var fechaDocumentoComprobante = getValueInputText("etiquetaFechaDocumentoComprobante");
	var fechaHoraProgSalida = getValueInputText("fechaHoraProgSalida");
	var fechaHoraProgRetorno = getValueInputText("fechaHoraProgRetorno");
	var fechaHoraEjeSalida = getValueInputText("fechaHoraEjeSalida");
	var fechaHoraEjeRetorno = getValueInputText("fechaHoraEjeRetorno");
	
	consoleLog( "valorVenta: " + valorVenta + " valorTotal " + valorTotal + " fecha " + fecha + " validaEstadoGeneral " + validaEstadoGeneral + " ruc "+ ruc + " numeroDocumento " + numeroDocumento + " serie " + serie + " tipoConcepto " + tipoConcepto + " clasificadorGasto " + clasificadorGasto)
	
	if (getValueInputText("selTipoDocumentoComprobante") == "907" || getValueInputText("selTipoDocumentoComprobante") == "906") {

    	if( $.trim(montoBase) == "0.00" ||  $.trim(montoTotal) == "0.00" || $.trim(fecha) == "" ||  validaEstadoGeneral == 0  ||  $.trim(numeroDocumento)== "" || $.trim(serie)== ""  ||  ($.trim(tipoConcepto) == "" && $.trim(tipoConcepto) == "00") || $.trim(clasificadorGasto) == ""){
			disabledElement("btnGrabarComprobante");
			disabledElement("btnGrabarAuxComprobante");			
    	}else{
    		if($.trim(fecha) != ""){
				if(tipoDestino == "01"){
					var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
					var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
					var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
					consoleLog("fechaInicio: " + fechaInicio.getTime()+ " fechaDocumentoComprobante: " + fechaDocumentoComprobante.getTime());
					if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
						disabledElement("btnGrabarComprobante");
						disabledElement("btnGrabarAuxComprobante");	
					}	
					else{
						consoleLog("samuel ingreso");
						enabledElement("btnGrabarComprobante");
						enabledElement("btnGrabarAuxComprobante");
					}
				}else if (tipoDestino == "02"){
					var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
					var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
					var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
						if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
							disabledElement("btnGrabarComprobante");
							disabledElement("btnGrabarAuxComprobante");	
						}	
						else{
							enabledElement("btnGrabarComprobante");
							enabledElement("btnGrabarAuxComprobante");
						}
				}  
			}

		}
	 
    }//COMPROBANTE DEL EXTERIOR
    else if (getValueInputText("selTipoDocumentoComprobante") == "916") {

    	if( $.trim(montoBase) == "0.00" ||  $.trim(montoTotal) == "0.00" || $.trim(fecha) == "" ||  validaEstadoGeneral == 0  ||  $.trim(numeroDocumento)== "" || $.trim(serie)== ""  ||  ($.trim(tipoConcepto) == "" && $.trim(tipoConcepto) == "00") || $.trim(clasificadorGasto) == ""){
			disabledElement("btnGrabarComprobante");
			disabledElement("btnGrabarAuxComprobante");
		}else{
			if($.trim(fecha) != ""){
				if(tipoDestino == "01"){
					var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
					var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
					var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
					consoleLog("fechaInicio: " + fechaInicio.getTime()+ " fechaDocumentoComprobante: " + fechaDocumentoComprobante.getTime());
					if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
						disabledElement("btnGrabarComprobante");
						disabledElement("btnGrabarAuxComprobante");	
					}	
					else{
						enabledElement("btnGrabarComprobante");
						enabledElement("btnGrabarAuxComprobante");
					}
				}else if (tipoDestino == "02"){
					var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
					var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
					var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
						if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
							disabledElement("btnGrabarComprobante");
							disabledElement("btnGrabarAuxComprobante");	
						}	
						else{
							enabledElement("btnGrabarComprobante");
							enabledElement("btnGrabarAuxComprobante");
						}
				}  
			}
		}
    }//BOLETO DE VIAJE
    else if (getValueInputText("selTipoDocumentoComprobante") == "915" || getValueInputText("selTipoDocumentoComprobante") == "067") {
    	
	    if(tipoDestino == "01"){    		
	    	if( $.trim(sustentoLugar) == "" || $.trim(valorVenta) == "0.00" ||  $.trim(valorTotal) == "0.00" || $.trim(fecha) == "" ||  validaEstadoGeneral == 0 ||  $.trim(ruc) == ""  ||  $.trim(numeroDocumento)== "" || $.trim(serie)== ""  ||  ($.trim(tipoConcepto) == "" && $.trim(tipoConcepto) == "00") || $.trim(clasificadorGasto) == ""){
    			disabledElement("btnGrabarComprobante");
				disabledElement("btnGrabarAuxComprobante");
			}else{				
				if($.trim(fecha) != ""){
					if(tipoDestino == "01"){
						var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
						var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
						var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
						consoleLog("fechaInicio: " + fechaInicio.getTime()+ " fechaDocumentoComprobante: " + fechaDocumentoComprobante.getTime());
						if (fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
							disabledElement("btnGrabarComprobante");
							disabledElement("btnGrabarAuxComprobante");
						}	
						else{
							enabledElement("btnGrabarComprobante");
							enabledElement("btnGrabarAuxComprobante");
						}
					}else if (tipoDestino == "02"){
						var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
						var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
						var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
							if (fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
								disabledElement("btnGrabarComprobante");
								disabledElement("btnGrabarAuxComprobante");
							}	
							else{
								enabledElement("btnGrabarComprobante");
								enabledElement("btnGrabarAuxComprobante");
							}
					}	
				
				}
			}
	    }else{ if(tipoDestino == "02") {
			    	if( $.trim(sustentoLugar) == "" || $.trim(valorVenta) == "0.00" ||  $.trim(valorTotal) == "0.00" || $.trim(fecha) == "" ||  validaEstadoGeneral == 0  ||  $.trim(numeroDocumento)== "" || $.trim(serie)== ""  ||  ($.trim(tipoConcepto) == "" && $.trim(tipoConcepto) == "00") || $.trim(clasificadorGasto) == ""){
						disabledElement("btnGrabarComprobante");
						disabledElement("btnGrabarAuxComprobante");
					}else{
						   if($.trim(fecha) != ""){	
								if(tipoDestino == "01"){
									var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
									var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
									var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
									consoleLog("fechaInicio: " + fechaInicio.getTime()+ " fechaDocumentoComprobante: " + fechaDocumentoComprobante.getTime());
									if (fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
										disabledElement("btnGrabarComprobante");
										disabledElement("btnGrabarAuxComprobante");
									}	
									else{
										enabledElement("btnGrabarComprobante");
										enabledElement("btnGrabarAuxComprobante");
									}
								}else if (tipoDestino == "02"){
									var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
									var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
									var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
										if (fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
											disabledElement("btnGrabarComprobante");
											disabledElement("btnGrabarAuxComprobante");
										}	
										else{
											enabledElement("btnGrabarComprobante");
											enabledElement("btnGrabarAuxComprobante");
										}
								}				
						   }	
					}
	    
	    		}//SELECCIONE
	    	}
	    }else if(getValueInputText("selTipoDocumentoComprobante") == "000"){

	}
	else {//OTROS
		consoleLog( "valorVenta: " + valorVenta + " valorTotal " + valorTotal + " fecha " + fecha + " validaEstadoGeneral " + validaEstadoGeneral + " ruc "+ ruc + " numeroDocumento " + numeroDocumento + " serie " + serie + " tipoConcepto " + tipoConcepto + " clasificadorGasto " + clasificadorGasto)
		if( $.trim(valorVenta) == "0.00" ||  $.trim(valorTotal) == "0.00" || $.trim(fecha) == "" ||  validaEstadoGeneral == 0 ||  $.trim(ruc) == ""  ||  $.trim(numeroDocumento)== "" || $.trim(serie)== ""  ||  ($.trim(tipoConcepto) == "" && $.trim(tipoConcepto) == "00") || $.trim(clasificadorGasto) == ""){
			
			disabledElement("btnGrabarComprobante");
			disabledElement("btnGrabarAuxComprobante");		
		}else{
			
		  if($.trim(fecha) != ""){
			if(tipoDestino == "01"){
				var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
				var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
				var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
				consoleLog("fechaInicio: " + fechaInicio.getTime() + " fechaFin: " +  fechaFin.getTime()  + " fechaDocumentoComprobante: " +fechaDocumentoComprobante.getTime());
				if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime() || fechaFin.getTime() < fechaDocumentoComprobante.getTime()){
					disabledElement("btnGrabarComprobante");
					disabledElement("btnGrabarAuxComprobante");
				}
				else {
					enabledElement("btnGrabarComprobante");
					enabledElement("btnGrabarAuxComprobante");
				}
			}else if (tipoDestino == "02"){
				var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
				var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
				var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
					if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime() || fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
						disabledElement("btnGrabarComprobante");
						disabledElement("btnGrabarAuxComprobante");
					}	
					else{
						enabledElement("btnGrabarComprobante");
						enabledElement("btnGrabarAuxComprobante");
					}
			}
				
		}
	  
	}
    
    }
    
}

