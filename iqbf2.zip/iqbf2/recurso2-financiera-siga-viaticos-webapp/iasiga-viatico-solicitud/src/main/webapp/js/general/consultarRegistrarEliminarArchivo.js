var parametroArchivo =new Object();
function initElementsConsultarRegistrarEliminarArchivo(dataParametrosArchivo){
	parametroArchivo.codigoBoleto = dataParametrosArchivo.codigoBoleto;
	parametroArchivo.estadoOrigen = dataParametrosArchivo.estadoOrigen;
	parametroArchivo.estadoLLamada = dataParametrosArchivo.estadoLLamada;
	parametroArchivo.aplicacion = dataParametrosArchivo.aplicacion;
	parametroArchivo.modulo = dataParametrosArchivo.modulo;
	parametroArchivo.numeroRegistroColaborador = dataParametrosArchivo.numeroRegistroColaborador;
	parametroArchivo.planViajeId = dataParametrosArchivo.planViajeId;
	parametroArchivo.paginaOrigen = dataParametrosArchivo.paginaOrigen;
	
	setInitElementsConsultarRegistrarEliminarArchivo(parametroArchivo);
	setInitConsultarRegistrarEliminarArchivoTable();
	callObtenerDatosAdjuntarArchivo(parametroArchivo);
}

function setInitElementsConsultarRegistrarEliminarArchivo(parametroArchivoTable) {
	var titulo="";
	var lblnumeroPlanilla="";
	addEventElement("btnAgregarArchivo", "click", clickBtnAgregarArchivo);
	addEventElement("btnEliminarArchivo", "click", clickBtnEliminarArchivo);
	addEventElement("btnSalirArchivo", "click", clickBtnSalirArchivo);
	addEventElement("btnCerrarArchivo", "click", clickBtnCerrarArchivo);
	addEventElement("btnSiMensajeEliminar", "click", clickBtnSiMensajeEliminar);
	addEventElement("btnNoMensajeEliminar", "click", clickBtnNoMensajeEliminar);
	
	
	if(parametroArchivoTable.estadoLLamada == "R"){
		titulo = adjuntarDocumento.tituloRegistro;		
		hideElement("divBtnConsulta");
		showElement("divBtnRegistro");
		//enabledElementForClass("chkGridArchivo");
		disabledElement("btnEliminarArchivo");
		
	}else if(parametroArchivoTable.estadoLLamada == "C" || parametroArchivoTable.estadoLLamada == "CE"){		
		titulo = adjuntarDocumento.tituloConsulta;
		hideElement("divBtnRegistro");
		showElement("divBtnConsulta");
		//disabledElementForClass("chkGridArchivo");
	}
	setHtmlElement("tituloAdjuntarDocumento", titulo);	
	
	if(parametroArchivoTable.estadoOrigen == "V"){
		lblnumeroPlanilla = adjuntarDocumento.numPlanilla;
	}else if(parametroArchivoTable.estadoOrigen == "R"){
		lblnumeroPlanilla = adjuntarDocumento.numSolicitudPlanilla;
	}
	
	setHtmlElement("spanNumeroPlanilla",lblnumeroPlanilla);
	
}

var listaDocumentosAdjuntos;
/*Inicio Codigo - Reutilizacion adjuntar archivo*/
var agregarArchivoBeforeMethod = function() {
	
};

var agregarArchivoAfterMethod = function(lista) {
	listaDocumentosAdjuntos = lista;
};
var agregarArchivoService = new AgregarArchivoService(agregarArchivoBeforeMethod, agregarArchivoAfterMethod);
/*Fin Codigo - Reutilizacion adjuntar archivo*/

function clickBtnSiMensajeEliminar(){
	callEliminarArchivo(parametroArchivo);
	//removeElementsConsultarRegistrarEliminarArchivo();
}

function clickBtnNoMensajeEliminar(){
	$('#divMensajeConfirmacionEliminar').modal('hide');
}

function clickBtnAgregarArchivo() {
	initElementsAgregarArchivo(parametroArchivo);
	$('#divAgregarArchivo').modal('show');
}

function clickBtnEliminarArchivo(){
	setHtmlElement("spaMensajeConfirmacionEliminarTitulo", adjuntarDocumento.textoConfimarEliminar);
	$("#divMensajeConfirmacionEliminar").modal("show");	
}

function clickBtnSalirArchivo(){
	adjuntarDocumentoService.adjuntarDocumentoAfter(listaDocumentosAdjuntos);
	$("#divAdjuntarDocumento").modal("hide");
	removeElementsConsultarRegistrarEliminarArchivo();
}

function clickBtnCerrarArchivo(){
	
	if ( typeof adjuntarDocumentoService != 'undefined' && adjuntarDocumentoService != null &&
	     typeof adjuntarDocumentoService.adjuntarDocumentoCerrarAfter != 'undefined' && adjuntarDocumentoService.adjuntarDocumentoCerrarAfter != null ) {

		if ( typeof parametroArchivo != 'undefined' && parametroArchivo.estadoLLamada == 'CE'  ) {
			
			adjuntarDocumentoService.adjuntarDocumentoCerrarAfter([]);	
		}
		
	}
	
	$("#divAdjuntarDocumento").modal("hide");
	removeElementsConsultarRegistrarEliminarArchivo();
}

function removeElementsConsultarRegistrarEliminarArchivo(){
	removeAllEventsElement("btnAgregarArchivo");
	removeAllEventsElement("btnEliminarArchivo");
	removeAllEventsElement("btnSalirArchivo");
	removeAllEventsElement("btnCerrarArchivo");
	var archivoTable = $("#tblArchivo");
}

function setInitConsultarRegistrarEliminarArchivoTable(){
	
	var archivoTable = $("#tblArchivo");
	var heightJqGrid = 115;
	if (archivoTable) {		
		var archivoTableDiv = $("#divArchivoTable");
			var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.viaticoModalContainer", ".viaticoModalContainerAuxiliar", "width"))/100);
			var widthTable = factorRedimensionamiento*archivoTableDiv.width();			
			archivoTable.jqGrid({
				width: widthTable,
				height: heightJqGrid,
				datatype: "local",
				autowidth: true,
				cmTemplate: {sortable: false},
			colNames:['N&uacute;mero','Numero Archivo','Nombre del Archivo','Tipo de Documento','Tama&ntilde;o','Fecha de registro','Selecci&oacute;n'],
			colModel:[
			          	{name:'secuenciaReg',key: true,index:'secuenciaReg', width:50, align:'center',hidden: true},
			          	{name:'numeroArchivo',index:'numeroArchivo', width:50, align:'center',hidden: true},
			          	{name:'fileName',index:'fileName', width:(6*widthTable/20),align:'left', formatter:'showlink',
							formatoptions:{baseLinkUrl:'viatico.htm', addParam: '&action=descargarArchivoAdjunto', idName:'secuenciaReg'}},
						{name:'tipoDoc',index:'tipoDoc', width:(4*widthTable/20),align:'center'},
						{name:'sizeTag',index:'sizeTag',  width:(4*widthTable/20) ,align:'center'},
						{name:'fecCargaTag',index:'fecCargaTag',  width:(4*widthTable/20) ,align:'center'},
						{name:'seleccion',index:'seleccion',  width:(2*widthTable/20) ,align:'center', formatter: formatterCheckBox }
					
			],
				viewrecords : true,
			    recordpos:'left',
				pagerpos:'center',
				altRows: true,
				multiselect: false,
			    multiboxonly: true,
			    headertitles: true,
			    hidegrid: false
		
		});
	}
	
}
var formatterCheckBox = function (cellvalue, options, rowObject){
	var secuenciaReg =   rowObject.secuenciaReg;
	if(parametroArchivo.estadoLLamada == "R"){
		return '<input name="chkGridArchivo" class="chkGridArchivo" id="'+secuenciaReg+'" type="checkbox" onclick="javascript:checkedSecuenciaRegistro(this);"/>';
	}else{
		return '<input name="chkGridArchivo" class="chkGridArchivo" id="'+secuenciaReg+'" type="checkbox" onclick="javascript:checkedSecuenciaRegistro(this);" disabled/>';
	}
}

function checkedSecuenciaRegistro(objeto){
	 var nombreClase = $(objeto).attr("class");
	
	 if($(objeto).is(':checked')){
		 $("."+nombreClase).each(function(){ 
			 if(!$(this).is(':checked')){
				 $(this).prop("disabled",true);
			 }
		 });	 
		 enabledElement("btnEliminarArchivo");
	 }else{
		 $("."+nombreClase).each(function(){ 
				 $(this).prop("disabled",false);
		 });
		 disabledElement("btnEliminarArchivo"); 
	 }
	 
}

function existenArchivosAdjuntos(dataParametrosArchivo, functionIfExists){
	
	$.ajax({
		url: contextPathUrl + "/viatico.htm?action=obtenerDatosArchivoAdjunto",
		data : {
			"codigoBoleto" : dataParametrosArchivo.codigoBoleto,
			"idPlanViaje": dataParametrosArchivo.planViajeId,
			"numeroRegitroColaborador" : dataParametrosArchivo.numeroRegistroColaborador,
			"paginaOrigen" : dataParametrosArchivo.paginaOrigen},
		type: "post",
		dataType: "json",
		cache:false,
		success:function(resultado){
			
			var listArchivosAdjuntos = resultado.listArchivosAdjuntos;
			if(listArchivosAdjuntos.length==0){
				showMensaje( 'No existen archivos adjuntos en la solicitud de vi&aacute;ticos ' + dataParametrosArchivo.codPlanilla );	
			}else{
				functionIfExists();
			}
			
		},
		error:function(){
			consoleLog("Error callObtenerDatosAdjuntarArchivo");
		},
	});
	
	
} 



function callObtenerDatosAdjuntarArchivo(parametroArchivoDatos){
	var archivoTable = $("#tblArchivo");
	archivoTable.jqGrid('clearGridData');
	$.ajax({
		url: contextPathUrl + "/viatico.htm?action=obtenerDatosArchivoAdjunto",
		data : {
			"codigoBoleto" : parametroArchivoDatos.codigoBoleto,
			"idPlanViaje": parametroArchivoDatos.planViajeId,
			"numeroRegitroColaborador" : parametroArchivoDatos.numeroRegistroColaborador,
			"paginaOrigen" : parametroArchivoDatos.paginaOrigen},
		type: "post",
		dataType: "json",
		cache:false,
		beforeSend: function(){
			
		},
		complete: function (){
			
		},
		success:function(resultado){
			
			setValueInputText("txtNombreColaboradorAdjuntar", resultado.comisionado);
			setValueInputText("txtUUOOAdjuntar", resultado.uuoo);
			setValueInputText("txtNumeroPlanillaAdjuntar", resultado.codigoPlanilla);
			setValueInputText("txtImporteDocumentoAdjuntar", resultado.montoTotal);
			
			var listArchivosAdjuntos = resultado.listArchivosAdjuntos;
			
			for(var i=0; i < listArchivosAdjuntos.length; i++){
				var archivo= listArchivosAdjuntos[i];
				var datarow = {
						secuenciaReg:archivo.sec_reg,
						numeroArchivo:archivo.num_reg,
						fileName:archivo.file_name,
						tipoDoc:archivo.tipo_doc,
						sizeTag:archivo.size_tag,
						fecCargaTag:archivo.fec_carga_tag,
						seleccion:'0'
							};
				var su= archivoTable.jqGrid('addRowData',archivo.sec_reg, datarow);
			}			
			agregarArchivoService.agregarArchivoAfter(listArchivosAdjuntos);
			archivoTable.trigger("reloadGrid");
			
			
		},
		error:function(){
			consoleLog("Error callObtenerDatosAdjuntarArchivo");
		},
	});
	
}

function obtenerRegistroSeleccionado(){
	var gridArchivo = $(".chkGridArchivo"); 
	var rowData="";
	var gridArchivoTable = $("#tblArchivo");
	var numeroSecuencia = "";
	gridArchivo.each(function(){ 
		 if($(this).is(':checked')){
			  numeroSecuencia = $(this).attr("id");
		 }
	 });
	rowData  = gridArchivoTable.getRowData(numeroSecuencia);
	return [rowData.numeroArchivo, rowData.secuenciaReg];
};

function callEliminarArchivo(parametroArchivoEliminar){
	var dataEliminar = obtenerRegistroSeleccionado();
	
	//consoleLog(dataEliminar[0]);
	
	var ajax_data ={"numeroRegitroArchivo"	:	dataEliminar[0],
			"numeroSecuencia" : dataEliminar[1],
			"paginaOrigen" : parametroArchivoEliminar.paginaOrigen,
			"codigoPlanViaje" : parametroArchivoEliminar.planViajeId,
			"codigoBoleto" : parametroArchivoEliminar.codigoBoleto};
	
	$.ajax({	
	    url: contextPathUrl+"/registroGeneral.htm?action=eliminarArchivoFisico",				
		data: ajax_data,
		type: "post",
		dataType: "json",
		beforeSend:function(){
			showModalElement("divScreenBlock");
		},
		complete: function(){
			hideModalElement("divScreenBlock");
		},
		success: function(respuesta) {
				if(respuesta.mensaje == "OK"){
					var listArchivosAdj = respuesta.listArchivosAdj;
					if(listArchivosAdj.length == 0){
						var archivoTable = $("#tblArchivo");
						archivoTable.jqGrid('clearGridData');
						agregarArchivoService.agregarArchivoAfter(listArchivosAdj);
						
					}
					else{
						var archivoTable = $("#tblArchivo");
						archivoTable.jqGrid('clearGridData');
						for(var i=0; i<listArchivosAdj.length; i++){
							var archivo= listArchivosAdj[i];
							var datarow = {
									secuenciaReg:archivo.sec_reg,
									numeroArchivo:archivo.num_reg,
									fileName:archivo.file_name,
									tipoDoc:archivo.tipo_doc,
									sizeTag:archivo.size_tag,
									fecCargaTag:archivo.fec_carga_tag,
									seleccion:'0'
										};
							var su=archivoTable.jqGrid('addRowData',archivo.sec_reg, datarow);											
						}
						archivoTable.trigger("reloadGrid");						
						agregarArchivoService.agregarArchivoAfter(listArchivosAdj);
					}
					disabledElement("btnEliminarArchivo");
					$('#divMensajeConfirmacionEliminar').modal('hide');
				}else{
					setHtmlElement("spaMensajeError", adjuntarDocumento.errorEliminar);
            		$("#divMensajeError").modal("show");
				}
			},
		error:function (xhr, ajaxOptions, thrownError) {}			 
	    });
}


