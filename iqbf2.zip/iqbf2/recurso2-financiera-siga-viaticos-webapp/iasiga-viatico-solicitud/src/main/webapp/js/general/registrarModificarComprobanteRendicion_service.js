function removeEventElementsRegistrarModificarComprobanteRendicion() {
	removeAllEventsElement("btnCerrarComprobante");
	removeAllEventsElement("btnGrabarComprobante");
	removeAllEventsElement("btnGrabarAuxComprobante");
	removeAllEventsElement("btnCerrarAuxComprobante");
	removeAllEventsElement("btnSiMensajeComprobante");
	removeAllEventsElement("btnNoMensajeComprobante");
	removeAllEventsElement("btnAceptarMensajeComprobante");
	removeAllEventsElement("btnAceptarMensajeWarningComprobante");
	removeAllEventsElement("btnAceptarMensajeErrorComprobante");
}

function removeTablesRegistrarModificarComprobanteRendicion() {
	var htmlElement = "<table id=\"tblDatosRendicion\"></table>";
	htmlElement += "<div id=\"divDatosRendicionPagerTable\"></div>";
	setHtmlElement("divDatosRendicionTable", htmlElement);
	
	var htmlElement = "<table id=\"tblDatosComprobantePago\"></table>";
	htmlElement += "<div id=\"divDatosComprobantePagoPagerTable\"></div>";
	setHtmlElement("divDatosComprobantePagoTable", htmlElement);
}

function ocultarMostrarColumna(idTabla, hideShowCol, columnaTabla){
	var table = $('#'+idTabla);
		table.jqGrid(hideShowCol,columnaTabla);
}

function bloqueoParametrosDocumentoComprobante(){
	disabledElement("selTipoDocumentoComprobante");
	disabledElement("txtRucComprobante");
	disabledElement("txtRazonSocialComprobante");
	disabledElement("txtSecuenciaComprobante");
	disabledElement("txtSerieDocumentoComprobante");
	disabledElement("txtNumeroDocumentoComprobante");
	disabledElement("etiquetaFechaDocumentoComprobante");
	disabledElement("selTipoConceptoComprobante");
	disabledElement("txtClasificadorGastoComprobante");
	disabledElement("txtSustentoLugarReferenciaComprobante");	
	disabledElement("montoBase");
	disabledElement("valorVenta");
	disabledElement("exoneracionIgv");
	disabledElement("otroGasto");
	disabledElement("valorTotal");
	disabledElement("montoTotal");
	disabledElementForClass("alimentacion");
	disabledElementForClass("hospedaje");
	disabledElementForClass("movilidad");
	disabledElementForClass("translado");
}

function bloqueoParametrosDocumentoComprobanteXAdventencia(){
	disabledElement("txtRucComprobante");
	disabledElement("txtRazonSocialComprobante");
	disabledElement("txtSecuenciaComprobante");
	disabledElement("txtSerieDocumentoComprobante");
	disabledElement("txtNumeroDocumentoComprobante");
	disabledElement("etiquetaFechaDocumentoComprobante");
	disabledElement("selTipoConceptoComprobante");
	disabledElement("txtClasificadorGastoComprobante");
	disabledElement("txtSustentoLugarReferenciaComprobante");	
	disabledElement("montoBase");
	disabledElement("valorVenta");
	disabledElement("exoneracionIgv");
	disabledElement("otroGasto");
	disabledElement("valorTotal");
	disabledElement("montoTotal");
	disabledElementForClass("alimentacion");
	disabledElementForClass("hospedaje");
	disabledElementForClass("movilidad");
	disabledElementForClass("translado");
}

function bloqueoEdicionDocumentoSustentatorio(){
	disabledElement("selTipoDocumentoComprobante");
	disabledElement("etiquetaFechaDocumentoComprobante");
	disabledElement("selTipoConceptoComprobante");
}

function onBlurMonto( objRef ) {
	var control = $( objRef );
	var igv = 0.00;
	var estadoMontoBAseValor = 0;
	var estadoOtrosGastos = 0;
	
	if($.trim(control.val()) == ""){
		control.val("0.00");		
	}		
	
	var importeDiario = control.val().replace(/,/g , '');
		
	if($.isNumeric(importeDiario)){
		var estado = control.data("tipo");									
		importeDiario = recortarDigitosEnteros( importeDiario, 8 );				
		control.val( roundComasMilesString( importeDiario, 2 )  );
		
		var valorVenta = getValueInputText("valorVenta");
		var montoBase = getValueInputText("montoBase");				
		var otroGasto = getValueInputText("otroGasto");
		var valorTotal = getValueInputText("valorTotal");
		var montoTotal = getValueInputText("montoTotal");
		var porcentajeIgv =  getValueInputText("igvActual");
		var estadoIgv = obtenerIgv();
		
		valorVenta = valorVenta.replace(/,/g , '');
		montoBase = montoBase.replace(/,/g , '');					
		otroGasto = otroGasto.replace(/,/g , '');
		valorTotal = valorTotal.replace(/,/g , '');
		montoTotal = montoTotal.replace(/,/g , '');
			
		if($.trim(estado) != ""){
			
				if(estadoIgv == "I" || estadoIgv == "E"){
					 igv = 0.00;			
					 
					 if(estado == "VV" || estado == "MB" || estado == "OG"){		
						 
						 var valorTotal = parseFloat(valorVenta) + parseFloat(otroGasto);
						 var montoTotal = parseFloat(montoBase) + parseFloat(otroGasto);
						 setValueInputText("valorTotal", roundComasMilesString(valorTotal, 2));
						 setValueInputText("montoTotal", roundComasMilesString(montoTotal, 2));
					 	 estadoMontoBAseValor =	validarMontoBaseValorVenta(estado);
						  
					}else if(estado == "VT" || estado == "MT"){
						 estadoOtrosGastos =  validarOtroGastoMayorMontoTotal();
						if(estadoOtrosGastos == 0){
						 	setValueInputText("otroGasto",roundComasMilesString(0.00, 2));									 
						 	var montoBase  = parseFloat(montoTotal);// - parseFloat(otroGasto);	
						 	var valorVenta = parseFloat(valorTotal);// - parseFloat(otroGasto);
						 	setValueInputText("montoBase",roundComasMilesString(montoBase, 2));
						 	setValueInputText("valorVenta",roundComasMilesString(valorVenta, 2));}
						 else if(estadoOtrosGastos == 1){
							//setValueInputText("otroGasto",roundComasMilesString(0.00, 2));		 	
							var montoBase  = parseFloat(montoTotal) - parseFloat(otroGasto);	
						 	var valorVenta = parseFloat(valorTotal) - parseFloat(otroGasto);
							setValueInputText("montoBase",roundComasMilesString(montoBase, 2));
						 	setValueInputText("valorVenta",roundComasMilesString(valorVenta, 2));
							estadoMontoBAseValor =	validarMontoBaseValorVenta(estado); 
						}
					 }	

					 consoleLog("estadoMontoBAseValor" + estadoMontoBAseValor);
				}else if(estadoIgv == "A" ){
					
					 if(estado == "VV" || estado == "OG" ){									 
						 igv = parseFloat(valorVenta) * porcentajeIgv;	
						 var valorTotal = parseFloat(valorVenta) + parseFloat(otroGasto) + igv;
						 setValueInputText("valorTotal", roundComasMilesString(valorTotal, 2))
					 	estadoMontoBAseValor =	validarMontoBaseValorVenta(estado);
					 }else	if(estado == "VT"){
						 estadoOtrosGastos = validarOtroGastoMayorMontoTotal();
						 if(estadoOtrosGastos == 0){
							var valorVenta  = parseFloat(valorTotal/(parseFloat(porcentajeIgv)+1));
							igv = roundComasMilesString(porcentajeIgv*valorVenta, 2);		
							igv = igv.replace(/,/g , '');
							setValueInputText("valorVenta",roundComasMilesString(valorVenta, 2));
							setValueInputText("otroGasto",roundComasMilesString(0.00, 2));
						 }else if(estadoOtrosGastos == 1){										 
							 var valorVenta  = parseFloat((valorTotal-otroGasto)/(parseFloat(porcentajeIgv)+1));
							igv = roundComasMilesString(porcentajeIgv*valorVenta, 2);		
							igv = igv.replace(/,/g , '');
							setValueInputText("valorVenta",roundComasMilesString(valorVenta, 2));
							//setValueInputText("otroGasto",roundComasMilesString(0.00, 2));
							estadoMontoBAseValor =	validarMontoBaseValorVenta(estado);
						 }
					}
					// if(estado != "OG")
						// if(estadoOtrosGastos == 1)
						// estadoMontoBAseValor =	validarMontoBaseValorVenta();							
				}						
				setHtmlElement("igv", roundComasMilesString(igv, 2 ));
				
		}	
					
	}else{
		control.val("0.00");
	}
			
	var montoTotalX1 = getValueInputText("montoTotal");
	if(estadoMontoBAseValor == 1){	
		var indExtDDJJ = getValueInputText("indExtDDJJ");
		
		if($.trim("indExtDDJJ") != ""){
			if(indExtDDJJ == "0"){
				
				//validamos las declaraciones juradas de comprobante de pago y declaraciones juradas de viaticos
				if(getValueInputText("selTipoDocumentoComprobante") == "906" || getValueInputText("selTipoDocumentoComprobante") == "907" ){
					
					var estadoValidaComprobantePago = validaComprobantePago();
					consoleLog("estadoValidaComprobantePago: " + estadoValidaComprobantePago);
					var idSelectorConcepto = getValueInputText("selTipoConceptoComprobante");
					
					//Si el comprobante de pago es valido y se trata de una asignacion nacional, 
					//entonces validamos que la suma distribuida sea correcta y que la asignacion de la declaracion tambien.
					if(idSelectorConcepto == "01"){					
						 var estadoSumaGeneralDistribucion = sumaGeneralDistribucion();
						 consoleLog("estadoSumaGeneralDistribucion:  " + estadoSumaGeneralDistribucion);
								if(estadoSumaGeneralDistribucion == 1)
									validarMontoxAsignacionDeclaracion();
					}
					
					//Si el comprobante de pago es valido y se trata de una asignacion internacional, entonces validamos solo la suma
					if(idSelectorConcepto == "12"){
						validarMontoxAsignacionDeclaracion();
					}
					
					
					if(idSelectorConcepto != "01" && idSelectorConcepto != "12"){
						validarMontoxAsignacion();
					}
										
				}else{
					//Si se trata de cualquier otro tipo de documento que no sea declaracion jurada o de comprobante
					var estadoValidaComprobantePago = validaComprobantePago();
					var idSelectorConcepto = getValueInputText("selTipoConceptoComprobante");
					
					if(estadoValidaComprobantePago == 1 && idSelectorConcepto == "01"){					
						var estadoSumaGeneralDistribucion = sumaGeneralDistribucion();
						if(estadoSumaGeneralDistribucion == 1)
							validarMontoxAsignacion();
					}
					
					//Todas las asignaciones menos la nacional que ya se valida en el segmento anterior.
					if(estadoValidaComprobantePago == 1 && idSelectorConcepto != "01"){
							validarMontoxAsignacion();
					}
				}
							
			}else if(indExtDDJJ == "1"){
				//Tipo de documento: Declaración Jurada Comprobante de Pago(906) o Tipo de documento: Declaración Jurada Viáticos(907)
				if(getValueInputText("selTipoDocumentoComprobante") == "906" ||getValueInputText("selTipoDocumentoComprobante") == "907" ){
					
					var estadoValidaComprobantePago = validaComprobantePago();
					var idSelectorConcepto = getValueInputText("selTipoConceptoComprobante");
					
					//cuando el concepto es asignacion nacional validamos la distribucion correcta de los montos
					if(estadoValidaComprobantePago == 1 && idSelectorConcepto == "01"){					
						sumaGeneralDistribucion();
						validarMontoxAsignacion();
					}
					
					if(estadoValidaComprobantePago == 1 && idSelectorConcepto != "01"){
						validarMontoxAsignacion();
					}
						
				}else{
					
					var estadoValidaComprobantePago = validaComprobantePago();
					var idSelectorConcepto = getValueInputText("selTipoConceptoComprobante");
					if(estadoValidaComprobantePago == 1 && idSelectorConcepto == "01"){					
						sumaGeneralDistribucion();
					}
					if(estadoValidaComprobantePago == 1 && idSelectorConcepto != "01"){
						validarMontoxAsignacion();
					}
				}
			}
		}			
	}
	var montoTotalX2 = getValueInputText("montoTotal");
	
	//al final siempre llamamos a validar el formulario
	validaFormulario();
	var montoTotalX3 = getValueInputText("montoTotal");
}

//SI 
function obtenerIgv(){	
	var igv="";
	if (getValueInputText("selTipoDocumentoComprobante") == "907" || getValueInputText("selTipoDocumentoComprobante") == "906" || getValueInputText("selTipoDocumentoComprobante") == "916" ){
		igv = getValueInputText("exoneracionFija");	
	}else{
		igv = getValueInputText("exoneracionIgv");
	}
	return igv;
}


//SI 
function recortarDigitosEnteros( numeroString, maxDigEnteros ) {	
	if ( isNullOrUndefined( numeroString )  ) return numeroString;	
	var num = (numeroString + '').replace(/,/g , '');	
	var posComa = num.indexOf( '.' );	
	if ( posComa >= 0 ) {	
		var izq = num.substring( 0, posComa );
		var der = num.substring( posComa + 1, num.length );	
		if ( izq.length > maxDigEnteros ) {
			izq = izq.substring( 0, maxDigEnteros );
		}		
		num = izq + '.' + der;		
	} else {	
		if ( num.length > maxDigEnteros ) {
			num = num.substring( 0, maxDigEnteros );
		}			
	}	
	return num;
} 

//SI 
function isNullOrUndefined( valor ) {
	return valor == null || ( typeof valor == 'undefined' );
}

//SI 
function roundComasMilesString( valor, digitos ) {
	var val = roundString( valor, digitos );
	var parts = val.toString().split(".");
	return parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",") + (parts[1] ? "." + parts[1] : "");
}

//SI 
function roundString( valor, digitos ) {
	// redondear
	var round = redondearNumeros( digitos, parseFloat( valor ) );
	// formatear completando el nro de digitos en los decimales
	var result = round.toFixed( digitos ) + '';
	return result;
}

//SI
function onBlurGastoItinerario( objRef ) {
	// recoge el valor ingresado, lo formatea y actualiza en el modelo/asignaciones
	var control = $( objRef );
	var fecha =  control.attr("id").split('_');
		
	var importeDiario = null;
	if($.trim(control.val()) != ""){
		importeDiario = control.val().replace(/,/g , '');
	}else{
		control.val("0.00");
		importeDiario = 0.00;		
	}	
	
	if($.isNumeric(importeDiario)){
		var estado = control.data("tipo");
		// en bd es 10,2												
		importeDiario = recortarDigitosEnteros( importeDiario, 8 );				
		control.val( roundComasMilesString( importeDiario, 2 ));				
		var alimentacion = getValueInputText("alimentacion_" + fecha[1]);
		var hospedaje = getValueInputText("hospedaje_" +  fecha[1]);				
		var movilidad = getValueInputText("movilidad_" + fecha[1]);
		var translado = getValueInputText("translado_" + fecha[1]);				
		alimentacion = alimentacion.replace(/,/g , '');
		hospedaje = hospedaje.replace(/,/g , '');					
		movilidad = movilidad.replace(/,/g , '');
		translado = translado.replace(/,/g , '');			
			sumaValoresIteracion(fecha[1], alimentacion, hospedaje, movilidad, translado);
			sumaValoresIteracionFooter();
	}else{
		control.val("0.00");
	}
	
	var total  = parseFloat(alimentacion) + parseFloat(hospedaje) + parseFloat(movilidad) + parseFloat(translado);
	total =  total.toFixed(2);
	var idSelectorConcepto = getValueInputText("selTipoConceptoComprobante");		
	//if(idSelectorConcepto == "01" || idSelectorConcepto == "12"){
	//La validacion en detalle solo aplica para las nacionales...
	
	if(idSelectorConcepto == "01"){
		//valida que el monto total del comprobante no sea mayor al monto distribuido o para casos de ddjj que sea igual al monto distribuido
		
		//Si los datos para esa fecha son validos...
		var estadoValidarMontoxFecha =  validarMontoxFecha(total, fecha[1]);
		if(estadoValidarMontoxFecha == 1){
			
			if(validaComprobantePago()==1){
				var sumaOk = sumaGeneralDistribucion();
				if(sumaOk==1){
					var indExtDDJJ = getValueInputText("indExtDDJJ");
					if(indExtDDJJ == "0"){
						if (getValueInputText("selTipoDocumentoComprobante") == "907" || getValueInputText("selTipoDocumentoComprobante") == "906"){
							validarMontoxAsignacionDeclaracion();
						}else{
							validarMontoxAsignacion();
						}			
					}else if(indExtDDJJ == "1"){
						validarMontoxAsignacion();
					}	
				}
				
			}	
			
		}
					
				
	}else{
		var estadoValidaComprobantePago = validaComprobantePago();
		if(estadoValidaComprobantePago == 1){			
			validarMontoxAsignacion();			
		}
	}
	validaSustentoLugar();
}


//SI 
function sumaValoresIteracionFooter(){
	var alimentacionSum = 0;
	var hospedajeSum = 0;
	var movilidadSum = 0;
	var transladoSum = 0;
	
	$(".fechaViatico").each(function(){
		var fecha = $(this).attr("id").split('_'); 
			if(fecha[1] != "undefined"){
				var alimentacion =  getValueInputText("alimentacion_" + fecha[1]);
				var hospedaje = getValueInputText("hospedaje_" +  fecha[1]);				
				var movilidad =  getValueInputText("movilidad_" + fecha[1]);
				var translado =  getValueInputText("translado_" + fecha[1]);				
				alimentacion = alimentacion.replace(/,/g , '');
				hospedaje = hospedaje.replace(/,/g , '');					
				movilidad = movilidad.replace(/,/g , '');
				translado = translado.replace(/,/g , '');				
				alimentacionSum = alimentacionSum + parseFloat(alimentacion);		
				hospedajeSum = hospedajeSum + parseFloat(hospedaje);		
				movilidadSum = movilidadSum + parseFloat(movilidad);		
				transladoSum = transladoSum + parseFloat(translado);
			}		
	});
	
	var total = alimentacionSum + hospedajeSum + movilidadSum + transladoSum;
	
	setValueInputText("alimentacion_undefined", roundComasMilesString(alimentacionSum, 2));
	setValueInputText("hospedaje_undefined", roundComasMilesString(hospedajeSum, 2));
	setValueInputText("movilidad_undefined", roundComasMilesString(movilidadSum, 2));
	setValueInputText("translado_undefined", roundComasMilesString(transladoSum, 2));
	setHtmlElement("total_undefined", roundComasMilesString(total, 2));
	//validaFormulario();
}

function sumaValoresIteracion (fecha, alimentacion, hospedaje, movilidad, translado){	
	var total  = parseFloat(alimentacion) + parseFloat(hospedaje) + parseFloat(movilidad) + parseFloat(translado);
	//validarMontoxFecha(total, fecha);
	setHtmlElement("total_"+fecha, roundComasMilesString(total, 2));
}

function showMessageErrorComprobante(etiquetaError, errorMessage, divError) {
	setHtmlElement(etiquetaError, errorMessage);
	showElement(divError);
}


function cambioIgv(){
	
	var estadoIgv = getValueInputText("exoneracionIgv");
	 if(estadoIgv == "A"){		 
		 	var porcentajeIgv = getValueInputText("igvActual");		
			var valorVenta = getValueInputText("valorVenta");
			valorVenta = valorVenta.replace(/,/g , '');
			valorVenta  = parseFloat(valorVenta);				
			var otroGasto = getValueInputText("otroGasto");
			otroGasto = otroGasto.replace(/,/g , '');
			otroGasto  = parseFloat(otroGasto);			
			setHtmlElement("igv", roundComasMilesString(porcentajeIgv*valorVenta, 2));			
			setValueInputText("valorTotal", roundComasMilesString(otroGasto + (porcentajeIgv*valorVenta) + valorVenta, 2));						
	 }else if(estadoIgv == "E"){		
			var valorVenta = getValueInputText("valorVenta");
			valorVenta = valorVenta.replace(/,/g , '');
			valorVenta  = parseFloat(valorVenta);			
			var otroGasto = getValueInputText("otroGasto");
			otroGasto = otroGasto.replace(/,/g , '');
			otroGasto  = parseFloat(otroGasto);
			setHtmlElement("igv","0.00");			
			setValueInputText("valorTotal", roundComasMilesString(otroGasto + valorVenta, 2));
			
	 }else if (estadoIgv == "I"){
		 	var valorVenta = getValueInputText("valorVenta");
			valorVenta = valorVenta.replace(/,/g , '');
			valorVenta  = parseFloat(valorVenta);			
			var otroGasto = getValueInputText("otroGasto");
			otroGasto = otroGasto.replace(/,/g , '');
			otroGasto  = parseFloat(otroGasto);
			setHtmlElement("igv","0.00");			
			setValueInputText("valorTotal", roundComasMilesString(otroGasto + valorVenta, 2));
	 }
	 onBlurMonto($("#valorTotal"));
	 //validaEstadoGeneral = 1;
	 validaFormulario();
}





