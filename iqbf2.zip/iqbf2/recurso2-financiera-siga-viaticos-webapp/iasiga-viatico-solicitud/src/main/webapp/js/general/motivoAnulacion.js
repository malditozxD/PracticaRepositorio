function initElementsMotivoAnulacionSolicitud(numRegistro,nomColaborador,nomDependencia,codPlanilla,importe,codUUOO) {
	$("#codPlanillaAnulacionTemp").val(codPlanilla);
	$("#cabAnulacion1").html(cabeceraAnulacion1(numRegistro,nomColaborador,nomDependencia,codUUOO));
	$("#cabAnulacion2").html(cabeceraAnulacion2(codPlanilla,importe));
	setHtmlElement("codPlanillaAnular",codPlanilla + "?");
	setInitElementsMotivoAnularSolicitud();
	setInitDataMotivoAnulacion();
	
}

function setInitElementsMotivoAnularSolicitud() {
	addEventElement("btnAceptarAnulacion", "click", clickBtnAceptarAnulacion);
	addEventElement("btnCancelarAnulacion", "click", clickBtnCancelarAnulacion);
	addEventElement("txtareaMotivoAnulacion", "focusout", blurTxtareaMotivoAnulacion);
	addEventElement("btnSiMensajeConfirmacionFinalizarAnulacion", "click", clickBtnSiMensajeConfirmacionFinalizarAnulacion);
	addEventElement("btnNoMensajeConfirmacionFinalizarAnulacion", "click", clickBtnNoMensajeConfirmacionFinalizarAnulacion);
	addEventElement("btnOkMensajeConfirmacionFinalizarAnulacion", "click", clickBtnOkMensajeConfirmacionFinalizarAnulacion);
	addEventElement("btnOkMensajeConfirmaAnulacion", "click", clickBtnOkMensajeConfirmaAnulacion);
	addEventElement("btnAlertMensajeErrorAnular" ,"click", clickBtnAlertMensajeErrorAnular);
}

function cabeceraAnulacion1(numRegistro,nomColaborador,nomDependencia,codUUOO) {
	var str="";
	str += "	<div class=\"col-xs-12 col-sm-3 col-md-2 col-lg-2\">";
	str += "		<label for=\"txtNombreColaborador\" class=\"text-muted alineartext\">Comisionado:<\/label>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-9 col-md-4 col-lg-4\">";
	str += "		<input class=\"form-control input-sm margen-input\" type=\"text\"";
	str += "			id=\"txtNombreColaborador\" name=\"txtNombreColaborador\" readonly=\"readonly\" value=\""+numRegistro +" - "+ nomColaborador+"\"><\/input>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-3 col-md-2 col-lg-2\">";
	str += "		<label for=\"txtNumUUOO\" class=\"text-muted alineartext\">UUOO:<\/label>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-9 col-md-4 col-lg-4\">";
	str += "		<input class=\"form-control input-sm margen-input\"  type=\"text\"";
	str += "			id=\"txtNumUUOO\" name=\"txtNumUUOO\"  readonly=\"readonly\" value=\""+ codUUOO +" - "+ nomDependencia+"\"><\/input>";
	str += "	<\/div>";
	return str;
} 

function cabeceraAnulacion2(codPlanilla,importe) {
	var str="";
	str += "	<div class=\"col-xs-12 col-sm-3 col-md-2 col-lg-2\">";
	str += "		<label for=\"txtNumPlanilla\" class=\"text-muted alineartext\">N&deg; Planilla:<\/label>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-9 col-md-4 col-lg-4\">";
	str += "		<input class=\"form-control input-sm margen-input\" type=\"text\"";
	str += "			id=\"txtNumPlanilla\" name=\"txtNumPlanilla\" readonly=\"readonly\" value=\""+codPlanilla +"\"><\/input>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-3 col-md-2 col-lg-2\">";
	str += "		<label for=\"txtImporte\" class=\"text-muted alineartext\">Importe Registrado:<\/label>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-9 col-md-4 col-lg-4\">";
	str += "		<input class=\"form-control input-sm margen-input\"  type=\"text\"";
	str += "			id=\"txtImporte\" name=\"txtImporte\"  readonly=\"readonly\" value=\""+ importe +"\"><\/input>";
	str += "	<\/div>";	
	return str;
} 

function setInitDataMotivoAnulacion() {
	var fechaAnulacion = getCurrentDateFormatEsp();
	$('#txtFecAnulacion').val(fechaAnulacion);
}

function clickBtnCancelarAnulacion() {
	$('#txtareaMotivoAnulacion').val("");
	removeEventElementsMotivoAnularSolicitud();
	$('#divMotivoAnulacionSolicitud').modal('hide');
}

function removeEventElementsMotivoAnularSolicitud() {
	removeAllEventsElement("btnCancelarAnulacion");
	removeAllEventsElement("btnAceptarAnulacion");
	removeAllEventsElement("txtareaMotivoAnulacion");	
	removeAllEventsElement("btnSiMensajeConfirmacionFinalizarAnulacion");
	removeAllEventsElement("btnNoMensajeConfirmacionFinalizarAnulacion");
	removeAllEventsElement("btnOkMensajeConfirmacionFinalizarAnulacion");
}

function ejecucionAnulacion() {
	
	$( 'divAlertMensajeErrorAnularMsg' ).html( '' );
	
	$.ajax({
		data: {
			"numeroRegistrador": getTrimValue( "#hidNumeroRegistroRegistrador" ),	
			"codigoRegistrador": getTrimValue( "#hidCodigoRegistrador" ),
			"codigoDocumento": getTrimValue( "#codPlanillaAnulacionTemp" ),
			"motivoAnulacion": getTrimValue( "#txtareaMotivoAnulacion" )
		},
		url: contextPathUrl + "/registrarSolicitud.htm?action=anularSolicitud",
		type: "post",
		dataType: "json",
		cache: false,
		success: function(result) {
			
			// error inesperado ajax app
			if ( huboErrorAjax( result ) ) {
				handleErrorAjax( result );
				return;
			}
			
			$('#divMensajeConfirmacionFinalizarAnulacion').modal('hide');
			clickBtnNoMensajeConfirmacionFinalizarAnulacion();
			
			if ( result.actualizado == "1" ) {
				
				$('#divMensajeConfirmaAnulacion').modal('show');
				
			} else{ 
				
				$( '#divAlertMensajeErrorAnular' ).modal("show");
				
				if ( $.trim( result.msgActualizado ) != '' ) {
					$( '#divAlertMensajeErrorAnularMsg' ).html( result.msgActualizado );
				}
				
			}
			
		},
		error: function( error ) {
			handleError( error );
		}
	});
}

function clickBtnSiMensajeConfirmacionFinalizarAnulacion() {
	ejecucionAnulacion();
}

function clickBtnNoMensajeConfirmacionFinalizarAnulacion() {
	
	$('#divMensajeConfirmacionFinalizarAnulacion').modal('hide');
}

function clickBtnOkMensajeConfirmacionFinalizarAnulacion() {

	var motivoAnulacion = $.trim( $("#txtareaMotivoAnulacion").val() );
	
	if (motivoAnulacion != "") {
		clickBtnConsultarSolicitud();	
	}
	
	$('#divMensajeConfirmacionOkFinalizarAnulacion').modal('hide');
	$('#divMensajeConfirmacionFinalizarAnulacion').modal('hide');
	$('#divMotivoAnulacionSolicitud').modal('hide');
	
	removeEventElementsMotivoAnularSolicitud();
	actualizarGridBandejaAnulacion();
}


function clickBtnOkMensajeConfirmaAnulacion() {
	var motivoAnulacion = $("#txtareaMotivoAnulacion").val();
	
	if (trimText(motivoAnulacion) != "") {
		$('#txtareaMotivoAnulacion').val("");
		clickBtnConsultarSolicitud();
	}
	
	$('#divMensajeConfirmaAnulacion').modal('hide');
	$('#divMensajeConfirmacionFinalizarAnulacion').modal('hide');
	$('#divMotivoAnulacionSolicitud').modal('hide');	
	removeEventElementsMotivoAnularSolicitud();
	actualizarGridBandejaAnulacion();
}


function actualizarGridBandejaAnulacion(){
	
	$('#txtareaMotivoAnulacion').val("");
	
	clickBtnCancelarAnulacion();
}

function blurTxtareaMotivoAnulacion() {

	var OBSERVACION_MAX_SIZE = 1000;
	
	// evita que se ingrese mas de 1000 caracteres (en IE8,9 no funciona el maxlength)
	var control = $( '#txtareaMotivoAnulacion' );
	var controlValue = $.trim( control.val() );
	
	if ( controlValue.length > OBSERVACION_MAX_SIZE ) {
		controlValue = controlValue.substring(0, OBSERVACION_MAX_SIZE);
		control.val( controlValue  );
	}
	
}

function clickBtnAceptarAnulacion() {
	var motivoAnulacion = $.trim( $( "#txtareaMotivoAnulacion" ).val() );
	
	if (motivoAnulacion != "" ) {
		$('#divMensajeConfirmacionFinalizarAnulacion').modal('show');
		
	} else {
		//$("#mensajeFinAnular").html("Se debe de ingresar un motivo de anulaci&oacute;n v&aacute;lido.");
		$('#divMensajeConfirmacionOkFinalizarAnulacion').modal('show');
	}	
}

function clickBtnAlertMensajeErrorAnular() {
	
	$("#divAlertMensajeErrorAnular").modal("hide");
}
