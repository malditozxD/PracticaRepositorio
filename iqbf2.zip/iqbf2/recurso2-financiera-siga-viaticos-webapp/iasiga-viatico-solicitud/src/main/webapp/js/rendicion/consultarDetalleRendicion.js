function initElementsDetalleRendicion(idElementCallModal, codPlanViaje,nomTipoViatico,codPlanilla,nomColaborador) {
	$("#cabDetalleRendicion").html(cabeceraDetalle(codPlanilla,nomColaborador));
	setInitElementsRendicion();
	setInitDetalleRendicionTable();
	callObtenerDetalleRendicion(codPlanViaje);
	resizeTable("divDetalleTableRendicion");
}

function cabeceraDetalle(codPlanilla, nomColaborador) { 
	var str="";
	str += "<div class=\"row\">";
	str += "	<div class=\"col-xs-12 col-sm-3 col-md-2 col-lg-2\">";
	str += "		<label for=\"txtNumPlanilla\" class=\"text-muted alineartext\">N&deg; Planilla:<\/label>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-9 col-md-4 col-lg-4\">";
	str += "		<input class=\"form-control input-sm margen-input\"  type=\"text\"";
	str += "			id=\"txtNumPlanilla\" name=\"txtNumPlanilla\" readonly=\"readonly\" value=\""+codPlanilla+"\"\/>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-3 col-md-2 col-lg-2\">";
	str += "		<label for=\"txtNombreColaborador\" class=\"text-muted alineartext\">Comisionado:<\/label>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-9 col-md-4 col-lg-4\">";
	str += "		<input class=\"form-control input-sm margen-input\" type=\"text\"";
	str += "			id=\"txtNombreColaborador\" name=\"txtNombreColaborador\" readonly=\"readonly\" value=\""+nomColaborador+"\"><\/input>";
	str += "	<\/div>";
	str += "<\/div>";
	return str;
} 

function setInitElementsRendicion() {
	addEventElement("btnCerrarDetalleRendicion", "click", clickBtnCerrarDetalleRendicion);
}

function clickBtnCerrarDetalleRendicion() {
	$('#divConsultarDetalleRendicion').modal('hide');
}



function setInitDetalleRendicionTable() {
	var detalleRendicionTable = $("#tblDetalleRendicion");
	var detalleRendicionTable2 = $("#tblDetalleRendicion2");
	if (detalleRendicionTable) {
		//Para el DivWitdh se utilizo un componente que llama al modal
		var detalleRendicionTableDiv = $("#divBandejaRendicionTable");
		var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.viaticoModalContainer", ".viaticoModalContainerAuxiliar", "width"))/100);
		var widthTable = factorRedimensionamiento*detalleRendicionTableDiv.width();
		detalleRendicionTable.jqGrid({
			width: widthTable,
			height: 70,
			datatype: "local",
			rowNum: 10,
			rowList: [10, 20],
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames:[
				"UUOO Comisionado",
				"Fecha de Salida",
				"Fecha de Retorno",
				"Itinerario",
				"Canal de Atenci&oacute;n",
				"Total d&iacute;as de la Comisi&oacute;n",
				"Motivo de la Comisi&oacute;n",
				"Asignaci&oacute;n de Pasajes",
				"Otros",
				"Importe Total Otorgado",
				"Nombre del Registrador"
			],
			colModel:[
			    {name: "nomUuOoCom", index: "nomUuOoCom",  width: (1.5*widthTable/12)},
			    {name: "fecSalida", index: "fecSalida", align:'center', width: (0.8*widthTable/12)},
				{name: "fecRetorno", index: "fecRetorno", align:'center', width: (0.8*widthTable/12)},
				{name: "itinerario", index: "itinerario", align:'center', width: (1*widthTable/12), hidden: false},
				{name: "canalAtencion", index: "canalAtencion", width: (1.5*widthTable/12), hidden: false},
				{name: "numDias", index: "numDias", align:'center', width: (0.5*widthTable/12)},
				{name: "motivoComis", index: "motivoComis", width: (1.7*widthTable/12), hidden: false},
				{name: "impAsigPasajes", index: "impAsigPasajes", align:'right', width: (0.8*widthTable/12), hidden: false},
				{name: "impOtros", index: "impOtros", align:'right', width: (0.7*widthTable/12)},
				{name: "impTotalOtorgado", index: "impTotalOtorgado", align:'right', width: (0.9*widthTable/12)},
				{name: "nomRegistrador", index: "nomRegistrador", width: (1.8*widthTable/12)}
			],
			//pager : "#divColaboradorPagerTable2",
			loadui: "disable"
		});
	}
	
	if (detalleRendicionTable2) {
		//Para el DivWitdh se utilizo un componente que llama al modal
		detalleRendicionTable2.jqGrid({
			width: widthTable,
			height: 70,
			datatype: "local",
			rowNum: 10,
			rowList: [10, 20],
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames:[
				"Alojamiento",
				"Alimentaci&oacute;n",
				"Movilidad Local",
				"Traslado al del Terminal",
				"Pasajes",
				"Importe Gastado",
				"Importe Devuelto",
				"Devoluci&oacute;n de Menor Gasto",
				"Nro Recibo Provisional",
				"Fecha Pago Caja Ch."
			],
			colModel:[
			    {name: "impGastoAloj", index: "impGastoAloj", width: (1.4*widthTable/12),align: 'right'},
			    {name: "impGastoAlim", index: "impGastoAlim", width: (1.4*widthTable/12),align: 'right' },
				{name: "impGastoMovLocal", index: "impGastoMovLocal", width: (1.4*widthTable/12),align: 'right'},
				{name: "impGastoTraslado", index: "impGastoTraslado", width: (1.4*widthTable/12), align: 'right', hidden: false},
				{name: "impGastoPasajes", index: "impGastoPasajes", width: (1.4*widthTable/12), align: 'right', hidden: false},
				{name: "impGasto", index: "impGasto", width: (1.4*widthTable/12), align: 'right', hidden: false },
				{name: "impDevuelto", index: "impDevuelto", width: (0.9*widthTable/12), align: 'right', hidden: false},
				{name: "impDevolMenor", index: "impDevolMenor", width: (0.9*widthTable/12), align: 'right' },
				{name: "numReciboProv", index: "numReciboProv", width: (1*widthTable/12) ,align: 'center' },
				{name: "fecPagoCajaCh", index: "fecPagoCajaCh", width: (0.9*widthTable/12) ,align: 'center' }
			],
			//pager : "#divColaboradorPagerTable2",
			loadui: "disable"
		});
	}
	detalleRendicionTable.clearGridData();
	detalleRendicionTable2.clearGridData();
}

function callObtenerDetalleRendicion(codPlanViaje) {
	setTimeout(function(){
		var detalleRendicionTable = $("#tblDetalleRendicion");
		var detalleRendicionTable2 = $("#tblDetalleRendicion2");
		detalleRendicionTable.clearGridData();
		detalleRendicionTable2.clearGridData();
		$.ajax({
			url: contextPathUrl + "/rendicion.htm?action=buscarRendicionDetalle",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codPlanViaje": codPlanViaje
			},
			beforeSend: function() {
				showElement("divLoadingDetalleRendicion");
			},
			complete: function() {
				hideElement("divLoadingDetalleRendicion");
			},
			success: function(result) {
				var detalleList = result.detalleList;
				if (detalleList != null && detalleList.length > 0) {
					
					for (var i = 0; i < detalleList.length; i++) {
						var detalle = detalleList[i];
						var datarow = {
							numeroSecuencial: (i + 1),
							nomUuOoCom: detalle.nomUuOoCom,
							fecSalida: detalle.fecSalida,
							fecRetorno: detalle.fecRetorno,
							itinerario: detalle.itinerario,
							canalAtencion: detalle.canalAtencion,
							numDias: detalle.numDias,
							motivoComis: detalle.motivoComis,
							impAsigPasajes: detalle.impAsigPasajes,
							impOtros: detalle.impOtros,
							impTotalOtorgado: detalle.impTotalOtorgado,
							nomRegistrador: detalle.nomRegistrador
						};
						var datarow2 = {
							numeroSecuencial2: (i + 1),
							impGastoAloj: detalle.impGastoAloj,
							impGastoAlim: detalle.impGastoAlim,
							impGastoMovLocal: detalle.impGastoMovLocal,
							impGastoTraslado: detalle.impGastoTraslado,
							impGastoPasajes: detalle.impGastoPasajes,
							impGasto: detalle.impGasto,
							impDevuelto: detalle.impDevuelto,
							impDevolMenor: detalle.impDevolMenor,
							numReciboProv: detalle.numReciboProv,
							fecPagoCajaCh: detalle.fecPagoCajaCh
							};
						detalleRendicionTable.jqGrid("addRowData", datarow.numeroSecuencial, datarow);
						detalleRendicionTable2.jqGrid("addRowData", datarow2.numeroSecuencial2, datarow2);
					}
					detalleRendicionTable.trigger("reloadGrid");
					detalleRendicionTable2.trigger("reloadGrid");
				}
				else {
					//
				}
			},
			error: function() {
				//
			}
		});
	}, 1000);
}