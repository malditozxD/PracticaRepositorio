function initElementsObservarDocumento(dataParametrosObservarDocumento) {
	setInitElementsObservarDocumento(dataParametrosObservarDocumento);
}

function setInitElementsObservarDocumento(dataParametrosObservarDocumento) {
	
	hideElement("divErrorObservarDocumento");
	if (dataParametrosObservarDocumento.codigoPaginaCaller != "01" && dataParametrosObservarDocumento.codigoPaginaCaller != "02") {
		setTextLabel("lblNumeroPlanillaObservarDocumento", propertyMessageObservarDocumento.nroSolicitudReembolso);
	}
	setValueInputText("hidCodPlanViajeObservarDocumento", dataParametrosObservarDocumento.codPlanViaje);
	setValueInputText("hidCodPerAutorizaObservarDocumento", dataParametrosObservarDocumento.codPerAutoriza);
	setValueInputText("hidCodigoSedeAutorizadorObservarDocumento", dataParametrosObservarDocumento.codigoSedeAutorizador);
	setValueInputText("hidExpedientePlanViajeObservarDocumento", dataParametrosObservarDocumento.expedientePlanViaje);
	setValueInputText("hidCodigoPaginaCallerObservarDocumento", dataParametrosObservarDocumento.codigoPaginaCaller);
	setValueInputText("txtNumeroPlanillaObservarDocumento", dataParametrosObservarDocumento.codPlanilla);
	setValueInputText("txtNombreAutorizadorObservarDocumento", dataParametrosObservarDocumento.nombreAutorizador);
	setValueInputText("etiquetaFechaObservacionObservarDocumento", getCurrentDateFormatEsp());
	setValueInputText("txtImporteObservarDocumento", dataParametrosObservarDocumento.montoTotal);
	setValueInputText("elementoMotivoObservarDocumento", "");
	
	addEventElement("btnAceptarObservarDocumento", "click", clickBtnAceptarObservarDocumento);
	addEventElement("btnCancelarObservarDocumento", "click", clickBtnCancelarObservarDocumento);
	addEventElement("btnSiObservarSolicitudObservarDocumento", "click", clickBtnSiObservarSolicitudObservarDocumento);
	addEventElement("btnNoObservarSolicitudObservarDocumento", "click", clickBtnNoObservarSolicitudObservarDocumento);
	addEventElement("btnAceptarObservacionExitosaObservarDocumento", "click", clickBtnAceptarObservacionExitosaObservarDocumento);
	addEventElement("btnAceptarMensajeConfirmacionErrorObservarDocumento", "click", clickBtnAceptarMensajeConfirmacionErrorObservarDocumento);
}

function removeEventElementsObservarDocumento() {
	
	removeAllEventsElement("elementoMotivoObservarDocumento");
	removeAllEventsElement("btnAceptarObservarDocumento");
	removeAllEventsElement("btnCancelarObservarDocumento");
	removeAllEventsElement("btnSiObservarSolicitudObservarDocumento");
	removeAllEventsElement("btnNoObservarSolicitudObservarDocumento");
	removeAllEventsElement("btnAceptarObservacionExitosaObservarDocumento");
	removeAllEventsElement("btnAceptarMensajeConfirmacionErrorObservarDocumento");
}

function clickBtnAceptarObservarDocumento() {
	if (validarObservarDocumento()) {
		var titulo1 = propertyMessageObservarDocumento.observarSolicitudTitulo1Solicitud;
		if (getValueInputText("hidCodigoPaginaCallerObservarDocumento") != "01" && getValueInputText("hidCodigoPaginaCallerObservarDocumento") != "02") {
			titulo1 = propertyMessageObservarDocumento.observarSolicitudTitulo1Reembolso;
		}
		setHtmlElement("divTituloPanelObservarSolicitudObservarDocumento", titulo1 + getValueInputText("txtNumeroPlanillaObservarDocumento") + propertyMessageObservarDocumento.observarSolicitudTitulo2);
		enabledElement("btnSiObservarSolicitudObservarDocumento");
		showModalElement("divMensajeConfirmacionObservarSolicitudObservarDocumento");
	}
}

function clickBtnCancelarObservarDocumento() {
	removeEventElementsObservarDocumento();
	hideModalElement("divObservarDocumento");
}

function clickBtnSiObservarSolicitudObservarDocumento() {
	disabledElement("btnSiObservarSolicitudObservarDocumento");
	hideModalElement("divObservarDocumento");
	hideModalElement("divMensajeConfirmacionObservarSolicitudObservarDocumento");
	callObservarDocumento();
}

function clickBtnNoObservarSolicitudObservarDocumento() {
	hideModalElement("divMensajeConfirmacionObservarSolicitudObservarDocumento");
}

function clickBtnAceptarObservacionExitosaObservarDocumento() {
	removeEventElementsObservarDocumento();
	if (getValueInputText("hidCodigoPaginaCallerObservarDocumento") == "02") {
		$("#btnConsultarSolicitud").trigger("click");
	}
	else if (getValueInputText("hidCodigoPaginaCallerObservarDocumento") == "04") {
		$("#btnConsultarReembolso").trigger("click");
	}
	hideModalElement("divMensajeConfirmacionObservacionExitosaObservarDocumento");
}

function clickBtnAceptarMensajeConfirmacionErrorObservarDocumento() {
	hideModalElement("divMensajeConfirmacionErrorObservarDocumento");
}

function validarObservarDocumento() {
	
	var dataValidacion;
	hideElement("divErrorObservarDocumento");
	
	dataValidacion = validarCamposNoVaciosObservarDocumento();
	if (!dataValidacion.flagCamposNoVacios) {
		showMessageErrorObservarDocumento(dataValidacion.errorMessage);
		return false;
	}
	
	dataValidacion = validarMotivoObservacionCorrecto();
	if (!dataValidacion.flagMotivoObservacionCorrecto) {
		showMessageErrorObservarDocumento(dataValidacion.errorMessage);
		return false;
	}
	
	return true;
}

function validarCamposNoVaciosObservarDocumento() {
	
	var flagCamposNoVacios = true;
	var errorMessage = "";
	
	if (flagCamposNoVacios && trimText(getValueInputText("elementoMotivoObservarDocumento")) == "") {
		flagCamposNoVacios = false;
		errorMessage = errorMessageObservarDocumento.completarMotivo;
	}
	
	var dataValidacion = {
		flagCamposNoVacios: flagCamposNoVacios,
		errorMessage: errorMessage
	};
	return dataValidacion;
}

function validarMotivoObservacionCorrecto() {
	
	var flagMotivoObservacionCorrecto = true;
	var errorMessage = "";
	
	if (flagMotivoObservacionCorrecto && getValueInputText("elementoMotivoObservarDocumento").length > 1000) {
		flagMotivoObservacionCorrecto = false;
		errorMessage = errorMessageObservarDocumento.maximoCaracteresMotivo;
	}
	
	var dataValidacion = {
		flagMotivoObservacionCorrecto: flagMotivoObservacionCorrecto,
		errorMessage: errorMessage
	};
	return dataValidacion;
}

function callObservarDocumento() {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/revisionGeneral.htm?action=observarDocumento",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codPlanViaje": getValueInputText("hidCodPlanViajeObservarDocumento"),
				"observacionAutorizador": getUpperCaseValueInputText("elementoMotivoObservarDocumento"),
				"codPerAutoriza": getUpperCaseValueInputText("hidCodPerAutorizaObservarDocumento"),
				"codigoSedeAutorizador": getUpperCaseValueInputText("hidCodigoSedeAutorizadorObservarDocumento"),
				"expedientePlanViaje": getUpperCaseValueInputText("hidExpedientePlanViajeObservarDocumento"),
				"codigoPaginaCaller": getValueInputText("hidCodigoPaginaCallerObservarDocumento")
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showModalElement("divMensajeConfirmacionLoadingObservarDocumento");
			},
			complete: function() {
				hideModalElement("divMensajeConfirmacionLoadingObservarDocumento");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var codigoOperacion = result.codigoOperacion;
				var errorMessage = result.errorMessage;
				var successMessage = result.successMessage;
				if (codigoOperacion != null && codigoOperacion == "00") {
					showModalElement("divMensajeConfirmacionObservacionExitosaObservarDocumento");
				}
				else {
					showMensajeConfirmacionErrorObservarDocumento(errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callObservarDocumento");
			}
		});
	}, 500);
}

function showMessageErrorObservarDocumento(errorMessage) {
	setHtmlElement("etiquetaErrorObservarDocumento", errorMessage);
	showElement("divErrorObservarDocumento");
}

function showMensajeConfirmacionErrorObservarDocumento(messageTitulo) {
	hideElement("divBodyPanelMensajeConfirmacionErrorObservarDocumento");
	setHtmlElement("divTituloPanelMensajeConfirmacionErrorObservarDocumento", messageTitulo);
	showModalElement("divMensajeConfirmacionErrorObservarDocumento");
}