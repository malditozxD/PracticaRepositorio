function initElementsRegistrarBoletaDeposito() {
    removeDuplicateComponents();
    setInitElementsRegistrarBoletaDeposito();
    callObtenerCuentasCorriente();
}

function setInitElementsRegistrarBoletaDeposito() {
    
	obtenerMonedaRegistrarBoletaDeposito(getValueInputText("hidTipoDestino"));
	hideElement("divErrorRegistrarBoletaDeposito");
	setTextLabel("lblSaldoDevolverRegistrarBoletaDeposito", propertyMessageRegistrarBoletaDeposito.saldoDevolver + " " + getValueInputText("hidSimboloMonedaRegistrarBoletaDeposito") + propertyMessageRegistrarBoletaDeposito.dosPuntos);
	setTextLabel("lblNumeroCuentaRegistrarBoletaDeposito", propertyMessageRegistrarBoletaDeposito.numeroCuenta + " " + getValueInputText("hidSimboloMonedaRegistrarBoletaDeposito") + propertyMessageRegistrarBoletaDeposito.dosPuntos);
	setTextLabel("lblImporteRegistrarBoletaDeposito", propertyMessageRegistrarBoletaDeposito.importe + " " + getValueInputText("hidSimboloMonedaRegistrarBoletaDeposito") + propertyMessageRegistrarBoletaDeposito.dosPuntos);
	setValueInputText("txtSaldoDevolverRegistrarBoletaDeposito", getUpperCaseValueInputText("hidMontoDevolver"));
	setValueInputText("hidCodigoBoletaDepositoRegistrarBoletaDeposito", "");
	setValueInputText("hidFlagBoletaDepositoRegistrado", "0");
	setValueInputText("selBancoRegistrarBoletaDeposito", "000");
	setValueInputText("txtNumeroCuentaRegistrarBoletaDeposito", "");
	setValueInputText("hidCodigoCuentaRegistrarBoletaDeposito", "");
	setValueInputText("etiquetaFechaVoucherRegistrarBoletaDeposito", "");
	setValueInputText("txtNumeroOperacionRegistrarBoletaDeposito", "");
	setValueInputText("txtImporteSolesRegistrarBoletaDeposito", "");
	setValueInputText("txtTipoCambioRegistrarBoletaDeposito", "");
	setValueInputText("txtImporteRegistrarBoletaDeposito", "");
	
	disabledElement("btnAdjuntarVoucherRegistrarBoletaDeposito");
	enabledElement("btnGrabarRegistrarBoletaDeposito");
	
	enabledElement("selBancoRegistrarBoletaDeposito");
	enabledElement("etiquetaFechaVoucherRegistrarBoletaDeposito");
	enabledElement("txtNumeroOperacionRegistrarBoletaDeposito");
	enabledElement("txtImporteSolesRegistrarBoletaDeposito");
	enabledElement("txtTipoCambioRegistrarBoletaDeposito");
	enabledElement("txtImporteRegistrarBoletaDeposito");
	
	disabledElement("selBancoRegistrarBoletaDeposito");
	disabledElement("txtNumeroCuentaRegistrarBoletaDeposito");
	addEventElement("selBancoRegistrarBoletaDeposito", "change", changeSelBancoRegistrarBoletaDeposito);
	addEventElement("txtImporteSolesRegistrarBoletaDeposito", "change", changeTxtImporteSolesRegistrarBoletaDeposito);
	addEventElement("txtTipoCambioRegistrarBoletaDeposito", "change", changeTxtTipoCambioRegistrarBoletaDeposito);
	addEventElement("txtImporteRegistrarBoletaDeposito", "change", changeTxtImporteRegistrarBoletaDeposito);
	addEventElement("btnAdjuntarVoucherRegistrarBoletaDeposito", "click", clickBtnAdjuntarVoucherRegistrarBoletaDeposito);
	addEventElement("btnGrabarRegistrarBoletaDeposito", "click", clickBtnGrabarRegistrarBoletaDeposito);
    addEventElement("btnCerrarRegistrarBoletaDeposito", "click", clickBtnCerrarRegistrarBoletaDeposito);
    addEventElement("etiquetaFechaVoucherRegistrarBoletaDeposito", "change", changeEtiquetaFechaVoucherRegistrarBoletaDeposito);
    initDateTimePickerWithMaxDate("etiquetaFechaVoucherRegistrarBoletaDepositoDiv", "dp.change", "changeDate", changeDateEtiquetaFechaVoucherRegistrarBoletaDepositoDiv, formatEspDateToEngFormatDate(getValueInputText("hidFechaMaximaDate")));
    
    addEventElement("btnSiMensajeConfirmacionRegistrarBoletaDeposito", "click", clickBtnSiMensajeConfirmacionRegistrarBoletaDeposito);
	addEventElement("btnNoMensajeConfirmacionRegistrarBoletaDeposito", "click", clickBtnNoMensajeConfirmacionRegistrarBoletaDeposito);
}

function removeEventElementsRegistrarBoletaDeposito() {
	
	removeAllEventsElement("selBancoRegistrarBoletaDeposito");
	removeAllEventsElement("txtImporteSolesRegistrarBoletaDeposito");
	removeAllEventsElement("txtTipoCambioRegistrarBoletaDeposito");
	removeAllEventsElement("txtImporteRegistrarBoletaDeposito");
	
	removeAllEventsElement("btnAdjuntarVoucherRegistrarBoletaDeposito");
	removeAllEventsElement("btnGrabarRegistrarBoletaDeposito");
    removeAllEventsElement("btnCerrarRegistrarBoletaDeposito");
    removeAllEventsElement("btnSiMensajeConfirmacionRegistrarBoletaDeposito");
    removeAllEventsElement("btnNoMensajeConfirmacionRegistrarBoletaDeposito");
}

function changeSelBancoRegistrarBoletaDeposito() {
	
	var dataCodigoCuenta = getDataAttributeSelect("selBancoRegistrarBoletaDeposito", "data-codigocuenta");
	var dataCuenta = getDataAttributeSelect("selBancoRegistrarBoletaDeposito", "data-cuenta");
	setValueInputText("hidCodigoCuentaRegistrarBoletaDeposito", dataCodigoCuenta);
	setValueInputText("txtNumeroCuentaRegistrarBoletaDeposito", dataCuenta);
	setValueInputText("txtImporteSolesRegistrarBoletaDeposito", "");
	setValueInputText("txtTipoCambioRegistrarBoletaDeposito", "");
	setValueInputText("txtImporteRegistrarBoletaDeposito", "");
	
	if (getValueInputText("hidTipoDestino") == "02") {
		if (getValueInputText("selBancoRegistrarBoletaDeposito") == "011") {
			disabledElement("txtImporteRegistrarBoletaDeposito");
			showElement("divBancoNacionInternacional");
		}
		else {
			enabledElement("txtImporteRegistrarBoletaDeposito");
			hideElement("divBancoNacionInternacional");
		}
	}
}

function changeTxtImporteSolesRegistrarBoletaDeposito() {
	
	if (isNaN(getValueInputText("txtImporteSolesRegistrarBoletaDeposito"))) {
		setValueInputText("txtImporteSolesRegistrarBoletaDeposito", "");
		setValueInputText("txtImporteRegistrarBoletaDeposito", "");
	}
	else {
		setValueInputText("txtImporteSolesRegistrarBoletaDeposito", Number(getValueInputText("txtImporteSolesRegistrarBoletaDeposito")).toFixed(2));
		if (trimText(getValueInputText("txtTipoCambioRegistrarBoletaDeposito")) != "") {
			calcularImporteTotal();
		}
	}
}

function changeTxtTipoCambioRegistrarBoletaDeposito() {
	
	if (isNaN(getValueInputText("txtTipoCambioRegistrarBoletaDeposito"))) {
		setValueInputText("txtTipoCambioRegistrarBoletaDeposito", "");
		setValueInputText("txtImporteRegistrarBoletaDeposito", "");
	}
	else {
		setValueInputText("txtTipoCambioRegistrarBoletaDeposito", Number(getValueInputText("txtTipoCambioRegistrarBoletaDeposito")).toFixed(2));
		if (trimText(getValueInputText("txtImporteSolesRegistrarBoletaDeposito")) != "") {
			calcularImporteTotal();
		}
	}
}

function changeTxtImporteRegistrarBoletaDeposito() {
	
	if (isNaN(getValueInputText("txtImporteRegistrarBoletaDeposito"))) {
		setValueInputText("txtImporteRegistrarBoletaDeposito", "");
	}
	else {
		setValueInputText("txtImporteRegistrarBoletaDeposito", Number(getValueInputText("txtImporteRegistrarBoletaDeposito")).toFixed(2));
	}
}

function clickBtnAdjuntarVoucherRegistrarBoletaDeposito() {
	
	var dataParametrosArchivo = new Object();
	dataParametrosArchivo.planViajeId = getValueInputText("hidCodigoPlanViaje");
    dataParametrosArchivo.codigoBoleto = getValueInputText("hidCodigoBoletaDepositoRegistrarBoletaDeposito");
    dataParametrosArchivo.estadoOrigen = "V";
    dataParametrosArchivo.estadoLLamada = "R";
    dataParametrosArchivo.numeroRegistroColaborador = getValueInputText("txtNroRegistro");
    dataParametrosArchivo.paginaOrigen = "SECUNDARIA";
    initElementsConsultarRegistrarEliminarArchivo(dataParametrosArchivo);
    showModalElement("divAdjuntarDocumento");
    triggerResizeEvent();
}

function clickBtnGrabarRegistrarBoletaDeposito() {
	if (validarRegistrarBoletaDeposito()) {
		showModalElement("divMensajeConfirmacionRegistrarBoletaDeposito");
	}
}

function clickBtnCerrarRegistrarBoletaDeposito() {
	hideElement("divErrorRegistrarBoletaDeposito");
	if (getValueInputText("hidProcesoViatico") == "01" && getValueInputText("hidFlagBoletaDepositoRegistrado") == "1") {
		callValidarPapeletaDepositoAdjuntado();
	}
	else {
		removeEventElementsRegistrarBoletaDeposito();
	    hideModalElement("divRegistrarBoletaDeposito");
	}
}

function changeEtiquetaFechaVoucherRegistrarBoletaDeposito() {
	if (isBrowserInternetExplorer()) {
		if (trimText(getValueInputText("etiquetaFechaVoucherRegistrarBoletaDeposito")) != "" && isValidoFormatDate(getValueInputText("etiquetaFechaVoucherRegistrarBoletaDeposito"))) {
			if (isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaVoucherRegistrarBoletaDeposito")), formatEspDateToEngFormatDate(getValueInputText("hidFechaMaximaDate")))) {
				setValueInputText("etiquetaFechaVoucherRegistrarBoletaDeposito", "");
			}
		}
		else {
			setValueInputText("etiquetaFechaVoucherRegistrarBoletaDeposito", "");
		}
		changeDateEtiquetaFechaVoucherRegistrarBoletaDepositoDiv();
	}
}

function changeDateEtiquetaFechaVoucherRegistrarBoletaDepositoDiv() {
	consoleLog("changeDateEtiquetaFechaVoucherRegistrarBoletaDepositoDiv");
}

function clickBtnSiMensajeConfirmacionRegistrarBoletaDeposito() {
	hideModalElement("divMensajeConfirmacionRegistrarBoletaDeposito");
	callRegistrarPapeletaDeposito();
}

function clickBtnNoMensajeConfirmacionRegistrarBoletaDeposito() {
	hideModalElement("divMensajeConfirmacionRegistrarBoletaDeposito");
}

function validarRegistrarBoletaDeposito() {
	
	var dataValidacion;
	hideElement("divErrorRegistrarBoletaDeposito");
	
	dataValidacion = validarCamposNoVaciosRegistrarBoletaDeposito();
	if (!dataValidacion.flagCamposNoVacios) {
		showMessageErrorRegistrarBoletaDeposito(dataValidacion.idDivErrorMessage, dataValidacion.idEtiquetaErrorMessage, dataValidacion.errorMessage);
		return false;
	}
	
	dataValidacion = validarFechaVoucher();
	if (!dataValidacion.flagFechaVoucherValida) {
		showMessageErrorRegistrarBoletaDeposito(dataValidacion.idDivErrorMessage, dataValidacion.idEtiquetaErrorMessage, dataValidacion.errorMessage);
		return false;
	}
	
	if (getValueInputText("hidTipoDestino") == "02") {
		if (getValueInputText("selBancoRegistrarBoletaDeposito") == "011") {
			dataValidacion = validarTipoCambioCorrectoRegistrarBoletaDeposito();
			if (!dataValidacion.flagTipoCambioCorrecto) {
				showMessageErrorRegistrarBoletaDeposito(dataValidacion.idDivErrorMessage, dataValidacion.idEtiquetaErrorMessage, dataValidacion.errorMessage);
				return false;
			}
		}
	}
	
	dataValidacion = validarImporteCorrectoRegistrarBoletaDeposito();
	if (!dataValidacion.flagImporteCorrecto) {
		showMessageErrorRegistrarBoletaDeposito(dataValidacion.idDivErrorMessage, dataValidacion.idEtiquetaErrorMessage, dataValidacion.errorMessage);
		return false;
	}
	
	return true;
}

function validarCamposNoVaciosRegistrarBoletaDeposito() {
	
	var flagCamposNoVacios = true;
	var errorMessage = "";
	
	if (flagCamposNoVacios && getValueInputText("selBancoRegistrarBoletaDeposito") == "000") {
		flagCamposNoVacios = false;
		errorMessage = errorMessageRegistrarBoletaDeposito.seleccionarBanco;
	}
	
	if (flagCamposNoVacios && trimText(getValueInputText("etiquetaFechaVoucherRegistrarBoletaDeposito")) == "") {
		flagCamposNoVacios = false;
		errorMessage = errorMessageRegistrarBoletaDeposito.completarFechaVoucher;
	}
	
	if (flagCamposNoVacios && trimText(getValueInputText("txtNumeroOperacionRegistrarBoletaDeposito")) == "") {
		flagCamposNoVacios = false;
		errorMessage = errorMessageRegistrarBoletaDeposito.completarNumeroOperacion;
	}
	
	if (getValueInputText("hidTipoDestino") == "02") {
		if (getValueInputText("selBancoRegistrarBoletaDeposito") == "011") {
			if (flagCamposNoVacios && trimText(getValueInputText("txtImporteSolesRegistrarBoletaDeposito")) == "") {
				flagCamposNoVacios = false;
				errorMessage = errorMessageRegistrarBoletaDeposito.completarImporteSoles;
			}
			
			if (flagCamposNoVacios && trimText(getValueInputText("txtTipoCambioRegistrarBoletaDeposito")) == "") {
				flagCamposNoVacios = false;
				errorMessage = errorMessageRegistrarBoletaDeposito.completarTipoCambio;
			}
		}
	}
	
	if (flagCamposNoVacios && trimText(getValueInputText("txtImporteRegistrarBoletaDeposito")) == "") {
		flagCamposNoVacios = false;
		errorMessage = errorMessageRegistrarBoletaDeposito.completarImporte;
	}
	
	var dataValidacion = {
		flagCamposNoVacios: flagCamposNoVacios,
		idDivErrorMessage: "divErrorRegistrarBoletaDeposito",
		idEtiquetaErrorMessage: "etiquetaErrorRegistrarBoletaDeposito",
		errorMessage: errorMessage
	};
	return dataValidacion;
}

function validarFechaVoucher() {
	
	var flagFechaVoucherValida = true;
	var errorMessage = "";
	
	if (flagFechaVoucherValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaVoucherRegistrarBoletaDeposito")))) {
		flagFechaVoucherValida = false;
		if (getValueInputText("hidTipoDestino") == "01") {
			errorMessage = errorMessageRegistrarBoletaDeposito.fechaVoucherMenorFechaSalidaEjecucion + " " + getValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado") + ".";
		}
		else {
			errorMessage = errorMessageRegistrarBoletaDeposito.fechaVoucherMenorFechaSalidaItinerario + " " + getValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado") + ".";
		}
	}
	
	var dataValidacion = {
		flagFechaVoucherValida: flagFechaVoucherValida,
		idDivErrorMessage: "divErrorRegistrarBoletaDeposito",
		idEtiquetaErrorMessage: "etiquetaErrorRegistrarBoletaDeposito",
		errorMessage: errorMessage
	};
	return dataValidacion;
}

function validarTipoCambioCorrectoRegistrarBoletaDeposito() {
	
	var flagTipoCambioCorrecto = true;
	var errorMessage = "";
	
	if (flagTipoCambioCorrecto && getValueInputText("txtTipoCambioRegistrarBoletaDeposito") <= 0) {
		flagTipoCambioCorrecto = false;
		errorMessage = errorMessageRegistrarBoletaDeposito.tipoCambioMayorCero;
	}
	
	var dataValidacion = {
		flagTipoCambioCorrecto: flagTipoCambioCorrecto,
		idDivErrorMessage: "divErrorRegistrarBoletaDeposito",
		idEtiquetaErrorMessage: "etiquetaErrorRegistrarBoletaDeposito",
		errorMessage: errorMessage
	};
	return dataValidacion;
}

function validarImporteCorrectoRegistrarBoletaDeposito() {
	
	var flagImporteCorrecto = true;
	var errorMessage = "";
	
	if (flagImporteCorrecto && getValueInputText("txtImporteRegistrarBoletaDeposito") <= 0) {
		flagImporteCorrecto = false;
		errorMessage = errorMessageRegistrarBoletaDeposito.importeMayorCero;
	}
	
	var dataValidacion = {
		flagImporteCorrecto: flagImporteCorrecto,
		idDivErrorMessage: "divErrorRegistrarBoletaDeposito",
		idEtiquetaErrorMessage: "etiquetaErrorRegistrarBoletaDeposito",
		errorMessage: errorMessage
	};
	return dataValidacion;
}

function callObtenerCuentasCorriente() {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/viatico.htm?action=obtenerCuentasCorriente",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"tipoDestino": getValueInputText("hidTipoDestino")
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showElement("divLoadingRegistrarBoletaDeposito");
			},
			complete: function() {
				hideElement("divLoadingRegistrarBoletaDeposito");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var cuentaCorrienteList = result.cuentaCorrienteList;
				if (cuentaCorrienteList != null && cuentaCorrienteList.length > 0) {
					var bancoRegistrarBoletaDepositoSel = $("#selBancoRegistrarBoletaDeposito");
					bancoRegistrarBoletaDepositoSel.empty();
					for (var i = 0; i < cuentaCorrienteList.length; i++) {
						var cuentaCorriente = cuentaCorrienteList[i];
						if (i == 0) {
							var optionSelectInicial = $("<option></option>").attr("value", "000").attr("data-cuenta", "").attr("data-codigocuenta", "").text(propertyMessageRegistrarBoletaDeposito.seleccioneOption);
							bancoRegistrarBoletaDepositoSel.append(optionSelectInicial);
						}
						if (getValueInputText("hidTipoDestino") == "01") {
							if (cuentaCorriente.codigoBanco = "011") {
								var optionSelect = $("<option></option>").attr("value", cuentaCorriente.codigoBanco).attr("data-cuenta", cuentaCorriente.numeroCuenta).attr("data-codigocuenta", cuentaCorriente.codigoCuentaBanco).text(cuentaCorriente.nombreBanco);
								bancoRegistrarBoletaDepositoSel.append(optionSelect);
								break;
							}
						}
						else {
							var optionSelect = $("<option></option>").attr("value", cuentaCorriente.codigoBanco).attr("data-cuenta", cuentaCorriente.numeroCuenta).attr("data-codigocuenta", cuentaCorriente.codigoCuentaBanco).text(cuentaCorriente.nombreBanco);
							bancoRegistrarBoletaDepositoSel.append(optionSelect);
						}
					}
					enabledElement("selBancoRegistrarBoletaDeposito");
				}
			},
			error: function() {
				consoleLog("Error callObtenerCuentaCorriente");
			}
		});
	}, 500);
}

function callRegistrarPapeletaDeposito() {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/registrarRendicion.htm?action=registrarPapeletaDeposito",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codigoPlanViaje": getValueInputText("hidCodigoPlanViaje"),
				"codigoBanco": getValueInputText("selBancoRegistrarBoletaDeposito"),
				"codigoCuentaBanco": getValueInputText("hidCodigoCuentaRegistrarBoletaDeposito"),
				"numeroOperacion": getValueInputText("txtNumeroOperacionRegistrarBoletaDeposito"),
				"fechaVoucher": getValueInputText("etiquetaFechaVoucherRegistrarBoletaDeposito"),
				"simboloMoneda": getValueInputText("hidSimboloMonedaRegistrarBoletaDeposito"),
				"montoUtilizado": getValueInputText("txtImporteSolesRegistrarBoletaDeposito"),
				"valorTipoCambio": getValueInputText("txtTipoCambioRegistrarBoletaDeposito"),
				"montoDeposito": getValueInputText("txtImporteRegistrarBoletaDeposito"),
				"codigoPersona": getValueInputText("hidCodigoRegistrador"),
				"tipoDestino": getValueInputText("hidTipoDestino")
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showModalElement("divMensajeConfirmacionLoadingRegistrarModificarRendicion");
			},
			complete: function() {
				hideModalElement("divMensajeConfirmacionLoadingRegistrarModificarRendicion");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var codigoOperacion = result.codigoOperacion;
				var errorMessage = result.errorMessage;
				var successMessage = result.successMessage;
				if (codigoOperacion != null && codigoOperacion == "00") {
					var codigoBoletaDeposito = result.codigoBoletaDeposito;
					setValueInputText("hidCodigoBoletaDepositoRegistrarBoletaDeposito", codigoBoletaDeposito);
					setValueInputText("hidFlagBoletaDepositoRegistrado", "1");
					setValueInputText("hidFlagHabilitarCerrarRendicion", "0");
					enabledElement("btnAdjuntarVoucherRegistrarBoletaDeposito");
					disabledElement("btnGrabarRegistrarBoletaDeposito");
					
					disabledElement("selBancoRegistrarBoletaDeposito");
					disabledElement("etiquetaFechaVoucherRegistrarBoletaDeposito");
					disabledElement("txtNumeroOperacionRegistrarBoletaDeposito");
					disabledElement("txtImporteSolesRegistrarBoletaDeposito");
					disabledElement("txtTipoCambioRegistrarBoletaDeposito");
					disabledElement("txtImporteRegistrarBoletaDeposito");
					
					showMensajeConfirmacionAplicativoWithoutBody("divMensajeConfirmacionRegistrarModificarRendicion", "divTituloPanelMensajeConfirmacionRegistrarModificarRendicion", "divBodyPanelMensajeConfirmacionRegistrarModificarRendicion", successMessage);
					callObtenerComprobantesAsignacionesPapeletasRics();
				}
				else {
					showMessageErrorRegistrarBoletaDeposito("divErrorRegistrarBoletaDeposito", "etiquetaErrorRegistrarBoletaDeposito", errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callRegistrarPapeletaDeposito");
			}
		});
	}, 500);
}

function callValidarPapeletaDepositoAdjuntado() {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/registrarRendicion.htm?action=validarPapeletaDepositoAdjuntado",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codigoPapeletaDeposito": getValueInputText("hidCodigoBoletaDepositoRegistrarBoletaDeposito")
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showModalElement("divMensajeConfirmacionLoadingRegistrarModificarRendicion");
			},
			complete: function() {
				hideModalElement("divMensajeConfirmacionLoadingRegistrarModificarRendicion");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var codigoConsulta = result.codigoConsulta;
				var errorMessage = result.errorMessage;
				if (codigoConsulta != null && codigoConsulta == "00") {
					var flagPapeletaDepositoAdjuntado = result.flagPapeletaDepositoAdjuntado;
					if (flagPapeletaDepositoAdjuntado == "1") {
						removeEventElementsRegistrarBoletaDeposito();
					    hideModalElement("divRegistrarBoletaDeposito");
					}
					else {
						showMessageErrorRegistrarBoletaDeposito("divErrorRegistrarBoletaDeposito", "etiquetaErrorRegistrarBoletaDeposito", errorMessage);
					}
				}
				else {
					showMessageErrorRegistrarBoletaDeposito("divErrorRegistrarBoletaDeposito", "etiquetaErrorRegistrarBoletaDeposito", errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callValidarPapeletaDepositoAdjuntado");
			}
		});
	}, 500);
}

function obtenerMonedaRegistrarBoletaDeposito(tipoDestino) {
	
	if (tipoDestino == "01") {
		setValueInputText("hidSimboloMonedaRegistrarBoletaDeposito", "S/.");
	}
	else {
		setValueInputText("hidSimboloMonedaRegistrarBoletaDeposito", "US$");
	}
}

function calcularImporteTotal() {
	if (Number(getValueInputText("txtTipoCambioRegistrarBoletaDeposito")) != 0) {
		var importeTotal = Number(getValueInputText("txtImporteSolesRegistrarBoletaDeposito"))/Number(getValueInputText("txtTipoCambioRegistrarBoletaDeposito"));
		setValueInputText("txtImporteRegistrarBoletaDeposito", importeTotal.toFixed(2));
	}
	else {
		setValueInputText("txtImporteRegistrarBoletaDeposito", "0.00");
	}
	
}

function showMessageErrorRegistrarBoletaDeposito(idDivErrorMessage, idEtiquetaErrorMessage, errorMessage) {
	setHtmlElement(idEtiquetaErrorMessage, errorMessage);
	showElement(idDivErrorMessage);
}

/*Inicio Codigo - Reutilizacion adjuntarDocumento*/
/* Nota: El codigo para reutilizar solo se debe poner en la pagina principal. */
/*Fin Codigo - Reutilizacion adjuntarDocumento*/