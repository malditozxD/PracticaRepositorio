/// <reference path="./registrarModificarSolicitud_event.js" />
/// <reference path="./registrarModificarSolicitud_rest.js" />
/// <reference path="./registrarModificarSolicitud_service.js" />
/// <reference path="./registrarModificarSolicitud_validate.js" />
/// <reference path="../general/common.js" />
/// <reference path="../../WEB-INF/jsp/solicitud/registrar/registrarModificarSolicitud.jsp" />
/// <reference path="D:\jcfr\data\ts-definitions\DefinitelyTyped-master\jquery\jquery.d.ts" />

// servicio buscar colaborador
var buscarColaboradorService = null;

// servicio buscar colaborador input
var buscarColaboradorInputService = null;

// servicio buscar cadena presupuestal
var buscarCadenaPresupuestalService = null;

// servicio buscar conceptos de viático (asignaciones)
var buscarConceptoViaticoService = null;

// servicio buscar destino
var buscarDestinoService = null;

// servicio adjuntar archivo
var adjuntarDocumentoService = null;

// init del módulo
function initElementsRegistrarModificarViatico() {

	removeDuplicateComponents();

	// inicializacion comun a registrar y modificar
	setInitElementsRegistrarModificarViatico();

	// post inicializaciones solo para registrar/modificar segun caso
	if ( esRegistrar() ) {
		setInitElementsRegistrarViatico();
	} else if ( esModificar() ) {
		setInitElementsModificarViatico();
	}

}

// init para registrar y modificar
function setInitElementsRegistrarModificarViatico() {
	
	updateTitulo();
	
	$( '#divHiddenPost' ).hide();

	// eventos: combos
	addEventElement("selTipoViatico", "change", changeSelTipoViatico);
	addEventElement("selDuracionComision", "change", changeSelDuracionComision);
	addEventElement("selDepartamento", "change", changeSelDepartamento);
	addEventElement("selProvincia", "change", changeSelProvincia);

	var fecMax = '12/31/' + new Date().getFullYear();

	// eventos: fechas
	addEventElementFechaIE("fechaSalidaNacMay4h", "change", changeDateFechaSalidaNacMay4hDiv );
	initDateTimePickerWithMinDateMaxDateUseCurrent("fechaSalidaNacMay4hDiv", "dp.change", "changeDate", changeDateFechaSalidaNacMay4hDiv, formatEspDateToEngFormatDate( configRSV.fechaRegistro ), fecMax, false );

	addEventElementFechaIE("fechaRetornoNacMay4h", "change", changeDateFechaRetornoNacMay4hDiv );
	initDateTimePickerWithMinDateMaxDateUseCurrent("fechaRetornoNacMay4hDiv", "dp.change", "changeDate", changeDateFechaRetornoNacMay4hDiv, formatEspDateToEngFormatDate( configRSV.fechaRegistro ), fecMax, false );

	addEventElementFechaIE("fechaNacMen4h", "change", changeDateFechaNacMen4hDiv );
	initDateTimePickerWithMinDateMaxDateUseCurrent("fechaNacMen4hDiv", "dp.change", "changeDate", changeDateFechaNacMen4hDiv, formatEspDateToEngFormatDate( configRSV.fechaRegistro ), fecMax, false );

	addEventElementFechaIE("fechaItinerarioInicioInter", "change", changeDateFechaItinerarioInicioInterDiv );
	initDateTimePickerWithMinDateMaxDateUseCurrent("fechaItinerarioInicioInterDiv", "dp.change", "changeDate", changeDateFechaItinerarioInicioInterDiv, formatEspDateToEngFormatDate( configRSV.fechaRegistro ), fecMax, false );

	addEventElementFechaIE("fechaItinerarioFinInter", "change", changeDateFechaItinerarioFinInterDiv );
	initDateTimePickerWithMinDateMaxDateUseCurrent("fechaItinerarioFinInterDiv", "dp.change", "changeDate", changeDateFechaItinerarioFinInterDiv, formatEspDateToEngFormatDate( configRSV.fechaRegistro ), fecMax, false);

	addEventElementFechaIE("fechaEventoInicioInter", "change", changeDateFechaEventoInicioInterDiv );
	initDateTimePickerWithMinDateMaxDateUseCurrent("fechaEventoInicioInterDiv", "dp.change", "changeDate", changeDateFechaEventoInicioInterDiv, formatEspDateToEngFormatDate( configRSV.fechaRegistro ), fecMax, false );

	addEventElementFechaIE("fechaEventoFinInter", "change", changeDateFechaEventoFinInterDiv );
	initDateTimePickerWithMinDateMaxDateUseCurrent("fechaEventoFinInterDiv", "dp.change", "changeDate", changeDateFechaEventoFinInterDiv, formatEspDateToEngFormatDate( configRSV.fechaRegistro ), fecMax, false );

	addEventElementFechaIE("fechaResolucionInter", "change", changeDateFechaResolucionInterDiv );
	initDateTimePickerUseCurrent("fechaResolucionInterDiv", "dp.change", "changeDate", changeDateFechaResolucionInterDiv, false );

	// eventos: horas
	addEventElementHoraIE("salidaNacMen4h", "change", changeHoraSalidaNacMen4hDiv );
	initDateTimeOnlyHourFormat24("salidaNacMen4hDiv", "dp.change", changeHoraSalidaNacMen4hDiv);

	addEventElementHoraIE("retornoNacMen4h", "change", changeHoraRetornoNacMen4hDiv);
	initDateTimeOnlyHourFormat24("retornoNacMen4hDiv", "dp.change", changeHoraRetornoNacMen4hDiv);

	// eventos: botones
	addEventElement("btnCambiarRegistro", "click", clickBtnCambiarRegistro);
	addEventElement("btnAfectacionPresupuestal", "click", clickBtnAfectacionPresupuestal);
	addEventElement("btnConsultarAsistenciaNacMay4h", "click", clickBtnConsultarAsistencia);	// nacional > 4h
	addEventElement("btnConsultarAsistenciaNacMen4h", "click", clickBtnConsultarAsistencia);	// nacional <= 4h
	addEventElement("btnConsultarAsistenciaInt", "click", clickBtnConsultarAsistencia);			// internacional
	addEventElement("btnConsultarLugar", "click", clickBtnConsultarLugar);
	addEventElement("btnAgregarDesplazamiento", "click", clickBtnAgregarDesplazamiento);
	addEventElement("btnCalcularAsignacion", "click", clickBtnCalcularAsignacion);
	addEventElement("btnAgregarAsignacion", "click", clickBtnAgregarAsignacion);
	addEventElement("btnGrabarViatico", "click", clickBtnGrabarViatico);
	addEventElement("btnAdjuntarViatico", "click", clickBtnAdjuntarViatico);
	addEventElement("btnImprimirViatico", "click", clickBtnImprimirViatico);
	addEventElement("btnEnviarViatico", "click", clickBtnEnviarViatico);
	addEventElement("btnSalirRetornarViatico", "click", clickBtnSalirRetornarViatico);

	addEventElement("btnMensajeAutorizaEnviarSI", "click", clickMensajeAutorizaEnviarSI);
	
	// eventos: radiobuttons
	addEventElement("rbViaticosProgramadosSI", "click", clickRbViaticosProgramadosSI);
	addEventElement("rbViaticosProgramadosNO", "click", clickRbViaticosProgramadosNO);

	// eventos: otros
	addEventElement("montoResolucionInter", "focusout", blurMontoResolucionInter);
	addEventElement("txtMotivoComision", "change", changeTxtMotivoComision);

	updateDivsDetalleViatico();
	updateBotonConsultarAsistencia();
	updateBotonAgregarDesplazamiento();
	updateEstadosPanelBotones();

	setTimeout(function() {
		updateEstructuraTablaDesplazamientos();
	}, 300);

	// creando copias de las listas para identificar las diferencias antes de enviar
	crearCopiaDesplazamientos();
	crearCopiaAsignaciones();
	
	setDatosFirmaElectronica(generateDataFirma,callAjaxEnviarSolicitudViatico);
	
}

// init particular para registrar
function setInitElementsRegistrarViatico() {

	setHtmlElement( 'divTituloPanelRegistrarModificarViatico', configRSV.mensajes.registroTitulo );
	setHtmlElement( 'btnSalirRetornarViatico', configRSV.mensajes.btnSalir );

	disabledElement( 'txtNroRegistro' );
	
	// inicializar las grillas vacias
	setInitDesplazamientoTableRSV();
	setInitAsignacionTableRSV();

	callAjaxObtenerDepartamento( 'selDepartamento' );

	disabledElement("selProvincia");

	updateFechaMaximaRendicion();
	hideMensajeLabelDetalleViatico();
	hideMensajeLabelAsignaciones();
}

// init particular para modificar
function setInitElementsModificarViatico() {

	setHtmlElement( 'divTituloPanelRegistrarModificarViatico', configRSV.mensajes.modificacionTitulo );
	setHtmlElement( 'btnSalirRetornarViatico', configRSV.mensajes.btnRetornar );

	// inicializar las grillas con los desplazamientos y asignaciones del viatico
	setInitDesplazamientoTableRSV();
	setInitAsignacionTableRSV();

	// deshabilitar/ocultar controles que no se deben visualizar en la modificacion
	disabledElement( 'selTipoViatico' );
	disabledElement( 'selDuracionComision' );

	disabledElement( 'txtNroRegistro' );
	disabledElement( 'btnCambiarRegistro' );

	$( '#btnCambiarRegistro' ).hide();

	// remover eventos que no aplican en la modificación
	removeAllEventsElement( 'selTipoViatico' );
	removeAllEventsElement( 'selDuracionComision' );
	removeAllEventsElement( 'txtNroRegistro' );

	hideMensajeLabelDetalleViatico();
	hideMensajeLabelAsignaciones();

	// solo para formatear el monto
	$('#montoResolucionInter').trigger( 'focusout' );
	
	updateEstadosPanelBotones();
	updateBotonAfectacionPresupuestal();	
	
	// casos particulares si tiene traslape: ocultar o mostrar controles según
	if ( getTrimValue( '#hidIndicadorTraslapeAnterior' ) == '1' ) {

		// traslape 1, autorizacion 0 (traslape pendiente de autorización)
		if ( getTrimValue( '#hidIndicadorAutorizacionAnterior' ) == '0' ) {
			 setTimeout( function() {
				 updateEstadoTraslapePendienteAutorizar();
				 // triggerTraslapeFechas();
			 }, 200 );			
		}
		
		// traslape 1, autorizacion 1 (traslape autorizado)
		if ( getTrimValue( '#hidIndicadorAutorizacionAnterior' ) == '1' ) {
			 setTimeout( function() {
				 updateEstadoTraslapeAutorizado();
				 // triggerTraslapeFechas();
			 }, 200 );			
		}	
		
		// traslape 1, autorizacion 2 (traslape rechazado)
		if ( getTrimValue( '#hidIndicadorAutorizacionAnterior' ) == '2' ) {
			 setTimeout( function() {
				 updateEstadoTraslapeNoAutorizado();
				 // triggerTraslapeFechas();
			 }, 200 );			
		}	
		 
	}

	// si es IE: al final volver a invocar el resize de las tablas mostradas al inicio
	setTimeout( function() {

		resizeTable("tblAsignacionRSV");
		resizeTable("tblDesplazamientoRSV");

	}, 800 );

}

// métodos creados para mejor legilidad 
function getDesplazamientosList() {
	return configRSV.desplazamientos;
}

function getAsignacionesList() {
	return configRSV.asignaciones;
}

function getArchivosAdjuntosList() {
	return configRSV.archivosAdjuntos;
}

function esRegistrar() {
	return getValueInputText('hidFlagDoAction') == 'registrar';
}

function esTarifarioRegional() {
	return configRSV.tipoTarifario == configRSV.constantes.TARIFARIO_NACIONAL;
}

function esTarifarioNacional() {
	return configRSV.tipoTarifario == configRSV.constantes.TARIFARIO_REGIONAL;
}

function esConfiguracionManual() {
	return configRSV.tipoConfiguracion == configRSV.constantes.CONFIGURACION_MANUAL;
}

function esConfiguracionAutomatica() {
	return configRSV.tipoConfiguracion == configRSV.constantes.CONFIGURACION_AUTOMATICA;
}

function esModificar() {
	return getValueInputText('hidFlagDoAction') == 'modificar';
}

function esNacional() {
	var selTipoViatico = $('#selTipoViatico').val();
	return selTipoViatico == 'nacional';
}

function esInternacional() {
	var selTipoViatico = $('#selTipoViatico').val();
	return selTipoViatico == 'internacional';
}

function esMayor4h() {
	var selDuracionComision = $('#selDuracionComision').val();
	return selDuracionComision == 'may4h';
}

function esMenorIgual4h() {
	var selDuracionComision = $('#selDuracionComision').val();
	return selDuracionComision == 'men4h';
}

// muestra el mensaje de error para las fechas
function showMensajeLabelDetalleViatico(errorMessage) {

	if ( esNacional() ) {

		if ( esMayor4h() ) {
			$( '#lblErrorMay4h' ).html( errorMessage );
			$( '#divErrorMay4h' ).show();
		} else {
			$( '#lblErrorMen4h' ).html( errorMessage );
			$( '#divErrorMen4h' ).show();
		}

	} else { // si es internacional

		$( '#lblErrorInt' ).html( errorMessage );
		$( '#divErrorInt' ).show();

	}
}

// oculta el mensaje de error para las fechas
function hideMensajeLabelDetalleViatico() {

	if ( esNacional() ) {

		if ( esMayor4h() ) {
			$( '#lblErrorMay4h' ).html( '' );
			$( '#divErrorMay4h' ).hide();
		} else {
			$( '#lblErrorMen4h' ).html( '' );
			$( '#divErrorMen4h' ).hide();
		}

	} else { // si es internacional

		$( '#lblErrorInt' ).html( '' );
		$( '#divErrorInt' ).hide();

	}
}

// muestra el mensaje de error para las asignaciones
function showMensajeLabelAsignaciones(errorMessage) {
	$( '#lblErrorAsignaciones' ).html( errorMessage );
	$( '#divErrorAsignaciones' ).show();
}

// oculta el mensaje de error para las asignaciones
function hideMensajeLabelAsignaciones() {
	$( '#lblErrorAsignaciones' ).html( '' );
	$( '#divErrorAsignaciones' ).hide();
}


// limpia lista de desplazamientos
function clearGridDesplazamientos() {
	$( '#tblDesplazamientoRSV' ).clearGridData();
	configRSV.desplazamientos = [];
}

// limpia lista de desplazamientos
function clearGridAsignaciones() {
	$( '#tblAsignacionRSV' ).clearGridData();
	configRSV.asignaciones = [];
}

// creación de grilla de desplazamientos
function setInitDesplazamientoTableRSV() {

	var table = $( '#tblDesplazamientoRSV' );
	if (table) {
		var tableDiv = $("#divDesplazamientoTableRSV");
		var widthTable = tableDiv.width();
		table.jqGrid({
			width: widthTable,
			height: 'auto',
			minHeight: 150,
			autowidth: true,
			datatype: "local",
			cmTemplate: {sortable: false},
			colNames: [
				"N&deg;",							// todos
				"Medio de transporte",				// todos
				"Departamento",						// nacional
				"Provincia",						// nacional
				"Lugar del destino",				// internacional						(hidden condicional)
				"D&iacute;as de vi&aacute;tico",	// nacional > 4 horas, e internacional	(hidden condicional)
				"Horas de vi&aacute;tico",			// nacional <= 4horas					(hidden condicional)
				"Importe diario",					// todos
				"Importe vi&aacute;tico",			// todos
				"D&iacute;as de traslado",			// internacional			(hidden condicional)
				"Viaje Ext/Gto. Trasl.",			// internacional			(hidden condicional)
				"Total otorgado",					// internacional			(hidden condicional)
				"<a href='javascript:void(0);' onclick='javascript:deleteDesplazamientosPregunta();'><img border='0' title='eliminar' width='15' height='15' src='/a/imagenes/sigad/acciones/delete.png'></a>",
				"codigoMedioTransporte", 			// todos hidden
				"codigoProvincia",					// nacional hidden
				"codigoDepartamento",				// nacional hidden
				"codigoLugar",						// nacional hidden
				"codigoLugarDestino", 				// internacional hidden
				"importeDiarioTope",				// todos hidden
				"diasTrasladoTope",                 // internacional hidden
				"codigoTarifario",                  // internacional hidden
				"porcentajeTarifario",              // internacional hidden
				"viajeExtGtoTrasTope"               // internacional hidden
			],
			colModel: [
				{name: "nro", index: "nro", width: (0.5*widthTable/12), align: "center"},										// todos
				{name: "medioTransporte", index: "medioTransporte", width: (1.5*widthTable/12), align: "center"},				// todos
				{name: "departamento", index: "departamento", width: (1.6*widthTable/12)},										// nacional
				{name: "provincia", index: "provincia", width: (1.6*widthTable/12)},											// nacional
				{name: "lugarDestino", index: "lugarDestino", width: (1.6*widthTable/12), hidden: true},						// internacional
				{name: "diasViatico", index: "diasViatico", width: (1.1*widthTable/12), align: "center",
					formatter: function(cellvalue, options, rowData) {
						var nro = rowData.nro;
						var dias = toNumero( rowData.diasViatico );
						var rowJSON = JSON.stringify( rowData );

						var htmlElement = '<input id="diasViatico_' + nro + '" value="' + dias + '" data-info=\'' + rowJSON + '\' onkeypress="return validarCharacterNumeric(event);" onblur="javascript:onBlurDesplazamientoDiasViatico(this);" onchange="javascript:onChangeDesplazamientoDiasViatico(\'' + nro + '\', this);" maxlength="3" style="padding: 3px; margin: 3px; text-align:right; width: 90%;" >';

						return htmlElement;
					}
				},		// nacional > 4 horas, e internacional
				{name: "horasViatico", index: "horasViatico", width: (1.1*widthTable/12), align: "center", hidden: true,
					formatter: function(cellvalue, options, rowData) {

						var nro = rowData.nro;
						var horas = $.trim( rowData.horasViatico );

						// solo por moneria, si tiene digito decimal mostrarlo formatear a 1  decimal
						if ( horas.indexOf( '.' ) >= 0 ) {
							horas = roundString( toNumero( rowData.horasViatico ), 1 );	// formatear a 1 digito decimal
						}

						var rowJSON = JSON.stringify( rowData );

						var htmlElement = '<input id="horasViatico_' + nro + '" value="' + horas + '" data-info=\'' + rowJSON + '\' onkeypress="return validarCharacterCurrency(event);" onblur="javascript:onBlurDesplazamientoHorasViatico(this);" onchange="javascript:onChangeDesplazamientoHorasViatico(\'' + nro + '\', this);" maxlength="4" style="padding: 3px; margin: 3px; text-align:right; width: 90%;" >';

						return htmlElement;
					}

				},		// nacional <= 4horas
				{name: "importeDiario", index: "importeDiario", width: (1.2*widthTable/12), align: "right",
					formatter: function(cellvalue, options, rowData) {
						var nro = rowData.nro;
						
						var importe = toNumero( rowData.importeDiario );
						
						importe = toNumero(roundString( importe, 1 ));//redondeamos el monto en pantalla a un decimal...
						
						var monto = roundComasMilesString( importe, 2 );
						var rowJSON = JSON.stringify( rowData );

						var htmlElement = '<input id="importeDiario_' + nro + '" value="' + monto + '" data-info=\'' + rowJSON + '\' onkeypress="return validarCharacterCurrency(event);" onblur="javascript:onBlurDesplazamientoImporteDiario(this);" onchange="javascript:onChangeDesplazamientoImporteDiario(\'' + nro + '\', this);" maxlength="10" style="padding: 3px; margin: 3px; text-align:right; width: 90%;" >';

						return htmlElement;
					}
				},		// todos
				{name: "importeViatico", index: "importeViatico", width: (1.2*widthTable/12), align: "right",
					formatter: function(cellvalue, options, rowData) {
						var importe = toNumero( rowData.importeViatico );
						return roundComasMilesString( importe, 2 );
					}
				},		// todos
				{name: "diasTraslado", index: "diasTraslado", width: (1.1*widthTable/12), align: "center", hidden: true,
					formatter: function(cellvalue, options, rowData) {
						var nro = rowData.nro;
						var dias = toNumero( rowData.diasTraslado );
						var rowJSON = JSON.stringify( rowData );

						var htmlElement = '<input id="diasTraslado_' + nro + '" value="' + dias + '" data-info=\'' + rowJSON + '\' onkeypress="return validarCharacterNumeric(event);" onblur="javascript:onBlurDesplazamientoDiasTraslado(this);" onchange="javascript:onChangeDesplazamientoDiasTraslado(\'' + nro + '\', this);" maxlength="2" style="padding: 3px; margin: 3px; text-align:right; width: 90%;" >';

						return htmlElement;
					}
				},		// internacional
				{name: "viajeExtGtoTras", index: "viajeExtGtoTras", width: (1.1*widthTable/12), align: "right", hidden: true,

					formatter: function(cellvalue, options, rowData) {
						var nro = rowData.nro;
						var importe = toNumero( rowData.viajeExtGtoTras );
						var monto = roundComasMilesString( importe, 2 );
						var rowJSON = JSON.stringify( rowData );

						var htmlElement = '<input id="viajeExtGtoTras_' + nro + '" value="' + monto + '" data-info=\'' + rowJSON + '\' onkeypress="return validarCharacterCurrency(event);" onblur="javascript:onBlurDesplazamientoViajeExtGtoTras(this);" onchange="javascript:onChangeDesplazamientoViajeExtGtoTras(\'' + nro + '\', this);" maxlength="10" style="padding: 3px; margin: 3px; text-align:right; width: 90%;" >';

						return htmlElement;
					}
				},		// internacional
				{name: "totalOtorgado", index: "totalOtorgado", width: (1.1*widthTable/12), align: "right", hidden: true,
					formatter: function(cellvalue, options, rowData) {
						var importe = toNumero( rowData.totalOtorgado );
						return roundComasMilesString( importe, 2 );
					}
				}, 		// internacional
				{name: "eliminar", index: "eliminar", width: (0.5*widthTable/12), align: "center",								// todos
					formatter: function(cellValue, options, rowData) {
						var nro = rowData.nro;
						var rowJSON = JSON.stringify( rowData );
						var htmlElement = '<input id="chkJqGridDesplazamiento' + nro + '" name="chkDesplazamientos" type="checkbox" value=\'' + rowJSON + '\' onclick="javascript:clickCheckboxDesplazamientos(this);">';
						return htmlElement;
					}
				},
				{name: "codigoMedioTransporte", index: "codigoMedioTransporte", width: (1.0*widthTable/12), hidden: true},		// todos hidden
				{name: "codigoProvincia", index: "codigoProvincia", width: (1.0*widthTable/12), hidden: true},					// nacional hidden
				{name: "codigoDepartamento", index: "codigoDepartamento", width: (1.0*widthTable/12), hidden: true},			// nacional hidden
				{name: "codigoLugar", index: "codigoLugar", width: (1.0*widthTable/12), hidden: true},							// nacional hidden
				{name: "codigoLugarDestino", index: "codigoLugarDestino", width: (1.0*widthTable/12), hidden: true},			// internacional hidden
				{name: "importeDiarioTope", index: "importeDiarioTope", width: (1.0*widthTable/12), hidden: true},	     	    // todos hidden
				{name: "diasTrasladoTope", index: "diasTrasladoTope", width: (1.0*widthTable/12), hidden: true},		   	    // internacional hidden
				{name: "codigoTarifario", index: "codigoTarifario", width: (1.0*widthTable/12), hidden: true},		   	        // internacional hidden
				{name: "porcentajeTarifario", index: "porcentajeTarifario", width: (1.0*widthTable/12), hidden: true},		  	// internacional hidden
				{name: "viajeExtGtoTrasTope", index: "viajeExtGtoTrasTope", width: (1.0*widthTable/12), hidden: true}		  	// internacional hidden
			],
			pager : "#divDesplazamientoPagerTableRSV",
			loadui: "disable"
		});

		// actualizar lista de desplazamientos
		fillGrilla( '#tblDesplazamientoRSV', getDesplazamientosList() );
		updateTotalDesplazamientos();

	}
}

// creación de grilla de asignaciones
function setInitAsignacionTableRSV() {

	var table = $( '#tblAsignacionRSV' );
	if (table) {
		var tableDiv = $("#divAsignacionTableRSV");
		var widthTable = tableDiv.width();
		table.jqGrid({
			width: widthTable,
			height: 'auto',
			minHeight: 150,
			autowidth: true,
			datatype: "local",
			cmTemplate: {sortable: false},
			colNames: [
				"N&deg;",
				"Asignaci&oacute;n",
				"Importe Asignado",
				"<a href='javascript:void(0);' onclick='javascript:deleteAsignaciones();'><img border='0' title='eliminar' width='15' height='15' src='/a/imagenes/sigad/acciones/delete.png'></a>",
				"codigoAsignacion",			// hidden
				"clasificadorGasto",		// hidden
				"conceptoCantidadPVI",   	// hidden
				"tipoFijoPVI",              // hidden
				"editable"					// hidden
			],
			colModel: [
				{name: "nro", index: "nro", width: (0.3*widthTable/12), align: "center"},
				{name: "asignacion", index: "asignacion", width: (2.2*widthTable/12)},
				{name: "importeAsignado", index: "importeAsignado", width: (0.5*widthTable/12), align: "right",
					formatter: function(cellvalue, options, rowData) {

						var nro = rowData.nro;
						var editable = rowData.editable;
						var importe = toNumero( rowData.importeAsignado );
						var monto = roundComasMilesString( importe, 2 );
						var rowJSON = JSON.stringify( rowData );

						var result = '';

						if ( editable == 'si' ) {
							result = '<input id="importeAsignado_' + nro + '" value="' + monto + '" data-info=\'' + rowJSON + '\' onkeypress="return validarCharacterCurrency(event);" onblur="javascript:onBlurAsignacionImporteAsignado(this);" maxlength="9" style="padding: 3px; margin: 3px; text-align:right; width: 90%;" >';
						} else {
							result = '<span style="padding-right: 7px;">' + roundComasMilesString( importe, 2 ) + '</span>';
						}

						return result;
					}
				},
				{name: "eliminar", index: "eliminar", width: (0.3*widthTable/12), align: "center",
					formatter: function(cellValue, options, rowData) {
						var nro = rowData.nro;
						var rowJSON = JSON.stringify( rowData );
						var htmlElement = '<input id="chkJqGridAsignaciones' + nro + '" name="chkAsignaciones" type="checkbox" value=\'' + rowJSON + '\' onclick="javascript:clickCheckboxAsignaciones(this);" >';

						return htmlElement;
					}
				},
				{name: "codigoAsignacion", index: "codigoAsignacion", width: (1*widthTable/12), hidden: true },     // hidden
				{name: "clasificadorGasto", index: "clasificadorGasto", width: (1*widthTable/12), hidden: true },	// hidden
				{name: "conceptoCantidadPVI", index: "cantidadPVI", width: (1*widthTable/12), hidden: true },	    // hidden
				{name: "tipoFijoPVI", index: "tipoFijoPVI", width: (1*widthTable/12), hidden: true },	            // hidden
				{name: "editable", index: "editable", width: (1*widthTable/12), hidden: true }					    // hidden
			],
			pager : "#divAsignacionPagerTableRSV",
			loadui: "disable"
		});

		// actualizar lista de asignaciones
		fillGrilla( '#tblAsignacionRSV', getAsignacionesList() );
		updateTotalAsignaciones();

	}
}

$(window).on("resize", function() {

	resizeTable("tblDesplazamientoRSV");
	resizeTable("tblAsignacionRSV");

	// Inicializando las tablas de los modales
	resizeTable("tblDestino");
	resizeTable("tblColaborador");
	resizeTable("tblConceptoViatico");
	resizeTable("tblCadenaPresupuestal");
	resizeTable("tblVacaciones");
	resizeTable("tblCompensaciones");
	resizeTable("tblLicencias");
	resizeTable("tblArchivo");
});