function initElementsImpresion(){
	
	setInitElementsImpresion();	    
}

function setInitElementsImpresion(){
	addEventElement("btnOpcionImpresionRendicion", "click", clickBtnOpcionImpresionRendicion);
	addEventElement("btnCerrarImpresionRendicion", "click", clickBtnCerrarImpresionRendicion);
	
	existeDocumentoFirmado("907",getTrimValue("#txtNroPlanilla"),function(resultado){
		var existe = resultado.existe;
		if(existe){
			$('#radioImpresionDclJurada').prop( 'disabled', false);		
		}else{
			$('#radioImpresionDclJurada').prop( 'disabled', true);
		}
	});
	
}

function removeEventElementsImpresion(){
	removeAllEventsElement("btnOpcionImpresionRendicion");
	removeAllEventsElement("btnCerrarImpresionRendicion");
}

function clickBtnOpcionImpresionRendicion(){
	
		var opcionCheck = $('input:radio[name=radioImpresion]:checked').val();
		
		if(opcionCheck=="rendicion"){
			
			//Aqui llamamos al servicio de la firma electronica...
			
			/*var formPost = $("#formImprimirPost");
			formPost.find("input[name='action']").val("imprimirRendicionViatico");
			formPost.find("input[name='codPlanilla']").val(getTrimValue("#txtNroPlanilla"));
			formPost.submit();*/
			
			descargarPdfFirmado("048",getTrimValue("#txtNroPlanilla"));
			
			
		}else if(opcionCheck=="declaracionJurada"){
			/*var formPost = $("#formImprimirPost");
			formPost.find("input[name='action']").val("imprimirRendicionDeclaracionJurada");
			formPost.find("input[name='codPlanilla']").val(getTrimValue("#txtNroPlanilla"));
			formPost.submit();*/
			
			descargarPdfFirmado("907",getTrimValue("#txtNroPlanilla"));
			
		}if(opcionCheck=="declaracionJuradaPermanencia"){
			var formPost = $("#formImprimirPost");
			formPost.find("input[name='action']").val("imprimirRendicionDeclaracionJuradaPermanencia");
			formPost.find("input[name='codPlanilla']").val(getTrimValue("#txtNroPlanilla"));
			formPost.submit();
		}
		
}

function clickBtnCerrarImpresionRendicion(){
	removeEventElementsImpresion();
	hideModalElement("divImpresion");
}