function initElementsMotivoRechazoSolicitud(numRegistro,nomColaborador,nomDependencia,codPlanilla,importe,codUUOO) {
	$("#codPlanillaRechazoTemp").val(codPlanilla);
	$("#cabRechazo1").html(cabeceraRechazo1(numRegistro,nomColaborador,nomDependencia,codUUOO));
	$("#cabRechazo2").html(cabeceraRechazo2(codPlanilla,importe));
	setHtmlElement("codPlanillaRechazar",codPlanilla + "?");
	setInitElementsMotivoRechazarSolicitud();
	setInitDataMotivoRechazo();
	
}

function setInitElementsMotivoRechazarSolicitud() {
	addEventElement("btnAceptarRechazo", "click", clickBtnAceptarRechazo);
	addEventElement("btnCancelarRechazo", "click", clickBtnCancelarRechazo);
	addEventElement("txtareaMotivoRechazo", "focusout", blurTxtareaMotivoRechazo);
	addEventElement("btnSiMensajeConfirmacionFinalizarRechazo", "click", clickBtnSiMensajeConfirmacionFinalizarRechazo);
	addEventElement("btnNoMensajeConfirmacionFinalizarRechazo", "click", clickBtnNoMensajeConfirmacionFinalizarRechazo);
	addEventElement("btnOkMensajeConfirmacionFinalizarRechazo", "click", clickBtnOkMensajeConfirmacionFinalizarRechazo);
	addEventElement("btnOkMensajeConfirmaRechazo", "click", clickBtnOkMensajeConfirmaRechazo);
	addEventElement("btnAlertMensajeErrorRechazar" ,"click", clickBtnAlertMensajeErrorRechazar);
}

function cabeceraRechazo1(numRegistro,nomColaborador,nomDependencia,codUUOO) {
	var str="";
	str += "	<div class=\"col-xs-12 col-sm-3 col-md-2 col-lg-2\">";
	str += "		<label for=\"txtNombreColaborador\" class=\"text-muted alineartext\">Comisionado:<\/label>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-9 col-md-4 col-lg-4\">";
	str += "		<input class=\"form-control input-sm margen-input\" type=\"text\"";
	str += "			id=\"txtNombreColaborador\" name=\"txtNombreColaborador\" readonly=\"readonly\" value=\""+numRegistro +" - "+ nomColaborador+"\"><\/input>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-3 col-md-2 col-lg-2\">";
	str += "		<label for=\"txtNumUUOO\" class=\"text-muted alineartext\">UUOO:<\/label>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-9 col-md-4 col-lg-4\">";
	str += "		<input class=\"form-control input-sm margen-input\"  type=\"text\"";
	str += "			id=\"txtNumUUOO\" name=\"txtNumUUOO\"  readonly=\"readonly\" value=\""+ codUUOO +" - "+ nomDependencia+"\"><\/input>";
	str += "	<\/div>";
	return str;
} 

function cabeceraRechazo2(codPlanilla,importe) {
	var str="";
	str += "	<div class=\"col-xs-12 col-sm-3 col-md-2 col-lg-2\">";
	str += "		<label for=\"txtNumPlanilla\" class=\"text-muted alineartext\">N&deg; Planilla:<\/label>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-9 col-md-4 col-lg-4\">";
	str += "		<input class=\"form-control input-sm margen-input\" type=\"text\"";
	str += "			id=\"txtNumPlanilla\" name=\"txtNumPlanilla\" readonly=\"readonly\" value=\""+codPlanilla +"\"><\/input>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-3 col-md-2 col-lg-2\">";
	str += "		<label for=\"txtImporte\" class=\"text-muted alineartext\">Importe Registrado:<\/label>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-9 col-md-4 col-lg-4\">";
	str += "		<input class=\"form-control input-sm margen-input\"  type=\"text\"";
	str += "			id=\"txtImporte\" name=\"txtImporte\"  readonly=\"readonly\" value=\""+ importe +"\"><\/input>";
	str += "	<\/div>";	
	return str;
} 

function setInitDataMotivoRechazo() {
	var fechaRechazo = getCurrentDateFormatEsp();
	$('#txtFecRechazo').val(fechaRechazo);
}

function clickBtnCancelarRechazo() {
	$('#txtareaMotivoRechazo').val("");
	removeEventElementsMotivoRechazarSolicitud();
	$('#divMotivoRechazoSolicitud').modal('hide');
}

function removeEventElementsMotivoRechazarSolicitud() {
	removeAllEventsElement("btnCancelarRechazo");
	removeAllEventsElement("btnAceptarRechazo");
	removeAllEventsElement("txtareaMotivoRechazo");	
	removeAllEventsElement("btnSiMensajeConfirmacionFinalizarRechazo");
	removeAllEventsElement("btnNoMensajeConfirmacionFinalizarRechazo");
	removeAllEventsElement("btnOkMensajeConfirmacionFinalizarRechazo");
}

function ejecucionRechazo() {
	
	$.ajax({
		url: contextPathUrl + "/registrarSolicitud.htm?action=rechazarSolicitud",
		data: {
			"numRegistrador": getTrimValue("#hidNumeroRegistroRegistrador"),	
			"codPlanilla": getTrimValue("#codPlanillaRechazoTemp"),
			"motivoRechazo": getTrimValue("#txtareaMotivoRechazo")
		},
		type: "post",
		dataType: "json",
		cache: false,
		success: function(result) {
			
			// error inesperado ajax app
			if ( huboErrorAjax( result ) ) {
				handleErrorAjax( result );
				return;
			}
			
			$('#divMensajeConfirmacionFinalizarRechazo').modal('hide');
			clickBtnNoMensajeConfirmacionFinalizarRechazo();
			
			if ( result.actualizado == "1" ) {
				
				$( '#divMensajeConfirmaRechazo' ).modal( 'show' );
				
			} else {
				
				$( '#divAlertMensajeErrorRechazar' ).modal( 'show' );
				
				if ( $.trim( result.msgActualizado ) != '' ) {
					
					$( '#divAlertMensajeErrorRechazarMsg' ).html( result.msgActualizado );
				}
				
			}
			
		},
		error: function( error ) {
			handleError( error );
		}
	});
}

function clickBtnSiMensajeConfirmacionFinalizarRechazo() {
	ejecucionRechazo();
}

function clickBtnNoMensajeConfirmacionFinalizarRechazo() {
	
	$('#divMensajeConfirmacionFinalizarRechazo').modal('hide');
}

function clickBtnOkMensajeConfirmacionFinalizarRechazo() {

	var motivoRechazo = $.trim( $("#txtareaMotivoRechazo").val() );
	
	if (motivoRechazo != "") {
		clickBtnConsultarSolicitud();	
	}
	
	$('#divMensajeConfirmacionOkFinalizarRechazo').modal('hide');
	$('#divMensajeConfirmacionFinalizarRechazo').modal('hide');
	$('#divMotivoRechazoSolicitud').modal('hide');
	
	removeEventElementsMotivoRechazarSolicitud();
	actualizarGridBandejaRechazo();
}


function clickBtnOkMensajeConfirmaRechazo() {
	var motivoRechazo = $("#txtareaMotivoRechazo").val();
	
	if (trimText(motivoRechazo) != "") {
		$('#txtareaMotivoRechazo').val("");
		clickBtnConsultarSolicitud();
	}
	
	$('#divMensajeConfirmaRechazo').modal('hide');
	$('#divMensajeConfirmacionFinalizarRechazo').modal('hide');
	$('#divMotivoRechazoSolicitud').modal('hide');	
	removeEventElementsMotivoRechazarSolicitud();
	actualizarGridBandejaRechazo();
}


function actualizarGridBandejaRechazo(){
	
	$('#txtareaMotivoRechazo').val("");
	
	clickBtnCancelarRechazo();
}

function blurTxtareaMotivoRechazo() {

	var OBSERVACION_MAX_SIZE = 1000;
	
	// evita que se ingrese más de 1000 caracteres (en IE8,9 no funciona el maxlength)
	var control = $( '#txtareaMotivoRechazo' );
	var controlValue = $.trim( control.val() );
	
	if ( controlValue.length > OBSERVACION_MAX_SIZE ) {
		controlValue = controlValue.substring(0, OBSERVACION_MAX_SIZE);
		control.val( controlValue  );
	}
	
}

function clickBtnAceptarRechazo() {
	var motivoRechazo = $.trim( $( "#txtareaMotivoRechazo" ).val() );
	
	if (motivoRechazo != "" ) {
		$('#divMensajeConfirmacionFinalizarRechazo').modal('show');
		
	} else {
		//$("#mensajeFinRechazar").html("Se debe de ingresar un motivo de anulaci&oacute;n v&aacute;lido.");
		$('#divMensajeConfirmacionOkFinalizarRechazo').modal('show');
	}	
}

function clickBtnAlertMensajeErrorRechazar() {
	
	$("#divAlertMensajeErrorRechazar").modal("hide");
}
