
function initElementsMotivoAutorizacionSolicitud(numRegistro,nomColaborador,nomDependencia,codPlanilla,importe,codUUOO) {
	$("#codPlanillaTemp").val(codPlanilla);
	setHtmlElement("codPlanillaAutorizar",codPlanilla + "?");
	setInitElementsMotivoAutorizarSolicitud(); 
}

function setInitElementsMotivoAutorizarSolicitud() {
	addEventElement("btnSiMensajeConfirmacionFinalizarAutorizacion", "click", clickBtnSiMensajeConfirmacionFinalizarAutorizacion);
	addEventElement("btnNoMensajeConfirmacionFinalizarAutorizacion", "click", clickBtnNoMensajeConfirmacionFinalizarAutorizacion);
	addEventElement("btnOkMensajeConfirmacionFinalizarAutorizacion", "click", clickBtnOkMensajeConfirmacionFinalizarAutorizacion);
	addEventElement("btnOkMensajeConfirmaAutorizacion", "click", clickBtnOkMensajeConfirmaAutorizacion);
	addEventElement("btnAlertMensajeErrorAutorizar" ,"click", clickBtnAlertMensajeErrorAutorizar);
}

function clickBtnCancelarAutorizacion() {
	removeEventElementsMotivoAutorizarSolicitud();
	$('#divMotivoAutorizacionSolicitud').modal('hide');
}

function removeEventElementsMotivoAutorizarSolicitud() {
	removeAllEventsElement("btnSiMensajeConfirmacionFinalizarAutorizacion");
	removeAllEventsElement("btnNoMensajeConfirmacionFinalizarAutorizacion");
	removeAllEventsElement("btnOkMensajeConfirmacionFinalizarAutorizacion");
}

function ejecucionAutorizacion() {
	
	var numeroRegistroReg = $("#hidNumeroRegistroRegistrador").val();
	var codigoRegistrador = $("#hidCodigoRegistrador").val();
	var codigoDocumento = $("#codPlanillaTemp").val();
	ajax_data = {
		"numeroRegistrador": numeroRegistroReg,	
		"codigoRegistrador": codigoRegistrador,
		"codigoDocumento": codigoDocumento
	};
	
	$.ajax({
		data: ajax_data,
		url: contextPathUrl + "/registrarSolicitud.htm?action=autorizarSolicitud",
		type: "post",
		dataType: "json",
		cache: false,
		success: function(respuesta) {
			$('#divMensajeConfirmacionFinalizarAutorizacion').modal('hide');
			if(respuesta.actualizado =="1"){
				removeAllEventsElement("btnOkMensajeConfirmaAutorizacion");
				addEventElement("btnOkMensajeConfirmaAutorizacion", "click", clickBtnOkMensajeConfirmaAutorizacion);
				$('#divMensajeConfirmaAutorizacion').modal('show');
			}
			else{ 
				$("#divAlertMensajeErrorAutorizar").modal("show");}
		},
		error: function(xhr, ajaxOptions, thrownError) {
			
		}
	});
	
	
}

function clickBtnSiMensajeConfirmacionFinalizarAutorizacion(){
	ejecucionAutorizacion();
}

function clickBtnNoMensajeConfirmacionFinalizarAutorizacion(){
	$('#divMensajeConfirmacionFinalizarAutorizacion').modal('hide');
	$("#divMotivoAutorizacionSolicitud").modal("hide");
	
}

function clickBtnOkMensajeConfirmacionFinalizarAutorizacion(){
	$('#divMensajeConfirmacionOkFinalizarAutorizacion').modal('hide');
	$('#divMensajeConfirmacionFinalizarAutorizacion').modal('hide');
	$('#divMotivoAutorizacionSolicitud').modal('hide');	
	removeEventElementsMotivoAutorizarSolicitud();
	actualizarGridBandejaAutorizacion();
}


function clickBtnOkMensajeConfirmaAutorizacion(){
	$('#divMensajeConfirmaAutorizacion').modal('hide');
	$('#divMensajeConfirmacionFinalizarAutorizacion').modal('hide');
	$('#divMotivoAutorizacionSolicitud').modal('hide');	
	removeEventElementsMotivoAutorizarSolicitud();
	actualizarGridBandejaAutorizacion();
	removeAllEventsElement("btnConsultarSolicitud");
	clickBtnConsultarSolicitud();
}

function actualizarGridBandejaAutorizacion(){
	 clickBtnCancelarAutorizacion();
}

function clickBtnAlertMensajeErrorAutorizar(){
	$("#divAlertMensajeErrorAutorizar").modal("hide");
}