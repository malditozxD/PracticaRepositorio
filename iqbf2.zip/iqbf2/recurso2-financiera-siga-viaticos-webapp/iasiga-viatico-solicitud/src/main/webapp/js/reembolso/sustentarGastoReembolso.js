function initElementsSustentarGastoReembolso() {
	
	setInitElementsSustentarGastoDetalle();
	setInitComprobanteTable(getValueInputText("hidMoneda"));
	setInitGastoViaticoTable(getValueInputText("hidMoneda"));
	setInitPasajeTasaEmbarqueTable(getValueInputText("hidMoneda"));
	setInitConceptoViaticoTable(getValueInputText("hidMoneda"));
	callObtenerComprobantesGastoPasajeConcepto();
}

function setInitElementsSustentarGastoDetalle() {
	
	hideElement("divHiddenModificarReembolsoPost");
	setValueInputText("selIndicadorDDJJ", getValueInputText("hidIndicadorExteriorDDJJ"));
	addEventElement("divRegistroComprobanteHeadingPanel", "click", clickDivRegistroComprobanteHeadingPanel);
	addEventElement("divGastoViaticoHeadingPanel", "click", clickDivGastoViaticoHeadingPanel);
	addEventElement("divResumenGastoHeadingPanel", "click", clickDivResumenGastoHeadingPanel);
	addEventElement("btnAgregarComprobante", "click", clickBtnAgregarComprobante);
	addEventElement("btnGrabarReembolso", "click", clickBtnGrabarReembolso);
	addEventElement("btnRetornarReembolso", "click", clickBtnRetornarReembolso);
	
	addEventElement("selIndicadorDDJJ", "change", changeSelIndicadorDDJJ);
	
	addEventElement("btnAceptarMensajeConfirmacionSustentarGastoReembolso", "click", clickBtnAceptarMensajeConfirmacionSustentarGastoReembolso);
	addEventElement("btnAceptarMensajeConfirmacionErrorSustentarGastoReembolso", "click", clickBtnAceptarMensajeConfirmacionErrorSustentarGastoReembolso);
	
	addEventElement("btnSiEliminarComprobanteSustentarGastoReembolso", "click", clickBtnSiEliminarComprobanteSustentarGastoReembolso);
	addEventElement("btnNoEliminarComprobanteSustentarGastoReembolso", "click", clickBtnNoEliminarComprobanteSustentarGastoReembolso);
	addEventElement("btnSiRegistrarSustentoSustentarGastoReembolso", "click", clickBtnSiRegistrarSustentoSustentarGastoReembolso);
	addEventElement("btnNoRegistrarSustentoSustentarGastoReembolso", "click", clickBtnNoRegistrarSustentoSustentarGastoReembolso);
}

function setInitComprobanteTable(monedaReembolso) {
	
	var comprobanteTable = $("#tblComprobante");
	var heightJqGrid = 200;
	setStyleElement("divComprobanteTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 2, true));
	if (comprobanteTable) {
		var comprobanteTableDiv = $("#divComprobanteTable");
		var widthTable = comprobanteTableDiv.width();
		comprobanteTable.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Codigo Plan Viaje",
				"Secuencial",
				"Concepto ID",
				"",
				"Nro.",
				"Codigo Tipo Documento",
				"Tipo Doc.",
				"Serie",
				"Nro. Documento",
				"Fecha Doc.",
				"Proveedor/Empleado",
				"Monto Dcto.",
				"Monto Dcto. " + monedaReembolso,
				"Monto Rendido",
				"Monto Rendido " + monedaReembolso,
				"Flag Rendicion Total",
				"Acción"
			],
			colModel: [
				{name: "planViajeId", index: "planViajeId", width: (1*widthTable/20), hidden: true},
				{name: "secuencial", index: "secuencial", width: (1*widthTable/20), hidden: true},
				{name: "conceptoId", index: "conceptoId", width: (1*widthTable/20), hidden: true},
				{name: "columna01", index: "columna01", width: (0.5*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "";
						if (rowData.flagRendicionTotal == "0") {
							htmlElement = "<input id=\"chkJqGridComprobante" + rowData.secuencial + "\" name=\"chkJqGridComprobante\" class=\"chkJqGridComprobanteClass\" type=\"checkbox\" value=\"" + rowData.secuencial + "\" onclick=\"javascript:clickCheckboxJqGridComprobante('" + rowData.secuencial + "');\" />";
						}
						return htmlElement;
					}
				},
				{name: "identificador", index: "identificador", width: (0.7*widthTable/20), align: "right"},
				{name: "tipoDocumento", index: "tipoDocumento", width: (1*widthTable/20), hidden: true},
				{name: "descripcionTipoDocumento", index: "descripcionTipoDocumento", width: (4*widthTable/20)},
				{name: "serie", index: "serie", width: (1.7*widthTable/20)},
				{name: "numeroDocumento", index: "numeroDocumento", width: (2*widthTable/20)},
				{name: "fechaDocumento", index: "fechaDocumento", width: (1.8*widthTable/20), align: "center"},
				{name: "nombreRazonSocial", index: "nombreRazonSocial", width: (3.7*widthTable/20)},
				{name: "montoTotal", index: "montoTotal", width: (1*widthTable/20), hidden: true},
				{name: "montoTotalFormateado", index: "montoTotalFormateado", width: (1.7*widthTable/20), align: "right"},
				{name: "mtoReconocido", index: "mtoReconocido", width: (1*widthTable/20), hidden: true},
				{name: "mtoReconocidoFormateado", index: "mtoReconocidoFormateado", width: (1.9*widthTable/20), align: "right"},
				{name: "flagRendicionTotal", index: "flagRendicionTotal", width: (1*widthTable/20), hidden: true},
				{name: "accion", index: "accion", width: (2*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "";
						if (rowData.flagRendicionTotal == "0") {
							var linkEditarComprobante = "<a class=\"jqGridViaticoLinkClass\" onclick=\"javascript:clickLinkEditarComprobante('" + rowData.secuencial + "');\">";
							linkEditarComprobante += "<img border=\"0\" title=\"editar\" width=\"14\" height=\"15\" src=\"/a/imagenes/sigad/acciones/edit.gif\">";
							linkEditarComprobante += "</a>";
							var linkEliminarComprobante = "<a class=\"jqGridViaticoLinkClass\" onclick=\"javascript:clickLinkEliminarComprobante('" + rowData.secuencial + "');\">";
							linkEliminarComprobante += "<img border=\"0\" title=\"eliminar\" width=\"14\" height=\"15\" src=\"/a/imagenes/sigad/acciones/delete.png\">";
							linkEliminarComprobante += "</a>";
							htmlElement = linkEditarComprobante + "&nbsp;&nbsp;" + linkEliminarComprobante;
						}
						return htmlElement;
					}
				}
			],
			rowattr: function(dataTable) {
				if (dataTable.flagRendicionTotal == "1") {
					return {"class": "boldFontTableClass"};
				}
			},
			caption: "Registro de Comprobantes",
			pager: "#divComprobantePagerTable",
			loadui: "disable"
		});
		comprobanteTable.clearGridData();
	}
}

function setInitGastoViaticoTable(monedaReembolso) {
	
	var gastoViaticoTable = $("#tblGastoViatico");
	var heightJqGrid = 200;
	setStyleElement("divGastoViaticoTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 1, true));
	if (gastoViaticoTable) {
		var gastoViaticoTableDiv = $("#divGastoViaticoTable");
		var widthTable = gastoViaticoTableDiv.width();
		gastoViaticoTable.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Secuencia",
				"Fecha",
				"Alimentación",
				"Hospedaje",
				"Movilidad",
				"Traslado",
				"Total " + monedaReembolso,
				"Flag Plan Viaje Informe Distrib Total"
			],
			colModel: [
				{name: "secuencia", index: "secuencia", width: (1*widthTable/20), hidden: true},
				{name: "fecViatico", index: "fecViatico", width: (4*widthTable/20), align: "center"},
				{name: "montoAlimentacion", index: "montoAlimentacion", width: (3*widthTable/20), align: "right"},
				{name: "montoHospedaje", index: "montoHospedaje", width: (3*widthTable/20), align: "right"},
				{name: "montoMovilidad", index: "montoMovilidad", width: (3*widthTable/20), align: "right"},
				{name: "montoTraslado", index: "montoTraslado", width: (3*widthTable/20), align: "right"},
				{name: "montoTotal", index: "montoTotal", width: (4*widthTable/20), align: "right"},
				{name: "flagPlanViajeInformeDistribTotal", index: "flagPlanViajeInformeDistribTotal", width: (1*widthTable/20), hidden: true}
			],
			rowattr: function(dataTable) {
				if (dataTable.flagPlanViajeInformeDistribTotal == "1") {
					return {"class": "boldFontTableClass"};
				}
			},
			caption: "Gastos",
			pager: "#divGastoViaticoPagerTable",
			loadui: "disable"
		});
		gastoViaticoTable.clearGridData();
	}
}

function setInitPasajeTasaEmbarqueTable(monedaReembolso) {
	
	var pasajeTasaEmbarqueTable = $("#tblPasajeTasaEmbarque");
	var heightJqGrid = 200;
	setStyleElement("divPasajeTasaEmbarqueTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 1, true));
	if (pasajeTasaEmbarqueTable) {
		var pasajeTasaEmbarqueTableDiv = $("#divPasajeTasaEmbarqueTable");
		var widthTable = pasajeTasaEmbarqueTableDiv.width();
		pasajeTasaEmbarqueTable.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Secuencia",
				"Fecha",
				"Pasaje",
				"TUUA",
				"Total " + monedaReembolso,
				"Flag Plan Viaje Informe Distrib Total"
			],
			colModel: [
				{name: "secuencia", index: "secuencia", width: (1*widthTable/20), hidden: true},
				{name: "fecViatico", index: "fecViatico", width: (4*widthTable/20), align: "center"},
				{name: "montoPasaje", index: "montoPasaje", width: (6*widthTable/20), align: "right"},
				{name: "montoTUUA", index: "montoTUUA", width: (6*widthTable/20), align: "right"},
				{name: "montoTotal", index: "montoTotal", width: (4*widthTable/20), align: "right"},
				{name: "flagPlanViajeInformeDistribTotal", index: "flagPlanViajeInformeDistribTotal", width: (1*widthTable/20), hidden: true}
			],
			rowattr: function(dataTable) {
				if (dataTable.flagPlanViajeInformeDistribTotal == "1") {
					return {"class": "boldFontTableClass"};
				}
			},
			caption: "Pasaje y Tasa Embarque",
			pager: "#divPasajeTasaEmbarquePagerTable",
			loadui: "disable"
		});
		pasajeTasaEmbarqueTable.clearGridData();
	}
}

function setInitConceptoViaticoTable(monedaReembolso) {
	
	var conceptoViaticoTable = $("#tblConceptoViatico");
	var heightJqGrid = 200;
	setStyleElement("divConceptoViaticoTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 1, true));
	if (conceptoViaticoTable) {
		var conceptoViaticoTableDiv = $("#divConceptoViaticoTable");
		var widthTable = conceptoViaticoTableDiv.width();
		conceptoViaticoTable.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Codigo Plan Viaje",
				"Secuencial",
				"Cod.",
				"Concepto",
				"Gasto Realizado " + monedaReembolso,
				"Flag Concepto Total"
			],
			colModel: [
				{name: "planViajeID", index: "planViajeID", width: (1*widthTable/20), hidden: true},
				{name: "secuencial", index: "secuencial", width: (1*widthTable/20), hidden: true},
				{name: "conceptoID", index: "conceptoID", width: (2*widthTable/20), align: "center"},
				{name: "descripcionConcepto", index: "descripcionConcepto", width: (6*widthTable/20)},
				{name: "monto", index: "monto", width: (3*widthTable/20), align: "right"},
				{name: "flagPlanViajeConceptoTotal", index: "flagPlanViajeConceptoTotal", width: (1*widthTable/20), hidden: true}
			],
			rowattr: function(dataTable) {
				if (dataTable.flagPlanViajeConceptoTotal == "1") {
					return {"class": "boldFontTableClass"};
				}
			},
			caption: "Concepto",
			pager: "#divConceptoViaticoPagerTable",
			loadui: "disable"
		});
		conceptoViaticoTable.clearGridData();
	}
}

function clickDivRegistroComprobanteHeadingPanel() {
	if (getValueInputText("hidEstadoRegistroComprobantePanel") == "maximize") {
		setValueInputText("hidEstadoRegistroComprobantePanel", "minimize");
		setSrcImageElement("imgRegistroComprobanteHeadingPanel", minimizeURL);
		hideElement("divRegistroComprobanteBodyPanel");
	}
	else if (getValueInputText("hidEstadoRegistroComprobantePanel") == "minimize") {
		setValueInputText("hidEstadoRegistroComprobantePanel", "maximize");
		setSrcImageElement("imgRegistroComprobanteHeadingPanel", maximizeURL);
		showElement("divRegistroComprobanteBodyPanel");
		triggerResizeEvent();
	}
}

function clickDivGastoViaticoHeadingPanel() {
	if (getValueInputText("hidEstadoGastoViaticoPanel") == "maximize") {
		setValueInputText("hidEstadoGastoViaticoPanel", "minimize");
		setSrcImageElement("imgGastoViaticoHeadingPanel", minimizeURL);
		hideElement("divGastoViaticoBodyPanel");
	}
	else if (getValueInputText("hidEstadoGastoViaticoPanel") == "minimize") {
		setValueInputText("hidEstadoGastoViaticoPanel", "maximize");
		setSrcImageElement("imgGastoViaticoHeadingPanel", maximizeURL);
		showElement("divGastoViaticoBodyPanel");
		triggerResizeEvent();
	}
}

function clickDivResumenGastoHeadingPanel() {
	if (getValueInputText("hidEstadoResumenGastoPanel") == "maximize") {
		setValueInputText("hidEstadoResumenGastoPanel", "minimize");
		setSrcImageElement("imgResumenGastoHeadingPanel", minimizeURL);
		hideElement("divResumenGastoBodyPanel");
	}
	else if (getValueInputText("hidEstadoResumenGastoPanel") == "minimize") {
		setValueInputText("hidEstadoResumenGastoPanel", "maximize");
		setSrcImageElement("imgResumenGastoHeadingPanel", maximizeURL);
		showElement("divResumenGastoBodyPanel");
		triggerResizeEvent();
	}
}

function clickBtnAgregarComprobante() {
	if (validarAgregarComprobante()) {
		var dataParametrosComprobante = new Object();
		dataParametrosComprobante.planViajeId = getValueInputText("hidCodPlanViaje");
		dataParametrosComprobante.estadoLlamada = "N";
		dataParametrosComprobante.secuencial = "";
		dataParametrosComprobante.origenLlamada = "R";
		dataParametrosComprobante.saldoRendir = "";
		dataParametrosComprobante.numeroRegistroColaborador = getValueInputText("hidNumeroRegistroColaborador");
		initElementsRegistrarModificarComprobanteRendicion(dataParametrosComprobante);
	    showModalElement("divRegistrarModificarComprobanteRendicion");
	    triggerResizeEvent();
	    triggerResizeEventTooSlow();
	}
}

function clickBtnGrabarReembolso() {
	showModalElement("divMensajeConfirmacionRegistrarSustentoSustentarGastoReembolso");
}

function clickBtnRetornarReembolso() {
	var formNode = $("#formModificarReembolso");
	if (formNode) {
		formNode.find("input[name='action']").val("mostrarModificarViatico");
		formNode.find("input[name='codPlanilla']").val(getUpperCaseValueInputText("txtNroPlanilla"));
		formNode.find("input[name='dataJSON']").val(dataJSON);
		formNode.submit();
	}
}

function changeSelIndicadorDDJJ() {
	var dataValidacion = validarNoExistenComprobantes();
	if (!dataValidacion.flagNoExistenComprobantes) {
		showMensajeConfirmacionAplicativoWithBody(dataValidacion.idDivModalErrorMessage, dataValidacion.idDivTituloPanelErrorMessage, dataValidacion.idDivBodyPanelErrorMessage, dataValidacion.idEtiquetaErrorMessage, dataValidacion.errorMessageTitulo, dataValidacion.errorMessageBody);
		setValueInputText("selIndicadorDDJJ", getValueInputText("hidIndicadorExteriorDDJJ"));
	}
}

function clickBtnAceptarMensajeConfirmacionSustentarGastoReembolso() {
	hideModalElement("divMensajeConfirmacionSustentarGastoReembolso");
}

function clickBtnAceptarMensajeConfirmacionErrorSustentarGastoReembolso() {
	hideModalElement("divMensajeConfirmacionErrorSustentarGastoReembolso");
}

function clickBtnSiEliminarComprobanteSustentarGastoReembolso() {
	hideModalElement("divMensajeConfirmacionEliminarComprobanteSustentarGastoReembolso");
	callEliminarComprobante();
}

function clickBtnNoEliminarComprobanteSustentarGastoReembolso() {
	setValueInputText("hidSecuencialEliminarComprobanteSustentarGastoReembolso", "");
	setValueInputText("hidConceptoIdEliminarComprobanteSustentarGastoReembolso", "");
	setValueInputText("hidMtoReconocidoEliminarComprobanteSustentarGastoReembolso", "");
	hideModalElement("divMensajeConfirmacionEliminarComprobanteSustentarGastoReembolso");
}

function clickBtnSiRegistrarSustentoSustentarGastoReembolso() {
	hideModalElement("divMensajeConfirmacionRegistrarSustentoSustentarGastoReembolso");
	callRegistrarSustentoGasto();
}

function clickBtnNoRegistrarSustentoSustentarGastoReembolso() {
	hideModalElement("divMensajeConfirmacionRegistrarSustentoSustentarGastoReembolso");
}

function clickCheckboxJqGridComprobante(secuencial) {
	
}

function clickLinkEditarComprobante(secuencial) {
	
	var dataParametrosComprobante = new Object();
	dataParametrosComprobante.planViajeId = getValueInputText("hidCodPlanViaje");
	dataParametrosComprobante.estadoLlamada = "E";
	dataParametrosComprobante.secuencial = secuencial;
	dataParametrosComprobante.origenLlamada = "R";
	dataParametrosComprobante.saldoRendir = "";
	dataParametrosComprobante.numeroRegistroColaborador = getValueInputText("hidNumeroRegistroColaborador");
	initElementsRegistrarModificarComprobanteRendicion(dataParametrosComprobante);
    showModalElement("divRegistrarModificarComprobanteRendicion");
    triggerResizeEvent();
    triggerResizeEventTooSlow();
}

function clickLinkEliminarComprobante(secuencial) {
	
	var comprobanteTable = $("#tblComprobante");
	var rowData = comprobanteTable.getRowData(secuencial);
	setValueInputText("hidSecuencialEliminarComprobanteSustentarGastoReembolso", secuencial);
	setValueInputText("hidConceptoIdEliminarComprobanteSustentarGastoReembolso", rowData.conceptoId);
	setValueInputText("hidMtoReconocidoEliminarComprobanteSustentarGastoReembolso", rowData.mtoReconocido);
	showModalElement("divMensajeConfirmacionEliminarComprobanteSustentarGastoReembolso");
}

function validarAgregarComprobante() {
	
	var dataValidacion;
	
	dataValidacion = validarNoExistenCambiosSustento();
	if (!dataValidacion.flagNoExistenCambiosSustento) {
		showMensajeConfirmacionAplicativoWithBody(dataValidacion.idDivModalErrorMessage, dataValidacion.idDivTituloPanelErrorMessage, dataValidacion.idDivBodyPanelErrorMessage, dataValidacion.idEtiquetaErrorMessage, dataValidacion.errorMessageTitulo, dataValidacion.errorMessageBody);
		return false;
	}
	
	return true;
}

function validarNoExistenComprobantes() {
	
	var flagNoExistenComprobantes = true;
	var errorMessage = "";
	var comprobanteTable = $("#tblComprobante");
	var numRowsComprobanteTable = comprobanteTable.jqGrid("getGridParam", "records")
	
	if (flagNoExistenComprobantes && numRowsComprobanteTable > 0) {
		flagNoExistenComprobantes = false;
		errorMessage = errorMessageSustentarGastoReembolso.existenComprobantesAsociados;
	}
	
	var dataValidacion = {
		flagNoExistenComprobantes: flagNoExistenComprobantes,
		idDivModalErrorMessage: "divMensajeConfirmacionErrorSustentarGastoReembolso",
		idDivTituloPanelErrorMessage: "divTituloPanelMensajeConfirmacionErrorSustentarGastoReembolso",
		idDivBodyPanelErrorMessage: "divBodyPanelMensajeConfirmacionErrorSustentarGastoReembolso",
		idEtiquetaErrorMessage: "etiquetaMensajeConfirmacionErrorSustentarGastoReembolso",
		errorMessageTitulo: "Error",
		errorMessageBody: errorMessage
	};
	return dataValidacion;
}

function validarNoExistenCambiosSustento() {
	
	var flagNoExistenCambiosSustento = true;
	var errorMessage = "";
	
	if (getValueInputText("hidTipoDestino") == "02") {
		if (flagNoExistenCambiosSustento && getValueInputText("hidIndicadorExteriorDDJJ") != getValueInputText("selIndicadorDDJJ")) {
			flagNoExistenCambiosSustento = false;
			errorMessage = errorMessageSustentarGastoReembolso.grabarSustento;
		}
	}
	
	var dataValidacion = {
		flagNoExistenCambiosSustento: flagNoExistenCambiosSustento,
		idDivModalErrorMessage: "divMensajeConfirmacionErrorSustentarGastoReembolso",
		idDivTituloPanelErrorMessage: "divTituloPanelMensajeConfirmacionErrorSustentarGastoReembolso",
		idDivBodyPanelErrorMessage: "divBodyPanelMensajeConfirmacionErrorSustentarGastoReembolso",
		idEtiquetaErrorMessage: "etiquetaMensajeConfirmacionErrorSustentarGastoReembolso",
		errorMessageTitulo: "Error",
		errorMessageBody: errorMessage
	};
	return dataValidacion;	
}

function callRegistrarSustentoGasto() {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/registrarReembolso.htm?action=registrarSustentoGasto",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codPlanViaje": getValueInputText("hidCodPlanViaje"),
				"montoDevueltoComprobanteTotal": getValueInputText("hidMontoDevueltoComprobanteTotal"),
				"indicadorExteriorDDJJ": getValueInputText("selIndicadorDDJJ"),
				"tipoDestino": getValueInputText("hidTipoDestino"),
				"flagMenorIgual4Horas": getValueInputText("hidFlagMenorIgual4Horas"),
				"moneda": getValueInputText("hidMoneda")
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showModalElement("divMensajeConfirmacionLoadingSustentarGastoReembolso");
			},
			complete: function() {
				hideModalElement("divMensajeConfirmacionLoadingSustentarGastoReembolso");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var codigoOperacion = result.codigoOperacion;
				var errorMessage = result.errorMessage;
				var successMessage = result.successMessage;
				if (codigoOperacion != null && codigoOperacion == "00") {
					setValueInputText("hidIndicadorExteriorDDJJ", getValueInputSelect("selIndicadorDDJJ", "0"));
					showMensajeConfirmacionAplicativoWithoutBody("divMensajeConfirmacionSustentarGastoReembolso", "divTituloPanelMensajeConfirmacionSustentarGastoReembolso", "divBodyPanelMensajeConfirmacionSustentarGastoReembolso", successMessage);
				}
				else {
					showMensajeConfirmacionAplicativoWithoutBody("divMensajeConfirmacionErrorSustentarGastoReembolso", "divTituloPanelMensajeConfirmacionErrorSustentarGastoReembolso", "divBodyPanelMensajeConfirmacionErrorSustentarGastoReembolso", errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callRegistrarSustentoGasto");
			}
		});
	}, 500);
}

function callEliminarComprobante() {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/registroGeneral.htm?action=eliminarComprobante",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"planViajeId": getValueInputText("hidCodPlanViaje"),
				"secuencial": getValueInputText("hidSecuencialEliminarComprobanteSustentarGastoReembolso"),
				"conceptoId": getValueInputText("hidConceptoIdEliminarComprobanteSustentarGastoReembolso"),
				"mtoReconocido": getValueInputText("hidMtoReconocidoEliminarComprobanteSustentarGastoReembolso"),
				"codigoPaginaCaller": getValueInputText("hidCodigoPaginaCaller")
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showModalElement("divMensajeConfirmacionLoadingSustentarGastoReembolso");
			},
			complete: function() {
				hideModalElement("divMensajeConfirmacionLoadingSustentarGastoReembolso");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var codigoOperacion = result.codigoOperacion;
				var errorMessage = result.errorMessage;
				var successMessage = result.successMessage;
				if (codigoOperacion != null && codigoOperacion == "00") {
					setValueInputText("hidSecuencialEliminarComprobanteSustentarGastoReembolso", "");
					setValueInputText("hidConceptoIdEliminarComprobanteSustentarGastoReembolso", "");
					setValueInputText("hidMtoReconocidoEliminarComprobanteSustentarGastoReembolso", "");
					//setValueInputText("hidFlagHabilitarCerrarRendicion", "0");
					showMensajeConfirmacionAplicativoWithoutBody("divMensajeConfirmacionSustentarGastoReembolso", "divTituloPanelMensajeConfirmacionSustentarGastoReembolso", "divBodyPanelMensajeConfirmacionSustentarGastoReembolso", successMessage);
					callObtenerComprobantesGastoPasajeConcepto();
				}
				else {
					showMensajeConfirmacionAplicativoWithoutBody("divMensajeConfirmacionErrorSustentarGastoReembolso", "divTituloPanelMensajeConfirmacionErrorSustentarGastoReembolso", "divBodyPanelMensajeConfirmacionErrorSustentarGastoReembolso", errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callEliminarComprobante");
			}
		});
	}, 500);
}

function callObtenerComprobantesGastoPasajeConcepto() {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/registrarReembolso.htm?action=obtenerComprobantesGastoPasajeConcepto",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codigoPlanViaje": getValueInputText("hidCodPlanViaje"),
				"simboloMoneda": getValueInputText("hidMoneda")
			},
			beforeSend: function() {
				/*
				showModalElement("divScreenBlock");
				showModalElement("divMensajeConfirmacionLoadingRegistrarModificarRendicion");
				*/
			},
			complete: function() {
				/*
				hideModalElement("divMensajeConfirmacionLoadingRegistrarModificarRendicion");
				hideModalElement("divScreenBlock");
				*/
			},
			success: function(result) {
				var codigoConsulta = result.codigoConsulta;
				var errorMessage = result.errorMessage;
				if (codigoConsulta != null && codigoConsulta == "00") {
					var reembolsoVO = result.reembolsoVO;
					var planViajeRendicionList = reembolsoVO.planViajeRendicionList;
					var gastoViaticoList = reembolsoVO.gastoViaticoList;
					var pasajeTasaEmbarqueList = reembolsoVO.pasajeTasaEmbarqueList;
					var planViajeConceptoList = reembolsoVO.planViajeConceptoList;
					actualizarMontosSustentarGastoReembolso(reembolsoVO);
					showComprobantesSustentarGastoReembolso(planViajeRendicionList);
					showGastoViaticoSustentarGastoReembolso(gastoViaticoList);
					showPasajeTasaEmbarqueSustentarGastoReembolso(pasajeTasaEmbarqueList);
					showAsignacionConceptoSustentarGastoReembolso(planViajeConceptoList);
				}
				else {
					showMensajeConfirmacionAplicativoWithoutBody("divMensajeConfirmacionErrorSustentarGastoReembolso", "divTituloPanelMensajeConfirmacionErrorSustentarGastoReembolso", "divBodyPanelMensajeConfirmacionErrorSustentarGastoReembolso", errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callObtenerComprobantesGastoPasajeConcepto");
			}
		});
	}, 500);
}

function actualizarMontosSustentarGastoReembolso(reembolsoVO) {
	
	setValueInputText("hidMontoComprobanteTotal", reembolsoVO.montoComprobanteTotal);
	setValueInputText("hidMontoDevueltoComprobanteTotal", reembolsoVO.montoDevueltoComprobanteTotal);
	setValueInputText("hidMontoAsignadoTotal", reembolsoVO.montoAsignadoTotal);
	setValueInputText("hidMontoComprobanteTotalFormateado", reembolsoVO.montoComprobanteTotalFormateado);
}

function showComprobantesSustentarGastoReembolso(planViajeRendicionArray) {
	
	var comprobanteTable = $("#tblComprobante");
	comprobanteTable.clearGridData();
	if (planViajeRendicionArray != null && planViajeRendicionArray.length > 0) {
		//setValueInputText("hidFlagRegistroComprobante", "1");
		for (var i = 0; i < planViajeRendicionArray.length; i++) {
			var comprobante = planViajeRendicionArray[i];
			var identificador = i + 1;
			if (comprobante.flagRendicionTotal == "1") {
				identificador = "";
			}
			var datarow = {
				planViajeId: comprobante.planViajeId,
				secuencial: comprobante.secuencial,
				conceptoId: comprobante.conceptoId,
				columna01: "",
				identificador: identificador,
				tipoDocumento: comprobante.tipoDocumento,
				descripcionTipoDocumento: comprobante.descripcionTipoDocumento,
				serie: comprobante.serie,
				numeroDocumento: comprobante.numeroDocumento,
				fechaDocumento: comprobante.fechaDocumentoFormateada,
				nombreRazonSocial: comprobante.nombreRazonSocial,
				montoTotal: comprobante.montoTotal,
				montoTotalFormateado: comprobante.montoTotalFormateado,
				mtoReconocido: comprobante.mtoReconocido,
				mtoReconocidoFormateado: comprobante.mtoReconocidoFormateado,
				flagRendicionTotal: comprobante.flagRendicionTotal,
				accion: comprobante.secuencial
			};
			comprobanteTable.jqGrid("addRowData", datarow.secuencial, datarow);
		}
		comprobanteTable.trigger("reloadGrid");
	}
	else {
		//setValueInputText("hidFlagRegistroComprobante", "0");
	}
}

function showGastoViaticoSustentarGastoReembolso(gastoViaticoArray) {
	
	var gastoViaticoTable = $("#tblGastoViatico");
	gastoViaticoTable.clearGridData();
	if (gastoViaticoArray != null && gastoViaticoArray.length > 0) {
		for (var i = 0; i < gastoViaticoArray.length; i++) {
			var gastoViatico = gastoViaticoArray[i];
			var secuencia = i + 1;
			var datarow = {
				secuencia: secuencia,
				fecViatico: gastoViatico.fecViaticoFormateada,
				montoAlimentacion: gastoViatico.montoAlimentacionFormateado,
				montoHospedaje: gastoViatico.montoHospedajeFormateado,
				montoMovilidad: gastoViatico.montoMovilidadFormateado,
				montoTraslado: gastoViatico.montoTrasladoFormateado,
				montoTotal: gastoViatico.montoTotalFormateado,
				flagPlanViajeInformeDistribTotal: gastoViatico.flagPlanViajeInformeDistribTotal
			};
			gastoViaticoTable.jqGrid("addRowData", datarow.secuencia, datarow);
		}
		gastoViaticoTable.trigger("reloadGrid");
	}
}

function showPasajeTasaEmbarqueSustentarGastoReembolso(pasajeTasaEmbarqueArray) {
	
	var pasajeTasaEmbarqueTable = $("#tblPasajeTasaEmbarque");
	pasajeTasaEmbarqueTable.clearGridData();
	if (pasajeTasaEmbarqueArray != null && pasajeTasaEmbarqueArray.length > 0) {
		for (var i = 0; i < pasajeTasaEmbarqueArray.length; i++) {
			var pasajeTasaEmbarque = pasajeTasaEmbarqueArray[i];
			var secuencia = i + 1;
			var datarow = {
				secuencia: secuencia,
				fecViatico: pasajeTasaEmbarque.fecViaticoFormateada,
				montoPasaje: pasajeTasaEmbarque.montoPasajeFormateado,
				montoTUUA: pasajeTasaEmbarque.montoTUUAFormateado,
				montoTotal: pasajeTasaEmbarque.montoTotalFormateado,
				flagPlanViajeInformeDistribTotal: pasajeTasaEmbarque.flagPlanViajeInformeDistribTotal
			};
			pasajeTasaEmbarqueTable.jqGrid("addRowData", datarow.secuencia, datarow);
		}
		pasajeTasaEmbarqueTable.trigger("reloadGrid");
	}
}

function showAsignacionConceptoSustentarGastoReembolso(planViajeConceptoArray) {
	
	var conceptoViaticoTable = $("#tblConceptoViatico");
	conceptoViaticoTable.clearGridData();
	if (planViajeConceptoArray != null && planViajeConceptoArray.length > 0) {
		for (var i = 0; i < planViajeConceptoArray.length; i++) {
			var asignacionConcepto = planViajeConceptoArray[i];
			var identificador = i + 1;
			var datarow = {
				planViajeID: asignacionConcepto.planViajeID,
				secuencial: identificador,
				conceptoID: asignacionConcepto.conceptoID,
				descripcionConcepto: asignacionConcepto.descripcionConcepto,
				monto: asignacionConcepto.montoFormateado,
				flagPlanViajeConceptoTotal: asignacionConcepto.flagPlanViajeConceptoTotal
			};
			conceptoViaticoTable.jqGrid("addRowData", datarow.secuencial, datarow);
		}
		conceptoViaticoTable.trigger("reloadGrid");
	}
}

function showMensajeConfirmacionAplicativoWithoutBody(idDivModalMessage, idDivTituloPanelMessage, idDivBodyPanelMessage, messageTitulo) {
	hideElement(idDivBodyPanelMessage);
	setHtmlElement(idDivTituloPanelMessage, messageTitulo);
	showModalElement(idDivModalMessage);
}

function showMensajeConfirmacionAplicativoWithBody(idDivModalMessage, idDivTituloPanelMessage, idDivBodyPanelMessage, idEtiquetaMessage, messageTitulo, messageBody) {
	showElement(idDivBodyPanelMessage);
	setHtmlElement(idDivTituloPanelMessage, messageTitulo);
	setHtmlElement(idEtiquetaMessage, messageBody);
	showModalElement(idDivModalMessage);
}

/*Inicio Codigo - Reutilizacion comprobantePago*/
var comprobantePagoBeforeMethod = function() {
	
};

var comprobantePagoAfterMethod = function(codPlanViaje) {
	callObtenerComprobantesGastoPasajeConcepto();
};

var comprobantePagoService = new ComprobantePagoService(comprobantePagoBeforeMethod, comprobantePagoAfterMethod);
/*Fin Codigo - Reutilizacion comprobantePago*/

$(window).on("resize", function() {
	resizeTable("tblComprobante");
	resizeTable("tblGastoViatico");
	resizeTable("tblPasajeTasaEmbarque");
	resizeTable("tblConceptoViatico");
	//Inicializando las tablas de los modales
	resizeTable("tblDatosRendicion");
	resizeTable("tblDatosComprobantePago");
});