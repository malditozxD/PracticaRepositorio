function initElementsNotificarRendicionBandeja() {
	removeDuplicateComponents();
	setInitElementsNotificarRendicionBandeja();
	setInitPlanillaTable();
}

function setInitElementsNotificarRendicionBandeja() {
	
	disabledElement("btnExportarExcelRendicion");
	disabledElement("btnEnviarNotificacion");
	setValueInputText("selCanalAtencionRendicion", "00");
	setValueInputText("etiquetaFechaMaximaRendicion", getInicioAnioEnEjercicio());
	
	addEventElement("btnBuscarUUOORendicion", "click", clickBtnBuscarUUOORendicion);
	addEventElement("selCanalAtencionRendicion", "change", changeSelCanalAtencionRendicion);
	addEventElement("btnConsultarRendicion", "click", clickBtnConsultarRendicion);
	addEventElement("btnExportarExcelRendicion", "click", clickBtnExportarExcelRendicion);
	addEventElement("btnEnviarNotificacion", "click", clickBtnEnviarNotificacion);
	addEventElement("btnSalir", "click", clickBtnSalir);
	addEventElement("etiquetaFechaMaximaRendicion", "change", changeEtiquetaFechaMaximaRendicion);
	initDateTimePickerWithMaxDate("etiquetaFechaMaximaRendicionDiv", "dp.change", "changeDate", changeDateEtiquetaFechaMaximaRendicionDiv, getCurrentDateFormatEng());
	
	addEventElement("btnAceptarMensajeConfirmacionErrorNotificarRendicionBandeja", "click", clickBtnAceptarMensajeConfirmacionErrorNotificarRendicionBandeja);
	addEventElement("btnSiNotificarRendicionNotificar", "click", clickBtnSiNotificarRendicionNotificar);
	addEventElement("btnNoNotificarRendicionNotificar", "click", clickBtnNoNotificarRendicionNotificar);
	addEventElement("btnAceptarNotificacionExitosaNotificar", "click", clickBtnAceptarNotificacionExitosaNotificar);
}

function setInitPlanillaTable() {
	
	var planillaTable = $("#tblPlanilla");
	var heightJqGrid = 200;
	setStyleElement("divPlanillaTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 2, true));
	if (planillaTable) {
		var planillaTableDiv = $("#divPlanillaTable");
		var widthTable = planillaTableDiv.width();
		planillaTable.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			datatype: "local",
			rowNum: 10,
			rowList: [10, 20],
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Código Plan Viaje",
				"Nro. Planilla",
				"Código Estado Solicitud",
				"Código Estado Rendicion",
				"Número de Registro",
				"Comisionado",
				"Plazo de Rendición",
				"Fecha de 1ra. Notificación",
				"Indicador Canal de Atención",
				"Canal",
				"Indicador de Menor Gasto",
				"Moneda",
				"Importe Otorgado",
				"Importe Rendido",
				"Importe Devolución Menor Gasto",
				"Observado",
				"Seleccionar"
			],
			colModel: [
				{name: "codPlanViaje", index: "codPlanViaje", width: (1*widthTable/20), hidden: true},
				{name: "codPlanilla", index: "codPlanilla", width: (2*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "";
						var codPlanViaje = rowData.codPlanViaje;
						var codPlanilla = rowData.codPlanilla;
						var encodeParam = "codPlanViaje=" + codPlanViaje;
						encodeParam += "&codigoPaginaCaller=" + getValueInputText("hidCodigoPaginaCaller");
					    htmlElement = sendDataMethodPost(codPlanilla + "_consultarRendicion", "rendicion", "mostrarConsultarRendicion", encodeParam, codPlanilla);
						return htmlElement;
					}
				},
				{name: "codEstadoSolic", index: "codEstadoSolic", width: (1*widthTable/20), hidden: true},
				{name: "codEstadoRend", index: "codEstadoRend", width: (1*widthTable/20), hidden: true},
				{name: "numeroRegistroAlterno", index: "numeroRegistroAlterno", width: (1*widthTable/20), hidden: true},
				{name: "nomColaborador", index: "nomColaborador", width: (3.5*widthTable/20)},
				{name: "fecMaxRend", index: "fecMaxRend", width: (2*widthTable/20), align: "center"},
				{name: "fechaNotificacion", index: "fechaNotificacion", width: (2*widthTable/20), align: "center"},
				{name: "indicadorCanalAtencion", index: "indicadorCanalAtencion", width: (1*widthTable/20), hidden: true},
				{name: "canalAtencion", index: "canalAtencion", width: (2*widthTable/20)},
				{name: "indicadorMenorGasto", index: "indicadorMenorGasto", width: (1*widthTable/20), hidden: true},
				{name: "moneda", index: "moneda", width: (1*widthTable/20), hidden: true},
				{name: "mtoTotal", index: "mtoTotal", width: (1.5*widthTable/20), align: "right"},
				{name: "montoDevuelto", index: "montoDevuelto", width: (1.5*widthTable/20), align: "right"},
				{name: "montoMenorGasto", index: "montoMenorGasto", width: (2.5*widthTable/20), align: "right"},
				{name: "observacionDCP", index: "observacionDCP", width: (1.5*widthTable/20), align: "center"},
				{name: "seleccionar", index: "seleccionar", width: (1.5*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "<input id=\"chkJqGridPlanilla" + rowData.codPlanViaje + "\" name=\"chkJqGridPlanilla\" class=\"chkJqGridPlanillaClass\" type=\"checkbox\" value=\"" + rowData.codPlanViaje + "\" onclick=\"javascript:clickCheckboxJqGridPlanilla();\" />";
						return htmlElement;
					}
				}
			],
			caption: "Planillas",
			pager: "#divPlanillaPagerTable",
			loadui: "disable"
		});
		planillaTable.clearGridData();
		addEventElementBySelector("#divPlanillaTable .ui-pg-button.ui-corner-all", "click", clickPagerPlanillaTable);
		addEventElementBySelector("#divPlanillaTable input.ui-pg-input", "keypress", keypressPagerPlanillaTable);
		addEventElementBySelector("#divPlanillaTable select.ui-pg-selbox", "change", changePagerPlanillaTable);
	}
}

function clickBtnBuscarUUOORendicion() {
	initElementsBuscarUUOO("divPlanillaTable");
	showModalElement("divBuscarUUOO");
    triggerResizeEvent();
}

function changeSelCanalAtencionRendicion() {
	clearPlanillaTableRendicionBandeja();
}

function clickBtnConsultarRendicion() {
	
	var flagValidacionFormulario = true;
	var errorMessage = "";
	hideElement("divErrorRendicion");
	disabledElement("btnConsultarRendicion");
	clearPlanillaTableRendicionBandeja();
	
	//solo si no se trata de un registrador universal realizar la validación de ingreso de la dependencia.
	
	var indRegistradorUniversal = trimText(getValueInputText("hidFlagRegistradorUniversal"));
	
	if (indRegistradorUniversal!='1' && flagValidacionFormulario && trimText(getValueInputText("hidCodigoDependencia")).length == 0) {
		flagValidacionFormulario = false;
		errorMessage = errorMessageNotificarRendicionBandeja.uuooInvalida;
	}
	
	if (flagValidacionFormulario && getValueInputText("etiquetaFechaMaximaRendicion") == "") {
		flagValidacionFormulario = false;
		errorMessage = errorMessageNotificarRendicionBandeja.completarFecha;
	}
	
	if (flagValidacionFormulario) {
		callBuscarPlanillasBandejaNotificacion();
	}
	else {
		showMessageErrorNotificarRendicionBandeja(errorMessage);
		enabledElement("btnConsultarRendicion");
	}
}

function clickBtnExportarExcelRendicion() {
	var encodeParam = "&codigoDependencia=" + getUpperCaseValueInputText("hidCodigoDependencia");
	encodeParam += "&indicadorCanalAtencion=" + trimText(getValueInputText("selCanalAtencionRendicion"));
	encodeParam += "&fechaHasta=" + getUpperCaseValueInputText("etiquetaFechaMaximaRendicion");
	location.href = contextPathUrl + "/revisarRendicion.htm?action=exportarExcelBandejaNotificacion" + encodeParam;
}

function clickBtnEnviarNotificacion() {
	showModalElement("divMensajeConfirmacionNotificarRendicionNotificar");
}

function clickBtnSalir() {
	window.history.back();
}

function changeEtiquetaFechaMaximaRendicion() {
	if (isBrowserInternetExplorer()) {
		if (trimText(getValueInputText("etiquetaFechaMaximaRendicion")) != "" && isValidoFormatDate(getValueInputText("etiquetaFechaMaximaRendicion"))) {
			if (isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaMaximaRendicion")), getCurrentDateFormatEng())) {
				setValueInputText("etiquetaFechaMaximaRendicion", "");
			}
		}
		else {
			setValueInputText("etiquetaFechaMaximaRendicion", "");
		}
		changeDateEtiquetaFechaMaximaRendicionDiv();
	}
}

function changeDateEtiquetaFechaMaximaRendicionDiv() {
	clearPlanillaTableRendicionBandeja();
}

function clickBtnAceptarMensajeConfirmacionErrorNotificarRendicionBandeja() {
	hideModalElement("divMensajeConfirmacionErrorNotificarRendicionBandeja");
}

function clickBtnSiNotificarRendicionNotificar() {
	
	var jqGridPlanillaChkArray = $("input.chkJqGridPlanillaClass:checked");
	if (jqGridPlanillaChkArray.length > 0) {
		var planViajeList = new Array();
		jqGridPlanillaChkArray.each(function() {
			var jqGridPlanillaChk = $(this);
			var codPlanViaje = obtenerCodigoPlanViajeJqGridPlanilla(jqGridPlanillaChk.attr("id"));
			var planViaje = new Object();
			planViaje.codPlanViaje = codPlanViaje;
			planViajeList.push(planViaje);
		});
		hideModalElement("divMensajeConfirmacionNotificarRendicionNotificar");
		callEnviarSegundaNotificacionRendicion(JSON.stringify(planViajeList));
	}
}

function clickBtnNoNotificarRendicionNotificar() {
	hideModalElement("divMensajeConfirmacionNotificarRendicionNotificar");
}

function clickBtnAceptarNotificacionExitosaNotificar() {
	$("#btnConsultarRendicion").trigger("click");
	hideModalElement("divMensajeConfirmacionNotificacionExitosaNotificar");
}

function clickPagerPlanillaTable() {
	disabledElement("btnEnviarNotificacion");
}

function keypressPagerPlanillaTable(event) {
	var keyCode = window.event ? event.keyCode : event.which;
	if (keyCode == 13) {
		disabledElement("btnEnviarNotificacion");
	}
}

function changePagerPlanillaTable() {
	disabledElement("btnEnviarNotificacion");
}

function clickCheckboxJqGridPlanilla() {
	var jqGridPlanillaChkSeleccionadaArray = $("input.chkJqGridPlanillaClass:checked");
	if (jqGridPlanillaChkSeleccionadaArray.length >= 1) {
		enabledElement("btnEnviarNotificacion");
	}
	else {
		disabledElement("btnEnviarNotificacion");
	}
}

function callBuscarPlanillasBandejaNotificacion() {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/revisarRendicion.htm?action=buscarPlanillasBandejaNotificacion",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codigoDependencia": getUpperCaseValueInputText("hidCodigoDependencia"),
				"indicadorCanalAtencion": trimText(getValueInputText("selCanalAtencionRendicion")),
				"fechaHasta": getValueInputText("etiquetaFechaMaximaRendicion")
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showElement("divLoadingNotificarRendicionBandeja");
			},
			complete: function() {
				enabledElement("btnConsultarRendicion");
				hideElement("divLoadingNotificarRendicionBandeja");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var codigoConsulta = result.codigoConsulta;
				var errorMessage = result.errorMessage;
				if (codigoConsulta != null && codigoConsulta == "00") {
					var planillaList = result.planViajeList;
					showPlanillasConsultarRendicionBandeja(planillaList);
				}
				else {
					showMensajeConfirmacionErrorNotificarRendicionBandeja(errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callBuscarPlanillasBandejaNotificacion");
			}
		});
	}, 500);
}

function callEnviarSegundaNotificacionRendicion(planViajeList) {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/revisarRendicion.htm?action=enviarSegundaNotificacionRendicion",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"planViajeList": planViajeList
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showModalElement("divMensajeConfirmacionLoadingNotificarRendicionBandeja");
			},
			complete: function() {
				hideModalElement("divMensajeConfirmacionLoadingNotificarRendicionBandeja");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var codigoOperacion = result.codigoOperacion;
				var errorMessage = result.errorMessage;
				if (codigoOperacion != null && codigoOperacion == "00") {
					showModalElement("divMensajeConfirmacionNotificacionExitosaNotificar");
				}
				else {
					showMensajeConfirmacionErrorNotificarRendicionBandeja(errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callEnviarSegundaNotificacionRendicion");
			}
		});
	}, 500);
}

function showMessageErrorNotificarRendicionBandeja(errorMessage) {
	setHtmlElement("etiquetaErrorRendicion", errorMessage);
	showElement("divErrorRendicion");
}

function showMensajeConfirmacionErrorNotificarRendicionBandeja(messageTitulo) {
	hideElement("divBodyPanelMensajeConfirmacionErrorNotificarRendicionBandeja");
	setHtmlElement("divTituloPanelMensajeConfirmacionErrorNotificarRendicionBandeja", messageTitulo);
	showModalElement("divMensajeConfirmacionErrorNotificarRendicionBandeja");
}

function showPlanillasConsultarRendicionBandeja(planillaArray) {
	
	if (planillaArray != null && planillaArray.length > 0) {
		var planillaTable = $("#tblPlanilla");
		planillaTable.clearGridData();
		for (var i = 0; i < planillaArray.length; i++) {
			var planilla = planillaArray[i];
			var datarow = {
				codPlanViaje: planilla.codPlanViaje,
				codPlanilla: planilla.codPlanilla,
				codEstadoSolic: planilla.codEstadoSolic,
				codEstadoRend: planilla.codEstadoRend,
				numeroRegistroAlterno: planilla.numeroRegistroAlterno,
				nomColaborador: planilla.nomColaborador,
				fecMaxRend: planilla.fecMaxRendFormateada,
				fechaNotificacion: planilla.fechaNotificacionFormateada,
				indicadorCanalAtencion: planilla.indicadorCanalAtencion,
				canalAtencion: planilla.canalAtencion,
				indicadorMenorGasto: planilla.indicadorMenorGasto,
				moneda: planilla.moneda,
				mtoTotal: planilla.mtoTotalFormateado,
				montoDevuelto: planilla.montoDevueltoFormateado,
				montoMenorGasto: planilla.montoMenorGastoFormateado,
				observacionDCP: planilla.observacionDCP,
				seleccionar: ""
			};
			planillaTable.jqGrid("addRowData", datarow.codPlanViaje, datarow);
		}
		planillaTable.trigger("reloadGrid");
		enabledElement("btnExportarExcelRendicion");
	}
	else {
		setHtmlElement("divPlanillaPagerTable_left", errorMessageNotificarRendicionBandeja.sinRegistrosBusqueda);
	}
}

function clearPlanillaTableRendicionBandeja() {
	var planillaTable = $("#tblPlanilla");
	planillaTable.clearGridData();
	disabledElement("btnExportarExcelRendicion");
	disabledElement("btnEnviarNotificacion");
	setHtmlElement("divPlanillaPagerTable_left", "");
}

/*Inicio Codigo - Reutilizacion buscarUUOO*/
var dataParametrosBuscarUUOO = new Object();
dataParametrosBuscarUUOO.idCodigoRegistrador = "hidCodigoRegistrador";
dataParametrosBuscarUUOO.idCodigoTipoUUOOViatico = getValueInputText("hidFlagBuscarUUOO");
dataParametrosBuscarUUOO.idDivScreenBlock = "divScreenBlock";

var buscarUUOOBeforeMethod = function() {
};

var buscarUUOOAfterMethod = function(rowData) {
	
	setValueInputText("txtUUOO", rowData["uuoo"]);
	setValueInputText("hidTxtUUOO", rowData["uuoo"]);
    setValueInputText("txtDescripcionDependencia", rowData["descripcionUUOO"]);
    setValueInputText("hidCodigoDependencia", rowData["codigoDependencia"]);
    hideElement("divErrorRendicion");
    clearPlanillaTableRendicionBandeja();
};

var buscarUUOOService = new BuscarUUOOService(dataParametrosBuscarUUOO, buscarUUOOBeforeMethod, buscarUUOOAfterMethod);
/*Fin Codigo - Reutilizacion buscarUUOO*/

/*Inicio Codigo - Reutilizacion buscarUUOOInput*/
function buscarUUOOInputBeforeMethod() {
	
	setValueInputText("hidTxtUUOO", "");
	setValueInputText("txtDescripcionDependencia", "");
	setValueInputText("hidCodigoDependencia", "");
	clearPlanillaTableRendicionBandeja();
}

function buscarUUOOInputAfterMethod(uuooList) {
	
	if (uuooList != null && uuooList.length > 0) {
		for (var i = 0; i < uuooList.length; i++) {
			var uuoo = uuooList[i];
			var datarow = {
				codigoDependencia: uuoo.cod_dep,
				uuoo: uuoo.uuoo,
				uuooDetalle: uuoo.nom_largo
			};
			setValueInputText("txtUUOO", datarow.uuoo);
			setValueInputText("hidTxtUUOO", datarow.uuoo);
			setValueInputText("hidCodigoDependencia", datarow.codigoDependencia);
			setValueInputText("txtDescripcionDependencia", datarow.uuooDetalle);
			break;
		}
	}
	else {         
		setHtmlElement("etiquetaErrorRendicion", errorMessageBuscarUUOOInput.sinRegistrosBusqueda);
		showElement("divErrorRendicion");
	}
}

var buscarUUOOInputService = new BuscarUUOOInputService();

function initElementsBuscarUUOOInputService(errorMessageBuscarUUOOInput) {
	
	var dataParametros = new Object();
	dataParametros.idNumeroUUOO = "txtUUOO";
	dataParametros.idCodigoRegistrador = "hidCodigoRegistrador";
	dataParametros.idCodigoTipoUUOOViatico = getValueInputText("hidFlagBuscarUUOO");
	dataParametros.idDivLoading = "divLoadingBuscarInput";
	dataParametros.idDivError = "divErrorRendicion";
	dataParametros.idEtiquetaError = "etiquetaErrorRendicion";
	dataParametros.idDivScreenBlock = "divScreenBlock";
	dataParametros.errorMessage = errorMessageBuscarUUOOInput;
	buscarUUOOInputService = new BuscarUUOOInputService(dataParametros, buscarUUOOInputBeforeMethod, buscarUUOOInputAfterMethod);
}
/*Fin Codigo - Reutilizacion buscarUUOOInput*/

function obtenerCodigoPlanViajeJqGridPlanilla(codigoPlanilla) {
	var codPlanViaje = "";
	var codPlanViajeArray = codigoPlanilla.split("chkJqGridPlanilla");
	if (codPlanViajeArray.length > 1) {
		codPlanViaje = codPlanViajeArray[1];
	}
	return codPlanViaje;
}

$(window).on("resize", function() {
	resizeTable("tblPlanilla");
	//Inicializando las tablas de los modales
	resizeTable("tblUUOO");
});