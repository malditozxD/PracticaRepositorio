/// <reference path="./registrarModificarSolicitud_init.js" />
/// <reference path="./registrarModificarSolicitud_rest.js" />
/// <reference path="./registrarModificarSolicitud_event.js" />
/// <reference path="./registrarModificarSolicitud_validate.js" />
/// <reference path="../general/common.js" />
/// <reference path="../../WEB-INF/jsp/solicitud/registrar/registrarModificarSolicitud.jsp" />
/// <reference path="D:\jcfr\data\ts-definitions\DefinitelyTyped-master\jquery\jquery.d.ts" />

function limpiarRegistro() {

	limpiarSeccionIIDetalleViatico();
	limpiarSeccionIIIPuntoPartida();
	limpiarSeccionIVDesplazamientos();
	limpiarSeccionVAsignaciones();

	// limpiar los divs que muestran errores
	limpiarLabelsError();

	// actualizando estado botones
	updateBotonConsultarAsistencia();
	updateBotonAgregarDesplazamiento();
	updateEstadosPanelBotones();
	
	triggerChangeFechas();
}

function triggerChangeFechas() {

	if ( esNacional() ) {

		if ( esMayor4h() ) {
		
			$( '#fechaSalidaNacMay4h' ).trigger( 'change' );
			$( '#fechaRetornoNacMay4h' ).trigger( 'change' );

		} else {	// si es menor igual a 4h
		
			$( '#fechaNacMen4h' ).trigger( 'change' );
			$( '#salidaNacMen4h' ).trigger( 'change' );
			$( '#retornoNacMen4h' ).trigger( 'change' );			
		}	

	} else { // si es internacional
	
		$( '#fechaEventoInicioInter' ).trigger( 'change' );
		$( '#fechaEventoFinInter' ).trigger( 'change' );
		
		$( '#fechaItinerarioInicioInter' ).trigger( 'change' );
		$( '#fechaItinerarioFinInter' ).trigger( 'change' );
	}

}


function triggerTraslapeFechas() {
	
	// En la casuística que tiene traslape y se maneja la autorización del registrador universal, 
	// es informativo que se muestre el texto de la validación de traslape a modo de guía.
	
	// validacion de traslape de fechas (petición síncrona)
	var codColaborador = getTrimValue( '#hidCodigoColaborador' );
	var fechaSalida = getTrimValue( '#fechaEventoInicioInter' );
	var fechaRetorno = getTrimValue( '#fechaEventoFinInter' );
	var codPlanViaje = getTrimValue( '#hidCodPlanViaje' );	// solo tiene valor cuando es modificación	
	
	if ( esNacional() ) {

		if ( esMayor4h() ) {

			fechaSalida = getTrimValue( '#fechaSalidaNacMay4h' );
			fechaRetorno = getTrimValue( '#fechaRetornoNacMay4h' );
			
		} else {	// si es menor igual a 4h
		
			fechaSalida = getTrimValue( '#fechaNacMen4h' );
			fechaRetorno = getTrimValue( '#fechaNacMen4h' );
		}	

	} else { // si es internacional
	
		fechaSalida = getTrimValue( '#fechaEventoInicioInter' );
		fechaRetorno = getTrimValue( '#fechaItinerarioFinInter' );
	}

	// petición síncrona
	var msgValidacionTraslape = '';
	
	callAjaxValidarTraslapeFechas(false, codColaborador, fechaSalida, fechaRetorno, codPlanViaje).then( function(response) {

		if ( response.traslapeFechas == 'si' ) {

			var msg = configRSV.mensajes.existePlanillaNombreComisionadoEnRango;
			msg = msg.replace( /NRO_SOLICITUD/g, response.traslapeFechasNroSolicitud );
			msg = msg.replace( /FECHA_INICIO/g, response.traslapeFechasInicio );
			msg = msg.replace( /FECHA_FINAL/g, response.traslapeFechasFinal );
			msg = msg + ' ' + configRSV.mensajes.deSerFechasCorrectasDistintaComisionAdjuntarSust;

			msgValidacionTraslape = msg;

			return; 
		}

	} );
	
	if ( $.trim( msgValidacionTraslape ) != '' ) {
		showMensajeLabelDetalleViatico( msgValidacionTraslape );
	}	

}

function limpiarSecciones2345() {
	limpiarSeccionIIDetalleViatico();
	limpiarSeccionIIIPuntoPartida();
	limpiarSeccionIVDesplazamientos();
	limpiarSeccionVAsignaciones();
}

function limpiarSecciones345() {
	limpiarSeccionIIIPuntoPartida();
	limpiarSeccionIVDesplazamientos();
	limpiarSeccionVAsignaciones();
}

function limpiarSecciones5() {
	limpiarSeccionVAsignaciones();
}


function limpiarSeccionIIDetalleViatico() {

	// limpiando campos nacional mayor a 4h
	setValueInputText( 'fechaSalidaNacMay4h', '' );
	setValueInputText( 'fechaRetornoNacMay4h', '' );
	setValueInputText( 'diasNacMay4h', '' );

	// limpiando campos nacional menor igual a 4h
	setValueInputText( 'fechaNacMen4h', '' );
	setValueInputText( 'salidaNacMen4h', '' );
	setValueInputText( 'retornoNacMen4h', '' );
	setValueInputText( 'horasNacMen4h', '' );

	// limpiando campos nacional (ambos)
	$('#rbViaticosProgramadosSI').trigger( 'click' )
	setValueInputText( 'fechaMaximaRendicionNac', '' );

	setValueInputText( 'txtMotivoComision', '' );
	setValueInputText( 'txtObservacion', '' );
	setValueInputText( 'txtCanalAtencion', '' );

	// limpiando campos internacional
	setValueInputText( 'fechaItinerarioInicioInter', '' );
	setValueInputText( 'fechaItinerarioFinInter', '' );
	setValueInputText( 'fechaEventoInicioInter', '' );
	setValueInputText( 'fechaEventoFinInter', '' );

	setValueInputText( 'fechaMaximaRendicionInter', '' );
	setValueInputText( 'fechaResolucionInter', '' );
	setValueInputText( 'nroResolucionInter', '' );
	setValueInputText( 'montoResolucionInter', '' );

	setValueInputText( 'txtMotivoComision', '' );
	setValueInputText( 'txtObservacion', '' );
	setValueInputText( 'txtCanalAtencion', '' );

	// reseteando el estado de consultar asistencia
	obligarVisualizarConsultaAsistencia();
}

function limpiarSeccionIIIPuntoPartida() {

	// ANTES:
	// setValueInputText( 'selDepartamento', '00' );
	// setValueInputText( 'selProvincia', '00' );
	// setValueInputText( 'hidCodigoPuntoPartida' , '' );
	
	// disabledElement("selProvincia");

	// AHORA:
	updateCombosPuntoPartida();
}

function limpiarSeccionIVDesplazamientos() {
	clearGridDesplazamientos();
	updateTotalDesplazamientos();
}

function limpiarSeccionVAsignaciones() {
	clearGridAsignaciones();
	updateTotalAsignaciones();
}

function limpiarLabelsError() {
	$( '#lblErrorMay4h' ).html( '' );
	$( '#divErrorMay4h' ).hide();
	$( '#lblErrorMen4h' ).html( '' );
	$( '#divErrorMen4h' ).hide();
	$( '#lblErrorInt' ).html( '' );
	$( '#divErrorInt' ).hide();
	$( '#lblErrorAsignaciones' ).html( '' );
	$( '#divErrorAsignaciones' ).hide();
}

// actualiza la caja de texto con el total de desplazamiento
function updateTotalDesplazamientos() {

	var lista = getDesplazamientosList();

	if ( !estaDefinido( lista ) || lista.length == 0 ) {
		
		$('#txtTotalDesplazamientos').val('');
		
	} else {
		
		var total = calcularTotalDesplazamientos();
		$('#txtTotalDesplazamientos').val( roundComasMilesString( total, 2 ) );
	}
}

// actualiza la caja de texto con el total de asignaciones
function updateTotalAsignaciones() {

	var asignaciones = getAsignacionesList();

	if ( !estaDefinido( asignaciones ) || asignaciones.length == 0 ) {
		
		$('#txtTotalAsignaciones').val('');
		
	} else {
		
		var acumulador = 0;
		$.each(asignaciones, function(i, item) {
			acumulador = toNumero( item.importeAsignado ) + acumulador;
		});

		$('#txtTotalAsignaciones').val( roundComasMilesString( acumulador, 2 ) );
	}

}

function calcularTotalDesplazamientos() {

	var acumulador = 0;
	var desplazamientos = getDesplazamientosList();

	$.each(desplazamientos, function(i, item) {

		if ( esNacional() ) {
			acumulador = toNumero( item.importeViatico ) + acumulador;
		} else { // si es internacional
			acumulador = toNumero( item.totalOtorgado ) + acumulador;
		}

	});

	return roundNumero( acumulador, 2 );
}

// habilita o deshabilita el botón consultar asistencia
function updateBotonConsultarAsistencia() {

	// activa/desactiva el boton agregar consultar asistencias de la seccion II
	var activar = false;

	if ( esNacional() ) {

		if ( esMayor4h() ) {

			activar = esFechaValida( getTrimValue( '#fechaSalidaNacMay4h' ) ) && esFechaValida( getTrimValue( '#fechaRetornoNacMay4h' ) );

		} else {	// si es menor o igual a 4 horas

			activar = esFechaValida( getTrimValue( '#fechaNacMen4h' ) );
		}

	} else { // si es internacional

		/*
		if ( esFechaValida( getTrimValue('#fechaItinerarioInicioInter') ) && esFechaValida( getTrimValue('#fechaItinerarioFinInter') ) ) {
			activar = true;
		}
		*/

		if ( esFechaValida( getTrimValue( '#fechaEventoInicioInter' ) ) && esFechaValida( getTrimValue( '#fechaEventoFinInter' ) ) ) {
			activar = true;
		}

	}

	$('#btnConsultarAsistenciaNacMay4h').prop( 'disabled', !activar );
	$('#btnConsultarAsistenciaNacMen4h').prop( 'disabled', !activar );
	$('#btnConsultarAsistenciaInt').prop( 'disabled', !activar );
}

// habilita o deshabilita el botón afectación presupuestal
function updateBotonAfectacionPresupuestal() {
	
	// Solo para modificar: activa/desactiva el boton afectación presupuestal (sección I - datos generales)
	if ( !esModificar() ) return; 

	var txtCodigoCanalAtencion = getTrimValue( '#txtCodigoCanalAtencion' );
	
	// solo visible si es abono en cuenta (reembolso)
	var visible = txtCodigoCanalAtencion == configRSV.constantes.CANAL_ATENCION_REEMBOLSO;
 
	if ( visible ) {
		$('#btnAfectacionPresupuestal').show();
	} else {
		$('#btnAfectacionPresupuestal').hide();
	}
}

// habilita o deshabilita el botón agregar desplazamiento
function updateBotonAgregarDesplazamiento() {

	// activa/desactiva el boton agregar desplazamiento de la seccion IV

	var selDepartamento = getTrimValue( '#selDepartamento' );
	var selProvincia = getTrimValue( '#selProvincia' );
	var hidCodigoPuntoPartida = getTrimValue( '#hidCodigoPuntoPartida' );

	// validar que ingresen fechas/horas y que estén ok
	var fechasHorasOK = false;

	if ( esNacional() ) {

		if ( esMayor4h() ) {
			fechasHorasOK = esFechaValida( getTrimValue( '#fechaSalidaNacMay4h' ) ) && esFechaValida( getTrimValue( '#fechaRetornoNacMay4h' ) );
		} else {
			fechasHorasOK = esFechaValida( getTrimValue( '#fechaNacMen4h' ) ) && isValidoFormatHour( getTrimValue( '#salidaNacMen4h' ) ) && isValidoFormatHour( getTrimValue( '#retornoNacMen4h' ) );
		}

	} else {
	
		fechasHorasOK = esFechaValida( getTrimValue( '#fechaEventoInicioInter' ) ) && esFechaValida( getTrimValue( '#fechaEventoFinInter' ) );
	}

	// validar que ingrese departamento y provincia
	var departamentoProvinciaOK = hidCodigoPuntoPartida != '' && selDepartamento != '00' && selProvincia != '00';
	
	// validar que ingrese motivo de comisión
	var motivoComisionOK = getTrimValue( '#txtMotivoComision' ) != '';
	
	// que departamento y provincia tengan un dato, y que ademas las fechas este ok
	var activar = departamentoProvinciaOK && fechasHorasOK && motivoComisionOK;

	$('#btnAgregarDesplazamiento').prop( 'disabled', !activar );
}

// actualiza el campo número de días cuando es tipo de viático nacional y duración de comisión es menor o igual a 4h
function updateNroDiasNacionalMen4h() {

	if ( esNacional() ) {

		if ( esMenorIgual4h() ) {

			var salidaNacMen4h = getTrimValue('#salidaNacMen4h');
			var retornoNacMen4h = getTrimValue('#retornoNacMen4h');

			if ( isValidoFormatHour( salidaNacMen4h ) && isValidoFormatHour( retornoNacMen4h ) ) {

				var diferencia = compararHoras( retornoNacMen4h, salidaNacMen4h );

				// si son igual o mayor
				if ( diferencia == 0 || diferencia == 1 ) {

					// convertir a horas y redondear a 1 digito
					var difHoras = roundDiferenciaHorasModulo60( retornoNacMen4h, salidaNacMen4h );

					$( '#horasNacMen4h' ).val( difHoras );

					var desplazamientos = getDesplazamientosList();
					if (desplazamientos.length == 1) {
						var desplazamiento = desplazamientos[0];
						actualizarUnidadFila(desplazamiento, difHoras);
						recalcularImportesFila(desplazamiento);
						//clickBtnCalcularAsignacion();
					}

				} else {
					$('#horasNacMen4h').val( '' );
				}

			} else {
				$('#horasNacMen4h').val( '' );
			}

			updateCanalAtencion();
			updateFechaMaximaRendicion();
			updateBotonAfectacionPresupuestal();
		}
	}

}

// actualiza el campo número de días cuando es tipo de viático nacional y duración de comisión es mayor a 4h
function updateNroDiasNacionalMay4h() {

	if ( esNacional() ) {

		if ( esMayor4h() ) {

			var fechaSalidaNacMay4h = getTrimValue('#fechaSalidaNacMay4h');
			var fechaRetornoNacMay4h = getTrimValue('#fechaRetornoNacMay4h');

			if ( esFechaValida( fechaSalidaNacMay4h ) && esFechaValida( fechaRetornoNacMay4h ) ) {

				var diferencia = compararFechas( fechaRetornoNacMay4h, fechaSalidaNacMay4h  );

				// si son igual o mayor
				if ( diferencia == 0 || diferencia == 1 ) {

					callAjaxCalcularNroDiasHabiles( fechaSalidaNacMay4h, fechaRetornoNacMay4h, function( result ) {

						$( '#diasNacMay4h' ).val( $.trim( result.nroDias ) );
						$( '#diasNacMay4hHabiles' ).val( $.trim( result.nroDiasHabiles ) );

						var desplazamientos = getDesplazamientosList();
						if (desplazamientos.length == 1) {
							var desplazamiento = desplazamientos[0];
							actualizarUnidadFila(desplazamiento, result.nroDias);
							recalcularImportesFila(desplazamiento);
							//clickBtnCalcularAsignacion();
						}

						updateCanalAtencion();
						updateFechaMaximaRendicion();
						updateBotonAfectacionPresupuestal();

						if ( toNumero( result.nroDiasHabiles ) > toNumero( configRSV.constantes.MAXIMO_NRO_DIAS_HABILES ) ) {

							var msg = configRSV.mensajes.cuentaAutorizacionRegViaPeriodoSuperior;
							var msgConfirm = msg.replace( /NRO_DIAS/g, configRSV.constantes.MAXIMO_NRO_DIAS_HABILES );

							showMensajeConfirm( msgConfirm, function(){
								//si da clic en aceptar no hacemos nada...
							}, function(){
								//si da clic en cancelar deshabilitamos todos los botones menos el de regresar.
								$('#formViatico').find( 'input, button, select, span' ).prop( 'disabled', true );
								$('#formViatico').find( 'input, button, select, span' ).off();
								$('#btnSalirRetornarViatico').prop( 'disabled', false );
								$('#btnSalirRetornarViatico').on("click", clickBtnSalirRetornarViatico);
							});

						} 

					});

				} else {

					$( '#diasNacMay4h' ).val( '' );
					$( '#diasNacMay4hHabiles' ).val( '' );

					updateCanalAtencion();
					updateFechaMaximaRendicion();
					updateBotonAfectacionPresupuestal();
				}

			} else {

				$( '#diasNacMay4h' ).val( '' );
				$( '#diasNacMay4hHabiles' ).val( '' );

				updateCanalAtencion();
				updateFechaMaximaRendicion();
				updateBotonAfectacionPresupuestal();
			}

		}
	}

}

// actualiza el campo número de días cuando es tipo de viático internacional
function updateNroDiasInternacional() {

	if ( esInternacional() ) {

		var fechaEventoInicioInter = getTrimValue('#fechaEventoInicioInter');
		var fechaEventoFinInter = getTrimValue('#fechaEventoFinInter');

		if ( esFechaValida( fechaEventoInicioInter ) && esFechaValida( fechaEventoFinInter ) ) {

			var diferencia = compararFechas( fechaEventoFinInter, fechaEventoInicioInter  );

			// si son igual o mayor
			if ( diferencia == 0 || diferencia == 1 ) {

				callAjaxCalcularNroDiasHabiles( fechaEventoInicioInter, fechaEventoFinInter, function( result ) {

					$( '#diasInter' ).val( $.trim( result.nroDias ) );
					$( '#diasInterHabiles' ).val( $.trim( result.nroDiasHabiles ) );

					var desplazamientos = getDesplazamientosList();
					if (desplazamientos.length == 1) {
						var desplazamiento = desplazamientos[0];
						actualizarUnidadFila(desplazamiento, result.nroDias);
						recalcularImportesFila(desplazamiento);
						//clickBtnCalcularAsignacion();
					}

					updateCanalAtencion();
					updateFechaMaximaRendicion();
					updateBotonAfectacionPresupuestal();

				} );

			} else {

				$( '#diasInter' ).val( '' );
				$( '#diasInterHabiles' ).val( '' );

				updateCanalAtencion();
				updateFechaMaximaRendicion();
				updateBotonAfectacionPresupuestal();
			}

		} else {

			$( '#diasInter' ).val( '' );
			$( '#diasInterHabiles' ).val( '' );

			updateCanalAtencion();
			updateFechaMaximaRendicion();
			updateBotonAfectacionPresupuestal();
		}

	}

}

function hayAsignacionesFijasCalculadas() {
	var asignaciones = getAsignacionesList();
	var posFija = indexOfAsignacionesFijas( asignaciones );
	return posFija >= 0;
}

function limpiarAsignacionesCalculadas() {

	var hayCambios = false;
	var asignaciones = getAsignacionesList();

	// borrando las asignaciones fijas anteriores
	var posFija = indexOfAsignacionesFijas( asignaciones );
	while ( posFija >= 0 ) {

		// quitar la asignacion
		asignaciones.splice(posFija, 1);

		// buscar siguiente
		posFija = indexOfAsignacionesFijas( asignaciones );

		hayCambios = true;
	}

	if ( hayCambios ) {

		// actualizar grilla de asignaciones
		fillGrilla( '#tblAsignacionRSV', getAsignacionesList() );
		updateTotalAsignaciones();

	}

	// actualizar estado botonera
	updateEstadosPanelBotones();
}

function buscarConceptoSinClasificador() {

	var result = null;
	var asignaciones = getAsignacionesList();

	$.each( asignaciones, function(i, item) {

		if ( $.trim( item.clasificadorGasto ) == '' ) {

			result = item;
			return false; // break
		}

	});

	return result;
}

function buscarConceptoConImporteCero() {

	var result = null;
	var asignaciones = getAsignacionesList();

	$.each( asignaciones, function(i, item) {

		if ( toNumero( item.importeAsignado ) == 0.0 ) {

			result = item;
			return false; // break
		}

	});

	return result;
}

function generarCodigosConceptoAsignacionesJSON() {

	var listaCodigosJSON = '';

	// recoger lista de asignaciones
	var asignaciones = getAsignacionesList();

	if ( asignaciones.length >= 0 ) {

		var listaCodigos = [];

		$.each(asignaciones, function(i, item) {
			listaCodigos.push( item.codigoAsignacion + '' );
		});

		listaCodigosJSON = JSON.stringify( listaCodigos );
	}

	return listaCodigosJSON;
}

function agregarAsignacionesCalculadas() {

	var asignacionesFijas = [];
	var asignaciones = getAsignacionesList();
	var totalDesplazamientos = calcularTotalDesplazamientos();

	if ( esNacional() ) {
		asignacionesFijas = configRSV.asignacionesFijasNacional;
	} else { // si es internacional
		asignacionesFijas = configRSV.asignacionesFijasInternacional;
	}

	// agregar las asignaciones fijas
	$.each(asignacionesFijas, function(i, item) {

		// "conceptoCantidadPVI": $.trim( item.conceptoCantidadPVI ),
		var asignacion = {
			"importeAsignado": totalDesplazamientos,
			"codigoAsignacion": $.trim( item.codigoConcepto ),
			"asignacion": $.trim( item.descripcionConcepto ),
			"clasificadorGasto": $.trim( item.clasificadorGasto ),
			"conceptoCantidadPVI": '',
			"tipoFijoPVI": $.trim( item.tipoFijoPVI ),
			"editable": 'no'
		};

		// agregar a la lista de asignaciones (siempre al inicio de la lista)
		asignaciones.unshift( asignacion );

	});

	// actualizar grilla de asignaciones
	fillGrilla( '#tblAsignacionRSV', getAsignacionesList() );
	updateTotalAsignaciones();

	// activa/desactiva la seccion de la botonera
	updateEstadosPanelBotones();

}

function deleteDesplazamientosPregunta() {

	// salir si no hay checks seleccionados
	if ( $( "input[name='chkDesplazamientos']:checked" ).length <= 0 ) return;

	showMensajeConfirm( configRSV.mensajes.deseaEliminarDestino, function() {

		// borra desplazamientos
		deleteDesplazamientos();

		// limpia asignaciones calculadas
		limpiarAsignacionesCalculadas();

	});

}

function deleteDesplazamientos() {

	var hayCambios = false;
	var desplazamientos = getDesplazamientosList();

	// busca todos los checks de desplazamientos seleccionados
	$( "input[name='chkDesplazamientos']:checked" ).each(function(i, obj) {

		var desplazamiento = $.parseJSON( obj.value );
		var pos = indexOfDesplazamientos( desplazamientos, desplazamiento );

		if ( pos >= 0 ) {

			// quita el desplazamiento de la lista
			desplazamientos.splice(pos, 1);

			hayCambios = true;
		}
	});

	if ( hayCambios ) {

		// actualizar lista de desplazamientos
		fillGrilla( '#tblDesplazamientoRSV', getDesplazamientosList() );
		updateTotalDesplazamientos();
	}

}

function deleteAsignaciones() {

	// salir si no hay checks seleccionados
	if ( $( "input[name='chkAsignaciones']:checked" ).length <= 0 ) return;

	showMensajeConfirm( configRSV.mensajes.deseaEliminarAsignacion, function() {

		var hayCambios = false;
		var asignaciones = getAsignacionesList();

		// busca todos los checks de asignaciones seleccionadas
		$( "input[name='chkAsignaciones']:checked" ).each(function(i, obj) {

			var asignacion = $.parseJSON( obj.value );

			var pos = indexOfAsignaciones( asignaciones, asignacion );

			if ( pos >= 0 ) {

				// si elimina un item con importeAsignado cero, tiene un mensaje de validacion que hay que eliminar si se borra el item
				if ( asignacion != null && toNumero( asignacion.importeAsignado, 0.0 ) == 0.0 ) {
					hideMensajeLabelAsignaciones();
				}

				// quitar de la lista de asignaciones
				asignaciones.splice(pos, 1);

				hayCambios = true;
			}

		});

		if ( hayCambios ) {
			// actualizar lista de asignaciones
			fillGrilla( '#tblAsignacionRSV', getAsignacionesList() );
			updateTotalAsignaciones();
		}

		updateEstadosPanelBotones();


	});

}

function obtenerBotonAsistenciaIDSegunCaso() {
	// por tema de visualizacion/maquetado se crearon tres botones de consultar asistencia,
	// este metodo retorna el boton segun el tipo de viatico y duracion de la comision
	if ( esNacional() ) {
		if ( esMayor4h() ) {
			return '#btnConsultarAsistenciaNacMay4h';
		} else {	// si es menor o igual a 4 horas
			return '#btnConsultarAsistenciaNacMen4h';
		}
	} else { // si es internacional
		return '#btnConsultarAsistenciaInt';
	}
}

function obligarVisualizarConsultaAsistencia() {
	// cambió alguna fecha y debe visualizar nuevamente sus asistencias
	configRSV.consultaAsistencia.visualizo = configRSV.constantes.NO;
	configRSV.consultaAsistencia.fecha = '';
	configRSV.consultaAsistencia.hora = '';
}

// buscar una asignación en la lista de asignaciones usando el campo nro como identificador
function indexOfAsignaciones( lista, asignacion ) {

	var pos = -1;

	// que lista y asignacion esten definidos
	if ( !estaDefinido( lista ) || !estaDefinido( asignacion ) || lista.length == 0 ) return pos;

	$.each(lista, function(i, item) {

		// criterios de busqueda/comparacion
		if ( item.nro == asignacion.nro ) {

			pos = i;
			return false; // break
		}

	});

	return pos;
}

// buscar una desplazamiento en la lista de desplazamientos usando el campo nro como identificador
function indexOfDesplazamientos( lista, desplazamiento ) {

	var pos = -1;

	// que lista y desplazamiento esten definidos
	if ( !estaDefinido( lista ) || !estaDefinido( desplazamiento ) || lista.length == 0 ) return pos;

	$.each(lista, function(i, item) {

		// criterios de comparacion
		if ( item.nro == desplazamiento.nro ) {

			pos = i;
			return false; // break
		}

	});

	return pos;
}

// buscar una asignación fija en la lista de asignaciones
function indexOfAsignacionesFijas( lista ) {

	var pos = -1;

	if ( !estaDefinido( lista ) || lista.length == 0 ) return pos;

	$.each(lista, function(i, item) {

		// buscar las asignaciones fijas (las que no se pueden editar)
		if ( item.editable == 'no' ) {

			pos = i;
			return false; // break
		}

	});

	return pos;
}

function updateCanalAtencion() {

	// limpiar canal de atencion para recalcular
	$('#txtCodigoCanalAtencion').val( '' );
	$('#txtCanalAtencion') .val( '' );

	var canalCodigo = '';
	var canalDescripcion = '';

	if ( esNacional() ) {

		if ( esMayor4h() ) {

			var poaProgramado = $( '#rbViaticosProgramadosSI' ).prop( 'checked' );
			var diasNacMay4h = getTrimValue( '#diasNacMay4h' );

			if ( poaProgramado ) {

				if ( diasNacMay4h != '' ) {

					if ( toNumero( diasNacMay4h ) <= toNumero( configRSV.constantes.CANAL_ATENCION_NUMERO_DIAS_TOPE ) ) {

						// caja chica
						canalCodigo = configRSV.constantes.CANAL_ATENCION_CAJA_CHICA;
						canalDescripcion = configRSV.constantes.CANAL_ATENCION_CAJA_CHICA_DESCRIP;

					} else {

						// reembolso
						canalCodigo = configRSV.constantes.CANAL_ATENCION_REEMBOLSO;
						canalDescripcion = configRSV.constantes.CANAL_ATENCION_REEMBOLSO_DESCRIP;
					}
					
				}

			} else {

				// no programados siempre por caja chica
				canalCodigo = configRSV.constantes.CANAL_ATENCION_CAJA_CHICA;
				canalDescripcion = configRSV.constantes.CANAL_ATENCION_CAJA_CHICA_DESCRIP;
			}

		} else {	// si es menor o igual a 4 horas

			// menor o igual a 4 horas siempre por caja chica
			canalCodigo = configRSV.constantes.CANAL_ATENCION_CAJA_CHICA;
			canalDescripcion = configRSV.constantes.CANAL_ATENCION_CAJA_CHICA_DESCRIP;
		}

	} else { // si es internacional

		// internacionales siempre por reembolso
		canalCodigo = configRSV.constantes.CANAL_ATENCION_REEMBOLSO;
		canalDescripcion = configRSV.constantes.CANAL_ATENCION_REEMBOLSO_DESCRIP;
	}

	$('#txtCodigoCanalAtencion').val( canalCodigo );
	$('#txtCanalAtencion') .val( canalDescripcion );
}

function updateFechaMaximaRendicion() {

	// limpiar fecha maxima para recalcular
	$( '#fechaMaximaRendicionNac' ).val( '' );
	$( '#fechaMaximaRendicionInter' ).val( '' );

	var fechaFinal = '';
	var fechaMaximaControlID = '';

	if ( esNacional() ) {

		fechaFinal = esMayor4h()? getTrimValue( '#fechaRetornoNacMay4h' ) : getTrimValue( '#fechaNacMen4h' );
		fechaMaximaControlID = '#fechaMaximaRendicionNac';

	} else { // si es internacional

		fechaFinal = getTrimValue( '#fechaEventoFinInter' );	// NOTA: debe tomar fecha de itinerario (no fecha de evento que es menor)
		fechaMaximaControlID = '#fechaMaximaRendicionInter';
	}

	if ( fechaFinal != '' ) {
		callAjaxCalcularFechaMaximaRendicion( fechaFinal, function(result) {
			if ( estaDefinido( result.fechaMaximaRendicion ) ) {
				$( fechaMaximaControlID ).val( result.fechaMaximaRendicion );
			}
		});
	}
}

function updateEstadoTraslapePendienteAutorizar() {
	
	// la solicitud de viático tiene traslape y el registrador universal aún no autoriza el traslape
	
	// deshabilitamos todo y borramos sus eventos por seguridad
	$( '#formViatico' ).find( 'input, button, select' ).prop( 'disabled', true );
	$( '#formViatico' ).find( 'input, select' ).off();

	// por bug en IE que permite seleccionar el calendario
 	deshabilitarFechasHorasBugIE();

	// se habilitan
	$( '#btnSalirRetornarViatico' ).prop( 'disabled', false );
	$( '#btnAdjuntarViatico' ).prop( 'disabled', false );
	
	// si tiene traslape pendiente de autorizar, pero tiene documento de sustento igual debería mostrarle el enviar
	/* se quito para que se alinee al documento
	if ( tieneAdjuntoSustentoTraslape() ) {
		enabledElement( 'btnEnviarViatico' );
	} else {
		disabledElement( 'btnEnviarViatico' );
	}
	*/
}

function updateEstadoTraslapeAutorizado() {

	// la solicitud de viático tiene traslape y el registrador universal ya autorizó el traslape, 
	// por lo que no puede cambiar ni fechas, ni desplazamientos, nada. Sólo puede enviar e imprimir para que siga el flujo.
	
	// deshabilitamos todo y borramos sus eventos por seguridad
	$( '#formViatico' ).find( 'input, button, select' ).prop( 'disabled', true );
	$( '#formViatico' ).find( 'input, select' ).off();

	// por bug en IE que permite seleccionar el calendario
	deshabilitarFechasHorasBugIE();

	// los botones que estan en el panel de botones se activan según reglas del negocio
	updateEstadosPanelBotones();
	
	// se deshabilitan
	$( '#btnGrabarViatico' ).prop( 'disabled', true ); 			// siempre se deshabilita
	$( '#btnAdjuntarViatico' ).prop( 'disabled', false ); 		// siempre se deshabilita (NOTA: puede darse el caso que le aceptan el traslape de fecha, pero aún debe adjuntar el sustento por más de 15días)
	
	// se habilitan
	if ( esConfiguracionManual() ) {
		$( '#btnImprimirViatico' ).prop( 'disabled', false );	
	}
	$( '#btnEnviarViatico' ).prop( 'disabled', false );			// se deja según reglas del negocio
	$( '#btnSalirRetornarViatico' ).prop( 'disabled', false );	// siempre se habilita
	
}

function updateEstadoTraslapeNoAutorizado() {

	// la solicitud de viático tiene traslape y el registrador universal ya rechazó el traslape, 
	// por lo que no puede cambiar ni fechas, ni desplazamientos, nada. Sólo puede enviar e imprimir para que siga el flujo.
	
	// deshabilitamos todo y borramos sus eventos por seguridad
	$( '#formViatico' ).find( 'input, button, select' ).prop( 'disabled', true );
	$( '#formViatico' ).find( 'input, select' ).off();

	// por bug en IE que permite seleccionar el calendario
	deshabilitarFechasHorasBugIE();

	// los botones que estan en el panel de botones se activan según reglas del negocio
	updateEstadosPanelBotones();
	
	// se deshabilitan
	$( '#btnGrabarViatico' ).prop( 'disabled', true ); 			// siempre se deshabilita
	$( '#btnAdjuntarViatico' ).prop( 'disabled', true ); 		// siempre se deshabilita (NOTA: puede darse el caso que le aceptan el traslape de fecha, pero aún debe adjuntar el sustento por más de 15días)
	
	$( '#btnEnviarViatico' ).prop( 'disabled', true );			// se deshabilita
	$( '#btnImprimirViatico' ).prop( 'disabled', true );
	
	$( '#btnSalirRetornarViatico' ).prop( 'disabled', false );	// siempre se habilita
}

function updateEstadosPanelBotones() {

	// habilita/deshabilita los botones grabar, adjuntar, imprimir, enviar
	
	var hayConceptos = getAsignacionesList().length > 0;
	var hayDesplazamientos = getDesplazamientosList().length > 0;
	
	var habilitarGrabar = false;
	var habilitarAdjuntar = false;
	var habilitarImprimir = false;
	var habilitarEnviar = false;
	
	if ( esRegistrar() ) {
	
		// si ingresó algo en desplazamientos y en asignaciones/conceptos
		habilitarGrabar = hayDesplazamientos && hayConceptos;
		
		// en el registro, enviar e imprimir siempre están deshabilitados ya que requieren del número de planilla
		habilitarEnviar = false;
		habilitarImprimir = false;
		
		// en el registro, siempre está deshabilitado ya que el adjuntar requiere del número de planilla
		habilitarAdjuntar = false;		
		
	} else { // si es modificar
		
		// si ingresó algo en desplazamientos y en asignaciones/conceptos
		habilitarGrabar = hayDesplazamientos && hayConceptos;		
		
		// Cuando se modifica debe estar habilitado si solo si es el comisionado quien va a firmar su solicitud
		if(!esRegistrador){
			habilitarEnviar = true;	
		}
		
		
		// solo si es manual (y siempre va tener numero de planilla cuando se modifica)
		habilitarImprimir = esConfiguracionManual();		
		
		// siempre está habilitado
		habilitarAdjuntar = true;
	}
	
	// habilitar el botón grabar
	$('#btnGrabarViatico').prop( 'disabled', !habilitarGrabar );

	// habilitar el botón adjuntar
	$('#btnAdjuntarViatico').prop( 'disabled', !habilitarAdjuntar );

	// habilitar el botón enviar
	$('#btnEnviarViatico').prop( 'disabled', !habilitarEnviar );

	habilitarBtnImprimirViatico();

}

function habilitarBtnImprimirViatico(){
	// habilitar el botón imprimir
	// El boton imprimir solo se habilitara si existe el documento firmado
	// y cuando el estado de la planilla sea diferente a observado:06
	var codPlanilla = $("#txtCodPlanilla").val();
	var codEstado = $("#hidCodigoEstadoViatico").val();
	$('#btnImprimirViatico').prop( 'disabled', true );
	if(codPlanilla!=""){
		existeDocumentoFirmado("043",codPlanilla,function(resultado){
			var existe = resultado.existe;
			//si el documento existe firmado electronicamente 
			//pero ademas no esta observado[06],observado por caja chica[07] ni observado por financiera[08]
			//--09:Anulación automática, 03:Anulado
			//$.inArray(codEstado, estadosObservacion) devuelve -1 si no encuentra el primer argumento(string) en el segundo(array)
			var estadosObservacion = ["06","07","08","09","03"]; //array de estados en observacion.
			
			if(existe && $.inArray(codEstado, estadosObservacion)<0){
				$('#btnImprimirViatico').prop( 'disabled', false );		
			}	
		});	
	}
}

function updateTitulo() {
	
	if ( esRegistrar() ) {
		setHtmlElement( 'divTituloPanelRegistrarModificarViatico', configRSV.mensajes.registroTitulo );	
	} else {
		setHtmlElement( 'divTituloPanelRegistrarModificarViatico', configRSV.mensajes.modificacionTitulo );	
	}
	
}

function huboModificaciones() {
	
	// hubieron cambios en la seccion I
	if ( getTrimValue( '#txtCodigoMetaPresupuestal' ) != getTrimValue( '#hidCodigoMetaPresupuestalAnterior' ) ) {
		return true;
	}
	
	// hubieron cambios en la seccion II
	if ( getTrimValue( '#txtMotivoComision' ) != getTrimValue( '#hidMotivoComisionAnterior' ) ) {
		return true;
	}
	
	if ( getTrimValue( '#txtObservacion' ) != getTrimValue( '#hidObservacionAnterior' ) ) {
		return true;
	}
	
	if ( esNacional() ) {

		var hidViaticosProgramadosNacAnterior = getTrimValue( '#hidViaticosProgramadosNacAnterior' );
		if ( $( '#rbViaticosProgramadosSI' ).prop( 'checked' ) ) {
			
			if ( $( '#rbViaticosProgramadosSI' ).val() != hidViaticosProgramadosNacAnterior ) {
				return true;
			}
			
		} else {
			
			if ( $( '#rbViaticosProgramadosNO' ).val() != hidViaticosProgramadosNacAnterior ) {
				return true;
			}		
		}		
		
	}
	
	// hubieron cambios en las fechas
	if ( esNacional() ) {
		
		if ( esMayor4h() ) {

			if ( getTrimValue( '#fechaSalidaNacMay4h' ) != getTrimValue( '#hidFechaSalidaNacMay4hAnterior' ) || 
				 getTrimValue( '#fechaRetornoNacMay4h' ) != getTrimValue( '#hidFechaRetornoNacMay4hAnterior' ) ) {
				
				return true;
			}
			
		} else { // es menor igual a 4 horas
			
			if ( getTrimValue( '#fechaNacMen4h' ) != getTrimValue( '#hidFechaNacMen4hAnterior' ) ) {
				
				return true;
			}					
			
		}
		
	} else {  // si es internacional
		
		if ( getTrimValue( '#fechaEventoInicioInter' ) != getTrimValue( '#hidFechaEventoInicioInterAnterior' ) || 
			 getTrimValue( '#fechaEventoFinInter' ) != getTrimValue( '#hidFechaEventoFinInterAnterior' ) ) {
			
			return true;
		}		
		
	}	
	
	// hubieron cambios en la seccion III
	if ( getTrimValue( '#hidCodigoPuntoPartida' ) != getTrimValue( '#hidCodigoPuntoPartidaAnterior' ) ) {
		return true;
	}
	
	// hubieron cambios en los desplazamientos
	if ( estaDefinido( configRSV.desplazamientosCopia ) ) {
		if ( !sonIgualesList( configRSV.desplazamientosCopia, getDesplazamientosList() ) ) {
			return true;
		}
	}
	
	// hubieron cambios en las asignaciones
	if ( estaDefinido( configRSV.asignacionesCopia ) ) {
		if ( !sonIgualesList( configRSV.asignacionesCopia, getAsignacionesList() ) ) {
			return true;
		}
	}
	
	return false;
}

function crearCopiaDesplazamientos() {
	
	// creando y limpiando el array copia de desplazamientos
	configRSV.desplazamientosCopia = [];
	
	crearCopiaList( getDesplazamientosList(), configRSV.desplazamientosCopia );
	
}

function crearCopiaAsignaciones() {

	// creando y limpiando el array copia de desplazamientos
	configRSV.asignacionesCopia = [];
	
	crearCopiaList( getAsignacionesList(), configRSV.asignacionesCopia);
}

function crearCopiaObject( origen, copia ) {
	
	if ( !estaDefinido( origen ) || !estaDefinido( copia ) ) return;
	
	for( var property in origen ) {
		copia[property] = origen[property];
	}
}

function sonIgualesObject( objeto01, objeto02 ) {
	
	// PRE: objeto01 y objeto02 solo deben contener atributos simples (no listas)
	
	if ( !estaDefinido( objeto01 ) || !estaDefinido( objeto02 ) ) return false;
	
	for( var property in objeto01 ) {
		/*
		if ( $.trim( objeto01[property] ) != $.trim( objeto02[property] ) ) {
			return false;
		}
		*/
		
		if ( objeto01[property] != objeto02[property] ) {
			return false;
		}
	}	
	
	
	return true;	
}

function crearCopiaList( listaOrigen, listaCopia ) {
	
	if ( !estaDefinido( listaOrigen ) || !estaDefinido( listaCopia ) ) return;
	
	$.each( listaOrigen, function(i, item) {
		
		var copia = new Object();
		
		crearCopiaObject( item, copia );
		
		listaCopia.push( copia );
		
	});	
}

function sonIgualesList( lista01, lista02 ) {
	
	if ( !estaDefinido( lista01 ) || !estaDefinido( lista02 ) ) return false;
	
	if ( lista01.length != lista02.length ) {
		return false;
	}	
	
	for( var i = 0; i < lista01.length; i++ ) {
		if ( !sonIgualesObject( lista01[i], lista02[i]  ) ) {
			return false;
		}
	} 

	return true;
}


function recalcularImportesFila( desplazamiento ) {

	if ( !estaDefinido( desplazamiento ) ) return;

	// segun tipo recalcula los importes
	if ( esNacional() ) {

		if ( esMayor4h() ) {

			// importeViatico = diasViatico * importeDiario
			desplazamiento.importeViatico = roundString( toNumero(desplazamiento.diasViatico) * toNumero(desplazamiento.importeDiario), 1 );

		} else {	// si es menor o igual a 4 horas

			// importeViatico = diasViatico * importeDiario
			desplazamiento.importeViatico = roundString( toNumero(desplazamiento.horasViatico) * toNumero(desplazamiento.importeDiario), 1 );
		}

	} else { // si es internacional

 		// importeViatico = diasViatico * importeDiario
		desplazamiento.importeViatico = roundString( toNumero(desplazamiento.diasViatico) * toNumero(desplazamiento.importeDiario), 1 );

		var viajeExtraPorDiasTraslado = roundString( toNumero(desplazamiento.viajeExtGtoTras) * toNumero(desplazamiento.diasTraslado), 2 );

		// importeViatico + viajeExtGtoTras * diasTraslado
		desplazamiento.totalOtorgado = roundString( toNumero( desplazamiento.importeViatico ) + toNumero( viajeExtraPorDiasTraslado ), 2 );
	}

	// actualizar solo la fila con el nuevo modelo
	$("#tblDesplazamientoRSV").jqGrid('setRowData', desplazamiento.nro, desplazamiento);

	// recalcular el total
	updateTotalDesplazamientos();
}

function actualizarUnidadFila( desplazamiento, unidad ) {

	if ( !estaDefinido( desplazamiento ) ) return;

	// segun tipo recalcula los importes
	if ( esNacional() ) {

		if ( esMayor4h() ) { // si es mayor o igual a 4 horas
			desplazamiento.diasViatico = unidad;
		} else {	// si es menor o igual a 4 horas
			desplazamiento.horasViatico = unidad;
		}
	} else { // si es internacional
		desplazamiento.diasViatico = unidad;
	}

	// actualizar solo la fila con el nuevo modelo
	$("#tblDesplazamientoRSV").jqGrid('setRowData', desplazamiento.nro, desplazamiento);
}


function obtenerNumeroDiasHorasComision() {
	
	// nacional
	if ( esNacional() ) {
		
		if ( esMayor4h() ) {
		
			return getTrimValue( '#diasNacMay4h' );
			
		} else {
			
			return getTrimValue( '#horasNacMen4h' );
		}
		
	} else {	// internacional
		
		return getTrimValue('#diasInter');
	}
	
}

function calcularDiasHorasDesplazamiento() {
	
	// calcula el número de días u horas de desplazamiento según tipo de viático y duración de comisión.
	var lista = getDesplazamientosList();

	if ( esNacional() ) {

		if ( esMayor4h() ) {

			var sumaDias = 0;
			$.each(lista, function(i, item) {
				sumaDias = sumaDias + toNumero( item.diasViatico );
			});

			// todos son enteros
			return sumaDias;

		} else {	// si es menor o igual a 4 horas

 			var sumaHoras = 0;
			$.each(lista, function(i, item) {
				sumaHoras = sumaHoras + toNumero( item.horasViatico );
			});

			// pueden ser decimales a un digito de redondeo
			return roundNumero(sumaHoras, 1);
		}

	} else { // si es internacional

		var sumaDias = 0;

		$.each(lista, function(i, item) {
			sumaDias = sumaDias + toNumero( item.diasViatico );
		});

		// todos son enteros
		return sumaDias;
	}

}

function buscarDesplazamientoQueSuperaImporteDiarioTope() {

	var result = null;
	var desplazamientos = getDesplazamientosList();

	$.each(desplazamientos, function(i, item) {

		if ( toNumero( item.importeDiario ) > toNumero( item.importeDiarioTope ) ) {
			result = item;
			return false; // break
		}

	});

	return result;
}

function buscarDesplazamientoQueSuperaViajeExtGtoTrasTope() {

	var result = null;
	var desplazamientos = getDesplazamientosList();

	$.each(desplazamientos, function(i, item) {

		if ( toNumero( item.viajeExtGtoTras ) > toNumero( item.viajeExtGtoTrasTope ) ) {
			result = item;
			return false; // break
		}

	});

	return result;
}

function buscarDesplazamientoInternacionalQueSupereDiasTrasladoTope() {

	var desplazamientos = getDesplazamientosList();
	var result = null;

	$.each(desplazamientos, function(i, item) {

		if ( toNumero( item.diasTraslado ) > toNumero( item.diasTrasladoTope ) ) {
			result = item;
			return false; // break
		}

	});

	return result;
}

function buscarDesplazamientoConDiasHorasNoValidos() {

	var desplazamientos = getDesplazamientosList();
	var result = null;

	$.each(desplazamientos, function(i, item) {

		if ( esNacional() ) {

			if ( esMayor4h() ) {

				if ( toNumero( item.diasViatico ) <= 0 ) {
					result = item;
					return false; // break
				}

			} else {  // si es menor igual 4h

				if ( toNumero( item.horasViatico ) <= 0 ) {
					result = item;
					return false; // break
				}
			}

		} else { // si es internacional

			if ( toNumero( item.diasViatico ) <= 0 ) {
				result = item;
				return false; // break
			}
		}

	});

	return result;
}

function buscarDesplazamientoConImporteDiarioNoValido() {

	var desplazamientos = getDesplazamientosList();
	var result = null;

	$.each(desplazamientos, function(i, item) {

		if ( toNumero( item.importeDiario ) <= 0 ) {
			result = item;
			return false; // break
		}

	});

	return result;
}

function construirDataPost( incluirDesplazamientos, incluirAsignaciones ) {

	// recuperar el formulario (elementos enabled y disabled)
	var dataPost = formToObject( 'formViatico', true );

	// quitar las comas en algunos montos
	dataPost.totalDesplazamientos = dataPost.totalDesplazamientos.replace(/,/g , '');
	dataPost.totalAsignaciones = dataPost.totalAsignaciones.replace(/,/g , '');
	dataPost.montoResolucionInter = dataPost.montoResolucionInter.replace(/,/g , '');

	// otros campos
	dataPost.consultaAsistenciaVisualizo = $.trim( configRSV.consultaAsistencia.visualizo );
	dataPost.consultaAsistenciaFecha = $.trim( configRSV.consultaAsistencia.fecha );
	dataPost.consultaAsistenciaHora = $.trim( configRSV.consultaAsistencia.hora );

	// se agregan los desplazamientos y asignaciones
	if ( incluirDesplazamientos )  dataPost.desplazamientosJSON = JSON.stringify( getDesplazamientosList() );
	if ( incluirAsignaciones )  dataPost.asignacionesJSON = JSON.stringify( getAsignacionesList() );

	return dataPost;
}

// manejo de fechas
function hayFechasConError() {

	if ( esNacional() ) {

		if ( esMayor4h() ) {

			return getValueInputText( 'hidFechaSalidaNacMay4hValido' ) == configRSV.VALIDO_ERROR ||
				   getValueInputText( 'hidFechaRetornoNacMay4hValido' ) == configRSV.VALIDO_ERROR;

		} else {

			return getValueInputText( 'hidFechaNacMen4hValido' ) == configRSV.VALIDO_ERROR ||
				   getValueInputText( 'hidSalidaNacMen4hValido' ) == configRSV.VALIDO_ERROR ||
				   getValueInputText( 'hidRetornoNacMen4hValido' ) == configRSV.VALIDO_ERROR;
		}

	} else {

		return getValueInputText( 'hidFechaItinerarioInicioInterValido' ) == configRSV.VALIDO_ERROR ||
			   getValueInputText( 'hidFechaItinerarioFinInterValido' ) == configRSV.VALIDO_ERROR ||
			   getValueInputText( 'hidFechaEventoInicioInterValido' ) == configRSV.VALIDO_ERROR ||
			   getValueInputText( 'hidFechaEventoFinInterValido' ) == configRSV.VALIDO_ERROR ||
			   getValueInputText( 'hidFechaResolucionInterValido' ) == configRSV.VALIDO_ERROR;

	}

}

function revalidarSiHayFechasConError() {

	// buscar en los hidden de validacion, alguna fecha con error

	if ( esNacional() ) {
		if ( esMayor4h() ) {

			if ( getValueInputText( 'hidFechaSalidaNacMay4hValido' ) == configRSV.VALIDO_ERROR ) {
				validarDateFechaSalidaNacMay4hDiv();
				return;
			}
			if ( getValueInputText( 'hidFechaRetornoNacMay4hValido' ) == configRSV.VALIDO_ERROR ) {
				validarDateFechaRetornoNacMay4hDiv();
				return;
			}

		} else {	// si es menor o igual a 4 horas

			if ( getValueInputText( 'hidFechaNacMen4hValido' ) == configRSV.VALIDO_ERROR ) {
				validarDateFechaNacMen4hDiv();
				return;
			}
			if ( getValueInputText( 'hidSalidaNacMen4hValido' ) == configRSV.VALIDO_ERROR ) {
				// no hay evento change todavia
				return;
			}
			if ( getValueInputText( 'hidRetornoNacMen4hValido' ) == configRSV.VALIDO_ERROR ) {
				validarHoraRetornoNacMen4hDiv();
				return;
			}

		}
		
	} else { // si es internacional

		if ( getValueInputText( 'hidFechaItinerarioInicioInterValido' ) == configRSV.VALIDO_ERROR ) {
			validarDateFechaItinerarioInicioInterDiv();
			return;
		}

		if ( getValueInputText( 'hidFechaItinerarioFinInterValido' ) == configRSV.VALIDO_ERROR ) {
			validarDateFechaItinerarioFinInterDiv();
			return;
		}

		if ( getValueInputText( 'hidFechaEventoInicioInterValido' ) == configRSV.VALIDO_ERROR ) {
			validarDateFechaEventoInicioInterDiv();
			return;
		}

		if ( getValueInputText( 'hidFechaEventoFinInterValido' ) == configRSV.VALIDO_ERROR ) {
			validarDateFechaEventoFinInterDiv();
			return;
		}

		if ( getValueInputText( 'hidFechaResolucionInterValido' ) == configRSV.VALIDO_ERROR ) {
			validarDateFechaResolucionInterDiv();
			return;
		}

	}
}

function obtenerFechaConError() {

	// buscar en los hidden de validacion, alguna fecha con error

	if ( esNacional() ) {
		if ( esMayor4h() ) {

			if ( getValueInputText( 'hidFechaSalidaNacMay4hValido' ) == configRSV.VALIDO_ERROR ) return '#fechaSalidaNacMay4h';
			if ( getValueInputText( 'hidFechaRetornoNacMay4hValido' ) == configRSV.VALIDO_ERROR ) return '#fechaRetornoNacMay4h';

			return '#fechaSalidaNacMay4h';

		} else {	// si es menor o igual a 4 horas

			if ( getValueInputText( 'hidFechaNacMen4hValido' ) == configRSV.VALIDO_ERROR ) return '#fechaNacMen4h';
			if ( getValueInputText( 'hidSalidaNacMen4hValido' ) == configRSV.VALIDO_ERROR ) return '#salidaNacMen4h';
			if ( getValueInputText( 'hidRetornoNacMen4hValido' ) == configRSV.VALIDO_ERROR ) return '#retornoNacMen4h';

			return '#fechaNacMen4h';
		}
	} else { // si es internacional

		if ( getValueInputText( 'hidFechaItinerarioInicioInterValido' ) == configRSV.VALIDO_ERROR ) return '#fechaItinerarioInicioInter';
		if ( getValueInputText( 'hidFechaItinerarioFinInterValido' ) == configRSV.VALIDO_ERROR ) return '#fechaItinerarioFinInter';
		if ( getValueInputText( 'hidFechaEventoInicioInterValido' ) == configRSV.VALIDO_ERROR ) return '#fechaEventoInicioInter';
		if ( getValueInputText( 'hidFechaEventoFinInterValido' ) == configRSV.VALIDO_ERROR ) return '#fechaEventoFinInter';
		if ( getValueInputText( 'hidFechaResolucionInterValido' ) == configRSV.VALIDO_ERROR ) return '#fechaResolucionInter';

		return '#fechaItinerarioInicioInter';
	}
}

function bloquearScreen() {
	showModalElement( "divScreenBlock" );
}

function desbloquearScreen() {
	hideModalElement( "divScreenBlock" );
}


// llena una grilla
function fillGrilla( tableID, lista ) {

	// que tableID y lista esten definidos
	if ( !estaDefinido( tableID ) || !estaDefinido( lista ) ) return;

	var table = $( tableID );
	if ( table ) {

		table.clearGridData();

		if (lista != null && lista.length > 0) {

			for (var i = 0; i < lista.length; i++) {

				var datarow = lista[i];

				// agrega el campo nro con una secuencia
				datarow.nro = String(i + 1);

				table.jqGrid("addRowData", datarow.nro, datarow);
			}

			table.trigger("reloadGrid");

		}

	}

}

function updateSelTipoViatico() {
	
	// actualizar controles fechas según el caso
	updateDivsDetalleViatico();

	// limpiar secciones
	limpiarSecciones2345();
	limpiarLabelsError();

	// actualizar botones
	updateBotonConsultarAsistencia();
	updateBotonAgregarDesplazamiento();
	updateEstadosPanelBotones();

	// actualizar dias/horas según el caso
	updateNroDiasInternacional();
	updateNroDiasNacionalMay4h();
	updateNroDiasNacionalMen4h();

}

function updateCombosPuntoPartida() {

	if ( esInternacional() ) {

		// indicador que el valor por defecto en los combos de punto de partida es LIMA/LIMA
		configRSV.puntoPartida.usarLimaComoDefault = configRSV.constantes.SI;

		// setea departamento lima (15), provincia lima (01) 
		setValueInputText( 'selDepartamento', configRSV.constantes.UBIGEO_DEPARTAMENTO_LIMA );
		$('#selDepartamento').trigger( 'change' );

		setTimeout( function() {

			enabledElement( 'selProvincia' );

			setValueInputText( 'selProvincia', configRSV.constantes.UBIGEO_PROVINCIA_LIMA );
			$('#selProvincia').trigger( 'change' );

		}, 300 );

	} else {

		// indicador que el valor por defecto en los combos de punto de partida es 00
		configRSV.puntoPartida.usarLimaComoDefault = configRSV.constantes.NO;

		setValueInputText( 'selDepartamento', '00' );
		setValueInputText( 'selProvincia', '00' );
		setValueInputText( 'hidCodigoPuntoPartida' , '' );
	
		disabledElement( 'selProvincia' );
	}
}

function updateSelDuracionComision() {
	
	// actualizar controles fechas según el caso
	updateDivsDetalleViatico();

	// limpiar secciones
	limpiarSecciones2345();
	limpiarLabelsError();

	// actualizar botones
	updateBotonConsultarAsistencia();
	updateBotonAgregarDesplazamiento();
	updateEstadosPanelBotones();

	// actualizar dias/horas según el caso
	updateNroDiasNacionalMay4h();
	updateNroDiasNacionalMen4h();	
}

//configura los campos en la grilla de desplazamientos (oculta y muestra campos según el tipo de viático y duración de comisión)
function updateEstructuraTablaDesplazamientos() {

	// actualiza la estructura de columnas de la tabla desplazamientos
	// segun el tipo de viatico (nacional, internacional) y duracion de comision (> 4horas, <= 4horas)
	var table = $('#tblDesplazamientoRSV');

	if ( esNacional() ) {

		// ocultar
		table.jqGrid("hideCol", "lugarDestino");
		table.jqGrid("hideCol", "diasTraslado");
		table.jqGrid("hideCol", "viajeExtGtoTras");
		table.jqGrid("hideCol", "totalOtorgado");

		// mostrar
		table.jqGrid("showCol", "departamento");
		table.jqGrid("showCol", "provincia");


		if ( esMayor4h() ) {

			table.jqGrid("hideCol", "horasViatico");
			table.jqGrid("showCol", "diasViatico");

		} else {	// si es menor o igual a 4 horas

			table.jqGrid("hideCol", "diasViatico");
			table.jqGrid("showCol", "horasViatico");
		}


	} else { // si es internacional

		// ocultar
		table.jqGrid("hideCol", "departamento");
		table.jqGrid("hideCol", "provincia");
		table.jqGrid("hideCol", "horasViatico");

		// mostrar
		table.jqGrid("showCol", "lugarDestino");
		table.jqGrid("showCol", "diasTraslado");
		table.jqGrid("showCol", "viajeExtGtoTras");
		table.jqGrid("showCol", "totalOtorgado");
		table.jqGrid("showCol", "diasViatico");

	}

	triggerResizeEvent();
}


//oculta y muestra controles según tipo de viático y duración de comisión
function updateDivsDetalleViatico() {

	// oculta o muestra los divs correspondientes a tipo de viatico nacional/internacional, y si es nacional mayor a 4horas o menor igual a 4horas
	if ( esNacional() ) {

		// cambia la moneda por defecto a soles
		configRSV.moneda = configRSV.constantes.MONEDA_SOLES;
		// $('.lblMoneda').html( configRSV.moneda );
		$('.lblMonedaDesplazamientos').html( 'S/.' );
		$('.lblMonedaAsignaciones').html( 'S/.' );

		// ocultar/visualizar divs
		$('#divTipoDesplazamientoWrapper').show();
		$('#divNacionalWrapper').show();

		if ( esMayor4h() ) {

			// ocultar/visualizar divs
			$('#divInternacionalWrapper').hide();
			$('#divNacionalMayor4Wrapper').show();
			$('#divNacionalMenorIgual4Wrapper').hide();

		} else {	// si es menor o igual a 4 horas

			$('#divInternacionalWrapper').hide();
			$('#divNacionalMayor4Wrapper').hide();
			$('#divNacionalMenorIgual4Wrapper').show();
		}

	} else { // si es internacional

		// cambia la moneda por defecto a soles
		configRSV.moneda = configRSV.constantes.MONEDA_DOLARES;
		// $('.lblMoneda').html( configRSV.moneda );
		$('.lblMonedaDesplazamientos').html( '($)' );
		$('.lblMonedaAsignaciones').html( '$' );

		$('#divTipoDesplazamientoWrapper').hide();
		$('#divNacionalWrapper').hide();

		$('#divInternacionalWrapper').show();
		$('#divNacionalMayor4Wrapper').hide();
		$('#divNacionalMenorIgual4Wrapper').hide();

	}

	updateEstructuraTablaDesplazamientos();
}

function debeRecalcularAsignaciones() {
	
	// CASO PARTICULAR: que tenga asignaciones calculadas fijas pero no coincidEn con el total de desplazamientos
	
	// si los montos
	var asignaciones = getAsignacionesList();
	
	var posFija = indexOfAsignacionesFijas( asignaciones );

	// si tiene asignaciones fijas calculadas
	if ( posFija >= 0 ) {
		
		var importeAsignadoFijo = asignaciones[posFija].importeAsignado;
		var totalDesplazamientos = calcularTotalDesplazamientos();
		
		if ( toNumero( totalDesplazamientos ) != toNumero( importeAsignadoFijo ) ) {
			return true;
		}
		
	}
	
	return false;
}

function tieneAdjuntoSustentoTraslape() {
	
	var archivosAdjuntos = getArchivosAdjuntosList();

	var cuentaConSustentoTraslape = false;
	
	$.each(archivosAdjuntos, function(i, item) {
		
		// NOTA: en el modulo popup de adjuntar archivos, 
		//       los items de la lista que devuelve el after siempre debe tener el campo tipo_doc 
		if ( $.trim( item.tipo_doc ) == 'JUSTIFICACION TRASLAPE COMISION' ) {
			cuentaConSustentoTraslape = true;
			return false; // break
		}
		
	});	
	
	return cuentaConSustentoTraslape;
}

function roundDiferenciaHorasModulo60( horaMayorHHMM, horaMenorHHMM ) {
	// PRE: horaMayorHHMM > horaMenorHHMM (en formato HH:MM )

	// convertir a minutos
	var mayorMins = convertirEnMinutos( horaMayorHHMM );
	var menorMins = convertirEnMinutos( horaMenorHHMM );

	// convertir a horas y redondear a 1 digito
	var roundDifHoras = roundString( ( mayorMins - menorMins ) / 60.0, 1 );

	// cuando la diferencia es uno o dos minutos, el redondeo hace desaparecer el primer dígito decimal
	if ( mayorMins >= menorMins ) {
		
		// cuando el modulo 60 es 1 o 2, por el redondeo esta retornando el x.0.
		var modulo60 = ( mayorMins - menorMins ) % 60;
		if ( modulo60 == 1 || modulo60 == 2 ) {
			roundDifHoras = toNumero( roundDifHoras ) + 0.1; // agregarle 0.1 para visualizar la diferencia
			roundDifHoras = roundString( roundDifHoras, 1 ); 
		}
		
	}

	return roundDifHoras;
}

function initHistorial() {
    
    // se barre todos los controles seleccionados en la cadena queryControlesInit, y crear un [] para guardar los valores del historial
    $( configRSV.historial.queryControlesInit ).each( function(i, item) {
        
        var control = $( item );
        var controlName = $.trim( control.prop( 'name' ) );
        
        if ( controlName != '' ) {
            
            var controlValue = $.trim( control.val() );
            
			configRSV.historial.valores[controlName] = [];
			configRSV.historial.valores[controlName].push( controlValue );

        }
        
    });
}

function grabarHistorial( controlName ) {

	if ( !estaDefinido( controlName ) ) return;
    
	// graba un cambio en el control 'controlName'
    $( configRSV.historial.queryControlesInit ).each( function(i, item) {
        
        var control = $( item );
        
        if ( controlName == control.prop( 'name' ) ) {
            
            var controlValue = $.trim( control.val() );

			configRSV.historial.valores[controlName].push( controlValue );

			// NOTA: si no se desea tener tanta data adicional en el modelo del historial,
			//       se podria cortar el tamaño de la lista a un número fijo de elementos.
			// if ( configRSV.historial.valores[controlName].length > 3 ) {
			//    configRSV.historial.valores[controlName].shift()
			// }
        }
        
    });
}
 

function deshacerHistorial( controlName ) {
    
	if ( !estaDefinido( controlName ) ) return;

	// deshace el último grabado del control 'controlName'
    $( configRSV.historial.queryControlesInit ).each( function(i, item) {
        
        var control = $( item );
        
        if ( controlName == control.prop( 'name' ) ) {
            
			configRSV.historial.valores[controlName].pop();
        }
        
    });
}
 
function getHistorialValorActual( controlName ) {
    
	var valores = configRSV.historial.valores[controlName];

	// retorna el ultimo de la lista - el insertado mas reciente
    return getHistorialValor( controlName, valores.length - 1 );
}

function getHistorialValorAnterior( controlName ) {

	var valores = configRSV.historial.valores[controlName];

	// retorna el penultimo de la lista
    return getHistorialValor( controlName, valores.length - 2 );
}

function getHistorialValor( controlName, posicion ) {

	var valores = configRSV.historial.valores[controlName];

	if ( posicion >= 0 && posicion < valores.length ) {
		return valores[ posicion ];
	}

	return '';
}

function huboCambioHistorial( controlName ) {

    if ( !estaDefinido( controlName ) ) return false;
    
    var valorAnterior = getHistorialValorAnterior( controlName );
    var valorActual = getHistorialValorActual( controlName );
    
    return valorAnterior != valorActual;    
}

function armarRangoFechaValida( fechaInicio, fechaFin ) {

	// PRE: al menos uno de los parametros debe ser fecha valida
	var inicio = fechaInicio;
	var fin = fechaFin;

	// si la fecha de termino no es valida, se forma un rango [fechaInicio, fechaInicio]
	if ( !esFechaValida( fin ) ) {
		fin = fechaInicio;
	}

	// si la fecha de inicio no es valida, se forma un rango [fechaFin, fechaFin]	
	if ( !esFechaValida( inicio ) ) {
		inicio = fechaFin;
	}

	var rangoFechas = {
		'inicio': inicio,
		'fin': fin,
		'rangoValido': esFechaValida( fechaInicio ) || esFechaValida( fechaFin )
	};

	return rangoFechas;
}

function resetearSpanCalendarioIE( queryFechaDiv ) {

	var contenidoHTML = $( queryFechaDiv ).children().last().html();

	$( queryFechaDiv ).children().last().remove();
	$( queryFechaDiv ).append('<span class="input-group-addon input-sm add-on"><span class="glyphicon glyphicon-calendar"></span></span>');

}

function deshabilitarFechasHorasBugIE() {

	// por bug en IE que permite seleccionar el calendario
	if ( isBrowserInternetExplorer() ) {
		
		if ( esNacional() ) {

			if ( esMayor4h() ) {

				resetearSpanCalendarioIE( '#fechaSalidaNacMay4hDiv' );
				resetearSpanCalendarioIE( '#fechaRetornoNacMay4hDiv' );

			} else {	// si es menor o igual a 4h

				resetearSpanCalendarioIE( '#fechaNacMen4hDiv' );
				// en IE no se ve el calendario
				// resetearSpanCalendarioHora( '#salidaNacMen4hDiv' );
				// resetearSpanCalendarioHora( '#retornoNacMen4hDiv' );
			}

		} else { // si es internacional

			// disabled
			resetearSpanCalendarioIE( '#fechaItinerarioInicioInterDiv' );
			resetearSpanCalendarioIE( '#fechaItinerarioFinInterDiv' );
			resetearSpanCalendarioIE( '#fechaEventoInicioInterDiv' );
			resetearSpanCalendarioIE( '#fechaEventoFinInterDiv' );	
			resetearSpanCalendarioIE( '#fechaResolucionInterDiv' );
		}

	}
	
}


var generateDataFirma = function(){
	var pass = $("#txtPasswordUsuario").val();
	var variableImprimirSendPost = $("#txtCodPlanilla").val();
	var dataFirmaJson = {
		"variableImprimirSendPost": variableImprimirSendPost,
		"tipDocumento": "043",
		"tipProceso": "R",
		"txtPasswordUsuario": pass
	};
	return dataFirmaJson;
};


