var buscarCodUUOOonChangeInput = function(event) {
	
	if (typeof buscarUUOOInputService != "undefined") {
			hideElement(buscarUUOOInputService.idDivError);
			if (typeof buscarUUOOInputService.buscarUUOOBefore != "undefined") {
				buscarUUOOInputService.buscarUUOOBefore();
			}
			
			
//			if (trimText(getUpperCaseValueInputText(buscarUUOOInputService.idNumeroUUOO)).length == 0) {
//				setValueInputText("txtNroRegistro", "");
//				setValueInputText("txtUUOODetalle","Todos");
//				setValueInputText("hidCodigoDependencia", "");
//				setValueInputText("txtNombreColaborador", "Todos");
//				setValueInputText("hidCodigoColaborador", "");
//				
//			}
			//var busq = $('#txtUUOO').val().toString();
			var busq = getUpperCaseValueInputText(buscarUUOOInputService.idNumeroUUOO);
			if (trimText(getUpperCaseValueInputText(buscarUUOOInputService.idNumeroUUOO)).length == 6) {
				setTimeout(function(){
					$.ajax({
						url: contextPathUrl + "/dependencias.htm?action=buscarUnidadOrganizacional",
						type: "post",
						dataType: "json",
						cache: false,
						data: {
							"codigoTipoBusquedaUUOO": "01",
							"descripcionBuscarUUOO": getUpperCaseValueInputText(buscarUUOOInputService.idNumeroUUOO),
							"codigoRegistrador": getUpperCaseValueInputText(buscarUUOOInputService.idCodigoRegistrador),
							"flagParametroTodos": "0",
							"codigoTipoUUOOViatico": buscarUUOOInputService.idCodigoTipoUUOOViatico
						},
						beforeSend: function() {
							if (typeof buscarUUOOInputService.idDivLoading != "undefined") {
								showElement(buscarUUOOInputService.idDivLoading);
							}
						},
						complete: function() {
							if (typeof buscarUUOOInputService.idDivLoading != "undefined") {
								hideElement(buscarUUOOInputService.idDivLoading);
							}
						},
						success: function(result) {
							var uoList = result.dependenciaList;
							if (typeof buscarUUOOInputService.buscarUUOOAfter != "undefined") {

								buscarUUOOInputService.buscarUUOOAfter(uoList);
							}
						},
						error: function() {
							if (typeof buscarUUOOInputService.idDivError != "undefined" && typeof buscarUUOOInputService.idEtiquetaError != "undefined" && typeof buscarUUOOInputService.errorMessage != "undefined") {
								showMessageErrorBuscarUUOOInput(buscarUUOOInputService.errorMessage.errorGenerico);
							}
						}
					});
				}, 500);
			}
			else {
				if (typeof buscarUUOOInputService.idDivError != "undefined" && typeof buscarUUOOInputService.idEtiquetaError != "undefined" && typeof buscarUUOOInputService.errorMessage != "undefined") {
					showMessageErrorBuscarUUOOInput(buscarUUOOInputService.errorMessage.cantidadMinimaNumeroRegistro);
				}
			}
		}
		
}

var buscarUUOONumeroUUOOonKeypressInput = function(event) {
	var keyCode = window.event ? event.keyCode : event.which;
	if (keyCode == 8 || (keyCode >= 48 && keyCode <= 57) || (keyCode >= 65 && keyCode <= 90) || (keyCode >= 97 && keyCode <= 122) || keyCode == 128) {
		return true;
	}
	else if (keyCode == 13) {
		//buscarColaboradorNumeroRegistroOnChangeInput(event);
		event.srcElement.blur();
		return false;
	}
	else {
		return false;
	}
}


function showMessageErrorBuscarUUOOInput(errorMessage) {
	setHtmlElement(buscarUUOOInputService.idEtiquetaError, errorMessage);
	showElement(buscarUUOOInputService.idDivError);
}