var buscarColaboradorNumeroRegistroOnChangeInput = function(event) {
	
	if (typeof buscarColaboradorInputService != "undefined") {
		
		hideElement(buscarColaboradorInputService.idDivError);
		if (typeof buscarColaboradorInputService.buscarColaboradorBefore != "undefined") {
			buscarColaboradorInputService.buscarColaboradorBefore();
		}
		if (trimText(getUpperCaseValueInputText(buscarColaboradorInputService.idNumeroRegistroColaborador)).length == 4) {
			
			setTimeout(function(){
				$.ajax({
					url: contextPathUrl + "/colaboradores.htm?action=buscarColaboradores",
					type: "post",
					dataType: "json",
					cache: false,
					data: {
						"tipoBuscaColaborador": "01",
						"parmBuscaColaborador": getUpperCaseValueInputText(buscarColaboradorInputService.idNumeroRegistroColaborador),
						"codigoRegistrador": getUpperCaseValueInputText(buscarColaboradorInputService.idCodigoRegistrador),
						"numeroRegistroRegistrador": getUpperCaseValueInputText(buscarColaboradorInputService.idNumeroRegistroRegistrador),
						"parmTodos": "0",
						"codigoTipoUsuarioViatico": buscarColaboradorInputService.idCodigoTipoUsuarioViatico
					},
					beforeSend: function() {
						if (typeof buscarColaboradorInputService.idDivScreenBlock != "undefined") {
							showModalElement(buscarColaboradorInputService.idDivScreenBlock);
						}
						if (typeof buscarColaboradorInputService.idDivLoading != "undefined") {
							showElement(buscarColaboradorInputService.idDivLoading);
						}
					},
					complete: function() {
						if (typeof buscarColaboradorInputService.idDivLoading != "undefined") {
							hideElement(buscarColaboradorInputService.idDivLoading);
						}
						if (typeof buscarColaboradorInputService.idDivScreenBlock != "undefined") {
							hideModalElement(buscarColaboradorInputService.idDivScreenBlock);
						}
					},
					success: function(result) {
						var colaboradorList = result.listColaboradores;
						if (typeof buscarColaboradorInputService.buscarColaboradorAfter != "undefined") {
							buscarColaboradorInputService.buscarColaboradorAfter(colaboradorList);
						}
					},
					error: function() {
						if (typeof buscarColaboradorInputService.idDivError != "undefined" && typeof buscarColaboradorInputService.idEtiquetaError != "undefined" && typeof buscarColaboradorInputService.errorMessage != "undefined") {
							showMessageErrorBuscarColaboradorInput(buscarColaboradorInputService.errorMessage.errorGenerico);
						}
					}
				});
			}, 500);
		}
		else {
			consoleLog("estadoLlamada: " + buscarColaboradorInputService.estadoLlamada + " cantidad: " + getUpperCaseValueInputText(buscarColaboradorInputService.idNumeroRegistroColaborador));
			if(buscarColaboradorInputService.estadoLlamada == "R"){
				if(typeof buscarColaboradorInputService.idDivError != "undefined" && typeof buscarColaboradorInputService.idEtiquetaError != "undefined" && typeof buscarColaboradorInputService.errorMessage != "undefined" ) {
					showMessageErrorBuscarColaboradorInput(buscarColaboradorInputService.errorMessage.cantidadMinimaNumeroRegistro);
				}
			}else if(buscarColaboradorInputService.estadoLlamada == "B" && trimText(getUpperCaseValueInputText(buscarColaboradorInputService.idNumeroRegistroColaborador)).length > 0){
				
				if(typeof buscarColaboradorInputService.idDivError != "undefined" && typeof buscarColaboradorInputService.idEtiquetaError != "undefined" && typeof buscarColaboradorInputService.errorMessage != "undefined" ) {
					showMessageErrorBuscarColaboradorInput(buscarColaboradorInputService.errorMessage.cantidadMinimaNumeroRegistro);
				}
			}
				
		}
	}
}

var buscarColaboradorNumeroRegistroOnKeypressInput = function(event) {
	var keyCode = window.event ? event.keyCode : event.which;
	if (keyCode == 8 || (keyCode >= 48 && keyCode <= 57) || (keyCode >= 65 && keyCode <= 90) || (keyCode >= 97 && keyCode <= 122) || keyCode == 128) {
		return true;
	}
	else if (keyCode == 13) {
		//buscarColaboradorNumeroRegistroOnChangeInput(event);
		event.srcElement.blur();
		return false;
	}
	else {
		return false;
	}
}

function showMessageErrorBuscarColaboradorInput(errorMessage) {
	setHtmlElement(buscarColaboradorInputService.idEtiquetaError, errorMessage);
	showElement(buscarColaboradorInputService.idDivError);
}