function initElementsConsultarRendicionDetalle(idElementCallModal, codPlanViaje,tipoDestino,indicadorHoras) {
	setInitElementsConsultarRendicionDetalle();
	setInitDetalleViaticoTable(idElementCallModal,tipoDestino,indicadorHoras);
	setInitDetalleGastoTable(idElementCallModal);
	callObtenerPlanViajeDetalle(codPlanViaje,indicadorHoras);
}

function setInitElementsConsultarRendicionDetalle() {
	
	setValueInputText("txtNumeroPlanillaConsultarRendicionDetalle", "");
	setValueInputText("txtNombreColaboradorConsultarRendicionDetalle", "");
	addEventElement("btnCerrarConsultarRendicionDetalle", "click", clickBtnCerrarConsultarRendicionDetalle);
}

function removeEventElementsConsultarRendicionDetalle() {
	removeAllEventsElement("btnCerrarConsultarRendicionDetalle");
}

function removeDetalleViaticoTable() {
	var htmlElement = "<table id=\"tblDetalleViatico\"></table>";
	setHtmlElement("divDetalleViaticoTable", htmlElement);
}

function removeDetalleGastoTable() {
	var htmlElement = "<table id=\"tblDetalleGasto\"></table>";
	setHtmlElement("divDetalleGastoTable", htmlElement);
}

function setInitDetalleViaticoTable(idElementCallModal,tipoDestino,indicadorHoras) {
	var detalleViaticoTable = $("#tblDetalleViatico");
	if (detalleViaticoTable) {
		var detalleViaticoTableDiv = $("#" + idElementCallModal);
		var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.viaticoModalConsultarDetalleContainer", ".viaticoModalConsultarDetalleContainerAuxiliar", "width"))/100);
		var widthTable = factorRedimensionamiento*detalleViaticoTableDiv.width();
		detalleViaticoTable.jqGrid({
			width: widthTable,
			height: 40,
			datatype: "local",
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Código Plan Viaje",
				"UUOO Comisionado",
				(tipoDestino=='01'?"Fecha de Salida":"Fecha Ini. Evento"),
				(tipoDestino=='01'?"Fecha de Retorno":"Fecha Ter. Evento"),
				"Itinerario",
				"Canal de Atención",
				(indicadorHoras=='1'?"Total Horas de la Comisión":"Total Días de la Comisión"),
				"Motivo de la Comisión",
				"Asignación de Pasajes",
				"Otros",
				"Importe Total Otorgado",
				"Nombre del Registrador"
			],
			colModel: [
				{name: "codPlanViaje", index: "codPlanViaje", width: (1*widthTable/20), fixed: true, hidden: true},
				{name: "nomUuOoCom", index: "nomUuOoCom", width: (6*widthTable/20), fixed: true},
				{name: "fecSalida", index: "fecSalida", width: (2*widthTable/20), fixed: true, align: "center"},
				{name: "fecRetorno", index: "fecRetorno", width: (2*widthTable/20), fixed: true, align: "center"},
				{name: "itinerario", index: "itinerario", width: (6*widthTable/20), fixed: true},
				{name: "canalAtencion", index: "canalAtencion", width: (2*widthTable/20), fixed: true},
				{name: "numDias", index: "numDias", width: (2*widthTable/20), fixed: true, align: "center"},
				{name: "motivoComis", index: "motivoComis", width: (6*widthTable/20), fixed: true},
				{name: "impAsigPasajes", index: "impAsigPasajes", width: (2*widthTable/20), fixed: true, align: "right"},
				{name: "impOtros", index: "impOtros", width: (2*widthTable/20), fixed: true, align: "right"},
				{name: "impTotalOtorgado", index: "impTotalOtorgado", width: (2*widthTable/20), fixed: true, align: "right"},
				{name: "nomRegistrador", index: "nomRegistrador", width: (5*widthTable/20), fixed: true}
			],
			caption: "Viático"
		});
	}
}

function setInitDetalleGastoTable(idElementCallModal) {
	var detalleGastoTable = $("#tblDetalleGasto");
	if (detalleGastoTable) {
		var detalleGastoTableDiv = $("#" + idElementCallModal);
		var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.viaticoModalConsultarDetalleContainer", ".viaticoModalConsultarDetalleContainerAuxiliar", "width"))/100);
		var widthTable = factorRedimensionamiento*detalleGastoTableDiv.width();
		detalleGastoTable.jqGrid({
			width: widthTable,
			height: 40,
			datatype: "local",
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Código Plan Viaje",
				"Alojamiento",
				"Alimentación",
				"Movilidad Local",
				"Traslado al del",
				"Pasajes",
				"TUUA",
				"Importe Gastado",
				"Importe Devuelto",
				"Devolución de Menor Gasto",
				"Nro. Recibo Provisional",
				"Fecha Pago Caja Ch."
			],
			colModel: [
				{name: "codPlanViaje", index: "codPlanViaje", width: (1*widthTable/20), fixed: true, hidden: true},
				{name: "impGastoAloj", index: "impGastoAloj", width: (2*widthTable/20), fixed: true, align: "right"},
				{name: "impGastoAlim", index: "impGastoAlim", width: (2*widthTable/20), fixed: true, align: "right"},
				{name: "impGastoMovLocal", index: "impGastoMovLocal", width: (2*widthTable/20), fixed: true, align: "right"},
				{name: "impGastoTraslado", index: "impGastoTraslado", width: (2*widthTable/20), fixed: true, align: "right"},
				{name: "impGastoPasajes", index: "impGastoPasajes", width: (2*widthTable/20), fixed: true, align: "right"},
				{name: "impGastoTUUA", index: "impGastoTUUA", width: (2*widthTable/20), fixed: true, hidden: true},
				{name: "impGasto", index: "impGasto", width: (2*widthTable/20), fixed: true, align: "right"},
				{name: "impDevuelto", index: "impDevuelto", width: (2*widthTable/20), fixed: true, align: "right"},
				{name: "impDevolMenor", index: "impDevolMenor", width: (2*widthTable/20), fixed: true, align: "right"},
				{name: "numReciboProv", index: "numReciboProv", width: (3*widthTable/20), fixed: true},
				{name: "fecPagoCajaCh", index: "fecPagoCajaCh", width: (2*widthTable/20), fixed: true, align: "center"}
			],
			caption: "Detalle del Gasto"
		});
	}
}

function clickBtnCerrarConsultarRendicionDetalle() {
	removeEventElementsConsultarRendicionDetalle();
	removeDetalleViaticoTable();
	removeDetalleGastoTable();
	hideModalElement("divConsultarRendicionDetalle");
}

function callObtenerPlanViajeDetalle(codPlanViaje,indicadorHoras) {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/rendicion.htm?action=obtenerPlanViajeDetalle",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codPlanViaje": codPlanViaje
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showElement("divLoadingConsultarRendicionDetalle");
			},
			complete: function() {
				hideElement("divLoadingConsultarRendicionDetalle");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var codigoConsulta = result.codigoConsulta;
				var errorMessage = result.errorMessage;
				if (codigoConsulta != null && codigoConsulta == "00") {
					
					var planViaje = result.planViajeBean;
					var detalleViaticoTable = $("#tblDetalleViatico");
					detalleViaticoTable.clearGridData();
					var detalleGastoTable = $("#tblDetalleGasto");
					detalleGastoTable.clearGridData();
					setValueInputText("txtNumeroPlanillaConsultarRendicionDetalle", planViaje.codPlanilla);
					setValueInputText("txtNombreColaboradorConsultarRendicionDetalle", planViaje.nomColaborador);
					var datarow = {
						codPlanViaje: planViaje.codPlanViaje,
						nomUuOoCom: planViaje.nomUuOoCom,
						fecSalida: planViaje.fecSalidaFormateada,
						fecRetorno: planViaje.fecRetornoFormateada,
						itinerario: planViaje.itinerario,
						canalAtencion: planViaje.canalAtencion,
						numDias: (indicadorHoras=='1'?planViaje.numeroHoras:planViaje.numDias),
						motivoComis: planViaje.motivoComis,
						impAsigPasajes: planViaje.impAsigPasajesFormateado,
						impOtros: planViaje.impOtrosFormateado,
						impTotalOtorgado: planViaje.impTotalOtorgadoFormateado,
						nomRegistrador: planViaje.nomRegistrador,
						impGastoAloj: planViaje.impGastoAlojFormateado,
						impGastoAlim: planViaje.impGastoAlimFormateado,
						impGastoMovLocal: planViaje.impGastoMovLocalFormateado,
						impGastoTraslado: planViaje.impGastoTrasladoFormateado,
						impGastoPasajes: planViaje.impGastoPasajesFormateado,
						impGastoTUUA: planViaje.impGastoTUUAFormateado,
						impGasto: planViaje.impGastoFormateado,
						impDevuelto: planViaje.impDevueltoFormateado,
						impDevolMenor: planViaje.impDevolMenorFormateado,
						numReciboProv: planViaje.numReciboProv,
						fecPagoCajaCh: planViaje.fecPagoCajaChFormateado
					};
					detalleViaticoTable.jqGrid("addRowData", datarow.codPlanViaje, datarow);
					detalleViaticoTable.trigger("reloadGrid");
					detalleGastoTable.jqGrid("addRowData", datarow.codPlanViaje, datarow);
					detalleGastoTable.trigger("reloadGrid");
					triggerResizeEventSlow();
				}
				else {
					//showMensajeConfirmacionAplicativoWithoutBody("divMensajeConfirmacionErrorRegistrarMofificarRendicion", "divTituloPanelMensajeConfirmacionErrorRegistrarMofificarRendicion", "divBodyPanelMensajeConfirmacionErrorRegistrarMofificarRendicion", errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callObtenerPlanViajeDetalle");
			}
		});
	}, 500);
}
