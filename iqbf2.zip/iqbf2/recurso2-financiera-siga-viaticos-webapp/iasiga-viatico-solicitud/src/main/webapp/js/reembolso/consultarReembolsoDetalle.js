function initElementsConsultarReembolsoDetalle(idElementCallModal, codPlanViaje) {
	
	setInitElementsConsultarReembolsoDetalle();
	setInitDetalleSolicitudTable(idElementCallModal);
	setInitDetalleGastoTable(idElementCallModal);
	callObtenerPlanViajeDetalleBandejaReembolso(codPlanViaje);
}

function setInitElementsConsultarReembolsoDetalle() {
	
	setValueInputText("txtNumeroPlanillaConsultarReembolsoDetalle", "");
	setValueInputText("txtNombreColaboradorConsultarReembolsoDetalle", "");
	addEventElement("btnCerrarConsultarReembolsoDetalle", "click", clickBtnCerrarConsultarReembolsoDetalle);
}

function removeEventElementsConsultarReembolsoDetalle() {
	removeAllEventsElement("btnCerrarConsultarReembolsoDetalle");
}

function removeDetalleSolicitudTable() {
	var htmlElement = "<table id=\"tblDetalleSolicitud\"></table>";
	setHtmlElement("divDetalleSolicitudTable", htmlElement);
}

function removeDetalleGastoTable() {
	var htmlElement = "<table id=\"tblDetalleGasto\"></table>";
	setHtmlElement("divDetalleGastoTable", htmlElement);
}

function setInitDetalleSolicitudTable(idElementCallModal) {
	var detalleSolicitudTable = $("#tblDetalleSolicitud");
	if (detalleSolicitudTable) {
		var detalleSolicitudTableDiv = $("#" + idElementCallModal);
		var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.viaticoModalConsultarDetalleContainer", ".viaticoModalConsultarDetalleContainerAuxiliar", "width"))/100);
		var widthTable = factorRedimensionamiento*detalleSolicitudTableDiv.width();
		detalleSolicitudTable.jqGrid({
			width: widthTable,
			height: 40,
			datatype: "local",
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Código Plan Viaje",
				"Planilla Asociada",
				"UUOO",
				"Itinerario",
				"Fecha de Salida",
				"Fecha de Retorno",
				"Motivo de la Comisión",
				"Motivo por el cual no se otorgo Viáticos",
				"Nombre del Registrador",
				"Nro. de Resolución Administrativa"
			],
			colModel: [
				{name: "codPlanViaje", index: "codPlanViaje", width: (1*widthTable/20), fixed: true, hidden: true},
				{name: "codigoPlanillaAsc", index: "codigoPlanillaAsc", width: (2*widthTable/20), fixed: true, align: "center"},
				{name: "nomUuOoCom", index: "nomUuOoCom", width: (6*widthTable/20), fixed: true},
				{name: "itinerario", index: "itinerario", width: (6*widthTable/20), fixed: true},
				{name: "fecSalida", index: "fecSalida", width: (2*widthTable/20), fixed: true, align: "center"},
				{name: "fecRetorno", index: "fecRetorno", width: (2*widthTable/20), fixed: true, align: "center"},
				{name: "motivoComis", index: "motivoComis", width: (6*widthTable/20), fixed: true},
				{name: "observacionAnulacion", index: "observacionAnulacion", width: (6*widthTable/20), fixed: true},
				{name: "nomRegistrador", index: "nomRegistrador", width: (5*widthTable/20), fixed: true},
				{name: "internacionalNroResolucion", index: "internacionalNroResolucion", width: (3*widthTable/20), fixed: true}
			],
			caption: "Detalle de la Solicitud"
		});
	}
}

function setInitDetalleGastoTable(idElementCallModal) {
	var detalleGastoTable = $("#tblDetalleGasto");
	if (detalleGastoTable) {
		var detalleGastoTableDiv = $("#" + idElementCallModal);
		var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.viaticoModalConsultarDetalleContainer", ".viaticoModalConsultarDetalleContainerAuxiliar", "width"))/100);
		var widthTable = factorRedimensionamiento*detalleGastoTableDiv.width();
		detalleGastoTable.jqGrid({
			width: widthTable,
			height: 40,
			datatype: "local",
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Código Plan Viaje",
				"Alojamiento",
				"Alimentación",
				"Movilidad Local",
				"Traslado al/del",
				"Pasajes",
				"TUUA",
				"Medio Pago"
			],
			colModel: [
				{name: "codPlanViaje", index: "codPlanViaje", width: (1*widthTable/20), fixed: true, hidden: true},
				{name: "impGastoAloj", index: "impGastoAloj", width: (3*widthTable/20), fixed: true, align: "right"},
				{name: "impGastoAlim", index: "impGastoAlim", width: (3*widthTable/20), fixed: true, align: "right"},
				{name: "impGastoMovLocal", index: "impGastoMovLocal", width: (3*widthTable/20), fixed: true, align: "right"},
				{name: "impGastoTraslado", index: "impGastoTraslado", width: (3*widthTable/20), fixed: true, align: "right"},
				{name: "impGastoPasajes", index: "impGastoPasajes", width: (3*widthTable/20), fixed: true, align: "right"},
				{name: "impGastoTUUA", index: "impGastoTUUA", width: (3*widthTable/20), fixed: true, hidden: true},
				{name: "medioPago", index: "medioPago", width: (6*widthTable/20), fixed: true}
			],
			caption: "Detalle del Gasto"
		});
	}
}

function clickBtnCerrarConsultarReembolsoDetalle() {
	removeEventElementsConsultarReembolsoDetalle();
	removeDetalleSolicitudTable();
	removeDetalleGastoTable();
	hideModalElement("divConsultarReembolsoDetalle");
}

function callObtenerPlanViajeDetalleBandejaReembolso(codPlanViaje) {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/reembolso.htm?action=obtenerPlanViajeDetalleBandejaReembolso",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codPlanViaje": codPlanViaje
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showElement("divLoadingConsultarReembolsoDetalle");
			},
			complete: function() {
				hideElement("divLoadingConsultarReembolsoDetalle");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var codigoConsulta = result.codigoConsulta;
				var errorMessage = result.errorMessage;
				if (codigoConsulta != null && codigoConsulta == "00") {
					
					var planViaje = result.planViajeBean;
					var detalleSolicitudTable = $("#tblDetalleSolicitud");
					detalleSolicitudTable.clearGridData();
					var detalleGastoTable = $("#tblDetalleGasto");
					detalleGastoTable.clearGridData();
					setValueInputText("txtNumeroPlanillaConsultarReembolsoDetalle", planViaje.codPlanilla);
					setValueInputText("txtNombreColaboradorConsultarReembolsoDetalle", planViaje.nomColaborador);
					var datarow = {
						codPlanViaje: planViaje.codPlanViaje,
						codigoPlanillaAsc: planViaje.codigoPlanillaAsc,
						nomUuOoCom: planViaje.nomUuOoCom,
						itinerario: planViaje.itinerario,
						fecSalida: planViaje.fecSalidaFormateada,
						fecRetorno: planViaje.fecRetornoFormateada,
						motivoComis: planViaje.motivoComis,
						observacionAnulacion: planViaje.observacionAnulacion,
						nomRegistrador: planViaje.nomRegistrador,
						internacionalNroResolucion: planViaje.internacionalNroResolucion,
						impGastoAloj: planViaje.impGastoAlojFormateado,
						impGastoAlim: planViaje.impGastoAlimFormateado,
						impGastoMovLocal: planViaje.impGastoMovLocalFormateado,
						impGastoTraslado: planViaje.impGastoTrasladoFormateado,
						impGastoPasajes: planViaje.impGastoPasajesFormateado,
						impGastoTUUA: planViaje.impGastoTUUAFormateado,
						medioPago: planViaje.medioPago
					};
					detalleSolicitudTable.jqGrid("addRowData", datarow.codPlanViaje, datarow);
					detalleSolicitudTable.trigger("reloadGrid");
					detalleGastoTable.jqGrid("addRowData", datarow.codPlanViaje, datarow);
					detalleGastoTable.trigger("reloadGrid");
					triggerResizeEventSlow();
				}
				else {
					//showMensajeConfirmacionAplicativoWithoutBody("divMensajeConfirmacionErrorRegistrarMofificarRendicion", "divTituloPanelMensajeConfirmacionErrorRegistrarMofificarRendicion", "divBodyPanelMensajeConfirmacionErrorRegistrarMofificarRendicion", errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callObtenerPlanViajeDetalleBandejaReembolso");
			}
		});
	}, 500);
}