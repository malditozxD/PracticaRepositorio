function initElementsRevisarRendicionBandeja() {
	removeDuplicateComponents();
	setInitElementsRevisarRendicionBandeja();
	if (getValueInputText("hidFlagRegistradorUniversal") == "1") {
		setInitPlanillaTableRegistradorUniversal();
	}
	else {
		setInitPlanillaTable();
	}
}

function setInitElementsRevisarRendicionBandeja() {
	
	disabledElement("btnExportarExcelRendicion");
	setValueInputText("txtCodigoPlanilla", "");
	setValueInputText("selEstadoRendicion", "00");
	setValueInputText("selAnioRendicion", getValueInputText("hidAnioActual"));
	setValueInputText("selCanalAtencionRendicion", "00");
	setValueInputText("hidFechaMaximaAnioActual", getValueInputText("hidAnioActual") + "/12/31");
	modificarRangoFechaRendicionBandeja(getValueInputText("hidAnioActual"));
	
	addEventElement("btnBuscarUUOORendicion", "click", clickBtnBuscarUUOORendicion);
	addEventElement("btnBuscarColaboradorRendicion", "click", clickBtnBuscarColaboradorRendicion);
	addEventElement("selEstadoRendicion", "change", changeSelEstadoRendicion);
	addEventElement("selAnioRendicion", "change", changeSelAnioRendicion);
	addEventElement("selCanalAtencionRendicion", "change", changeSelCanalAtencionRendicion);
	addEventElement("btnConsultarRendicion", "click", clickBtnConsultarRendicion);
	addEventElement("btnExportarExcelRendicion", "click", clickBtnExportarExcelRendicion);
	addEventElement("etiquetaFechaInicioRendicion", "change", changeEtiquetaFechaInicioRendicion);
	addEventElement("etiquetaFechaFinRendicion", "change", changeEtiquetaFechaFinRendicion);
	initDateTimePickerWithMaxDate("etiquetaFechaInicioRendicionDiv", "dp.change", "changeDate", changeDateEtiquetaFechaInicioRendicionDiv, getValueInputText("hidFechaMaximaAnioActual"));
	initDateTimePickerWithMaxDate("etiquetaFechaFinRendicionDiv", "dp.change", "changeDate", changeDateEtiquetaFechaFinRendicionDiv, getValueInputText("hidFechaMaximaAnioActual"));
	
	addEventElement("btnAceptarMensajeConfirmacionRevisarRendicionBandeja", "click", clickBtnAceptarMensajeConfirmacionRevisarRendicionBandeja);
	addEventElement("btnAceptarMensajeConfirmacionErrorRevisarRendicionBandeja", "click", clickBtnAceptarMensajeConfirmacionErrorRevisarRendicionBandeja);
	addEventElement("btnSiAnularEnvioRevisar", "click", clickBtnSiAnularEnvioRevisar);
	addEventElement("btnNoAnularEnvioRevisar", "click", clickBtnNoAnularEnvioRevisar);
	addEventElement("btnAceptarAnulacionExitosaRevisar", "click", clickBtnAceptarAnulacionExitosaRevisar);
}

function setInitPlanillaTable() {
	
	var planillaTable = $("#tblPlanilla");
	var heightJqGrid = 200;
	setStyleElement("divPlanillaTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 2, true));
	if (planillaTable) {
		var planillaTableDiv = $("#divPlanillaTable");
		var widthTable = planillaTableDiv.width();
		planillaTable.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			datatype: "local",
			rowNum: 10,
			rowList: [10, 20],
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Código Plan Viaje",
				"Nro. Planilla",
				"Nro. Planilla",
				"Fec. Registro Solicitud",
				"Fec. Registro de la Rendición",
				"Número Registro",
				"Nombre Colaborador",
				"Código Tipo Destino",
				"Tipo de Viáticos",
				"Monto Total",
				"Total Otorgado",
				"Fecha para Rendir Cuenta",
				"Fecha Reprogramada",
				"Días Vcto. Plazo",
				"Código Estado Rendición",
				"Estado Rendición",
				"Observación",
				"Indicador Canal Atención",
				"Motivo",
				"Fecha Salida",
				"Fecha Retorno",
				"Hora Salida",
				"Hora Retorno",
				"Indicador Horas",
				"Numero Dias",
				"Numero Horas",
				"PoaProgramado",
				"Indicador Segunda Notificación",
				"Expediente Plan Viaje",
				"Expediente Rendicion",
				"Numero Registro Archivo",
				"",
				"Acción",
				"",
				""
			],
			colModel: [
				{name: "codPlanViaje", index: "codPlanViaje", width: (1*widthTable/20), hidden: true},
				{name: "codPlanilla", index: "codPlanilla", width: (1*widthTable/20), hidden: true},
				{name: "codPlanillaLink", index: "codPlanillaLink", width: (2*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "";
						var codPlanViaje = rowData.codPlanViaje;
						var codPlanilla = rowData.codPlanilla;
						var encodeParam = "codPlanViaje=" + codPlanViaje;
						//Si el estado de la rendicion es pendiente(01), observado por caja chica(03) u observado(04) y ademas no ha sido notificado por segunda vez.
						if ((rowData.codEstadoRend == "01" || rowData.codEstadoRend == "03" || rowData.codEstadoRend == "04") && rowData.indicadorSegNotif != "1") {
							htmlElement = sendDataMethodPost(codPlanViaje + "_registrarRendicion", "registrarRendicion", "mostrarRegistrarRendicion", encodeParam, codPlanilla);
						}
						else {
							encodeParam += "&codigoPaginaCaller=" + getValueInputText("hidCodigoPaginaCaller");
							htmlElement = sendDataMethodPost(codPlanViaje + "_consultarRendicion", "rendicion", "mostrarConsultarRendicion", encodeParam, codPlanilla);
						}
						return htmlElement;
					}
				},
				{name: "fechaRegistro", index: "fechaRegistro", width: (1*widthTable/20), hidden: true},
				{name: "fechaRegistroRendicion", index: "fechaRegistroRendicion", width: (2*widthTable/20), align: "center"},
				{name: "numeroRegistroAlterno", index: "numeroRegistroAlterno", width: (1*widthTable/20), hidden: true},
				{name: "nomColaborador", index: "nomColaborador", width: (3*widthTable/20)},
				{name: "tipoDestino", index: "tipoDestino", width: (1*widthTable/20), hidden: true},
				{name: "nomTipoViatico", index: "nomTipoViatico", width: (1.7*widthTable/20)},
				{name: "mtoTotal", index: "mtoTotal", width: (1*widthTable/20), hidden: true},
				{name: "mtoTotalFormateado", index: "mtoTotalFormateado", width: (1.9*widthTable/20), align: "right"},
				{name: "fecMaxRend", index: "fecMaxRend", width: (1.8*widthTable/20), align: "center"},
				//JMCR-ME Fecha Reprogramacion
				{name: "fecReprog", index: "fecReprog", width: (1.8*widthTable/20), align: "center"},
				//JMCR-ME Fecha Reprogramacion
				{name: "cantDiasRend", index: "cantDiasRend", width: (1.4*widthTable/20),
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "";
						if (cellValue < 0) {
							htmlElement = "<span class=\"jqGridViaticoSemaphoreRedCell\">" + cellValue + "</span>";
						}
						else {
							htmlElement = "<span class=\"jqGridViaticoSemaphoreGreenCell\">" + cellValue + "</span>";
						}
						return htmlElement;
					}
				},
				{name: "codEstadoRend", index: "codEstadoRend", width: (1*widthTable/20), hidden: true},
				{name: "nomEstRend", index: "nomEstRend", width: (1.8*widthTable/20),
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "";
						if (rowData.codEstadoRend == "03" || rowData.codEstadoRend == "04") {
							htmlElement = "<a class=\"jqGridViaticoTooltipClass\" data-toggle=\"tooltip\" data-placement=\"right\" title=\"" + rowData.obsRendicion + "\" >" + rowData.nomEstRend + "</a>";
						}
						else {
							htmlElement = rowData.nomEstRend;
						}
						return htmlElement;
					}
				},
				{name: "obsRendicion", index: "obsRendicion", width: (1*widthTable/20), hidden: true},
				{name: "indicadorCanalAtencion", index: "indicadorCanalAtencion", width: (1*widthTable/20), hidden: true},
				{name: "motivoComis", index: "motivoComis", width: (1*widthTable/20), hidden: true},
				{name: "fecSalida", index: "fecSalida", width: (1*widthTable/20), hidden: true},
				{name: "fecRetorno", index: "fecRetorno", width: (1*widthTable/20), hidden: true},
				{name: "horaSalida", index: "horaSalida", width: (1*widthTable/20), hidden: true},
				{name: "horaRetorno", index: "horaRetorno", width: (1*widthTable/20), hidden: true},
				{name: "indicadorHoras", index: "indicadorHoras", width: (1*widthTable/20), hidden: true},
				{name: "numDias", index: "numDias", width: (1*widthTable/20), hidden: true},
				{name: "numeroHoras", index: "numeroHoras", width: (1*widthTable/20), hidden: true},
				{name: "poaProgramado", index: "poaProgramado", width: (1*widthTable/20), hidden: true},
				{name: "indicadorSegNotif", index: "indicadorSegNotif", width: (1*widthTable/20), hidden: true},
				{name: "expedientePlanViaje", index: "expedientePlanViaje", width: (1*widthTable/20), hidden: true},
				{name: "expedienteRendicion", index: "expedienteRendicion", width: (1*widthTable/20), hidden: true},
				{name: "numeroRegistroArchivo", index: "numeroRegistroArchivo", width: (1*widthTable/20), hidden: true},
				{name: "detalleRendicion", index: "detalleRendicion", width: (1*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkConsultarRendicionDetalle('" + rowData.codPlanViaje + "');\">" + rowData.detalleRendicion + "</a>";
						return htmlElement;
					}
				},
				{name: "seguimientoPlanilla", index: "seguimientoPlanilla", width: (1.4*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkConsultarSeguimientoRendicion('" + rowData.codPlanViaje + "');\">" + rowData.seguimientoPlanilla + "</a>";
						return htmlElement;
					}
				},
				{name: "anularEnvio", index: "anularEnvio", width: (1.4*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "";
						
						//Si el estado de la rendicion es rendido(10) o no ha sido notificado por segunda vez.
						if (!(rowData.codEstadoRend == "10" || rowData.indicadorSegNotif == "1")) {
							var htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkAnularEnvio('" + rowData.codPlanViaje + "');\">" + rowData.anularEnvio + "</a>";
						}
						return htmlElement;
					}
				},
				{name: "verAdjuntosPlanilla", index: "verAdjuntosPlanilla", width: (0.6*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkConsultarAdjuntosRendicion('" + rowData.codPlanViaje + "');\">" + rowData.verAdjuntosPlanilla + "</a>";
						return htmlElement;
					}
				}
			],
			caption: "Planillas",
			pager: "#divPlanillaPagerTable",
			loadui: "disable"
		});
		planillaTable.clearGridData();
		addEventElementBySelector("#divPlanillaTable .ui-pg-button.ui-corner-all", "click", clickPagerPlanillaTable);
		addEventElementBySelector("#divPlanillaTable input.ui-pg-input", "keypress", keypressPagerPlanillaTable);
		addEventElementBySelector("#divPlanillaTable select.ui-pg-selbox", "change", changePagerPlanillaTable);
	}
}

function setInitPlanillaTableRegistradorUniversal() {
	
	var planillaTable = $("#tblPlanilla");
	var heightJqGrid = 200;
	setStyleElement("divPlanillaTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 1, true));
	if (planillaTable) {
		var planillaTableDiv = $("#divPlanillaTable");
		var widthTable = planillaTableDiv.width();
		planillaTable.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			datatype: "local",
			rowNum: 10,
			rowList: [10, 20],
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Código Plan Viaje",
				"Nro. Planilla",
				"Nro. Planilla",
				"Fec. Registro Solicitud",
				"Fec. Registro de la Rendición",
				"Número Registro",
				"Nombre Colaborador",
				"Código Tipo Destino",
				"Tipo de Viáticos",
				"Monto Total",
				"Total Otorgado",
				"Fecha para Rendir Cuenta",
				"Fecha Reprogramada",
				"Días Vcto. Plazo",
				"Código Estado Rendición",
				"Estado Rendición",
				"Observación",
				"Indicador Canal Atención",
				"Motivo",
				"Fecha Salida",
				"Fecha Retorno",
				"Hora Salida",
				"Hora Retorno",
				"Indicador Horas",
				"Numero Dias",
				"Numero Horas",
				"PoaProgramado",
				"Indicador Segunda Notificación",
				"Expediente Plan Viaje",
				"Expediente Rendicion",
				"Numero Registro Archivo",
				"",
				"",
				"Acción",
				"",
				""
			],
			colModel: [
				{name: "codPlanViaje", index: "codPlanViaje", width: (1*widthTable/20), hidden: true},
				{name: "codPlanilla", index: "codPlanilla", width: (1*widthTable/20), hidden: true},
				{name: "codPlanillaLink", index: "codPlanillaLink", width: (2*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "";
						var codPlanViaje = rowData.codPlanViaje;
						var codPlanilla = rowData.codPlanilla;
						var encodeParam = "codPlanViaje=" + codPlanViaje;
						/*
						if (rowData.indicadorSegNotif == "1") {
							encodeParam += "&codigoPaginaCaller=" + getValueInputText("hidCodigoPaginaCaller");
							htmlElement = sendDataMethodPost(codPlanViaje + "_consultarRendicion", "consultarRendicion", "mostrarConsultarRendicion", encodeParam, codPlanilla);
						}
						else {
							if (rowData.codEstadoRend == "01" || rowData.codEstadoRend == "03") {
								htmlElement = sendDataMethodPost(codPlanViaje + "_registrarRendicion", "registrarRendicion", "mostrarRegistrarRendicion", encodeParam, codPlanilla);
							}
							else {
								encodeParam += "&codigoPaginaCaller=" + getValueInputText("hidCodigoPaginaCaller");
								htmlElement = sendDataMethodPost(codPlanViaje + "_consultarRendicion", "consultarRendicion", "mostrarConsultarRendicion", encodeParam, codPlanilla);
							}
						}*/
						if (rowData.codEstadoRend == "01" || rowData.codEstadoRend == "03" || rowData.codEstadoRend == "04") { //JMCR-ME MODIFICACION RENDICION
							htmlElement = sendDataMethodPost(codPlanViaje + "_registrarRendicion", "registrarRendicion", "mostrarRegistrarRendicion", encodeParam, codPlanilla);
						}
						else {
							encodeParam += "&codigoPaginaCaller=" + getValueInputText("hidCodigoPaginaCaller");
							htmlElement = sendDataMethodPost(codPlanViaje + "_consultarRendicion", "rendicion", "mostrarConsultarRendicion", encodeParam, codPlanilla);
						}
						return htmlElement;
					}
				},
				{name: "fechaRegistro", index: "fechaRegistro", width: (1*widthTable/20), hidden: true},
				{name: "fechaRegistroRendicion", index: "fechaRegistroRendicion", width: (1.8*widthTable/20), align: "center"},
				{name: "numeroRegistroAlterno", index: "numeroRegistroAlterno", width: (1*widthTable/20), hidden: true},
				{name: "nomColaborador", index: "nomColaborador", width: (2.7*widthTable/20)},
				{name: "tipoDestino", index: "tipoDestino", width: (1*widthTable/20), hidden: true},
				{name: "nomTipoViatico", index: "nomTipoViatico", width: (1.6*widthTable/20)},
				{name: "mtoTotal", index: "mtoTotal", width: (1*widthTable/20), hidden: true},
				{name: "mtoTotalFormateado", index: "mtoTotalFormateado", width: (1.8*widthTable/20), align: "right"},
				{name: "fecMaxRend", index: "fecMaxRend", width: (1.7*widthTable/20), align: "center"},
				//JMCR-ME Fecha Reprogramacion
				{name: "fecReprog", index: "fecReprog", width: (1.7*widthTable/20), align: "center"},
				//JMCR-ME Fecha Reprogramacion
				{name: "cantDiasRend", index: "cantDiasRend", width: (1.2*widthTable/20),
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "";
						if (cellValue < 0) {
							htmlElement = "<span class=\"jqGridViaticoSemaphoreRedCell\">" + cellValue + "</span>";
						}
						else {
							htmlElement = "<span class=\"jqGridViaticoSemaphoreGreenCell\">" + cellValue + "</span>";
						}
						return htmlElement;
					}
				},
				{name: "codEstadoRend", index: "codEstadoRend", width: (1*widthTable/20), hidden: true},
				{name: "nomEstRend", index: "nomEstRend", width: (1.8*widthTable/20),
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "";
						if (rowData.codEstadoRend == "03" || rowData.codEstadoRend == "04") {
							htmlElement = "<a class=\"jqGridViaticoTooltipClass\" data-toggle=\"tooltip\" data-placement=\"right\" title=\"" + rowData.obsRendicion + "\" >" + rowData.nomEstRend + "</a>";
						}
						else {
							htmlElement = rowData.nomEstRend;
						}
						return htmlElement;
					}
				},
				{name: "obsRendicion", index: "obsRendicion", width: (1*widthTable/20), hidden: true},
				{name: "indicadorCanalAtencion", index: "indicadorCanalAtencion", width: (1*widthTable/20), hidden: true},
				{name: "motivoComis", index: "motivoComis", width: (1*widthTable/20), hidden: true},
				{name: "fecSalida", index: "fecSalida", width: (1*widthTable/20), hidden: true},
				{name: "fecRetorno", index: "fecRetorno", width: (1*widthTable/20), hidden: true},
				{name: "horaSalida", index: "horaSalida", width: (1*widthTable/20), hidden: true},
				{name: "horaRetorno", index: "horaRetorno", width: (1*widthTable/20), hidden: true},
				{name: "indicadorHoras", index: "indicadorHoras", width: (1*widthTable/20), hidden: true},
				{name: "numDias", index: "numDias", width: (1*widthTable/20), hidden: true},
				{name: "numeroHoras", index: "numeroHoras", width: (1*widthTable/20), hidden: true},
				{name: "poaProgramado", index: "poaProgramado", width: (1*widthTable/20), hidden: true},
				{name: "indicadorSegNotif", index: "indicadorSegNotif", width: (1*widthTable/20), hidden: true},
				{name: "expedientePlanViaje", index: "expedientePlanViaje", width: (1*widthTable/20), hidden: true},
				{name: "expedienteRendicion", index: "expedienteRendicion", width: (1*widthTable/20), hidden: true},
				{name: "numeroRegistroArchivo", index: "numeroRegistroArchivo", width: (1*widthTable/20), hidden: true},
				{name: "detalleRendicion", index: "detalleRendicion", width: (0.9*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkConsultarRendicionDetalle('" + rowData.codPlanViaje + "');\">" + rowData.detalleRendicion + "</a>";
						return htmlElement;
					}
				},
				{name: "seguimientoPlanilla", index: "seguimientoPlanilla", width: (1.3*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkConsultarSeguimientoRendicion('" + rowData.codPlanViaje + "');\">" + rowData.seguimientoPlanilla + "</a>";
						return htmlElement;
					}
				},
				{name: "anularEnvio", index: "anularEnvio", width: (1.4*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "";
						if (!(rowData.codEstadoRend == "10" || rowData.indicadorSegNotif == "1")) {
							var htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkAnularEnvio('" + rowData.codPlanViaje + "');\">" + rowData.anularEnvio + "</a>";
						}
						return htmlElement;
					}
				},
				{name: "reprogramarFechaRendicion", index: "reprogramarFechaRendicion", width: (1.4*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						//PLAN_VIAJE_WEB_REN	Pendiente	01	Pendiente de rendición
						//PLAN_VIAJE_WEB_REN	Observado por Caja chica	03	Observado por Caja chica
						//PLAN_VIAJE_WEB_REN	Observado 	04	Observado por Financiera

						var htmlElement = "";
						if ((rowData.codEstadoRend == "01" || rowData.codEstadoRend == "03" || rowData.codEstadoRend == "04") && rowData.indicadorSegNotif != "1") {
							htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkReprogramarFechaRendicion('" + rowData.codPlanViaje + "');\">" + rowData.reprogramarFechaRendicion + "</a>";
						}
						return htmlElement;
					}
				},
				{name: "verAdjuntosPlanilla", index: "verAdjuntosPlanilla", width: (0.6*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkConsultarAdjuntosRendicion('" + rowData.codPlanViaje + "');\">" + rowData.verAdjuntosPlanilla + "</a>";
						return htmlElement;
					}
				}
			],
			caption: "Planillas",
			pager: "#divPlanillaPagerTable",
			loadui: "disable"
		});
		planillaTable.clearGridData();
		addEventElementBySelector("#divPlanillaTable .ui-pg-button.ui-corner-all", "click", clickPagerPlanillaTable);
		addEventElementBySelector("#divPlanillaTable input.ui-pg-input", "keypress", keypressPagerPlanillaTable);
		addEventElementBySelector("#divPlanillaTable select.ui-pg-selbox", "change", changePagerPlanillaTable);
	}
}

function clickBtnBuscarUUOORendicion() {
	initElementsBuscarUUOO("divPlanillaTable");
	showModalElement("divBuscarUUOO");
    triggerResizeEvent();
}

function clickBtnBuscarColaboradorRendicion() {
	initElementsBuscarColaborador("divPlanillaTable");
	showModalElement("divBuscarColaborador");
	triggerResizeEvent();
}

function changeSelEstadoRendicion() {
	clearPlanillaTableRendicionBandeja();
}

function changeSelAnioRendicion() {
	var anioSeleccionado = getValueInputText("selAnioRendicion");
	hideElement("divErrorFechaInicioRendicion");
	hideElement("divErrorFechaFinalRendicion");
	hideElement("divErrorRendicion");
	modificarRangoFechaRendicionBandeja(anioSeleccionado);
	clearPlanillaTableRendicionBandeja();
}

function changeSelCanalAtencionRendicion() {
	clearPlanillaTableRendicionBandeja();
}

function changeEtiquetaFechaInicioRendicion() {
	if (isBrowserInternetExplorer()) {
		if (trimText(getValueInputText("etiquetaFechaInicioRendicion")) != "" && isValidoFormatDate(getValueInputText("etiquetaFechaInicioRendicion"))) {
			if (isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaInicioRendicion")), getValueInputText("hidFechaMaximaAnioActual"))) {
				setValueInputText("etiquetaFechaInicioRendicion", "");
			}
		}
		else {
			setValueInputText("etiquetaFechaInicioRendicion", "");
		}
		changeDateEtiquetaFechaInicioRendicionDiv();
	}
}

function changeEtiquetaFechaFinRendicion() {
	if (isBrowserInternetExplorer()) {
		if (trimText(getValueInputText("etiquetaFechaFinRendicion")) != "" && isValidoFormatDate(getValueInputText("etiquetaFechaFinRendicion"))) {
			if (isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaFinRendicion")), getValueInputText("hidFechaMaximaAnioActual"))) {
				setValueInputText("etiquetaFechaFinRendicion", "");
			}
		}
		else {
			setValueInputText("etiquetaFechaFinRendicion", "");
		}
		changeDateEtiquetaFechaFinRendicionDiv();
	}
}

function changeDateEtiquetaFechaInicioRendicionDiv() {
	clearPlanillaTableRendicionBandeja();
	validarFechaInicioRevisarRendicionBandeja();
}

function changeDateEtiquetaFechaFinRendicionDiv() {
	clearPlanillaTableRendicionBandeja();
	validarFechaFinalRevisarRendicionBandeja();
}

function clickBtnConsultarRendicion() {
	
	var flagValidacionFormulario = true;
	var flagFechaValida = true;
	var errorMessage = "";
	hideElement("divErrorRendicion");
	disabledElement("btnConsultarRendicion");
	clearPlanillaTableRendicionBandeja();
	
	if (flagValidacionFormulario && trimText(getValueInputText("hidCodigoColaborador")).length == 0 && trimText(getValueInputText("hidCodigoDependencia")).length == 0) {
		flagValidacionFormulario = false;
		errorMessage = errorMessageRevisarRendicionBandeja.numeroRegistroUUOOInvalido;
	}
	
	if (flagValidacionFormulario && trimText(getValueInputText("txtNroRegistro")).length != 0 && trimText(getValueInputText("hidCodigoColaborador")).length == 0 && trimText(getValueInputText("hidCodigoDependencia")).length != 0) {
		flagValidacionFormulario = false;
		errorMessage = errorMessageRevisarRendicionBandeja.numeroRegistroInvalido;
	}
	
	if (flagValidacionFormulario && trimText(getValueInputText("etiquetaFechaInicioRendicion")) == "") {
		flagValidacionFormulario = false;
		errorMessage = errorMessageRevisarRendicionBandeja.fechaInicioInvalida;
	}
	
	if (flagValidacionFormulario && trimText(getValueInputText("etiquetaFechaFinRendicion")) == "") {
		flagValidacionFormulario = false;
		errorMessage = errorMessageRevisarRendicionBandeja.fechaFinalInvalida;
	}
	
	/*
	if (flagValidacionFormulario && (getValueInputText("hidFlagFechaInicioValida") == "0" || getValueInputText("hidFlagFechaFinalValida") == "0")) {
		flagValidacionFormulario = false;
		errorMessage = errorMessageRevisarRendicionBandeja.rangoFechaInvalido;
	}
	*/
	
	if (flagValidacionFormulario && getValueInputText("hidFlagFechaInicioValida") == "0") {
		flagValidacionFormulario = false;
		flagFechaValida = false;
		validarFechaInicioRevisarRendicionBandeja();
	}
	
	if (flagValidacionFormulario && getValueInputText("hidFlagFechaFinalValida") == "0") {
		flagValidacionFormulario = false;
		flagFechaValida = false;
		validarFechaFinalRevisarRendicionBandeja();
	}
	
	if (flagValidacionFormulario) {
		callBuscarPlanillasBandeja();
	}
	else {
		if (flagFechaValida) {
			showMessageErrorRevisarRendicionBandeja(errorMessage);
		}
		enabledElement("btnConsultarRendicion");
	}
}

function clickBtnExportarExcelRendicion() {
	var encodeParam = "&codigoDependencia=" + getUpperCaseValueInputText("hidCodigoDependencia");
	encodeParam += "&codPlanilla=" + getUpperCaseValueInputText("txtCodigoPlanilla");
	encodeParam += "&codTrabajador=" + getUpperCaseValueInputText("hidCodigoColaborador");
	encodeParam += "&codEstadoRend=" + getUpperCaseValueInputText("selEstadoRendicion");
	encodeParam += "&indicadorCanalAtencion=" + trimText(getValueInputText("selCanalAtencionRendicion"));
	encodeParam += "&fechaDesde=" + getUpperCaseValueInputText("etiquetaFechaInicioRendicion");
	encodeParam += "&fechaHasta=" + getUpperCaseValueInputText("etiquetaFechaFinRendicion");
	encodeParam += "&codigoPaginaCaller=" + getUpperCaseValueInputText("hidCodigoPaginaCaller");
	location.href = contextPathUrl + "/rendicion.htm?action=exportarExcelBandejaRendicion" + encodeParam;
}

function clickBtnAceptarMensajeConfirmacionRevisarRendicionBandeja() {
	hideModalElement("divMensajeConfirmacionRevisarRendicionBandeja");
}

function clickBtnAceptarMensajeConfirmacionErrorRevisarRendicionBandeja() {
	hideModalElement("divMensajeConfirmacionErrorRevisarRendicionBandeja");
}

function clickBtnSiAnularEnvioRevisar() {
	disabledElement("btnSiAnularEnvioRevisar");
	hideModalElement("divMensajeConfirmacionAnularEnvioRevisar");
	callAnularEnvioPlanViaje(getValueInputText("hidCodPlanViajeAnularEnvioRevisar"));
}

function clickBtnNoAnularEnvioRevisar() {
	hideModalElement("divMensajeConfirmacionAnularEnvioRevisar");
}

function clickBtnAceptarAnulacionExitosaRevisar() {
	$("#btnConsultarRendicion").trigger("click");
	hideModalElement("divMensajeConfirmacionAnulacionExitosaRevisar");
}

function clickPagerPlanillaTable() {
	showTooltip();
}

function keypressPagerPlanillaTable(event) {
	var keyCode = window.event ? event.keyCode : event.which;
	if (keyCode == 13) {
		showTooltip();
	}
}

function changePagerPlanillaTable() {
	showTooltip();
}

function clickLinkConsultarRendicionDetalle(codPlanViaje) {
	var planillaTable = $("#tblPlanilla");
	var rowData = planillaTable.getRowData(codPlanViaje);
	var tipoDestino = $.trim( rowData.tipoDestino );
	var indicadorHoras = $.trim( rowData.indicadorHoras );
	initElementsConsultarRendicionDetalle("divPlanillaTable", codPlanViaje,tipoDestino,indicadorHoras);
	showModalElement("divConsultarRendicionDetalle");
	triggerResizeEvent();
}

function clickLinkConsultarSeguimientoRendicion(codPlanViaje) {
	
	var planillaTable = $("#tblPlanilla");
	var rowData = planillaTable.getRowData(codPlanViaje);
	var dataParametrosConsultarSeguimiento = new Object();
	dataParametrosConsultarSeguimiento.codPlanViaje = codPlanViaje;
	dataParametrosConsultarSeguimiento.numeroExpediente = rowData.expedienteRendicion;
	dataParametrosConsultarSeguimiento.idElementCallModal = "divPlanillaTable";
	dataParametrosConsultarSeguimiento.codigoPaginaCaller = "01";
	initElementsConsultarSeguimiento(dataParametrosConsultarSeguimiento);
	showModalElement("divConsultarSeguimiento");
	triggerResizeEvent();
	triggerResizeEventSlow();
}

function clickLinkAnularEnvio(codPlanViaje) {
	
	/*
	Si el estado es diferente a “ENVIADO A CAJA CHICA” o “ENVIADO A FINANCIERA” “OBSERVADO POR CAJA CHICA”, “OBSERVADO POR FINANCIERA”, mostrara el siguiente mensaje:
	“No puede anular el envió porque la planilla aun no ha sido derivado al canal de atención correspondiente”

	Si el estado de la Rendición <>(”PENDIENTE”,  “OBSERVADO POR CAJA CHICA”, “OBSERVADO POR FINANCIERA) el sistema mostrara:
¿	Está seguro de anular el envió de la planilla <NRO_PLANILLA> al <CANAL>? con las alternativas Si/No
	 */
	
	//estados antiguos
	//('PLAN_VIAJE_WEB_REN', 'Pendiente','01','Pendiente de rendición' );
	//('PLAN_VIAJE_WEB_REN', 'Cerrado','02','Cerrado' );
	//('PLAN_VIAJE_WEB_REN', 'Observado por Caja chica','03','Observado por Caja chica' );
	//('PLAN_VIAJE_WEB_REN', 'Observado por Financiera','04','Observado por Financiera' );
	//('PLAN_VIAJE_WEB_REN', 'En revisión','05','En revisión' );
	//('PLAN_VIAJE_WEB_REN', 'Rendido','10','Rendido' );
	
	//estados ahora
	//PLAN_VIAJE_WEB_REN	Pendiente	01: Pendiente de rendición
	//PLAN_VIAJE_WEB_REN	Enviado a Caja Chica	02: Enviado a Caja Chica
	//PLAN_VIAJE_WEB_REN	Observado por Caja chica	03: Observado por Caja chica
	//PLAN_VIAJE_WEB_REN	Observado 	04: Observado por Financiera
	//PLAN_VIAJE_WEB_REN	Enviado a Financiera	05: Enviado a Financiera
	//PLAN_VIAJE_WEB_REN	Enviado a OSA	06: Enviado a OSA
	//PLAN_VIAJE_WEB_REN	Rendido	10	: Rendido
	
	//JMCR-ME ANULACION RENDICION
	
	/*var planillaTable = $("#tblPlanilla");
	var rowData = planillaTable.getRowData(codPlanViaje);
	var codEstadoRend = rowData.codEstadoRend;
	if (codEstadoRend == "02") {//antes si estaba "cerrado" permitia eliminar
		var indicadorCanalAtencion = rowData.indicadorCanalAtencion;
		var messageTitulo = "";
		if (indicadorCanalAtencion == "C") {
			messageTitulo = propertyMessageRevisarRendicionBandeja.tituloCajaChica; 
		}
		else if (indicadorCanalAtencion == "R") {
			messageTitulo = propertyMessageRevisarRendicionBandeja.tituloDCP;
		}
		setValueInputText("hidCodPlanViajeAnularEnvioRevisar", codPlanViaje);
		setHtmlElement("divTituloPanelAnularEnvioRevisar", messageTitulo);
		enabledElement("btnSiAnularEnvioRevisar");
		showModalElement("divMensajeConfirmacionAnularEnvioRevisar");
	}
	else {
		showMensajeConfirmacionErrorRevisarRendicionBandeja(errorMessageRevisarRendicionBandeja.estadoDiferenteCerrado);
	}*/

	var planillaTable = $("#tblPlanilla");
	var rowData = planillaTable.getRowData(codPlanViaje);
	var codEstadoRend = rowData.codEstadoRend;
	if (codEstadoRend == "02" || codEstadoRend == "05" || codEstadoRend == "06") {//antes si estaba "cerrado" permitia eliminar
		var indicadorCanalAtencion = rowData.indicadorCanalAtencion;
		var messageTitulo = "";
		if (indicadorCanalAtencion == "C") {
			messageTitulo = propertyMessageRevisarRendicionBandeja.tituloGeneral + " " + rowData.codPlanilla + " a " + propertyMessageRevisarRendicionBandeja.enviadoCajaChica + "?"; 
		}
		else if (indicadorCanalAtencion == "R") {//osa tambien cuenta como abono en cuenta
			if (codEstadoRend == "05") {
				messageTitulo = propertyMessageRevisarRendicionBandeja.tituloGeneral +  " " + rowData.codPlanilla + " a " + propertyMessageRevisarRendicionBandeja.enviadoPresupuesto + "?";				
			}
			else if (codEstadoRend == "06") {
				messageTitulo = propertyMessageRevisarRendicionBandeja.tituloGeneral +  " " + rowData.codPlanilla + " a " + propertyMessageRevisarRendicionBandeja.enviadoOsa + "?";				
			}
		}
		setValueInputText("hidCodPlanViajeAnularEnvioRevisar", codPlanViaje);
		setHtmlElement("divTituloPanelAnularEnvioRevisar", messageTitulo);
		enabledElement("btnSiAnularEnvioRevisar");
		showModalElement("divMensajeConfirmacionAnularEnvioRevisar");
	}
	else {
		showMensajeConfirmacionErrorRevisarRendicionBandeja(errorMessageRevisarRendicionBandeja.estadoDiferenteEnviado);
	}
	
	//JMCR-ME ANULACION RENDICION
}

function clickLinkReprogramarFechaRendicion(codPlanViaje) {
	
	var planillaTable = $("#tblPlanilla");
	var rowData = planillaTable.getRowData(codPlanViaje);
	var dataParametrosReprogramar = new Object();
	dataParametrosReprogramar.codPlanViaje = codPlanViaje;
	dataParametrosReprogramar.codPlanilla = rowData.codPlanilla;
	dataParametrosReprogramar.tipoDestino = rowData.tipoDestino;
	dataParametrosReprogramar.nomEstRend = rowData.nomEstRend;
	dataParametrosReprogramar.numeroRegistroAlterno = rowData.numeroRegistroAlterno;
	dataParametrosReprogramar.nomColaborador = rowData.nomColaborador;
	dataParametrosReprogramar.fecSalida = rowData.fecSalida;
	dataParametrosReprogramar.fecRetorno = rowData.fecRetorno;
	dataParametrosReprogramar.horaSalida = rowData.horaSalida;
	dataParametrosReprogramar.horaRetorno = rowData.horaRetorno;
	dataParametrosReprogramar.fecMaxRend = rowData.fecMaxRend;
	//JMCR-ME Fecha Reprogramacion
	dataParametrosReprogramar.fecReprog = rowData.fecReprog;
	//JMCR-ME Fecha Reprogramacion
	dataParametrosReprogramar.indicadorHoras = rowData.indicadorHoras;
	dataParametrosReprogramar.numDias = rowData.numDias;
	dataParametrosReprogramar.numeroHoras = rowData.numeroHoras;
	dataParametrosReprogramar.poaProgramado = rowData.poaProgramado;
	dataParametrosReprogramar.motivoComis = rowData.motivoComis;
	
	initElementsReprogramarFechaRendicion(dataParametrosReprogramar);
	showModalElement("divReprogramarFechaRendicion");
}

function clickLinkConsultarAdjuntosRendicion(codPlanViaje) {
	
	var planillaTable = $("#tblPlanilla");
	var rowData = planillaTable.getRowData(codPlanViaje);
	var codPlanilla = $.trim( rowData.codPlanilla );
	
	var dataParametrosArchivo = new Object();
	dataParametrosArchivo.planViajeId = codPlanViaje;
	dataParametrosArchivo.codPlanilla = codPlanilla;
    dataParametrosArchivo.codigoBoleto = "";
    dataParametrosArchivo.estadoOrigen = "V";
    dataParametrosArchivo.estadoLLamada = "C";
    dataParametrosArchivo.numeroRegistroColaborador = rowData.numeroRegistroAlterno;
    dataParametrosArchivo.paginaOrigen = "PRINCIPAL";
    
    existenArchivosAdjuntos(dataParametrosArchivo, function(){
		
		initElementsConsultarRegistrarEliminarArchivo(dataParametrosArchivo);
		$("#divAdjuntarDocumento").modal("show");
		triggerResizeEvent();

		setTimeout(function() {
			resizeTable( "tblArchivo" );
		}, 700);		
		
	});
	
}

function modificarRangoFechaRendicionBandeja(anioSeleccionado) {
	
	setValueInputText("hidFechaInicialRangoFecha", "01/01/" + anioSeleccionado);
	setValueInputText("hidFechaFinalRangoFecha", "31/12/" + anioSeleccionado);
	setValueInputText("etiquetaFechaInicioRendicion", getValueInputText("hidFechaInicialRangoFecha"));
	setValueInputText("etiquetaFechaFinRendicion", getValueInputText("hidFechaFinalRangoFecha"));
	setValueInputText("hidFlagFechaInicioValida", "1");
	setValueInputText("hidFlagFechaFinalValida", "1");
}

function validarFechaInicioRevisarRendicionBandeja() {
	
	var flagFechaValida = true;
	var errorMessage = "";
	hideElement("divErrorRendicion");
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("hidFechaInicialRangoFecha")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaInicioRendicion")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRevisarRendicionBandeja.fechaInicioInvalida;
	}
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaInicioRendicion")), formatEspDateToEngFormatDate(getValueInputText("hidFechaFinalRangoFecha")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRevisarRendicionBandeja.fechaInicioInvalida;
	}
	
	if (!flagFechaValida) {
		setValueInputText("hidFlagFechaInicioValida", "0");
		showMessageErrorRevisarRendicionBandeja(errorMessage);
	}
	else {
		if (trimText(getValueInputText("etiquetaFechaInicioRendicion")) != "") {
			setValueInputText("hidFlagFechaInicioValida", "1");
			if (trimText(getValueInputText("etiquetaFechaFinRendicion")) != "") {
				validarFechaFinalRevisarRendicionBandeja();
			}
		}
		else {
			setValueInputText("hidFlagFechaInicioValida", "0");
		}
	}
}

function validarFechaFinalRevisarRendicionBandeja() {
	
	var flagFechaValida = true;
	var errorMessage = "";
	hideElement("divErrorRendicion");
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("hidFechaInicialRangoFecha")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaFinRendicion")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRevisarRendicionBandeja.fechaFinalInvalida;
	}
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaFinRendicion")), formatEspDateToEngFormatDate(getValueInputText("hidFechaFinalRangoFecha")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRevisarRendicionBandeja.fechaFinalInvalida;
	}
	
	if (!flagFechaValida) {
		setValueInputText("hidFlagFechaFinalValida", "0");
		showMessageErrorRevisarRendicionBandeja(errorMessage);
	}
	else {
		if (trimText(getValueInputText("etiquetaFechaFinRendicion")) != "") {
			setValueInputText("hidFlagFechaFinalValida", "1");
			if (trimText(getValueInputText("etiquetaFechaInicioRendicion")) != "") {
				validarFechaFinalMayorIgualFechaInicioRevisarRendicionBandeja();
			}
		}
		else {
			setValueInputText("hidFlagFechaFinalValida", "0");
		}
	}
}

function validarFechaFinalMayorIgualFechaInicioRevisarRendicionBandeja() {
	
	var flagFechaValida = true;
	var errorMessage = "";
	hideElement("divErrorRendicion");
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaInicioRendicion")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaFinRendicion")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRevisarRendicionBandeja.fechaFinalMenorFechaInicial;
	}
	
	if (!flagFechaValida) {
		setValueInputText("hidFlagFechaFinalValida", "0");
		showMessageErrorRevisarRendicionBandeja(errorMessage);
	}
	else {
		setValueInputText("hidFlagFechaFinalValida", "1");
	}
}

function callBuscarPlanillasBandeja() {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/rendicion.htm?action=buscarPlanillasBandeja",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codigoDependencia": getUpperCaseValueInputText("hidCodigoDependencia"),
				"codPlanilla": getUpperCaseValueInputText("txtCodigoPlanilla"),
				"codTrabajador": getUpperCaseValueInputText("hidCodigoColaborador"),
				"codEstadoRend": getValueInputText("selEstadoRendicion"),
				"indicadorCanalAtencion": trimText(getValueInputText("selCanalAtencionRendicion")),
				"fechaDesde": getValueInputText("etiquetaFechaInicioRendicion"),
				"fechaHasta": getValueInputText("etiquetaFechaFinRendicion")
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showElement("divLoadingRendicion");
			},
			complete: function() {
				enabledElement("btnConsultarRendicion");
				hideElement("divLoadingRendicion");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var codigoConsulta = result.codigoConsulta;
				var errorMessage = result.errorMessage;
				if (codigoConsulta != null && codigoConsulta == "00") {
					var planillaList = result.planViajeList;
					showPlanillasRevisarRendicionBandeja(planillaList);
				}
				else if (codigoConsulta == "02") {
					showMessageErrorRevisarRendicionBandeja(errorMessage);
				}
				else {
					showMensajeConfirmacionErrorRevisarRendicionBandeja(errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callBuscarPlanillasBandeja");
			}
		});
	}, 500);
}

function callAnularEnvioPlanViaje(codPlanViaje) {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/revisarRendicion.htm?action=anularEnvioPlanViaje",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codPlanViaje": codPlanViaje
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showModalElement("divMensajeConfirmacionLoadingRevisarRendicionBandeja");
			},
			complete: function() {
				hideModalElement("divMensajeConfirmacionLoadingRevisarRendicionBandeja");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var codigoOperacion = result.codigoOperacion;
				var errorMessage = result.errorMessage;
				var successMessage = result.successMessage;
				if (codigoOperacion != null && codigoOperacion == "00") {
					showModalElement("divMensajeConfirmacionAnulacionExitosaRevisar");
				}
				else {
					showMensajeConfirmacionErrorRevisarRendicionBandeja(errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callAnularEnvioPlanViaje");
			}
		});
	}, 500);
}

function showMessageErrorFechaInicioRevisarRendicionBandeja(errorMessage) {
	setHtmlElement("etiquetaErrorFechaInicioRendicion", errorMessage);
	showElement("divErrorFechaInicioRendicion");
}

function showMessageErrorFechaFinalRevisarRendicionBandeja(errorMessage) {
	setHtmlElement("etiquetaErrorFechaFinalRendicion", errorMessage);
	showElement("divErrorFechaFinalRendicion");
}

function showMessageErrorRevisarRendicionBandeja(errorMessage) {
	setHtmlElement("etiquetaErrorRendicion", errorMessage);
	showElement("divErrorRendicion");
}

function showMensajeConfirmacionRevisarRendicionBandeja(messageTitulo) {
	hideElement("divBodyPanelMensajeConfirmacionRevisarRendicionBandeja");
	setHtmlElement("divTituloPanelMensajeConfirmacionRevisarRendicionBandeja", messageTitulo);
	showModalElement("divMensajeConfirmacionRevisarRendicionBandeja");
}

function showMensajeConfirmacionErrorRevisarRendicionBandeja(messageTitulo) {
	hideElement("divBodyPanelMensajeConfirmacionErrorRevisarRendicionBandeja");
	setHtmlElement("divTituloPanelMensajeConfirmacionErrorRevisarRendicionBandeja", messageTitulo);
	showModalElement("divMensajeConfirmacionErrorRevisarRendicionBandeja");
}

function showPlanillasRevisarRendicionBandeja(planillaArray) {
	
	if (planillaArray != null && planillaArray.length > 0) {
		var planillaTable = $("#tblPlanilla");
		planillaTable.clearGridData();
		for (var i = 0; i < planillaArray.length; i++) {
			var planilla = planillaArray[i];
			var datarow = {
				codPlanViaje: planilla.codPlanViaje,
				codPlanilla: planilla.codPlanilla,
				codPlanillaLink: planilla.codPlanilla,
				fechaRegistro: planilla.fechaRegistro,
				fechaRegistroRendicion: planilla.fechaRegistroRendicionFormateda,
				numeroRegistroAlterno: planilla.numeroRegistroAlterno,
				nomColaborador: planilla.nomColaborador,
				tipoDestino: planilla.tipoDestino,
				nomTipoViatico: planilla.nomTipoViatico,
				mtoTotal: planilla.mtoTotal,
				mtoTotalFormateado: planilla.mtoTotalFormateado,
				fecMaxRend: planilla.fecMaxRendFormateada,
				//JMCR-ME Fecha Reprogramacion
				fecReprog: planilla.fecReprogFormateada,
				//JMCR-ME Fecha Reprogramacion
				cantDiasRend: planilla.cantDiasRend,
				codEstadoRend: planilla.codEstadoRend,
				nomEstRend: planilla.nomEstRend,
				obsRendicion: planilla.obsRendicion,
				indicadorCanalAtencion: planilla.indicadorCanalAtencion,
				motivoComis: planilla.motivoComis,
				fecSalida: planilla.fecSalidaFormateada,
				fecRetorno: planilla.fecRetornoFormateada,
				horaSalida: planilla.horaSalidaFormateada,
				horaRetorno: planilla.horaRetornoFormateada,
				indicadorHoras: planilla.indicadorHoras,
				numDias: planilla.numDias,
				numeroHoras: planilla.numeroHoras,
				poaProgramado: planilla.poaProgramado,
				indicadorSegNotif: planilla.indicadorSegNotif,
				expedientePlanViaje: planilla.expedientePlanViaje,
				expedienteRendicion: planilla.expedienteRendicion,
				numeroRegistroArchivo: planilla.numeroRegistroArchivo,
				detalleRendicion: "DETALLE",
				seguimientoPlanilla: "SEGUIMIENTO",
				anularEnvio: "ANULAR ENVÍO",
				reprogramarFechaRendicion: "REPROGRAMAR",
				verAdjuntosPlanilla: "VER"
			};
			planillaTable.jqGrid("addRowData", datarow.codPlanViaje, datarow);
		}
		planillaTable.trigger("reloadGrid");
		enabledElement("btnExportarExcelRendicion");
		showTooltip();
	}
	else {
		setHtmlElement("divPlanillaPagerTable_left", errorMessageRevisarRendicionBandeja.sinRegistrosBusqueda);
	}
}

function clearPlanillaTableRendicionBandeja() {
	
	var planillaTable = $("#tblPlanilla");
	planillaTable.clearGridData();
	disabledElement("btnExportarExcelRendicion");
	setHtmlElement("divPlanillaPagerTable_left", "");
}

/*Inicio Codigo - Reutilizacion buscarUUOO*/
var dataParametrosBuscarUUOO = new Object();
dataParametrosBuscarUUOO.idCodigoRegistrador = "hidCodigoRegistrador";
dataParametrosBuscarUUOO.idCodigoTipoUUOOViatico = getValueInputText("hidFlagBuscarUUOO");
dataParametrosBuscarUUOO.idDivScreenBlock = "divScreenBlock";

var buscarUUOOBeforeMethod = function() {
};

var buscarUUOOAfterMethod = function(rowData) {
	
	setValueInputText("txtNroRegistro", "");
	setValueInputText("hidTxtNroRegistro", "");
	setValueInputText("txtNombreColaborador", "");
	setValueInputText("hidCodigoColaborador", "");
	setValueInputText("hidCodigoEstadoColaborador", "");
	setValueInputText("txtUUOO", rowData["uuoo"]);
	setValueInputText("hidTxtUUOO", rowData["uuoo"]);
    setValueInputText("txtDescripcionDependencia", rowData["descripcionUUOO"]);
    setValueInputText("hidCodigoDependencia", rowData["codigoDependencia"]);
    hideElement("divErrorRendicion");
	clearPlanillaTableRendicionBandeja();
};

var buscarUUOOService = new BuscarUUOOService(dataParametrosBuscarUUOO, buscarUUOOBeforeMethod, buscarUUOOAfterMethod);
/*Fin Codigo - Reutilizacion buscarUUOO*/

/*Inicio Codigo - Reutilizacion buscarUUOOInput*/
function buscarUUOOInputBeforeMethod() {
	
	setValueInputText("txtNroRegistro", "");
	setValueInputText("hidTxtNroRegistro", "");
	setValueInputText("hidCodigoColaborador", "");
	setValueInputText("txtNombreColaborador", "");
	setValueInputText("hidCodigoEstadoColaborador", "");
	setValueInputText("hidTxtUUOO", "");
	setValueInputText("txtDescripcionDependencia", "");
	setValueInputText("hidCodigoDependencia", "");
	clearPlanillaTableRendicionBandeja();
}

function buscarUUOOInputAfterMethod(uuooList) {
	
	if (uuooList != null && uuooList.length > 0) {
		for (var i = 0; i < uuooList.length; i++) {
			var uuoo = uuooList[i];
			var datarow = {
				codigoDependencia: uuoo.cod_dep,
				uuoo: uuoo.uuoo,
				uuooDetalle: uuoo.nom_largo
			};
			setValueInputText("txtUUOO", datarow.uuoo);
			setValueInputText("hidTxtUUOO", datarow.uuoo);
			setValueInputText("hidCodigoDependencia", datarow.codigoDependencia);
			setValueInputText("txtDescripcionDependencia", datarow.uuooDetalle);
			break;
		}
	}
	else {         
		setHtmlElement("etiquetaErrorRendicion", errorMessageBuscarUUOOInput.sinRegistrosBusqueda);
		showElement("divErrorRendicion");
	}
}

var buscarUUOOInputService = new BuscarUUOOInputService();

function initElementsBuscarUUOOInputService(errorMessageBuscarUUOOInput) {
	
	var dataParametros = new Object();
	dataParametros.idNumeroUUOO = "txtUUOO";
	dataParametros.idCodigoRegistrador = "hidCodigoRegistrador";
	dataParametros.idCodigoTipoUUOOViatico = getValueInputText("hidFlagBuscarUUOO");
	dataParametros.idDivLoading = "divLoadingBuscarInput";
	dataParametros.idDivError = "divErrorRendicion";
	dataParametros.idEtiquetaError = "etiquetaErrorRendicion";
	dataParametros.idDivScreenBlock = "divScreenBlock";
	dataParametros.errorMessage = errorMessageBuscarUUOOInput;
	buscarUUOOInputService = new BuscarUUOOInputService(dataParametros, buscarUUOOInputBeforeMethod, buscarUUOOInputAfterMethod);
}
/*Fin Codigo - Reutilizacion buscarUUOOInput*/

/*Inicio Codigo - Reutilizacion buscarColaborador*/
var dataParametrosBuscarColaborador = new Object();
dataParametrosBuscarColaborador.idCodigoRegistrador = "hidCodigoRegistrador";
dataParametrosBuscarColaborador.idNumeroRegistroRegistrador = "hidNumeroRegistroRegistrador";
dataParametrosBuscarColaborador.idCodigoTipoUsuarioViatico = getValueInputText("hidFlagBuscarColaborador");
dataParametrosBuscarColaborador.idDivScreenBlock = "divScreenBlock";

var buscarColaboradorBeforeMethod = function() {
};

var buscarColaboradorAfterMethod = function(rowData) {
	
	setValueInputText("txtNroRegistro", rowData["numeroRegistro"]);
	setValueInputText("hidTxtNroRegistro", rowData["numeroRegistro"]);
	setValueInputText("hidCodigoColaborador", rowData["codigoEmpleado"]);
	setValueInputText("txtNombreColaborador", rowData["nombreCompleto"]);
	setValueInputText("hidCodigoEstadoColaborador", rowData["codigoEstado"]);
	setValueInputText("txtUUOO", rowData["uuoo"]);
	setValueInputText("hidTxtUUOO", rowData["uuoo"]);
	setValueInputText("txtDescripcionDependencia", rowData["uuooDetalle"]);
	setValueInputText("hidCodigoDependencia", rowData["codigoDependencia"]);
	hideElement("divErrorRendicion");
	clearPlanillaTableRendicionBandeja();
};

var buscarColaboradorService = new BuscarColaboradorService(dataParametrosBuscarColaborador, buscarColaboradorBeforeMethod, buscarColaboradorAfterMethod);
/*Fin Codigo - Reutilizacion buscarColaborador*/

/*Inicio Codigo - Reutilizacion buscarColaboradorInput*/
var buscarColaboradorInputBeforeMethod = function() {
	
	setValueInputText("hidTxtNroRegistro", "");
	setValueInputText("hidCodigoColaborador", "");
	setValueInputText("txtNombreColaborador", "");
	setValueInputText("hidCodigoEstadoColaborador", "");
	/*
	setValueInputText("txtUUOO", "");
	setValueInputText("txtDescripcionDependencia", "");
	setValueInputText("hidCodigoDependencia", "");
	*/
	clearPlanillaTableRendicionBandeja();
};

var buscarColaboradorInputAfterMethod = function(colaboradorList) {
	
	if (colaboradorList != null && colaboradorList.length > 0) {
		for (var i = 0; i < colaboradorList.length; i++) {
			var colaborador = colaboradorList[i];
			var datarow = {
				numeroRegistro: colaborador.numero_registro,
				nombreCompleto: colaborador.nombre_completo,
				uuoo: colaborador.uuoo,
				codigoDependencia: colaborador.codigoDependencia,
				uuooDetalle: colaborador.dependencia,
				codigoEmpleado: colaborador.codigoEmpleado,
				codigoEstado: colaborador.codigoEstado,
				estadoDetalle: colaborador.estado
			};
			setValueInputText("hidTxtNroRegistro", datarow.numeroRegistro);
			setValueInputText("hidCodigoColaborador", datarow.codigoEmpleado);
			setValueInputText("txtNombreColaborador", datarow.nombreCompleto);
			setValueInputText("hidCodigoEstadoColaborador", datarow.codigoEstado);
			setValueInputText("txtUUOO", datarow.uuoo);
			setValueInputText("hidTxtUUOO", datarow.uuoo);
			setValueInputText("txtDescripcionDependencia", datarow.uuooDetalle);
			setValueInputText("hidCodigoDependencia", datarow.codigoDependencia);
			break;
		}
	}
	else {
		setHtmlElement("etiquetaErrorRendicion", errorMessageBuscarColaboradorInput.sinRegistrosBusqueda);
		showElement("divErrorRendicion");
	}
};

var buscarColaboradorInputService = new BuscarColaboradorInputService();

function initElementsBuscarColaboradorInputService(errorMessageBuscarColaboradorInput) {
	
	var dataParametros = new Object();
	dataParametros.idNumeroRegistroColaborador = "txtNroRegistro";
	dataParametros.idCodigoRegistrador = "hidCodigoRegistrador";
	dataParametros.idNumeroRegistroRegistrador = "hidNumeroRegistroRegistrador";
	dataParametros.idCodigoTipoUsuarioViatico = getValueInputText("hidFlagBuscarColaborador");
	dataParametros.estadoLlamada = "B";
	dataParametros.idDivLoading = "divLoadingBuscarInput";
	dataParametros.idDivError = "divErrorRendicion";
	dataParametros.idEtiquetaError = "etiquetaErrorRendicion";
	dataParametros.idDivScreenBlock = "divScreenBlock";
	dataParametros.errorMessage = errorMessageBuscarColaboradorInput;
	buscarColaboradorInputService = new BuscarColaboradorInputService(dataParametros, buscarColaboradorInputBeforeMethod, buscarColaboradorInputAfterMethod);
}
/*Fin Codigo - Reutilizacion buscarColaboradorInput*/

/*Inicio Codigo - Reutilizacion adjuntarDocumento*/
var adjuntarDocumentoBeforeMethod = function() {
};

var adjuntarDocumentoAfterMethod = function(data) {
};

var adjuntarDocumentoService = new AdjuntarDocumentoService(adjuntarDocumentoBeforeMethod, adjuntarDocumentoAfterMethod);
/*Fin Codigo - Reutilizacion adjuntarDocumento*/

$(window).on("resize", function() {
	resizeTable("tblPlanilla");
	//Inicializando las tablas de los modales
	resizeTable("tblUUOO");
	resizeTable("tblColaborador");
	resizeTable("tblDetalleViatico");
	resizeTable("tblDetalleGasto");
	resizeTable("tblSeguimiento");
	resizeTable("tblArchivo");
});