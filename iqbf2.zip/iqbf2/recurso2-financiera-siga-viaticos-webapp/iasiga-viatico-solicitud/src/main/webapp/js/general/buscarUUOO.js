function initElementsBuscarUUOO(idElementCallModal) {
	setInitElementsBuscarUUOO();
	setInitUUOOTable(idElementCallModal);
}

function setInitElementsBuscarUUOO() {
	setValueInputText("selTipoBusquedaBuscarUUOO", "00");
	setValueInputText("txtDescripcionBusquedaBuscarUUOO", "");
	hideElement("divErrorBuscarUUOO");
	disabledElement("txtDescripcionBusquedaBuscarUUOO");
	disabledElement("btnBuscarRegistroBuscarUUOO");
	disabledElement("btnAceptarBuscarUUOO");
	addEventElement("btnBuscarRegistroBuscarUUOO", "click", clickBtnBuscarRegistroBuscarUUOO);
	addEventElement("btnBuscarTodosRegistroBuscarUUOO", "click", clickBtnBuscarTodosRegistroBuscarUUOO);
	addEventElement("btnAceptarBuscarUUOO", "click", clickBtnAceptarBuscarUUOO);
	addEventElement("btnCancelarBuscarUUOO", "click", clickBtnCancelarBuscarUUOO);
	addEventElement("selTipoBusquedaBuscarUUOO", "change", changeSelTipoBusquedaBuscarUUOO);
	if (buscarUUOOService.idCodigoTipoUUOOViatico == "01" || buscarUUOOService.idCodigoTipoUUOOViatico == "03") {
		hideElement("btnBuscarTodosRegistroBuscarUUOO");
	}
}

function removeEventElementsBuscarUUOO() {
	removeAllEventsElement("btnBuscarRegistroBuscarUUOO");
	removeAllEventsElement("btnBuscarTodosRegistroBuscarUUOO");
	removeAllEventsElement("btnAceptarBuscarUUOO");
	removeAllEventsElement("btnCancelarBuscarUUOO");
	removeAllEventsElement("selTipoBusquedaBuscarUUOO");
}

function removeUUOOTableBuscarUUOO() {
	var htmlElement = "<table id=\"tblUUOO\"></table>";
	htmlElement += "<div id=\"divUUOOPagerTable\" class=\"jqGridMovilidadPagerClass\"></div>";
	setHtmlElement("divUUOOTable", htmlElement);
}

function setInitUUOOTable(idElementCallModal) {
	var uuooTable = $("#tblUUOO");
	if (uuooTable) {
		//Para el DivWitdh se utilizo un componente que llama al modal
		var uuooTableDiv = $("#" + idElementCallModal);
		var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.movilidadModalContainer", ".movilidadModalContainerAuxiliar", "width"))/100);
		var widthTable = factorRedimensionamiento*uuooTableDiv.width();
		uuooTable.jqGrid({
			width: widthTable,
			height: 200,
			datatype: "local",
			rowNum: 10,
			rowList: [10, 20],
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames:[
				"C&oacute;digo UUOO",
				"Descripci&oacute;n",
				"C&oacute;digo Dependencia",
				"Intendencia"
			],
			colModel:[
				{name:"uuoo", index: "uuoo", width: (3*widthTable/12)},
				{name:"descripcionUUOO", index: "descripcionUUOO", width: (6*widthTable/12)},
				{name:"codigoDependencia", index: "codigoDependencia", width: (3*widthTable/12), hidden: true},
				{name:"intendencia", index: "intendencia", width: (3*widthTable/12)}
			],
			pager : "#divUUOOPagerTable",
			loadui: "disable"
		});
	}
	uuooTable.clearGridData();
}

function clickBtnBuscarRegistroBuscarUUOO() {
	
	var flagParametrosValidos = true;
	var errorMessage = "";
	setHtmlElement("divUUOOPagerTable_left", "");
	hideElement("divErrorBuscarUUOO");
	if (flagParametrosValidos && getValueInputText("selTipoBusquedaBuscarUUOO") == "00") {
		errorMessage = errorMessageBuscarUUOO.seleccionarTipoBusqueda;
		flagParametrosValidos = false;
	}
	
	if (flagParametrosValidos && trimText(getValueInputText("txtDescripcionBusquedaBuscarUUOO")) == "") {
		errorMessage = errorMessageBuscarUUOO.completarDescripcion;
		flagParametrosValidos = false;
	}
	
	if (flagParametrosValidos && trimText(getValueInputText("txtDescripcionBusquedaBuscarUUOO")).length < 2) {
		errorMessage = errorMessageBuscarUUOO.cantidadMinimaDescripcion;
		flagParametrosValidos = false;
	}
	
	if (flagParametrosValidos) {
		callObtenerUnidadOrganizacional("0");
	}
	else {
		showMessageErrorBuscarUUOO(errorMessage);
	}
}

function clickBtnBuscarTodosRegistroBuscarUUOO() {
	setValueInputText("selTipoBusquedaBuscarUUOO", "00");
	setValueInputText("txtDescripcionBusquedaBuscarUUOO", "");
	setHtmlElement("divUUOOPagerTable_left", "");
	hideElement("divErrorBuscarUUOO");
	disabledElement("txtDescripcionBusquedaBuscarUUOO");
	disabledElement("btnBuscarRegistroBuscarUUOO");
	disabledElement("btnBuscarTodosRegistroBuscarUUOO");
	callObtenerUnidadOrganizacional("1");
}

function clickBtnAceptarBuscarUUOO() {
	
	var uuooTable = $("#tblUUOO");
	var rowId = uuooTable.jqGrid("getGridParam", "selrow");
	if (rowId == null) {
		setHtmlElement("divUUOOPagerTable_left", errorMessageBuscarUUOO.seleccionarRegistro);
	}
	else {
		var rowData = uuooTable.getRowData(rowId);
		if (typeof buscarUUOOService.buscarUUOOBefore != "undefined") {
			buscarUUOOService.buscarUUOOBefore();
		}
		if (typeof buscarUUOOService.buscarUUOOAfter != "undefined") {
			buscarUUOOService.buscarUUOOAfter(rowData);
		}
		removeEventElementsBuscarUUOO();
		removeUUOOTableBuscarUUOO();
		$("#divBuscarUUOO").modal("hide");
	}
}

function validaCantidadCaracteres(){
	var descripcionBusquedaBuscarUUOO = getValueInputText("txtDescripcionBusquedaBuscarUUOO");
	if(descripcionBusquedaBuscarUUOO.length == 0){
		disabledElement("btnBuscarRegistroBuscarUUOO");
		return false;
	}else{
		enabledElement("btnBuscarRegistroBuscarUUOO");
		return true;
	}
}

function clickBtnCancelarBuscarUUOO() {
	removeEventElementsBuscarUUOO();
	removeUUOOTableBuscarUUOO();
	$("#divBuscarUUOO").modal("hide");
}

function changeSelTipoBusquedaBuscarUUOO() {
	
	var uuooTable = $("#tblUUOO");
	uuooTable.clearGridData();
	setValueInputText("txtDescripcionBusquedaBuscarUUOO", "");
	setHtmlElement("divUUOOPagerTable_left", "");
	hideElement("divErrorBuscarUUOO");
	disabledElement("btnAceptarBuscarUUOO");
	
	if (getValueInputText("selTipoBusquedaBuscarUUOO") == "00") {
		disabledElement("txtDescripcionBusquedaBuscarUUOO");
		//disabledElement("btnBuscarRegistroBuscarUUOO");
		var estadoCantidadCaracteres = validaCantidadCaracteres();
		if(estadoCantidadCaracteres){
			disabledElement("btnBuscarRegistroBuscarUUOO");
		}else{
			disabledElement("btnBuscarRegistroBuscarUUOO");
		}
	}
	else {
		enabledElement("txtDescripcionBusquedaBuscarUUOO");
		//enabledElement("btnBuscarRegistroBuscarUUOO");
		var estadoCantidadCaracteres = validaCantidadCaracteres();
		if(estadoCantidadCaracteres){
			enabledElement("btnBuscarRegistroBuscarUUOO");
		}else{
			disabledElement("btnBuscarRegistroBuscarUUOO");
		}
	}
}

function callObtenerUnidadOrganizacional(indicadorBuscarTodos) {
	
	var uuooTable = $("#tblUUOO");
	uuooTable.clearGridData();
	if (typeof buscarUUOOService != "undefined") {
		$.ajax({
			url: contextPathUrl + "/dependencias.htm?action=buscarUnidadOrganizacional",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codigoTipoBusquedaUUOO": getValueInputText("selTipoBusquedaBuscarUUOO"),
				"descripcionBuscarUUOO": getUpperCaseValueInputText("txtDescripcionBusquedaBuscarUUOO"),
				"codigoRegistrador": getUpperCaseValueInputText(buscarUUOOService.idCodigoRegistrador),
				"flagParametroTodos": indicadorBuscarTodos,
				"codigoTipoUUOOViatico": buscarUUOOService.idCodigoTipoUUOOViatico
			},
			beforeSend: function() {
				if (typeof buscarUUOOService.idDivScreenBlock != "undefined") {
					showModalElement(buscarUUOOService.idDivScreenBlock);
				}
				showElement("divLoadingBuscarUUOO");
			},
			complete: function() {
				hideElement("divLoadingBuscarUUOO");
				enabledElement("btnBuscarTodosRegistroBuscarUUOO");
				if (typeof buscarUUOOService.idDivScreenBlock != "undefined") {
					hideModalElement(buscarUUOOService.idDivScreenBlock);
				}
			},
			success: function(result) {
				var dependenciaList = result.dependenciaList;
				if (dependenciaList != null && dependenciaList.length > 0) {
					for (var i = 0; i < dependenciaList.length; i++) {
						var dependencia = dependenciaList[i];
						var datarow = {
							uuoo: dependencia.uuoo,
							descripcionUUOO: dependencia.nom_largo,
							codigoDependencia: dependencia.cod_dep,
							intendencia : dependencia.intendencia
						};
						uuooTable.jqGrid("addRowData", dependencia.uuoo, datarow);
					}
					uuooTable.trigger("reloadGrid");
					enabledElement("btnAceptarBuscarUUOO");
				}
				else {
					setHtmlElement("divUUOOPagerTable_left", errorMessageBuscarUUOO.sinRegistrosBusqueda);
				}
			},
			error: function() {
				consoleBrowser("Error callObtenerUnidadOrganizacional");
			}
		});
	}
}

function showMessageErrorBuscarUUOO(errorMessage) {
	setHtmlElement("etiquetaErrorBuscarUUOO", errorMessage);
	showElement("divErrorBuscarUUOO");
}