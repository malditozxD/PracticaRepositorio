function initElementsConsultarSeguimiento(dataParametrosConsultarSeguimiento) {
	setInitElementsConsultarSeguimiento(dataParametrosConsultarSeguimiento);
	setInitSeguimientoTable(dataParametrosConsultarSeguimiento.idElementCallModal);
	callConsultarSeguimiento();
}

function setInitElementsConsultarSeguimiento(dataParametrosConsultarSeguimiento) {
	
	if (dataParametrosConsultarSeguimiento.codigoPaginaCaller != "01") {
		setTextLabel("lblNumeroPlanillaConsultarSeguimiento", propertyMessageConsultarSeguimiento.nroSolicitudReembolso)
	}
	setValueInputText("txtNombreColaboradorConsultarSeguimiento", "");
	setValueInputText("txtDescripcionDependenciaConsultarSeguimiento", "");
	setValueInputText("txtNumeroPlanillaConsultarSeguimiento", "");
	setValueInputText("txtImporteConsultarSeguimiento", "");
	setValueInputText("hidCodPlanViajeConsultarSeguimiento", dataParametrosConsultarSeguimiento.codPlanViaje);
	setValueInputText("hidNumeroExpedienteConsultarSeguimiento", dataParametrosConsultarSeguimiento.numeroExpediente);
	setValueInputText("hidCodigoPaginaCallerConsultarSeguimiento", dataParametrosConsultarSeguimiento.codigoPaginaCaller);
	addEventElement("btnCerrarConsultarSeguimiento", "click", clickBtnCerrarConsultarSeguimiento);
}

function removeEventElementsConsultarSeguimiento() {
	removeAllEventsElement("clickBtnCerrarConsultarSeguimiento");
}

function removeSeguimientoTable() {
	
	var htmlElement = "<table id=\"tblSeguimiento\"></table>";
	htmlElement += "<div id=\"divSeguimientoPagerTable\" class=\"jqGridViaticoPagerClass\"></div>";
	setHtmlElement("divSeguimientoTable", htmlElement);
}

function setInitSeguimientoTable(idElementCallModal) {
	
	var seguimientoTable = $("#tblSeguimiento");
	if (seguimientoTable) {
		var seguimientoTableDiv = $("#" + idElementCallModal);
		var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.viaticoModalConsultarDetalleContainer", ".viaticoModalConsultarDetalleContainerAuxiliar", "width"))/100);
		var widthTable = factorRedimensionamiento*seguimientoTableDiv.width();
		seguimientoTable.jqGrid({
			width: widthTable,
			height: 200,
			datatype: "local",
			rowNum: 10,
			rowList: [10, 20],
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Núm.",
				"Actividad",
				"Colaborador",
				"Fecha Inicio",
				"Fecha Termino",
				"Observación",
				"Estado"
			],
			colModel: [
				{name: "secuencial", index: "secuencial", width: (1*widthTable/20), fixed: true, align: "center"},
				{name: "actividad", index: "actividad", width: (4.5*widthTable/20), fixed: true},
				{name: "nombreColaborador", index: "nombreColaborador", width: (4.5*widthTable/20), fixed: true},
				{name: "fechaInicio", index: "fechaInicio", width: (2.5*widthTable/20), fixed: true, align: "center"},
				{name: "fechaFin", index: "fechaFin", width: (2.5*widthTable/20), fixed: true, align: "center"},
				{name: "accion", index: "accion", width: (4.5*widthTable/20), fixed: true},
				{name: "estado", index: "estado", width: (4.5*widthTable/20), fixed: true}
			],
			/*caption: "Seguimiento",*/
			pager : "#divSeguimientoPagerTable",
			loadui: "disable"
		});
	}
}

function clickBtnCerrarConsultarSeguimiento() {
	setValueInputText("hidCodPlanViajeConsultarSeguimiento", "");
	setValueInputText("hidNumeroExpedienteConsultarSeguimiento", "");
	setValueInputText("hidCodigoPaginaCallerConsultarSeguimiento", "");
	removeEventElementsConsultarSeguimiento();
	removeSeguimientoTable();
	hideModalElement("divConsultarSeguimiento");
}

function callConsultarSeguimiento() {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/viatico.htm?action=consultarSeguimiento",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codPlanViaje": getUpperCaseValueInputText("hidCodPlanViajeConsultarSeguimiento"),
				"numeroExpediente": getUpperCaseValueInputText("hidNumeroExpedienteConsultarSeguimiento")
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showElement("divLoadingConsultarSeguimiento");
			},
			complete: function() {
				hideElement("divLoadingConsultarSeguimiento");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var codigoConsulta = result.codigoConsulta;
				var errorMessage = result.errorMessage;
				if (codigoConsulta != null && codigoConsulta == "00") {
					var planViajeBean = result.planViajeBean;
					var expedienteInternoAccionList = result.expedienteInternoAccionList;
					showSeguimientoDatos(planViajeBean);
					showSeguimiento(expedienteInternoAccionList);
				}
				else {
					if (codigoConsulta != null && codigoConsulta == "02") {
						var planViajeBean = result.planViajeBean;
						showSeguimientoDatos(planViajeBean);
					}
				}
			},
			error: function() {
				consoleLog("Error callConsultarSeguimiento");
			}
		});
	}, 500);
}

function showSeguimientoDatos(planViajeBean) {
	
	setValueInputText("txtNombreColaboradorConsultarSeguimiento", planViajeBean.numeroRegistroAlterno + " - " + planViajeBean.nomColaborador);
	setValueInputText("txtDescripcionDependenciaConsultarSeguimiento", planViajeBean.nomUuOoCom);
	setValueInputText("txtNumeroPlanillaConsultarSeguimiento", planViajeBean.codPlanilla);
	setValueInputText("txtImporteConsultarSeguimiento", planViajeBean.mtoTotalFormateado);
}

function showSeguimiento(seguimientoArray) {
	
	if (seguimientoArray != null && seguimientoArray.length > 0) {
		var seguimientoTable = $("#tblSeguimiento");
		seguimientoTable.clearGridData();
		for (var i = 0; i < seguimientoArray.length; i++) {
			var seguimiento = seguimientoArray[i];
			var datarow = {
				secuencial: seguimiento.numItem,
				actividad: seguimiento.des_accion,
				nombreColaborador: seguimiento.nom_emp,
				fechaInicio: seguimiento.fechaInicioFormat,
				fechaFin: seguimiento.fechaFinFormat,
				accion: seguimiento.observacion,
				estado: seguimiento.nom_estado
			};
			seguimientoTable.jqGrid("addRowData", datarow.secuencial, datarow);
		}
		seguimientoTable.trigger("reloadGrid");
	}
	else {
		setHtmlElement("divSeguimientoPagerTable_left", errorMessageConsultarSeguimiento.sinRegistrosBusqueda);
	}
	triggerResizeEventSlow();
}