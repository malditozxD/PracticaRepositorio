
function initElementsMotivoObservacionSolicitud(numRegistro,nomColaborador,nomDependencia,codPlanilla,importe,codUUOO) {
	$("#codPlanillaTemp").val(codPlanilla);
	$("#cabObservacion1").html(cabeceraObservacion1(numRegistro,nomColaborador,codPlanilla));
	$("#cabObservacion2").html(cabeceraObservacion2(importe));
	setHtmlElement("codPlanillaObservar",codPlanilla + "?");
	setInitElementsMotivoObservarSolicitud(); 
	setInitDataMotivoObservacion();
	
}

function setInitElementsMotivoObservarSolicitud() {
	addEventElement("btnAceptarObservacion", "click", clickBtnAceptarObservacion);
	addEventElement("btnCancelarObservacion", "click", clickBtnCancelarObservacion);
	addEventElement("btnSiMensajeConfirmacionFinalizarObservacion", "click", clickBtnSiMensajeConfirmacionFinalizarObservacion);
	addEventElement("btnNoMensajeConfirmacionFinalizarObservacion", "click", clickBtnNoMensajeConfirmacionFinalizarObservacion);
	addEventElement("btnOkMensajeConfirmacionFinalizarObservacion", "click", clickBtnOkMensajeConfirmacionFinalizarObservacion);
	addEventElement("btnOkMensajeConfirmaObservacion", "click", clickBtnOkMensajeConfirmaObservacion);
	addEventElement("btnAlertMensajeErrorObservar" ,"click", clickBtnAlertMensajeErrorObservar);
}

function cabeceraObservacion1(numRegistro,nomColaborador,codPlanilla) {
	var str="";
	str += "	<div class=\"col-xs-12 col-sm-3 col-md-2 col-lg-2\">";
	str += "		<label for=\"txtNumPlanilla\" class=\"text-muted alineartext\">N&deg; Planilla:<\/label>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-9 col-md-4 col-lg-4\">";
	str += "		<input class=\"form-control input-sm margen-input\" type=\"text\"";
	str += "			id=\"txtNumPlanilla\" name=\"txtNumPlanilla\" readonly=\"readonly\" value=\""+codPlanilla +"\"><\/input>";
	str += "	<\/div>";
	
	
	str += "	<div class=\"col-xs-12 col-sm-3 col-md-2 col-lg-2\">";
	str += "		<label for=\"txtNombreColaborador\" class=\"text-muted alineartext\">Autorizador:<\/label>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-9 col-md-4 col-lg-4\">";
	str += "		<input class=\"form-control input-sm margen-input\"  type=\"text\"";
	str += "			id=\"txtNombreColaborador\" name=\"txtNombreColaborador\"  readonly=\"readonly\" value=\""+ numRegistro +" - "+ nomColaborador+"\"><\/input>";
	str += "	<\/div>";
	return str;
} 

function cabeceraObservacion2(importe) {
	var str="";
	str += "	<div class=\"col-xs-12 col-sm-3 col-md-2 col-lg-2\">";
	str += "		<label for=\"txtFecObservacion\" class=\"text-muted alineartext\">Fecha de Observaci&oacute;n:<\/label>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-9 col-md-4 col-lg-4\">";
	str += "		<input class=\"form-control input-sm margen-input\" type=\"text\"";
	str += "			id=\"txtFecObservacion\" name=\"txtFecObservacion\" readonly=\"readonly\"><\/input>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-3 col-md-2 col-lg-2\">";
	str += "		<label for=\"txtImporte\" class=\"text-muted alineartext\">Importe Registrado:<\/label>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-9 col-md-4 col-lg-4\">";
	str += "		<input class=\"form-control input-sm margen-input\"  type=\"text\"";
	str += "			id=\"txtImporte\" name=\"txtImporte\"  readonly=\"readonly\" value=\""+ importe +"\"><\/input>";
	str += "	<\/div>";	
	return str;
} 

function setInitDataMotivoObservacion() {
	var fechaObservacion = getCurrentDateFormatEsp();
	$('#txtFecObservacion').val(fechaObservacion);
}

function limpiarInputs(){
	
}

function clickBtnCancelarObservacion() {
	$('#txtareaMotivoObservacion').val("");
	removeEventElementsMotivoObservarSolicitud();
	$('#divMotivoObservacionSolicitud').modal('hide');
}

function removeEventElementsMotivoObservarSolicitud() {
	removeAllEventsElement("btnCancelarObservacion");
	removeAllEventsElement("btnAceptarObservacion");
	removeAllEventsElement("btnSiMensajeConfirmacionFinalizarObservacion");
	removeAllEventsElement("btnNoMensajeConfirmacionFinalizarObservacion");
	removeAllEventsElement("btnOkMensajeConfirmacionFinalizarObservacion");
}

function ejecucionObservacion() {
	
	var numeroRegistroReg = $("#hidNumeroRegistroRegistrador").val();
	var codigoRegistrador = $("#hidCodigoRegistrador").val();
	var motivoObservacion = $("#txtareaMotivoObservacion").val();
	var codigoDocumento = $("#codPlanillaTemp").val();
	ajax_data = {
		"numeroRegistrador": numeroRegistroReg,	
		"codigoRegistrador": codigoRegistrador,
		"codigoDocumento": codigoDocumento,
		"motivoObservacion": motivoObservacion
	};
	
	$.ajax({
		data: ajax_data,
		url: contextPathUrl + "/registrarSolicitud.htm?action=observarSolicitud",
		type: "post",
		dataType: "json",
		cache: false,
		success: function(respuesta) {
			$('#divMensajeConfirmacionFinalizarObservacion').modal('hide');
			clickBtnNoMensajeConfirmacionFinalizarObservacion();
			if(respuesta.actualizado =="1"){
				//$("#mensajeFinObservar").html("Se observ&oacute; correctamente.");
				//$('#divMensajeConfirmacionOkFinalizarObservacion').modal('show');
				$('#divMensajeConfirmaObservacion').modal('show');
			}
			else{ 
				//$("#spaMensajeAlertaObservar").html("A ocurrido un error inesperado por favor intentelo m&aacute;s tarde.");	
				$("#divAlertMensajeErrorObservar").modal("show");}
		},
		error: function(xhr, ajaxOptions, thrownError) {
			
		}
	});
	
	
}

function clickBtnSiMensajeConfirmacionFinalizarObservacion(){
	ejecucionObservacion();
}

function clickBtnNoMensajeConfirmacionFinalizarObservacion(){
	$('#divMensajeConfirmacionFinalizarObservacion').modal('hide');
}

function clickBtnOkMensajeConfirmacionFinalizarObservacion(){
	var motivoObservacion = $("#txtareaMotivoObservacion").val();
	if (trimText(motivoObservacion) != "") {
		clickBtnConsultarSolicitud();	
	}
	$('#divMensajeConfirmacionOkFinalizarObservacion').modal('hide');
	$('#divMensajeConfirmacionFinalizarObservacion').modal('hide');
	$('#divMotivoObservacionSolicitud').modal('hide');	
	removeEventElementsMotivoObservarSolicitud();
	actualizarGridBandejaObservacion();
}


function clickBtnOkMensajeConfirmaObservacion(){
	var motivoObservacion = $("#txtareaMotivoObservacion").val();
	if (trimText(motivoObservacion) != "") {
		clickBtnConsultarSolicitud();	
	}
	$('#divMensajeConfirmaObservacion').modal('hide');
	$('#divMensajeConfirmacionFinalizarObservacion').modal('hide');
	$('#divMotivoObservacionSolicitud').modal('hide');	
	removeEventElementsMotivoObservarSolicitud();
	actualizarGridBandejaObservacion();
}


function actualizarGridBandejaObservacion(){
	$('#txtareaMotivoObservacion').val("");
	 clickBtnCancelarObservacion();
}

function clickBtnAceptarObservacion() {
		var motivoObservacion = $("#txtareaMotivoObservacion").val();
		if (trimText(motivoObservacion) != "") {
			$('#divMensajeConfirmacionFinalizarObservacion').modal('show');
		}
		else {
			//$("#mensajeFinObservar").html("Se debe de ingresar un motivo de observaci&oacute;n v&aacute;lido.");
			$('#divMensajeConfirmacionOkFinalizarObservacion').modal('show');
		}	
}

function clickBtnAlertMensajeErrorObservar(){
	$("#divAlertMensajeErrorObservar").modal("hide");
}