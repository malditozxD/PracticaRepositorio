function initElementsReprogramarFechaRendicion(dataParametrosReprogramar) {
	removeDuplicateComponents();
	setInitElementsReprogramarFechaRendicion(dataParametrosReprogramar);
}

function setInitElementsReprogramarFechaRendicion(dataParametrosReprogramar) {
	
	hideElement("divInternacional");
	hideElement("divNacional");
	hideElement("divNacionalMenorIgual4Horas");
	hideElement("divErrorReprogramar");
	uncheckElement("rbtnViaticoProgramadoSi");
	uncheckElement("rbtnViaticoProgramadoNo");
	uncheckElement("rbtnViaticoProgramadoMenorSi");
	uncheckElement("rbtnViaticoProgramadoMenorNo");
	setValueInputText("hidCodPlanViajeReprogramar", dataParametrosReprogramar.codPlanViaje);
	
	//JMCR-ME Fecha Reprogramacion
	var fecMaxRend = dataParametrosReprogramar.fecMaxRend;
	var fecReprog = dataParametrosReprogramar.fecReprog;

	var fecMaxRep = fecMaxRend;	
	//if (fecReprog != null && esFechaValida(fecReprog) && esFechaMayor(fecReprog, fecMaxRend)) {
	//	fecMaxRep = fecReprog;
	//}
	setValueInputText("hidFechaMaximaProgramada", fecMaxRep);
	//JMCR-ME Fecha Reprogramacion
	
	setValueInputText("hidFechaMaximaDate", "31/12/" + getNextYear());
	setValueInputText("txtNumeroPlanillaReprogramar", dataParametrosReprogramar.codPlanilla);
	setValueInputText("txtEstadoRendicionReprogramar", dataParametrosReprogramar.nomEstRend);
	setValueInputText("txtNroRegistroReprogramar", dataParametrosReprogramar.numeroRegistroAlterno);
	setValueInputText("txtNombreColaboradorReprogramar", dataParametrosReprogramar.nomColaborador);
	setValueInputText("txtMotivoViaticoReprogramar", dataParametrosReprogramar.motivoComis);
	setValueInputText("txtJustificacionViaticoReprogramar", "");
	setValueInputText("etiquetaFechaMaximaReprogramacion", "");
	if (dataParametrosReprogramar.tipoDestino == "01") {
		if (dataParametrosReprogramar.indicadorHoras == "1") {
			setInitElementsNacionalMenorIgual4HorasReprogramar(dataParametrosReprogramar);
			showElement("divNacionalMenorIgual4Horas");
		}
		else {
			setInitElementsNacionalReprogramar(dataParametrosReprogramar);
			showElement("divNacional");
		}
	}
	else if (dataParametrosReprogramar.tipoDestino == "02") {
		setInitElementsInternacionalReprogramar(dataParametrosReprogramar);
		showElement("divInternacional");
	}
	addEventElement("btnAceptarReprogramar", "click", clickBtnAceptarReprogramar);
	addEventElement("btnCancelarReprogramar", "click", clickBtnCancelarReprogramar);
	addEventElement("etiquetaFechaMaximaReprogramacion", "change", changeEtiquetaFechaMaximaReprogramacion);
    initDateTimePickerWithMaxDate("etiquetaFechaMaximaReprogramacionDiv", "dp.change", "changeDate", changeDateEtiquetaFechaMaximaReprogramacionDiv, formatEspDateToEngFormatDate(getValueInputText("hidFechaMaximaDate")));
    
	addEventElement("btnSiReprogramarRendicionReprogramar", "click", clickBtnSiReprogramarRendicionReprogramar);
	addEventElement("btnNoReprogramarRendicionReprogramar", "click", clickBtnNoReprogramarRendicionReprogramar);
	addEventElement("btnAceptarReprogramacionExitosaReprogramar", "click", clickBtnAceptarReprogramacionExitosaReprogramar);
	addEventElement("btnAceptarMensajeConfirmacionErrorReprogramarFechaRendicion", "click", clickBtnAceptarMensajeConfirmacionErrorReprogramarFechaRendicion);
}

function removeEventElementsReprogramarFechaRendicion() {
	removeAllEventsElement("clickBtnAceptarReprogramar");
	removeAllEventsElement("clickBtnCancelarReprogramar");
	removeAllEventsElement("etiquetaFechaMaximaReprogramacion");
	removeAllEventsElement("etiquetaFechaMaximaReprogramacionDiv");
	removeAllEventsElement("btnSiReprogramarRendicionReprogramar");
	removeAllEventsElement("btnNoReprogramarRendicionReprogramar");
	removeAllEventsElement("btnAceptarReprogramacionExitosaReprogramar");
	removeAllEventsElement("btnAceptarMensajeConfirmacionErrorReprogramarFechaRendicion");
}

function clickBtnAceptarReprogramar() {
	if (validarReprogramarFechaRendicion()) {
		enabledElement("btnSiReprogramarRendicionReprogramar");
		showModalElement("divMensajeConfirmacionReprogramarRendicionReprogramar");
	}
}

function setInitElementsNacionalReprogramar(dataParametrosReprogramar) {
	setValueInputText("etiquetaFechaSalidaNacionalReprogramar", dataParametrosReprogramar.fecSalida);
	setValueInputText("etiquetaFechaRetornoNacionalReprogramar", dataParametrosReprogramar.fecRetorno);
	setValueInputText("txtDiasNacionalReprogramar", dataParametrosReprogramar.numDias);
	if (dataParametrosReprogramar.poaProgramado == "S") {
		ckeckElement("rbtnViaticoProgramadoSi");
	}
	else {
		ckeckElement("rbtnViaticoProgramadoNo");
	}
}

function setInitElementsNacionalMenorIgual4HorasReprogramar(dataParametrosReprogramar) {
	setValueInputText("etiquetaFechaNacionalMenorReprogramar", dataParametrosReprogramar.fecSalida);
	setValueInputText("txtHoraSalidaNacionalMenorReprogramar", dataParametrosReprogramar.horaSalida);
	setValueInputText("txtHoraRetornoNacionalMenorReprogramar", dataParametrosReprogramar.horaRetorno);
	setValueInputText("txtHorasNacionalMenorReprogramar", dataParametrosReprogramar.numeroHoras);
	if (dataParametrosReprogramar.poaProgramado == "S") {
		ckeckElement("rbtnViaticoProgramadoMenorSi");
	}
	else {
		ckeckElement("rbtnViaticoProgramadoMenorNo");
	}
}

function setInitElementsInternacionalReprogramar(dataParametrosReprogramar) {
	setValueInputText("etiquetaFechaInicialInternacionalReprogramar", dataParametrosReprogramar.fecSalida);
	setValueInputText("etiquetaFechaFinalInternacionalReprogramar", dataParametrosReprogramar.fecRetorno);
	setValueInputText("txtDiasInternacionalReprogramar", dataParametrosReprogramar.numDias);
}

function clickBtnCancelarReprogramar() {
	removeEventElementsReprogramarFechaRendicion();
	hideModalElement("divReprogramarFechaRendicion");
}

function changeEtiquetaFechaMaximaReprogramacion() {
	if (isBrowserInternetExplorer()) {
		if (trimText(getValueInputText("etiquetaFechaMaximaReprogramacion")) != "" && isValidoFormatDate(getValueInputText("etiquetaFechaMaximaReprogramacion"))) {
			if (isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaMaximaReprogramacion")), getValueInputText("hidFechaMaximaDate"))) {
				setValueInputText("etiquetaFechaMaximaReprogramacion", "");
			}
		}
		else {
			setValueInputText("etiquetaFechaMaximaReprogramacion", "");
		}
		changeDateEtiquetaFechaMaximaReprogramacionDiv();
	}
}

function changeDateEtiquetaFechaMaximaReprogramacionDiv() {
	consoleLog("changeDateEtiquetaFechaVoucherRegistrarBoletaDepositoDiv");
}


function clickBtnSiReprogramarRendicionReprogramar() {
	disabledElement("btnSiReprogramarRendicionReprogramar");
	hideModalElement("divReprogramarFechaRendicion");
	hideModalElement("divMensajeConfirmacionReprogramarRendicionReprogramar");
	callReprogramarFechaRendicion();
}

function clickBtnNoReprogramarRendicionReprogramar() {
	hideModalElement("divMensajeConfirmacionReprogramarRendicionReprogramar");
}

function clickBtnAceptarReprogramacionExitosaReprogramar() {
	removeEventElementsReprogramarFechaRendicion();
	$("#btnConsultarRendicion").trigger("click");
	hideModalElement("divMensajeConfirmacionReprogramacionExitosaReprogramar");
}

function clickBtnAceptarMensajeConfirmacionErrorReprogramarFechaRendicion() {
	hideModalElement("divMensajeConfirmacionErrorReprogramarFechaRendicion");
}

function validarReprogramarFechaRendicion() {
	
	var dataValidacion;
	hideElement("divErrorReprogramar");
	
	dataValidacion = validarCamposNoVaciosReprogramarFechaRendicion();
	if (!dataValidacion.flagCamposNoVacios) {
		showMessageErrorReprogramarFechaRendicion(dataValidacion.errorMessage);
		return false;
	}
	
	dataValidacion = validarJustificacionCorrecta();
	if (!dataValidacion.flagJustificacionCorrecta) {
		showMessageErrorReprogramarFechaRendicion(dataValidacion.errorMessage);
		return false;
	}
	
	dataValidacion = validarFechaRendicionCorrecta();
	if (!dataValidacion.flagFechaRendicionCorrecta) {
		showMessageErrorReprogramarFechaRendicion(dataValidacion.errorMessage);
		return false;
	}
	
	return true;
}

function validarCamposNoVaciosReprogramarFechaRendicion() {
	
	var flagCamposNoVacios = true;
	var errorMessage = "";
	
	if (flagCamposNoVacios && trimText(getValueInputText("txtJustificacionViaticoReprogramar")) == "") {
		flagCamposNoVacios = false;
		errorMessage = errorMessageReprogramarFechaRendicion.completarJustificacion;
	}
	
	if (flagCamposNoVacios && getValueInputText("etiquetaFechaMaximaReprogramacion") == "") {
		flagCamposNoVacios = false;
		errorMessage = errorMessageReprogramarFechaRendicion.completarFechaRendicion;
	}
	
	var dataValidacion = {
		flagCamposNoVacios: flagCamposNoVacios,
		errorMessage: errorMessage
	};
	return dataValidacion;
}

function validarJustificacionCorrecta() {
	
	var flagJustificacionCorrecta = true;
	var errorMessage = "";
	
	if (flagJustificacionCorrecta && trimText(getValueInputText("txtJustificacionViaticoReprogramar")).length > 1000) {
		flagJustificacionCorrecta = false;
		errorMessage = errorMessageReprogramarFechaRendicion.maximoCaracteresJustificacion;
	}
	
	var dataValidacion = {
		flagJustificacionCorrecta: flagJustificacionCorrecta,
		errorMessage: errorMessage
	};
	return dataValidacion;
}

function validarFechaRendicionCorrecta() {
	
	var flagFechaRendicionCorrecta = true;
	var errorMessage = "";
	
	if (flagFechaRendicionCorrecta && !isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaMaximaReprogramacion")), formatEspDateToEngFormatDate(getValueInputText("hidFechaMaximaProgramada")))) {
		flagFechaRendicionCorrecta = false;
		errorMessage = errorMessageReprogramarFechaRendicion.fechaRendicionMenorFechaProgramada + getValueInputText("hidFechaMaximaProgramada") + ".";
	}
	
	var dataValidacion = {
		flagFechaRendicionCorrecta: flagFechaRendicionCorrecta,
		errorMessage: errorMessage
	};
	return dataValidacion;
}

function callReprogramarFechaRendicion() {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/revisarRendicion.htm?action=reprogramarFechaRendicion",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codPlanViaje": getValueInputText("hidCodPlanViajeReprogramar"),
				"fecMaxRend": getValueInputText("etiquetaFechaMaximaReprogramacion"),
				"descripcionJustRep": trimText(getUpperCaseValueInputText("txtJustificacionViaticoReprogramar"))
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showModalElement("divMensajeConfirmacionLoadingRevisarRendicionBandeja");
			},
			complete: function() {
				hideModalElement("divMensajeConfirmacionLoadingRevisarRendicionBandeja");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var codigoOperacion = result.codigoOperacion;
				var errorMessage = result.errorMessage;
				var successMessage = result.successMessage;
				if (codigoOperacion != null && codigoOperacion == "00") {
					showModalElement("divMensajeConfirmacionReprogramacionExitosaReprogramar");
				}
				else {
					showMensajeConfirmacionErrorReprogramarFechaRendicion(errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callReprogramarFechaRendicion");
			}
		});
	}, 500);
}

function showMessageErrorReprogramarFechaRendicion(errorMessage) {
	setHtmlElement("etiquetaReprogramar", errorMessage);
	showElement("divErrorReprogramar");
}

function showMensajeConfirmacionErrorReprogramarFechaRendicion(messageTitulo) {
	hideElement("divBodyPanelMensajeConfirmacionErrorReprogramarFechaRendicion");
	setHtmlElement("divTituloPanelMensajeConfirmacionErrorReprogramarFechaRendicion", messageTitulo);
	showModalElement("divMensajeConfirmacionErrorReprogramarFechaRendicion");
}
