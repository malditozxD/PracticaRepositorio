function callObtenerDocumentoSustentario(parametrosConsulta) {

			var datosRendicionTable = $("#tblDatosRendicion");
			datosRendicionTable.clearGridData();
			var datosComprobantePagoTable = $("#tblDatosComprobantePago");
			datosComprobantePagoTable.clearGridData();
			$.ajax({
				url: contextPathUrl + "/viatico.htm?action=obtenerDocumentoSustentario",
				data: {
					"idPlanViaje": parametrosConsulta.planViajeId,
					"secuencia": parametrosConsulta.secuencial
				},
				type: "post",
				dataType: "json",
				cache: false,
				beforeSend: function() {
					showModalElement("divScreenBlock");
				},
				complete: function() {
					hideModalElement("divScreenBlock");
				},
				success: function(result) {
					if(result.documentoSustentarioVO.mensajeRepuesta == "OK"){						
						consoleLog(result.documentoSustentarioVO);
						//estado de edicion/nuevo (true)/(false)
						setValueInputText("porcentajeDeclaracion",result.documentoSustentarioVO.porcentajeDeclaracion);
						var montoEditarRendicion = result.documentoSustentarioVO.montoTotalRendicion;
						setValueInputText("montoEditarRendicion", montoEditarRendicion);
						/*
						if($.trim(result.documentoSustentarioVO.listaPlanViajeRendicion[0].conceptoId) == "915" || $.trim(result.documentoSustentarioVO.listaPlanViajeRendicion[0].conceptoId) == "067" ){
							montoEditarRendicion = (result.documentoSustentarioVO.listaPlanViajeRendicion[0].montoDocumento).toFixed(2);}		
						*/
						monedaViatico = $.trim(result.documentoSustentarioVO.moneda);
						setValueInputText("monedaViatico",monedaViatico);
						var tipoDocumentoComprobanteSel = $("#selTipoDocumentoComprobante");
						tipoDocumentoComprobanteSel.empty();
						var tipoDocumentoList = result.documentoSustentarioVO.tipoDocumentoList;
						var optionSelect = $("<option></option>").attr("value", "000").text("--Seleccione--");
						tipoDocumentoComprobanteSel.append(optionSelect);
						if (tipoDocumentoList != null && tipoDocumentoList.length > 0) {
							for (var i = 0; i < tipoDocumentoList.length; i++) {
								var tipoDocumento = tipoDocumentoList[i];
								optionSelect = $("<option></option>").attr("value", tipoDocumento.codigoTipoDocumento).text(tipoDocumento.descripcionTipoDocumento);
								tipoDocumentoComprobanteSel.append(optionSelect);
							}					
						}				
						else {
							consoleLog("Error callObtenerTipoDocumentoToComprobante");
						}
						
						if(parametrosConsulta.estadoLlamada == "C" || parametrosConsulta.estadoLlamada == "N"){
										var tipoConceptoComprobanteSel = $("#selTipoConceptoComprobante");
										tipoConceptoComprobanteSel.empty();						
										var conceptoPlanillaViaticosList = result.documentoSustentarioVO.planViajeConceptoList;
										conceptoViaticosListGeneral = conceptoPlanillaViaticosList;
										var optionSelect = $("<option></option>").attr("value", "00").attr("data-clasificadorgasto", "").attr("data-monto", "").attr("data-montoDeclaracion","").text("--Seleccione--");
										tipoConceptoComprobanteSel.append(optionSelect);
										if (conceptoPlanillaViaticosList != null && conceptoPlanillaViaticosList.length > 0) {
											for (var i = 0; i < conceptoPlanillaViaticosList.length; i++) {
												var conceptoPlanillaViaticos = conceptoPlanillaViaticosList[i];
												optionSelect = $("<option></option>").attr("id", conceptoPlanillaViaticos.conceptoID).attr("value", conceptoPlanillaViaticos.conceptoID).attr("data-clasificadorgasto", conceptoPlanillaViaticos.clasificadorGasto).attr("data-montoDeclaracion", conceptoPlanillaViaticos.monto).attr("data-monto", conceptoPlanillaViaticos.montoDevolver).text(
														conceptoPlanillaViaticos.descripcionConcepto + 
														($.trim(conceptoPlanillaViaticos.montoDevolver) == "" ? ""  :   " - "+ $.trim(result.documentoSustentarioVO.moneda)+ " "+(conceptoPlanillaViaticos.montoDevolver).toFixed(2) )  );
												tipoConceptoComprobanteSel.append(optionSelect);
											}
										}
										else {
											consoleLog("Error callObtenerConceptoPlanillaViaticosToComprobante");
										}
						}else if(parametrosConsulta.estadoLlamada == "E"){
							var tipoConceptoComprobanteSel = $("#selTipoConceptoComprobante");
							tipoConceptoComprobanteSel.empty();						
							var conceptoPlanillaViaticosList = result.documentoSustentarioVO.planViajeConceptoList;
							var optionSelect = $("<option></option>").attr("value", "00").attr("data-clasificadorgasto", "").attr("data-monto", "").attr("data-montoDeclaracion","").text("--Seleccione--");
							tipoConceptoComprobanteSel.append(optionSelect);
							
							conceptoViaticosListGeneral = conceptoPlanillaViaticosList;		
							consoleLog("samuelllll" + conceptoPlanillaViaticosList);
							if (conceptoPlanillaViaticosList != null && conceptoPlanillaViaticosList.length > 0) {
								for (var i = 0; i < conceptoPlanillaViaticosList.length; i++) {
									var conceptoPlanillaViaticos = conceptoPlanillaViaticosList[i];
									optionSelect = $("<option></option>").attr("id", conceptoPlanillaViaticos.conceptoID).attr("value", conceptoPlanillaViaticos.conceptoID).attr("data-clasificadorgasto", conceptoPlanillaViaticos.clasificadorGasto).attr("data-montoDeclaracion", conceptoPlanillaViaticos.monto).attr("data-monto", conceptoPlanillaViaticos.montoDevolver  + (montoEditarRendicion)).text(conceptoPlanillaViaticos.descripcionConcepto + 
											($.trim(conceptoPlanillaViaticos.montoDevolver) == "" ? ""  :   " - "+ $.trim(result.documentoSustentarioVO.moneda)+ " "+(conceptoPlanillaViaticos.montoDevolver + (montoEditarRendicion)).toFixed(2))											
									);
									tipoConceptoComprobanteSel.append(optionSelect);
								}
							}
							else {
								consoleLog("Error callObtenerConceptoPlanillaViaticosToComprobante");
							}
						}
									
						
						
						
						if(result.documentoSustentarioVO.estadoDocumentoSustentario){
							
							initSelectValue("selTipoDocumentoComprobante",result.documentoSustentarioVO.listaPlanViajeRendicion[0].tipoDocumento);
							setValueInputText("txtSecuenciaComprobante", result.documentoSustentarioVO.listaPlanViajeRendicion[0].secuencial);
							setValueInputText("txtRucComprobante", result.documentoSustentarioVO.listaPlanViajeRendicion[0].ruc);
							setValueInputText("txtRazonSocialComprobante", result.documentoSustentarioVO.listaPlanViajeRendicion[0].razoSociPro);					
							setValueInputText("txtSerieDocumentoComprobante", result.documentoSustentarioVO.listaPlanViajeRendicion[0].serie);
							setValueInputText("txtNumeroDocumentoComprobante", result.documentoSustentarioVO.listaPlanViajeRendicion[0].numeroDocumento);
							setValueInputText("etiquetaFechaDocumentoComprobante", result.documentoSustentarioVO.listaPlanViajeRendicion[0].fechaDocumento);
							initSelectValue("selTipoConceptoComprobante", result.documentoSustentarioVO.listaPlanViajeRendicion[0].conceptoId);
							setValueInputText("txtClasificadorGastoComprobante",result.documentoSustentarioVO.listaPlanViajeRendicion[0].clasificadorGasto); 
							setValueInputText("txtSustentoLugarReferenciaComprobante", result.documentoSustentarioVO.listaPlanViajeRendicion[0].lugarGasto);		
							
							setValueInputText("tipoDestino", result.documentoSustentarioVO.planViajeBean.tipoDestino);
							setValueInputText("fechaHoraProgSalida", result.documentoSustentarioVO.planViajeBean.fechaHoraProgSalida);
							setValueInputText("fechaHoraProgRetorno", result.documentoSustentarioVO.planViajeBean.fechaHoraProgRetorno);						
							setValueInputText("fechaHoraEjeSalida", result.documentoSustentarioVO.planViajeBean.fechaHoraEjeSalida);
							setValueInputText("fechaHoraEjeRetorno", result.documentoSustentarioVO.planViajeBean.fechaHoraEjeRetorno);
							setValueInputText("igvActual", result.documentoSustentarioVO.igv);
							setValueInputText("indExtDDJJ", result.documentoSustentarioVO.planViajeBean.indicadorExtDdjj);
							setValueInputText("estadoDDJJ", result.documentoSustentarioVO.estadoDDJJ);							
							
							var datarow = {
									indice: "1",
									moneda: $.trim(result.documentoSustentarioVO.moneda),
									valorVenta: (result.documentoSustentarioVO.listaPlanViajeRendicion[0].valorVenta).toFixed(2),
									montoBase: (result.documentoSustentarioVO.listaPlanViajeRendicion[0].valorVenta).toFixed(2),
									igv: (result.documentoSustentarioVO.listaPlanViajeRendicion[0].montoIgv).toFixed(2),
									exoneracionIgv: result.documentoSustentarioVO.listaExoneracion,
									cero:"0.00",
									otroGasto: (result.documentoSustentarioVO.listaPlanViajeRendicion[0].mtoOtrosGastos).toFixed(2),
									valorTotal: (result.documentoSustentarioVO.listaPlanViajeRendicion[0].montoDocumento).toFixed(2),
									montoTotal: (result.documentoSustentarioVO.listaPlanViajeRendicion[0].montoDocumento).toFixed(2),
									indAfectoIgv: result.documentoSustentarioVO.listaPlanViajeRendicion[0].indAfectoIgv,
								};
							consoleLog("datarow.valorTotal: " + datarow.valorTotal + " datarow.montoTotal: "+ datarow.montoTotal);
							setValueInputText("montoTotalEditar",datarow.valorTotal);
							datosRendicionTable.jqGrid("addRowData", datarow.indice, datarow);
							datosRendicionTable.trigger("reloadGrid");
							initSelectValue("exoneracionIgv",$.trim(result.documentoSustentarioVO.listaPlanViajeRendicion[0].indAfectoIgv));
							
							//var conceptoId = result.documentoSustentarioVO.listaPlanViajeRendicion[0].conceptoId;
							
							if(result.documentoSustentarioVO.listaPlanViajeInformeDitrib != null){
								for(i = 0; i< result.documentoSustentarioVO.listaPlanViajeInformeDitrib.length; i++){
									var listaPlanViajeInformeDitrib = result.documentoSustentarioVO.listaPlanViajeInformeDitrib[i];
									var montoAlimentacion = parseFloat(( $.trim(listaPlanViajeInformeDitrib.montoDocumentoAlimentacion) == "" ) ? "0.00" : listaPlanViajeInformeDitrib.montoDocumentoAlimentacion);
									var montoHospedaje = parseFloat(($.trim(listaPlanViajeInformeDitrib.montoDocumentoHospedaje) == "" ) ? "0.00" : listaPlanViajeInformeDitrib.montoDocumentoHospedaje);
									var montoMovilidad = parseFloat(($.trim(listaPlanViajeInformeDitrib.montoDocumentoMovilidad) == "" ) ? "0.00" : listaPlanViajeInformeDitrib.montoDocumentoMovilidad);
									var montoTranslado = parseFloat(($.trim(listaPlanViajeInformeDitrib.montoDocumentoTranslado) == "" ) ? "0.00" : listaPlanViajeInformeDitrib.montoDocumentoTranslado);
									var montoRendicionXFecha = parseFloat(($.trim(listaPlanViajeInformeDitrib.montoDestionFecha) == "" ) ? "0.00" : listaPlanViajeInformeDitrib.montoDestionFecha);
									var dataRowComprobantePago = {
											indice: i,
											fechaViatico: listaPlanViajeInformeDitrib.fecViatico,
											alimentacion: montoAlimentacion.toFixed(2),
											hospedaje: montoHospedaje.toFixed(2),
											movilidad: montoMovilidad.toFixed(2),
											translado: montoTranslado.toFixed(2),
											total: (montoAlimentacion + montoHospedaje + montoMovilidad + montoTranslado).toFixed(2),
											fechaDDMMYYYY : $.trim(listaPlanViajeInformeDitrib.fecViatico).replace("/","").replace("/",""),
											rendicionFechaRendicion : $.trim(result.documentoSustentarioVO.moneda) + " " +(montoRendicionXFecha + montoAlimentacion + montoHospedaje + montoMovilidad + montoTranslado).toFixed(2),
											rendicionFechaRendicionSinFormato: (montoRendicionXFecha + montoAlimentacion + montoHospedaje + montoMovilidad + montoTranslado).toFixed(2)
										};	
									datosComprobantePagoTable.jqGrid("addRowData", dataRowComprobantePago.indice, dataRowComprobantePago);
								}						
							
								datosComprobantePagoTable.trigger("reloadGrid");
								
							}
							
							if(parametrosConsulta.estadoLlamada == "C"){
								selTipoDocumentoComprobante();
								bloqueoParametrosDocumentoComprobante();
								sumaValoresIteracionFooter();
							}else if(parametrosConsulta.estadoLlamada == "E"){
								selTipoDocumentoComprobante();
								bloqueoEdicionDocumentoSustentatorio();
								sumaValoresIteracionFooter();								
							}	
							
							
						}			
					else{
						
						setValueInputText("tipoDestino", result.documentoSustentarioVO.planViajeBean.tipoDestino);
						setValueInputText("fechaHoraProgSalida", result.documentoSustentarioVO.planViajeBean.fechaHoraProgSalida);
						setValueInputText("fechaHoraProgRetorno", result.documentoSustentarioVO.planViajeBean.fechaHoraProgRetorno);						
						setValueInputText("fechaHoraEjeSalida", result.documentoSustentarioVO.planViajeBean.fechaHoraEjeSalida);
						setValueInputText("fechaHoraEjeRetorno", result.documentoSustentarioVO.planViajeBean.fechaHoraEjeRetorno);
						setValueInputText("igvActual", result.documentoSustentarioVO.igv);
						setValueInputText("indExtDDJJ", result.documentoSustentarioVO.planViajeBean.indicadorExtDdjj);
						setValueInputText("estadoDDJJ", result.documentoSustentarioVO.estadoDDJJ);
						setValueInputText("montoTotalRendicion", result.documentoSustentarioVO.montoTotalRendicion);						
						
						var datarow = {
								indice: "1",
								moneda: $.trim(result.documentoSustentarioVO.moneda),
								valorVenta: "0.00",
								montoBase:"0.00",
								igv:"0.00",
								exoneracionIgv: result.documentoSustentarioVO.listaExoneracion,
								cero:"0.00",
								otroGasto:"0.00",
								valorTotal:"0.00",
								montoTotal:"0.00"							
							};
						datosRendicionTable.jqGrid("addRowData", datarow.indice, datarow);
						datosRendicionTable.trigger("reloadGrid");
						
						for(i = 0; i< result.documentoSustentarioVO.listaPlanViajeInformeDitrib.length; i++){
							var listaPlanViajeInformeDitrib = result.documentoSustentarioVO.listaPlanViajeInformeDitrib[i];
							var montoAlimentacion = parseFloat(( $.trim(listaPlanViajeInformeDitrib.montoDocumentoAlimentacion) == "" ) ? "0.00" : listaPlanViajeInformeDitrib.montoDocumentoAlimentacion);
							var montoHospedaje = parseFloat(($.trim(listaPlanViajeInformeDitrib.montoDocumentoHospedaje) == "" ) ? "0.00" : listaPlanViajeInformeDitrib.montoDocumentoHospedaje);
							var montoMovilidad = parseFloat(($.trim(listaPlanViajeInformeDitrib.montoDocumentoMovilidad) == "" ) ? "0.00" : listaPlanViajeInformeDitrib.montoDocumentoMovilidad);
							var montoTranslado = parseFloat(($.trim(listaPlanViajeInformeDitrib.montoDocumentoTranslado) == "" ) ? "0.00" : listaPlanViajeInformeDitrib.montoDocumentoTranslado);
							var montoRendicionXFecha = parseFloat(($.trim(listaPlanViajeInformeDitrib.montoDestionFecha) == "" ) ? "0.00" : listaPlanViajeInformeDitrib.montoDestionFecha);
							var dataRowComprobantePago = {
									indice: i,
									fechaViatico: listaPlanViajeInformeDitrib.fecViatico,
									alimentacion: montoAlimentacion.toFixed(2),
									hospedaje: montoHospedaje.toFixed(2),
									movilidad: montoMovilidad.toFixed(2),
									translado: montoTranslado.toFixed(2),
									total: (montoAlimentacion + montoHospedaje + montoMovilidad + montoTranslado).toFixed(2),
									fechaDDMMYYYY : $.trim(listaPlanViajeInformeDitrib.fecViatico).replace("/","").replace("/",""),
									rendicionFechaRendicion : result.documentoSustentarioVO.moneda + " " +(montoRendicionXFecha + montoAlimentacion + montoHospedaje + montoMovilidad + montoTranslado).toFixed(2),
									rendicionFechaRendicionSinFormato: (montoRendicionXFecha + montoAlimentacion + montoHospedaje + montoMovilidad + montoTranslado).toFixed(2)
							};	
							datosComprobantePagoTable.jqGrid("addRowData", dataRowComprobantePago.indice, dataRowComprobantePago);
						}						
						
						datosComprobantePagoTable.trigger("reloadGrid");							
						selTipoDocumentoComprobante();
						
					}			
						if(parametrosConsulta.estadoLlamada == "E"){
							if($.trim(result.documentoSustentarioVO.listaPlanViajeRendicion[0].conceptoId) != "01" && $.trim(result.documentoSustentarioVO.listaPlanViajeRendicion[0].conceptoId) != "12")
							hideElementByClass("rendicionFechaRendicion");
						}
						
						var selCon = $.trim(getValueInputText("selTipoConceptoComprobante"));
						mostrarSustentoLugar(selCon);
						
					}					
				},
				error: function() {
					consoleLog("Error callObtenerConceptoPlanillaViaticosToComprobante");
				}
			});
}

function callGrabarEditarComprobantePago(parametrosEntrada){
	var estadoNumeroDocumento = false;
	if(parametros.estadoLlamada == "N"){
		estadoNumeroDocumento = validarNumeroDocumentoRepetido("N");
		consoleLog(" estadoNumeroDocumento--->" +  estadoNumeroDocumento);
	}
	else{
		//modo editable
		estadoNumeroDocumento = validarNumeroDocumentoRepetido("E");
		//estadoNumeroDocumento = true;
	}	
							if(estadoNumeroDocumento == "true" || estadoNumeroDocumento==true){
										var arrayListaPlanRendicion = new Array();
										var objetoPlanRendicion = new Object();
										objetoPlanRendicion.tipoDocumento = getValueInputText("selTipoDocumentoComprobante");
										objetoPlanRendicion.ruc = getValueInputText("txtRucComprobante");
										objetoPlanRendicion.razoSociPro = getValueInputText("txtRazonSocialComprobante");	
										objetoPlanRendicion.serie = getValueInputText("txtSerieDocumentoComprobante");	
										objetoPlanRendicion.numeroDocumento = getValueInputText("txtNumeroDocumentoComprobante");
										objetoPlanRendicion.fechaDocumento = getValueInputText("etiquetaFechaDocumentoComprobante");
										objetoPlanRendicion.conceptoId = getValueInputText("selTipoConceptoComprobante");
										objetoPlanRendicion.clasificadorGasto = getValueInputText("txtClasificadorGastoComprobante");
										objetoPlanRendicion.lugarGasto = getValueInputText("txtSustentoLugarReferenciaComprobante");
										
										//DECLARACION JURADA - COMPROBANTE DE PAGO(906) / DECLARACION JURADA - VIATICOS(907) / COMPROBANTE DEL EXTERIOR(916)
									    if (getValueInputText("selTipoDocumentoComprobante") == "907" || 
									    	getValueInputText("selTipoDocumentoComprobante") == "906" || getValueInputText("selTipoDocumentoComprobante") == "916" ) {
									    	var montoTotal = $.trim(getValueInputText("montoTotal"));
									    	montoTotal = montoTotal.replace(/,/g , '');
									    	montoTotal  = parseFloat(montoTotal);
										 	objetoPlanRendicion.montoDocumento  =  montoTotal;
									    	objetoPlanRendicion.montoIgv = "0.00";
									    	objetoPlanRendicion.indAfectoIgv = "I";
									    	objetoPlanRendicion.anio = getValueInputText("etiquetaFechaDocumentoComprobante").split("/")[2];
									    	var montoRendicion = getValueText("total_undefined");
									    	if(montoRendicion=="0.00"){
								    			montoRendicion = $.trim(getValueInputText("montoTotal"));
								    		}
									    	
									    	montoRendicion = montoRendicion.replace(/,/g , '');
									    	montoRendicion  = parseFloat(montoRendicion);
									    	objetoPlanRendicion.montoRendicion =  montoRendicion;
									    }
									    else{
									    	var valorTotal = $.trim(getValueInputText("valorTotal"));
									    	valorTotal = valorTotal.replace(/,/g , '');
									    	valorTotal  = parseFloat(valorTotal);   	
									    	objetoPlanRendicion.montoDocumento = valorTotal;
									    	
									    	var igv = $.trim(getValueText("igv"));
									    	igv = igv.replace(/,/g , '');
									    	igv  = parseFloat(igv);    	
									    	objetoPlanRendicion.montoIgv = igv;
									    	objetoPlanRendicion.indAfectoIgv = getValueInputText("exoneracionIgv");
									    	
									    	
									    	if (getValueInputText("selTipoDocumentoComprobante") == "915" || getValueInputText("selTipoDocumentoComprobante") == "067"){
									    		objetoPlanRendicion.montoRendicion =  valorTotal;	
									    	}else{
									    		var montoRendicion = getValueText("total_undefined");//esto solo es cuando se distribuyen los datos...
									    		if(montoRendicion=="0.00"){
									    			montoRendicion = $.trim(getValueInputText("valorTotal"));
									    		}
										    	montoRendicion = montoRendicion.replace(/,/g , '');
										    	montoRendicion  = parseFloat(montoRendicion);
									    		objetoPlanRendicion.montoRendicion =  montoRendicion;	
									    	}
									    }
									    
									    var otroGasto = $.trim(getValueInputText("otroGasto"));
									    otroGasto = otroGasto.replace(/,/g , '');
									    otroGasto  = parseFloat(otroGasto);
									    objetoPlanRendicion.mtoOtrosGastos = otroGasto;
										arrayListaPlanRendicion.push(objetoPlanRendicion);
										
									
										var arrayListaPlanInformeDistrib = new Array();
										
										var planInformeDistribTable = $("#tblDatosComprobantePago");	
										var planInformeDistribArray = planInformeDistribTable.jqGrid("getRowData");
										
										for(i = 0; i < planInformeDistribArray.length; i++){
											var objetoPlanInformeDistrib = new Object();
											objetoPlanInformeDistrib.fechaViaticoEntrada = getValueText("fechaViatico_"+planInformeDistribArray[i].fechaDDMMYYYY);		
											objetoPlanInformeDistrib.montoDocumentoAlimentacion = getValueInputText("alimentacion_" + planInformeDistribArray[i].fechaDDMMYYYY).replace(/,/g , '');
											objetoPlanInformeDistrib.montoDocumentoHospedaje = getValueInputText("hospedaje_"+planInformeDistribArray[i].fechaDDMMYYYY).replace(/,/g , '');
											objetoPlanInformeDistrib.montoDocumentoMovilidad = getValueInputText("movilidad_"+planInformeDistribArray[i].fechaDDMMYYYY).replace(/,/g , '');
											objetoPlanInformeDistrib.montoDocumentoTranslado = getValueInputText("translado_"+planInformeDistribArray[i].fechaDDMMYYYY).replace(/,/g , '');
											objetoPlanInformeDistrib.codConceptoOri = getValueInputText("selTipoConceptoComprobante");
											arrayListaPlanInformeDistrib.push(objetoPlanInformeDistrib);
										}
										
										/*if (getValueInputText("selTipoDocumentoComprobante") != "915" && getValueInputText("selTipoDocumentoComprobante") != "067"){
												
										}else{
											arrayListaPlanInformeDistrib = new Array();
										}*/

										$.ajax({
											url: contextPathUrl + "/registroGeneral.htm?action=registrarComprobantePago",
											data: {
												"planViajeId": parametrosEntrada.planViajeId,
												"secuencial": parametrosEntrada.secuencial,
												"fechaDocumento": objetoPlanRendicion.fechaDocumento,
												"numeroRegistroColaborador" : parametrosEntrada.numeroRegistroColaborador,			
												"listaPlanViajeRendicion": JSON.stringify(arrayListaPlanRendicion),
												"listaPlanViajeInformeDistrib": JSON.stringify(arrayListaPlanInformeDistrib)
											},
											type: "post",
											dataType: "json",
											cache: false,
											async: true,
											beforeSend: function() {
												showModalElement("divScreenBlock");
											},
											complete: function() {
												$("#divMensajeConfirmacionComprobante").modal("hide");
												hideModalElement("divScreenBlock");
											},
											success: function(result) {	
												
												 if(result.documentoSustentarioDTO.mensajeOut==0){
													 setValueInputText("txtNumeroDocumentoComprobante", result.documentoSustentarioDTO.planViajeRendicionBean.numeroDocumento);
													 setValueInputText("txtSecuenciaComprobante", result.documentoSustentarioDTO.planViajeRendicionBean.secuencial);
														 comprobantePagoService.comprobantePagoAfter(parametrosEntrada.planViajeId);					 
														 setHtmlElement("spaMensajeInformativoTituloComprobante", errorMessageRegistrarComprobante.mensajeExito);
														 $("#divMensajeInfomativoComprobante").modal("show");
												 }else if(result.documentoSustentarioDTO.mensajeOut==-1){
													 comprobantePagoService.comprobantePagoAfter("");
													 setHtmlElement("spaMensajeErrorComprobante", errorMessageRegistrarComprobante.mensajeErrorGenerico);
													 $("#divMensajeErrorComprobante").modal("show");
												 }else{
													 comprobantePagoService.comprobantePagoAfter(""); 
													 setHtmlElement("spaMensajeErrorComprobante", errorMessageRegistrarComprobante.mensajeErrorGenerico);
													 $("#divMensajeErrorComprobante").modal("show");
												 }
											},
											error: function() {
												setHtmlElement("spaMensajeErrorComprobante", errorMessageRegistrarComprobante.mensajeErrorGenerico);
												 $("#divMensajeErrorComprobante").modal("show");
												consoleLog("Error callObtenerConceptoPlanillaViaticosToComprobante");
											}
										});
								}	
}