/// <reference path="./registrarModificarSolicitud_init.js" />
/// <reference path="./registrarModificarSolicitud_rest.js" />
/// <reference path="./registrarModificarSolicitud_service.js" />
/// <reference path="./registrarModificarSolicitud_event.js" />
/// <reference path="../general/common.js" />
/// <reference path="../../WEB-INF/jsp/solicitud/registrar/registrarModificarSolicitud.jsp" />
/// <reference path="D:\jcfr\data\ts-definitions\DefinitelyTyped-master\jquery\jquery.d.ts" />

// validaciones para el agregar desplazamiento
function validarAgregarDesplazamiento() {

	var result = {
		'hayError': false,
		'msgError': null,
		'queryControlFocus': null
	};

	// validacion adicional
	if ( esNacional() ) {

		if ( esMayor4h() ) {

			if ( getTrimValue( '#fechaSalidaNacMay4h' ) == '' || getTrimValue( '#fechaRetornoNacMay4h' ) == '' ) {
				result.hayError = true;
				result.msgError = configRSV.mensajes.porFavorIngreseFechaSalidaYRetornoViatico;

				if ( getTrimValue( '#fechaSalidaNacMay4h' ) == '' ) result.queryControlFocus = '#fechaSalidaNacMay4h';
				else if ( getTrimValue( '#fechaRetornoNacMay4h' ) == '' ) result.queryControlFocus = '#fechaRetornoNacMay4h';

				return result;
			}
			
			// ya no dejar ingresar si ya ingreso el maximo
			var diasHorasProg = obtenerNumeroDiasHorasComision();
			var diasHorasDesplazamiento = calcularDiasHorasDesplazamiento();
			
			if ( esNumero( diasHorasProg ) ) {

				if ( toNumero( diasHorasDesplazamiento ) >= toNumero( diasHorasProg ) ) {

					var msg = 'No puede agregar m&aacute;s desplazamientos. No se puede exceder el n&uacute;mero de d&iacute;as programados del vi&aacute;tico (DIAS_PROGRAMADOS d&iacute;as)';
					msg = msg.replace( /DIAS_PROGRAMADOS/g, '' + diasHorasProg );
					
					result.hayError = true;
					result.msgError = msg;

					return result;
				}

			}

		} else {

			// validacion correcta con fechas y horas
			if ( getTrimValue( '#fechaNacMen4h' ) == '' || getTrimValue( '#salidaNacMen4h' ) == ''  || getTrimValue( '#retornoNacMen4h' ) == '' ) {
				result.hayError = true;
				result.msgError = configRSV.mensajes.porFavorIngreseFechaViaticoYHoras;

				if ( getTrimValue( '#fechaNacMen4h' ) == '' ) result.queryControlFocus = '#fechaNacMen4h';
				else if ( getTrimValue( '#salidaNacMen4h' ) == '' ) result.queryControlFocus = '#salidaNacMen4h';
				else if ( getTrimValue( '#retornoNacMen4h' ) == '' ) result.queryControlFocus = '#retornoNacMen4h';

				return result;
			}

			// ya no dejar ingresar si ya ingreso el maximo
			var diasHorasProg = obtenerNumeroDiasHorasComision();			
			var nroHorasDesplazamiento = calcularDiasHorasDesplazamiento();
			
			if ( esNumero( diasHorasProg ) ) {

				if ( toNumero( nroHorasDesplazamiento ) >= toNumero( diasHorasProg ) ) {

					var msg = 'No puede agregar m&aacute;s desplazamientos. No se puede exceder el n&uacute;mero de horas programadas del vi&aacute;tico (HORAS_PROGRAMADAS horas)';
					msg = msg.replace( /HORAS_PROGRAMADAS/g, '' + diasHorasProg );
					
					result.hayError = true;
					result.msgError = msg;

					return result;
				}

			}

		}

	} else {

		if ( getTrimValue( '#fechaEventoInicioInter' ) == '' || getTrimValue( '#fechaEventoFinInter' ) == ''   ) {
			result.hayError = true;
			result.msgError = configRSV.mensajes.porFavorIngreseFechaInicioFinEvento;

			if ( getTrimValue( '#fechaEventoInicioInter' ) == '' ) result.queryControlFocus = '#fechaEventoInicioInter';
			else if ( getTrimValue( '#fechaEventoFinInter' ) == '' ) result.queryControlFocus = '#fechaEventoFinInter';

			return result;
		}

		// ya no dejar ingresar si ya ingreso el maximo
		var diasHorasProg = obtenerNumeroDiasHorasComision();
		var diasHorasDesplazamiento = calcularDiasHorasDesplazamiento();
		
		if ( esNumero( diasHorasProg ) ) {

			if ( toNumero( diasHorasDesplazamiento ) >= toNumero( diasHorasProg ) ) {

				var msg = 'No puede agregar m&aacute;s desplazamientos. No se puede exceder el n&uacute;mero de d&iacute;as programados del vi&aacute;tico (DIAS_PROGRAMADOS d&iacute;as)';
				msg = msg.replace( /DIAS_PROGRAMADOS/g, '' + diasHorasProg );
				
				result.hayError = true;
				result.msgError = msg;

				return result;
			}

		}

	}

	// validacion adicional
	// verificar el ingreso correcto de fechas (ya que el usuario puede borrar los mensajes de validación)
	if ( hayFechasConError() ) {

		revalidarSiHayFechasConError();

		result.hayError = true;
		result.msgError = 'Por favor verifique las fechas ingresadas';
		result.queryControlFocus = obtenerFechaConError();
		
		// personalizacion para horas
		if ( result.queryControlFocus == '#fechaNacMen4h' ) {
			result.msgError = 'Por favor verifique la fecha ingresada';
		} else if ( result.queryControlFocus == '#salidaNacMen4h' ||  result.queryControlFocus == '#retornoNacMen4h' ) {
			result.msgError = 'Por favor verifique las horas ingresadas';
		}

		return result;
	}

	return result;
}

// validaciones para el guardar viático
function validarGuardarViatico(esGrabacion) {
	
	// validaciones locales en ambos casos: guardar o modificar	
	hideMensajeLabelDetalleViatico();
	var result = validarFechaHoraGrabarViatico();
	if(result.hayError){
		return result;
	}

	if ( esNacional() ) {
		if ( esMayor4h() ) {
			return validarGuardarViaticoNacionalMayor4h(esGrabacion);
		} else {	// si es menor o igual a 4 horas
			return validarGuardarViaticoMenorIgual4h(esGrabacion);
		}
	}

	// si es internacional
	return validarGuardarViaticoInternacional(esGrabacion);
}


function validarFechaHoraGrabarViatico(){

	var result = {
		'hayError': false,
		'msgError': null,
		'queryControlFocus': null
	};
	
	//validamos que la hora de inicio no sea mayor a la hora actual en la que se firma...
	var salidaNacMen4h = getTrimValue( '#salidaNacMen4h' );
	var fechaSalidaNacMen4h = getTrimValue( '#fechaNacMen4h' );
	var horaActual = getHoraActualString();
	var fechaActual = getCurrentDateFormatEsp();
	var fechaSalidaNacMay4h = $('#fechaSalidaNacMay4h').val();
	var fechaEventoInicioInter = $('#fechaEventoInicioInter').val();
	
	
	//Si la hora actual es mayor a la fecha ingresada entonces ERROR
	var codPlanilla = $("#txtCodPlanilla").val();
	
	
	if ( esNacional() ) {
		if ( esMayor4h() ) {
			//Validamos las fechas
			
			/*if(compararFechas(fechaActual,fechaSalidaNacMay4h)==1){
				result.hayError = true;
				result.msgError = "No se puede firmar la solicitud de viáticos "+codPlanilla+", debido a que la fecha de salida de la comision es menor a la fecha actual";
				return result;
			}*/
			
		}else{
			//Si la fecha de salida es la misma que la fecha de hoy
			if(compararFechas(fechaActual,fechaSalidaNacMen4h)==0){
				if(compararHoras(horaActual,salidaNacMen4h)==1){
					result.hayError = true;
					result.msgError = "No se puede registrar un rango de horas cuya hora de inicio sea menor a la hora actual";
				}	
			}
		}
		
	}else{
		//TODO: Verificar que funcione.
		/*if(compararFechas(fechaActual,fechaEventoInicioInter)==1){
			result.hayError = true;
			result.msgError = "No se puede firmar la solicitud de viáticos "+codPlanilla+", debido a que la fecha de inicio de evento de la comision  es menor a la fecha actual";
			return result;
		}*/
	}
	
	return result;
	
}

// validaciones para el guardar viático nacional mayor a 4horas (segundo bloque de validaciones)
function validarGuardarViaticoNacionalMayor4h(esGrabacion) {

	// validaciones locales en ambos casos (guardar o modificar) para viáticos nacionales mayores de 4 horas
	var result = {
		'hayError': false,
		'msgError': null,
		'queryControlFocus': null
	};

	var fechaSalidaNacMay4h = $('#fechaSalidaNacMay4h').val();
	var fechaRetornoNacMay4h = $('#fechaRetornoNacMay4h').val();

	//JMCR-ME-FECHA
	
	// La fecha de salida del desplazamiento de la comisión de servicio deberá ser mayor a la fecha de la operación de registro de la solicitud (ok)
	if ( esFechaValida( fechaSalidaNacMay4h ) && !esFechaMayorIgual( fechaSalidaNacMay4h, configRSV.fechaRegistro ) ) {
		result.hayError = true;
		result.msgError = configRSV.mensajes.fechaSalidaMayorIgualFechaRegistroSolicitud;
		return result;
	}

	if ( esFechaValida( fechaSalidaNacMay4h ) && esFechaMayorAnio( fechaSalidaNacMay4h ) ) {
		result.hayError = true;
		result.msgError = configRSV.mensajes.fechaSalidaMenorIgualAnio;
		return result;
	}

	// La Fecha de Retorno debe ser mayor a la fecha registro de la solicitud de viático (ok)
	if ( esFechaValida( fechaRetornoNacMay4h ) && !esFechaMayorIgual( fechaRetornoNacMay4h, configRSV.fechaRegistro ) ) {
		result.hayError = true;
		result.msgError = configRSV.mensajes.fechaRetornoMayorIgualFechaRegistroSolicitud;
		return result;
	}

	if ( esFechaValida( fechaRetornoNacMay4h ) && esFechaMayorAnio( fechaRetornoNacMay4h ) ) {
		result.hayError = true;
		result.msgError = configRSV.mensajes.fechaRetornoMenorIgualAnio;
		return result;
	}
	//JMCR-ME-FECHA

	// La Fecha de Retorno debe ser mayor a la fecha de Salida (ok)
	if ( esFechaValida( fechaRetornoNacMay4h ) && esFechaValida( fechaSalidaNacMay4h ) ) {
		if ( !esFechaMayorIgual( fechaRetornoNacMay4h, fechaSalidaNacMay4h )  ) {
			result.hayError = true;
			result.msgError = configRSV.mensajes.fechaRetornoMayorIgualFechaSalida;
			return result;
		}
	}

	// validar motivo de comision
	var txtMotivoComision = getTrimValue('#txtMotivoComision');
	if ( txtMotivoComision == '' ) {
		result.hayError = true;
		result.msgError = configRSV.mensajes.debeIngresarMotivoDesplazamientoValido;
		result.queryControlFocus = '#txtMotivoComision';
		return result;
	}
	
	// validacion adicional
	var selDepartamento = getTrimValue( '#selDepartamento' );
	if ( selDepartamento == '00' ) {
		result.hayError = true;
		result.msgError = 'Debe seleccionar un departamento de origen';
		result.queryControlFocus = '#selDepartamento';

		return result;
	}
	
	// validacion adicional
	var selProvincia = getTrimValue( '#selProvincia' );
	if ( selProvincia == '00' ) {
		result.hayError = true;
		result.msgError = 'Debe seleccionar un provincia de origen';
		result.queryControlFocus = '#selProvincia';

		return result;
	}

	// validar que haya ingresado asignaciones fijas (que haya presionado el boton calcular).
	if ( !hayAsignacionesFijasCalculadas() ) {
		result.hayError = true;
		result.msgError = configRSV.mensajes.debeCalcularAsigViaticSeleccioneCalcular;
		result.queryControlFocus = '#btnCalcularAsignacion';
		return result;
	}

	// que haya visualizado la consulta de asistencia
	if ( configRSV.consultaAsistencia.visualizo == configRSV.constantes.NO ) {
		result.hayError = true;
		result.msgError = configRSV.mensajes.debeVerificarFechasProgramandoVacasCompenLicencias;
		result.queryControlFocus = obtenerBotonAsistenciaIDSegunCaso();
		return result;
	}

	// validacion adicional, para que no se deje ingresar asignaciones con monto 0
	var concepto = buscarConceptoConImporteCero();
	if ( concepto != null ) {

		result.hayError = true;
		result.msgError = configRSV.mensajes.debeIngresarImporteMayorACeroParaConcepto + ' ' + concepto.asignacion + '.';
		return result;
	}

	
	// El total de días del viatico( sección II ) debe coincidir con la cantidad de días programados( Sección IV )
	var diasNacMay4h = getTrimValue( '#diasNacMay4h' );
	if ( diasNacMay4h != '' ) {

		var nroDiasDesplazamiento = calcularDiasHorasDesplazamiento();
		if ( toNumero( nroDiasDesplazamiento ) != toNumero( diasNacMay4h ) ) {

			var msg = configRSV.mensajes.numeroDiasViaticoNroTotalItinerario;
			msg = msg.replace( /DIAS_PROGRAMADOS/g, diasNacMay4h );
			msg = msg.replace( /SUMA_DIAS_DESPLAZAMIENTO/g, '' + nroDiasDesplazamiento );

			result.hayError = true;
			result.msgError = msg;

			return result;
		}
	}

	// No se debe exceder el monto tope diario
	var itemSuperaMontoDiario = buscarDesplazamientoQueSuperaImporteDiarioTope();
	if ( itemSuperaMontoDiario != null ) {

		var msg = configRSV.mensajes.montoDiarioNoDebeExcederTope;
		msg = msg.replace( /MONEDA_TOPE/g, configRSV.moneda );
		msg = msg.replace( /MONTO_TOPE/g, '' + itemSuperaMontoDiario.importeDiarioTope );

		result.hayError = true;
		result.msgError = msg;

		return result;
	}

	// El número de días para realizar el viático debe ser mayor a cero
	var sumaDias = calcularDiasHorasDesplazamiento();
	if ( !( sumaDias > 0 ) ) {

		var nroDiasComision = obtenerNumeroDiasHorasComision();
		
		var msg = configRSV.mensajes.debeIngresarDiasParaDesplazamiento;
		msg = msg.replace( /NRO_DIAS/g, nroDiasComision );	
		
		result.hayError = true;
		result.msgError = msg;

		return result;
	}

	var itemConDiasHorasNoValidos = buscarDesplazamientoConDiasHorasNoValidos();
	if ( itemConDiasHorasNoValidos != null ) {

		var msg = configRSV.mensajes.debeIngresarDeplazamientoConDiasValidos;
		msg = msg.replace( /NRO_DESPLAZAMIENTO/g, itemConDiasHorasNoValidos.nro );

		result.hayError = true;
		result.msgError = msg;
		result.queryControlFocus = '#diasViatico_' + itemConDiasHorasNoValidos.nro;

		return result;
	}

	var itemConImporteDiarioNoValido = buscarDesplazamientoConImporteDiarioNoValido();
	if ( itemConImporteDiarioNoValido != null ) {

		var msg = 'No es posible ingresar el desplazamiento n&uacute;mero NRO_DESPLAZAMIENTO con un importe diario igual a 0, favor de corregir';
		msg = msg.replace( /NRO_DESPLAZAMIENTO/g, itemConImporteDiarioNoValido.nro );

		result.hayError = true;
		result.msgError = msg;
		result.queryControlFocus = '#importeDiario_' + itemConImporteDiarioNoValido.nro;

		return result;
	}	

	// validación adicional (caso raro que sólo se da en viáticos menores a 4 horas)
	// que no intente registrar 0 como monto de desplazamiento
	var montoTotalDesplazamiento = calcularTotalDesplazamientos();
	if ( !( toNumero( montoTotalDesplazamiento ) > 0 ) ) {

		result.hayError = true;
		result.msgError = 'Monto total de desplazamientos debe ser mayor a cero';

		return result;
	}	
	
	// validación adicional
	// que recalculo asignaciones si la asignacion fija no coincide con el importe total de los desplazamientos
	if ( debeRecalcularAsignaciones() ) {

		result.hayError = true;
		result.msgError =  configRSV.mensajes.debeRecalcularAsignaciones;
		result.queryControlFocus = '#btnCalcularAsignacion';

		return result;
	}

	// validacion adicional
	// que seleccione meta / afectacion presupuestal
	var txtCodigoMetaPresupuestal = getTrimValue( '#txtCodigoMetaPresupuestal' );
	if ( txtCodigoMetaPresupuestal == '' ) {

		result.hayError = true;
		result.msgError = 'Por favor seleccione una meta';
		result.queryControlFocus = '#btnAfectacionPresupuestal';

		return result;
	}	
	
	// que no supere los 15 dias habiles
	var diasNacMay4hHabiles = getTrimValue( '#diasNacMay4hHabiles' );
	if ( diasNacMay4hHabiles != '' ) {

		if ( toNumero( diasNacMay4hHabiles ) >  toNumero( configRSV.constantes.MAXIMO_NRO_DIAS_HABILES ) ) {

			validarGuardarViaticoNacionalMayor4hSegundoBloque( result, esGrabacion );

			//ya se invoca a la grabación desde clickBtnGrabarViatico
			//evaluarYContinuarGrabarModificar( result, esGrabacion );

			return result;
		}
	}

	// realizar el 2do bloque de validaciones despues del confirm de 15 dias habiles
	validarGuardarViaticoNacionalMayor4hSegundoBloque( result, esGrabacion )

	return result;
}

// validaciones para el guardar viático nacional mayor a 4horas (segundo bloque de validaciones)
// NOTA: este debería ser la última validación antes de enviar a guardar/modificar
function validarGuardarViaticoNacionalMayor4hSegundoBloque(result, esGrabacion) {

	// SEGUNDO BLOQUE DE VALIDACIONES DESPUES DEL CONFIRMAR

	// NOTA: ESTA DEBE SER LA ÚLTIMA VALIDACIÓN
	// validacion de traslape de fechas (petición síncrona)
	var codColaborador = getTrimValue( '#hidCodigoColaborador' );
	var fechaSalida = getTrimValue( '#fechaSalidaNacMay4h' );
	var fechaRetorno = getTrimValue( '#fechaRetornoNacMay4h' );
	var codPlanViaje = getTrimValue( '#hidCodPlanViaje' );  // sólo tiene valor cuando es modificación

	if ( esFechaValida( fechaSalida ) || esFechaValida( fechaRetorno ) ) {
		
		callAjaxValidarTraslapeFechas(false, codColaborador, fechaSalida, fechaRetorno, codPlanViaje).then( function(response) {

			if ( huboErrorAjax( response ) ) {
				result.hayError = true;
				handleErrorAjax( response );
				return;
			}

			// actualizar nuevo indicador de traslape
			setValueInputText( 'hidIndicadorTraslape', response.traslapeFechas == configRSV.constantes.SI ? '1' : '0' );
			
			if ( response.traslapeFechas == 'si' ) {
				
				var msg = configRSV.mensajes.existePlanillaNombreComisionadoEnRango;
				msg = msg.replace( /NRO_SOLICITUD/g, response.traslapeFechasNroSolicitud );
				msg = msg.replace( /FECHA_INICIO/g, response.traslapeFechasInicio );
				msg = msg.replace( /FECHA_FINAL/g, response.traslapeFechasFinal );
				msg = msg + '<br >' + configRSV.mensajes.deSerFechasCorrectasDistintaComisionAdjuntarSust;

				// NOTA: ahora cuando hay traslape lo deja pasar para que grabe.
				//       muestra el popup pero al aceptar realiza la grabación (por tanto se debe personalizar el botón aceptar).
				//       por ese motivo ésta validación de traslape debe ser la última validación
				//       se le crea una acción particular para que al evaluarYContinuarGrabarModificar() tome un resultOK y llegue a los callAjax
				result.hayError = false;
				result.msgError = msg;
				result.accionParticular = function() {
					
					var resultOK = {
						'hayError': false,
						'msgError': null,
						'queryControlFocus': null
					};
					
					evaluarYContinuarGrabarModificar( resultOK, esGrabacion );
					
				};
				
				return; // sale de la funcion dentro del then()
			}

			//alert("aqui me quede");

		}, function( error ) {
			result.hayError = true;
			handleError( error );
			return;
		});

		// por la invocacion sincrona, el objeto result pudo cambiar
		if ( result.hayError ) {
			return result;
		}

	}
	
	// NOTA: este return no tiene mucha importancia, dado que todo esta result
	return result;
}

// validaciones para el guardar viático nacional menor igual a 4 horas
function validarGuardarViaticoMenorIgual4h(esGrabacion) {

	// validaciones locales en ambos casos (guardar o modificar) para viáticos nacionales menores o iguales de 4 horas
	var result = {
		'hayError': false,
		'msgError': null,
		'queryControlFocus': null
	};

	//JMCR-ME-FECHA
	// validacion adicional
	// valida fecha mayor a la registro.
	var fechaNacMen4h = getTrimValue( '#fechaNacMen4h' );
	if ( esFechaValida( fechaNacMen4h ) && !esFechaMayorIgual( fechaNacMen4h, configRSV.fechaRegistro ) ) {

		result.hayError = true;
		result.msgError = configRSV.mensajes.fechaViaticoMayorIgualFechaRegistro;
		result.queryControlFocus = '#fechaNacMen4h';

		return result;
	}

	if ( esFechaValida( fechaNacMen4h ) && esFechaMayorAnio( fechaNacMen4h ) ) {

		result.hayError = true;
		result.msgError = configRSV.mensajes.fechaViaticoMenorIgualAnio;
		result.queryControlFocus = '#fechaNacMen4h';

		return result;
	}
	//JMCR-ME-FECHA
	
	// validacion adicional
	// validar motivo de comision
	var txtMotivoComision = getTrimValue( '#txtMotivoComision' );
	if ( txtMotivoComision == '' ) {
		result.hayError = true;
		result.msgError = configRSV.mensajes.debeIngresarMotivoDesplazamientoValido;
		result.queryControlFocus = '#txtMotivoComision';

		return result;
	}
	
	// validacion adicional
	var selDepartamento = getTrimValue( '#selDepartamento' );
	if ( selDepartamento == '00' ) {
		result.hayError = true;
		result.msgError = 'Debe seleccionar un departamento de origen';
		result.queryControlFocus = '#selDepartamento';

		return result;
	}
	
	// validacion adicional
	var selProvincia = getTrimValue( '#selProvincia' );
	if ( selProvincia == '00' ) {
		result.hayError = true;
		result.msgError = 'Debe seleccionar un provincia de origen';
		result.queryControlFocus = '#selProvincia';

		return result;
	}	

	// valida que ingrese las horas de salida y retorno
	var salidaNacMen4h = getTrimValue( '#salidaNacMen4h' );
	var retornoNacMen4h = getTrimValue( '#retornoNacMen4h' );

	if ( salidaNacMen4h == '' || retornoNacMen4h == '' ) {
		result.hayError = true;
		result.msgError = configRSV.mensajes.seDebeSeleccionarLasHorasDeDeplazamiento;

		if ( salidaNacMen4h == '' ) result.queryControlFocus = '#salidaNacMen4h';
		else if ( retornoNacMen4h == '' ) result.queryControlFocus = '#retornoNacMen4h';

		return result;
	}

	/* -1: err, 1: f1>f2, 2: f1<f2, 0: f1=f2 */
	var diferencia = compararHoras( retornoNacMen4h, salidaNacMen4h );
	if ( diferencia == 0 || diferencia == 2 ) {  	// no es -1 (formato) y no es 1
		result.hayError = true;
		result.msgError = configRSV.mensajes.horaRetornoMayorHoraSalida;
		result.queryControlFocus = '#retornoNacMen4h';

		return result;
	}

	var horasNacMen4h = getTrimValue( '#horasNacMen4h' );
	if ( horasNacMen4h != '' && toNumero( horasNacMen4h ) > 4.0 ) {
		
		result.hayError = true;
		result.msgError = configRSV.mensajes.diferenciaHoraRetornoSalidaNoSupereHoras;
		result.queryControlFocus = '#retornoNacMen4h';

		return result;	
	}	
	
	// validacion adicional
	if ( horasNacMen4h != '' && toNumero( horasNacMen4h ) <= 0.0 ) {
		
		result.hayError = true;
		result.msgError = configRSV.mensajes.diferenciaHoraRetornoSalidaSupereCero;
		result.queryControlFocus = '#retornoNacMen4h';

		return result;	
	}		
	
	// validar que haya ingresado asignaciones fijas (que haya presionado el boton calcular).
	if ( !hayAsignacionesFijasCalculadas() ) {
		result.hayError = true;
		result.msgError = configRSV.mensajes.debeCalcularAsigViaticSeleccioneCalcular;
		result.queryControlFocus = '#btnCalcularAsignacion';
		return result;
	}

	// que haya visualizado la consulta de asistencia
	if ( configRSV.consultaAsistencia.visualizo == configRSV.constantes.NO ) {
		result.hayError = true;
		result.msgError = configRSV.mensajes.debeVerificarFechasProgramandoVacasCompenLicencias;
		result.queryControlFocus = obtenerBotonAsistenciaIDSegunCaso();

		return result;
	}

	// validacion adicional
	// para que no se deje ingresar asignaciones con monto 0
	var concepto = buscarConceptoConImporteCero();
	if ( concepto != null ) {

		result.hayError = true;
		result.msgError = configRSV.mensajes.debeIngresarImporteMayorACeroParaConcepto + ' ' + concepto.asignacion + '.';

		return result;
	}

	// Validara que el total de horas de la sección II y la sección IV difieren en el número de horas
	if ( horasNacMen4h != '' ) {

		var nroHorasDesplazamiento = calcularDiasHorasDesplazamiento();
		if ( toNumero( nroHorasDesplazamiento ) != toNumero( horasNacMen4h ) ) {

			// var msg = configRSV.mensajes.cantidadHorasSeccionIIySeccionIVNoCoinciden;
			
			var msg = configRSV.mensajes.numeroHorasViaticoNroTotalItinerario;
			msg = msg.replace( /HORAS_PROGRAMADAS/g, horasNacMen4h );
			msg = msg.replace( /SUMA_HORAS_DESPLAZAMIENTO/g, '' + nroHorasDesplazamiento );

			result.hayError = true;
			result.msgError = msg;

			return result;
		}
	}

	var itemConDiasHorasNoValidos = buscarDesplazamientoConDiasHorasNoValidos();
	if ( itemConDiasHorasNoValidos != null ) {

		var msg = configRSV.mensajes.debeIngresarDeplazamientoConHorasValidos;
		msg = msg.replace( /NRO_DESPLAZAMIENTO/g, itemConDiasHorasNoValidos.nro );

		result.hayError = true;
		result.msgError = msg;
		result.queryControlFocus = '#horasViatico_' + itemConDiasHorasNoValidos.nro;

		return result;
	}	
	
	// validación adicional (caso raro que sólo se da en viáticos menores a 4 horas)
	// que no intente registrar 0 como monto de desplazamiento
	var montoTotalDesplazamiento = calcularTotalDesplazamientos();
	if ( !( toNumero( montoTotalDesplazamiento ) > 0 ) ) {

		result.hayError = true;
		result.msgError = 'Monto total de desplazamientos debe ser mayor a cero';

		return result;
	}	

	// validación adicional
	// que recalculo asignaciones si la asignacion fija no coincide con el importe total de los desplazamientos
	if ( debeRecalcularAsignaciones() ) {

		result.hayError = true;
		result.msgError =  configRSV.mensajes.debeRecalcularAsignaciones;
		result.queryControlFocus = '#btnCalcularAsignacion';

		return result;
	}

	var itemConImporteDiarioNoValido = buscarDesplazamientoConImporteDiarioNoValido();
	if ( itemConImporteDiarioNoValido != null ) {

		var msg = 'No es posible ingresar el desplazamiento n&uacute;mero NRO_DESPLAZAMIENTO con un importe diario igual a 0, favor de corregir';
		msg = msg.replace( /NRO_DESPLAZAMIENTO/g, itemConImporteDiarioNoValido.nro );

		result.hayError = true;
		result.msgError = msg;
		result.queryControlFocus = '#importeDiario_' + itemConImporteDiarioNoValido.nro;

		return result;
	}

	// validacion adicional
	// que seleccione meta / afectacion presupuestal
	var txtCodigoMetaPresupuestal = getTrimValue( '#txtCodigoMetaPresupuestal' );
	if ( txtCodigoMetaPresupuestal == '' ) {

		result.hayError = true;
		result.msgError = 'Por favor seleccione una meta';
		result.queryControlFocus = '#btnAfectacionPresupuestal';

		return result;
	}		

	// NOTA: ESTA DEBE SER LA ÚLTIMA VALIDACIÓN
	// validacion de traslape de fechas (petición síncrona)
	var codColaborador = getTrimValue( '#hidCodigoColaborador' );
	var fechaSalida = getTrimValue( '#fechaNacMen4h' );
	var fechaRetorno = getTrimValue( '#fechaNacMen4h' );
	var codPlanViaje = getTrimValue( '#hidCodPlanViaje' );	// sólo tiene valor cuando es modificación

	if ( esFechaValida( fechaSalida ) || esFechaValida( fechaRetorno ) ) {

		callAjaxValidarTraslapeFechas(false, codColaborador, fechaSalida, fechaRetorno, codPlanViaje).then( function(response) {

			if ( huboErrorAjax( response ) ) {
				result.hayError = true;
				handleErrorAjax( response );
				return;
			}

			// actualizar nuevo indicador de traslape
			setValueInputText( 'hidIndicadorTraslape', response.traslapeFechas == configRSV.constantes.SI ? '1' : '0' );
			
			if ( response.traslapeFechas == 'si' ) {
				
				var msg = configRSV.mensajes.existePlanillaNombreComisionadoEnRango;
				msg = msg.replace( /NRO_SOLICITUD/g, response.traslapeFechasNroSolicitud );
				msg = msg.replace( /FECHA_INICIO/g, response.traslapeFechasInicio );
				msg = msg.replace( /FECHA_FINAL/g, response.traslapeFechasFinal );
				msg = msg + '<br >' + configRSV.mensajes.deSerFechasCorrectasDistintaComisionAdjuntarSust;

				// NOTA: ahora cuando hay traslape lo deja pasar para que grabe.
				// se le crea una acción particular para que al evaluarYContinuarGrabarModificar() tome un resultOK y llegue a los callAjax
				result.hayError = false;
				result.msgError = msg;
				result.accionParticular = function() {
					
					var resultOK = {
						'hayError': false,
						'msgError': null,
						'queryControlFocus': null
					};
					
					evaluarYContinuarGrabarModificar( resultOK, esGrabacion );
					
				};

				return; // sale de la funcion dentro del then()
			}

		}, function( error ) {
			result.hayError = true;
			
			handleError( error );
			return;
		});

		return result;
	}

	return result;
}

// validaciones para el guardar viático internacional
function validarGuardarViaticoInternacional(esGrabacion) {

	// validaciones locales en ambos casos (guardar o modificar) para viáticos internacionales
	var result = {
		'hayError': false,
		'msgError': null,
		'queryControlFocus': null
	};

	var fechaItinerarioInicioInter = $('#fechaItinerarioInicioInter').val();
	var fechaItinerarioFinInter = $('#fechaItinerarioFinInter').val();
	var fechaEventoInicioInter = getTrimValue('#fechaEventoInicioInter');
	var fechaEventoFinInter = getTrimValue('#fechaEventoFinInter');
	var fechaResolucionInter = getTrimValue( '#fechaResolucionInter' );
	var fechaEventoInicioInter = getTrimValue( '#fechaEventoInicioInter' );

	// validacion adicional
	// la fecha de ini. Itinerario sea mayor a la fecha de registro de  la solicitud de viáticos (ok)
	if ( esFechaValida( fechaItinerarioInicioInter ) && !esFechaMayor( fechaItinerarioInicioInter, configRSV.fechaRegistro ) ) {

		result.hayError = true;
		result.msgError = configRSV.mensajes.fechaInicioItinerarioMayorFechaRegistro;
		result.queryControlFocus = '#fechaItinerarioInicioInter';

		return result;
	}

	// validacion adicional
	// que la fecha fin del itinerario sea mayor a la fecha de ini. Itinerario (ok)
	if ( esFechaValida( fechaItinerarioFinInter ) && esFechaValida( fechaItinerarioInicioInter ) ) {
		if ( !esFechaMayorIgual( fechaItinerarioFinInter, fechaItinerarioInicioInter )  ) {

			result.hayError = true;
			result.msgError = configRSV.mensajes.fechaTerminoItinerarioDebeMayoFechaInicioItinerario;
			result.queryControlFocus = '#fechaItinerarioFinInter';

			return result;
		}
	}

	// validacion adicional
	// que la fecha de inicio del evento sea mayor a la fecha de registro de operación de la solicitud de viáticos (ok)
	if ( esFechaValida( fechaEventoInicioInter ) && !esFechaMayor( fechaEventoInicioInter, configRSV.fechaRegistro ) ) {

		result.hayError = true;
		result.msgError = configRSV.mensajes.fechaInicioEventoMayorFechaRegistroSolicitud;
		result.queryControlFocus = '#fechaEventoInicioInter';

		return result;
	}

	// validacion adicional
	// la fecha de ini. Evento sea mayor o igual a la fecha de inicio del Itinerario (ok)
	if ( esFechaValida( fechaEventoInicioInter ) && esFechaValida( fechaItinerarioInicioInter ) ) {
		if ( !esFechaMayorIgual( fechaEventoInicioInter, fechaItinerarioInicioInter ) ) {
			result.hayError = true;
			result.msgError = configRSV.mensajes.fechaInicioEventoMayorIgualFechaInicioItinerario;
			result.queryControlFocus = '#fechaEventoInicioInter';

			return result;
		}
	}

	//JMCR-ME-FECHA
	// validacion adicional
	// La fecha término del evento sea mayor a la fecha de Inicio del evento (ok)
	if ( esFechaValida( fechaEventoFinInter ) && esFechaValida( fechaEventoInicioInter ) ) {
		if ( !esFechaMayorIgual( fechaEventoFinInter, fechaEventoInicioInter )  ) {
			result.hayError = true;
			result.msgError = configRSV.mensajes.fechaInicioEventoMayorIgualFechaInicioEvento;
			result.queryControlFocus = '#fechaEventoFinInter';

			return result;
		}
	}

	if ( esFechaValida( fechaItinerarioInicioInter ) && esFechaMayorAnio( fechaItinerarioInicioInter ) ) {
		result.hayError = true;
		result.msgError = configRSV.mensajes.fechaInicioItinerarioAnio;
		result.queryControlFocus = '#fechaItinerarioInicioInter';
		return result;
	}

	if ( esFechaValida( fechaItinerarioFinInter ) && esFechaMayorAnio( fechaItinerarioFinInter ) ) {
		result.hayError = true;
		result.msgError = configRSV.mensajes.fechaFinItinerarioAnio;
		result.queryControlFocus = '#fechaItinerarioFinInter';
		return result;
	}	
	
	//JMCR-ME-FECHA
	
	// validacion adicional
	// si ingreso fecha de inicio de itinerario (solo por legibilidad de código respecto al F2)
	if ( fechaItinerarioInicioInter != '' ) {
		// las fechas de inicio del itinerario, el sistema validara que este sea menor o igual a la fecha de inicio del evento (ok)
		if ( esFechaValida( fechaItinerarioInicioInter ) && esFechaValida( fechaEventoInicioInter ) ) {
			if ( !esFechaMenorIgual( fechaItinerarioInicioInter, fechaEventoInicioInter )  ) {
				result.hayError = true;
				result.msgError = configRSV.mensajes.fechaInicioItinerarioMenorIgualInicioEvento;
				result.queryControlFocus = '#fechaEventoFinInter';

				return result;
			}
		}
	}

	// validacion adicional
	// si ingreso fecha de fin de itinerario (solo por legibilidad de código respecto al F2)
	if ( fechaItinerarioFinInter != '' ) {
		// las fechas de fin del itinerario, el sistema validara que este sea mayor o igual a la fecha de fin del evento (ok)
		if ( esFechaValida( fechaItinerarioFinInter ) && esFechaValida( fechaEventoFinInter ) ) {
			if ( !esFechaMayorIgual( fechaItinerarioFinInter, fechaEventoFinInter )  ) {
				result.hayError = true;
				result.msgError = configRSV.mensajes.fechaFinItinerarioMayorIgualFechaFinEvento;
				result.queryControlFocus = '#fechaEventoFinInter';

				return result;
			}
		}
	}

	// validacion adicional
	if ( esFechaValida( fechaResolucionInter ) ) {
		// la fecha de resolución es mayor a la fecha de registro (ok)
		if ( !esFechaMenor( fechaResolucionInter, configRSV.fechaRegistro ) ) {
			result.hayError = true;
			result.msgError = configRSV.mensajes.fechaResolucionMenorFecharegistroMenorProgEvento;
			result.queryControlFocus = '#fechaResolucionInter';

			return result;
		}
	}

	// validacion adicional
	if ( esFechaValida( fechaResolucionInter ) && esFechaValida( fechaEventoInicioInter ) ) {
		// la fecha de resolución es menor a la fecha de registro y menor a la fecha de programación del evento (ok)
		if ( !esFechaMenor( fechaResolucionInter, fechaEventoInicioInter ) ) {
			result.hayError = true;
			result.msgError = configRSV.mensajes.fechaResolucionMenorFecharegistroMenorProgEvento;
			result.queryControlFocus = '#fechaResolucionInter';

			return result;
		}
	}
	
	// validacion adicional
	// validar motivo de comision
	var txtMotivoComision = getTrimValue( '#txtMotivoComision' );
	if ( txtMotivoComision == '' ) {
		result.hayError = true;
		result.msgError = configRSV.mensajes.debeIngresarMotivoDesplazamientoValido;
		result.queryControlFocus = '#txtMotivoComision';

		return result;
	}	
	
	// validacion adicional
	var selDepartamento = getTrimValue( '#selDepartamento' );
	if ( selDepartamento == '00' ) {
		result.hayError = true;
		result.msgError = 'Debe seleccionar un departamento de origen';
		result.queryControlFocus = '#selDepartamento';

		return result;
	}
	
	// validacion adicional	
	var selProvincia = getTrimValue( '#selProvincia' );
	if ( selProvincia == '00' ) {
		result.hayError = true;
		result.msgError = 'Debe seleccionar un provincia de origen';
		result.queryControlFocus = '#selProvincia';

		return result;
	}		

	// El número de días para realizar el viático debe ser mayor a cero
	var sumaDias = calcularDiasHorasDesplazamiento();
	if ( !( sumaDias > 0 ) ) {
		
		var nroDiasComision = obtenerNumeroDiasHorasComision();
		
		var msg = configRSV.mensajes.debeIngresarDiasParaDesplazamiento;
		msg = msg.replace( /NRO_DIAS/g, nroDiasComision );			
		
		result.hayError = true;
		result.msgError = msg;

		return result;
	}

	var itemConDiasHorasNoValidos = buscarDesplazamientoConDiasHorasNoValidos();
	if ( itemConDiasHorasNoValidos != null ) {

		var msg = configRSV.mensajes.debeIngresarDeplazamientoConDiasValidos;
		msg = msg.replace( /NRO_DESPLAZAMIENTO/g, itemConDiasHorasNoValidos.nro );

		result.hayError = true;
		result.msgError = msg;
		result.queryControlFocus = '#diasViatico_' + itemConDiasHorasNoValidos.nro;

		return result;
	}

	// que haya visualizado la consulta de asistencia
	if ( configRSV.consultaAsistencia.visualizo == configRSV.constantes.NO ) {
		result.hayError = true;
		result.msgError = configRSV.mensajes.debeVerificarFechasProgramandoVacasCompenLicencias;
		result.queryControlFocus = obtenerBotonAsistenciaIDSegunCaso();

		return result;
	}

	// validar se cuente con al menos un desplazamiento
	var hayDesplazamientos = getDesplazamientosList().length > 0;
	if ( !hayDesplazamientos ) {
		result.hayError = true;
		result.msgError = configRSV.mensajes.debeIngresarAlMenosUnDesplazamiento;
		return result;
	}

	// validar que haya ingresado asignaciones fijas (que haya presionado el boton calcular).
	if ( !hayAsignacionesFijasCalculadas() ) {
		result.hayError = true;
		result.msgError = configRSV.mensajes.debeCalcularAsigViaticSeleccioneCalcular;
		result.queryControlFocus = '#btnCalcularAsignacion';
		return result;
	}

	// validacion adicional
	// que seleccione meta / afectacion presupuestal
	var txtCodigoMetaPresupuestal = getTrimValue( '#txtCodigoMetaPresupuestal' );
	if ( txtCodigoMetaPresupuestal == '' ) {

		result.hayError = true;
		result.msgError = 'Por favor seleccione una meta';
		result.queryControlFocus = '#btnAfectacionPresupuestal';

		return result;
	}	

	// El total de días del viático( sección II ) debe coincidir con la cantidad de días programados( Sección IV )
	var diasInter = getTrimValue('#diasInter');
	if ( diasInter != '' ) {

		var nroDiasDesplazamiento = calcularDiasHorasDesplazamiento();
		if ( toNumero( nroDiasDesplazamiento ) != toNumero( diasInter ) ) {

			var msg = configRSV.mensajes.numeroDiasViaticoNroTotalItinerario;
			msg = msg.replace( /DIAS_PROGRAMADOS/g, diasInter );
			msg = msg.replace( /SUMA_DIAS_DESPLAZAMIENTO/g, '' + nroDiasDesplazamiento );

			result.hayError = true;
			result.msgError = msg;

			return result;
		}
	}

	// No se debe exceder el traslado máximo
	var itemSuperaDiasTraslado = buscarDesplazamientoInternacionalQueSupereDiasTrasladoTope();
	if ( itemSuperaDiasTraslado != null ) {

		var msg = configRSV.mensajes.topeMaxAsigDiasTraslado;
		msg = msg.replace( /NRO_DIAS/g, itemSuperaDiasTraslado.diasTrasladoTope );

		result.hayError = true;
		result.msgError = msg;

		return result;
	}

	// No se debe exceder el monto tope diario
	var itemSuperaMontoDiario = buscarDesplazamientoQueSuperaImporteDiarioTope();
	if ( itemSuperaMontoDiario != null ) {

		var msg = configRSV.mensajes.montoDiarioNoDebeExcederTope;
		msg = msg.replace( /MONEDA_TOPE/g, configRSV.moneda );
		msg = msg.replace( /MONTO_TOPE/g, '' + itemSuperaMontoDiario.importeDiarioTope );

		result.hayError = true;
		result.msgError = msg;

		return result;
	}

	// No se debe exceder el monto tope para gastos de instalación y traslado
	var itemSuperaViajeExtGtoTras = buscarDesplazamientoQueSuperaViajeExtGtoTrasTope();
	if ( itemSuperaViajeExtGtoTras != null ) {

		var msg = configRSV.mensajes.topeMaxAsigGastosInstTraslado; // x2
		msg = msg.replace( /MONTO_TOPE/g, '' + itemSuperaViajeExtGtoTras.viajeExtGtoTrasTope );

		result.hayError = true;
		result.msgError = msg;

		return result;
	}
	
	var itemConImporteDiarioNoValido = buscarDesplazamientoConImporteDiarioNoValido();
	if ( itemConImporteDiarioNoValido != null ) {

		var msg = 'No es posible ingresar el desplazamiento n&uacute;mero NRO_DESPLAZAMIENTO con un importe diario igual a 0, favor de corregir';
		msg = msg.replace( /NRO_DESPLAZAMIENTO/g, itemConImporteDiarioNoValido.nro );

		result.hayError = true;
		result.msgError = msg;
		result.queryControlFocus = '#importeDiario_' + itemConImporteDiarioNoValido.nro;

		return result;
	}

	// validación adicional (caso raro que sólo se da en viáticos menores a 4 horas)
	// que no intente registrar 0 como monto de desplazamiento
	var montoTotalDesplazamiento = calcularTotalDesplazamientos();
	if ( !( toNumero( montoTotalDesplazamiento ) > 0 ) ) {

		result.hayError = true;
		result.msgError = 'Monto total de desplazamientos debe ser mayor a cero';

		return result;
	}	
		
	// validación adicional
	// que recalculo asignaciones si la asignacion fija no coincide con el importe total de los desplazamientos
	if ( debeRecalcularAsignaciones() ) {

		result.hayError = true;
		result.msgError =  configRSV.mensajes.debeRecalcularAsignaciones;
		result.queryControlFocus = '#btnCalcularAsignacion';

		return result;
	}	
	
	// NOTA: ESTA DEBE SER LA ÚLTIMA VALIDACIÓN
	// validacion de traslape de fechas (petición síncrona)
	var codColaborador = getTrimValue( '#hidCodigoColaborador' );
	var fechaSalida = getTrimValue( '#fechaEventoInicioInter' );
	var fechaRetorno = getTrimValue( '#fechaEventoFinInter' );
	var codPlanViaje = getTrimValue( '#hidCodPlanViaje' );	// sólo tiene valor cuando es modificación

	if ( esFechaValida( fechaSalida ) || esFechaValida( fechaRetorno ) ) {
		
		callAjaxValidarTraslapeFechas(false, codColaborador, fechaSalida, fechaRetorno, codPlanViaje).then( function(response) {

			if ( huboErrorAjax( response ) ) {
				result.hayError = true;
				handleErrorAjax( response );
				return;
			}
			
			// actualizar nuevo indicador de traslape
			setValueInputText( 'hidIndicadorTraslape', response.traslapeFechas == configRSV.constantes.SI ? '1' : '0' );

			if ( response.traslapeFechas == 'si' ) {
				
				var msg = configRSV.mensajes.existePlanillaNombreComisionadoEnRango;
				msg = msg.replace( /NRO_SOLICITUD/g, response.traslapeFechasNroSolicitud );
				msg = msg.replace( /FECHA_INICIO/g, response.traslapeFechasInicio );
				msg = msg.replace( /FECHA_FINAL/g, response.traslapeFechasFinal );
				msg = msg + '<br >' + configRSV.mensajes.deSerFechasCorrectasDistintaComisionAdjuntarSust;

				// NOTA: ahora cuando hay traslape lo deja pasar para que grabe.
				// se le crea una acción particular para que al evaluarYContinuarGrabarModificar() tome un resultOK y llegue a los callAjax
				result.hayError = false;
				result.msgError = msg;
				result.accionParticular = function() {
					
					var resultOK = {
						'hayError': false,
						'msgError': null,
						'queryControlFocus': null
					};
					
					evaluarYContinuarGrabarModificar( resultOK,  esGrabacion );
					
				};

				return; // sale de la funcion dentro del then()
			}

		}, function( error ) {
			result.hayError = true;

			handleError( error );
			return;
		});

		return result;
	}

	return result;
}

//continúa el proceso de grabar o modificar según caso, después de su validación 
function evaluarYContinuarGrabarModificar( result, esGrabacion ) {

	//alert("valor de result: " + result);

	if ( !estaDefinido( result ) ) return;
	
	//alert("valor de result.hayError: " + result.hayError);	
	
	// CASO PARTICULAR QUE VENGA UNA ACCION A EJECUTAR
	if ( estaDefinido( result.accionParticular ) ) {
		
		showMensaje( result.msgError, result.accionParticular );
		
		// la acción particular no deja pasar a los callAjax
		return;
		
	} else {
		
		// CASO NORMAL
		
		// si hay error
		if ( result.hayError ) {
			// si viene el mensaje de error
			if ( estaDefinido( result.msgError ) ) {
				// si viene el control para darle foco
				if ( estaDefinido( result.queryControlFocus ) ) {
					// muestra mensaje dejandole el foco al control despues de aceptar
					showMensaje( result.msgError, function() {
						darFoco( result.queryControlFocus );
					});
				} else {
					// solo muestra el mensaje sin dejar foco
					showMensaje( result.msgError );
				}
			}
			
			// si hay error no deja pasar a los callAjax
			return;
		}		
		
	}
	

	// CASO: solicitud con traslape rechazado
	// si una solicitud con traslape rechazado y que sus fechas han cambiado (ya no tiene las mismas fechas que el autorizador universal rechazó)
	// se debe resetear el indicador de autorización a 0 
	if ( getTrimValue( '#hidIndicadorTraslapeAnterior' ) == '1' ) {
		if ( getTrimValue( '#hidIndicadorAutorizacionAnterior' ) == '2' ) {
			
			if ( huboCambioDeFechas() ) {
				$( '#hidFlagResetearTraslapeAutorizacion' ).val( '1' );	
			}			
			
		}
	}	

	// invocar al guardar viático
	if ( esRegistrar() ) {
		// validaciones finales lado servidor
		if (esGrabacion) {
		callAjaxValidarGuardarViatico();
		}
	} else {
		// validaciones finales lado servidor
		callAjaxValidarModificarViatico();
	}

}

// validaciones para el cálculo de asignaciones
function validarCalcularAsignacion() {

	var result = {
		'hayError': false,
		'msgError': null,
		'queryControlFocus': null
	};

	if ( esNacional() ) {

		if ( esMayor4h() ) {

			var fechaSalidaNacMay4h = getTrimValue( '#fechaSalidaNacMay4h' );
			var fechaRetornoNacMay4h = getTrimValue( '#fechaRetornoNacMay4h' );

			// validacion adicional
			if ( fechaSalidaNacMay4h == '' || fechaRetornoNacMay4h == '' ) {
				result.hayError = true;
				result.msgError = configRSV.mensajes.porFavorIngreseFechaSalidaYRetornoViatico;
				if ( fechaSalidaNacMay4h == '' ) result.queryControlFocus = '#fechaSalidaNacMay4h';
				else if ( fechaRetornoNacMay4h == '' ) result.queryControlFocus = '#fechaRetornoNacMay4h';
				return result;
			}

			//JMCR-ME-FECHA
			// La fecha de salida del desplazamiento de la comisión de servicio deberá ser mayor a la fecha de la operación de registro de la solicitud (ok)
			if ( esFechaValida( fechaSalidaNacMay4h ) && !esFechaMayorIgual( fechaSalidaNacMay4h, configRSV.fechaRegistro ) ) {
				result.hayError = true;
				result.msgError = configRSV.mensajes.fechaSalidaMayorIgualFechaRegistroSolicitud;
				result.queryControlFocus = '#fechaSalidaNacMay4h';
				return result;
			}

			if ( esFechaValida( fechaSalidaNacMay4h ) && esFechaMayorAnio( fechaSalidaNacMay4h ) ) {
				result.hayError = true;
				result.msgError = configRSV.mensajes.fechaSalidaMenorIgualAnio;
				result.queryControlFocus = '#fechaSalidaNacMay4h';
				return result;
			}

			// La Fecha de Retorno debe ser mayor igual a la fecha de Salida (ok)
			if ( esFechaValida( fechaRetornoNacMay4h ) && esFechaValida( fechaSalidaNacMay4h ) ) {
				if ( !esFechaMayorIgual( fechaRetornoNacMay4h, fechaSalidaNacMay4h )  ) {
					result.hayError = true;
					result.msgError = configRSV.mensajes.fechaRetornoMayorIgualFechaSalida;
					result.queryControlFocus = '#fechaRetornoNacMay4h';
					return result;
				}
			}			

			if ( esFechaValida( fechaRetornoNacMay4h ) && esFechaMayorAnio( fechaRetornoNacMay4h ) ) {
				result.hayError = true;
				result.msgError = configRSV.mensajes.fechaRetornoMenorIgualAnio;
				result.queryControlFocus = '#fechaRetornoNacMay4h';
				return result;
			}		
			
			// La Fecha de Retorno debe ser mayor a la fecha registro de la solicitud de viático (validacion demas)
			if ( esFechaValida( fechaRetornoNacMay4h ) && !esFechaMayorIgual( fechaRetornoNacMay4h, configRSV.fechaRegistro ) ) {
				result.hayError = true;
				result.msgError = configRSV.mensajes.fechaRetornoMayorIgualFechaRegistroSolicitud;
				result.queryControlFocus = '#fechaRetornoNacMay4h';
				return result;
			}
			//JMCR-ME-FECHA	

			// validar motivo de comision
			var txtMotivoComision = getTrimValue('#txtMotivoComision');
			if ( txtMotivoComision == '' ) {
				result.hayError = true;
				result.msgError = configRSV.mensajes.debeIngresarMotivoDesplazamientoValido;
				result.queryControlFocus = '#txtMotivoComision';
				return result;
			}

			// que haya visualizado la consulta de asistencia
			if ( configRSV.consultaAsistencia.visualizo == configRSV.constantes.NO ) {
				result.hayError = true;
				result.msgError = configRSV.mensajes.debeVerificarFechasProgramandoVacasCompenLicencias;
				result.queryControlFocus = obtenerBotonAsistenciaIDSegunCaso();
				return result;
			}

			// El total de días del viático( sección II ) debe coincidir con la cantidad de días programados( Sección IV )
			var diasNacMay4h = getTrimValue( '#diasNacMay4h' );
			if ( diasNacMay4h != '' ) {

				var nroDiasDesplazamiento = calcularDiasHorasDesplazamiento();
				if ( toNumero( nroDiasDesplazamiento ) != toNumero( diasNacMay4h ) ) {

					var msg = configRSV.mensajes.numeroDiasViaticoNroTotalItinerario;
					msg = msg.replace( /DIAS_PROGRAMADOS/g, diasNacMay4h );
					msg = msg.replace( /SUMA_DIAS_DESPLAZAMIENTO/g, '' + nroDiasDesplazamiento );

					result.hayError = true;
					result.msgError = msg;

					return result;
				}
			}

			// No se debe exceder el monto tope diario
			var itemSuperaMontoDiario = buscarDesplazamientoQueSuperaImporteDiarioTope();
			if ( itemSuperaMontoDiario != null ) {

				var msg = configRSV.mensajes.montoDiarioNoDebeExcederTope;
				msg = msg.replace( /MONEDA_TOPE/g, configRSV.moneda );
				msg = msg.replace( /MONTO_TOPE/g, '' + itemSuperaMontoDiario.importeDiarioTope );

				result.hayError = true;
				result.msgError = msg;

				return result;
			}
			
			var itemConImporteDiarioNoValido = buscarDesplazamientoConImporteDiarioNoValido();
			if ( itemConImporteDiarioNoValido != null ) {

				var msg = 'No es posible ingresar el desplazamiento n&uacute;mero NRO_DESPLAZAMIENTO con un importe diario igual a 0, favor de corregir';
				msg = msg.replace( /NRO_DESPLAZAMIENTO/g, itemConImporteDiarioNoValido.nro );

				result.hayError = true;
				result.msgError = msg;
				result.queryControlFocus = '#importeDiario_' + itemConImporteDiarioNoValido.nro;

				return result;
			}

			// buscar asignacion sin clasificador
			var concepto = buscarConceptoSinClasificador();
			if ( concepto != null ) {
				result.hayError = true;
				result.msgError = 'El concepto ' + concepto.asignacion  + ' no tiene un clasificador asignado, comun&iacute;quese con el administrador del sistema.';
				return result;
			}

		} else {

			var fechaNacMen4h = getTrimValue( '#fechaNacMen4h'  );
			var salidaNacMen4h = getTrimValue( '#salidaNacMen4h' );
			var retornoNacMen4h = getTrimValue( '#retornoNacMen4h' );
			var horasNacMen4h = getTrimValue( '#horasNacMen4h' );

			// validacion adicional
			// que ingrese la fecha
			if ( fechaNacMen4h == '' ) {
				result.hayError = true;
				result.msgError = configRSV.mensajes.porFavorIngreseFechaViatico;
				result.queryControlFocus = '#fechaNacMen4h';
				return result;
			}

			// que ingrese las horas
			if ( salidaNacMen4h == '' || retornoNacMen4h == '' ) {

				result.hayError = true;
				result.msgError = configRSV.mensajes.porFavorIngreseFechaViaticoYHoras;

				if ( salidaNacMen4h == '' )   result.queryControlFocus = '#salidaNacMen4h';
				else if ( retornoNacMen4h == '' )  result.queryControlFocus = '#retornoNacMen4h';

				return result;
			}

			// que la fecha del viatico debe ser mayor a la fecha de registro
			if ( esFechaValida( fechaNacMen4h ) && !esFechaMayorIgual( fechaNacMen4h, configRSV.fechaRegistro ) ) {
				result.hayError = true;
				result.msgError = 'La fecha del vi&aacute;tico debe ser mayor o igual a la fecha de registro';
				result.queryControlFocus = '#fechaNacMen4h';
				return result;
			}			

			// la hora de retorno sea mayor a la hora de salida -> -1: err, 1: f1>f2, 2: f1<f2, 0: f1=f2 
			var diferencia = compararHoras( retornoNacMen4h, salidaNacMen4h );
			if ( diferencia == 0 || diferencia == 2 ) {
				result.hayError = true;
				result.msgError = configRSV.mensajes.horaRetornoMayorHoraSalida;
				result.queryControlFocus = '#retornoNacMen4h';
				return result;				
			}
			
			// que la diferencia de horas no supere las 4h
			if ( horasNacMen4h != '' && toNumero( horasNacMen4h ) > 4.0 ) {
				result.hayError = true;
				result.msgError = configRSV.mensajes.diferenciaHoraRetornoSalidaNoSupereHoras;
				result.queryControlFocus = '#retornoNacMen4h';
				return result;					
			}

			// validar motivo de comision
			var txtMotivoComision = getTrimValue('#txtMotivoComision');
			if ( txtMotivoComision == '' ) {
				result.hayError = true;
				result.msgError = configRSV.mensajes.debeIngresarMotivoDesplazamientoValido;
				result.queryControlFocus = '#txtMotivoComision';
				return result;
			}

			// que haya visualizado la consulta de asistencia
			if ( configRSV.consultaAsistencia.visualizo == configRSV.constantes.NO ) {
				result.hayError = true;
				result.msgError = configRSV.mensajes.debeVerificarFechasProgramandoVacasCompenLicencias;
				result.queryControlFocus = obtenerBotonAsistenciaIDSegunCaso();
				return result;
			}				

			// Validara que el total de horas de la sección II y la sección IV no difieran en el número de hora
			if ( horasNacMen4h != '' ) {

				var nroHorasDesplazamiento = calcularDiasHorasDesplazamiento();
				if ( toNumero( nroHorasDesplazamiento ) != toNumero( horasNacMen4h ) ) {

					var msg = configRSV.mensajes.numeroHorasViaticoNroTotalItinerario;
					msg = msg.replace( /HORAS_PROGRAMADAS/g, horasNacMen4h );
					msg = msg.replace( /SUMA_HORAS_DESPLAZAMIENTO/g, '' + nroHorasDesplazamiento );

					result.hayError = true;
					result.msgError = msg;

					return result;
				}
			}

			var itemConImporteDiarioNoValido = buscarDesplazamientoConImporteDiarioNoValido();
			if ( itemConImporteDiarioNoValido != null ) {

				var msg = 'No es posible ingresar el desplazamiento n&uacute;mero NRO_DESPLAZAMIENTO con un importe diario igual a 0, favor de corregir';
				msg = msg.replace( /NRO_DESPLAZAMIENTO/g, itemConImporteDiarioNoValido.nro );

				result.hayError = true;
				result.msgError = msg;
				result.queryControlFocus = '#importeDiario_' + itemConImporteDiarioNoValido.nro;

				return result;
			}

			// buscar asignacion sin clasificador
			var concepto = buscarConceptoSinClasificador();
			if ( concepto != null ) {
				result.hayError = true;
				result.msgError = 'El concepto ' + concepto.asignacion  + ' no tiene un clasificador asignado, comun&iacute;quese con el administrador del sistema.';
				return result;
			}

		}

	} else {

		// fechas de itinerario/ejecucion
		var fechaItinerarioInicioInter = getTrimValue( '#fechaItinerarioInicioInter' );
		var fechaItinerarioFinInter = getTrimValue( '#fechaItinerarioFinInter' );

		// fechas de evento/programacion
		var fechaEventoInicioInter = getTrimValue( '#fechaEventoInicioInter' );
		var fechaEventoFinInter = getTrimValue( '#fechaEventoFinInter' );

		// validacion adicional
		if ( fechaEventoInicioInter == '' || fechaEventoFinInter == ''   ) {
			result.hayError = true;
			result.msgError = configRSV.mensajes.porFavorIngreseFechaInicioFinEvento;

			if ( fechaEventoInicioInter == '' ) result.queryControlFocus = '#fechaEventoInicioInter';
			else if ( fechaEventoFinInter == '' ) result.queryControlFocus = '#fechaEventoFinInter';

			return result;
		}
		
		// La fecha de inicio del evento debe ser mayor a la fecha de registro de la solicitud
		if ( esFechaValida( fechaEventoInicioInter ) && !esFechaMayor( fechaEventoInicioInter, configRSV.fechaRegistro ) ) {
			result.hayError = true;
			result.msgError = configRSV.mensajes.fechaInicioEventoMayorFechaRegistroSolicitud;
			result.queryControlFocus = '#fechaEventoInicioInter';
			return result;
		}

		//JMCR-ME-FECHA
		// La fecha termino del evento debe ser mayor a la fecha de inicio del evento
		if ( esFechaValida( fechaEventoFinInter ) && esFechaValida( fechaEventoInicioInter ) ) {
			if ( !esFechaMayorIgual( fechaEventoFinInter, fechaEventoInicioInter )  ) {
				result.hayError = true;
				result.msgError = configRSV.mensajes.fechaInicioEventoMayorIgualFechaInicioEvento;
				result.queryControlFocus = '#fechaEventoFinInter';
				return result;
			}
		}
		
		if ( esFechaValida( fechaItinerarioInicioInter ) && esFechaMayorAnio( fechaItinerarioInicioInter ) ) {
			result.hayError = true;
			result.msgError = configRSV.mensajes.fechaInicioItinerarioAnio;
			result.queryControlFocus = '#fechaItinerarioInicioInter';
			return result;
		}

		if ( esFechaValida( fechaItinerarioFinInter ) && esFechaMayorAnio( fechaItinerarioFinInter ) ) {
			result.hayError = true;
			result.msgError = configRSV.mensajes.fechaFinItinerarioAnio;
			result.queryControlFocus = '#fechaItinerarioFinInter';
			return result;
		}	
		//JMCR-ME-FECHA

		// validar motivo de comision
		var txtMotivoComision = getTrimValue('#txtMotivoComision');
		if ( txtMotivoComision == '' ) {
			result.hayError = true;
			result.msgError = configRSV.mensajes.debeIngresarMotivoDesplazamientoValido;
			result.queryControlFocus = '#txtMotivoComision';
			return result;
		}

		// que haya visualizado la consulta de asistencia
		if ( configRSV.consultaAsistencia.visualizo == configRSV.constantes.NO ) {
			result.hayError = true;
			result.msgError = configRSV.mensajes.debeVerificarFechasProgramandoVacasCompenLicencias;
			result.queryControlFocus = obtenerBotonAsistenciaIDSegunCaso();
			return result;
		}			

		// El número de días para realizar el viático debe ser mayor a cero
		// NOTA: en el F2, esta validación sólo la pone para internacional y no para los otros dos tipos de viáticos
		var sumaDias = calcularDiasHorasDesplazamiento();
		if ( !( sumaDias > 0 ) ) {
			
			var nroDiasComision = obtenerNumeroDiasHorasComision();
			
			var msg = configRSV.mensajes.debeIngresarDiasParaDesplazamiento;
			msg = msg.replace( /NRO_DIAS/g, nroDiasComision );				
			
			result.hayError = true;
			result.msgError = msg; 

			return result;
		}

		// El total de días del viático(sección II-Detalle de viático) debe coincidir con la cantidad de “días de viático” (Sección IV - Información desplazamiento -lugar(es) destino)
		var diasInter = getTrimValue( '#diasInter' );
		if ( diasInter != '' ) {

			var nroDiasDesplazamiento = calcularDiasHorasDesplazamiento();
			if ( toNumero( nroDiasDesplazamiento ) != toNumero( diasInter ) ) {

				var msg = configRSV.mensajes.numeroDiasViaticoNroTotalItinerario;
				msg = msg.replace( /DIAS_PROGRAMADOS/g, diasInter );
				msg = msg.replace( /SUMA_DIAS_DESPLAZAMIENTO/g, '' + nroDiasDesplazamiento );

				result.hayError = true;
				result.msgError = msg;

				return result;
			}
		}

		// No se debe exceder el traslado máximo
		var itemSuperaDiasTraslado = buscarDesplazamientoInternacionalQueSupereDiasTrasladoTope();
		if ( itemSuperaDiasTraslado != null ) {

			var msg = configRSV.mensajes.topeMaxAsigDiasTraslado;
			msg = msg.replace( /NRO_DIAS/g, itemSuperaDiasTraslado.diasTrasladoTope );

			result.hayError = true;
			result.msgError = msg;

			return result;
		}

		// No se debe exceder el monto tope diario
		var itemSuperaMontoDiario = buscarDesplazamientoQueSuperaImporteDiarioTope();
		if ( itemSuperaMontoDiario != null ) {

			var msg = configRSV.mensajes.montoDiarioNoDebeExcederTope;
			msg = msg.replace( /MONEDA_TOPE/g, configRSV.moneda );
			msg = msg.replace( /MONTO_TOPE/g, '' + itemSuperaMontoDiario.importeDiarioTope );

			result.hayError = true;
			result.msgError = msg;

			return result;
		}

		// No se debe exceder el monto tope para gastos de instalación y traslado
		var itemSuperaViajeExtGtoTras = buscarDesplazamientoQueSuperaViajeExtGtoTrasTope();
		if ( itemSuperaViajeExtGtoTras != null ) {

			var msg = configRSV.mensajes.topeMaxAsigGastosInstTraslado;
			msg = msg.replace( /MONTO_TOPE/g, '' + itemSuperaViajeExtGtoTras.viajeExtGtoTrasTope );

			result.hayError = true;
			result.msgError = msg;

			return result;
		}

		var itemConImporteDiarioNoValido = buscarDesplazamientoConImporteDiarioNoValido();
		if ( itemConImporteDiarioNoValido != null ) {

			var msg = 'No es posible ingresar el desplazamiento n&uacute;mero NRO_DESPLAZAMIENTO con un importe diario igual a 0, favor de corregir';
			msg = msg.replace( /NRO_DESPLAZAMIENTO/g, itemConImporteDiarioNoValido.nro );

			result.hayError = true;
			result.msgError = msg;
			result.queryControlFocus = '#importeDiario_' + itemConImporteDiarioNoValido.nro;

			return result;
		}

		// validacion adicional
		// buscar asignacion sin clasificador
		var concepto = buscarConceptoSinClasificador();
		if ( concepto != null ) {
			result.hayError = true;
			result.msgError = 'El concepto ' + concepto.asignacion  + ' no tiene un clasificador asignado, comun&iacute;quese con el administrador del sistema.';
			return result;
		}

	}

	// validacion adicional
	// verificar el ingreso correcto de fechas (ya que el usuario puede borrar los mensajes de validación)
	if ( hayFechasConError() ) {

		revalidarSiHayFechasConError();

		result.hayError = true;
		result.msgError = 'Por favor verifique las fechas ingresadas';
		result.queryControlFocus = obtenerFechaConError();
		
		// personalizacion para horas
		if ( result.queryControlFocus == '#fechaNacMen4h' ) {
			result.msgError = 'Por favor verifique la fecha ingresada';
		} else if ( result.queryControlFocus == '#salidaNacMen4h' ||  result.queryControlFocus == '#retornoNacMen4h' ) {
			result.msgError = 'Por favor verifique las horas ingresadas';
		}	

		return result;
	}

	return result;
}

function huboCambioDeFechas() {
	
	if ( esNacional() ) {
		
		if ( esMayor4h() ) {

			// si no ha cambiado las fechas
			if ( getTrimValue( '#fechaSalidaNacMay4h' ) != getTrimValue( '#hidFechaSalidaNacMay4hAnterior' ) || 
				 getTrimValue( '#fechaRetornoNacMay4h' ) != getTrimValue( '#hidFechaRetornoNacMay4hAnterior' ) ) {
				
				return true;
			}
			
		} else { // es menor igual a 4 horas
			
			// si no han cambiado las fechas
			if ( getTrimValue( '#fechaNacMen4h' ) != getTrimValue( '#hidFechaNacMen4hAnterior' ) ) {
				
				return true;
			}					
			
		}
		
	} else {  // si es internacional
		
		// si no han cambiado las fechas
		if ( getTrimValue( '#fechaEventoInicioInter' ) != getTrimValue( '#hidFechaEventoInicioInterAnterior' ) || 
			 getTrimValue( '#fechaEventoFinInter' ) != getTrimValue( '#hidFechaEventoFinInterAnterior' ) ) {
			
			return true;
		}				
		
	}	
	
	return false;
}


// validaciones para el envío de solicitud de viático
function validarEnviarViatico() {
	// validación local antes de enviar el viático
	
	var result = {
		'hayError': false,
		'msgError': null,
		'queryControlFocus': null
	};
	
	//validamos que la hora de inicio no sea mayor a la hora actual en la que se firma...
	var salidaNacMen4h = getTrimValue( '#salidaNacMen4h' );
	var horaActual = getHoraActualString();
	var fechaActual = getCurrentDateFormatEsp();
	var fechaSalidaNacMen4h = getTrimValue( '#fechaNacMen4h' );
	var fechaSalidaNacMay4h = $('#fechaSalidaNacMay4h').val();
	var fechaEventoInicioInter = $('#fechaEventoInicioInter').val();
	
	
	//Si la hora actual es mayor a la fecha ingresada entonces ERROR
	var codPlanilla = $("#txtCodPlanilla").val();
	
	
	if ( esNacional() ) {
		if ( esMayor4h() ) {
			//Validamos las fechas
			
			if(compararFechas(fechaActual,fechaSalidaNacMay4h)==1){
				result.hayError = true;
				result.msgError = "No se puede firmar la solicitud de viáticos "+codPlanilla+", debido a que la fecha de salida de la comision es menor a la fecha actual";
				return result;
			}
			
		}else{
			//Validamos las horas
			if(compararFechas(fechaActual,fechaSalidaNacMen4h)==0){
				if(compararHoras(horaActual,salidaNacMen4h)==1){
					result.hayError = true;
					result.msgError = "No se puede firmar la solicitud de viáticos "+codPlanilla+", debido a que la hora de salida de la comisión es menor  a la hora actual";
					return result;
				}	
			}
		}
		
	}else{
		//TODO: Verificar que funcione.
		if(compararFechas(fechaActual,fechaEventoInicioInter)==1){
			result.hayError = true;
			result.msgError = "No se puede firmar la solicitud de viáticos "+codPlanilla+", debido a que la fecha de inicio de evento de la comision  es menor a la fecha actual";
			return result;
		}
	}
	
	
	
	
	// validación adicional 
	// que primero grabe los cambios realizado (si los hubiesen)
	if ( huboModificaciones() ) {
		
		result.hayError = true;
		result.msgError = configRSV.mensajes.seHanEfectuadoCambiosGrabarPrimero;
		
		return result;		
	}
	
	// manejo de traslapes (si esta en proceso de autorización o si ya le rechazaron)
	// usa los hiddens (valores en BD)
	if ( getTrimValue( '#hidIndicadorTraslapeAnterior' ) == '1' ) {
		
		// traslape 1, autorizacion 2 (traslape rechazado)
		if ( getTrimValue( '#hidIndicadorAutorizacionAnterior' ) == '2' ) {
			
			if ( esNacional() ) {
				
				if ( esMayor4h() ) {

					var fechaSalidaNacMay4h = getTrimValue( '#fechaSalidaNacMay4h' );
					var hidFechaSalidaNacMay4hAnterior = getTrimValue( '#hidFechaSalidaNacMay4hAnterior' );	// fecha de BD sin modificar
					
					var fechaRetornoNacMay4h = getTrimValue( '#fechaRetornoNacMay4h' );
					var hidFechaRetornoNacMay4hAnterior = getTrimValue( '#hidFechaRetornoNacMay4hAnterior' ); // fecha de BD sin modificar
					
					// si no ha cambiado las fechas
					if ( fechaSalidaNacMay4h == hidFechaSalidaNacMay4hAnterior && fechaRetornoNacMay4h == hidFechaRetornoNacMay4hAnterior ) {
						
						var msg = configRSV.mensajes.presentaTraslapeRechazadoConFechasInicioFin;
						msg = msg.replace( /FECHA_INICIO/g, hidFechaSalidaNacMay4hAnterior );
						msg = msg.replace( /FECHA_FIN/g, '' + hidFechaRetornoNacMay4hAnterior );						
						
						result.hayError = true;
						result.msgError = msg;
						
						return result;
					}
					
					
				} else { // es menor igual a 4 horas
					
					var fechaNacMen4h = getTrimValue( '#fechaNacMen4h' );
					var hidFechaNacMen4hAnterior = getTrimValue( '#hidFechaNacMen4hAnterior' );
					
					// si no han cambiado las fechas
					if ( fechaNacMen4h == hidFechaNacMen4hAnterior ) {
						
						var msg = configRSV.mensajes.presentaTraslapeRechazadoConFecha;
						msg = msg.replace( /FECHA_INICIO/g, hidFechaNacMen4hAnterior );
						
						result.hayError = true;
						result.msgError = msg;
						
						return result;
					}					
					
				}
				
			} else {  // si es internacional
				
				var fechaEventoInicioInter = getTrimValue( '#fechaEventoInicioInter' );
				var hidFechaEventoInicioInterAnterior = getTrimValue( '#hidFechaEventoInicioInterAnterior' );	// fecha de BD sin modificar
				
				var fechaEventoFinInter = getTrimValue( '#fechaEventoFinInter' );
				var hidFechaEventoFinInterAnterior = getTrimValue( '#hidFechaEventoFinInterAnterior' ); // fecha de BD sin modificar
				
				// si no han cambiado las fechas
				if ( fechaEventoInicioInter == hidFechaEventoInicioInterAnterior && fechaEventoFinInter == hidFechaEventoFinInterAnterior ) {
					
					var msg = configRSV.mensajes.presentaTraslapeRechazadoConFechasInicioFin;
					msg = msg.replace( /FECHA_INICIO/g, hidFechaEventoInicioInterAnterior );
					msg = msg.replace( /FECHA_FIN/g, '' + hidFechaEventoFinInterAnterior );						
					
					result.hayError = true;
					result.msgError = msg;
					
					return result;
				}				
				
			}
			
		}	
		 
	}	
	
	return result;
}

// métodos que retornan si se ingresaron todos los datos obligatorios en las secciones
function ingresoDatosSeccionIDatosGenerales() {
	
	var isOK = true;

	// que ingrese nro de registro
	if ( isOK && getTrimValue( '#txtNroRegistro' ) == '' ) {
		isOK = false;
	}

	if ( isOK && getTrimValue( '#hidCodigoColaborador' ) == '' ) {
		isOK = false;
	}

	// que ingrese UUOO
	if ( isOK && getTrimValue( '#txtUUOO' ) == '' ) {
		isOK = false;
	}

	if ( isOK && getTrimValue( '#hidCodigoDependencia' ) == '' ) {
		isOK = false;
	}

	// que escoga meta presupuestal
	if ( isOK && getTrimValue( '#txtCodigoMetaPresupuestal' ) == '' ) {
		isOK = false;
	}

	return isOK;
}

function ingresoDatosSeccionIIDetalle() {
	
	// método que retorna true si ha ingresado todos los campos fecha obligatorios (sólo fechas)
	var isOK = true;

	if ( esNacional() ) {

		if ( esMayor4h() ) {

			// que ingrese las fechas de salida y retorno
			if ( isOK && getTrimValue( '#fechaSalidaNacMay4h' ) == '' ) {
				isOK = false;
			}

			if ( isOK && getTrimValue( '#fechaRetornoNacMay4h' ) == '' ) {
				isOK = false;
			}

		} else {

			// que ingrese las fechas de salida, hora de salida y retorno
			if ( isOK && getTrimValue( '#fechaNacMen4h' ) == '' ) {
				isOK = false;
			}

			if ( isOK && getTrimValue( '#salidaNacMen4h' ) == '' ) {
				isOK = false;
			}

			if ( isOK && getTrimValue( '#retornoNacMen4h' ) == '' ) {
				isOK = false;
			}
		}

	} else {	// si es internacional

		// que ingrese las fechas del evento
		if ( isOK && getTrimValue( '#fechaEventoInicioInter' ) == '' ) {
			isOK = false;
		}

		if ( isOK && getTrimValue( '#fechaEventoFinInter' ) == '' ) {
			isOK = false;
		}

	}

	return isOK;
}

function ingresoDatosSeccionIIIPuntoPartida() {

	// método que retorna true si ha ingresado todos los campos obligatorios de la sección III
	
	var isOK = true;

	if ( isOK && getTrimValue( '#selDepartamento' ) == '00' ) {
		isOK = false;
	}

	if ( isOK && getTrimValue( '#selProvincia' ) == '00' ) {
		isOK = false;
	}

	if ( isOK && getTrimValue( '#hidCodigoPuntoPartida' ) == '' ) {
		isOK = false;
	}

	return isOK;
}

// métodos que retornan true si se ingresó algún datos en las secciones
function ingresoAlgunDatoSeccionIIDetalle() {
	
	// campos de viáticos nacionales > 4h
	if ( getTrimValue( '#fechaSalidaNacMay4h' ) != '' )	return true;
	if ( getTrimValue( '#fechaRetornoNacMay4h' ) != '' ) return true;
	if ( getTrimValue( '#txtMotivoComision' ) != '' ) return true;
	if ( getTrimValue( '#txtObservacion' ) != '' ) return true;

	// campos de viáticos nacionales <= 4h			
	if ( getTrimValue( '#fechaNacMen4h' ) != '' ) return true;
	if ( getTrimValue( '#salidaNacMen4h' ) != '' ) return true;
	if ( getTrimValue( '#retornoNacMen4h' ) != '' )	return true;
	if ( getTrimValue( '#txtMotivoComision' ) != '' ) return true;
	if ( getTrimValue( '#txtObservacion' ) != '' ) return true;
 
	// campos de viáticos internacionales
	if ( getTrimValue( '#fechaItinerarioInicioInter' ) != '' ) return true;
	if ( getTrimValue( '#fechaItinerarioFinInter' ) != '' ) return true;
	
	if ( getTrimValue( '#fechaEventoInicioInter' ) != '' ) return true;
	if ( getTrimValue( '#fechaEventoFinInter' ) != '' ) return true;
	
	if ( getTrimValue( '#fechaResolucionInter' ) != '' ) return true;
	if ( getTrimValue( '#nroResolucionInter' ) != '' ) return true;
	if ( getTrimValue( '#montoResolucionInter' ) != '' ) return true;
	
	if ( getTrimValue( '#txtMotivoComision' ) != '' ) return true;
	if ( getTrimValue( '#txtObservacion' ) != '' ) return true;


	return false;
}

function ingresoAlgunDatoSeccionIIIPuntoPartida() {

	// en caso de nacional, los valores por default son seleccione (00), seleccione(00)
	// en caso de internacional, los valores por default son LIMA (01), LIMA(15)

	if ( configRSV.puntoPartida.usarLimaComoDefault == configRSV.constantes.NO ) {

		// caso normal
		if ( getTrimValue( '#selDepartamento' ) != '00' ) return true;
		if ( getTrimValue( '#selProvincia' ) != '00' ) return true;

	} else {

		// defaults usando lima
		if ( getTrimValue( '#selDepartamento' ) != configRSV.constantes.UBIGEO_DEPARTAMENTO_LIMA ) return true;
		if ( getTrimValue( '#selProvincia' ) != configRSV.constantes.UBIGEO_PROVINCIA_LIMA ) return true;
	}

	return false;
}

function ingresoAlgunDatoSeccionIVDesplazamientos() {

	return getDesplazamientosList().length > 0;
}

function ingresoAlgunDatoSeccionVAsignaciones() {
	
	return getAsignacionesList().length > 0;
}