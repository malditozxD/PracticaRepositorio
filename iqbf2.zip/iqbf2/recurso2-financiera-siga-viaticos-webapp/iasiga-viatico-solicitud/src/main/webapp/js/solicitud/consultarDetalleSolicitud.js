function initElementsDetalleSolicitud(idElementCallModal, codPlanViaje,nomTipoViatico,codPlanilla,nomColaborador) {
	$("#cabDetalleSolicitud").html(cabeceraDetalleSolicitud(codPlanilla,nomColaborador));
	setInitElementsDetalleSolicitud();
	setInitDetalleSolicitudTable();
	callObtenerDetalleSolicitud(codPlanViaje);
	resizeTable("divDetalleTableSolicitud");
}

function cabeceraDetalleSolicitud(codPlanilla, nomColaborador) { 
	var str="";
	str += "<div class=\"row\">";
	str += "	<div class=\"col-xs-12 col-sm-3 col-md-2 col-lg-2\">";
	str += "		<label for=\"txtNumPlanilla\" class=\"text-muted alineartext\">N&deg; Planilla<\/label>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-9 col-md-4 col-lg-4\">";
	str += "		<input class=\"form-control input-sm margen-input\"  type=\"text\"";
	str += "			id=\"txtNumPlanilla\" name=\"txtNumPlanilla\" readonly=\"readonly\" value=\""+codPlanilla+"\"\/>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-3 col-md-2 col-lg-2\">";
	str += "		<label for=\"txtNombreColaborador\" class=\"text-muted alineartext\">Comisionado<\/label>";
	str += "	<\/div>";
	str += "	<div class=\"col-xs-12 col-sm-9 col-md-4 col-lg-4\">";
	str += "		<input class=\"form-control input-sm margen-input\" type=\"text\"";
	str += "			id=\"txtNombreColaborador\" name=\"txtNombreColaborador\" readonly=\"readonly\" value=\""+nomColaborador+"\"><\/input>";
	str += "	<\/div>";
	str += "<\/div>";
	return str;
} 

function setInitElementsDetalleSolicitud() {
	addEventElement("btnCerrarDetalleSolicitud", "click", clickBtnCerrarDetalleSolicitud);
}

function clickBtnCerrarDetalleSolicitud() {
	$('#divConsultarDetalleSolicitud').modal('hide');
}

function setInitDetalleSolicitudTable() {
	var detalleSolicitudTable = $("#tblDetalleSolicitud");
	var detalleSolicitudTable2 = $("#tblDetalleSolicitud2");
	if (detalleSolicitudTable) {
		//Para el DivWitdh se utilizo un componente que llama al modal
		var detalleSolicitudTableDiv = $("#divDetalleTableSolicitud");
		var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.viaticoModalContainer", ".viaticoModalContainerAuxiliar", "width"))/100);
		var widthTable = factorRedimensionamiento*detalleSolicitudTableDiv.width();
		detalleSolicitudTable.jqGrid({
			width: widthTable,
			height: 'auto',
			minHeight: 70,
			autowidth: true,
			datatype: "local",
			rowNum: 10,
			rowList: [10, 20],
			cmTemplate: {sortable: false},
			colNames:[
				"UUOO",
				"Itinerario",
				"Fecha de Salida",
				"Fecha de Retorno",
				"Total d&iacute;as de Comisi&oacute;n",
				"Motivo de la Comisi&oacute;n",
				"Autorizador de gasto",
				"Nombre del Registrador"
			],
			colModel:[
			    {name: "nomUuOoCom", index: "nomUuOoCom", width: (1.4*widthTable/12),align: 'right'},
			    {name: "itinerario", index: "itinerario", width: (1.4*widthTable/12),align: 'right' },
				{name: "fecSalida", index: "fecSalida", width: (1.4*widthTable/12),align: 'right'},
				{name: "fecRetorno", index: "fecRetorno", width: (1.4*widthTable/12), align: 'right', hidden: false},
				{name: "numDias", index: "numDias", width: (1.4*widthTable/12), align: 'right', hidden: false},
				{name: "motivoComis", index: "motivoComis", width: (1.4*widthTable/12), align: 'right', hidden: false },
				{name: "nomAutorizador", index: "nomAutorizador", width: (0.9*widthTable/12), align: 'right', hidden: false},
				{name: "nomRegistrador", index: "nomRegistrador", width: (0.9*widthTable/12), align: 'right' }
			],
			//pager : "#divColaboradorPagerTable2",
			loadui: "disable"
		});
	}
	if (detalleSolicitudTable2) {
		detalleSolicitudTable2.jqGrid({
			width: widthTable,
			height: 'auto',
			minHeight: 70,
			autowidth: true,
			datatype: "local",
			rowNum: 10,
			rowList: [10, 20],
			cmTemplate: {sortable: false},
			colNames:[
				"Asignaci&oacute;n de Vi&aacute;ticos",
				"Pasajes",
				"Otros",
				"Total Otorgado",
				"Medio de Pago",
				"N&deg; Recibo Provisional",
				"Fecha Pago Caja Ch."
				
			],
			colModel:[
			    {name: "impAsigViatico", index: "impAsigViatico", width: (0.9*widthTable/12), align: 'right' },
				{name: "impPasaje", index: "impPasaje", width: (0.9*widthTable/12), align: 'right' },
				{name: "impOtros", index: "impOtros", width: (0.9*widthTable/12), align: 'right' },
				{name: "impTotalOtorgado", index: "impTotalOtorgado", width: (0.9*widthTable/12), align: 'right' },
				{name: "medioPago", index: "medioPago", width: (0.9*widthTable/12), align: 'right' },
				{name: "numReciboProv", index: "numReciboProv", width: (1*widthTable/12) ,align: 'center' },
				{name: "fecPagoCajaCh", index: "fecPagoCajaCh", width: (0.9*widthTable/12) ,align: 'center' }
			],
			//pager : "#divColaboradorPagerTable2",
			loadui: "disable"
		});
	}
	detalleSolicitudTable.clearGridData();
	detalleSolicitudTable2.clearGridData();
}

function callObtenerDetalleSolicitud(codPlanViaje) {
	setTimeout(function(){
		var detalleSolicitudTable = $("#tblDetalleSolicitud");
		var detalleSolicitudTable2 = $("#tblDetalleSolicitud2");
		detalleSolicitudTable.clearGridData();
		detalleSolicitudTable2.clearGridData();
		
		$.ajax({
			url: contextPathUrl + "/solicitud.htm?action=buscarSolicitudDetalle",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codPlanViaje": codPlanViaje
			},
			beforeSend: function() {
				showElement("divLoadingDetalleSolicitud");
			},
			complete: function() {
				hideElement("divLoadingDetalleSolicitud");
			},
			success: function(result) {
				var numeroSecuencial = 0;
				var detalleList = result.detalleList;
				if (detalleList != null && detalleList.length > 0) {
					
					
					for (var i = 0; i < detalleList.length; i++) {
						var detalle = detalleList[i];
						var datarow = {
							numeroSecuencial: (i + 1),
							nomUuOoCom: detalle.nomUuOoCom,
							itinerario: detalle.itinerario,
							fecSalida: detalle.fecSalida,
							fecRetorno: detalle.fecRetorno,
							numDias: detalle.numDias,
							motivoComis: detalle.motivoComis,
							nomAutorizador: detalle.nomAutorizador,
							nomRegistrador: detalle.nomRegistrador,
						};
						var datarow2 = {
								numeroSecuencial2: (i + 1),
								impAsigViatico: detalle.impAsigViatico,
								impPasaje: detalle.impPasaje,
								impOtros: detalle.impOtros,
								impTotalOtorgado: detalle.impTotalOtorgado,
								medioPago: detalle.medioPago,
								numReciboProv: detalle.numReciboProv,
								fecPagoCajaCh: detalle.fecPagoCajaCh
							};
						detalleSolicitudTable.jqGrid("addRowData", datarow.numeroSecuencial, datarow);
						detalleSolicitudTable2.jqGrid("addRowData", datarow2.numeroSecuencial2, datarow2);
					}
					detalleSolicitudTable.trigger("reloadGrid");
					detalleSolicitudTable2.trigger("reloadGrid");
				}
				else {
					//
				}
				
			},
			error: function() {
					//
				}
			});
		}, 900);
	}