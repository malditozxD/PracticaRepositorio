function initElementsRevisarSolicitudAutorizador() {
	removeDuplicateComponents();
	setInitElementsRevisarSolicitudAutorizador();
	setInitPlanillaTable();
}


var generateDataFirma = function(){
	var pass = $("#txtPasswordUsuario").val();
	var variableImprimirSendPost = getValueInputText("hidTxtCodPlanilla");
	var dataFirmaJson = {
		"variableImprimirSendPost": variableImprimirSendPost,
		"tipDocumento": "043",
		"tipProceso": "A",
		"txtPasswordUsuario": pass
	};
	return dataFirmaJson;
};

function setInitElementsRevisarSolicitudAutorizador() {
	
	disabledElement("btnExportarExcelSolicitud");
	setValueInputText("selAnioSolicitud", getValueInputText("hidAnioActual"));
	setValueInputText("selCanalAtencionSolicitud", "00");
	setValueInputText("hidFechaMaximaAnioActual", getValueInputText("hidAnioActual") + "/12/31");
	modificarRangoFechaRevisarSolicitudAutorizador(getValueInputText("hidAnioActual"));
	
	addEventElement("btnBuscarUUOOSolicitud", "click", clickBtnBuscarUUOOSolicitud);
	addEventElement("btnBuscarColaboradorSolicitud", "click", clickBtnBuscarColaboradorSolicitud);
	addEventElement("selEstadoSolicitud", "change", changeSelEstadoSolicitud);
	addEventElement("selAnioSolicitud", "change", changeSelAnioSolicitud);
	addEventElement("selCanalAtencionSolicitud", "change", changeSelCanalAtencionSolicitud);
	addEventElement("btnConsultarSolicitud", "click", clickBtnConsultarSolicitud);
	addEventElement("btnExportarExcelSolicitud", "click", clickBtnExportarExcelSolicitud);
	
	addEventElement("etiquetaFechaInicioSolicitud", "change", changeEtiquetaFechaInicioSolicitud);
	addEventElement("etiquetaFechaFinSolicitud", "change", changeEtiquetaFechaFinSolicitud);
	initDateTimePickerWithMaxDate("etiquetaFechaInicioSolicitudDiv", "dp.change", "changeDate", changeDateEtiquetaFechaInicioSolicitudDiv, getValueInputText("hidFechaMaximaAnioActual"));
	initDateTimePickerWithMaxDate("etiquetaFechaFinSolicitudDiv", "dp.change", "changeDate", changeDateEtiquetaFechaFinSolicitudDiv, getValueInputText("hidFechaMaximaAnioActual"));
	
	addEventElement("btnAceptarMensajeConfirmacionRevisarSolicitudAutorizador", "click", clickBtnAceptarMensajeConfirmacionRevisarSolicitudAutorizador);
	addEventElement("btnAceptarMensajeConfirmacionErrorRevisarSolicitudAutorizador", "click", clickBtnAceptarMensajeConfirmacionErrorRevisarSolicitudAutorizador);
	addEventElement("btnSiAutorizarSolicitudRevisarSolicitudAutorizador", "click", clickBtnSiAutorizarSolicitudRevisarSolicitudAutorizador);
	addEventElement("btnNoAutorizarSolicitudRevisarSolicitudAutorizador", "click", clickBtnNoAutorizarSolicitudRevisarSolicitudAutorizador);
	addEventElement("btnAceptarAutorizacionExitosaRevisarSolicitudAutorizador", "click", clickBtnAceptarAutorizacionExitosaRevisarSolicitudAutorizador);
	
	addEventElement("btnAceptarDerivarOk", "click", clickBtnAceptarDerivarOk);
	
	setDatosFirmaElectronica(generateDataFirma,clickBtnSiAutorizarSolicitudRevisarSolicitudAutorizador);
}

function setInitPlanillaTable() {
	
	var planillaTable = $("#tblPlanilla");
	var heightJqGrid = 200;
	setStyleElement("divPlanillaTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 2, true));
	if (planillaTable) {
		var planillaTableDiv = $("#divPlanillaTable");
		var widthTable = planillaTableDiv.width();
		planillaTable.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			datatype: "local",
			rowNum: 10,
			rowList: [10, 20],
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Código Plan Viaje",
				"tipoDestino",      		// hidden
			    "indicadorHoras",      		// hidden
				"Nro. Planilla",
				"Nro. Planilla",
				"Fec. Registro Solicitud",
				"Número Registro",
				"Nombre Colaborador",
				"Código Tipo Destino",
				"Tipo de Viáticos",
				"Monto Total",
				"Importe Total Otorgado",
				"Canal de Atención",
				"Plazo para Rendir",
				"Código Estado Planilla",
				"Estado Planilla",
				"UUOO",
				"Indicador Canal Atencion",
				"Expediente Plan Viaje",
				"Numero Registro Archivo",
				"",
				"",
				"Acción",
				"",
				"",
				""
			],
			colModel: [
				{name: "codPlanViaje", index: "codPlanViaje", width: (1*widthTable/20), hidden: true},
				{name:'tipoDestino',index:'tipoDestino', width:(0.1*widthTable/20),hidden: true},
				{name:'indicadorHoras',index:'indicadorHoras', width:(0.1*widthTable/20),hidden: true},
				{name: "codPlanilla", index: "codPlanilla", width: (1*widthTable/20), align: "center", hidden: true},
				{name: "codPlanillaLink", index: "codPlanillaLink", width: (2*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkConsultarSolicitud('" + rowData.codPlanilla + "');\">" + rowData.codPlanilla + "</a>";
						return htmlElement;
					}
				},
				{name: "fechaRegistro", index: "fechaRegistro", width: (1.6*widthTable/20), align: "center"},
				{name: "numeroRegistroAlterno", index: "numeroRegistroAlterno", width: (1*widthTable/20), hidden: true},
				{name: "nomColaborador", index: "nomColaborador", width: (3.2*widthTable/20)},
				{name: "tipoDestino", index: "tipoDestino", width: (1*widthTable/20), hidden: true},
				{name: "nomTipoViatico", index: "nomTipoViatico", width: (1.7*widthTable/20)},
				{name: "mtoTotal", index: "mtoTotal", width: (1*widthTable/20), hidden: true},
				{name: "mtoTotalFormateado", index: "mtoTotalFormateado", width: (1.8*widthTable/20), align: "right"},
				{name: "canalAtencion", index: "canalAtencion", width: (1.5*widthTable/20)},
				{name: "fecMaxRend", index: "fecMaxRend", width: (1.6*widthTable/20), align: "center"},
				{name: "codEstadoSolic", index: "codEstadoSolic", width: (1*widthTable/20), hidden: true},
				{name: "nomEstSolic", index: "nomEstSolic", width: (1.6*widthTable/20)},
				{name: "nomUuOoCom", index: "nomUuOoCom", width: (1*widthTable/20), hidden: true},
				{name: "indicadorCanalAtencion", index: "indicadorCanalAtencion", width: (1*widthTable/20), hidden: true},
				{name: "expedientePlanViaje", index: "expedientePlanViaje", width: (1*widthTable/20), hidden: true},
				{name: "numeroRegistroArchivo", index: "numeroRegistroArchivo", width: (1*widthTable/20), hidden: true},
				{name: "autorizarSolicitud", index: "autorizarSolicitud", width: (1.1*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "";
						if (rowData.codEstadoSolic == "04") {
							htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkAutorizarSolicitud('" + rowData.codPlanViaje + "');\">" + rowData.autorizarSolicitud + "</a>";
						}
						return htmlElement;
					}
				},
				{name: "observarSolicitud", index: "observarSolicitud", width: (1.1*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "";
						if (rowData.codEstadoSolic == "04") {
							htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkObservarSolicitud('" + rowData.codPlanViaje + "');\">" + rowData.observarSolicitud + "</a>";
						}
						return htmlElement;
					}
				},
				{name: "anularSolicitud", index: "anularSolicitud", width: (1*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "";
						if (rowData.codEstadoSolic == "04") {
							htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkAnularSolicitud('" + rowData.codPlanViaje + "');\">" + rowData.anularSolicitud + "</a>";
						}
						return htmlElement;
					}
				},
				{name: "detalleSolicitud", index: "detalleSolicitud", width: (1*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkConsultarDetalleSolicitudAutorizador('" + rowData.codPlanViaje + "');\">" + rowData.detalleSolicitud + "</a>";
						return htmlElement;
					}
				},
				{name: "seguimientoSolicitud", index: "seguimientoSolicitud", width: (1.4*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkConsultarSeguimientoSolicitudAutorizador('" + rowData.codPlanViaje + "');\">" + rowData.seguimientoSolicitud + "</a>";
						return htmlElement;
					}
				},
				{name: "verAdjuntosPlanilla", index: "verAdjuntosPlanilla", width: (0.6*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkConsultarAdjuntosSolicitudAutorizador('" + rowData.codPlanViaje + "');\">" + rowData.verAdjuntosPlanilla + "</a>";
						return htmlElement;
					}
				}
			],
			caption: "Planillas",
			pager: "#divPlanillaPagerTable",
			loadui: "disable"
		});
		planillaTable.clearGridData();
	}
}

function clickBtnBuscarUUOOSolicitud() {
	initElementsBuscarUUOO("divPlanillaTable");
	showModalElement("divBuscarUUOO");
    triggerResizeEvent();
}

function clickBtnBuscarColaboradorSolicitud() {
	initElementsBuscarColaborador("divPlanillaTable");
	showModalElement("divBuscarColaborador");
	triggerResizeEvent();
}

function changeSelEstadoSolicitud() {
	clearPlanillaTableRevisarSolicitudAutorizador();
}

function changeSelAnioSolicitud() {
	var anioSeleccionado = getValueInputText("selAnioSolicitud");
	hideElement("divErrorFechaInicioRevisarSolicitudAutorizador");
	hideElement("divErrorFechaFinalRevisarSolicitudAutorizador");
	hideElement("divErrorRevisarSolicitudAutorizador");
	modificarRangoFechaRevisarSolicitudAutorizador(anioSeleccionado);
	clearPlanillaTableRevisarSolicitudAutorizador();
}

function changeSelCanalAtencionSolicitud() {
	clearPlanillaTableRevisarSolicitudAutorizador();
}

function clickBtnConsultarSolicitud() {
	
	var flagValidacionFormulario = true;
	var flagFechaValida = true;
	var errorMessage = "";
	hideElement("divErrorRevisarSolicitudAutorizador");
	disabledElement("btnConsultarSolicitud");
	clearPlanillaTableRevisarSolicitudAutorizador();
	/*
	if (flagValidacionFormulario && trimText(getValueInputText("hidCodigoColaborador")).length != 0) {
		if (trimText(getValueInputText("hidCodigoDependencia")).length == 0) {
			flagValidacionFormulario = false;
			errorMessage = errorMessageRevisarSolicitudAutorizador.numeroRegistroUUOOInvalido;
		}
	}
	*/
	
	if (flagValidacionFormulario && trimText(getValueInputText("txtNroRegistro")).length != 0 && trimText(getValueInputText("hidCodigoColaborador")).length == 0 && trimText(getValueInputText("hidCodigoDependencia")).length != 0) {
		flagValidacionFormulario = false;
		errorMessage = errorMessageRevisarSolicitudAutorizador.numeroRegistroInvalido;
	}
	
	if (flagValidacionFormulario && trimText(getValueInputText("etiquetaFechaInicioSolicitud")) == "") {
		flagValidacionFormulario = false;
		errorMessage = errorMessageRevisarSolicitudAutorizador.fechaInicioInvalida;
	}
	
	if (flagValidacionFormulario && trimText(getValueInputText("etiquetaFechaFinSolicitud")) == "") {
		flagValidacionFormulario = false;
		errorMessage = errorMessageRevisarSolicitudAutorizador.fechaFinalInvalida;
	}
	
	/*
	if (flagValidacionFormulario && (getValueInputText("hidFlagFechaInicioValida") == "0" || getValueInputText("hidFlagFechaFinalValida") == "0")) {
		flagValidacionFormulario = false;
		errorMessage = errorMessageRevisarSolicitudAutorizador.rangoFechaInvalido;
	}
	*/
	
	if (flagValidacionFormulario && getValueInputText("hidFlagFechaInicioValida") == "0") {
		flagValidacionFormulario = false;
		flagFechaValida = false;
		validarFechaInicioRevisarSolicitudAutorizador();
	}
	
	if (flagValidacionFormulario && getValueInputText("hidFlagFechaFinalValida") == "0") {
		flagValidacionFormulario = false;
		flagFechaValida = false;
		validarFechaFinalRevisarSolicitudAutorizador();
	}
	
	if (flagValidacionFormulario) {
		callBuscarPlanillasBandejaAutorizacionSolicitud();
	}
	else {
		if (flagFechaValida) {
			showMessageErrorRevisarSolicitudAutorizador(errorMessage);
		}
		enabledElement("btnConsultarSolicitud");
	}
}

function clickBtnExportarExcelSolicitud() {
	
	var encodeParam = "&codigoDependencia=" + getUpperCaseValueInputText("hidCodigoDependencia");
	encodeParam += "&codPlanilla=" + getUpperCaseValueInputText("txtCodigoPlanilla");
	encodeParam += "&codTrabajador=" + getUpperCaseValueInputText("hidCodigoColaborador");
	encodeParam += "&codEstadoSolic=" + getValueInputText("selEstadoSolicitud");
	encodeParam += "&indicadorCanalAtencion=" + trimText(getValueInputText("selCanalAtencionSolicitud"));
	encodeParam += "&fechaDesde=" + getValueInputText("etiquetaFechaInicioSolicitud");
	encodeParam += "&fechaHasta=" + getValueInputText("etiquetaFechaFinSolicitud");
	encodeParam += "&codigoAutorizador=" + getValueInputText("hidCodigoAutorizador");
	location.href = contextPathUrl + "/revisarSolicitud.htm?action=exportarExcelBandejaAutorizacionSolicitud" + encodeParam;
}

function changeEtiquetaFechaInicioSolicitud() {
	if (isBrowserInternetExplorer()) {
		if (trimText(getValueInputText("etiquetaFechaInicioSolicitud")) != "" && isValidoFormatDate(getValueInputText("etiquetaFechaInicioSolicitud"))) {
			if (isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaInicioSolicitud")), getValueInputText("hidFechaMaximaAnioActual"))) {
				setValueInputText("etiquetaFechaInicioSolicitud", "");
			}
		}
		else {
			setValueInputText("etiquetaFechaInicioSolicitud", "");
		}
		changeDateEtiquetaFechaInicioSolicitudDiv();
	}
}

function changeEtiquetaFechaFinSolicitud() {
	if (isBrowserInternetExplorer()) {
		if (trimText(getValueInputText("etiquetaFechaFinSolicitud")) != "" && isValidoFormatDate(getValueInputText("etiquetaFechaFinSolicitud"))) {
			if (isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaFinSolicitud")), getValueInputText("hidFechaMaximaAnioActual"))) {
				setValueInputText("etiquetaFechaFinSolicitud", "");
			}
		}
		else {
			setValueInputText("etiquetaFechaFinSolicitud", "");
		}
		changeDateEtiquetaFechaFinSolicitudDiv();
	}
}

function changeDateEtiquetaFechaInicioSolicitudDiv() {
	clearPlanillaTableRevisarSolicitudAutorizador();
	validarFechaInicioRevisarSolicitudAutorizador();
}

function changeDateEtiquetaFechaFinSolicitudDiv() {
	clearPlanillaTableRevisarSolicitudAutorizador();
	validarFechaFinalRevisarSolicitudAutorizador();
}

function clickBtnAceptarMensajeConfirmacionRevisarSolicitudAutorizador() {
	hideModalElement("divMensajeConfirmacionRevisarSolicitudAutorizador");
}

function clickBtnAceptarMensajeConfirmacionErrorRevisarSolicitudAutorizador() {
	hideModalElement("divMensajeConfirmacionErrorRevisarSolicitudAutorizador");
}

function clickBtnSiAutorizarSolicitudRevisarSolicitudAutorizador() {
	disabledElement("btnSiAutorizarSolicitudRevisarSolicitudAutorizador");
	hideModalElement("divMensajeConfirmacionAutorizarSolicitudRevisarSolicitudAutorizador");
	callAutorizarSolicitudBandejaAutorizacionSolicitud(getValueInputText("hidCodPlanViajeAutorizarSolicitudRevisarSolicitudAutorizador"), getValueInputText("hidExpedientePlanViajeAutorizarSolicitudRevisarSolicitudAutorizador"), getValueInputText("hidIndicadorCanalAtencionAutorizarSolicitudRevisarSolicitudAutorizador"));
}

function clickBtnNoAutorizarSolicitudRevisarSolicitudAutorizador() {
	hideModalElement("divMensajeConfirmacionAutorizarSolicitudRevisarSolicitudAutorizador");
}

function clickBtnAceptarAutorizacionExitosaRevisarSolicitudAutorizador() {
	$("#btnConsultarSolicitud").trigger("click");
	hideModalElement("divMensajeConfirmacionAutorizacionExitosaRevisarSolicitudAutorizador");
}

function clickBtnAceptarDerivarOk() {
	$("#btnConsultarSolicitud").trigger("click");
	hideModalElement("divMensajeDerivarOk");
}

function validarFechaInicioRevisarSolicitudAutorizador() {
	
	var flagFechaValida = true;
	var errorMessage = "";
	hideElement("divErrorRevisarSolicitudAutorizador");
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("hidFechaInicialRangoFecha")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaInicioSolicitud")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRevisarSolicitudAutorizador.fechaInicioInvalida;
	}
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaInicioSolicitud")), formatEspDateToEngFormatDate(getValueInputText("hidFechaFinalRangoFecha")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRevisarSolicitudAutorizador.fechaInicioInvalida;
	}
	
	if (!flagFechaValida) {
		setValueInputText("hidFlagFechaInicioValida", "0");
		showMessageErrorRevisarSolicitudAutorizador(errorMessage);
	}
	else {
		if (trimText(getValueInputText("etiquetaFechaInicioSolicitud")) != "") {
			setValueInputText("hidFlagFechaInicioValida", "1");
			if (trimText(getValueInputText("etiquetaFechaFinSolicitud")) != "") {
				validarFechaFinalRevisarSolicitudAutorizador();
			}
		}
		else {
			setValueInputText("hidFlagFechaInicioValida", "0");
		}
	}
}

function validarFechaFinalRevisarSolicitudAutorizador() {
	
	var flagFechaValida = true;
	var errorMessage = "";
	hideElement("divErrorRevisarSolicitudAutorizador");
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("hidFechaInicialRangoFecha")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaFinSolicitud")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRevisarSolicitudAutorizador.fechaFinalInvalida;
	}
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaFinSolicitud")), formatEspDateToEngFormatDate(getValueInputText("hidFechaFinalRangoFecha")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRevisarSolicitudAutorizador.fechaFinalInvalida;
	}
	
	if (!flagFechaValida) {
		setValueInputText("hidFlagFechaFinalValida", "0");
		showMessageErrorRevisarSolicitudAutorizador(errorMessage);
	}
	else {
		if (trimText(getValueInputText("etiquetaFechaFinSolicitud")) != "") {
			setValueInputText("hidFlagFechaFinalValida", "1");
			if (trimText(getValueInputText("etiquetaFechaInicioSolicitud")) != "") {
				validarFechaFinalMayorIgualFechaInicioRevisarSolicitudAutorizador();
			}
		}
		else {
			setValueInputText("hidFlagFechaFinalValida", "0");
		}
	}
}

function validarFechaFinalMayorIgualFechaInicioRevisarSolicitudAutorizador() {
	
	var flagFechaValida = true;
	var errorMessage = "";
	hideElement("divErrorRevisarSolicitudAutorizador");
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaInicioSolicitud")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaFinSolicitud")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRevisarSolicitudAutorizador.fechaFinalMenorFechaInicial;
	}
	
	if (!flagFechaValida) {
		setValueInputText("hidFlagFechaFinalValida", "0");
		showMessageErrorRevisarSolicitudAutorizador(errorMessage);
	}
	else {
		setValueInputText("hidFlagFechaFinalValida", "1");
	}
}

function clickLinkConsultarSolicitud(codPlanilla) {
	
	initElementsConsultarSolicitud(codPlanilla, false,'bandeja-revision-solicitud');
	showModalElement("divConsultarSolicitudModal");
	triggerResizeEventSlow();
}

function clickLinkAutorizarSolicitud(codPlanViaje) {
	
	var planillaTable = $("#tblPlanilla");
	var rowData = planillaTable.getRowData(codPlanViaje);
	var codPlanilla = rowData.codPlanilla;
	var expedientePlanViaje = rowData.expedientePlanViaje;
	var indicadorCanalAtencion= rowData.indicadorCanalAtencion;
	setValueInputText("hidCodPlanViajeAutorizarSolicitudRevisarSolicitudAutorizador", codPlanViaje);
	setValueInputText("hidExpedientePlanViajeAutorizarSolicitudRevisarSolicitudAutorizador", expedientePlanViaje);
	setValueInputText("hidIndicadorCanalAtencionAutorizarSolicitudRevisarSolicitudAutorizador", indicadorCanalAtencion);
	setValueInputText("hidTxtCodPlanilla", codPlanilla);
	
	
	setHtmlElement("divTituloPanelAutorizarSolicitudRevisarSolicitudAutorizador", propertyMessageRevisarSolicitudAutorizador.autorizarSolicitudTitulo1 + codPlanilla + propertyMessageRevisarSolicitudAutorizador.autorizarSolicitudTitulo2);
	enabledElement("btnSiAutorizarSolicitudRevisarSolicitudAutorizador");
	
	//FE
	showMensajePreviaConfirmacionFirma(codPlanilla,function(){
		//showModalElement("divMensajeAutorizaEnviar");//mensaje modal de la firma	
		
		$("#txtPasswordUsuario").val("");
		firmaElectronicaValida(resultadoProcessVerificaFirma);
		
	},true);
	
	//showModalElement("divMensajeConfirmacionAutorizarSolicitudRevisarSolicitudAutorizador");
}

function clickLinkObservarSolicitud(codPlanViaje) {
	
	var planillaTable = $("#tblPlanilla");
	var rowData = planillaTable.getRowData(codPlanViaje);
	var dataParametrosObservarDocumento = new Object();
	dataParametrosObservarDocumento.codPlanViaje = codPlanViaje;
	dataParametrosObservarDocumento.codPlanilla = rowData.codPlanilla;
	dataParametrosObservarDocumento.montoTotal = rowData.mtoTotalFormateado;
	dataParametrosObservarDocumento.codPerAutoriza = getValueInputText("hidCodigoAutorizador");
	dataParametrosObservarDocumento.codigoSedeAutorizador = getValueInputText("hidCodigoSedeAutorizador");
	dataParametrosObservarDocumento.nombreAutorizador = getValueInputText("hidNumeroRegistroAutorizador") + " - " + getValueInputText("hidNombreAutorizador");
	dataParametrosObservarDocumento.expedientePlanViaje = rowData.expedientePlanViaje;
	dataParametrosObservarDocumento.codigoPaginaCaller = getValueInputText("hidCodigoPaginaCaller");
	initElementsObservarDocumento(dataParametrosObservarDocumento);
	showModalElement("divObservarDocumento");
}

function clickLinkAnularSolicitud(codPlanViaje) {
	
	var planillaTable = $("#tblPlanilla");
	var rowData = planillaTable.getRowData(codPlanViaje);
	var dataParametrosAnularDocumento = new Object();
	dataParametrosAnularDocumento.codPlanViaje = codPlanViaje;
	dataParametrosAnularDocumento.codPlanilla = rowData.codPlanilla;
	dataParametrosAnularDocumento.nomColaborador = rowData.numeroRegistroAlterno + " - " + rowData.nomColaborador;
	dataParametrosAnularDocumento.descripcionDependencia = rowData.nomUuOoCom;
	dataParametrosAnularDocumento.montoTotal = rowData.mtoTotalFormateado;
	dataParametrosAnularDocumento.codigoColaborador = getValueInputText("hidCodigoAutorizador");
	dataParametrosAnularDocumento.codigoSedeColaborador = getValueInputText("hidCodigoSedeAutorizador");
	dataParametrosAnularDocumento.expedientePlanViaje = rowData.expedientePlanViaje;
	dataParametrosAnularDocumento.codigoPaginaCaller = getValueInputText("hidCodigoPaginaCaller");
	initElementsAnularDocumento(dataParametrosAnularDocumento);
	showModalElement("divAnularDocumento");
}

function clickLinkConsultarDetalleSolicitudAutorizador(codPlanViaje) {
	var planillaTable = $( "#tblPlanilla" );
	var rowData = planillaTable.getRowData(codPlanViaje);	
	var tipoDestino = $.trim( rowData.tipoDestino );
	var indicadorHoras = $.trim( rowData.indicadorHoras );
	initElementsConsultarSolicitudDetalle("divPlanillaTable", codPlanViaje,tipoDestino,indicadorHoras);
	showModalElement("divConsultarSolicitudDetalle");
	triggerResizeEvent();
	triggerResizeEventSlow();
}

function clickLinkConsultarSeguimientoSolicitudAutorizador(codPlanViaje) {
	
	var planillaTable = $("#tblPlanilla");
	var rowData = planillaTable.getRowData(codPlanViaje);
	var dataParametrosConsultarSeguimiento = new Object();
	dataParametrosConsultarSeguimiento.codPlanViaje = codPlanViaje;
	dataParametrosConsultarSeguimiento.numeroExpediente = rowData.expedientePlanViaje;
	dataParametrosConsultarSeguimiento.idElementCallModal = "divPlanillaTable";
	dataParametrosConsultarSeguimiento.codigoPaginaCaller = "01";
	initElementsConsultarSeguimiento(dataParametrosConsultarSeguimiento);
	showModalElement("divConsultarSeguimiento");
	triggerResizeEvent();
	triggerResizeEventSlow();
}

function clickLinkConsultarAdjuntosSolicitudAutorizador(codPlanViaje) {
	
	var planillaTable = $("#tblPlanilla");
	var rowData = planillaTable.getRowData(codPlanViaje);
	var codPlanilla = $.trim( rowData.codPlanilla );
	var dataParametrosArchivo = new Object();
	dataParametrosArchivo.planViajeId = codPlanViaje;
	dataParametrosArchivo.codPlanilla = codPlanilla;
    dataParametrosArchivo.codigoBoleto = "";
    dataParametrosArchivo.estadoOrigen = "V";
    dataParametrosArchivo.estadoLLamada = "C";
    dataParametrosArchivo.numeroRegistroColaborador = rowData.numeroRegistroAlterno;
    dataParametrosArchivo.paginaOrigen = "PRINCIPAL";
	
	existenArchivosAdjuntos(dataParametrosArchivo, function(){
		
		initElementsConsultarRegistrarEliminarArchivo(dataParametrosArchivo);
		$("#divAdjuntarDocumento").modal("show");
		triggerResizeEvent();

		setTimeout(function() {
			resizeTable( "tblArchivo" );
		}, 700);		
		
	});
	
	
}

function modificarRangoFechaRevisarSolicitudAutorizador(anioSeleccionado) {
	
	setValueInputText("hidFechaInicialRangoFecha", "01/01/" + anioSeleccionado);
	setValueInputText("hidFechaFinalRangoFecha", "31/12/" + anioSeleccionado);
	setValueInputText("etiquetaFechaInicioSolicitud", getValueInputText("hidFechaInicialRangoFecha"));
	setValueInputText("etiquetaFechaFinSolicitud", getValueInputText("hidFechaFinalRangoFecha"));
	setValueInputText("hidFlagFechaInicioValida", "1");
	setValueInputText("hidFlagFechaFinalValida", "1");
}

function callBuscarPlanillasBandejaAutorizacionSolicitud() {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/revisarSolicitud.htm?action=buscarPlanillasBandejaAutorizacionSolicitud",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codigoDependencia": getUpperCaseValueInputText("hidCodigoDependencia"),
				"codPlanilla": getUpperCaseValueInputText("txtCodigoPlanilla"),
				"codTrabajador": getUpperCaseValueInputText("hidCodigoColaborador"),
				"codEstadoSolic": getValueInputText("selEstadoSolicitud"),
				"indicadorCanalAtencion": trimText(getValueInputText("selCanalAtencionSolicitud")),
				"fechaDesde": getValueInputText("etiquetaFechaInicioSolicitud"),
				"fechaHasta": getValueInputText("etiquetaFechaFinSolicitud"),
				"codigoAutorizador": getValueInputText("hidCodigoAutorizador")
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showElement("divLoadingRevisarSolicitudAutorizador");
			},
			complete: function() {
				enabledElement("btnConsultarSolicitud");
				hideElement("divLoadingRevisarSolicitudAutorizador");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var codigoConsulta = result.codigoConsulta;
				var errorMessage = result.errorMessage;
				if (codigoConsulta != null && codigoConsulta == "00") {
					var planillaList = result.planViajeList;
					showPlanillasRevisarSolicitudAutorizador(planillaList);
				}
				else if (codigoConsulta == "02") {
					showMessageErrorRevisarSolicitudAutorizador(errorMessage);
				}
				else {
					showMensajeConfirmacionErrorRevisarSolicitudAutorizador(errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callBuscarPlanillasBandejaAutorizacionSolicitud");
			}
		});
	}, 500);
}

function callAutorizarSolicitudBandejaAutorizacionSolicitud(codPlanViaje, expedientePlanViaje, indicadorCanalAtencion) {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/revisarSolicitud.htm?action=autorizarSolicitudBandejaAutorizacionSolicitud",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codPlanViaje": codPlanViaje,
				"codPerAutoriza": getValueInputText("hidCodigoAutorizador"),
				"codigoDependenciaAutorizador": getValueInputText("hidCodigoDependenciaAutorizador"),
				"codigoSedeAutorizador": getValueInputText("hidCodigoSedeAutorizador"),
				"codigoNivelAutorizador": getValueInputText("hidCodigoNivelAutorizador"),
				"expedientePlanViaje": expedientePlanViaje,
				"numArchivoPdfFirmado":numArchivoPdfFirmado,
				"indicadorCanalAtencion": indicadorCanalAtencion
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showModalElement("divMensajeConfirmacionLoadingRevisarSolicitudAutorizador");
			},
			complete: function() {
				hideModalElement("divMensajeConfirmacionLoadingRevisarSolicitudAutorizador");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				numArchivoPdfFirmado = null;//seteamos el valor, variable definida en firmaElectronica.js
				var codigoOperacion = result.codigoOperacion;
				var errorMessage = result.errorMessage;
				var successMessage = result.successMessage;
				if (codigoOperacion != null && codigoOperacion == "00") {
					showModalElement("divMensajeConfirmacionAutorizacionExitosaRevisarSolicitudAutorizador");
				}
				else {
					showMensajeConfirmacionErrorRevisarSolicitudAutorizador(errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callAutorizarSolicitudBandejaAutorizacionSolicitud");
			}
		});
	}, 500);
}

function showMessageErrorFechaInicioRevisarSolicitudAutorizador(errorMessage) {
	setHtmlElement("etiquetaErrorFechaInicioRevisarSolicitudAutorizador", errorMessage);
	showElement("divErrorFechaInicioRevisarSolicitudAutorizador");
}

function showMessageErrorFechaFinalRevisarSolicitudAutorizador(errorMessage) {
	setHtmlElement("etiquetaErrorFechaFinalRevisarSolicitudAutorizador", errorMessage);
	showElement("divErrorFechaFinalRevisarSolicitudAutorizador");
}

function showMessageErrorRevisarSolicitudAutorizador(errorMessage) {
	setHtmlElement("etiquetaErrorRevisarSolicitudAutorizador", errorMessage);
	showElement("divErrorRevisarSolicitudAutorizador");
}

function showMensajeConfirmacionRevisarSolicitudAutorizador(messageTitulo) {
	hideElement("divBodyPanelMensajeConfirmacionRevisarSolicitudAutorizador");
	setHtmlElement("divTituloPanelMensajeConfirmacionRevisarSolicitudAutorizador", messageTitulo);
	showModalElement("divMensajeConfirmacionRevisarSolicitudAutorizador");
}

function showMensajeConfirmacionErrorRevisarSolicitudAutorizador(messageTitulo) {
	hideElement("divBodyPanelMensajeConfirmacionErrorRevisarSolicitudAutorizador");
	setHtmlElement("divTituloPanelMensajeConfirmacionErrorRevisarSolicitudAutorizador", messageTitulo);
	showModalElement("divMensajeConfirmacionErrorRevisarSolicitudAutorizador");
}

function showPlanillasRevisarSolicitudAutorizador(planillaArray) {
	
	if (planillaArray != null && planillaArray.length > 0) {
		var planillaTable = $("#tblPlanilla");
		planillaTable.clearGridData();
		for (var i = 0; i < planillaArray.length; i++) {
			var planilla = planillaArray[i];
			var datarow = {
				codPlanViaje: planilla.codPlanViaje,
				codPlanilla: planilla.codPlanilla,
				fechaRegistro: planilla.fechaRegistroFormateada,
				numeroRegistroAlterno: planilla.numeroRegistroAlterno,
				nomColaborador: planilla.nomColaborador,
				tipoDestino: planilla.tipoDestino,
				nomTipoViatico: planilla.nomTipoViatico,
				mtoTotal: planilla.mtoTotal,
				mtoTotalFormateado: planilla.mtoTotalFormateado,
				canalAtencion: planilla.canalAtencion,
				fecMaxRend: planilla.fecMaxRendFormateada,
				codEstadoSolic: planilla.codEstadoSolic,
				nomEstSolic: planilla.nomEstSolic,
				nomUuOoCom: planilla.nomUuOoCom,
				indicadorCanalAtencion: planilla.indicadorCanalAtencion,
				expedientePlanViaje: planilla.expedientePlanViaje,
				numeroRegistroArchivo: planilla.numeroRegistroArchivo,
				autorizarSolicitud: "AUTORIZAR",
				observarSolicitud: "OBSERVAR",
				anularSolicitud: "ANULAR",
				detalleSolicitud: "DETALLE",
				seguimientoSolicitud: "SEGUIMIENTO",
				verAdjuntosPlanilla: "VER",
				indicadorHoras: planilla.indicadorHoras,
				tipoDestino: planilla.tipoDestino 
			};
			planillaTable.jqGrid("addRowData", datarow.codPlanViaje, datarow);
		}
		planillaTable.trigger("reloadGrid");
		enabledElement("btnExportarExcelSolicitud");
	}
	else {
		setHtmlElement("divPlanillaPagerTable_left", errorMessageRevisarSolicitudAutorizador.sinRegistrosBusqueda);
	}
}

function clearPlanillaTableRevisarSolicitudAutorizador() {
	var planillaTable = $("#tblPlanilla");
	planillaTable.clearGridData();
	disabledElement("btnExportarExcelSolicitud");
	setHtmlElement("divPlanillaPagerTable_left", "");
}

/*Inicio Codigo - Reutilizacion buscarUUOO*/
var dataParametrosBuscarUUOO = new Object();
dataParametrosBuscarUUOO.idCodigoRegistrador = "hidCodigoAutorizador";
dataParametrosBuscarUUOO.idCodigoTipoUUOOViatico = getValueInputText("hidFlagBuscarUUOO");
dataParametrosBuscarUUOO.idDivScreenBlock = "divScreenBlock";

var buscarUUOOBeforeMethod = function() {
};

var buscarUUOOAfterMethod = function(rowData) {
	
	setValueInputText("txtNroRegistro", "");
	setValueInputText("hidTxtNroRegistro", "");
	setValueInputText("txtNombreColaborador", "");
	setValueInputText("hidCodigoColaborador", "");
	setValueInputText("hidCodigoEstadoColaborador", "");
	setValueInputText("txtUUOO", rowData["uuoo"]);
	setValueInputText("hidTxtUUOO", rowData["uuoo"]);
    setValueInputText("txtDescripcionDependencia", rowData["descripcionUUOO"]);
    setValueInputText("hidCodigoDependencia", rowData["codigoDependencia"]);
    hideElement("divErrorRevisarSolicitudAutorizador");
    clearPlanillaTableRevisarSolicitudAutorizador();
};

var buscarUUOOService = new BuscarUUOOService(dataParametrosBuscarUUOO, buscarUUOOBeforeMethod, buscarUUOOAfterMethod);
/*Fin Codigo - Reutilizacion buscarUUOO*/


/*Inicio Codigo - Reutilizacion buscarUUOOAutoriza*/
var dataParametrosBuscarUUOOAutoriza = new Object();
dataParametrosBuscarUUOOAutoriza.idCodigoRegistrador = "hidCodigoAutorizador";
dataParametrosBuscarUUOOAutoriza.idCodigoTipoUUOOViatico = getValueInputText("hidFlagBuscarUUOO");
dataParametrosBuscarUUOOAutoriza.idDivScreenBlock = "divScreenBlock";

var buscarUUOOAutorizaBeforeMethod = function() {
};

var buscarUUOOAutorizaAfterMethod = function(rowData) {
	
	/*setValueInputText("txtUUOO", rowData["uuoo"]);
	setValueInputText("hidTxtUUOO", rowData["uuoo"]);
    setValueInputText("txtDescripcionDependencia", rowData["descripcionUUOO"]);
    setValueInputText("hidCodigoDependencia", rowData["codigoDependencia"]);
    hideElement("divErrorRevisarSolicitudAutorizador");
    clearPlanillaTableRevisarSolicitudAutorizador();*/
    
    //Aquí llamamos al servicio rest respectivo...
    //alert("Codigo de uuoo seleccionado:"+rowData["uuoo"]+", codigo dependencia:"+rowData["codigoDependencia"]);
    
    //Actualizar
    var codDependencia = rowData["codigoDependencia"];
    var codPlanViaje = getValueInputText("hidCodPlanViajeAutorizarSolicitudRevisarSolicitudAutorizador");
    var codExpediente = getValueInputText("hidExpedientePlanViajeAutorizarSolicitudRevisarSolicitudAutorizador");
    var indicadorCanalAtencion = getValueInputText("hidIndicadorCanalAtencionAutorizarSolicitudRevisarSolicitudAutorizador");
    
    callAjaxActualizarDependenciaPlanViaje(codDependencia,codPlanViaje,codExpediente,indicadorCanalAtencion);
};

var callAjaxActualizarDependenciaPlanViaje = function(codDependencia,codPlanViaje,codExpediente,indicadorCanalAtencion) {

	$.ajax({
		url: contextPathUrl + "/revisarSolicitud.htm?action=actualizarDependenciaPlanViaje",
		type: "post",
		dataType: "json",
		cache: false,
		data: {
			"codDependencia": codDependencia,
			"codPlanViaje": codPlanViaje,
			"codigoSedeAutorizador": getValueInputText("hidCodigoSedeAutorizador"),
			"codExpediente": codExpediente,
			"indicadorCanalAtencion": indicadorCanalAtencion
		},
		beforeSend: function() {
			// bloquearScreen();
		},
		complete: function() {
			// desbloquearScreen();
		},
		success: function(result) {
			setHtmlElement("divTituloPanelMensajeDerivarOk", result.mensajeDerivacion);
			showModalElement("divMensajeDerivarOk");
		},
		error: function( error ) {
			handleError( error );
		}
	});
};


var buscarUUOOAutorizaService = new BuscarUUOOService(dataParametrosBuscarUUOOAutoriza, buscarUUOOAutorizaBeforeMethod, buscarUUOOAutorizaAfterMethod);
/*Fin Codigo - Reutilizacion buscarUUOOAutoriza*/


/*Inicio Codigo - Reutilizacion buscarUUOOInput*/
function buscarUUOOInputBeforeMethod() {
	
	setValueInputText("txtNroRegistro", "");
	setValueInputText("hidTxtNroRegistro", "");
	setValueInputText("hidCodigoColaborador", "");
	setValueInputText("txtNombreColaborador", "");
	setValueInputText("hidCodigoEstadoColaborador", "");
	setValueInputText("hidTxtUUOO", "");
	setValueInputText("txtDescripcionDependencia", "");
	setValueInputText("hidCodigoDependencia", "");
	clearPlanillaTableRevisarSolicitudAutorizador();
}

function buscarUUOOInputAfterMethod(uuooList) {
	
	if (uuooList != null && uuooList.length > 0) {
		for (var i = 0; i < uuooList.length; i++) {
			var uuoo = uuooList[i];
			var datarow = {
				codigoDependencia: uuoo.cod_dep,
				uuoo: uuoo.uuoo,
				uuooDetalle: uuoo.nom_largo
			};
			setValueInputText("txtUUOO", datarow.uuoo);
			setValueInputText("hidTxtUUOO", datarow.uuoo);
			setValueInputText("hidCodigoDependencia", datarow.codigoDependencia);
			setValueInputText("txtDescripcionDependencia", datarow.uuooDetalle);
			break;
		}
	}
	else {         
		setHtmlElement("etiquetaErrorRevisarSolicitudAutorizador", errorMessageBuscarUUOOInput.sinRegistrosBusqueda);
		showElement("divErrorRevisarSolicitudAutorizador");
	}
}

var buscarUUOOInputService = new BuscarUUOOInputService();

function initElementsBuscarUUOOInputService(errorMessageBuscarUUOOInput) {
	
	var dataParametros = new Object();
	dataParametros.idNumeroUUOO = "txtUUOO";
	dataParametros.idCodigoRegistrador = "hidCodigoAutorizador";
	dataParametros.idCodigoTipoUUOOViatico = getValueInputText("hidFlagBuscarUUOO");
	dataParametros.idDivLoading = "divLoadingBuscarInput";
	dataParametros.idDivError = "divErrorRevisarSolicitudAutorizador";
	dataParametros.idEtiquetaError = "etiquetaErrorRevisarSolicitudAutorizador";
	dataParametros.idDivScreenBlock = "divScreenBlock";
	dataParametros.errorMessage = errorMessageBuscarUUOOInput;
	buscarUUOOInputService = new BuscarUUOOInputService(dataParametros, buscarUUOOInputBeforeMethod, buscarUUOOInputAfterMethod);
}
/*Fin Codigo - Reutilizacion buscarUUOOInput*/

/*Inicio Codigo - Reutilizacion buscarColaborador*/
var dataParametrosBuscarColaborador = new Object();
dataParametrosBuscarColaborador.idCodigoRegistrador = "hidCodigoAutorizador";
dataParametrosBuscarColaborador.idNumeroRegistroRegistrador = "hidNumeroRegistroAutorizador";
dataParametrosBuscarColaborador.idCodigoTipoUsuarioViatico = getValueInputText("hidFlagBuscarColaborador");
dataParametrosBuscarColaborador.idDivScreenBlock = "divScreenBlock";

var buscarColaboradorBeforeMethod = function() {
};

var buscarColaboradorAfterMethod = function(rowData) {
	
	setValueInputText("txtNroRegistro", rowData["numeroRegistro"]);
	setValueInputText("hidTxtNroRegistro", rowData["numeroRegistro"]);
	setValueInputText("hidCodigoColaborador", rowData["codigoEmpleado"]);
	setValueInputText("txtNombreColaborador", rowData["nombreCompleto"]);
	setValueInputText("hidCodigoEstadoColaborador", rowData["codigoEstado"]);
	setValueInputText("txtUUOO", rowData["uuoo"]);
	setValueInputText("hidTxtUUOO", rowData["uuoo"]);
	setValueInputText("txtDescripcionDependencia", rowData["uuooDetalle"]);
	setValueInputText("hidCodigoDependencia", rowData["codigoDependencia"]);
	hideElement("divErrorRevisarSolicitudAutorizador");
	clearPlanillaTableRevisarSolicitudAutorizador();
};

var buscarColaboradorService = new BuscarColaboradorService(dataParametrosBuscarColaborador, buscarColaboradorBeforeMethod, buscarColaboradorAfterMethod);
/*Fin Codigo - Reutilizacion buscarColaborador*/

/*Inicio Codigo - Reutilizacion buscarColaboradorInput*/
var buscarColaboradorInputBeforeMethod = function() {
	
	setValueInputText("hidTxtNroRegistro", "");
	setValueInputText("hidCodigoColaborador", "");
	setValueInputText("txtNombreColaborador", "");
	setValueInputText("hidCodigoEstadoColaborador", "");
	/*
	setValueInputText("txtUUOO", "");
	setValueInputText("txtDescripcionDependencia", "");
	setValueInputText("hidCodigoDependencia", "");
	*/
	clearPlanillaTableRevisarSolicitudAutorizador();
};

var buscarColaboradorInputAfterMethod = function(colaboradorList) {
	
	if (colaboradorList != null && colaboradorList.length > 0) {
		for (var i = 0; i < colaboradorList.length; i++) {
			var colaborador = colaboradorList[i];
			var datarow = {
				numeroRegistro: colaborador.numero_registro,
				nombreCompleto: colaborador.nombre_completo,
				uuoo: colaborador.uuoo,
				codigoDependencia: colaborador.codigoDependencia,
				uuooDetalle: colaborador.dependencia,
				codigoEmpleado: colaborador.codigoEmpleado,
				codigoEstado: colaborador.codigoEstado,
				estadoDetalle: colaborador.estado
			};
			setValueInputText("hidTxtNroRegistro", datarow.numeroRegistro);
			setValueInputText("hidCodigoColaborador", datarow.codigoEmpleado);
			setValueInputText("txtNombreColaborador", datarow.nombreCompleto);
			setValueInputText("hidCodigoEstadoColaborador", datarow.codigoEstado);
			setValueInputText("txtUUOO", datarow.uuoo);
			setValueInputText("hidTxtUUOO", datarow.uuoo);
			setValueInputText("txtDescripcionDependencia", datarow.uuooDetalle);
			setValueInputText("hidCodigoDependencia", datarow.codigoDependencia);
			break;
		}
	}
	else {
		setHtmlElement("etiquetaErrorRevisarSolicitudAutorizador", errorMessageBuscarColaboradorInput.sinRegistrosBusqueda);
		showElement("divErrorRevisarSolicitudAutorizador");
	}
};

var buscarColaboradorInputService = new BuscarColaboradorInputService();

function initElementsBuscarColaboradorInputService(errorMessageBuscarColaboradorInput) {
	
	var dataParametros = new Object();
	dataParametros.idNumeroRegistroColaborador = "txtNroRegistro";
	dataParametros.idCodigoRegistrador = "hidCodigoAutorizador";
	dataParametros.idNumeroRegistroRegistrador = "hidNumeroRegistroAutorizador";
	dataParametros.idCodigoTipoUsuarioViatico = getValueInputText("hidFlagBuscarColaborador");
	dataParametros.estadoLlamada = "B";
	dataParametros.idDivLoading = "divLoadingBuscarInput";
	dataParametros.idDivError = "divErrorRevisarSolicitudAutorizador";
	dataParametros.idEtiquetaError = "etiquetaErrorRevisarSolicitudAutorizador";
	dataParametros.idDivScreenBlock = "divScreenBlock";
	dataParametros.errorMessage = errorMessageBuscarColaboradorInput;
	buscarColaboradorInputService = new BuscarColaboradorInputService(dataParametros, buscarColaboradorInputBeforeMethod, buscarColaboradorInputAfterMethod);
}
/*Fin Codigo - Reutilizacion buscarColaboradorInput*/

/*Inicio Codigo - Reutilizacion adjuntarDocumento*/
var adjuntarDocumentoBeforeMethod = function() {
};

var adjuntarDocumentoAfterMethod = function(data) {
};

var adjuntarDocumentoService = new AdjuntarDocumentoService(adjuntarDocumentoBeforeMethod, adjuntarDocumentoAfterMethod);
/*Fin Codigo - Reutilizacion adjuntarDocumento*/

$(window).on("resize", function() {
	resizeTable("tblPlanilla");
	//Inicializando las tablas de los modales
	resizeTable("tblUUOO");
	resizeTable("tblUUOOAutoriza");
	resizeTable("tblColaborador");
	resizeTable("tblDetalleViatico");
	resizeTable("tblDetalleGasto");
	resizeTable("tblSeguimiento");
	resizeTable("tblArchivo");
});