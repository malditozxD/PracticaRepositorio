function initElementsRevisarReembolsoAutorizador() {
	removeDuplicateComponents();
	setInitElementsRevisarReembolsoAutorizador();
	setInitPlanillaTable();
}

function setInitElementsRevisarReembolsoAutorizador() {
	
	hideElement("divHiddenConsultarReembolsoPost");
	disabledElement("btnExportarExcelReembolso");
	setValueInputText("selAnioReembolso", getValueInputText("hidAnioActual"));
	setValueInputText("hidFechaMaximaAnioActual", getValueInputText("hidAnioActual") + "/12/31");
	modificarRangoFechaRevisarReembolsoAutorizador(getValueInputText("hidAnioActual"));
	
	addEventElement("btnBuscarUUOOReembolso", "click", clickBtnBuscarUUOOReembolso);
	addEventElement("btnBuscarColaboradorReembolso", "click", clickBtnBuscarColaboradorReembolso);
	addEventElement("selEstadoReembolso", "change", changeSelEstadoReembolso);
	addEventElement("selAnioReembolso", "change", changeSelAnioReembolso);
	addEventElement("btnConsultarReembolso", "click", clickBtnConsultarReembolso);
	addEventElement("btnExportarExcelReembolso", "click", clickBtnExportarExcelReembolso);
	
	addEventElement("etiquetaFechaInicioReembolso", "change", changeEtiquetaFechaInicioReembolso);
	addEventElement("etiquetaFechaFinReembolso", "change", changeEtiquetaFechaFinReembolso);
	initDateTimePickerWithMaxDate("etiquetaFechaInicioReembolsoDiv", "dp.change", "changeDate", changeDateEtiquetaFechaInicioReembolsoDiv, getValueInputText("hidFechaMaximaAnioActual"));
	initDateTimePickerWithMaxDate("etiquetaFechaFinReembolsoDiv", "dp.change", "changeDate", changeDateEtiquetaFechaFinReembolsoDiv, getValueInputText("hidFechaMaximaAnioActual"));
	
	addEventElement("btnAceptarMensajeConfirmacionRevisarReembolsoAutorizador", "click", clickBtnAceptarMensajeConfirmacionRevisarReembolsoAutorizador);
	addEventElement("btnAceptarMensajeConfirmacionErrorRevisarReembolsoAutorizador", "click", clickBtnAceptarMensajeConfirmacionErrorRevisarReembolsoAutorizador);
	addEventElement("btnSiAutorizarReembolsoRevisarReembolsoAutorizador", "click", clickBtnSiAutorizarReembolsoRevisarReembolsoAutorizador);
	addEventElement("btnNoAutorizarReembolsoRevisarReembolsoAutorizador", "click", clickBtnNoAutorizarReembolsoRevisarReembolsoAutorizador);
	addEventElement("btnAceptarAutorizacionExitosaRevisarReembolsoAutorizador", "click", clickBtnAceptarAutorizacionExitosaRevisarReembolsoAutorizador);
}

function setInitPlanillaTable() {
	
	var planillaTable = $("#tblPlanilla");
	var heightJqGrid = 200;
	setStyleElement("divPlanillaTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 2, true));
	if (planillaTable) {
		var planillaTableDiv = $("#divPlanillaTable");
		var widthTable = planillaTableDiv.width();
		planillaTable.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			datatype: "local",
			rowNum: 10,
			rowList: [10, 20],
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Código Plan Viaje",
				"Nro. Solicitud",
				"Nro. Solicitud",
				"Fec. Registro Solicitud",
				"Número Registro",
				"Código Colaborador",
				"Nombre Colaborador",
				"Total Días de la Comisión",
				"Monto Total",
				"Total Gasto",
				"Código Estado Planilla",
				"Estado Solicitud",
				"Código Autorizador",
				"Nombre del Autorizador",
				"UUOO",
				"Expediente Plan Viaje",
				"Expediente Rendicion",
				"Numero Registro Archivo",
				"",
				"",
				"Acción",
				"",
				"",
				""
			],
			colModel: [
				{name: "codPlanViaje", index: "codPlanViaje", width: (1*widthTable/20), hidden: true},
				{name: "codPlanilla", index: "codPlanilla", width: (1*widthTable/20), align: "center", hidden: true},
				{name: "codPlanillaLink", index: "codPlanillaLink", width: (2*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkConsultarReembolso('" + rowData.codPlanViaje + "');\">" + rowData.codPlanilla + "</a>";
						return htmlElement;
					}
				},
				{name: "fechaRegistro", index: "fechaRegistro", width: (1.5*widthTable/20), align: "center"},
				{name: "numeroRegistroAlterno", index: "numeroRegistroAlterno", width: (1*widthTable/20), hidden: true},
				{name: "codTrabajador", index: "codTrabajador", width: (1*widthTable/20), hidden: true},
				{name: "nomColaborador", index: "nomColaborador", width: (2.7*widthTable/20)},
				{name: "numDias", index: "numDias", width: (1.5*widthTable/20), align: "center"},
				{name: "mtoTotal", index: "mtoTotal", width: (1*widthTable/20), hidden: true},
				{name: "mtoTotalFormateado", index: "mtoTotalFormateado", width: (1.5*widthTable/20), align: "right"},
				{name: "codEstadoSolic", index: "codEstadoSolic", width: (1*widthTable/20), hidden: true},
				{name: "nomEstSolic", index: "nomEstSolic", width: (1.6*widthTable/20)},
				{name: "codPerAutoriza", index: "codPerAutoriza", width: (1*widthTable/20), hidden: true},
				{name: "nomAutorizador", index: "nomAutorizador", width: (2.7*widthTable/20)},
				{name: "nomUuOoCom", index: "nomUuOoCom", width: (1*widthTable/20), hidden: true},
				{name: "expedientePlanViaje", index: "expedientePlanViaje", width: (1*widthTable/20), hidden: true},
				{name: "expedienteRendicion", index: "expedienteRendicion", width: (1*widthTable/20), hidden: true},
				{name: "numeroRegistroArchivo", index: "numeroRegistroArchivo", width: (1*widthTable/20), hidden: true},
				{name: "autorizarReembolso", index: "autorizarReembolso", width: (1.1*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkAutorizarReembolso('" + rowData.codPlanViaje + "');\">" + rowData.autorizarReembolso + "</a>";
						return htmlElement;
					}
				},
				{name: "observarReembolso", index: "observarReembolso", width: (1.1*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkObservarReembolso('" + rowData.codPlanViaje + "');\">" + rowData.observarReembolso + "</a>";
						return htmlElement;
					}
				},
				{name: "anularReembolso", index: "anularReembolso", width: (1.1*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkAnularReembolso('" + rowData.codPlanViaje + "');\">" + rowData.anularReembolso + "</a>";
						return htmlElement;
					}
				},
				{name: "detalleReembolso", index: "detalleReembolso", width: (1.1*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkConsultarDetalleReembolsoAutorizador('" + rowData.codPlanViaje + "');\">" + rowData.detalleReembolso + "</a>";
						return htmlElement;
					}
				},
				{name: "seguimientoReembolso", index: "seguimientoReembolso", width: (1.5*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkConsultarSeguimientoReembolsoAutorizador('" + rowData.codPlanViaje + "');\">" + rowData.seguimientoReembolso + "</a>";
						return htmlElement;
					}
				},
				{name: "verAdjuntosPlanilla", index: "verAdjuntosPlanilla", width: (0.6*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkConsultarAdjuntosReembolsoAutorizador('" + rowData.codPlanViaje + "');\">" + rowData.verAdjuntosPlanilla + "</a>";
						return htmlElement;
					}
				}
			],
			caption: "Solicitudes",
			pager: "#divPlanillaPagerTable",
			loadui: "disable"
		});
		planillaTable.clearGridData();
	}
}

function clickBtnBuscarUUOOReembolso() {
	initElementsBuscarUUOO("divPlanillaTable");
	showModalElement("divBuscarUUOO");
    triggerResizeEvent();
}

function clickBtnBuscarColaboradorReembolso() {
	initElementsBuscarColaborador("divPlanillaTable");
	showModalElement("divBuscarColaborador");
	triggerResizeEvent();
}

function changeSelEstadoReembolso() {
	clearPlanillaTableRevisarReembolsoAutorizador();
}

function changeSelAnioReembolso() {
	
	var anioSeleccionado = getValueInputText("selAnioReembolso");
	hideElement("divErrorFechaInicioRevisarReembolsoAutorizador");
	hideElement("divErrorFechaFinalRevisarReembolsoAutorizador");
	hideElement("divErrorRevisarReembolsoAutorizador");
	modificarRangoFechaRevisarReembolsoAutorizador(anioSeleccionado);
	clearPlanillaTableRevisarReembolsoAutorizador();
}

function clickBtnConsultarReembolso() {
	
	var flagValidacionFormulario = true;
	var flagFechaValida = true;
	var errorMessage = "";
	hideElement("divErrorRevisarReembolsoAutorizador");
	disabledElement("btnConsultarReembolso");
	clearPlanillaTableRevisarReembolsoAutorizador();
	/*
	if (flagValidacionFormulario && trimText(getValueInputText("hidCodigoColaborador")).length != 0) {
		if (trimText(getValueInputText("hidCodigoDependencia")).length == 0) {
			flagValidacionFormulario = false;
			errorMessage = errorMessageRevisarReembolsoAutorizador.numeroRegistroUUOOInvalido;
		}
	}
	*/
	
	if (flagValidacionFormulario && trimText(getValueInputText("txtNroRegistro")).length != 0 && trimText(getValueInputText("hidCodigoColaborador")).length == 0 && trimText(getValueInputText("hidCodigoDependencia")).length != 0) {
		flagValidacionFormulario = false;
		errorMessage = errorMessageRevisarReembolsoAutorizador.numeroRegistroInvalido;
	}
	
	if (flagValidacionFormulario && trimText(getValueInputText("etiquetaFechaInicioReembolso")) == "") {
		flagValidacionFormulario = false;
		errorMessage = errorMessageRevisarReembolsoAutorizador.fechaInicioInvalida;
	}
	
	if (flagValidacionFormulario && trimText(getValueInputText("etiquetaFechaFinReembolso")) == "") {
		flagValidacionFormulario = false;
		errorMessage = errorMessageRevisarReembolsoAutorizador.fechaFinalInvalida;
	}
	
	/*
	if (flagValidacionFormulario && (getValueInputText("hidFlagFechaInicioValida") == "0" || getValueInputText("hidFlagFechaFinalValida") == "0")) {
		flagValidacionFormulario = false;
		errorMessage = errorMessageRevisarReembolsoAutorizador.rangoFechaInvalido;
	}
	*/
	
	if (flagValidacionFormulario && getValueInputText("hidFlagFechaInicioValida") == "0") {
		flagValidacionFormulario = false;
		flagFechaValida = false;
		validarFechaInicioRevisarReembolsoAutorizador();
	}
	
	if (flagValidacionFormulario && getValueInputText("hidFlagFechaFinalValida") == "0") {
		flagValidacionFormulario = false;
		flagFechaValida = false;
		validarFechaFinalRevisarReembolsoAutorizador();
	}
	
	if (flagValidacionFormulario) {
		callBuscarPlanillasBandejaAutorizacionReembolso();
	}
	else {
		if (flagFechaValida) {
			showMessageErrorRevisarReembolsoAutorizador(errorMessage);
		}
		enabledElement("btnConsultarReembolso");
	}
}

function clickBtnExportarExcelReembolso() {
	
	var encodeParam = "&codigoDependencia=" + getUpperCaseValueInputText("hidCodigoDependencia");
	encodeParam += "&codPlanilla=" + getUpperCaseValueInputText("txtCodigoPlanilla");
	encodeParam += "&codTrabajador=" + getUpperCaseValueInputText("hidCodigoColaborador");
	encodeParam += "&codEstadoSolic=" + getValueInputText("selEstadoReembolso");
	encodeParam += "&fechaDesde=" + getValueInputText("etiquetaFechaInicioReembolso");
	encodeParam += "&fechaHasta=" + getValueInputText("etiquetaFechaFinReembolso");
	encodeParam += "&codigoAutorizador=" + getValueInputText("hidCodigoAutorizador");
	location.href = contextPathUrl + "/revisarReembolso.htm?action=exportarExcelBandejaAutorizacionReembolso" + encodeParam;
}

function changeEtiquetaFechaInicioReembolso() {
	if (isBrowserInternetExplorer()) {
		if (trimText(getValueInputText("etiquetaFechaInicioReembolso")) != "" && isValidoFormatDate(getValueInputText("etiquetaFechaInicioReembolso"))) {
			if (isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaInicioReembolso")), getValueInputText("hidFechaMaximaAnioActual"))) {
				setValueInputText("etiquetaFechaInicioReembolso", "");
			}
		}
		else {
			setValueInputText("etiquetaFechaInicioReembolso", "");
		}
		changeDateEtiquetaFechaInicioReembolsoDiv();
	}
}

function changeEtiquetaFechaFinReembolso() {
	if (isBrowserInternetExplorer()) {
		if (trimText(getValueInputText("etiquetaFechaFinReembolso")) != "" && isValidoFormatDate(getValueInputText("etiquetaFechaFinReembolso"))) {
			if (isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaFinReembolso")), getValueInputText("hidFechaMaximaAnioActual"))) {
				setValueInputText("etiquetaFechaFinReembolso", "");
			}
		}
		else {
			setValueInputText("etiquetaFechaFinReembolso", "");
		}
		changeDateEtiquetaFechaFinReembolsoDiv();
	}
}

function changeDateEtiquetaFechaInicioReembolsoDiv() {
	clearPlanillaTableRevisarReembolsoAutorizador();
	validarFechaInicioRevisarReembolsoAutorizador();
}

function changeDateEtiquetaFechaFinReembolsoDiv() {
	clearPlanillaTableRevisarReembolsoAutorizador();
	validarFechaFinalRevisarReembolsoAutorizador();
}

function clickBtnAceptarMensajeConfirmacionRevisarReembolsoAutorizador() {
	hideModalElement("divMensajeConfirmacionRevisarReembolsoAutorizador");
}

function clickBtnAceptarMensajeConfirmacionErrorRevisarReembolsoAutorizador() {
	hideModalElement("divMensajeConfirmacionErrorRevisarReembolsoAutorizador");
}

function clickBtnSiAutorizarReembolsoRevisarReembolsoAutorizador() {
	hideModalElement("divMensajeConfirmacionAutorizarReembolsoRevisarReembolsoAutorizador");
	callAutorizarReembolsoBandejaAutorizacionReembolso(getValueInputText("hidCodPlanViajeAutorizarReembolsoRevisarReembolsoAutorizador"), getValueInputText("hidExpedientePlanViajeAutorizarReembolsoRevisarReembolsoAutorizador"));
}

function clickBtnNoAutorizarReembolsoRevisarReembolsoAutorizador() {
	setValueInputText("hidCodPlanViajeAutorizarReembolsoRevisarReembolsoAutorizador", "");
	setValueInputText("hidExpedientePlanViajeAutorizarReembolsoRevisarReembolsoAutorizador", "");
	hideModalElement("divMensajeConfirmacionAutorizarReembolsoRevisarReembolsoAutorizador");
}

function clickBtnAceptarAutorizacionExitosaRevisarReembolsoAutorizador() {
	$("#btnConsultarReembolso").trigger("click");
	hideModalElement("divMensajeConfirmacionAutorizacionExitosaRevisarReembolsoAutorizador");
}

function validarFechaInicioRevisarReembolsoAutorizador() {
	
	var flagFechaValida = true;
	var errorMessage = "";
	hideElement("divErrorRevisarReembolsoAutorizador");
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("hidFechaInicialRangoFecha")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaInicioReembolso")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRevisarReembolsoAutorizador.fechaInicioInvalida;
	}
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaInicioReembolso")), formatEspDateToEngFormatDate(getValueInputText("hidFechaFinalRangoFecha")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRevisarReembolsoAutorizador.fechaInicioInvalida;
	}
	
	if (!flagFechaValida) {
		setValueInputText("hidFlagFechaInicioValida", "0");
		showMessageErrorRevisarReembolsoAutorizador(errorMessage);
	}
	else {
		if (trimText(getValueInputText("etiquetaFechaInicioReembolso")) != "") {
			setValueInputText("hidFlagFechaInicioValida", "1");
			if (trimText(getValueInputText("etiquetaFechaFinReembolso")) != "") {
				validarFechaFinalRevisarReembolsoAutorizador();
			}
		}
		else {
			setValueInputText("hidFlagFechaInicioValida", "0");
		}
	}
}

function validarFechaFinalRevisarReembolsoAutorizador() {
	
	var flagFechaValida = true;
	var errorMessage = "";
	hideElement("divErrorRevisarReembolsoAutorizador");
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("hidFechaInicialRangoFecha")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaFinReembolso")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRevisarReembolsoAutorizador.fechaFinalInvalida;
	}
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaFinReembolso")), formatEspDateToEngFormatDate(getValueInputText("hidFechaFinalRangoFecha")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRevisarReembolsoAutorizador.fechaFinalInvalida;
	}
	
	if (!flagFechaValida) {
		setValueInputText("hidFlagFechaFinalValida", "0");
		showMessageErrorRevisarReembolsoAutorizador(errorMessage);
	}
	else {
		if (trimText(getValueInputText("etiquetaFechaFinReembolso")) != "") {
			setValueInputText("hidFlagFechaFinalValida", "1");
			if (trimText(getValueInputText("etiquetaFechaInicioReembolso")) != "") {
				validarFechaFinalMayorIgualFechaInicioRevisarReembolsoAutorizador();
			}
		}
		else {
			setValueInputText("hidFlagFechaFinalValida", "0");
		}
	}
}

function validarFechaFinalMayorIgualFechaInicioRevisarReembolsoAutorizador() {
	
	var flagFechaValida = true;
	var errorMessage = "";
	hideElement("divErrorRevisarReembolsoAutorizador");
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaInicioReembolso")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaFinReembolso")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRevisarReembolsoAutorizador.fechaFinalMenorFechaInicial;
	}
	
	if (!flagFechaValida) {
		setValueInputText("hidFlagFechaFinalValida", "0");
		showMessageErrorRevisarReembolsoAutorizador(errorMessage);
	}
	else {
		setValueInputText("hidFlagFechaFinalValida", "1");
	}
}

function clickLinkConsultarReembolso(codPlanViaje) {
	
	var planillaTable = $("#tblPlanilla");
	var rowData = planillaTable.getRowData(codPlanViaje);
	var codPlanilla = rowData.codPlanilla;
	var formNode = $("#formConsultarReembolso");
	if (formNode) {
		var dataObject = {
			"UUOO": getUpperCaseValueInputText("txtUUOO"),
			"nombreDependencia": getUpperCaseValueInputText("txtDescripcionDependencia"),
			"codigoDependencia": getUpperCaseValueInputText("hidCodigoDependencia"),
			"selAnioReembolsotUUOO": getUpperCaseValueInputText("selAnioReembolso"),
			"etiquetaFechaInicioReembolso": getUpperCaseValueInputText("etiquetaFechaInicioReembolso"),
			"etiquetaFechaFinReembolso": getUpperCaseValueInputText("etiquetaFechaFinReembolso"),
			"codigoPlanilla": getUpperCaseValueInputText("txtCodigoPlanilla"),
			"selEstadoReembolso": getUpperCaseValueInputText("selEstadoReembolso"),
			"nroRegistro": getUpperCaseValueInputText("txtNroRegistro"),
			"codigoColaborador": getUpperCaseValueInputText("hidCodigoColaborador"),
			"nombreColaborador": getUpperCaseValueInputText("txtNombreColaborador"),
			"codigoRegistrador": getUpperCaseValueInputText("hidCodigoAutorizador")
		};
		var dataJSON = JSON.stringify(dataObject);
		formNode.find("input[name='action']").val("mostrarConsultarViatico");
		formNode.find("input[name='codPlanilla']").val(codPlanilla);
		formNode.find("input[name='dataJSON']").val(dataJSON);
		formNode.submit();
	}
}

function clickLinkAutorizarReembolso(codPlanViaje) {
	
	var planillaTable = $("#tblPlanilla");
	var rowData = planillaTable.getRowData(codPlanViaje);
	var codPlanilla = rowData.codPlanilla;
	var expedientePlanViaje = rowData.expedientePlanViaje;
	setValueInputText("hidCodPlanViajeAutorizarReembolsoRevisarReembolsoAutorizador", codPlanViaje);
	setValueInputText("hidExpedientePlanViajeAutorizarReembolsoRevisarReembolsoAutorizador", expedientePlanViaje);
	setHtmlElement("divTituloPanelAutorizarReembolsoRevisarReembolsoAutorizador", propertyMessageRevisarReembolsoAutorizador.autorizarReembolsoTitulo1 + codPlanilla + propertyMessageRevisarReembolsoAutorizador.autorizarReembolsoTitulo2);
	showModalElement("divMensajeConfirmacionAutorizarReembolsoRevisarReembolsoAutorizador");
}

function clickLinkObservarReembolso(codPlanViaje) {
	
	var planillaTable = $("#tblPlanilla");
	var rowData = planillaTable.getRowData(codPlanViaje);
	var dataParametrosObservarDocumento = new Object();
	dataParametrosObservarDocumento.codPlanViaje = codPlanViaje;
	dataParametrosObservarDocumento.codPlanilla = rowData.codPlanilla;
	dataParametrosObservarDocumento.montoTotal = rowData.mtoTotalFormateado;
	dataParametrosObservarDocumento.codPerAutoriza = getValueInputText("hidCodigoAutorizador");
	dataParametrosObservarDocumento.codigoSedeAutorizador = getValueInputText("hidCodigoSedeAutorizador");
	dataParametrosObservarDocumento.nombreAutorizador = getValueInputText("hidNumeroRegistroAutorizador") + " - " + getValueInputText("hidNombreAutorizador");
	dataParametrosObservarDocumento.expedientePlanViaje = rowData.expedientePlanViaje;
	dataParametrosObservarDocumento.codigoPaginaCaller = getValueInputText("hidCodigoPaginaCaller");
	initElementsObservarDocumento(dataParametrosObservarDocumento);
	showModalElement("divObservarDocumento");
}

function clickLinkAnularReembolso(codPlanViaje) {
	
	var planillaTable = $("#tblPlanilla");
	var rowData = planillaTable.getRowData(codPlanViaje);
	var dataParametrosAnularDocumento = new Object();
	dataParametrosAnularDocumento.codPlanViaje = codPlanViaje;
	dataParametrosAnularDocumento.codPlanilla = rowData.codPlanilla;
	dataParametrosAnularDocumento.nomColaborador = rowData.numeroRegistroAlterno + " - " + rowData.nomColaborador;
	dataParametrosAnularDocumento.descripcionDependencia = rowData.nomUuOoCom;
	dataParametrosAnularDocumento.montoTotal = rowData.mtoTotalFormateado;
	dataParametrosAnularDocumento.codigoColaborador = getValueInputText("hidCodigoAutorizador");
	dataParametrosAnularDocumento.codigoSedeColaborador = getValueInputText("hidCodigoSedeAutorizador");
	dataParametrosAnularDocumento.expedientePlanViaje = rowData.expedientePlanViaje;
	dataParametrosAnularDocumento.codigoPaginaCaller = getValueInputText("hidCodigoPaginaCaller");
	initElementsAnularDocumento(dataParametrosAnularDocumento);
	showModalElement("divAnularDocumento");
}

function clickLinkConsultarDetalleReembolsoAutorizador(codPlanViaje) {
	initElementsConsultarReembolsoDetalle("divPlanillaTable", codPlanViaje);
	showModalElement("divConsultarReembolsoDetalle");
	triggerResizeEvent();
	triggerResizeEventSlow();
}

function clickLinkConsultarSeguimientoReembolsoAutorizador(codPlanViaje) {
	
	var planillaTable = $("#tblPlanilla");
	var rowData = planillaTable.getRowData(codPlanViaje);
	var dataParametrosConsultarSeguimiento = new Object();
	dataParametrosConsultarSeguimiento.codPlanViaje = codPlanViaje;
	dataParametrosConsultarSeguimiento.numeroExpediente = rowData.expedientePlanViaje;
	dataParametrosConsultarSeguimiento.idElementCallModal = "divPlanillaTable";
	dataParametrosConsultarSeguimiento.codigoPaginaCaller = "02";
	initElementsConsultarSeguimiento(dataParametrosConsultarSeguimiento);
	showModalElement("divConsultarSeguimiento");
	triggerResizeEvent();
	triggerResizeEventSlow();
}

function clickLinkConsultarAdjuntosReembolsoAutorizador(codPlanViaje) {
	
	var planillaTable = $("#tblPlanilla");
	var rowData = planillaTable.getRowData(codPlanViaje);
	var numeroRegistroArchivo = rowData.numeroRegistroArchivo;
	if (trimText(numeroRegistroArchivo) != "") {
		var dataParametrosArchivo = new Object();
		dataParametrosArchivo.planViajeId = codPlanViaje;
	    dataParametrosArchivo.codigoBoleto = "";
	    dataParametrosArchivo.estadoOrigen = "R";
	    dataParametrosArchivo.estadoLLamada = "C";
	    dataParametrosArchivo.numeroRegistroColaborador = rowData.numeroRegistroAlterno;
	    dataParametrosArchivo.paginaOrigen = "PRINCIPAL";
	    initElementsConsultarRegistrarEliminarArchivo(dataParametrosArchivo);
	    showModalElement("divAdjuntarDocumento");
	    triggerResizeEvent();
	}
	else {
		var codPlanilla = rowData.codPlanilla;
		showMensajeConfirmacionRevisarReembolsoAutorizador(errorMessageRevisarReembolsoAutorizador.sinArchivoAdjunto + " " + codPlanilla);
	}
}

function modificarRangoFechaRevisarReembolsoAutorizador(anioSeleccionado) {
	
	setValueInputText("hidFechaInicialRangoFecha", "01/01/" + anioSeleccionado);
	setValueInputText("hidFechaFinalRangoFecha", "31/12/" + anioSeleccionado);
	setValueInputText("etiquetaFechaInicioReembolso", getValueInputText("hidFechaInicialRangoFecha"));
	setValueInputText("etiquetaFechaFinReembolso", getValueInputText("hidFechaFinalRangoFecha"));
	setValueInputText("hidFlagFechaInicioValida", "1");
	setValueInputText("hidFlagFechaFinalValida", "1");
}

function callBuscarPlanillasBandejaAutorizacionReembolso() {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/revisarReembolso.htm?action=buscarPlanillasBandejaAutorizacionReembolso",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codigoDependencia": getUpperCaseValueInputText("hidCodigoDependencia"),
				"codPlanilla": getUpperCaseValueInputText("txtCodigoPlanilla"),
				"codTrabajador": getUpperCaseValueInputText("hidCodigoColaborador"),
				"codEstadoSolic": getValueInputText("selEstadoReembolso"),
				"fechaDesde": getValueInputText("etiquetaFechaInicioReembolso"),
				"fechaHasta": getValueInputText("etiquetaFechaFinReembolso"),
				"codigoAutorizador": getValueInputText("hidCodigoAutorizador")
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showElement("divLoadingRevisarReembolsoAutorizador");
			},
			complete: function() {
				enabledElement("btnConsultarReembolso");
				hideElement("divLoadingRevisarReembolsoAutorizador");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var codigoConsulta = result.codigoConsulta;
				var errorMessage = result.errorMessage;
				if (codigoConsulta != null && codigoConsulta == "00") {
					var planillaList = result.planViajeList;
					showPlanillasRevisarReembolsoAutorizador(planillaList);
				}
				else if (codigoConsulta == "02") {
					showMessageErrorRevisarReembolsoAutorizador(errorMessage);
				}
				else {
					showMensajeConfirmacionErrorRevisarReembolsoAutorizador(errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callBuscarPlanillasBandejaAutorizacionSolicitud");
			}
		});
	}, 500);
}

function callAutorizarReembolsoBandejaAutorizacionReembolso(codPlanViaje, expedientePlanViaje) {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/revisarReembolso.htm?action=autorizarReembolsoBandejaAutorizacionReembolso",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codPlanViaje": codPlanViaje,
				"codPerAutoriza": getValueInputText("hidCodigoAutorizador"),
				"codigoSedeAutorizador": getValueInputText("hidCodigoSedeAutorizador"),
				"codigoNivelAutorizador": getValueInputText("hidCodigoNivelAutorizador"),
				"expedientePlanViaje": expedientePlanViaje
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showModalElement("divMensajeConfirmacionLoadingRevisarReembolsoAutorizador");
			},
			complete: function() {
				hideModalElement("divMensajeConfirmacionLoadingRevisarReembolsoAutorizador");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var codigoOperacion = result.codigoOperacion;
				var errorMessage = result.errorMessage;
				var successMessage = result.successMessage;
				if (codigoOperacion != null && codigoOperacion == "00") {
					showModalElement("divMensajeConfirmacionAutorizacionExitosaRevisarReembolsoAutorizador");
				}
				else {
					showMensajeConfirmacionErrorRevisarReembolsoAutorizador(errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callAutorizarReembolsoBandejaAutorizacionReembolso");
			}
		});
	}, 500);
}

function showMessageErrorRevisarReembolsoAutorizador(errorMessage) {
	setHtmlElement("etiquetaErrorRevisarReembolsoAutorizador", errorMessage);
	showElement("divErrorRevisarReembolsoAutorizador");
}

function showMensajeConfirmacionRevisarReembolsoAutorizador(messageTitulo) {
	hideElement("divBodyPanelMensajeConfirmacionRevisarReembolsoAutorizador");
	setHtmlElement("divTituloPanelMensajeConfirmacionRevisarReembolsoAutorizador", messageTitulo);
	showModalElement("divMensajeConfirmacionRevisarReembolsoAutorizador");
}

function showMensajeConfirmacionErrorRevisarReembolsoAutorizador(messageTitulo) {
	hideElement("divBodyPanelMensajeConfirmacionErrorRevisarReembolsoAutorizador");
	setHtmlElement("divTituloPanelMensajeConfirmacionErrorRevisarReembolsoAutorizador", messageTitulo);
	showModalElement("divMensajeConfirmacionErrorRevisarReembolsoAutorizador");
}

function showPlanillasRevisarReembolsoAutorizador(planillaArray) {
	
	if (planillaArray != null && planillaArray.length > 0) {
		var planillaTable = $("#tblPlanilla");
		planillaTable.clearGridData();
		for (var i = 0; i < planillaArray.length; i++) {
			var planilla = planillaArray[i];
			var datarow = {
				codPlanViaje: planilla.codPlanViaje,
				codPlanilla: planilla.codPlanilla,
				fechaRegistro: planilla.fechaRegistroFormateada,
				numeroRegistroAlterno: planilla.numeroRegistroAlterno,
				codTrabajador: planilla.codTrabajador,
				nomColaborador: planilla.nomColaborador,
				numDias: planilla.numDias,
				mtoTotal: planilla.mtoTotal,
				mtoTotalFormateado: planilla.mtoTotalFormateado,
				codEstadoSolic: planilla.codEstadoSolic,
				nomEstSolic: planilla.nomEstSolic,
				codPerAutoriza: planilla.codPerAutoriza,
				nomAutorizador: planilla.nomAutorizador,
				nomUuOoCom: planilla.nomUuOoCom,
				expedientePlanViaje: planilla.expedientePlanViaje,
				expedienteRendicion: planilla.expedienteRendicion,
				numeroRegistroArchivo: planilla.numeroRegistroArchivo,
				autorizarReembolso: "AUTORIZAR",
				observarReembolso: "OBSERVAR",
				anularReembolso: "ANULAR",
				detalleReembolso: "DETALLE",
				seguimientoReembolso: "SEGUIMIENTO",
				verAdjuntosPlanilla: "VER"
			};
			planillaTable.jqGrid("addRowData", datarow.codPlanViaje, datarow);
		}
		planillaTable.trigger("reloadGrid");
		enabledElement("btnExportarExcelReembolso");
	}
	else {
		setHtmlElement("divPlanillaPagerTable_left", errorMessageRevisarReembolsoAutorizador.sinRegistrosBusqueda);
	}
}

function clearPlanillaTableRevisarReembolsoAutorizador() {
	var planillaTable = $("#tblPlanilla");
	planillaTable.clearGridData();
	disabledElement("btnExportarExcelReembolso");
	setHtmlElement("divPlanillaPagerTable_left", "");
}

/*Inicio Codigo - Reutilizacion buscarUUOO*/
var dataParametrosBuscarUUOO = new Object();
dataParametrosBuscarUUOO.idCodigoRegistrador = "hidCodigoAutorizador";
dataParametrosBuscarUUOO.idCodigoTipoUUOOViatico = getValueInputText("hidFlagBuscarUUOO");
dataParametrosBuscarUUOO.idDivScreenBlock = "divScreenBlock";

var buscarUUOOBeforeMethod = function() {
};

var buscarUUOOAfterMethod = function(rowData) {
	
	setValueInputText("txtNroRegistro", "");
	setValueInputText("hidTxtNroRegistro", "");
	setValueInputText("txtNombreColaborador", "");
	setValueInputText("hidCodigoColaborador", "");
	setValueInputText("hidCodigoEstadoColaborador", "");
	setValueInputText("txtUUOO", rowData["uuoo"]);
	setValueInputText("hidTxtUUOO", rowData["uuoo"]);
    setValueInputText("txtDescripcionDependencia", rowData["descripcionUUOO"]);
    setValueInputText("hidCodigoDependencia", rowData["codigoDependencia"]);
    hideElement("divErrorRevisarReembolsoAutorizador");
    clearPlanillaTableRevisarReembolsoAutorizador();
};

var buscarUUOOService = new BuscarUUOOService(dataParametrosBuscarUUOO, buscarUUOOBeforeMethod, buscarUUOOAfterMethod);
/*Fin Codigo - Reutilizacion buscarUUOO*/

/*Inicio Codigo - Reutilizacion buscarUUOOInput*/
function buscarUUOOInputBeforeMethod() {
	
	setValueInputText("txtNroRegistro", "");
	setValueInputText("hidTxtNroRegistro", "");
	setValueInputText("hidCodigoColaborador", "");
	setValueInputText("txtNombreColaborador", "");
	setValueInputText("hidCodigoEstadoColaborador", "");
	setValueInputText("hidTxtUUOO", "");
	setValueInputText("txtDescripcionDependencia", "");
	setValueInputText("hidCodigoDependencia", "");
	clearPlanillaTableRevisarReembolsoAutorizador();
}

function buscarUUOOInputAfterMethod(uuooList) {
	
	if (uuooList != null && uuooList.length > 0) {
		for (var i = 0; i < uuooList.length; i++) {
			var uuoo = uuooList[i];
			var datarow = {
				codigoDependencia: uuoo.cod_dep,
				uuoo: uuoo.uuoo,
				uuooDetalle: uuoo.nom_largo
			};
			setValueInputText("txtUUOO", datarow.uuoo);
			setValueInputText("hidTxtUUOO", datarow.uuoo);
			setValueInputText("hidCodigoDependencia", datarow.codigoDependencia);
			setValueInputText("txtDescripcionDependencia", datarow.uuooDetalle);
			break;
		}
	}
	else {         
		setHtmlElement("etiquetaErrorRevisarReembolsoAutorizador", errorMessageBuscarUUOOInput.sinRegistrosBusqueda);
		showElement("divErrorRevisarReembolsoAutorizador");
	}
}

var buscarUUOOInputService = new BuscarUUOOInputService();

function initElementsBuscarUUOOInputService(errorMessageBuscarUUOOInput) {
	
	var dataParametros = new Object();
	dataParametros.idNumeroUUOO = "txtUUOO";
	dataParametros.idCodigoRegistrador = "hidCodigoAutorizador";
	dataParametros.idCodigoTipoUUOOViatico = getValueInputText("hidFlagBuscarUUOO");
	dataParametros.idDivLoading = "divLoadingBuscarInput";
	dataParametros.idDivError = "divErrorRevisarReembolsoAutorizador";
	dataParametros.idEtiquetaError = "etiquetaErrorRevisarReembolsoAutorizador";
	dataParametros.idDivScreenBlock = "divScreenBlock";
	dataParametros.errorMessage = errorMessageBuscarUUOOInput;
	buscarUUOOInputService = new BuscarUUOOInputService(dataParametros, buscarUUOOInputBeforeMethod, buscarUUOOInputAfterMethod);
}
/*Fin Codigo - Reutilizacion buscarUUOOInput*/

/*Inicio Codigo - Reutilizacion buscarColaborador*/
var dataParametrosBuscarColaborador = new Object();
dataParametrosBuscarColaborador.idCodigoRegistrador = "hidCodigoAutorizador";
dataParametrosBuscarColaborador.idNumeroRegistroRegistrador = "hidNumeroRegistroAutorizador";
dataParametrosBuscarColaborador.idCodigoTipoUsuarioViatico = getValueInputText("hidFlagBuscarColaborador");
dataParametrosBuscarColaborador.idDivScreenBlock = "divScreenBlock";

var buscarColaboradorBeforeMethod = function() {
};

var buscarColaboradorAfterMethod = function(rowData) {
	
	setValueInputText("txtNroRegistro", rowData["numeroRegistro"]);
	setValueInputText("hidTxtNroRegistro", rowData["numeroRegistro"]);
	setValueInputText("hidCodigoColaborador", rowData["codigoEmpleado"]);
	setValueInputText("txtNombreColaborador", rowData["nombreCompleto"]);
	setValueInputText("hidCodigoEstadoColaborador", rowData["codigoEstado"]);
	setValueInputText("txtUUOO", rowData["uuoo"]);
	setValueInputText("hidTxtUUOO", rowData["uuoo"]);
	setValueInputText("txtDescripcionDependencia", rowData["uuooDetalle"]);
	setValueInputText("hidCodigoDependencia", rowData["codigoDependencia"]);
	hideElement("divErrorRevisarReembolsoAutorizador");
	clearPlanillaTableRevisarReembolsoAutorizador();
};

var buscarColaboradorService = new BuscarColaboradorService(dataParametrosBuscarColaborador, buscarColaboradorBeforeMethod, buscarColaboradorAfterMethod);
/*Fin Codigo - Reutilizacion buscarColaborador*/

/*Inicio Codigo - Reutilizacion buscarColaboradorInput*/
var buscarColaboradorInputBeforeMethod = function() {
	
	setValueInputText("hidTxtNroRegistro", "");
	setValueInputText("hidCodigoColaborador", "");
	setValueInputText("txtNombreColaborador", "");
	setValueInputText("hidCodigoEstadoColaborador", "");
	/*
	setValueInputText("txtUUOO", "");
	setValueInputText("txtDescripcionDependencia", "");
	setValueInputText("hidCodigoDependencia", "");
	*/
	clearPlanillaTableRevisarReembolsoAutorizador();
};

var buscarColaboradorInputAfterMethod = function(colaboradorList) {
	
	if (colaboradorList != null && colaboradorList.length > 0) {
		for (var i = 0; i < colaboradorList.length; i++) {
			var colaborador = colaboradorList[i];
			var datarow = {
				numeroRegistro: colaborador.numero_registro,
				nombreCompleto: colaborador.nombre_completo,
				uuoo: colaborador.uuoo,
				codigoDependencia: colaborador.codigoDependencia,
				uuooDetalle: colaborador.dependencia,
				codigoEmpleado: colaborador.codigoEmpleado,
				codigoEstado: colaborador.codigoEstado,
				estadoDetalle: colaborador.estado
			};
			setValueInputText("hidTxtNroRegistro", datarow.numeroRegistro);
			setValueInputText("hidCodigoColaborador", datarow.codigoEmpleado);
			setValueInputText("txtNombreColaborador", datarow.nombreCompleto);
			setValueInputText("hidCodigoEstadoColaborador", datarow.codigoEstado);
			setValueInputText("txtUUOO", datarow.uuoo);
			setValueInputText("hidTxtUUOO", datarow.uuoo);
			setValueInputText("txtDescripcionDependencia", datarow.uuooDetalle);
			setValueInputText("hidCodigoDependencia", datarow.codigoDependencia);
			break;
		}
	}
	else {
		setHtmlElement("etiquetaErrorRevisarReembolsoAutorizador", errorMessageBuscarColaboradorInput.sinRegistrosBusqueda);
		showElement("divErrorRevisarReembolsoAutorizador");
	}
};

var buscarColaboradorInputService = new BuscarColaboradorInputService();

function initElementsBuscarColaboradorInputService(errorMessageBuscarColaboradorInput) {
	
	var dataParametros = new Object();
	dataParametros.idNumeroRegistroColaborador = "txtNroRegistro";
	dataParametros.idCodigoRegistrador = "hidCodigoAutorizador";
	dataParametros.idNumeroRegistroRegistrador = "hidNumeroRegistroAutorizador";
	dataParametros.idCodigoTipoUsuarioViatico = getValueInputText("hidFlagBuscarColaborador");
	dataParametros.estadoLlamada = "B";
	dataParametros.idDivLoading = "divLoadingBuscarInput";
	dataParametros.idDivError = "divErrorRevisarReembolsoAutorizador";
	dataParametros.idEtiquetaError = "etiquetaErrorRevisarReembolsoAutorizador";
	dataParametros.idDivScreenBlock = "divScreenBlock";
	dataParametros.errorMessage = errorMessageBuscarColaboradorInput;
	buscarColaboradorInputService = new BuscarColaboradorInputService(dataParametros, buscarColaboradorInputBeforeMethod, buscarColaboradorInputAfterMethod);
}
/*Fin Codigo - Reutilizacion buscarColaboradorInput*/

/*Inicio Codigo - Reutilizacion adjuntarDocumento*/
var adjuntarDocumentoBeforeMethod = function() {
};

var adjuntarDocumentoAfterMethod = function(data) {
};

var adjuntarDocumentoService = new AdjuntarDocumentoService(adjuntarDocumentoBeforeMethod, adjuntarDocumentoAfterMethod);
/*Fin Codigo - Reutilizacion adjuntarDocumento*/

$(window).on("resize", function() {
	resizeTable("tblPlanilla");
	//Inicializando las tablas de los modales
	resizeTable("tblUUOO");
	resizeTable("tblColaborador");
	resizeTable("tblDetalleSolicitud");
	resizeTable("tblDetalleGasto");
	resizeTable("tblSeguimiento");
	resizeTable("tblArchivo");
});