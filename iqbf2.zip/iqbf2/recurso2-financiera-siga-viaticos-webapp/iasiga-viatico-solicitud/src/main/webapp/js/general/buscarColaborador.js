function initElementsBuscarColaborador(idElementCallModal) {
	setInitElementsBuscarColaborador();
	setInitColaboradorTable(idElementCallModal);
}

function setInitElementsBuscarColaborador() {
	setValueInputText("selTipoBusquedaBuscarColaborador", "00");
	setValueInputText("txtDescripcionBusquedaBuscarColaborador", "");
	hideElement("divErrorBuscarColaborador");
	disabledElement("txtDescripcionBusquedaBuscarColaborador");
	disabledElement("btnBuscarBuscarColaborador");
	disabledElement("btnAceptarColaborador");
	addEventElement("btnBuscarBuscarColaborador", "click", btnBuscarBuscarColaborador);
	addEventElement("btnBuscarTodosColaborador", "click", clickBtnBuscarTodosColaborador);
	addEventElement("btnAceptarColaborador", "click", clickBtnAceptarColaborador);
	addEventElement("btnCancelarColaborador", "click", clickBtnCancelarColaborador);
	addEventElement("selTipoBusquedaBuscarColaborador", "change", changeSelTipoBusquedaBuscarColaborador);
	if (buscarColaboradorService.idCodigoTipoUsuarioViatico == "01" || buscarColaboradorService.idCodigoTipoUsuarioViatico == "03") {
		hideElement("btnBuscarTodosColaborador");
	}
}

function removeEventElementsBuscarColaborador() {
	removeAllEventsElement("btnBuscarBuscarColaborador");
	removeAllEventsElement("btnBuscarTodosColaborador");
	removeAllEventsElement("btnAceptarColaborador");
	removeAllEventsElement("btnCancelarColaborador");
	removeAllEventsElement("selTipoBusquedaBuscarColaborador");
}

function removeColaboradorTableBuscarColaborador() {
	var htmlElement = "<table id=\"tblColaborador\"></table>";
	htmlElement += "<div id=\"divColaboradorPagerTable\" class=\"jqGridMovilidadPagerClass\"></div>";
	setHtmlElement("divColaboradorTable", htmlElement);
}

function setInitColaboradorTable(idElementCallModal) {
	var colaboradorTable = $("#tblColaborador");
	if (colaboradorTable) {
		//Para el DivWitdh se utilizo un componente que llama al modal
		var colaboradorTableDiv = $("#" + idElementCallModal);
		var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.movilidadModalContainer", ".movilidadModalContainerAuxiliar", "width"))/100);
		var widthTable = factorRedimensionamiento*colaboradorTableDiv.width();
		colaboradorTable.jqGrid({
			width: widthTable,
			height: 200,
			datatype: "local",
			rowNum: 10,
			rowList: [10, 20],
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Secuencial",
				"Nro de Registro",
				"Apellidos y Nombres",
				"Codigo UUOO",
				"Codigo Dependencia",
				"Detalle UUOO",
				"UUOO",
				"Codigo Empleado",
				"Codigo Estado",
				"Estado",
				"codigoEncargado",
				"codigoCategoriaViatico",
				"codigoNivelNvl",
				"codigoViaticoNvi",
				"codigoSede"
			],
			colModel: [
				{name: "secuencialNumeroRegistro", index: "secuencialNumeroRegistro", width: (1*widthTable/20), hidden: true},
				{name: "numeroRegistro", index: "numeroRegistro", width: (3*widthTable/20)},
				{name: "nombreCompleto", index: "nombreCompleto", width: (7*widthTable/20)},
				{name: "uuoo", index: "uuoo", width: (1*widthTable/20), hidden: true},
				{name: "codigoDependencia", index: "codigoDependencia", width: (1*widthTable/20), hidden: true},
				{name: "uuooDetalle", index: "uuooDetalle", width: (1*widthTable/20), hidden: true},
				{name: "uuooDetalleCompleto", index: "uuooDetalleCompleto", width: (10*widthTable/20)},
				{name: "codigoEmpleado", index: "codigoEmpleado", width: (1*widthTable/20), hidden: true},
				{name: "codigoEstado", index: "codigoEstado", width: (1*widthTable/20), hidden: true},
				{name: "estadoDetalle", index: "estadoDetalle", width: (3*widthTable/20), hidden: true},
				{name: "codigoEncargado", index: "codigoEncargado", width: (3*widthTable/20), hidden: true},
				{name: "codigoCategoriaViatico", index: "codigoCategoriaViatico", width: (3*widthTable/20), hidden: true},
				{name: "codigoNivelNvl", index: "codigoNivelNvl", width: (3*widthTable/20), hidden: true},
				{name: "codigoViaticoNvi", index: "codigoViaticoNvi", width: (3*widthTable/20), hidden: true},
				{name: "codigoSede", index: "codigoSede", width: (3*widthTable/20), hidden: true}
				
			],
			rowattr: function(dataTable) {
				if (dataTable.codigoEstado == "0") {
					return {"class": "colorFontRedTableClass"};
				}
			},
			pager : "#divColaboradorPagerTable",
			loadui: "disable"
		});
	}
	colaboradorTable.clearGridData();
}

function btnBuscarBuscarColaborador() {
	
	setHtmlElement("divColaboradorPagerTable_left", "");
	hideElement("divErrorBuscarColaborador");
	callObtenerColaborador("0");
}

function clickBtnBuscarTodosColaborador() {
	
	setValueInputText("selTipoBusquedaBuscarColaborador", "00");
	setValueInputText("txtDescripcionBusquedaBuscarColaborador", "");
	setHtmlElement("divColaboradorPagerTable_left", "");
	hideElement("divErrorBuscarColaborador");
	disabledElement("txtDescripcionBusquedaBuscarColaborador");
	disabledElement("btnBuscarBuscarColaborador");
	disabledElement("btnBuscarTodosColaborador");
	callObtenerColaborador("1");
}

function clickBtnAceptarColaborador() {
	
	var colaboradorTable = $("#tblColaborador");
	var rowId = colaboradorTable.jqGrid("getGridParam", "selrow");
	if (rowId == null) {
		setHtmlElement("divColaboradorPagerTable_left", errorMessageBuscarColaborador.seleccionarRegistro);
	}
	else {
		var rowData = colaboradorTable.getRowData(rowId);
		if (typeof buscarColaboradorService.buscarColaboradorBefore != "undefined") {
			buscarColaboradorService.buscarColaboradorBefore();
		}
		if (typeof buscarColaboradorService.buscarColaboradorAfter != "undefined") {
			buscarColaboradorService.buscarColaboradorAfter(rowData);
		}
		removeEventElementsBuscarColaborador();
		removeColaboradorTableBuscarColaborador();
		$("#divBuscarColaborador").modal("hide");
	}
}

function clickBtnCancelarColaborador() {
	removeEventElementsBuscarColaborador();
	removeColaboradorTableBuscarColaborador();
	$("#divBuscarColaborador").modal("hide");
}

function changeSelTipoBusquedaBuscarColaborador() {
	
	var tipoBusquedaSel = $("#selTipoBusquedaBuscarColaborador");
	var colaboradorTable = $("#tblColaborador");
	var valueSelect = tipoBusquedaSel.val();
	colaboradorTable.clearGridData();
	setValueInputText("txtDescripcionBusquedaBuscarColaborador", "");
	setHtmlElement("divColaboradorPagerTable_left", "");
	hideElement("divErrorBuscarColaborador");
	disabledElement("btnAceptarColaborador");
	
	if (valueSelect == "00") {
		disabledElement("txtDescripcionBusquedaBuscarColaborador");
		disabledElement("btnBuscarBuscarColaborador");
	}
	else {
		enabledElement("txtDescripcionBusquedaBuscarColaborador");
		enabledElement("btnBuscarBuscarColaborador");
	}
	tipoValidarInputText(valueSelect);
}

function tipoValidarInputText(valueSelect){
	var valueSelect = $.trim(valueSelect);
		if(valueSelect == "02"){
			consoleLog("02");
			$("#txtDescripcionBusquedaBuscarColaborador").removeAttr("onkeypress");
			$("#txtDescripcionBusquedaBuscarColaborador").attr("onkeypress", "return validarCharacterLetterWithEspacio(event);");			
			$("#txtDescripcionBusquedaBuscarColaborador").attr("onpaste", "validarCharacterInput('txtDescripcionBusquedaBuscarColaborador');");
			
		}else{
			$("#txtDescripcionBusquedaBuscarColaborador").removeAttr("onkeypress");
			$("#txtDescripcionBusquedaBuscarColaborador").removeAttr("onpaste");
			$("#txtDescripcionBusquedaBuscarColaborador").attr("onkeypress", "return validarCharacterAlfanumericWithEspacio(event);");
		}
}

function callObtenerColaborador(indicadorBuscarTodos) {
	
	var tipoBusquedaSel = $("#selTipoBusquedaBuscarColaborador");
	var descripcionBusquedaTxt = getUpperCaseValueInputText("txtDescripcionBusquedaBuscarColaborador");
	
	if (typeof buscarColaboradorService != "undefined") {
		hideElement("divErrorBuscarColaborador");
		if (tipoBusquedaSel.val() == "00" && indicadorBuscarTodos == "0") {
			showMessageErrorBuscarColaborador(errorMessageBuscarColaborador.seleccionarTipoBusqueda);
		}
		else if ((descripcionBusquedaTxt == "" || trimText(descripcionBusquedaTxt) == "") && indicadorBuscarTodos == "0") {
			showMessageErrorBuscarColaborador(errorMessageBuscarColaborador.completarDescripcion);
		}
		else if ((descripcionBusquedaTxt.length < 2) && indicadorBuscarTodos == "0") {
			showMessageErrorBuscarColaborador(errorMessageBuscarColaborador.cantidadMinimaDescripcion);
		}
		else {
			var colaboradorTable = $("#tblColaborador");
			colaboradorTable.clearGridData();
			setHtmlElement("divColaboradorPagerTable_left", "");
			disabledElement("btnAceptarColaborador");
			$.ajax({
				url: contextPathUrl + "/colaboradores.htm?action=buscarColaboradores",
				type: "post",
				dataType: "json",
				cache: false,
				data: {
					"tipoBuscaColaborador": tipoBusquedaSel.val(),
					"parmBuscaColaborador": descripcionBusquedaTxt,
					"codigoRegistrador": getUpperCaseValueInputText(buscarColaboradorService.idCodigoRegistrador),
					"numeroRegistroRegistrador": getUpperCaseValueInputText(buscarColaboradorService.idNumeroRegistroRegistrador),
					"parmTodos": indicadorBuscarTodos,
					"codigoTipoUsuarioViatico": buscarColaboradorService.idCodigoTipoUsuarioViatico
				},
				beforeSend: function() {
					if (typeof buscarColaboradorService.idDivScreenBlock != "undefined") {
						showModalElement(buscarColaboradorService.idDivScreenBlock);
					}
					showElement("divLoadingBuscarColaborador");
				},
				complete: function() {
					hideElement("divLoadingBuscarColaborador");
					enabledElement("btnBuscarTodosColaborador");
					if (typeof buscarColaboradorService.idDivScreenBlock != "undefined") {
						hideModalElement(buscarColaboradorService.idDivScreenBlock);
					}
				},
				success: function(result) {
					var colaboradorList = result.listColaboradores;
					if (colaboradorList != null && colaboradorList.length > 0) {
						consoleLog("colaboradorList.length: " + colaboradorList.length);
						for (var i = 0; i < colaboradorList.length; i++) {
							var colaborador = colaboradorList[i];
							
							if(colaborador.codigoEstado == "1"){
								var datarow = {
									secuencialNumeroRegistro: i + "_" + colaborador.numero_registro,
									numeroRegistro: colaborador.numero_registro,
									nombreCompleto: colaborador.nombre_completo,
									uuoo: colaborador.uuoo,
									codigoDependencia: colaborador.codigoDependencia,
									uuooDetalle: colaborador.dependencia,
									uuooDetalleCompleto: colaborador.uuoo + " - " + colaborador.dependencia,
									codigoEmpleado: colaborador.codigoEmpleado,
									codigoEstado: colaborador.codigoEstado,
									estadoDetalle: colaborador.estado,
									codigoEncargado: colaborador.codigoEncargado,
									codigoCategoriaViatico: colaborador.codigoCategoriaViatico,
									codigoNivelNvl: colaborador.codigoNivelNvl,
									codigoViaticoNvi :  colaborador.codigoViaticoNvi,
									codigoSede : colaborador.codigoSede								
								};								
								colaboradorTable.jqGrid("addRowData", datarow.secuencialNumeroRegistro, datarow);
							}
						}
						colaboradorTable.trigger("reloadGrid");
						enabledElement("btnAceptarColaborador");
					}
					else {
						setHtmlElement("divColaboradorPagerTable_left", errorMessageBuscarColaborador.sinRegistrosBusqueda);
					}
				},
				error: function() {
					setHtmlElement("divColaboradorPagerTable_left", "Error callObtenerColaborador");
				}
			});
		}
	}
}

function showMessageErrorBuscarColaborador(errorMessage) {
	setHtmlElement("etiquetaErrorBuscarColaborador", errorMessage);
	showElement("divErrorBuscarColaborador");
}