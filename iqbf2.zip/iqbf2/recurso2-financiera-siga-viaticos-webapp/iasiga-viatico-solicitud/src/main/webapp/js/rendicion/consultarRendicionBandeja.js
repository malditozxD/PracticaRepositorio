function initElementsConsultarRendicionBandeja() {
	removeDuplicateComponents();
	setInitElementsConsultarRendicionBandeja();
	setInitPlanillaTable();
}

function setInitElementsConsultarRendicionBandeja() {
	
	disabledElement("btnExportarExcelRendicion");
	setValueInputText("txtCodigoPlanilla", "");
	setValueInputText("selEstadoRendicion", "00");
	setValueInputText("selAnioRendicion", getValueInputText("hidAnioActual"));
	setValueInputText("selCanalAtencionRendicion", "00");
	setValueInputText("hidFechaMaximaAnioActual", getValueInputText("hidAnioActual") + "/12/31");
	modificarRangoFechaRendicionBandeja(getValueInputText("hidAnioActual"));
	
	addEventElement("btnBuscarUUOORendicion", "click", clickBtnBuscarUUOORendicion);
	addEventElement("btnBuscarColaboradorRendicion", "click", clickBtnBuscarColaboradorRendicion);
	addEventElement("selEstadoRendicion", "change", changeSelEstadoRendicion);
	addEventElement("selAnioRendicion", "change", changeSelAnioRendicion);
	addEventElement("selCanalAtencionRendicion", "change", changeSelCanalAtencionRendicion);
	addEventElement("btnConsultarRendicion", "click", clickBtnConsultarRendicion);
	addEventElement("btnExportarExcelRendicion", "click", clickBtnExportarExcelRendicion);
	addEventElement("etiquetaFechaInicioRendicion", "change", changeEtiquetaFechaInicioRendicion);
	addEventElement("etiquetaFechaFinRendicion", "change", changeEtiquetaFechaFinRendicion);
	initDateTimePickerWithMaxDate("etiquetaFechaInicioRendicionDiv", "dp.change", "changeDate", changeDateEtiquetaFechaInicioRendicionDiv, getValueInputText("hidFechaMaximaAnioActual"));
	initDateTimePickerWithMaxDate("etiquetaFechaFinRendicionDiv", "dp.change", "changeDate", changeDateEtiquetaFechaFinRendicionDiv, getValueInputText("hidFechaMaximaAnioActual"));
	
	addEventElement("btnAceptarMensajeConfirmacionConsultarRendicionBandeja", "click", clickBtnAceptarMensajeConfirmacionConsultarRendicionBandeja);
	addEventElement("btnAceptarMensajeConfirmacionErrorConsultarRendicionBandeja", "click", clickBtnAceptarMensajeConfirmacionErrorConsultarRendicionBandeja);
}

function setInitPlanillaTable() {
	
	var planillaTable = $("#tblPlanilla");
	var heightJqGrid = 200;
	setStyleElement("divPlanillaTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 2, true));
	if (planillaTable) {
		var planillaTableDiv = $("#divPlanillaTable");
		var widthTable = planillaTableDiv.width();
		planillaTable.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			datatype: "local",
			rowNum: 10,
			rowList: [10, 20],
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Código Plan Viaje",
				"Nro. Planilla",
				"Nro. Planilla",
				"Fec. Registro Solicitud",
				"Fec. Registro de la Rendición",
				"Número Registro",
				"Nombre Colaborador",
				"Código Tipo Destino",
				"Tipo de Viáticos",
				"Monto Total",
				"Importe Total Otorgado",
				"Fecha para Rendir Cuenta",
				"Fecha Reprogramada", 
				"Días Vcto. Plazo",
				"Código Estado Rendición",
				"Estado Rendición",
				"Observación",
				"Expediente Plan Viaje",
				"Expediente Rendicion",
				"Numero Registro Archivo",
				"",
				"Acción",
				"",
				"",
				""
			],
			colModel: [
				{name: "codPlanViaje", index: "codPlanViaje", width: (1*widthTable/20), hidden: true},
				{name: "codPlanilla", index: "codPlanilla", width: (1*widthTable/20), align: "center", hidden: true},
				{name: "codPlanillaLink", index: "codPlanillaLink", width: (2*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "";
						var codPlanViaje = rowData.codPlanViaje;
						var codPlanilla = rowData.codPlanilla;
						var encodeParam = "codPlanViaje=" + codPlanViaje;
						encodeParam += "&codigoPaginaCaller=" + getValueInputText("hidCodigoPaginaCaller");
					    htmlElement = sendDataMethodPost(codPlanViaje + "_consultarRendicion", "rendicion", "mostrarConsultarRendicion", encodeParam, codPlanilla);
						return htmlElement;
					}
				},
				{name: "fechaRegistro", index: "fechaRegistro", width: (1*widthTable/20), hidden: true},
				{name: "fechaRegistroRendicion", index: "fechaRegistroRendicion", width: (2*widthTable/20), align: "center"},
				{name: "numeroRegistroAlterno", index: "numeroRegistroAlterno", width: (1*widthTable/20), hidden: true},
				{name: "nomColaborador", index: "nomColaborador", width: (3*widthTable/20)},
				{name: "tipoDestino", index: "tipoDestino", width: (1*widthTable/20), hidden: true},
				{name: "nomTipoViatico", index: "nomTipoViatico", width: (2*widthTable/20)},
				{name: "mtoTotal", index: "mtoTotal", width: (1*widthTable/20), hidden: true},
				{name: "mtoTotalFormateado", index: "mtoTotalFormateado", width: (2*widthTable/20), align: "right"},
				{name: "fecMaxRend", index: "fecMaxRend", width: (2*widthTable/20), align: "center"},
				//JMCR-ME Fecha Reprogramacion
				{name: "fecReprog", index: "fecReprog", width: (2*widthTable/20), align: "center"},
				//JMCR-ME Fecha Reprogramacion
				{name: "cantDiasRend", index: "cantDiasRend", width: (2*widthTable/20),
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "";
						if (cellValue < 0) {
							htmlElement = "<span class=\"jqGridViaticoSemaphoreRedCell\">" + cellValue + "</span>";
						}
						else {
							htmlElement = "<span class=\"jqGridViaticoSemaphoreGreenCell\">" + cellValue + "</span>";
						}
						return htmlElement;
					}
				},
				{name: "codEstadoRend", index: "codEstadoRend", width: (1*widthTable/20), hidden: true},
				{name: "nomEstRend", index: "nomEstRend", width: (2*widthTable/20),
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "";
						if (rowData.codEstadoRend == "03" || rowData.codEstadoRend == "04") {
							htmlElement = "<a class=\"jqGridViaticoTooltipClass\" data-toggle=\"tooltip\" data-placement=\"right\" title=\"" + rowData.obsRendicion + "\" >" + rowData.nomEstRend + "</a>";
						}
						else {
							htmlElement = rowData.nomEstRend;
						}
						return htmlElement;
					}
				},
				{name: "obsRendicion", index: "obsRendicion", width: (1*widthTable/20), hidden: true},
				{name: "expedientePlanViaje", index: "expedientePlanViaje", width: (1*widthTable/20), hidden: true},
				{name: "expedienteRendicion", index: "expedienteRendicion", width: (1*widthTable/20), hidden: true},
				{name: "numeroRegistroArchivo", index: "numeroRegistroArchivo", width: (1*widthTable/20), hidden: true},
				{name: "detalleRendicion", index: "detalleRendicion", width: (1.1*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkConsultarRendicionDetalle('" + rowData.codPlanViaje + "');\">" + rowData.detalleRendicion + "</a>";
						return htmlElement;
					}
				},
				{name: "seguimientoPlanilla", index: "seguimientoPlanilla", width: (1.2*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkConsultarSeguimientoRendicion('" + rowData.codPlanViaje + "');\">" + rowData.seguimientoPlanilla + "</a>";
						return htmlElement;
					}
				},
				{name: "verAdjuntosPlanilla", index: "verAdjuntosPlanilla", width: (0.7*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "<a class=\"jqGridViaticoLinkClass\" onclick=\"clickLinkConsultarAdjuntosRendicion('" + rowData.codPlanViaje + "');\">" + rowData.verAdjuntosPlanilla + "</a>";
						return htmlElement;
					}
				},
				{name: "indicadorHoras", index: "indicadorHoras", width: (1*widthTable/20), hidden: true},
				{name: "tipoDestino", index: "tipoDestino", width: (1*widthTable/20), hidden: true}
			],
			caption: "Planillas",
			pager: "#divPlanillaPagerTable",
			loadui: "disable"
		});
		planillaTable.clearGridData();
		addEventElementBySelector("#divPlanillaTable .ui-pg-button.ui-corner-all", "click", clickPagerPlanillaTable);
		addEventElementBySelector("#divPlanillaTable input.ui-pg-input", "keypress", keypressPagerPlanillaTable);
		addEventElementBySelector("#divPlanillaTable select.ui-pg-selbox", "change", changePagerPlanillaTable);
	}
}

function clickBtnBuscarUUOORendicion() {
	initElementsBuscarUUOO("divPlanillaTable");
	showModalElement("divBuscarUUOO");
    triggerResizeEvent();
}

function clickBtnBuscarColaboradorRendicion() {
	initElementsBuscarColaborador("divPlanillaTable");
	showModalElement("divBuscarColaborador");
	triggerResizeEvent();
}

function changeSelEstadoRendicion() {
	clearPlanillaTableRendicionBandeja();
}

function changeSelAnioRendicion() {
	
	var anioSeleccionado = getValueInputText("selAnioRendicion");
	hideElement("divErrorFechaInicioRendicion");
	hideElement("divErrorFechaFinalRendicion");
	hideElement("divErrorRendicion");
	modificarRangoFechaRendicionBandeja(anioSeleccionado);
	clearPlanillaTableRendicionBandeja();
}

function changeSelCanalAtencionRendicion() {
	clearPlanillaTableRendicionBandeja();
}

function changeEtiquetaFechaInicioRendicion() {
	if (isBrowserInternetExplorer()) {
		if (trimText(getValueInputText("etiquetaFechaInicioRendicion")) != "" && isValidoFormatDate(getValueInputText("etiquetaFechaInicioRendicion"))) {
			if (isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaInicioRendicion")), getValueInputText("hidFechaMaximaAnioActual"))) {
				setValueInputText("etiquetaFechaInicioRendicion", "");
			}
		}
		else {
			setValueInputText("etiquetaFechaInicioRendicion", "");
		}
		changeDateEtiquetaFechaInicioRendicionDiv();
	}
}

function changeEtiquetaFechaFinRendicion() {
	if (isBrowserInternetExplorer()) {
		if (trimText(getValueInputText("etiquetaFechaFinRendicion")) != "" && isValidoFormatDate(getValueInputText("etiquetaFechaFinRendicion"))) {
			if (isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaFinRendicion")), getValueInputText("hidFechaMaximaAnioActual"))) {
				setValueInputText("etiquetaFechaFinRendicion", "");
			}
		}
		else {
			setValueInputText("etiquetaFechaFinRendicion", "");
		}
		changeDateEtiquetaFechaFinRendicionDiv();
	}
}

function changeDateEtiquetaFechaInicioRendicionDiv() {
	clearPlanillaTableRendicionBandeja();
	validarFechaInicioConsultarRendicionBandeja();
}

function changeDateEtiquetaFechaFinRendicionDiv() {
	clearPlanillaTableRendicionBandeja();
	validarFechaFinalConsultarRendicionBandeja();
}

function clickBtnConsultarRendicion() {
	
	var flagValidacionFormulario = true;
	var flagFechaValida = true;
	var errorMessage = "";
	hideElement("divErrorRendicion");
	disabledElement("btnConsultarRendicion");
	clearPlanillaTableRendicionBandeja();
	
	if (flagValidacionFormulario && trimText(getValueInputText("hidCodigoColaborador")).length == 0 && trimText(getValueInputText("hidCodigoDependencia")).length == 0) {
		flagValidacionFormulario = false;
		errorMessage = errorMessageConsultarRendicionBandeja.numeroRegistroUUOOInvalido;
	}
	
	if (flagValidacionFormulario && trimText(getValueInputText("txtNroRegistro")).length != 0 && trimText(getValueInputText("hidCodigoColaborador")).length == 0 && trimText(getValueInputText("hidCodigoDependencia")).length != 0) {
		flagValidacionFormulario = false;
		errorMessage = errorMessageConsultarRendicionBandeja.numeroRegistroInvalido;
	}
	
	if (flagValidacionFormulario && trimText(getValueInputText("etiquetaFechaInicioRendicion")) == "") {
		flagValidacionFormulario = false;
		errorMessage = errorMessageConsultarRendicionBandeja.fechaInicioInvalida;
	}
	
	if (flagValidacionFormulario && trimText(getValueInputText("etiquetaFechaFinRendicion")) == "") {
		flagValidacionFormulario = false;
		errorMessage = errorMessageConsultarRendicionBandeja.fechaFinalInvalida;
	}
	
	/*
	if (flagValidacionFormulario && (getValueInputText("hidFlagFechaInicioValida") == "0" || getValueInputText("hidFlagFechaFinalValida") == "0")) {
		flagValidacionFormulario = false;
		errorMessage = errorMessageConsultarRendicionBandeja.rangoFechaInvalido;
	}
	*/
	
	if (flagValidacionFormulario && getValueInputText("hidFlagFechaInicioValida") == "0") {
		flagValidacionFormulario = false;
		flagFechaValida = false;
		validarFechaInicioConsultarRendicionBandeja();
	}
	
	if (flagValidacionFormulario && getValueInputText("hidFlagFechaFinalValida") == "0") {
		flagValidacionFormulario = false;
		flagFechaValida = false;
		validarFechaFinalConsultarRendicionBandeja();
	}
	
	if (flagValidacionFormulario) {
		callBuscarPlanillasBandeja();
	}
	else {
		if (flagFechaValida) {
			showMessageErrorConsultarRendicionBandeja(errorMessage);
		}
		enabledElement("btnConsultarRendicion");
	}
}

function clickBtnExportarExcelRendicion() {
	var encodeParam = "&codigoDependencia=" + getUpperCaseValueInputText("hidCodigoDependencia");
	encodeParam += "&codPlanilla=" + getUpperCaseValueInputText("txtCodigoPlanilla");
	encodeParam += "&codTrabajador=" + getUpperCaseValueInputText("hidCodigoColaborador");
	encodeParam += "&codEstadoRend=" + getUpperCaseValueInputText("selEstadoRendicion");
	encodeParam += "&indicadorCanalAtencion=" + trimText(getValueInputText("selCanalAtencionRendicion"));
	encodeParam += "&fechaDesde=" + getUpperCaseValueInputText("etiquetaFechaInicioRendicion");
	encodeParam += "&fechaHasta=" + getUpperCaseValueInputText("etiquetaFechaFinRendicion");
	encodeParam += "&codigoPaginaCaller=" + getUpperCaseValueInputText("hidCodigoPaginaCaller");
	location.href = contextPathUrl + "/rendicion.htm?action=exportarExcelBandejaRendicion" + encodeParam;
}

function clickBtnAceptarMensajeConfirmacionConsultarRendicionBandeja() {
	hideModalElement("divMensajeConfirmacionConsultarRendicionBandeja");
}

function clickBtnAceptarMensajeConfirmacionErrorConsultarRendicionBandeja() {
	hideModalElement("divMensajeConfirmacionErrorConsultarRendicionBandeja");
}

function clickPagerPlanillaTable() {
	showTooltip();
}

function keypressPagerPlanillaTable(event) {
	var keyCode = window.event ? event.keyCode : event.which;
	if (keyCode == 13) {
		showTooltip();
	}
}

function changePagerPlanillaTable() {
	showTooltip();
}

function clickLinkConsultarRendicionDetalle(codPlanViaje) {
	
	var planillaTable = $("#tblPlanilla");
	var rowData = planillaTable.getRowData(codPlanViaje);
	var tipoDestino = $.trim( rowData.tipoDestino );
	var indicadorHoras = $.trim( rowData.indicadorHoras );
	initElementsConsultarRendicionDetalle("divPlanillaTable", codPlanViaje,tipoDestino,indicadorHoras);
	showModalElement("divConsultarRendicionDetalle");
	triggerResizeEvent();
}

function clickLinkConsultarSeguimientoRendicion(codPlanViaje) {
	
	var planillaTable = $("#tblPlanilla");
	var rowData = planillaTable.getRowData(codPlanViaje);
	var dataParametrosConsultarSeguimiento = new Object();
	dataParametrosConsultarSeguimiento.codPlanViaje = codPlanViaje;
	dataParametrosConsultarSeguimiento.numeroExpediente = rowData.expedienteRendicion;
	dataParametrosConsultarSeguimiento.idElementCallModal = "divPlanillaTable";
	dataParametrosConsultarSeguimiento.codigoPaginaCaller = "01";
	initElementsConsultarSeguimiento(dataParametrosConsultarSeguimiento);
	showModalElement("divConsultarSeguimiento");
	triggerResizeEvent();
	triggerResizeEventSlow();
}

function clickLinkConsultarAdjuntosRendicion(codPlanViaje) {
	
	var planillaTable = $("#tblPlanilla");
	var rowData = planillaTable.getRowData(codPlanViaje);
	var numeroRegistroArchivo = rowData.numeroRegistroArchivo;
	if (trimText(numeroRegistroArchivo) != "") {
		var dataParametrosArchivo = new Object();
		dataParametrosArchivo.planViajeId = codPlanViaje;
	    dataParametrosArchivo.codigoBoleto = "";
	    dataParametrosArchivo.estadoOrigen = "V";
	    dataParametrosArchivo.estadoLLamada = "C";
	    dataParametrosArchivo.numeroRegistroColaborador = rowData.numeroRegistroAlterno;
	    dataParametrosArchivo.paginaOrigen = "PRINCIPAL";
	    initElementsConsultarRegistrarEliminarArchivo(dataParametrosArchivo);
	    showModalElement("divAdjuntarDocumento");
	    triggerResizeEvent();
	}
	else {
		var codPlanilla = rowData.codPlanilla;
		showMensajeConfirmacionConsultarRendicionBandeja(errorMessageConsultarRendicionBandeja.sinArchivoAdjunto + " " + codPlanilla);
	}
}

function modificarRangoFechaRendicionBandeja(anioSeleccionado) {
	
	setValueInputText("hidFechaInicialRangoFecha", "01/01/" + anioSeleccionado);
	setValueInputText("hidFechaFinalRangoFecha", "31/12/" + anioSeleccionado);
	setValueInputText("etiquetaFechaInicioRendicion", getValueInputText("hidFechaInicialRangoFecha"));
	setValueInputText("etiquetaFechaFinRendicion", getValueInputText("hidFechaFinalRangoFecha"));
	setValueInputText("hidFlagFechaInicioValida", "1");
	setValueInputText("hidFlagFechaFinalValida", "1");
}

function validarFechaInicioConsultarRendicionBandeja() {
	
	var flagFechaValida = true;
	var errorMessage = "";
	hideElement("divErrorRendicion");
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("hidFechaInicialRangoFecha")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaInicioRendicion")))) {
		flagFechaValida = false;
		errorMessage = errorMessageConsultarRendicionBandeja.fechaInicioInvalida;
	}
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaInicioRendicion")), formatEspDateToEngFormatDate(getValueInputText("hidFechaFinalRangoFecha")))) {
		flagFechaValida = false;
		errorMessage = errorMessageConsultarRendicionBandeja.fechaInicioInvalida;
	}
	
	if (!flagFechaValida) {
		setValueInputText("hidFlagFechaInicioValida", "0");
		showMessageErrorConsultarRendicionBandeja(errorMessage);
	}
	else {
		if (trimText(getValueInputText("etiquetaFechaInicioRendicion")) != "") {
			setValueInputText("hidFlagFechaInicioValida", "1");
			if (trimText(getValueInputText("etiquetaFechaFinRendicion")) != "") {
				validarFechaFinalConsultarRendicionBandeja();
			}
		}
		else {
			setValueInputText("hidFlagFechaInicioValida", "0");
		}
	}
}

function validarFechaFinalConsultarRendicionBandeja() {
	
	var flagFechaValida = true;
	var errorMessage = "";
	hideElement("divErrorRendicion");
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("hidFechaInicialRangoFecha")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaFinRendicion")))) {
		flagFechaValida = false;
		errorMessage = errorMessageConsultarRendicionBandeja.fechaFinalInvalida;
	}
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaFinRendicion")), formatEspDateToEngFormatDate(getValueInputText("hidFechaFinalRangoFecha")))) {
		flagFechaValida = false;
		errorMessage = errorMessageConsultarRendicionBandeja.fechaFinalInvalida;
	}
	
	if (!flagFechaValida) {
		setValueInputText("hidFlagFechaFinalValida", "0");
		showMessageErrorConsultarRendicionBandeja(errorMessage);
	}
	else {
		if (trimText(getValueInputText("etiquetaFechaFinRendicion")) != "") {
			setValueInputText("hidFlagFechaFinalValida", "1");
			if (trimText(getValueInputText("etiquetaFechaInicioRendicion")) != "") {
				validarFechaFinalMayorIgualFechaInicioConsultarRendicionBandeja();
			}
		}
		else {
			setValueInputText("hidFlagFechaFinalValida", "0");
		}
	}
}

function validarFechaFinalMayorIgualFechaInicioConsultarRendicionBandeja() {
	
	var flagFechaValida = true;
	var errorMessage = "";
	hideElement("divErrorRendicion");
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaInicioRendicion")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaFinRendicion")))) {
		flagFechaValida = false;
		errorMessage = errorMessageConsultarRendicionBandeja.fechaFinalMenorFechaInicial;
	}
	
	if (!flagFechaValida) {
		setValueInputText("hidFlagFechaFinalValida", "0");
		showMessageErrorConsultarRendicionBandeja(errorMessage);
	}
	else {
		setValueInputText("hidFlagFechaFinalValida", "1");
	}
}

function callBuscarPlanillasBandeja() {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/rendicion.htm?action=buscarPlanillasBandeja",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codigoDependencia": getUpperCaseValueInputText("hidCodigoDependencia"),
				"codPlanilla": getUpperCaseValueInputText("txtCodigoPlanilla"),
				"codTrabajador": getUpperCaseValueInputText("hidCodigoColaborador"),
				"codEstadoRend": getValueInputText("selEstadoRendicion"),
				"indicadorCanalAtencion": trimText(getValueInputText("selCanalAtencionRendicion")),
				"fechaDesde": getValueInputText("etiquetaFechaInicioRendicion"),
				"fechaHasta": getValueInputText("etiquetaFechaFinRendicion")
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showElement("divLoadingRendicion");
			},
			complete: function() {
				enabledElement("btnConsultarRendicion");
				hideElement("divLoadingRendicion");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var codigoConsulta = result.codigoConsulta;
				var errorMessage = result.errorMessage;
				if (codigoConsulta != null && codigoConsulta == "00") {
					var planillaList = result.planViajeList;
					showPlanillasConsultarRendicionBandeja(planillaList);
				}
				else if (codigoConsulta == "02") {
					showMessageErrorConsultarRendicionBandeja(errorMessage);
				}
				else {
					showMensajeConfirmacionErrorConsultarRendicionBandeja(errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callBuscarPlanillasBandeja");
			}
		});
	}, 500);
}

function showMessageErrorFechaInicioConsultarRendicionBandeja(errorMessage) {
	setHtmlElement("etiquetaErrorFechaInicioRendicion", errorMessage);
	showElement("divErrorFechaInicioRendicion");
}

function showMessageErrorFechaFinalConsultarRendicionBandeja(errorMessage) {
	setHtmlElement("etiquetaErrorFechaFinalRendicion", errorMessage);
	showElement("divErrorFechaFinalRendicion");
}

function showMessageErrorConsultarRendicionBandeja(errorMessage) {
	setHtmlElement("etiquetaErrorRendicion", errorMessage);
	showElement("divErrorRendicion");
}

function showMensajeConfirmacionConsultarRendicionBandeja(messageTitulo) {
	hideElement("divBodyPanelMensajeConfirmacionConsultarRendicionBandeja");
	setHtmlElement("divTituloPanelMensajeConfirmacionConsultarRendicionBandeja", messageTitulo);
	showModalElement("divMensajeConfirmacionConsultarRendicionBandeja");
}

function showMensajeConfirmacionErrorConsultarRendicionBandeja(messageTitulo) {
	hideElement("divBodyPanelMensajeConfirmacionErrorConsultarRendicionBandeja");
	setHtmlElement("divTituloPanelMensajeConfirmacionErrorConsultarRendicionBandeja", messageTitulo);
	showModalElement("divMensajeConfirmacionErrorConsultarRendicionBandeja");
}

function showPlanillasConsultarRendicionBandeja(planillaArray) {
	
	if (planillaArray != null && planillaArray.length > 0) {
		var planillaTable = $("#tblPlanilla");
		planillaTable.clearGridData();
		for (var i = 0; i < planillaArray.length; i++) {
			var planilla = planillaArray[i];
			var datarow = {
				codPlanViaje: planilla.codPlanViaje,
				codPlanilla: planilla.codPlanilla,
				fechaRegistro: planilla.fechaRegistro,
				fechaRegistroRendicion: planilla.fechaRegistroRendicionFormateda,
				numeroRegistroAlterno: planilla.numeroRegistroAlterno,
				nomColaborador: planilla.nomColaborador,
				tipoDestino: planilla.tipoDestino,
				nomTipoViatico: planilla.nomTipoViatico,
				mtoTotal: planilla.mtoTotal,
				mtoTotalFormateado: planilla.mtoTotalFormateado,
				fecMaxRend: planilla.fecMaxRendFormateada,
				//JMCR-ME Fecha Reprogramacion
				fecReprog: planilla.fecReprogFormateada,
				//JMCR-ME Fecha Reprogramacion
				cantDiasRend: planilla.cantDiasRend,
				codEstadoRend: planilla.codEstadoRend,
				nomEstRend: planilla.nomEstRend,
				obsRendicion: planilla.obsRendicion,
				expedientePlanViaje: planilla.expedientePlanViaje,
				expedienteRendicion: planilla.expedienteRendicion,
				numeroRegistroArchivo: planilla.numeroRegistroArchivo,
				detalleRendicion: "DETALLE",
				seguimientoPlanilla: "SEGUIMIENTO",
				verAdjuntosPlanilla: "VER",
				indicadorHoras: planilla.indicadorHoras,
				tipoDestino: planilla.tipoDestino,
			};
			planillaTable.jqGrid("addRowData", datarow.codPlanViaje, datarow);
		}
		planillaTable.trigger("reloadGrid");
		enabledElement("btnExportarExcelRendicion");
		showTooltip();
	}
	else {
		setHtmlElement("divPlanillaPagerTable_left", errorMessageConsultarRendicionBandeja.sinRegistrosBusqueda);
	}
}

function clearPlanillaTableRendicionBandeja() {
	var planillaTable = $("#tblPlanilla");
	planillaTable.clearGridData();
	disabledElement("btnExportarExcelRendicion");
	setHtmlElement("divPlanillaPagerTable_left", "");
}

/*Inicio Codigo - Reutilizacion buscarUUOO*/
var dataParametrosBuscarUUOO = new Object();
dataParametrosBuscarUUOO.idCodigoRegistrador = "hidCodigoRegistrador";
dataParametrosBuscarUUOO.idCodigoTipoUUOOViatico = getValueInputText("hidFlagBuscarUUOO");
dataParametrosBuscarUUOO.idDivScreenBlock = "divScreenBlock";

var buscarUUOOBeforeMethod = function() {
};

var buscarUUOOAfterMethod = function(rowData) {
	
	setValueInputText("txtNroRegistro", "");
	setValueInputText("hidTxtNroRegistro", "");
	setValueInputText("txtNombreColaborador", "");
	setValueInputText("hidCodigoColaborador", "");
	setValueInputText("hidCodigoEstadoColaborador", "");
	setValueInputText("txtUUOO", rowData["uuoo"]);
	setValueInputText("hidTxtUUOO", rowData["uuoo"]);
    setValueInputText("txtDescripcionDependencia", rowData["descripcionUUOO"]);
    setValueInputText("hidCodigoDependencia", rowData["codigoDependencia"]);
    hideElement("divErrorRendicion");
	clearPlanillaTableRendicionBandeja();
};

var buscarUUOOService = new BuscarUUOOService(dataParametrosBuscarUUOO, buscarUUOOBeforeMethod, buscarUUOOAfterMethod);
/*Fin Codigo - Reutilizacion buscarUUOO*/

/*Inicio Codigo - Reutilizacion buscarUUOOInput*/
function buscarUUOOInputBeforeMethod() {
	
	setValueInputText("txtNroRegistro", "");
	setValueInputText("hidTxtNroRegistro", "");
	setValueInputText("hidCodigoColaborador", "");
	setValueInputText("txtNombreColaborador", "");
	setValueInputText("hidCodigoEstadoColaborador", "");
	setValueInputText("hidTxtUUOO", "");
	setValueInputText("txtDescripcionDependencia", "");
	setValueInputText("hidCodigoDependencia", "");
	clearPlanillaTableRendicionBandeja();
}

function buscarUUOOInputAfterMethod(uuooList) {
	
	if (uuooList != null && uuooList.length > 0) {
		for (var i = 0; i < uuooList.length; i++) {
			var uuoo = uuooList[i];
			var datarow = {
				codigoDependencia: uuoo.cod_dep,
				uuoo: uuoo.uuoo,
				uuooDetalle: uuoo.nom_largo
			};
			setValueInputText("txtUUOO", datarow.uuoo);
			setValueInputText("hidTxtUUOO", datarow.uuoo);
			setValueInputText("hidCodigoDependencia", datarow.codigoDependencia);
			setValueInputText("txtDescripcionDependencia", datarow.uuooDetalle);
			break;
		}
	}
	else {         
		setHtmlElement("etiquetaErrorRendicion", errorMessageBuscarUUOOInput.sinRegistrosBusqueda);
		showElement("divErrorRendicion");
	}
}

var buscarUUOOInputService = new BuscarUUOOInputService();

function initElementsBuscarUUOOInputService(errorMessageBuscarUUOOInput) {
	
	var dataParametros = new Object();
	dataParametros.idNumeroUUOO = "txtUUOO";
	dataParametros.idCodigoRegistrador = "hidCodigoRegistrador";
	dataParametros.idCodigoTipoUUOOViatico = getValueInputText("hidFlagBuscarUUOO");
	dataParametros.idDivLoading = "divLoadingBuscarInput";
	dataParametros.idDivError = "divErrorRendicion";
	dataParametros.idEtiquetaError = "etiquetaErrorRendicion";
	dataParametros.idDivScreenBlock = "divScreenBlock";
	dataParametros.errorMessage = errorMessageBuscarUUOOInput;
	buscarUUOOInputService = new BuscarUUOOInputService(dataParametros, buscarUUOOInputBeforeMethod, buscarUUOOInputAfterMethod);
}
/*Fin Codigo - Reutilizacion buscarUUOOInput*/

/*Inicio Codigo - Reutilizacion buscarColaborador*/
var dataParametrosBuscarColaborador = new Object();
dataParametrosBuscarColaborador.idCodigoRegistrador = "hidCodigoRegistrador";
dataParametrosBuscarColaborador.idNumeroRegistroRegistrador = "hidNumeroRegistroRegistrador";
dataParametrosBuscarColaborador.idCodigoTipoUsuarioViatico = getValueInputText("hidFlagBuscarColaborador");
dataParametrosBuscarColaborador.idDivScreenBlock = "divScreenBlock";

var buscarColaboradorBeforeMethod = function() {
};

var buscarColaboradorAfterMethod = function(rowData) {
	
	setValueInputText("txtNroRegistro", rowData["numeroRegistro"]);
	setValueInputText("hidTxtNroRegistro", rowData["numeroRegistro"]);
	setValueInputText("hidCodigoColaborador", rowData["codigoEmpleado"]);
	setValueInputText("txtNombreColaborador", rowData["nombreCompleto"]);
	setValueInputText("hidCodigoEstadoColaborador", rowData["codigoEstado"]);
	setValueInputText("txtUUOO", rowData["uuoo"]);
	setValueInputText("hidTxtUUOO", rowData["uuoo"]);
	setValueInputText("txtDescripcionDependencia", rowData["uuooDetalle"]);
	setValueInputText("hidCodigoDependencia", rowData["codigoDependencia"]);
	hideElement("divErrorRendicion");
	clearPlanillaTableRendicionBandeja();
};

var buscarColaboradorService = new BuscarColaboradorService(dataParametrosBuscarColaborador, buscarColaboradorBeforeMethod, buscarColaboradorAfterMethod);
/*Fin Codigo - Reutilizacion buscarColaborador*/

/*Inicio Codigo - Reutilizacion buscarColaboradorInput*/
var buscarColaboradorInputBeforeMethod = function() {
	
	setValueInputText("hidTxtNroRegistro", "");
	setValueInputText("hidCodigoColaborador", "");
	setValueInputText("txtNombreColaborador", "");
	setValueInputText("hidCodigoEstadoColaborador", "");
	/*
	setValueInputText("txtUUOO", "");
	setValueInputText("txtDescripcionDependencia", "");
	setValueInputText("hidCodigoDependencia", "");
	*/
	clearPlanillaTableRendicionBandeja();
};

var buscarColaboradorInputAfterMethod = function(colaboradorList) {
	
	if (colaboradorList != null && colaboradorList.length > 0) {
		for (var i = 0; i < colaboradorList.length; i++) {
			var colaborador = colaboradorList[i];
			var datarow = {
				numeroRegistro: colaborador.numero_registro,
				nombreCompleto: colaborador.nombre_completo,
				uuoo: colaborador.uuoo,
				codigoDependencia: colaborador.codigoDependencia,
				uuooDetalle: colaborador.dependencia,
				codigoEmpleado: colaborador.codigoEmpleado,
				codigoEstado: colaborador.codigoEstado,
				estadoDetalle: colaborador.estado
			};
			setValueInputText("hidTxtNroRegistro", datarow.numeroRegistro);
			setValueInputText("hidCodigoColaborador", datarow.codigoEmpleado);
			setValueInputText("txtNombreColaborador", datarow.nombreCompleto);
			setValueInputText("hidCodigoEstadoColaborador", datarow.codigoEstado);
			setValueInputText("txtUUOO", datarow.uuoo);
			setValueInputText("hidTxtUUOO", datarow.uuoo);
			setValueInputText("txtDescripcionDependencia", datarow.uuooDetalle);
			setValueInputText("hidCodigoDependencia", datarow.codigoDependencia);
			break;
		}
	}
	else {
		setHtmlElement("etiquetaErrorRendicion", errorMessageBuscarColaboradorInput.sinRegistrosBusqueda);
		showElement("divErrorRendicion");
	}
};

var buscarColaboradorInputService = new BuscarColaboradorInputService();

function initElementsBuscarColaboradorInputService(errorMessageBuscarColaboradorInput) {
	
	var dataParametros = new Object();
	dataParametros.idNumeroRegistroColaborador = "txtNroRegistro";
	dataParametros.idCodigoRegistrador = "hidCodigoRegistrador";
	dataParametros.idNumeroRegistroRegistrador = "hidNumeroRegistroRegistrador";
	dataParametros.idCodigoTipoUsuarioViatico = getValueInputText("hidFlagBuscarColaborador");
	dataParametros.estadoLlamada = "B";
	dataParametros.idDivLoading = "divLoadingBuscarInput";
	dataParametros.idDivError = "divErrorRendicion";
	dataParametros.idEtiquetaError = "etiquetaErrorRendicion";
	dataParametros.idDivScreenBlock = "divScreenBlock";
	dataParametros.errorMessage = errorMessageBuscarColaboradorInput;
	buscarColaboradorInputService = new BuscarColaboradorInputService(dataParametros, buscarColaboradorInputBeforeMethod, buscarColaboradorInputAfterMethod);
}
/*Fin Codigo - Reutilizacion buscarColaboradorInput*/

/*Inicio Codigo - Reutilizacion adjuntarDocumento*/
var adjuntarDocumentoBeforeMethod = function() {
};

var adjuntarDocumentoAfterMethod = function(data) {
};

var adjuntarDocumentoService = new AdjuntarDocumentoService(adjuntarDocumentoBeforeMethod, adjuntarDocumentoAfterMethod);
/*Fin Codigo - Reutilizacion adjuntarDocumento*/

$(window).on("resize", function() {
	resizeTable("tblPlanilla");
	//Inicializando las tablas de los modales
	resizeTable("tblUUOO");
	resizeTable("tblColaborador");
	resizeTable("tblDetalleViatico");
	resizeTable("tblDetalleGasto");
	resizeTable("tblSeguimiento");
	resizeTable("tblArchivo");
});