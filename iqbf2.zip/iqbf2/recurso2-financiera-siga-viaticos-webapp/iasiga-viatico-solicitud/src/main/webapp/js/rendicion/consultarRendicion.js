function initElementsConsultarRendicion() {
	
	setInitElementsConsultarRendicion();
	setInitComprobanteTable(getValueInputText("hidMoneda"));
	setInitRendicionTable(getValueInputText("hidMoneda"));
	if (getValueInputText("hidCodigoCanalAtencion") == "R") {
		setInitDepositoTable();
		if (getValueInputText("hidFlagAsociadoRIC") == "1") {
			setInitRICTable();
		}
	}
	callObtenerComprobantesAsignacionesPapeletasRics();
}

function setInitElementsConsultarRendicion() {	
	
	//JMCR-ME Hora < 4 Rendicion
	enabledElement("etiquetaHoraSalidaEventoProgramado");
	enabledElement("etiquetaHoraRetornoEventoProgramado");		
	enabledElement("etiquetaHoraSalidaItinerarioEjecutado");
	enabledElement("etiquetaHoraRetornoItinerarioEjecutado");
	
	hideElement("etiquetaHoraSalidaEventoProgramado");
	hideElement("etiquetaHoraRetornoEventoProgramado");
	hideElement("etiquetaHoraSalidaItinerarioEjecutado");
	hideElement("etiquetaHoraRetornoItinerarioEjecutado");	
	
	disabledElement("etiquetaHoraSalidaEventoProgramado");
	disabledElement("etiquetaHoraRetornoEventoProgramado");		
	disabledElement("etiquetaHoraSalidaItinerarioEjecutado");
	disabledElement("etiquetaHoraRetornoItinerarioEjecutado");		
	//JMCR-ME Hora < 4 Rendicion	
	
	if (getValueInputText("hidTipoDestino") == "01") {
		setHtmlElement("divTituloPanelConsultarRendicion", propertyMessageConsultarRendicion.tituloNacional);
		
		//JMCR-ME Hora < 4 Rendicion	
		
		if (getValueInputText("hidFlagMenorIgual4Horas") == "1") {		
			enabledElement("etiquetaHoraSalidaEventoProgramado");
			enabledElement("etiquetaHoraRetornoEventoProgramado");		
			enabledElement("etiquetaHoraSalidaItinerarioEjecutado");
			enabledElement("etiquetaHoraRetornoItinerarioEjecutado");
			
			showElement("etiquetaHoraSalidaEventoProgramado");
			showElement("etiquetaHoraRetornoEventoProgramado");
			showElement("etiquetaHoraSalidaItinerarioEjecutado");
			showElement("etiquetaHoraRetornoItinerarioEjecutado");
			
			disabledElement("etiquetaHoraSalidaEventoProgramado");
			disabledElement("etiquetaHoraRetornoEventoProgramado");		
			disabledElement("etiquetaHoraSalidaItinerarioEjecutado");
			disabledElement("etiquetaHoraRetornoItinerarioEjecutado");		
		}
		else {
		}
		//JMCR-ME Hora < 4 Rendicion		
	}
	else {
		setHtmlElement("divTituloPanelConsultarRendicion", propertyMessageConsultarRendicion.tituloInternacional);
	}
	
	//Si el estado es Enviado a Caja Chica(02), Enviado a Financiera(05), Enviado a OSA(06) o Rendido(10)
	var codEstado = getValueInputText("hidCodigoEstadoRendicion"); 
	if (codEstado == "02" || codEstado == "05" || codEstado == "06" || codEstado == "10") {
		enabledElement("btnImprimirRendicion");
	}
	
	hideElement("divHiddenImprimirPost");
	setValueInputText("selIndicadorDDJJ", getValueInputText("hidIndicadorExteriorDDJJ"));
	setValueInputText("selIndicadorDevolucionMenorGasto", getValueInputText("hidIndicadorMenorGasto"));
	addEventElement("divRendicionHeadingPanel", "click", clickDivRendicionHeadingPanel);
	addEventElement("divDevolucionHeadingPanel", "click", clickDivDevolucionHeadingPanel);
	addEventElement("btnConsultarAsistencia", "click", clickBtnConsultarAsistencia);
	addEventElement("btnVerDetalleRendicion", "click", clickBtnVerDetalleRendicion);
	addEventElement("btnImprimirRendicion", "click", clickBtnImprimirRendicion);
	addEventElement("btnRetornarRendicion", "click", clickBtnRetornarRendicion);
}

function setInitComprobanteTable(monedaViatico) {
	
	var comprobanteTable = $("#tblComprobante");
	var heightJqGrid = 200;
	setStyleElement("divComprobanteTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 2, true));
	if (comprobanteTable) {
		var comprobanteTableDiv = $("#divComprobanteTable");
		var widthTable = comprobanteTableDiv.width();
		comprobanteTable.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Codigo Plan Viaje",
				"Secuencial",
				"Concepto ID",
				"",
				"Id",
				"Codigo Tipo Documento",
				"Tipo Doc.",
				"Serie",
				"Nro. Documento",
				"Fecha Doc.",
				"Proveedor/Empleado",
				"Monto Doc.",
				"Monto Doc. " + monedaViatico,
				"Monto Rendido",
				"Monto Rendido " + monedaViatico,
				"Flag Rendicion Total",
				"Acción"
			],
			colModel: [
				{name: "planViajeId", index: "planViajeId", width: (1*widthTable/20), hidden: true},
				{name: "secuencial", index: "secuencial", width: (1*widthTable/20), hidden: true},
				{name: "conceptoId", index: "conceptoId", width: (1*widthTable/20), hidden: true},
				{name: "columna01", index: "columna01", width: (0.5*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "";
						if (rowData.flagRendicionTotal == "0") {
							htmlElement = "<input id=\"chkJqGridComprobante" + rowData.secuencial + "\" name=\"chkJqGridComprobante\" class=\"chkJqGridComprobanteClass\" type=\"checkbox\" value=\"" + rowData.secuencial + "\" onclick=\"javascript:clickCheckboxJqGridComprobante('" + rowData.secuencial + "');\" />";
						}
						return htmlElement;
					}
				},
				{name: "identificador", index: "identificador", width: (0.5*widthTable/20), align: "right"},
				{name: "tipoDocumento", index: "tipoDocumento", width: (1*widthTable/20), hidden: true},
				{name: "descripcionTipoDocumento", index: "descripcionTipoDocumento", width: (4.2*widthTable/20)},
				{name: "serie", index: "serie", width: (1.7*widthTable/20)},
				{name: "numeroDocumento", index: "numeroDocumento", width: (2*widthTable/20)},
				{name: "fechaDocumento", index: "fechaDocumento", width: (1.8*widthTable/20), align: "center"},
				{name: "nombreRazonSocial", index: "nombreRazonSocial", width: (3.7*widthTable/20)},
				{name: "montoTotal", index: "montoTotal", width: (1*widthTable/20), hidden: true},
				{name: "montoTotalFormateado", index: "montoTotalFormateado", width: (1.7*widthTable/20), align: "right"},
				{name: "mtoReconocido", index: "mtoReconocido", width: (1*widthTable/20), hidden: true},
				{name: "mtoReconocidoFormateado", index: "mtoReconocidoFormateado", width: (1.9*widthTable/20), align: "right"},
				{name: "flagRendicionTotal", index: "flagRendicionTotal", width: (1*widthTable/20), hidden: true},
				{name: "accion", index: "accion", width: (2*widthTable/20), align: "center", hidden: true,
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "";
						if (rowData.flagRendicionTotal == "0") {
							var linkConsultarComprobante = "<a class=\"jqGridViaticoLinkClass\" onclick=\"javascript:clickLinkConsultarComprobante('" + rowData.secuencial + "');\">";
							linkConsultarComprobante += "<img border=\"0\" title=\"consultar\" width=\"14\" height=\"15\" src=\"/a/imagenes/sigad/icono_lupa3.png\">";
							linkConsultarComprobante += "</a>";
							htmlElement = linkConsultarComprobante;
						}
						return htmlElement;
					}
				}
			],
			rowattr: function(dataTable) {
				if (dataTable.flagRendicionTotal == "1") {
					return {"class": "boldFontTableClass"};
				}
			},
			caption: "Registro de Comprobantes",
			pager: "#divComprobantePagerTable",
			loadui: "disable"
		});
		comprobanteTable.clearGridData();
	}
}

function setInitRendicionTable(monedaViatico) {
	var rendicionTable = $("#tblRendicion");
	var heightJqGrid = 200;
	setStyleElement("divRendicionTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 1, true));
	if (rendicionTable) {
		var rendicionTableDiv = $("#divRendicionTable");
		var widthTable = rendicionTableDiv.width();
		rendicionTable.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Codigo Plan Viaje",
				"Secuencial",
				"Cod.",
				"Asignación",
				"Entregado&nbsp;" + monedaViatico,
				"Rendido&nbsp;" + monedaViatico,
				"x Devolver&nbsp;" + monedaViatico,
				"Devuelto&nbsp;" + monedaViatico,
				"Flag Concepto Total"
			],
			colModel: [
				{name: "planViajeID", index: "planViajeID", width: (1*widthTable/20), hidden: true},
				{name: "secuencial", index: "secuencial", width: (1*widthTable/20), hidden: true},
				{name: "conceptoID", index: "conceptoID", width: (2*widthTable/20), align: "center"},
				{name: "descripcionConcepto", index: "descripcionConcepto", width: (6*widthTable/20)},
				{name: "monto", index: "monto", width: (3*widthTable/20), align: "right"},
				{name: "montoRendido", index: "montoRendido", width: (3*widthTable/20), align: "right"},
				{name: "montoDevolver", index: "montoDevolver", width: (3*widthTable/20), align: "right"},
				{name: "montoDevueltoVoucherRIC", index: "montoDevueltoVoucherRIC", width: (3*widthTable/20), align: "right"},
				{name: "flagPlanViajeConceptoTotal", index: "flagPlanViajeConceptoTotal", width: (1*widthTable/20), hidden: true}
			],
			rowattr: function(dataTable) {
				if (dataTable.flagPlanViajeConceptoTotal == "1") {
					return {"class": "boldFontTableClass"};
				}
			},
			caption: "Detalle de Rendición",
			pager: "#divRendicionPagerTable",
			loadui: "disable"
		});
		rendicionTable.clearGridData();
	}
}

function setInitDepositoTable() {
	var depositoTable = $("#tblDeposito");
	var heightJqGrid = 200;
	setStyleElement("divDepositoTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 1, true));
	if (depositoTable) {
		var depositoTableDiv = $("#divDepositoTable");
		var widthTable = depositoTableDiv.width();
		depositoTable.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Codigo Boleta Deposito",
				"Banco",
				"Nro. Cuenta",
				"Fecha Voucher",
				"Nro. Operación",
				"T.C.",
				"Importe",
				"Importe",
				"RIC Asociado",
				"Flag Asociado RIC",
				"Flag Papeleta Total"
			],
			colModel: [
				{name: "codigoBoletaDeposito", index: "codigoBoletaDeposito", width: (1*widthTable/20), hidden: true},
				{name: "nombreBanco", index: "nombreBanco", width: (4.5*widthTable/20)},
				{name: "numeroCuentaBanco", index: "numeroCuentaBanco", width: (3*widthTable/20)},
				{name: "fechaVoucher", index: "fechaVoucher", width: (2*widthTable/20), align: "center"},
				{name: "numeroOperacion", index: "numeroOperacion", width: (3.3*widthTable/20)},
				{name: "valorTipoCambio", index: "valorTipoCambio", width: (1.5*widthTable/20), align: "right"},
				{name: "montoDeposito", index: "montoDeposito", width: (1*widthTable/20), hidden: true},
				{name: "montoDepositoFormateado", index: "montoDepositoFormateado", width: (2.2*widthTable/20), align: "right"},
				{name: "reciboIngresoCajaAsosiado", index: "reciboIngresoCajaAsosiado", width: (3*widthTable/20)},
				{name: "flagAsociadoRIC", index: "flagAsociadoRIC", width: (1*widthTable/20), hidden: true},
				{name: "flagPapeletaTotal", index: "flagPapeletaTotal", width: (1*widthTable/20), hidden: true}
			],
			rowattr: function(dataTable) {
				if (dataTable.flagPapeletaTotal == "1") {
					return {"class": "boldFontTableClass"};
				}
			},
			caption: "Voucher de Depósito",
			pager: "#divDepositoPagerTable",
			loadui: "disable"
		});
		depositoTable.clearGridData();
	}
}

function setInitRICTable() {
	
	var ricTable = $("#tblRIC");
	var heightJqGrid = 200;
	setStyleElement("divRICTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 1, true));
	if (ricTable) {
		var ricTableDiv = $("#divRICTable");
		var widthTable = ricTableDiv.width();
		ricTable.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Secuencia RIC",
				"Nro. RIC",
				"Fecha Generación",
				"Monto Numerico",
				"Monto",
				"Clasificador",
				"Flag Comprobante Total",
				"Observación"
			],
			colModel: [
				{name: "secuenciaRIC", index: "secuenciaRIC", width: (1*widthTable/30), hidden: true},
				{name: "numeroDocumento", index: "numeroDocumento", width: (3*widthTable/30)},
				{name: "fechaGeneracion", index: "fechaGeneracion", width: (4*widthTable/30), align: "center"},
				{name: "monto", index: "monto", width: (1*widthTable/20), hidden: true},
				{name: "montoFormateado", index: "montoFormatedado", width: (3*widthTable/30), align: "right"},
				{name: "clasificador", index: "clasificador", width: (10*widthTable/30)},
				{name: "flagComprobanteTotal", index: "flagComprobanteTotal", width: (1*widthTable/30), hidden: true},
				{name: "observacion", index: "observacion", width: (10*widthTable/30)}
			],
			rowattr: function(dataTable) {
				if (dataTable.flagComprobanteTotal == "1") {
					return {"class": "boldFontTableClass"};
				}
			},
			caption: "Detalle de RIC",
			pager: "#divRICPagerTable",
			loadui: "disable"
		});
		ricTable.clearGridData();
	}
}

function clickDivRendicionHeadingPanel() {
	if (getValueInputText("hidEstadoRendicionPanel") == "maximize") {
		setValueInputText("hidEstadoRendicionPanel", "minimize");
		setSrcImageElement("imgRendicionHeadingPanel", minimizeURL);
		hideElement("divRendicionBodyPanel");
	}
	else if (getValueInputText("hidEstadoRendicionPanel") == "minimize") {
		setValueInputText("hidEstadoRendicionPanel", "maximize");
		setSrcImageElement("imgRendicionHeadingPanel", maximizeURL);
		showElement("divRendicionBodyPanel");
		triggerResizeEvent();
	}
}

function clickDivDevolucionHeadingPanel() {
	if (getValueInputText("hidEstadoDevolucionPanel") == "maximize") {
		setValueInputText("hidEstadoDevolucionPanel", "minimize");
		setSrcImageElement("imgDevolucionHeadingPanel", minimizeURL);
		hideElement("divDevolucionBodyPanel");
	}
	else if (getValueInputText("hidEstadoDevolucionPanel") == "minimize") {
		setValueInputText("hidEstadoDevolucionPanel", "maximize");
		setSrcImageElement("imgDevolucionHeadingPanel", maximizeURL);
		showElement("divDevolucionBodyPanel");
		triggerResizeEvent();
	}
}

function clickBtnConsultarAsistencia() {
	
	var fechaInicial = getCurrentDateFormatEsp();
	var fechaFinal = getCurrentDateFormatEsp();
	if (getValueInputText("hidTipoDestino") == "01") {
		fechaInicial = getValueInputText("etiquetaFechaHoraSalidaEventoProgramado");
		fechaFinal = getValueInputText("etiquetaFechaHoraRetornoEventoProgramado");
		
		//JMCR-ME Hora < 4 Rendicion
		horaInicial = getValueInputText("etiquetaHoraSalidaEventoProgramado");
		horaFinal = getValueInputText("etiquetaHoraRetornoEventoProgramado");
		//JMCR-ME Hora < 4 Rendicion
	}
	else {
		fechaInicial = getValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado");
		fechaFinal = getValueInputText("etiquetaFechaHoraRetornoItinerarioEjecutado");

		//JMCR-ME Hora < 4 Rendicion
		horaInicial = getValueInputText("etiquetaHoraSalidaItinerarioEjecutado");
		horaFinal = getValueInputText("etiquetaHoraRetornoItinerarioEjecutado");
		//JMCR-ME Hora < 4 Rendicion
	}
	initElementsReportarAsistencia("divComprobanteTable", getValueInputText("txtNroRegistro"), fechaInicial, fechaFinal, getValueInputText("txtNombreColaborador"));
	showModalElement("divReporteAsistencia");
	triggerResizeEvent();
}

function clickBtnVerDetalleRendicion() {
	initElementsConsultarGastoDetalle("divComprobanteTable", getValueInputText("hidCodigoPlanViaje"), getValueInputText("hidValueChkJqGridComprobante"), getValueInputText("hidMoneda"));
    showModalElement("divConsultarGastoDetalle");
	triggerResizeEvent();
}

function clickBtnImprimirRendicion() {
  /*  var formPost = $("#formImprimirPost");
    formPost.find("input[name='action']").val("imprimirRendicionViatico");
    //formPost.find("input[name='action']").val("imprimirRendicionDeclaracionJurada");
    //formPost.find("input[name='action']").val("imprimirRendicionDeclaracionJuradaPermanencia");
    formPost.find("input[name='codPlanilla']").val(getTrimValue("#txtNroPlanilla"));
    formPost.submit();*/
	initElementsImpresion();
    showModalElement("divImpresion");
    
}

function clickBtnRetornarRendicion() {
	window.history.back();
}

function clickCheckboxJqGridComprobante(secuencial) {
	
	var jqGridComprobanteChk = $("input#chkJqGridComprobante" + secuencial);
	var jqGridComprobanteChkAnother = $("input.chkJqGridComprobanteClass").not("input#chkJqGridComprobante" + secuencial);
	
	if (jqGridComprobanteChk.is(":checked")) {
		setValueInputText("hidValueChkJqGridComprobante", secuencial);
		jqGridComprobanteChkAnother.attr("disabled", "disabled");
	}
	else {
		setValueInputText("hidValueChkJqGridComprobante", "");
		jqGridComprobanteChkAnother.removeAttr("disabled", "disabled");
	}
}

function clickLinkConsultarComprobante(secuencial) {
	
	var dataParametrosComprobante = new Object();
	dataParametrosComprobante.planViajeId = getValueInputText("hidCodigoPlanViaje");
	dataParametrosComprobante.estadoLlamada = "C";
	dataParametrosComprobante.secuencial = secuencial;
	dataParametrosComprobante.origenLlamada = "V";
	dataParametrosComprobante.saldoRendir = getValueInputText("hidMontoRendirTotal");
	dataParametrosComprobante.numeroRegistroColaborador = getValueInputText("txtNroRegistro");
	initElementsRegistrarModificarComprobanteRendicion(dataParametrosComprobante);
    showModalElement("divRegistrarModificarComprobanteRendicion");
    triggerResizeEvent();
    triggerResizeEventTooSlow();
}

function callObtenerComprobantesAsignacionesPapeletasRics() {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/registrarRendicion.htm?action=obtenerComprobantesAsignacionesPapeletasRics",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codigoPlanViaje": getValueInputText("hidCodigoPlanViaje"),
				"montoRendirTotal": getValueInputText("hidMontoRendirTotal"),
				"simboloMoneda": getValueInputText("hidMoneda")
			},
			beforeSend: function() {
				/*
				showModalElement("divScreenBlock");
				showModalElement("divMensajeConfirmacionLoadingRegistrarModificarRendicion");
				*/
			},
			complete: function() {
				/*
				hideModalElement("divMensajeConfirmacionLoadingRegistrarModificarRendicion");
				hideModalElement("divScreenBlock");
				*/
			},
			success: function(result) {
				var codigoConsulta = result.codigoConsulta;
				var errorMessage = result.errorMessage;
				if (codigoConsulta != null && codigoConsulta == "00") {
					var rendicionVO = result.rendicionVO;
					var planViajeRendicionList = rendicionVO.planViajeRendicionList;
					var planViajeConceptoList = rendicionVO.planViajeConceptoList;
					var papeletaDepositoList = rendicionVO.papeletaDepositoList;
					var comprobanteIngresoList = rendicionVO.comprobanteIngresoList;
					showComprobantesConsultarRendicion(planViajeRendicionList);
					showAsignacionConceptoConsultarRendicion(planViajeConceptoList);
					if (getValueInputText("hidCodigoCanalAtencion") == "R") {
						showPapeletasDepositoConsultarRendicion(papeletaDepositoList);
						if (getValueInputText("hidFlagAsociadoRIC") == "1") {
							showRecibosIngresoCaja(comprobanteIngresoList);
						}
					}
				}
				else {
					alert(errorMessage);
					//showMensajeConfirmacionAplicativoWithoutBody("divMensajeConfirmacionErrorRegistrarModificarRendicion", "divTituloPanelMensajeConfirmacionErrorRegistrarModificarRendicion", "divBodyPanelMensajeConfirmacionErrorRegistrarModificarRendicion", errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callObtenerComprobantesAsignacionesPapeletasRics");
			}
		});
	}, 500);
}

function showComprobantesConsultarRendicion(planViajeRendicionArray) {
	
	var comprobanteTable = $("#tblComprobante");
	comprobanteTable.clearGridData();
	if (planViajeRendicionArray != null && planViajeRendicionArray.length > 0) {
		for (var i = 0; i < planViajeRendicionArray.length; i++) {
			var comprobante = planViajeRendicionArray[i];
			var identificador = i + 1;
			if (comprobante.flagRendicionTotal == "1") {
				identificador = "";
			}
			var datarow = {
				planViajeId: comprobante.planViajeId,
				secuencial: comprobante.secuencial,
				conceptoId: comprobante.conceptoId,
				columna01: "",
				identificador: identificador,
				tipoDocumento: comprobante.tipoDocumento,
				descripcionTipoDocumento: comprobante.descripcionTipoDocumento,
				serie: comprobante.serie,
				numeroDocumento: comprobante.numeroDocumento,
				fechaDocumento: comprobante.fechaDocumentoFormateada,
				nombreRazonSocial: comprobante.nombreRazonSocial,
				montoTotal: comprobante.montoTotal,
				montoTotalFormateado: comprobante.montoTotalFormateado,
				mtoReconocido: comprobante.mtoReconocido,
				mtoReconocidoFormateado: comprobante.mtoReconocidoFormateado,
				flagRendicionTotal: comprobante.flagRendicionTotal
			};
			comprobanteTable.jqGrid("addRowData", datarow.secuencial, datarow);
		}
		comprobanteTable.trigger("reloadGrid");
	}
}

function showAsignacionConceptoConsultarRendicion(planViajeConceptoArray) {
	
	var rendicionTable = $("#tblRendicion");
	rendicionTable.clearGridData();
	if (planViajeConceptoArray != null && planViajeConceptoArray.length > 0) {
		for (var i = 0; i < planViajeConceptoArray.length; i++) {
			var asignacionConcepto = planViajeConceptoArray[i];
			var identificador = i + 1;
			var datarow = {
				planViajeID: asignacionConcepto.planViajeID,
				secuencial: identificador,
				conceptoID: asignacionConcepto.conceptoID,
				descripcionConcepto: asignacionConcepto.descripcionConcepto,
				monto: asignacionConcepto.montoFormateado,
				montoRendido: asignacionConcepto.montoRendidoFormateado,
				montoDevolver: asignacionConcepto.montoDevolverFormateado,
				montoDevueltoVoucherRIC: asignacionConcepto.montoDevueltoVoucherRICFormateado,
				flagPlanViajeConceptoTotal: asignacionConcepto.flagPlanViajeConceptoTotal
			};
			rendicionTable.jqGrid("addRowData", datarow.secuencial, datarow);
		}
		rendicionTable.trigger("reloadGrid");
	}
}

function showPapeletasDepositoConsultarRendicion(papeletaDepositoArray) {
	
	var depositoTable = $("#tblDeposito");
	depositoTable.clearGridData();
	if (papeletaDepositoArray != null && papeletaDepositoArray.length > 0) {
		for (var i = 0; i < papeletaDepositoArray.length; i++) {
			var papeleta = papeletaDepositoArray[i];
			var datarow = {
				codigoBoletaDeposito: papeleta.codigoBoletaDeposito,
				nombreBanco: papeleta.nombreBanco,
				numeroCuentaBanco: papeleta.numeroCuentaBanco,
				fechaVoucher: papeleta.fechaVoucher,
				numeroOperacion: papeleta.numeroOperacion,
				valorTipoCambio: papeleta.valorTipoCambioFormateado,
				montoDeposito: papeleta.montoDeposito,
				montoDepositoFormateado: papeleta.montoDepositoFormateado,
				reciboIngresoCajaAsosiado: papeleta.reciboIngresoCajaAsosiado,
				flagAsociadoRIC: papeleta.flagAsociadoRIC,
				flagPapeletaTotal: papeleta.flagPapeletaTotal
			};
			depositoTable.jqGrid("addRowData", datarow.codigoBoletaDeposito, datarow);
		}
		depositoTable.trigger("reloadGrid");
	}
}

function showRecibosIngresoCaja(comprobanteIngresoArray) {
	
	var ricTable = $("#tblRIC");
	ricTable.clearGridData();
	if (comprobanteIngresoArray != null && comprobanteIngresoArray.length > 0) {
		for (var i = 0; i < comprobanteIngresoArray.length; i++) {
			var comprobante = comprobanteIngresoArray[i];
			var secuenciaRIC = i + 1;
			var datarow = {
				secuenciaRIC: secuenciaRIC,
				numeroDocumento: comprobante.numeroDocumento,
				fechaGeneracion: comprobante.fechaGeneracionFormateada,
				monto: comprobante.monto,
				montoFormateado: comprobante.montoFormateado,
				clasificador: comprobante.clasificador,
				flagComprobanteTotal: comprobante.flagComprobanteTotal,
				observacion: comprobante.observacion
			};
			ricTable.jqGrid("addRowData", datarow.secuenciaRIC, datarow);
		}
		ricTable.trigger("reloadGrid");
	}
}

$(window).on("resize", function() {
	resizeTable("tblComprobante");
	resizeTable("tblRendicion");
	resizeTable("tblDeposito");
	resizeTable("tblRIC");
	//Inicializando las tablas de los modales
	resizeTable("tblVacaciones");
	resizeTable("tblCompensaciones");
	resizeTable("tblLicencias");
	resizeTable("tblDatosRendicion");
	resizeTable("tblDatosComprobantePago");
	resizeTable("tblAsignacionViatico");
	resizeTable("tblPasajeTasaEmbarque");
});