function initElementsConsultarGastoDetalle(idElementCallModal, codPlanViaje, secuencial, monedaViatico) {
	setInitElementsConsultarGastoDetalle();
	setInitAsignacionViaticoTable(idElementCallModal, monedaViatico);
	setInitPasajeTasaEmbarqueTable(idElementCallModal, monedaViatico);
	callObtenerGastoDetallePorConcepto(codPlanViaje, secuencial, monedaViatico);
}

function setInitElementsConsultarGastoDetalle() {
	addEventElement("btnCerrarConsultarGastoDetalle", "click", clickBtnCerrarConsultarGastoDetalle);
}

function removeEventElementsConsultarGastoDetalle() {
	removeAllEventsElement("btnCerrarConsultarGastoDetalle");
}

function removeAsignacionViaticoTable() {
	var htmlElement = "<table id=\"tblAsignacionViatico\"></table>";
	htmlElement += "<div id=\"divAsignacionViaticoPagerTable\" class=\"jqGridViaticoPagerClass jqGridViaticoWithoutPagerClass\"></div>";
	setHtmlElement("divAsignacionViaticoTable", htmlElement);
}

function removePasajeTasaEmbarqueTable() {
	var htmlElement = "<table id=\"tblPasajeTasaEmbarque\"></table>";
	htmlElement += "<div id=\"divPasajeTasaEmbarquePagerTable\" class=\"jqGridViaticoPagerClass jqGridViaticoWithoutPagerClass\"></div>";
	setHtmlElement("divPasajeTasaEmbarqueTable", htmlElement);
}

function setInitAsignacionViaticoTable(idElementCallModal, monedaViatico) {
	var asignacionViaticoTable = $("#tblAsignacionViatico");
	if (asignacionViaticoTable) {
		var asignacionViaticoTableDiv = $("#" + idElementCallModal);
		var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.viaticoModalConsultarDetalleContainer", ".viaticoModalConsultarDetalleContainerAuxiliar", "width"))/100);
		var widthTable = factorRedimensionamiento*asignacionViaticoTableDiv.width();
		asignacionViaticoTable.jqGrid({
			width: widthTable,
			height: 100,
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Secuencia",
				"Fecha",
				"Alimentación",
				"Hospedaje",
				"Movilidad",
				"Traslado",
				"Total " + monedaViatico,
				"Flag Plan Viaje Informe Distrib Total"
			],
			colModel: [
				{name: "secuencia", index: "secuencia", width: (1*widthTable/20), hidden: true},
				{name: "fecViatico", index: "fecViatico", width: (4*widthTable/20), align: "center"},
				{name: "montoAlimentacion", index: "montoAlimentacion", width: (3*widthTable/20), align: "right"},
				{name: "montoHospedaje", index: "montoHospedaje", width: (3*widthTable/20), align: "right"},
				{name: "montoMovilidad", index: "montoMovilidad", width: (3*widthTable/20), align: "right"},
				{name: "montoTraslado", index: "montoTraslado", width: (3*widthTable/20), align: "right"},
				{name: "montoTotal", index: "montoTotal", width: (4*widthTable/20), align: "right"},
				{name: "flagPlanViajeInformeDistribTotal", index: "flagPlanViajeInformeDistribTotal", width: (1*widthTable/20), hidden: true}
			],
			rowattr: function(dataTable) {
				if (dataTable.flagPlanViajeInformeDistribTotal == "1") {
					return {"class": "bolderFontTableClass"};
				}
			},
			caption: "Asignación por Viáticos",
			pager: "#divAsignacionViaticoPagerTable",
			loadui: "disable"
		});
	}
}

function setInitPasajeTasaEmbarqueTable(idElementCallModal, monedaViatico) {
	var pasajeTasaEmbarqueTable = $("#tblPasajeTasaEmbarque");
	if (pasajeTasaEmbarqueTable) {
		var pasajeTasaEmbarqueTableDiv = $("#" + idElementCallModal);
		var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.viaticoModalConsultarDetalleContainer", ".viaticoModalConsultarDetalleContainerAuxiliar", "width"))/100);
		var widthTable = factorRedimensionamiento*pasajeTasaEmbarqueTableDiv.width();
		pasajeTasaEmbarqueTable.jqGrid({
			width: widthTable,
			height: 100,
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Secuencia",
				"Fecha",
				"Pasaje",
				"TUUA",
				"Total " + monedaViatico,
				"Flag Plan Viaje Informe Distrib Total"
			],
			colModel: [
				{name: "secuencia", index: "secuencia", width: (1*widthTable/20), hidden: true},
				{name: "fecViatico", index: "fecViatico", width: (4*widthTable/20), align: "center"},
				{name: "montoPasaje", index: "montoPasaje", width: (6*widthTable/20), align: "right"},
				{name: "montoTUUA", index: "montoTUUA", width: (6*widthTable/20), align: "right"},
				{name: "montoTotal", index: "montoTotal", width: (4*widthTable/20), align: "right"},
				{name: "flagPlanViajeInformeDistribTotal", index: "flagPlanViajeInformeDistribTotal", width: (1*widthTable/20), hidden: true}
			],
			rowattr: function(dataTable) {
				if (dataTable.flagPlanViajeInformeDistribTotal == "1") {
					return {"class": "bolderFontTableClass"};
				}
			},
			caption: "Pasaje y Tasa Embarque",
			pager: "#divPasajeTasaEmbarquePagerTable",
			loadui: "disable"
		});
	}
}

function clickBtnCerrarConsultarGastoDetalle() {
	removeEventElementsConsultarGastoDetalle();
	removeAsignacionViaticoTable();
	removePasajeTasaEmbarqueTable();
	hideModalElement("divConsultarGastoDetalle");
}

function callObtenerGastoDetallePorConcepto(codPlanViaje, secuencial, monedaViatico) {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/registrarRendicion.htm?action=obtenerGastoDetallePorConcepto",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"planViajeId": codPlanViaje,
				"secuencial": secuencial,
				"simboloMoneda": monedaViatico
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showElement("divLoadingConsultarRendicionDetalle");
			},
			complete: function() {
				hideElement("divLoadingConsultarRendicionDetalle");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var codigoConsulta = result.codigoConsulta;
				var errorMessage = result.errorMessage;
				if (codigoConsulta != null && codigoConsulta == "00") {
					var rendicionVO = result.rendicionVO;
					var asignacionViaticoList = rendicionVO.asignacionViaticoList;
					var pasajeTasaEmbarqueList = rendicionVO.pasajeTasaEmbarqueList;
					showAsignacionViatico(asignacionViaticoList);
					showPasajeTasaEmbarque(pasajeTasaEmbarqueList);
				}
				else {
					//showMensajeConfirmacionAplicativoWithoutBody("divMensajeConfirmacionErrorRegistrarMofificarRendicion", "divTituloPanelMensajeConfirmacionErrorRegistrarMofificarRendicion", "divBodyPanelMensajeConfirmacionErrorRegistrarMofificarRendicion", errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callObtenerPlanViajeDetalle");
			}
		});
	}, 500);
}

function showAsignacionViatico(asignacionViaticoArray) {
	
	var asignacionViaticoTable = $("#tblAsignacionViatico");
	asignacionViaticoTable.clearGridData();
	if (asignacionViaticoArray != null && asignacionViaticoArray.length > 0) {
		for (var i = 0; i < asignacionViaticoArray.length; i++) {
			var asignacionViatico = asignacionViaticoArray[i];
			var secuencia = i + 1;
			var datarow = {
				secuencia: secuencia,
				fecViatico: asignacionViatico.fecViaticoFormateada,
				montoAlimentacion: asignacionViatico.montoAlimentacionFormateado,
				montoHospedaje: asignacionViatico.montoHospedajeFormateado,
				montoMovilidad: asignacionViatico.montoMovilidadFormateado,
				montoTraslado: asignacionViatico.montoTrasladoFormateado,
				montoTotal: asignacionViatico.montoTotalFormateado,
				flagPlanViajeInformeDistribTotal: asignacionViatico.flagPlanViajeInformeDistribTotal
			};
			asignacionViaticoTable.jqGrid("addRowData", datarow.secuencia, datarow);
		}
		asignacionViaticoTable.trigger("reloadGrid");
	}
	else {
		setHtmlElement("divAsignacionViaticoPagerTable_left", errorMessageConsultarGastoDetalle.sinRegistrosBusqueda);
	}
	triggerResizeEventSlow();
}

function showPasajeTasaEmbarque(pasajeTasaEmbarqueArray) {
	
	var pasajeTasaEmbarqueTable = $("#tblPasajeTasaEmbarque");
	pasajeTasaEmbarqueTable.clearGridData();
	if (pasajeTasaEmbarqueArray != null && pasajeTasaEmbarqueArray.length > 0) {
		for (var i = 0; i < pasajeTasaEmbarqueArray.length; i++) {
			var pasajeTasaEmbarque = pasajeTasaEmbarqueArray[i];
			var secuencia = i + 1;
			var datarow = {
				secuencia: secuencia,
				fecViatico: pasajeTasaEmbarque.fecViaticoFormateada,
				montoPasaje: pasajeTasaEmbarque.montoPasajeFormateado,
				montoTUUA: pasajeTasaEmbarque.montoTUUAFormateado,
				montoTotal: pasajeTasaEmbarque.montoTotalFormateado,
				flagPlanViajeInformeDistribTotal: pasajeTasaEmbarque.flagPlanViajeInformeDistribTotal
			};
			pasajeTasaEmbarqueTable.jqGrid("addRowData", datarow.secuencia, datarow);
		}
		pasajeTasaEmbarqueTable.trigger("reloadGrid");
	}
	else {
		setHtmlElement("divPasajeTasaEmbarquePagerTable_left", errorMessageConsultarGastoDetalle.sinRegistrosBusqueda);
	}
	triggerResizeEventSlow();
}