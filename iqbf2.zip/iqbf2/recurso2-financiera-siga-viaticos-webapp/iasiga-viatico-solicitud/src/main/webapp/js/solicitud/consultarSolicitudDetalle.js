function initElementsConsultarSolicitudDetalle(idElementCallModal, codPlanViaje, tipoDestino,indicadorHoras) {
	setInitElementsConsultarSolicitudDetalle();
	setInitDetalleViaticoTable(idElementCallModal,tipoDestino,indicadorHoras);
	setInitDetalleGastoTable(idElementCallModal);
	callObtenerPlanViajeDetalleBandejaSolicitud(codPlanViaje,indicadorHoras);
}

function setInitElementsConsultarSolicitudDetalle() {
	
	setValueInputText("txtNumeroPlanillaConsultarSolicitudDetalle", "");
	setValueInputText("txtNombreColaboradorConsultarSolicitudDetalle", "");
	addEventElement("btnCerrarConsultarSolicitudDetalle", "click", clickBtnCerrarConsultarSolicitudDetalle);
}

function removeEventElementsConsultarSolicitudDetalle() {
	removeAllEventsElement("btnCerrarConsultarSolicitudDetalle");
}

function removeDetalleViaticoTable() {
	var htmlElement = "<table id=\"tblDetalleViatico\"></table>";
	setHtmlElement("divDetalleViaticoTable", htmlElement);
}

function removeDetalleGastoTable() {
	var htmlElement = "<table id=\"tblDetalleGasto\"></table>";
	setHtmlElement("divDetalleGastoTable", htmlElement);
}

function setInitDetalleViaticoTable(idElementCallModal,tipoDestino,indicadorHoras) {
	var detalleViaticoTable = $("#tblDetalleViatico");
	if (detalleViaticoTable) {
		var detalleViaticoTableDiv = $("#" + idElementCallModal);
		var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.viaticoModalConsultarDetalleContainer", ".viaticoModalConsultarDetalleContainerAuxiliar", "width"))/100);
		var widthTable = factorRedimensionamiento*detalleViaticoTableDiv.width();
		detalleViaticoTable.jqGrid({
			width: widthTable,
			height: 40,
			datatype: "local",
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Código Plan Viaje",
				"UUOO Comisionado",
				"Itinerario",
				(tipoDestino=='01'?"Fecha de Salida":"Fecha Ini. Evento"),
				(tipoDestino=='01'?"Fecha de Retorno":"Fecha Ter. Evento"),
				(indicadorHoras=='1'?"Total Horas de la Comisión":"Total Días de la Comisión"),
				"Motivo de la Comisión",
				"Autorizador de Gasto",
				"Nombre del Registrador"
			],
			colModel: [
				{name: "codPlanViaje", index: "codPlanViaje", width: (1*widthTable/20), fixed: true, hidden: true},
				{name: "nomUuOoCom", index: "nomUuOoCom", width: (6*widthTable/20), fixed: true},
				{name: "itinerario", index: "itinerario", width: (6*widthTable/20), fixed: true},
				{name: "fecSalida", index: "fecSalida", width: (2*widthTable/20), fixed: true, align: "center"},
				{name: "fecRetorno", index: "fecRetorno", width: (2*widthTable/20), fixed: true, align: "center"},
				{name: "numDias", index: "numDias", width: (2*widthTable/20), fixed: true, align: "center"},
				{name: "motivoComis", index: "motivoComis", width: (6*widthTable/20), fixed: true},
				{name: "nomAutorizador", index: "nomAutorizador", width: (5*widthTable/20), fixed: true},
				{name: "nomRegistrador", index: "nomRegistrador", width: (5*widthTable/20), fixed: true}
			],
			caption: "Detalle de Comisión"
		});
	}
}

function setInitDetalleGastoTable(idElementCallModal) {
	var detalleGastoTable = $("#tblDetalleGasto");
	if (detalleGastoTable) {
		var detalleGastoTableDiv = $("#" + idElementCallModal);
		var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.viaticoModalConsultarDetalleContainer", ".viaticoModalConsultarDetalleContainerAuxiliar", "width"))/100);
		var widthTable = factorRedimensionamiento*detalleGastoTableDiv.width();
		detalleGastoTable.jqGrid({
			width: widthTable,
			height: 40,
			datatype: "local",
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Código Plan Viaje",
				"Asignación de Viáticos",
				"Pasajes",
				"Otros",
				"Total Otorgado",
				"Medio de Pago",
				"Nro. Recibo Provisional",
				"Fecha Pago Caja Ch."
			],
			colModel: [
				{name: "codPlanViaje", index: "codPlanViaje", width: (1*widthTable/20), fixed: true, hidden: true},
				{name: "impAsigViatico", index: "impAsigViatico", width: (3*widthTable/20), fixed: true, align: "right"},
				{name: "impAsigPasajes", index: "impAsigPasajes", width: (3*widthTable/20), fixed: true, align: "right"},
				{name: "impOtros", index: "impOtros", width: (3*widthTable/20), fixed: true, align: "right"},
				{name: "impTotalOtorgado", index: "impTotalOtorgado", width: (3*widthTable/20), fixed: true, align: "right"},
				{name: "medioPago", index: "medioPago", width: (3*widthTable/20), fixed: true},
				{name: "numReciboProv", index: "numReciboProv", width: (3*widthTable/20), fixed: true},
				{name: "fecPagoCajaCh", index: "fecPagoCajaCh", width: (3*widthTable/20), fixed: true, align: "center"}
			],
			caption: "&nbsp;"
		});
	}
}

function clickBtnCerrarConsultarSolicitudDetalle() {
	removeEventElementsConsultarSolicitudDetalle();
	removeDetalleViaticoTable();
	removeDetalleGastoTable();
	hideModalElement("divConsultarSolicitudDetalle");
}

function callObtenerPlanViajeDetalleBandejaSolicitud(codPlanViaje,indicadorHoras) {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/solicitud.htm?action=obtenerPlanViajeDetalleBandejaSolicitud",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codPlanViaje": codPlanViaje
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showElement("divLoadingConsultarSolicitudDetalle");
			},
			complete: function() {
				hideElement("divLoadingConsultarSolicitudDetalle");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var codigoConsulta = result.codigoConsulta;
				var errorMessage = result.errorMessage;
				if (codigoConsulta != null && codigoConsulta == "00") {
					
					var planViaje = result.planViajeBean;
					var detalleViaticoTable = $("#tblDetalleViatico");
					detalleViaticoTable.clearGridData();
					var detalleGastoTable = $("#tblDetalleGasto");
					detalleGastoTable.clearGridData();
					setValueInputText("txtNumeroPlanillaConsultarSolicitudDetalle", planViaje.codPlanilla);
					setValueInputText("txtNombreColaboradorConsultarSolicitudDetalle", planViaje.nomColaborador);
					var datarow = {
						codPlanViaje: planViaje.codPlanViaje,
						nomUuOoCom: planViaje.nomUuOoCom,
						itinerario: planViaje.itinerario,
						fecSalida: planViaje.fecSalidaFormateada,
						fecRetorno: planViaje.fecRetornoFormateada,
						numDias: (indicadorHoras=='1'?planViaje.numeroHoras:planViaje.numDias),
						motivoComis: planViaje.motivoComis,
						nomAutorizador: planViaje.nomAutorizador,
						nomRegistrador: planViaje.nomRegistrador,
						impAsigViatico: planViaje.impAsigViaticoFormateado,
						impAsigPasajes: planViaje.impAsigPasajesFormateado,
						impOtros: planViaje.impOtrosFormateado,
						impTotalOtorgado: planViaje.impTotalOtorgadoFormateado,
						medioPago: planViaje.medioPago,
						numReciboProv: planViaje.numReciboProv,
						fecPagoCajaCh: planViaje.fecPagoCajaChFormateado
					};
					detalleViaticoTable.jqGrid("addRowData", datarow.codPlanViaje, datarow);
					detalleViaticoTable.trigger("reloadGrid");
					detalleGastoTable.jqGrid("addRowData", datarow.codPlanViaje, datarow);
					detalleGastoTable.trigger("reloadGrid");
					triggerResizeEventSlow();
				}
				else {
					//showMensajeConfirmacionAplicativoWithoutBody("divMensajeConfirmacionErrorRegistrarMofificarRendicion", "divTituloPanelMensajeConfirmacionErrorRegistrarMofificarRendicion", "divBodyPanelMensajeConfirmacionErrorRegistrarMofificarRendicion", errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callObtenerPlanViajeDetalleBandejaSolicitud");
			}
		});
	}, 500);
}