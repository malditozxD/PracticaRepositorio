function initElementsSolicitud(flagPerfilRegistrador) {	
	setFechas()
	setInitSolicitudTable();
	setInitElementsBandejaSolicitud(flagPerfilRegistrador);
	getInitDetalleBandejaSolicitud();
	$.blockUI.defaults.baseZ = 4000;
	$(document).ajaxStop($.unblockUI);
}

function setInitElementsBandejaSolicitud(flagPerfilRegistrador) {
	addEventElement("btnBuscarRegistro", "click", clickBtnBuscarRegistro);
	addEventElement("btnBuscarUUOO", "click", clickBtnBuscarUUOO);
	addEventElement("btnConsultarSolicitud", "click", clickBtnConsultarSolicitud);
	addEventElement("btnExpExcel", "click",clickBtnExpExcel);
	addEventElement("SelAnnio", "change", setFechas);
}

function setFechas() {
	var annio = $("#SelAnnio");
	var fecDesde = "01/01/"+annio.val();
	var fecHasta = "31/12/"+annio.val();
	
	var fecFinal = "2999/12/31";
	
	var xfecDesde= annio.val()+"/01/01";
	var xfecHasta =annio.val()+"/12/31";
	
	//initDateTimePickerWithDefaultMinDateMaxDate("txtDesde", "dp.change", changeDateEtiquetaFechaDesdeDiv, fecFinal, "0000/01/01", fecFinal);
	//initDateTimePickerWithDefaultMinDateMaxDate("txtHasta", "dp.change", changeDateEtiquetaFechaHastaDiv, fecFinal, "0000/01/01", fecFinal);
	//$('#txtDesdeDiv').datetimepicker( {dateFormat: 'dd/mm/yy', minDate:new Date(2015,1-1,31) , maxDate:new Date(2015,12-1,31)});
	
	
	initDateTimePickerWithDefaultMinDateMaxDate("txtDesdeDiv", "dp.change", changeDateEtiquetaFechaDesdeDiv, fecFinal, "0000/01/01", fecFinal);
	initDateTimePickerWithDefaultMinDateMaxDate("txtHastaDiv", "dp.change", changeDateEtiquetaFechaHastaDiv, fecFinal, "0000/01/01", fecFinal);
	
//	initDateTimePickerWithDefaultMinDateMaxDate("txtDesdeDiv", "dp.change", "changeDate", changeDateEtiquetaFechaDesdeDiv, xfecHasta, xfecDesde, xfecHasta,fecDesde,fecHasta);
//	initDateTimePickerWithDefaultMinDateMaxDate("txtHastaDiv", "dp.change", "changeDate", changeDateEtiquetaFechaHastaDiv, xfecHasta, xfecDesde, xfecHasta,fecDesde,fecHasta);
	
	
	//$('#txtDesdeDiv').datetimepicker({defaultDate: "fecDesde",disabledDates: [moment("12/25/2013"),new Date(2013, 11 - 1, 21),"11/22/2013 00:53"]});
	//$('#txtDesdeDiv').datetimepicker( { minDate:new Date(2015,1-1,1) , maxDate:new Date(2015,12-1,31)});
	//$('#txtDesdeDiv').datetimepicker( { locale: "es"});
	//$('#txtDesdeDiv').datetimepicker( { minDate:new Date(2015,1-1,1)});
	//$('#txtDesdeDiv').datetimepicker( { format: "DD/MM/YYYY"});
	//$('#txtDesdeDiv').datetimepicker( { defaultDate: "31/12/2015"});	
	//$('#txtDesdeDiv').datetimepicker( { minDate: "2015/01/15"});
	$("#txtDesde").val(fecDesde);
	$("#txtHasta").val(fecHasta);
}

function changeDateEtiquetaFechaDesdeDiv(element) {
	//console.log("changeDateEtiquetaFechaDesdeDiv");
}

function changeDateEtiquetaFechaHastaDiv(element) {
	//console.log("changeDateEtiquetaFechaHastaDiv");
}

function setInitSolicitudTable() {
	var solicitudTable = $("#tblBandejaSolicitud");
	if (solicitudTable) {
		var solicitudTableDiv = $("#divBandejaSolicitudTable");
		var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.viaticoModalContainer", ".viaticoModalContainerAuxiliar", "width"))/100);
		var widthTable = factorRedimensionamiento*solicitudTableDiv.width();
		//var widthTable = solicitudTableDiv.width();
		solicitudTable.jqGrid({
			width: widthTable,
			height: 230,			
			autowidth: true,
			datatype : "local",
			cmTemplate: { sortable: true },
			colNames:['Nro Planilla','Fecha de Registro','Nombre Colaborador','Tipo de Viaticos','Total Otorgado','Canal de Atenci&oacute;n','Plazo para rendir','Estado Planilla', '','','','Acci&oacute;n','','','','','','',''],
			colModel:[
						{name:'codPlanilla',index:'codPlanilla', width:(0.7*widthTable/12),formatter:formatterVerPlanilla},
						{name:'fecRegistro',index:'fecRegistro',width:(0.5*widthTable/12),align:'center'},
						{name:'nomColaborador',index:'nomColaborador', width:(1.2*widthTable/12)},
						{name:'nomTipoViatico',index:'nomTipoViatico', width:(0.7*widthTable/12),align: 'center'},
						{name:'mtoTotal',index:'mtoTotal', width:(0.6*widthTable/12),align:'right'},
						{name:'canalAtencion',index:'canalAtencion', width:(0.8*widthTable/12),align:'right'},
						{name:'fecMaxRend',index:'fecMaxRend', width:(0.8*widthTable/12),align: 'center'},
						{name:'nomEstSolic',index:'nomEstSolic', width:(0.7*widthTable/12),align:'center',formatter:formatterVerEstado},
						{name:'autorizar',index:'autorizar', width:(0.4*widthTable/12),align:'center',formatter:formatterVerAutorizar},
						{name:'observar',index:'observar', width:(0.4*widthTable/12),align:'center',formatter:formatterVerObservar},
						{name:'anular',index:'anular', width:(0.3*widthTable/12),align:'center',formatter:formatterVerAnular},
						{name:'detalle',index:'detalle', width:(0.4*widthTable/12),align:'center',formatter:formatterVerDetalle},
						{name:'seguimiento',index:'seguimiento', width:(0.5*widthTable/12),align:'center',formatter:formatterVerSeguimiento},
						{name:'ver',index:'ver', width:(0.2*widthTable/12),align:'center',formatter:formatterVerArchivo},
						{name:'codPlanViaje',index:'codPlanViaje', width:(0.1*widthTable/12),hidden: true}, 
						{name:'codPlanillaSl',key: true,index:'codPlanillaSl', width:(0.1*widthTable/12),hidden: true},
						{name:'numArchivo',index:'numArchivo', width:(0.1*widthTable/12),hidden: true},
						{name:'numExpSolic', index:'numExpSolic', width:(0.1*widthTable/12), hidden: true},
						{name:'obsSolicitud', index:'obsSolicitud', width:(0.1*widthTable/12), hidden: true}
					],
				viewrecords : true,
				//loadtext:'Buscando...',
				loadui:'disable',
			 	recordpos:'left',
				pagerpos:'center',
				//altRows: true,
				multiselect: false,
		        multiboxonly: true,
		        headertitles: true,
		        hidegrid: false,
				rowNum:10,
				rowList:[10,20,30],
				rownumbers : true,
				idPrefix : "filaxxx_",
			pager : "#divBandejaSolicitudPagerTable",
			caption: " ",
			cellattr: function (rowId, cellValue, rowObject) { return ' title="Here is my tooltip on colCell!"'; },
			loadComplete : function( ) {
				var ids = solicitudTable.jqGrid('getDataIDs');
				for (var i = 0; i < ids.length; i++) 
				{
				    var rowId = ids[i];
				    var rowData = solicitudTable.jqGrid ('getRowData', rowId);
//				    if (rowData.cantDiasRend == null || rowData.cantDiasRend.trim() == "") {  
//				   //
//				    }
//				    else {
//				    	if (parseInt(rowData.cantDiasRend) < 0) {
//						    	solicitudTable.jqGrid('setCell',rowId,"cantDiasRend","",{'background-color':'red','color':'white','background-image':'none'});
//						    } else 
//						    	{solicitudTable.jqGrid('setCell',rowId,"cantDiasRend","",{'background-color':'green','color':'white','background-image':'none'});}
//				    }
				}
			} 
		});
	}
}

var formatterVerPlanilla = function(cellvalue, options, rowObject) {
    var codPlanilla = rowObject.codPlanilla;
    return "<a class=\"jqGridViaticoLinkClass\" href=\"javascript:clickBtnConsultaPlanilla('"+codPlanilla+"')\">"+codPlanilla+"</a>"; 
}

var formatterVerEstado = function(cellvalue, options, rowObject) {
    var nomEstSolic = isNullValue(rowObject.nomEstSolic);
    var obsSolicitud  = isNullValue(rowObject.obsSolicitud); 
    if (nomEstSolic=='Observado') { 
    	return "<a title=\""+ obsSolicitud +"\">"+nomEstSolic+"<\/a>";
    } else 	{
    	return "<a title=\""+ nomEstSolic +"\">"+nomEstSolic+"<\/a>";
    }
}

var formatterVerDetalle = function(cellvalue, options, rowObject) {
    var codPlanViaje = rowObject.codPlanViaje;
    var nomTipoViatico = rowObject.nomTipoViatico;
    var codPlanilla = rowObject.codPlanilla;
    var nomColaborador = rowObject.nomColaborador;
    return "<a class=\"jqGridViaticoLinkClass\" href=\"javascript:clickVerDetalle('"+codPlanViaje+"','"+nomTipoViatico+"','"+codPlanilla+"','"+nomColaborador+"')\">Detalle</a>"; 
}

function isNullValue(varEvaluar){
	if(varEvaluar == undefined  && $.trim(varEvaluar) == "")
		varEvaluar = " ";	
	return varEvaluar;
}

var contadorNumSeguimiento = 0;
var formatterVerSeguimiento = function (cellvalue, options, rowObject){
	var numExpSolic = rowObject.numExpSolic;
	var numRegistro = $("#txtNroRegistro").val();
	var nomColaborador = rowObject.nomColaborador;
	var nomDependencia = $("#txtUUOODetalle").val();
	var codPlanilla = rowObject.codPlanilla;
	var importe = rowObject.mtoTotal;
	var codUUOO = $("#txtUUOO").val();
	numExpSolic = isNullValue(numExpSolic);
	numRegistro = isNullValue(numRegistro);
	nomColaborador = isNullValue(nomColaborador);
	nomDependencia = isNullValue(nomDependencia);
	codPlanilla = isNullValue(codPlanilla);
	importe = isNullValue(importe);
	codUUOO = isNullValue(codUUOO);
		 
//	if ( $.trim(numExpSolic) != "" && numExpSolic != undefined && $.trim(numExpSolic) != "-1" ){			 
    	return "<a class=\"jqGridViaticoLinkClass\" href=\"javascript:clickVerSeguimiento('"+numExpSolic+"','"+numRegistro+"','"+nomColaborador+"','"+nomDependencia+"','"+codPlanilla+"','"+importe+"','"+codUUOO+"');\">Seguimiento</a>";
//	} else { 
//		return " ";
//	}
}

var formatterVerAutorizar = function (cellvalue, options, rowObject){
	var nomEstSolic = rowObject.nomEstSolic;
	var numRegistro = $("#txtNroRegistro").val();
	var nomColaborador = rowObject.nomColaborador;
	var nomDependencia = $("#txtUUOODetalle").val();
	var codPlanilla = rowObject.codPlanilla;
	var importe = rowObject.mtoTotal;
	var codUUOO = $("#txtUUOO").val();
	nomEstSolic = isNullValue(nomEstSolic);
	numRegistro = isNullValue(numRegistro);
	nomColaborador = isNullValue(nomColaborador);
	nomDependencia = isNullValue(nomDependencia);
	codPlanilla = isNullValue(codPlanilla);
	importe = isNullValue(importe);
	codUUOO = isNullValue(codUUOO);
	if ( $.trim(nomEstSolic) != "" && nomEstSolic != undefined && $.trim(nomEstSolic) != "Anulado" && $.trim(nomEstSolic) != "Observado" && $.trim(nomEstSolic) != "Autorizado"){			 
		return "<a class=\"jqGridViaticoLinkClass\" href=\"javascript:void(0)\" onClick=\"javascript:clickVerAutorizar('"+numRegistro+"','"+nomColaborador+"','"+nomDependencia+"','"+codPlanilla+"','"+importe+"','"+codUUOO+"');\">Autorizar</a>";
	} else { 
		return " ";
	}
}

var formatterVerObservar = function (cellvalue, options, rowObject){
	var nomEstSolic = rowObject.nomEstSolic;
	var numRegistro = $("#txtNroRegistro").val();
	var nomColaborador = rowObject.nomColaborador;
	var nomDependencia = $("#txtUUOODetalle").val();
	var codPlanilla = rowObject.codPlanilla;
	var importe = rowObject.mtoTotal;
	var codUUOO = $("#txtUUOO").val();
	nomEstSolic = isNullValue(nomEstSolic);
	numRegistro = isNullValue(numRegistro);
	nomColaborador = isNullValue(nomColaborador);
	nomDependencia = isNullValue(nomDependencia);
	codPlanilla = isNullValue(codPlanilla);
	importe = isNullValue(importe);
	codUUOO = isNullValue(codUUOO);
	if ( $.trim(nomEstSolic) != "" && nomEstSolic != undefined && $.trim(nomEstSolic) != "Anulado" && $.trim(nomEstSolic) != "Observado"){			 
		return "<a class=\"jqGridViaticoLinkClass\" href=\"javascript:clickVerObservar('"+numRegistro+"','"+nomColaborador+"','"+nomDependencia+"','"+codPlanilla+"','"+importe+"','"+codUUOO+"');\">Observar</a>";
	} else { 
		return " ";
	}
}

var formatterVerAnular = function (cellvalue, options, rowObject){
	var nomEstSolic = rowObject.nomEstSolic;
	var numRegistro = $("#txtNroRegistro").val();
	var nomColaborador = rowObject.nomColaborador;
	var nomDependencia = $("#txtUUOODetalle").val();
	var codPlanilla = rowObject.codPlanilla;
	var importe = rowObject.mtoTotal;
	var codUUOO = $("#txtUUOO").val();
	nomEstSolic = isNullValue(nomEstSolic);
	numRegistro = isNullValue(numRegistro);
	nomColaborador = isNullValue(nomColaborador);
	nomDependencia = isNullValue(nomDependencia);
	codPlanilla = isNullValue(codPlanilla);
	importe = isNullValue(importe);
	codUUOO = isNullValue(codUUOO);
	if ( $.trim(nomEstSolic) != "" && nomEstSolic != undefined && $.trim(nomEstSolic) != "Anulado" ){			 
		return "<a class=\"jqGridViaticoLinkClass\" href=\"javascript:clickVerAnular('"+numRegistro+"','"+nomColaborador+"','"+nomDependencia+"','"+codPlanilla+"','"+importe+"','"+codUUOO+"');\">Anular</a>";
	} else { 
		return " ";
	}
}
	
var formatterVerArchivo = function (cellvalue, options, rowObject){
	var numArchivo = rowObject.numArchivo;
	var codPlanViaje = rowObject.codPlanViaje;
	numArchivo = isNullValue(numArchivo);
	codPlanViaje = isNullValue(codPlanViaje);
	//agregado
	var numRegistro = $("#txtNroRegistro").val();
	var nomColaborador = rowObject.nomColaborador;
    var nomDependencia = $("#txtUUOODetalle").val();
    var codPlanilla = rowObject.codPlanilla; 
	var importe = rowObject.mtoTotal;
	var codUUOO = $("#txtUUOO").val()
	numRegistro = isNullValue(numRegistro);
	nomColaborador = isNullValue(nomColaborador);
	nomDependencia = isNullValue(nomDependencia);
	codPlanilla = isNullValue(codPlanilla);
	importe = isNullValue(importe);
	codUUOO = isNullValue(codUUOO);
	
//	if ($.trim(numArchivo) != "" && $.trim(numArchivo) != undefined ){
    	return "<a class=\"jqGridViaticoLinkClass\" href=\"javascript:clickVerArchivo('"+numArchivo+"','"+codPlanViaje+"','"+numRegistro+"','"+nomColaborador+"','"+nomDependencia+"','"+codPlanilla+"','"+importe+"','"+codUUOO+"');\">Ver</a>"; 
//	}
//    else { 
//    	return "";
//    }
}

function clickVerAutorizar(numRegistro,nomColaborador,nomDependencia,codPlanilla,importe,codUUOO){
	initElementsMotivoAutorizacionSolicitud(numRegistro,nomColaborador,nomDependencia,codPlanilla,importe,codUUOO);
	$("#divMotivoAutorizacionSolicitud").modal("show");
	$('#divMensajeConfirmacionFinalizarAutorizacion').modal('show');
	triggerResizeEvent();
}

function clickVerObservar(numRegistro,nomColaborador,nomDependencia,codPlanilla,importe,codUUOO){
	initElementsMotivoObservacionSolicitud(numRegistro,nomColaborador,nomDependencia,codPlanilla,importe,codUUOO);
	$("#divMotivoObservacionSolicitud").modal("show");
	triggerResizeEvent();
}

function clickVerAnular(numRegistro,nomColaborador,nomDependencia,codPlanilla,importe,codUUOO){
	initElementsMotivoAnulacionSolicitud(numRegistro,nomColaborador,nomDependencia,codPlanilla,importe,codUUOO);
	$("#divMotivoAnulacionSolicitud").modal("show");
	triggerResizeEvent();
}

function clickVerDetalle(codPlanViaje,nomTipoViatico,codPlanilla,nomColaborador) {
	initElementsDetalleSolicitud("divDetalleTableSolicitud",codPlanViaje,nomTipoViatico,codPlanilla,nomColaborador);
	$("#divConsultarDetalleSolicitud").modal("show");
	triggerResizeEvent();
}

function clickVerSeguimiento(numExpSolic,numRegistro,nomColaborador,nomDependencia,codPlanilla,importe,codUUOO){
	initElementsSeguimiento(numExpSolic,numRegistro,nomColaborador,nomDependencia,codPlanilla,importe,codUUOO);
	$("#divConsultarSeguimiento").modal("show");
	triggerResizeEvent();
}

function clickVerArchivo(numArchivo, codPlanViaje,numRegistro,nomColaborador,nomDependencia,codPlanilla,importe,codUUOO){
	initElementsArchivo(numArchivo,codPlanViaje,numRegistro,nomColaborador,nomDependencia,codPlanilla,importe,codUUOO);
	$("#divConsultarArchivo").modal("show");
	triggerResizeEvent();
}

function clickBtnConsultarSolicitud(){
	getInitDetalleBandejaSolicitud();	
}

function clickBtnConsultaPlanilla(codPlanilla){
	
	// si el usuario que ingresa a session es registrador
	var esRegistrador = toNumero( getTrimValue('#hidFlagRegistrador') ) > 0;	
	
	// mostrar popup consultar solicitud
	initElementsConsultarSolicitud( codPlanilla);	
	showModalElement( 'divConsultarSolicitudModal' );
	triggerResizeEvent();	
}

function clickBtnBuscarUUOO() {
	var flagLimpiarDatosColaboradorBuscarUUOO = true;
	initElementsBuscarUUOO("divBandejaSolicitudTable", flagLimpiarDatosColaboradorBuscarUUOO);
	$("#divBuscarUUOO").modal("show");
}

function clickBtnBuscarRegistro() {
	var flagAsociarUUOOBuscarColaborador = false;
	initElementsBuscarColaborador("divBandejaSolicitudTable",flagAsociarUUOOBuscarColaborador);
	$("#divBuscarColaborador").modal("show");
}

function clickBtnExpExcel(){
		var codUUOO = $("#txtUUOO").val();
		var numRegistro = $("#txtNroRegistro").val();
		var nomColaborador = $("#txtNombreColaborador").val();
		var nomDependencia = $("#txtUUOODetalle").val();
		var codDependencia = $("#hidCodigoDependencia").val();	 
		var codColaborador = $("#hidCodigoColaborador").val();  
		var codRegistrador = $("#hidCodigoRegistrador").val(); 
		var codEstado = $("#SelCodEstado").val();
		var estado = $("#SelCodEstado option:selected").text();
		var codCanal = $("#SelCodCanal").val();
		var fechaDesde = $("#txtDesde").val();
		var fechaHasta = $("#txtHasta").val();
		var numPlanilla = $("#txtNumPlanilla").val();
		var anio = $("#SelAnnio option:selected").text();
		var canal = $("#SelCodCanal option:selected").text();
		
		var encodeParam = "&codUUOO=" + codUUOO;
		encodeParam += "&numRegistro=" + numRegistro;
		encodeParam += "&nomColaborador=" + nomColaborador;
		encodeParam += "&nomDependencia=" + nomDependencia;
		encodeParam += "&codDependencia=" + codDependencia;
		encodeParam += "&codColaborador=" + codColaborador;
		encodeParam += "&codRegistrador=" + codRegistrador;
		encodeParam += "&codEstado=" + codEstado;
		encodeParam += "&codCanal=" + codCanal;
		encodeParam += "&fechaDesde=" + fechaDesde;
		encodeParam += "&fechaHasta=" + fechaHasta;
		encodeParam += "&numPlanilla=" + numPlanilla;
		encodeParam += "&estado=" + estado;
		encodeParam += "&anio=" + anio;
		encodeParam += "&canal=" + canal;

		var url = contextPathUrl + "/solicitud.htm?action=exportadoExcel"+encodeParam;
		location.href = url;
}

function getInitDetalleBandejaSolicitud(){
		setTimeout(function(){
		var codUUOO = $("#txtUUOO").val();
		var numRegistro = $("#txtNroRegistro").val();
		var nomColaborador = $("#txtNombreColaborador").val();
		var nomDependencia = $("#txtUUOODetalle").val();
		var codDependencia = $("#hidCodigoDependencia").val();	 
		var codColaborador = $("#hidCodigoColaborador").val();  
		var codRegistrador = $("#hidCodigoRegistrador").val(); 
		var codEstado = $("#SelCodEstado").val();
		var codCanal = $("#SelCodCanal").val();
		var fechaDesde = $("#txtDesde").val();
		var fechaHasta = $("#txtHasta").val();
		var numPlanilla = $("#txtNumPlanilla").val();
		var ajax_data = {
				"codUUOO"			:	codUUOO,
				"numRegistro"		:	numRegistro,
				"nomColaborador"	:	nomColaborador,
				"nomDependencia"	:	nomDependencia,
				"codDependencia"	:	codDependencia,
				"codColaborador"	:	codColaborador,
				"codRegistrador"	:	codRegistrador,
				"codEstado"			: 	codEstado,
				"codCanal"			: 	codCanal,
				"fechaDesde"	 	:	fechaDesde,
				"fechaHasta"	 	:	fechaHasta,
				"numPlanilla"	 	:	numPlanilla
			};
	//enviar al control y mostrar el poput de detalle
	$("#tblBandejaSolicitud").jqGrid('clearGridData');	
		
	$.ajax({ 
		data:ajax_data,
		url: contextPathUrl+"/solicitud.htm?action=buscarSolicitudesBandeja",
		type: "post",
		dataType: "json",
		cache: false,
		beforeSend: function() {
			$.blockUI({  message: '<h3>Revisando Solicitudes...</h3> '}); 
	    },
		success: function(respuesta){
					var listSolicitud=respuesta.listSolicitudes;
					for(var i=0;i<listSolicitud.length;i++){
						var solicitud= listSolicitud[i];
						var datarow = {
								codPlanilla:solicitud.codPlanilla,
								fecRegistro:solicitud.fecRegistro,
								nomColaborador:solicitud.nomColaborador,
								nomTipoViatico:solicitud.nomTipoViatico,
								mtoTotal:solicitud.mtoTotal,
								canalAtencion:solicitud.canalAtencion,
								fecMaxRend:solicitud.fecMaxRend, 
								nomEstSolic:solicitud.nomEstSolic, 
								detalle:solicitud.detalle,
								seguimiento:solicitud.seguimiento,
								anular:solicitud.anular,
								ver:solicitud.ver,
								codPlanViaje:solicitud.codPlanViaje,
								numArchivo:solicitud.numArchivo,
								numExpSolic:solicitud.numExpSolic,
								obsSolicitud:solicitud.obsSolicitud
									};
						var su=jQuery("#tblBandejaSolicitud").jqGrid('addRowData',solicitud.codPlanillaSl,datarow);
					}
					$("#tblBandejaSolicitud").trigger("reloadGrid");
		},
		error:function (xhr, ajaxOptions, thrownError) {
		}
	});
	}, 500);
}

/*Inicio Codigo - buscarUUOOInput*/
var buscarUUOOInputBeforeMethod = function() {
	setValueInputText("txtUUOODetalle","");
	setValueInputText("txtNroRegistro","");
	setValueInputText("txtNombreColaborador","");
	$('#txtNroRegistro').attr('disabled', true);
	$('#btnConsultarSolicitud').attr('disabled', true);
	$('#btnExpExcel').attr('disabled', true);
	$('#btnBuscarRegistro').attr('disabled', true);
	$("#tblBandejaSolicitud").jqGrid('clearGridData');
};

var buscarUUOOInputAfterMethod = function(uoList) {
	if (uoList != null && uoList.length > 0) {
		for (var i = 0; i < uoList.length; i++) {
			var uo = uoList[i];
			var datarow = {
				uuoo: uo.uuoo,
				codigoDependencia: uo.cod_dep,
				uuooDetalle: uo.nom_largo,
			};
			setValueInputText("hidCodigoColaborador", "");
			setValueInputText("txtNombreColaborador", "Todos");
			setValueInputText("txtNroRegistro","");
			setValueInputText("txtUUOO", datarow.uuoo);
			setValueInputText("txtUUOODetalle", datarow.uuooDetalle);
			setValueInputText("hidCodigoDependencia", datarow.codigoDependencia);
			$('#txtNroRegistro').attr('disabled', false);
			$('#btnConsultarSolicitud').attr('disabled', false);
			$('#btnExpExcel').attr('disabled', false);
			$('#btnBuscarRegistro').attr('disabled', false);
			break;
		}
	}
	else {
		setHtmlElement("etiquetaErrorConsultarBandejaSolicitud", errorMessageBuscarUUOOInput.sinRegistrosBusqueda);
		showElement("divErrorConsultarBandejaSolicitud");
	}
	//clickBtnConsultarSolicitud();
};

var buscarUUOOInputService = new BuscarUUOOInputService();

function initElementsBuscarUUOOInputService(errorMessageBuscarUUOOInput) {
	var dataParametros = new Object();
	dataParametros.idNumeroUUOO = "txtUUOO";
	dataParametros.idCodigoDependencia = "hidCodigoDependencia";
	dataParametros.idNumeroRegistroColaborador = "txtNroRegistro";
	dataParametros.idCodigoRegistrador = "hidCodigoRegistrador";
	dataParametros.idNumeroRegistroRegistrador = "hidNumeroRegistroRegistrador";
	dataParametros.idCodigoTipoPagina = "hidCodigoTipoPagina";
	dataParametros.idDivLoading = "divLoadingBuscarColaboradorInput";
	dataParametros.idDivError = "divErrorConsultarBandejaSolicitud";
	dataParametros.idEtiquetaError = "etiquetaErrorConsultarBandejaSolicitud";
	dataParametros.errorMessage = errorMessageBuscarUUOOInput;
	buscarUUOOInputService = new BuscarUUOOInputService(dataParametros, buscarUUOOInputBeforeMethod, buscarUUOOInputAfterMethod);
}
/*Fin Codigo - buscarUUOOInput*/


/*Inicio Codigo - buscarColaboradorInput*/
var buscarColaboradorInputBeforeMethod = function() {
	$('#btnConsultarSolicitud').attr('disabled', true);
	$('#btnExpExcel').attr('disabled', true);
	setValueInputText("hidCodigoColaborador", "%");
	setValueInputText("txtNombreColaborador", "");
	$("#tblBandejaSolicitud").jqGrid('clearGridData');
};

var buscarColaboradorInputAfterMethod = function(colaboradorList) {
	if (colaboradorList != null && colaboradorList.length > 0) {
		for (var i = 0; i < colaboradorList.length; i++) {
			var colaborador = colaboradorList[i];
			var datarow = {
				numeroRegistro: colaborador.numero_registro,
				nombreCompleto: colaborador.nombre_completo,
				uuoo: colaborador.uuoo,
				codigoDependencia: colaborador.codigoDependencia,
				uuooDetalle: colaborador.dependencia,
				codigoEmpleado: colaborador.codigoEmpleado,
				codigoEstado: colaborador.codigoEstado,
				estadoDetalle: colaborador.estado
			};
			setValueInputText("hidCodigoColaborador", datarow.codigoEmpleado);
			setValueInputText("txtNombreColaborador", datarow.nombreCompleto);
			setValueInputText("txtUUOO", datarow.uuoo);
			setValueInputText("txtUUOODetalle", datarow.uuooDetalle);
			setValueInputText("hidCodigoDependencia", datarow.codigoDependencia);
			$('#btnConsultarSolicitud').attr('disabled', false);
			$('#btnExpExcel').attr('disabled', false);
			break;
		}
	}
	else {
		setHtmlElement("etiquetaErrorConsultarBandejaSolicitud", errorMessageBuscarColaboradorInput.sinRegistrosBusqueda);
		showElement("divErrorConsultarBandejaSolicitud");
	}
	//clickBtnConsultarSolicitud();
};

var buscarColaboradorInputService = new BuscarColaboradorInputService();

function initElementsBuscarColaboradorInputService(errorMessageBuscarColaboradorInput) {
	var dataParametros = new Object();
	dataParametros.idCodigoDependencia = "hidCodigoDependencia";
	dataParametros.idNumeroRegistroColaborador = "txtNroRegistro";
	dataParametros.idCodigoRegistrador = "hidCodigoRegistrador";
	dataParametros.idNumeroRegistroRegistrador = "hidNumeroRegistroRegistrador";
	dataParametros.idCodigoTipoPagina = "hidCodigoTipoPagina";
	dataParametros.idDivLoading = "divLoadingBuscarColaboradorInput";
	dataParametros.idDivError = "divErrorConsultarBandejaSolicitud";
	dataParametros.idEtiquetaError = "etiquetaErrorConsultarBandejaSolicitud";
	dataParametros.errorMessage = errorMessageBuscarColaboradorInput;
	buscarColaboradorInputService = new BuscarColaboradorInputService(dataParametros, buscarColaboradorInputBeforeMethod, buscarColaboradorInputAfterMethod);
}
/*Fin Codigo - buscarColaboradorInput*/

$(window).on("resize", function () {
	resizeTable("tblSeguimiento");
	resizeTable("tblArchivo");
	resizeTable("tblBandejaSolicitud");
	resizeTable("tblColaborador");
	resizeTable("tblUUOO");
	resizeTable("tblUUOOAutoriza");
	resizeTable("tblDetalleSolicitud");
	resizeTable("tblDetalleSolicitud2");
});