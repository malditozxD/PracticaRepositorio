/// <reference path="./registrarModificarSolicitud_init.js" />
/// <reference path="./registrarModificarSolicitud_event.js" />
/// <reference path="./registrarModificarSolicitud_service.js" />
/// <reference path="./registrarModificarSolicitud_validate.js" />
/// <reference path="../general/common.js" />
/// <reference path="../../WEB-INF/jsp/solicitud/registrar/registrarModificarSolicitud.jsp" />
/// <reference path="D:\jcfr\data\ts-definitions\DefinitelyTyped-master\jquery\jquery.d.ts" />

// petición ajax obtener departamentos
function callAjaxObtenerDepartamento( comboDepartamentoID ) {

	$.ajax({
		url: contextPathUrl + "/parametros.htm?action=obtenerDepartamentos",
		type: "post",
		dataType: "json",
		cache: false,
		beforeSend: function() {
			// bloquearScreen();
		},
		complete: function() {
			// desbloquearScreen();
		},
		success: function(result) {
			var departamentoList = result.departamentoList;
			if (departamentoList != null && departamentoList.length > 0) {

				var departamentoSel = $( '#' + comboDepartamentoID );
				departamentoSel.empty();
				for (var i = 0; i < departamentoList.length; i++) {
					var departamento = departamentoList[i];

					var optionSelect = $("<option></option>").attr("value", departamento.codiDepaDpt).text(departamento.nombDptoDpt);
					departamentoSel.append(optionSelect);

				}
			}
		},
		error: function( error ) {
			handleError( error );
		}
	});
}

// petición ajax obtener provincias en un departamento
function callAjaxObtenerProvincia(codigoDepartamento, comboProvinciaID) {

	$.ajax({
		url: contextPathUrl + "/parametros.htm?action=obtenerProvincias",
		type: "post",
		dataType: "json",
		cache: false,
		data: {
			"codigoDepartamento": codigoDepartamento
		},
		beforeSend: function() {
			// bloquearScreen();
		},
		complete: function() {
			// desbloquearScreen();
		},
		success: function(result) {
			var provinciaList = result.provinciaList;
			if (provinciaList != null && provinciaList.length > 0) {
				var provinciaSel = $( '#' + comboProvinciaID);
				provinciaSel.empty();
				for (var i = 0; i < provinciaList.length; i++) {
					var provincia = provinciaList[i];
					var optionSelect = $("<option></option>").attr("value", provincia.codiProvTpr).text(provincia.nombProvTpr);
					provinciaSel.append(optionSelect);
				}
				enabledElement( comboProvinciaID );
			}
		},
		error: function( error ) {
			handleError( error );
		}
	});
}


// petición ajax que realiza una validación lado servidor de traslape de fechas
function callAjaxValidarTraslapeFechas( asincrono, codColaborador, fechaSalidaParam, fechaRetornoParam, codPlanViaje, esComisionNacionalParam ) {

	// rango de fechas [fechaSalida, fechaRetorno]
	// siempre viene al menos una fecha seteada
	// si alguna fecha no viene con data, se toma un rango [fechaSalida, fechaSalida] o [fechaRetorno, fechaRetorno] segun el caso
	
	var rangoFechas = armarRangoFechaValida( fechaSalidaParam, fechaRetornoParam );
	
	var esComisionNacional = esNacional()? configRSV.constantes.SI : configRSV.constantes.NO;
	if ( estaDefinido( esComisionNacionalParam ) ) {
		esComisionNacional = esComisionNacionalParam;
	}

 	var dataPost = {
		'codColaborador' : codColaborador,
		'fechaSalida' : rangoFechas.inicio,
		'fechaRetorno' : rangoFechas.fin,
		'codPlanViaje' : codPlanViaje,
		'esComisionNacional' : esComisionNacional
	};
 
	return callAjaxValidarTraslapeFechasDataPost( asincrono, dataPost ); 
}

function callAjaxValidarTraslapeFechasDataPost( asincrono, dataPost ) {
	// busca plan de viajes del codColaborador que se traslapen con fechaSalida | fechaRetorno,
	// y opcionalmente que dichos planes de viaje sean diferentes a codPlanViaje
	
	// dataPost: debe contener los parámetros 'codColaborador', 'fechaSalida', 'fechaRetorno', 'codPlanViaje'

	// para usar con $.when(), o this.then()
	return $.ajax({
		url: contextPathUrl + "/registrarSolicitud.htm?action=validarTraslapeFechas",
		type: "post",
		dataType: "json",
		async: asincrono,
		cache: false,
		data: dataPost
	});
}

// petición ajax que realiza una validación lado servidor del guardar
function callAjaxValidarGuardarViatico() {

	$.ajax({
		url: contextPathUrl + "/registrarSolicitud.htm?action=validarGuardarViatico",
		type: "post",
		dataType: "json",
		cache: false,
		data: construirDataPost(true, true),
		beforeSend: function() {
			// bloquearScreen();
		},
		complete: function() {
			// desbloquearScreen();
		},
		success: function(result) {

			if ( huboErrorAjax( result ) ) {
				handleErrorAjax( result );
				return;
			}

			if ( result.validacionOk == 'si' ) {

				callAjaxGuardarViatico();

			} else {

				showMensaje( result.validacionMsg );

			}

		},
		error: function( error ) {
			handleError( error );
		}
	});
}

// petición ajax que realiza el guardar solicitud de viático
function callAjaxGuardarViatico() {

	$.ajax({
		url: contextPathUrl + "/registrarSolicitud.htm?action=guardarViatico",
		type: "post",
		dataType: "json",
		cache: false,
		data: construirDataPost(true, true),
		beforeSend: function() {
			bloquearScreen();
		},
		complete: function() {
			desbloquearScreen();
		},
		success: function(result) {

			if ( huboErrorAjax( result ) ) {
				handleErrorAjax( result );
				return;
			}

			if ( result.seGraboOK == 'si' ) {

				if ( result.generadoCodPlanViaje != null ) {
					$('#hidCodPlanViaje').val( result.generadoCodPlanViaje );
				}

				if ( result.generadoCodPlanilla != null ) {
					$('#txtCodPlanilla').val( result.generadoCodPlanilla );
				}

				// deshabilitar todo
				$( '#formViatico' ).find( 'input, button, select' ).prop( 'disabled', true );
				$( '#formViatico' ).find( 'input, button, select' ).off();

				//setTimeout(function() {
					callAjaxValidarInformarGuardarViatico();					
				//}, 500 );
						
			}

		},
		error: function( error ) {
			handleError( error );
		}
	});
}

function refrescaFormularioGrabado() {
						var formPost = $( '#formPost' );	
						formPost.find( 'input[name="action"]' ).val( 'mostrarModificarViatico' );
						formPost.find( 'input[name="codPlanilla"]' ).val( getTrimValue( '#txtCodPlanilla' )  );
						formPost.submit();	
}

function muestraMensajeExito() {
	showMensajeEmbebido( configRSV.mensajes.seGraboConExitoSolicitudViaticos, refrescaFormularioGrabado);
}

//petición ajax que realiza una validación lado servidor del guardar
function callAjaxValidarInformarGuardarViatico() {

	$.ajax({
		url: contextPathUrl + "/registrarSolicitud.htm?action=validarInformarGuardarViatico",
		type: "post",
		dataType: "json",
		cache: false,
		data: construirDataPost(true, true),
		beforeSend: function() {
			// bloquearScreen();
		},
		complete: function() {
			// desbloquearScreen();
		},
		success: function(result) {

			if ( huboErrorAjax( result ) ) {
				handleErrorAjax( result );
				return;
			}

			if ( result.validacionOk == 'no' ) {
				showMensaje( result.validacionMsg, muestraMensajeExito );
			}
			else {
				muestraMensajeExito();
			}
		},
		error: function( error ) {
			handleError( error );
		}
					});					
}

//petición ajax que realiza una validación lado servidor del guardar
function callAjaxValidarInformarModificarViatico() {

	$.ajax({
		url: contextPathUrl + "/registrarSolicitud.htm?action=validarInformarModificarViatico",
		type: "post",
		dataType: "json",
		cache: false,
		data: construirDataPost(true, true),
		beforeSend: function() {
			// bloquearScreen();
		},
		complete: function() {
			// desbloquearScreen();
		},
		success: function(result) {

			if ( huboErrorAjax( result ) ) {
				handleErrorAjax( result );
				return;
			}

			/*if ( result.validacionOk == 'no' ) {
				showMensajeEmbebido( result.validacionMsg, function() {
					callAjaxModificarViatico();
				});
			}
			else {
				callAjaxModificarViatico();			
			}*/
			if ( result.validacionOk == 'no' ) {
				showMensaje( result.validacionMsg, muestraMensajeExito );
			}
			else {
				muestraMensajeExito();
			}
		},
		error: function( error ) {
			handleError( error );
		}
	});
}

// petición ajax que realiza el validar modificar solicitud de viático
function callAjaxValidarModificarViatico() {

	$.ajax({
		url: contextPathUrl + "/registrarSolicitud.htm?action=validarModificarViatico",
		type: "post",
		dataType: "json",
		cache: false,
		data: construirDataPost(true, true),
		beforeSend: function() {
			bloquearScreen();
		},
		complete: function() {
			desbloquearScreen();
		},
		success: function(result) {

			if ( huboErrorAjax( result ) ) {
				handleErrorAjax( result );
				return;
			}

			if ( result.validacionOk == 'si' ) {
				 //callAjaxValidarInformarModificarViatico();//JMCR-ME CUS11
				 callAjaxModificarViatico();
			} else {
				showMensaje( result.validacionMsg );
			}

		},
		error: function( error ) {
			handleError( error );
		}
	});
}

// petición ajax que realiza el modificar solicitud de viático
function callAjaxModificarViatico() {

	$.ajax({
		url: contextPathUrl + "/registrarSolicitud.htm?action=modificarViatico",
		type: "post",
		dataType: "json",
		cache: false,
		data: construirDataPost(true, true),
		beforeSend: function() {
			bloquearScreen();
		},
		complete: function() {
			desbloquearScreen();
		},
		success: function(result) {

			if ( huboErrorAjax( result ) ) {
				handleErrorAjax( result );
				return;
			}

			if ( result.seGraboOK == 'si' ) {
				
				// deshabilitar todo
				$( '#formViatico' ).find( 'input, button, select' ).prop( 'disabled', true );
				$( '#formViatico' ).find( 'input, button, select' ).off();				
				
				/*setTimeout(function() {

					showMensaje( configRSV.mensajes.seGraboConExitoSolicitudViaticos, function() {
						
						// updateEstadosPanelBotones();
						
						var formPost = $( '#formPost' );	
						formPost.find( 'input[name="action"]' ).val( 'mostrarModificarViatico' );
						formPost.find( 'input[name="codPlanilla"]' ).val( getTrimValue( '#txtCodPlanilla' )  );
						formPost.submit();						

					});					
					
				}, 500);*/

				callAjaxValidarInformarModificarViatico();			
			}

		},
		error: function( error ) {
			handleError( error );
		}
	});

}

//petición ajax que realiza el validar enviar solicitud de viático
function callAjaxValidarEnviarSolicitudViatico() {

	$.ajax({
		url: contextPathUrl + "/registrarSolicitud.htm?action=validarEnviarSolicitudViatico",
		type: "post",
		dataType: "json",
		cache: false,
		data: construirDataPost(false, false),
		beforeSend: function() {
			bloquearScreen();
		},
		complete: function() {
			desbloquearScreen();
		},
		success: function(result) {
			
			if ( huboErrorAjax( result ) ) {
				handleErrorAjax( result );
				return;
			}

			if ( result.validacionOk == 'si' ) {
				
				//Se pasaron todas las validaciones en el front y backend, aquí firmamos.
				//FE
				var codPlanilla = $("#txtCodPlanilla").val();
				showMensajePreviaConfirmacionFirma(codPlanilla,function(){
					showModalElement("divMensajeAutorizaEnviar");//mensaje modal de la firma
				});
				
			} else {
				showMensaje( result.validacionMsg );
			}

		},
		error: function( error ) {
			handleError( error );
		}
	});
}

//petición ajax que realiza el envío solicitud de viático
function callAjaxEnviarSolicitudViatico() {

	var dataSend = construirDataPost(false, false);
	dataSend["numeroRegistroArchivo"] = numArchivoPdfFirmado;
	
	$.ajax({
		url: contextPathUrl + "/registrarSolicitud.htm?action=enviarSolicitudViatico",
		type: "post",
		dataType: "json",
		cache: false,
		data: dataSend,
		beforeSend: function() {
			bloquearScreen();
		},
		complete: function() {
			desbloquearScreen();
		},
		success: function(result) {

			if ( huboErrorAjax( result ) ) {
				handleErrorAjax( result );
				return;
			}

			if ( result.seEnvioOK == 'si' ) {

				showMensaje( configRSV.mensajes.planillaRemitidaParaAutorizacionExitosa );
				
				// actualizar en pantalla el estado
				$( '#hidCodigoEstadoViatico' ).val( result.estadoViatico );
				$( '#txtEstadoViatico' ).val( result.estadoViaticoDescripcion );
				
				// deshabilitar todo
				$( '#formViatico' ).find( 'input, button, select' ).prop( 'disabled', true );
				$( '#formViatico' ).find( 'input, button, select' ).off();
				
				// habilitar el botón retornar
				$( '#btnSalirRetornarViatico' ).prop( 'disabled', false );
				addEventElement("btnSalirRetornarViatico", "click", clickBtnSalirRetornarViatico);
				addEventElement("btnImprimirViatico", "click", clickBtnImprimirViatico);
				habilitarBtnImprimirViatico();
				
			} else {
				
				showMensaje( result.envioError );
			}

		},
		error: function( error ) {
			handleError( error );
		}
	});
}

// petición ajax que trae los número de días hábiles entre dos fechas
function callAjaxCalcularNroDiasHabiles( fechaInicial, fechaFinal, functionOK ) {

	$.ajax({
		url: contextPathUrl + "/solicitud.htm?action=calcularNroDiasHabiles",
		type: "post",
		dataType: "json",
		cache: false,
		data: {
			'fechaInicial' : fechaInicial,
			'fechaFinal' : fechaFinal
		},
		beforeSend: function() {
			// bloquearScreen();
		},
		complete: function() {
			// desbloquearScreen();
		},
		success: function(result) {

			if ( huboErrorAjax( result ) ) {
				handleErrorAjax( result );
				return;
			}

			if ( estaDefinido( functionOK ) ) {
				functionOK( result );
			}

		},
		error: function( error ) {
			handleError( error );
		}
	});
}

// petición ajax que trae la fecha máxima de rendición
function callAjaxCalcularFechaMaximaRendicion( fechaFinal, functionOK ) {

	$.ajax({
		url: contextPathUrl + "/solicitud.htm?action=calcularFechaMaximaRendicion",
		type: "post",
		dataType: "json",
		cache: false,
		data: {
			'tipoViatico': $( '#selTipoViatico' ).val(),
			'duracionComision': $( '#selDuracionComision' ).val(),
			'fechaFinal': fechaFinal,
			'canalAtencion' : $( '#txtCodigoCanalAtencion' ).val()
		},
		beforeSend: function() {
			// bloquearScreen();
		},
		complete: function() {
			// desbloquearScreen();
		},
		success: function(result) {

			if ( huboErrorAjax( result ) ) {
				handleErrorAjax( result );
				return;
			}

			if ( estaDefinido( functionOK ) ) {
				functionOK( result );
			}

		},
		error: function( error ) {
			handleError( error );
		}
	});
}

// petición ajax que trae las cadenas presupuestales
function callAjaxObtenerCadenaPresupuestal(codigoDependencia) {

	$.ajax({
		url: contextPathUrl + "/viatico.htm?action=obtenerMetas",
		type: "post",
		dataType: "json",
		cache: false,
		data: {
			'ordenarPor': 'CODIGO_PROY',
			'codigoDependencia': codigoDependencia
		},
		beforeSend: function() {
			// bloquearScreen();
		},
		complete: function() {
			// desbloquearScreen();
		},
		success: function(result) {
			
			var metasList = result.metasList;
			
			if (metasList != null && metasList.length > 0) {

				// buscar meta por default (IND_META_UUOO = 1)
				var meta = null;
				$.each( metasList, function(i, item) {
					
					if ( $.trim( item.indicadorMetaUUOO ) == '1' )  {
						meta = item;						
						return false; // break
					}
					
				});

				// si no hay meta por default, coge la primera meta (en ambos casos se ordena por mayor código)
				if (meta == null) {
					meta = metasList[0];
				}

				var datarow = {
					secuFuncSfu: meta.secuFuncSfu,
					codigoDependencia: meta.codiDepeTde,
					codigoMetaPresupuestal: meta.codiLargMet,
					metaPresupuestal: meta.descLargMet
				};

				setValueInputText( 'txtMetaPresupuestal', datarow.secuFuncSfu + " - " + datarow.codigoMetaPresupuestal + " " + datarow.metaPresupuestal );
				setValueInputText( 'txtCodigoMetaPresupuestal', datarow.secuFuncSfu );

			} else {
				// limpiar meta presupuestal
				setValueInputText( 'txtMetaPresupuestal', '' );
				setValueInputText( 'txtCodigoMetaPresupuestal', '' );
			}

		},
		error: function( error ) {
			// limpiar meta presupuestal
			setValueInputText( 'txtMetaPresupuestal', '' );
			setValueInputText( 'txtCodigoMetaPresupuestal', '' );

			handleError( error );
		}
	});

}

// petición ajax que trae los lugares por código de departamento y provincia
function callAjaxObtenerLugarByCodigo(codigoDepartamento, codigoProvincia) {

	$.ajax({
		url: contextPathUrl + "/viatico.htm?action=obtenerLugaresByCodigo",
		type: "post",
		dataType: "json",
		cache: false,
		data: {
			"codigoDepartamento": codigoDepartamento,
			"codigoProvincia": codigoProvincia
		},
		beforeSend: function() {
			// bloquearScreen();
		},
		complete: function() {
			// desbloquearScreen();
			updateBotonAgregarDesplazamiento();
		},
		success: function(result) {

			if ( huboErrorAjax( result ) ) {
				handleErrorAjax( result );
				return;
			}

			var codigoLugar = $.trim( result.codigoLugar );

			// NOTA: puede que la tabla txxx8lugarubigo no tenga todas las combinaciones que hay en departamento/provincia,
			//       lo cual generaría un codigoLugar en blanco.
			if ( codigoLugar == '' ) {
				consoleLog( 'no existe lugar para el departamento y provincia seleccionados: ' + codigoDepartamento + " " + codigoProvincia );
			}

			$('#hidCodigoPuntoPartida').val( codigoLugar );

		},
		error: function( error ) {
			handleError( error );
		}
	});
}

// petición ajax que trae la intendencia usando el numero de uuoo
function callAjaxObtenerIntendencia(num_uuoo) {

	$.ajax({
		url: contextPathUrl + "/dependencias.htm?action=buscarIntendencia",
		type: "post",
		dataType: "json",
		cache: false,
		data: {
			'num_uuoo': num_uuoo
		},
		beforeSend: function() {
			// bloquearScreen();
		},
		complete: function() {
			// desbloquearScreen();
		},
		success: function(result) {

			// lista de intendencias (como lista de intendencias)	
			var dependenciaList = result.dependenciaList;
			
			if (dependenciaList != null && dependenciaList.length > 0) {

				var dependencia = dependenciaList[0];

				if ( dependencia != null ) {

					// concatenar la intendencia
					var intendencia = $.trim( dependencia.intendencia );

					if ( intendencia != '' ) {

						var txtUUOODetalle = getTrimValue( '#txtUUOODetalle' );

						txtUUOODetalle = txtUUOODetalle + ' - ' + intendencia;

						setValueInputText( 'txtUUOODetalle', txtUUOODetalle );

					}

				}

			}  

		},
		error: function( error ) {

			handleError( error );
		}
	});

}