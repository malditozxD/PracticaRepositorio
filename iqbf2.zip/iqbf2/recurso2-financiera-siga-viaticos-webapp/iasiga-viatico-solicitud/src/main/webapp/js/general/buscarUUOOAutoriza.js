function initElementsBuscarUUOOAutoriza(idElementCallModal) {
	setInitElementsBuscarUUOOAutoriza();
	setInitUUOOAutorizaTable(idElementCallModal);
}

function setInitElementsBuscarUUOOAutoriza() {
	setValueInputText("selTipoBusquedaBuscarUUOOAutoriza", "00");
	setValueInputText("txtDescripcionBusquedaBuscarUUOOAutoriza", "");
	hideElement("divErrorBuscarUUOOAutoriza");
	disabledElement("txtDescripcionBusquedaBuscarUUOOAutoriza");
	disabledElement("btnBuscarRegistroBuscarUUOOAutoriza");
	disabledElement("btnAceptarBuscarUUOOAutoriza");
	addEventElement("btnBuscarRegistroBuscarUUOOAutoriza", "click", clickBtnBuscarRegistroBuscarUUOOAutoriza);
	addEventElement("btnBuscarTodosRegistroBuscarUUOOAutoriza", "click", clickBtnBuscarTodosRegistroBuscarUUOOAutoriza);
	addEventElement("btnAceptarBuscarUUOOAutoriza", "click", clickBtnAceptarBuscarUUOOAutoriza);
	addEventElement("btnCancelarBuscarUUOOAutoriza", "click", clickBtnCancelarBuscarUUOOAutoriza);
	addEventElement("selTipoBusquedaBuscarUUOOAutoriza", "change", changeSelTipoBusquedaBuscarUUOOAutoriza);
	/*if (buscarUUOOAutorizaService.idCodigoTipoUUOOViatico == "01" || buscarUUOOAutorizaService.idCodigoTipoUUOOViatico == "03") {
		hideElement("btnBuscarTodosRegistroBuscarUUOOAutoriza");
	}*/
}

function removeEventElementsBuscarUUOOAutoriza() {
	removeAllEventsElement("btnBuscarRegistroBuscarUUOOAutoriza");
	removeAllEventsElement("btnBuscarTodosRegistroBuscarUUOOAutoriza");
	removeAllEventsElement("btnAceptarBuscarUUOOAutoriza");
	removeAllEventsElement("btnCancelarBuscarUUOOAutoriza");
	removeAllEventsElement("selTipoBusquedaBuscarUUOOAutoriza");
}

function removeUUOOTableBuscarUUOOAutoriza() {
	var htmlElement = "<table id=\"tblUUOOAutoriza\"></table>";
	htmlElement += "<div id=\"divUUOOAutorizaPagerTable\" class=\"jqGridMovilidadPagerClass\"></div>";
	setHtmlElement("divUUOOAutorizaTable", htmlElement);
}

function setInitUUOOAutorizaTable(idElementCallModal) {
	var uuooTable = $("#tblUUOOAutoriza");
	if (uuooTable) {
		//Para el DivWitdh se utilizo un componente que llama al modal
		var uuooTableDiv = $("#" + idElementCallModal);
		var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.movilidadModalContainer", ".movilidadModalContainerAuxiliar", "width"))/100);
		var widthTable = factorRedimensionamiento*uuooTableDiv.width();
		uuooTable.jqGrid({
			width: widthTable,
			height: 200,
			datatype: "local",
			rowNum: 10,
			rowList: [10, 20],
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames:[
				"C&oacute;digo UUOO",
				"Descripci&oacute;n",
				"C&oacute;digo Dependencia"
			],
			colModel:[
				{name:"uuoo", index: "uuoo", width: (3*widthTable/12)},
				{name:"descripcionUUOO", index: "descripcionUUOO", width: (9*widthTable/12)},
				{name:"codigoDependencia", index: "codigoDependencia", width: (3*widthTable/12), hidden: true}
			],
			pager : "#divUUOOAutorizaPagerTable",
			loadui: "disable"
		});
	}
	uuooTable.clearGridData();
}

function clickBtnBuscarRegistroBuscarUUOOAutoriza() {
	
	var flagParametrosValidos = true;
	var errorMessage = "";
	setHtmlElement("divUUOOAutorizaPagerTable_left", "");
	hideElement("divErrorBuscarUUOOAutoriza");
	if (flagParametrosValidos && getValueInputText("selTipoBusquedaBuscarUUOOAutoriza") == "00") {
		errorMessage = errorMessageBuscarUUOOAutoriza.seleccionarTipoBusqueda;
		flagParametrosValidos = false;
	}
	
	if (flagParametrosValidos && trimText(getValueInputText("txtDescripcionBusquedaBuscarUUOOAutoriza")) == "") {
		errorMessage = errorMessageBuscarUUOOAutoriza.completarDescripcion;
		flagParametrosValidos = false;
	}
	
	if (flagParametrosValidos && trimText(getValueInputText("txtDescripcionBusquedaBuscarUUOOAutoriza")).length < 2) {
		errorMessage = errorMessageBuscarUUOOAutoriza.cantidadMinimaDescripcion;
		flagParametrosValidos = false;
	}
	
	if (flagParametrosValidos) {
		callObtenerUnidadOrganizacionalAutoriza("0");
	}
	else {
		showMessageErrorBuscarUUOOAutoriza(errorMessage);
	}
}

function clickBtnBuscarTodosRegistroBuscarUUOOAutoriza() {
	setValueInputText("selTipoBusquedaBuscarUUOOAutoriza", "00");
	setValueInputText("txtDescripcionBusquedaBuscarUUOOAutoriza", "");
	setHtmlElement("divUUOOAutorizaPagerTable_left", "");
	hideElement("divErrorBuscarUUOOAutoriza");
	disabledElement("txtDescripcionBusquedaBuscarUUOOAutoriza");
	disabledElement("btnBuscarRegistroBuscarUUOOAutoriza");
	disabledElement("btnBuscarTodosRegistroBuscarUUOOAutoriza");
	callObtenerUnidadOrganizacionalAutoriza("1");
}

function clickBtnAceptarBuscarUUOOAutoriza() {
	
	var uuooTable = $("#tblUUOOAutoriza");
	var rowId = uuooTable.jqGrid("getGridParam", "selrow");
	if (rowId == null) {
		setHtmlElement("divUUOOAutorizaPagerTable_left", errorMessageBuscarUUOOAutoriza.seleccionarRegistro);
	}
	else {
		var rowData = uuooTable.getRowData(rowId);
		if (typeof buscarUUOOAutorizaService.buscarUUOOBefore != "undefined") {
			buscarUUOOAutorizaService.buscarUUOOBefore();
		}
		if (typeof buscarUUOOAutorizaService.buscarUUOOAfter != "undefined") {
			buscarUUOOAutorizaService.buscarUUOOAfter(rowData);
		}
		removeEventElementsBuscarUUOOAutoriza();
		removeUUOOTableBuscarUUOOAutoriza();
		$("#divBuscarUUOOAutoriza").modal("hide");
	}
}

function validaCantidadCaracteresAutoriza(){
	var descripcionBusquedaBuscarUUOO = getValueInputText("txtDescripcionBusquedaBuscarUUOOAutoriza");
	if(descripcionBusquedaBuscarUUOO.length == 0){
		disabledElement("btnBuscarRegistroBuscarUUOOAutoriza");
		return false;
	}else{
		enabledElement("btnBuscarRegistroBuscarUUOOAutoriza");
		return true;
	}
}

function clickBtnCancelarBuscarUUOOAutoriza() {
	removeEventElementsBuscarUUOOAutoriza();
	removeUUOOTableBuscarUUOOAutoriza();
	$("#divBuscarUUOOAutoriza").modal("hide");
}

function changeSelTipoBusquedaBuscarUUOOAutoriza() {
	
	var uuooTable = $("#tblUUOOAutoriza");
	uuooTable.clearGridData();
	setValueInputText("txtDescripcionBusquedaBuscarUUOOAutoriza", "");
	setHtmlElement("divUUOOAutorizaPagerTable_left", "");
	hideElement("divErrorBuscarUUOOAutoriza");
	disabledElement("btnAceptarBuscarUUOOAutoriza");
	
	if (getValueInputText("selTipoBusquedaBuscarUUOOAutoriza") == "00") {
		disabledElement("txtDescripcionBusquedaBuscarUUOOAutoriza");
		//disabledElement("btnBuscarRegistroBuscarUUOO");
		var estadoCantidadCaracteres = validaCantidadCaracteresAutoriza();
		if(estadoCantidadCaracteres){
			disabledElement("btnBuscarRegistroBuscarUUOOAutoriza");
		}else{
			disabledElement("btnBuscarRegistroBuscarUUOOAutoriza");
		}
	}
	else {
		enabledElement("txtDescripcionBusquedaBuscarUUOOAutoriza");
		//enabledElement("btnBuscarRegistroBuscarUUOO");
		var estadoCantidadCaracteres = validaCantidadCaracteresAutoriza();
		if(estadoCantidadCaracteres){
			enabledElement("btnBuscarRegistroBuscarUUOOAutoriza");
		}else{
			disabledElement("btnBuscarRegistroBuscarUUOOAutoriza");
		}
	}
}

function callObtenerUnidadOrganizacionalAutoriza(indicadorBuscarTodos) {
	
	var uuooTable = $("#tblUUOOAutoriza");
	uuooTable.clearGridData();
	if (typeof buscarUUOOAutorizaService != "undefined") {
		$.ajax({
			url: contextPathUrl + "/dependencias.htm?action=buscarUnidadOrganizacional",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"flagAutoriza":"1",
				"codigoTipoBusquedaUUOO": getValueInputText("selTipoBusquedaBuscarUUOOAutoriza"),
				"descripcionBuscarUUOO": getUpperCaseValueInputText("txtDescripcionBusquedaBuscarUUOOAutoriza"),
				"codigoRegistrador": getUpperCaseValueInputText(buscarUUOOAutorizaService.idCodigoRegistrador),
				"flagParametroTodos": indicadorBuscarTodos,
				"codigoTipoUUOOViatico": buscarUUOOAutorizaService.idCodigoTipoUUOOViatico
			},
			beforeSend: function() {
				if (typeof buscarUUOOAutorizaService.idDivScreenBlock != "undefined") {
					showModalElement(buscarUUOOAutorizaService.idDivScreenBlock);
				}
				showElement("divLoadingBuscarUUOOAutoriza");
			},
			complete: function() {
				hideElement("divLoadingBuscarUUOOAutoriza");
				enabledElement("btnBuscarTodosRegistroBuscarUUOOAutoriza");
				if (typeof buscarUUOOAutorizaService.idDivScreenBlock != "undefined") {
					hideModalElement(buscarUUOOAutorizaService.idDivScreenBlock);
				}
			},
			success: function(result) {
				var dependenciaList = result.dependenciaList;
				if (dependenciaList != null && dependenciaList.length > 0) {
					for (var i = 0; i < dependenciaList.length; i++) {
						var dependencia = dependenciaList[i];
						var datarow = {
							uuoo: dependencia.uuoo,
							descripcionUUOO: dependencia.nom_largo,
							codigoDependencia: dependencia.cod_dep,
							intendencia : dependencia.intendencia
						};
						uuooTable.jqGrid("addRowData", dependencia.uuoo, datarow);
					}
					uuooTable.trigger("reloadGrid");
					enabledElement("btnAceptarBuscarUUOOAutoriza");
				}
				else {
					setHtmlElement("divUUOOAutorizaPagerTable_left", errorMessageBuscarUUOO.sinRegistrosBusqueda);
				}
			},
			error: function() {
				consoleBrowser("Error callObtenerUnidadOrganizacional");
			}
		});
	}
}

function showMessageErrorBuscarUUOOAutoriza(errorMessage) {
	setHtmlElement("etiquetaErrorBuscarUUOOAutoriza", errorMessage);
	showElement("divErrorBuscarUUOOAutoriza");
}