function initElementsReportarAsistencia(idElementCallModal, numeroRegistro, fechaInicial, fechaFinal, nombreColaborador) {
	setInitElementsReportarAsistencia(numeroRegistro, nombreColaborador);
	setInitAsistenciaTable(idElementCallModal);
	callObtenerAsistenciaEmpleado(numeroRegistro, fechaInicial, fechaFinal);
}

function setInitElementsReportarAsistencia(numeroRegistro, nombreColaborador) {
	setHtmlElement("divVacacionesPagerTable_left", "");
	setHtmlElement("divCompensacionesPagerTable_left", "");
	setHtmlElement("divLicenciasPagerTable_left", "");
	addEventElement("btnCerrarReporteAsistencia", "click", clickBtnCerrarReportarAsistencia);
	
	$('#divDatosColaboradorAsistencia').html( $.trim( nombreColaborador ) );
	
}

function removeEventElementsReportarAsistencia() {
	removeAllEventsElement("btnCerrarReporteAsistencia");
}

function removeAsistenciaTable() {
	
	// remueve las tablas de asistencia
	
	var htmlElement = null;
	// remover tabla vacaciones
	htmlElement = "<table id=\"tblVacaciones\"></table>";
	htmlElement += "<div id=\"divVacacionesPagerTable\" class=\"jqGridViaticoPagerClass\"></div>";
	setHtmlElement("divVacacionesTable", htmlElement);
	
	// remover tabla compensaciones
	htmlElement = "<table id=\"tblCompensaciones\"></table>";
	htmlElement += "<div id=\"divCompensacionesPagerTable\" class=\"jqGridViaticoPagerClass\"></div>";
	setHtmlElement("divCompensacionesTable", htmlElement);
	
	// remover tabla licencias
	htmlElement = "<table id=\"tblLicencias\"></table>";
	htmlElement += "<div id=\"divLicenciasPagerTable\" class=\"jqGridViaticoPagerClass\"></div>";
	setHtmlElement("divLicenciasTable", htmlElement);
}

function setInitAsistenciaTable(idElementCallModal) {
	
	// inicializa las tablas de asistencia
	
	//Para el DivWitdh se utilizo un componente que llama al modal
	var callModalCallerDiv = $("#" + idElementCallModal);
	var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.viaticoModalContainer", ".viaticoModalContainerAuxiliar", "width"))/100);
	var widthTable = factorRedimensionamiento*callModalCallerDiv.width();

	// tabla vacaciones
	var vacacionesTable = $("#tblVacaciones");
	if (vacacionesTable) {

		vacacionesTable.jqGrid({
			width: widthTable,
			height: 'auto',
			minHeight: 70,
			autowidth: true,
			datatype: "local",
			rowNum: 100,
			pgbuttons: false,     // disable page control like next, back button
			pgtext: null,         // disable pager text like 'Page 0 of 10'
			viewrecords: false,    // disable current view record text like 'View 1-10 of 100'			
			cmTemplate: {sortable: false},
			colNames:[
				"Nro", 			// hidden
				"Concepto",		// hidden
				"Desde",
				"Hasta",
				"D&iacute;as"
			],
			colModel:[
				{name: "secuencia", index: "secuencia", width: (1*widthTable/12), align:'center', hidden: true},
				{name: "concepto", index: "concepto", width: (3*widthTable/12), hidden: true},
				{name: "desde", index: "desde", width: (2.5*widthTable/12), align:'center'},
				{name: "hasta", index: "hasta", width: (2.5*widthTable/12), align:'center'},
				{name: "dias", index: "dias", width: (1.5*widthTable/12), align:'center'}
			],
			pager : "#divVacacionesPagerTable",
			loadui: "disable",
			caption: messageReportarAsistencia.lblVacaciones
		});
	}
	
	// tabla compensaciones
	var compensacionesTable = $("#tblCompensaciones");
	if (compensacionesTable) {
 
		compensacionesTable.jqGrid({
			width: widthTable,
			height: 'auto',
			minHeight: 70,
			autowidth: true,
			datatype: "local",
			rowNum: 100,
			pgbuttons: false,     // disable page control like next, back button
			pgtext: null,         // disable pager text like 'Page 0 of 10'
			viewrecords: false,    // disable current view record text like 'View 1-10 of 100'			
			cmTemplate: {sortable: false},
			colNames:[
				"Nro",			// hidden
				"Concepto",		// hidden	
				"Desde",
				"Hasta",
				"D&iacute;as"
			],
			colModel:[
				{name: "secuencia", index: "secuencia", width: (1*widthTable/12), align:'center', hidden: true},
				{name: "concepto", index: "concepto", width: (3*widthTable/12), hidden: true},
				{name: "desde", index: "desde", width: (2.5*widthTable/12), align:'center'},
				{name: "hasta", index: "hasta", width: (2.5*widthTable/12), align:'center'},
				{name: "dias", index: "dias", width: (1.5*widthTable/12), align:'center'}
			],
			pager : "#divCompensacionesPagerTable",
			loadui: "disable",
			caption: messageReportarAsistencia.lblCompensaciones
		});
	}
	
	// tabla licencias
	var licenciasTable = $("#tblLicencias");
	if (licenciasTable) {
		
		licenciasTable.jqGrid({
			width: widthTable,
			height: 'auto',
			minHeight: 70,
			autowidth: true,
			datatype: "local",
			rowNum: 100,
			pgbuttons: false,     // disable page control like next, back button
			pgtext: null,         // disable pager text like 'Page 0 of 10'
			viewrecords: false,    // disable current view record text like 'View 1-10 of 100'
			cmTemplate: {sortable: false},
			colNames:[
				"Nro",			// hidden
				"Concepto",		// hidden
				"Desde",
				"Hasta",
				"D&iacute;as"
			],
			colModel:[
				{name: "secuencia", index: "secuencia", width: (1*widthTable/12), align:'center', hidden: true},
				{name: "concepto", index: "concepto", width: (3*widthTable/12), hidden: true},
				{name: "desde", index: "desde", width: (2.5*widthTable/12), align:'center'},
				{name: "hasta", index: "hasta", width: (2.5*widthTable/12), align:'center'},
				{name: "dias", index: "dias", width: (1.5*widthTable/12), align:'center'}
			],
			pager : "#divLicenciasPagerTable",
			loadui: "disable",
			caption: messageReportarAsistencia.lblLicencias
		});
	}	
	
}

function clickBtnCerrarReportarAsistencia() {
	removeEventElementsReportarAsistencia();
	removeAsistenciaTable();
	$('#divReporteAsistencia').modal('hide');
}

function callObtenerAsistenciaEmpleado(numeroRegistro, fechaInicial, fechaFinal) {
	
	setTimeout(function(){

		$.ajax({
			url: contextPathUrl + "/viatico.htm?action=obtenerAsistenciaEmpleado",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"numeroRegistro": numeroRegistro,
				"fechaInicial": fechaInicial,
				"fechaFinal": fechaFinal
			},
			beforeSend: function() {
				showElement("divLoadingReportarAsistencia");
			},
			complete: function() {
				hideElement("divLoadingReportarAsistencia");
			},
			success: function(result) {
				
				// fill tabla vacaciones
				var vacacionTable = $("#tblVacaciones");
				vacacionTable.clearGridData();
				var vacacionList = result.vacacionList;
				if (vacacionList != null && vacacionList.length > 0) {
					for (var i = 0; i < vacacionList.length; i++) {
						var vacacion = vacacionList[i];
						var datarow = {
							secuencia: (i + 1),
							concepto: vacacion.concepto,
							desde: vacacion.fechaInicio,
							hasta: vacacion.fechaFin,
							dias: vacacion.diferenciaDias
						};
						vacacionTable.jqGrid("addRowData", datarow.secuencia, datarow);						
					}
					vacacionTable.trigger("reloadGrid");
				}
				else {
					setHtmlElement("divVacacionesPagerTable_left", messageReportarAsistencia.sinRegistrosBusqueda);
				}
				
				// fill tabla compensaciones
				var compensacionesTable = $("#tblCompensaciones");
				compensacionesTable.clearGridData();
				var compensacionList = result.compensacionList;
				if (compensacionList != null && compensacionList.length > 0) {
					for (var i = 0; i < compensacionList.length; i++) {
						var compensacion = compensacionList[i];
						var datarow = {
							secuencia: (i + 1),
							concepto: licencia.concepto,
							desde: licencia.fechaInicio,
							hasta: licencia.fechaFin,
							dias: licencia.diferenciaDias
						};
						compensacionesTable.jqGrid("addRowData", datarow.secuencia, datarow);						
					}
					compensacionesTable.trigger("reloadGrid");
				}
				else {
					setHtmlElement("divCompensacionesPagerTable_left", messageReportarAsistencia.sinRegistrosBusqueda);
				}				
				
				// fill tabla licencias
				var licenciasTable = $("#tblLicencias");
				licenciasTable.clearGridData();
				var licenciaList = result.licenciaList;
				if (licenciaList != null && licenciaList.length > 0) {
					for (var i = 0; i < licenciaList.length; i++) {
						var licencia = licenciaList[i];
						var datarow = {
							secuencia: (i + 1),
							concepto: licencia.concepto,
							desde: licencia.fechaInicio,
							hasta: licencia.fechaFin,
							dias: licencia.diferenciaDias
						};
						licenciasTable.jqGrid("addRowData", datarow.secuencia, datarow);						
					}
					licenciasTable.trigger("reloadGrid");
				}
				else {
					setHtmlElement("divLicenciasPagerTable_left", messageReportarAsistencia.sinRegistrosBusqueda);
				}
				
			},
			error: function() {
				consoleLog("Error callObtenerAsistenciaEmpleado");
			}
		});
	}, 500);
}