/// <reference path="../general/common.js" />
/// <reference path="../../WEB-INF/jsp/solicitud/consultar/consultarSolicitud.jsp" />
/// <reference path="D:\jcfr\data\ts-definitions\DefinitelyTyped-master\jquery\jquery.d.ts" />


var configCSV = null;
var adjuntarDocumentoService = null;

function initElementsConsultarSolicitud( codPlanilla, esRegistrador, paginaOrigen ) {
	
	removeDuplicateComponents();

	// codPlanViaje y nroRegistro es lo que necesita el modulo de consultar/adjuntar archivo
	var origen = '';
	if ( estaDefinido( paginaOrigen ) ) {
		origen = paginaOrigen;
	}
	
	configCSV = {
		'codPlanilla' : codPlanilla,
		'codPlanViaje': '',
		'nroRegistro': '',
		'esRegistrador': esRegistrador,
		'origen': origen
	};
	
	setInitElementsConsultarSolicitud();

	limpiarSeccionesConsultarSolicitud();
	
	callAjaxObtenerDatosViaticoConsultarSolicitud( configCSV.codPlanilla );
	
}

function setInitElementsConsultarSolicitud() {
	$( '#divHiddenImprimirPost' ).hide();
	// inicializa los controles	y eventos
	addEventElement("btnAdjuntarViatico", "click", clickBtnAdjuntarViatico);
	addEventElement("btnImprimirViatico", "click", clickBtnImprimirViatico);
	addEventElement("btnSalirRetornarViatico", "click", clickBtnSalirRetornarViatico);

	addEventElement("btnConsultarAsistenciaNacMay4h", "click", clickBtnConsultarAsistencia);	// nacional > 4h
	addEventElement("btnConsultarAsistenciaNacMen4h", "click", clickBtnConsultarAsistencia);	// nacional <= 4h
	addEventElement("btnConsultarAsistenciaInt", "click", clickBtnConsultarAsistencia);			// internacional	
}

function habilitarBtnImprimir(codPlanilla,codEstado){
	$('#btnImprimirViatico').prop( 'disabled', true );
	if(codPlanilla!=""){
		existeDocumentoFirmado("043",codPlanilla,function(resultado){
			var existe = resultado.existe;
			
			var estadosObservacion = ["06","07","08","09","03"]; //array de estados en observacion o anulados
			if(existe && $.inArray(codEstado, estadosObservacion)<0){
				$('#btnImprimirViatico').prop( 'disabled', false );		
			}
		});	
	}
}


function clickBtnConsultarAsistencia() {

	var fechaFinal = '';
	var fechaInicial = '';
	var numeroRegistroText = getTrimValue( '#txtNroRegistroCSV' );
	var txtNombreColaborador = getTrimValue( '#txtNombreColaboradorCSV' );

	// validacion adicional
	if ( numeroRegistroText == '' ) {
		showMensaje( 'Por favor ingresar un colaborador', function() {
			darFoco( '#txtNroRegistroCSV' );
		});
		return;
	}

	if ( esNacional() ) {

		if ( esMayor4h() ) {

			fechaInicial = getTrimValue( '#fechaSalidaNacMay4hCSV' );
			fechaFinal = getTrimValue( '#fechaRetornoNacMay4hCSV' );

		} else {	// si es menor o igual a 4 horas

			// la fecha inicial y final es el mismo dia
			fechaInicial = getTrimValue( '#fechaNacMen4hCSV' );
			fechaFinal = getTrimValue( '#fechaNacMen4hCSV' );
		}

	} else { // si es internacional

		// en primera instancia, toma las fechas de itinerario/ejecucion (asi dice en el F2)
		if ( esFechaValida( getTrimValue( '#fechaItinerarioInicioInterCSV' ) ) && esFechaValida( getTrimValue( '#fechaItinerarioFinInterCSV' ) ) ) {

			fechaInicial = getTrimValue( '#fechaItinerarioInicioInterCSV' );
			fechaFinal = getTrimValue( '#fechaItinerarioFinInterCSV' );

		} else {
			
			// dado que son las fechas de itinetario/ejecucion son opcionales.
			// en otro caso toma las fechas de programacion/evento

			fechaInicial = getTrimValue( '#fechaEventoInicioInterCSV' );
			fechaFinal = getTrimValue( '#fechaEventoFinInterCSV' );
		}

	}

	initElementsReportarAsistencia("divDesplazamientoTableRSV", numeroRegistroText, fechaInicial, fechaFinal, txtNombreColaborador);
	showModalElement("divReporteAsistencia");
	triggerResizeEvent();

}

function clickBtnImprimirViatico() {
	/*var formPost = $( '#formImprimirPost' );
	formPost.find( 'input[name="action"]' ).val( 'imprimirSolicitudViatico' );
	formPost.find( 'input[name="codPlanilla"]' ).val( getTrimValue( '#txtCodPlanillaCSV' ) );
	formPost.submit();*/
	
	//La impresion solo debe ser posible si existe el documento, si está habilitado es por que ya existe.
	descargarPdfFirmado("043",configCSV.codPlanilla);
}

function clickBtnSalirRetornarViatico() {
	
	removeEventElementsConsultarSolicitud();
	hideModalElement( 'divConsultarSolicitudModal' );
}

function clickBtnAdjuntarViatico() {

	var tieneAdjuntos = configCSV.registroVO.tieneArchivoAdjunto == 'si';

	if ( tieneAdjuntos ) {

		var dataParametrosArchivo = new Object();
		
		dataParametrosArchivo.codigoBoleto = ''; 	  			// codigo vaucher 00000901
		dataParametrosArchivo.estadoOrigen = 'V';			  	// V: viatico
		dataParametrosArchivo.estadoLLamada = 'C'; 				// C: consulta, R: registro, CE: consulta con evento cerrar
		dataParametrosArchivo.numeroRegistroColaborador = configCSV.nroRegistro;
		dataParametrosArchivo.planViajeId = configCSV.codPlanViaje;
		dataParametrosArchivo.paginaOrigen = 'PRINCIPAL';		// PRINCIPAL O SECUNDARIA(VAUCHER) 
		
		initElementsConsultarRegistrarEliminarArchivo(dataParametrosArchivo);
		$("#divAdjuntarDocumento").modal("show");
		triggerResizeEvent();	

	} else {

		showMensaje( 'Esta solicitud no tiene documentos adjuntos asociados' );
	}
	
}

function clickBtnAdjuntarViaticoHideShowModalArchivo() {

	// cerrar el modal actual (consultar solicitud) 
	hideModalElement( 'divConsultarSolicitudModal' );
	
	// abrir el modal de consultar archivo adjunto
	setTimeout(function() {
		
		// falta invocar al after close ventana de consulta
		var dataParametrosArchivo = new Object();
		
		dataParametrosArchivo.codigoBoleto = ''; 	  				// codigo vaucher 00000901
		dataParametrosArchivo.estadoOrigen = 'V';			  		// V: viatico
		dataParametrosArchivo.estadoLLamada = 'CE'; 				// C: consulta, R: registro, CE: consulta con evento cerrar
		dataParametrosArchivo.numeroRegistroColaborador = configCSV.nroRegistro;
		dataParametrosArchivo.planViajeId = configCSV.codPlanViaje;
		dataParametrosArchivo.paginaOrigen = 'PRINCIPAL';			// PRINCIPAL O SECUNDARIA(VAUCHER) 
		
		// personalizar el cerrar del consultar
		adjuntarDocumentoService = new AdjuntarDocumentoService(function() { }, function() { }, functionAfterCloseConsultarArchivo);	
		
		initElementsConsultarRegistrarEliminarArchivo(dataParametrosArchivo);
		$("#divAdjuntarDocumento").modal("show");
		triggerResizeEvent();			
		
	}, 200);

}

function functionAfterCloseConsultarArchivo() {

	// abrir el modal actual (consultar solicitud)
	setTimeout(function() {
		
		showModalElement( 'divConsultarSolicitudModal' );
		triggerResizeEvent();
		
	}, 550);
	
}

function limpiarSeccionesConsultarSolicitud() {

	// deshabilitando todo
	$( '#divConsultarSolicitudModal' ).find( 'input, button, select' ).each(function(i, item) {
		$(item).prop( 'disabled', true );
	});		
	
	// limpiando todos los inputs
	$( '#divConsultarSolicitudModal' ).find( 'input' ).each(function(i, item) {
		$(item).val( '' );
	});
	
	setValueInputText( 'selDepartamento', '00' );
	setValueInputText( 'selProvincia', '00' );

	limpiarSeccionIVDesplazamientos();
	limpiarSeccionVAsignaciones();	
}
 

function poblarControlesConsultarSolicitud() {
	
	// deshabilitar controles
	$( '#divConsultarSolicitudModal' ).find( 'button, select, input' ).prop( 'disabled', true );
	
	$( '#btnAdjuntarViatico' ).prop( 'disabled', false );
	$( '#btnImprimirViatico' ).prop( 'disabled', false );
	$( '#btnSalirRetornarViatico' ).prop( 'disabled', false );

	// botones de consultar asistencia
	$( '#btnConsultarAsistenciaNacMay4h' ).prop( 'disabled', false );
	$( '#btnConsultarAsistenciaNacMen4h' ).prop( 'disabled', false );
	$( '#btnConsultarAsistenciaInt' ).prop( 'disabled', false );
	$( '#btnCerrarReporteAsistencia' ).prop( 'disabled', false );
	
	var esRegistrador = configCSV.esRegistrador;
	var esConfiguracionAutomatica = configCSV.registroVO.tipoConfiguracion == '02';
	
	// El boton imprimir en configuracion automatica, se mostrara solo para el perfil registrador.
	var mostrarImprimir = true;
	if ( esConfiguracionAutomatica && !esRegistrador ) {
		mostrarImprimir = false;
	}
	
	// TODO/FIXME: caso particular, siempre muestra en bandeja revision.
	//             esto luego va cambiar cuando modifiquen el documento.
	if ( mostrarImprimir || configCSV.origen == 'bandeja-revision-solicitud' ) {
		$( '#divImprimirViatico' ).show();	
	} else {
		$( '#divImprimirViatico' ).hide();
	}
	
	// seteando todos los input
	$( '#divConsultarSolicitudModal' ).find( 'input' ).each(function(i, item) {
		var control = $(item);		
		control.val( configCSV.registroVO[control.prop('name')] );		
	});

	// llenando los combos
	fillComboFromJSON('#selDepartamento', configCSV.registroVO.departamentoList, 'codiDepaDpt', 'nombDptoDpt');
	fillComboFromJSON('#selProvincia', configCSV.registroVO.provinciaList, 'codiProvTpr', 'nombProvTpr');
	
	// setear campos seccion II
	$( '#selTipoViatico' ).val( configCSV.registroVO.tipoViatico );
	$( '#selDuracionComision' ).val( configCSV.registroVO.duracionComision );
	
	// setear campos seccion III
	$( '#selDepartamento' ).val( configCSV.registroVO.departamento );
	$( '#selProvincia' ).val( configCSV.registroVO.provincia );
	
	// setear campos seccion IV, seccion V (grillas)
	setInitDesplazamientoTableRSV();
	setInitAsignacionTableRSV();

	// actualizar estado vista
	updateDivsDetalleViatico();

	setTimeout(function() {
		updateEstructuraTablaDesplazamientos();
		triggerResizeEvent();
	}, 200);


	// al final volver a invocar el resize de las tablas mostradas al inicio
	setTimeout( function() {
		
		resizeTable("tblDesplazamientoRSV");
	}, 800 );		
} 
  
function callAjaxObtenerDatosViaticoConsultarSolicitud( codPlanilla ) {

	// traer la informacion de la solicitud del servidor (plan viaje, asignaciones y desplazamientos)
	$.ajax({
		url: contextPathUrl + "/registrarSolicitud.htm?action=obtenerDatosViaticoConsultarSolicitud",
		type: "post",
		dataType: "json",
		cache: false,
		data: {
			"codPlanilla": codPlanilla
		},
		beforeSend: function() {
			$( '#divLoadingConsulta' ).show();
		},
		complete: function() {
			$( '#divLoadingConsulta' ).hide();
		},
		success: function(result) {

			if ( huboErrorAjax( result ) ) {
				consoleLog( 'error app callAjaxObtenerDatosViaticoConsultarSolicitud ' + result.msgError );
				return;
			}
			
			// modelo vista: configCSV.registroVO
			configCSV.registroVO = result.registroVO;
			configCSV.codPlanViaje = result.registroVO.codPlanViaje;
			configCSV.nroRegistro = result.registroVO.numeroRegistro;
			
			poblarControlesConsultarSolicitud();
			
			var codPlanilla = result.registroVO.codPlanilla;
			var codEstado = result.registroVO.codigoEstadoViatico;
			
			habilitarBtnImprimir(codPlanilla,codEstado);

		},
		error: function() {
			consoleLog( 'error callAjaxObtenerDatosViaticoConsultarSolicitud' );
		}
	});
}

function fillComboFromJSON(selectID, dataJSON, campoCodigo, campoDescripcion) {
	
	if (dataJSON == null) return;
	
	var selectControl = $(selectID);

	$.each(dataJSON, function(i, item) {
		$('<option>').val(item[campoCodigo]).text(item[campoDescripcion]).appendTo(selectControl);
	});
	
}
 

function limpiarSeccionIVDesplazamientos() {
	clearGridDesplazamientos();
	updateTotalDesplazamientos();
}

function limpiarSeccionVAsignaciones() {
	clearGridAsignaciones();
	updateTotalAsignaciones();
}


function clearGridDesplazamientos() {
	$( '#tblDesplazamientoRSV' ).clearGridData();
}

function clearGridAsignaciones() {
	$( '#tblAsignacionRSV' ).clearGridData();
}


// llena una grilla general
function fillGrilla( tableID, lista ) {

	// que tableID y lista esten definidos
	if ( !estaDefinido( tableID ) || !estaDefinido( lista ) ) return;

	var table = $( tableID );
	if ( table ) {

		table.clearGridData();

		if (lista != null && lista.length > 0) {

			for (var i = 0; i < lista.length; i++) {

				var datarow = lista[i];

				// agrega el campo nro con una secuencia
				datarow.nro = String(i + 1);

				table.jqGrid("addRowData", datarow.nro, datarow);
			}

			table.trigger("reloadGrid");

		}

	}

}

// manejo de grillas
function setInitDesplazamientoTableRSV() {

	var table = $( '#tblDesplazamientoRSV' );
	if (table) {
		var tableDiv = $("#divDesplazamientoTableRSV");
		var widthTable = tableDiv.width();
		table.jqGrid({
			width: widthTable,
			height: 'auto',
			minHeight: 150,
			autowidth: true,
			datatype: "local",
			cmTemplate: {sortable: false},
			colNames: [
				"N&deg;",							// todos
				"Medio de transporte",				// todos
				"Departamento",						// nacional
				"Provincia",						// nacional
				"Lugar del Destino",				// internacional						(hidden condicional)
				"D&iacute;as de Vi&aacute;ticos",	// nacional > 4 horas, e internacional	(hidden condicional)
				"Horas de vi&aacute;tico",			// nacional <= 4horas					(hidden condicional)
				"Importe diario",					// todos
				"Importe vi&aacute;tico",			// todos
				"D&iacute;as de traslado",			// internacional			(hidden condicional)
				"Viaje Ext/Gto. Trasl.",			// internacional			(hidden condicional)
				"Total Otorgado",					// internacional			(hidden condicional)
				"<img border='0' title='eliminar' width='15' height='15' src='/a/imagenes/sigad/acciones/delete.png'>",
				"codigoMedioTransporte", 			// todos hidden
				"codigoProvincia",					// nacional hidden
				"codigoDepartamento",				// nacional hidden
				"codigoLugar",						// nacional hidden
				"codigoLugarDestino", 				// internacional hidden
				"importeDiarioTope",				// todos hidden
				"diasTrasladoTope",                 // internacional hidden
				"codigoTarifario",                  // internacional hidden
				"porcentajeTarifario",              // internacional hidden
				"viajeExtGtoTrasTope"               // internacional hidden
			],
			colModel: [
				{name: "nro", index: "nro", width: (0.5*widthTable/12), align: "center"},										// todos
				{name: "medioTransporte", index: "medioTransporte", width: (1.5*widthTable/12), align: "center"},				// todos
				{name: "departamento", index: "departamento", width: (1.6*widthTable/12)},										// nacional
				{name: "provincia", index: "provincia", width: (1.6*widthTable/12)},											// nacional
				{name: "lugarDestino", index: "lugarDestino", width: (1.6*widthTable/12), hidden: true},						// internacional
				{name: "diasViatico", index: "diasViatico", width: (1.1*widthTable/12), align: "center",
					formatter: function(cellvalue, options, rowData) {
						var nro = rowData.nro;
						var dias = toNumero( rowData.diasViatico );
						var rowJSON = JSON.stringify( rowData );

						var htmlElement = '<input disabled id="diasViatico_' + nro + '" value="' + dias + '" data-info=\'' + rowJSON + '\' maxlength="3" style="padding: 3px; margin: 3px; text-align:right; width: 90%;" >';

						return htmlElement;
					}
				},		// nacional > 4 horas, e internacional
				{name: "horasViatico", index: "horasViatico", width: (1.1*widthTable/12), align: "center", hidden: true,
					formatter: function(cellvalue, options, rowData) {

						var nro = rowData.nro;
						var horas = $.trim( rowData.horasViatico );

						// solo por moneria, si tiene digito decimal mostrarlo formatear a 1  decimal
						if ( horas.indexOf( '.' ) >= 0 ) {
							horas = roundString( toNumero( rowData.horasViatico ), 1 );	// formatear a 1 digito decimal
						}

						var rowJSON = JSON.stringify( rowData );

						var htmlElement = '<input disabled id="horasViatico_' + nro + '" value="' + horas + '" data-info=\'' + rowJSON + '\' maxlength="4" style="padding: 3px; margin: 3px; text-align:right; width: 90%;" >';

						return htmlElement;
					}

				},		// nacional <= 4horas
				{name: "importeDiario", index: "importeDiario", width: (1.2*widthTable/12), align: "right",
					formatter: function(cellvalue, options, rowData) {
						var nro = rowData.nro;
						var importe = toNumero( rowData.importeDiario );
						var monto = roundComasMilesString( importe, 2 );
						var rowJSON = JSON.stringify( rowData );

						var htmlElement = '<input disabled id="importeDiario_' + nro + '" value="' + monto + '" data-info=\'' + rowJSON + '\' maxlength="10" style="padding: 3px; margin: 3px; text-align:right; width: 90%;" >';

						return htmlElement;
					}
				},		// todos
				{name: "importeViatico", index: "importeViatico", width: (1.2*widthTable/12), align: "right",
					formatter: function(cellvalue, options, rowData) {
						var importe = toNumero( rowData.importeViatico );
						return roundComasMilesString( importe, 2 );
					}
				},		// todos
				{name: "diasTraslado", index: "diasTraslado", width: (1.1*widthTable/12), align: "center", hidden: true,
					formatter: function(cellvalue, options, rowData) {
						var nro = rowData.nro;
						var dias = toNumero( rowData.diasTraslado );
						var rowJSON = JSON.stringify( rowData );

						var htmlElement = '<input disabled id="diasTraslado_' + nro + '" value="' + dias + '" data-info=\'' + rowJSON + '\' maxlength="2" style="padding: 3px; margin: 3px; text-align:right; width: 90%;" >';

						return htmlElement;
					}
				},		// internacional
				{name: "viajeExtGtoTras", index: "viajeExtGtoTras", width: (1.1*widthTable/12), align: "right", hidden: true,

					formatter: function(cellvalue, options, rowData) {
						var nro = rowData.nro;
						var importe = toNumero( rowData.viajeExtGtoTras );
						var monto = roundComasMilesString( importe, 2 );
						var rowJSON = JSON.stringify( rowData );

						var htmlElement = '<input disabled id="viajeExtGtoTras_' + nro + '" value="' + monto + '" data-info=\'' + rowJSON + '\' maxlength="10" style="padding: 3px; margin: 3px; text-align:right; width: 90%;" >';

						return htmlElement;
					}
				},		// internacional
				{name: "totalOtorgado", index: "totalOtorgado", width: (1.1*widthTable/12), align: "right", hidden: true,
					formatter: function(cellvalue, options, rowData) {
						var importe = toNumero( rowData.totalOtorgado );
						return roundComasMilesString( importe, 2 );
					}
				}, 		// internacional
				{name: "eliminar", index: "eliminar", width: (0.5*widthTable/12), align: "center",								// todos
					formatter: function(cellValue, options, rowData) {
						var nro = rowData.nro;
						var rowJSON = JSON.stringify( rowData );
						var htmlElement = '<input disabled id="chkJqGridDesplazamiento' + nro + '" name="chkDesplazamientos" type="checkbox" value=\'' + rowJSON + '\' >';
						return htmlElement;
					}
				},
				{name: "codigoMedioTransporte", index: "codigoMedioTransporte", width: (1.0*widthTable/12), hidden: true},		// todos hidden
				{name: "codigoProvincia", index: "codigoProvincia", width: (1.0*widthTable/12), hidden: true},					// nacional hidden
				{name: "codigoDepartamento", index: "codigoDepartamento", width: (1.0*widthTable/12), hidden: true},			// nacional hidden
				{name: "codigoLugar", index: "codigoLugar", width: (1.0*widthTable/12), hidden: true},							// nacional hidden
				{name: "codigoLugarDestino", index: "codigoLugarDestino", width: (1.0*widthTable/12), hidden: true},			// internacional hidden
				{name: "importeDiarioTope", index: "importeDiarioTope", width: (1.0*widthTable/12), hidden: true},	     	    // todos hidden
				{name: "diasTrasladoTope", index: "diasTrasladoTope", width: (1.0*widthTable/12), hidden: true},		   	    // internacional hidden
				{name: "codigoTarifario", index: "codigoTarifario", width: (1.0*widthTable/12), hidden: true},		   	        // internacional hidden
				{name: "porcentajeTarifario", index: "porcentajeTarifario", width: (1.0*widthTable/12), hidden: true},		  	// internacional hidden
				{name: "viajeExtGtoTrasTope", index: "viajeExtGtoTrasTope", width: (1.0*widthTable/12), hidden: true}		  	// internacional hidden
			],
			pager : "#divDesplazamientoPagerTableRSV",
			loadui: "disable"
		});

		// actualizar lista de desplazamientos
		fillGrilla( '#tblDesplazamientoRSV', getDesplazamientosList() );
		updateTotalDesplazamientos();

	}
}

function setInitAsignacionTableRSV() {

	var table = $( '#tblAsignacionRSV' );
	if (table) {
		var tableDiv = $("#divAsignacionTableRSV");
		var widthTable = tableDiv.width();
		table.jqGrid({
			width: widthTable,
			height: 'auto',
			minHeight: 150,
			autowidth: true,
			datatype: "local",
			cmTemplate: {sortable: false},
			colNames: [
				"N&deg;",
				"Asignaci&oacute;n",
				"Importe Asignado",
				"<img border='0' title='eliminar' width='15' height='15' src='/a/imagenes/sigad/acciones/delete.png'>",
				"codigoAsignacion",			// hidden
				"clasificadorGasto",		// hidden
				"conceptoCantidadPVI",   	// hidden
				"tipoFijoPVI",              // hidden
				"editable"					// hidden
			],
			colModel: [
				{name: "nro", index: "nro", width: (0.3*widthTable/12), align: "center"},
				{name: "asignacion", index: "asignacion", width: (2.2*widthTable/12)},
				{name: "importeAsignado", index: "importeAsignado", width: (0.5*widthTable/12), align: "right",
					formatter: function(cellvalue, options, rowData) {

						var nro = rowData.nro;
						var editable = rowData.editable;
						var importe = toNumero( rowData.importeAsignado );
						var monto = roundComasMilesString( importe, 2 );
						var rowJSON = JSON.stringify( rowData );

						var result = '';

						if ( editable == 'si' ) {
							result = '<input disabled id="importeAsignado_' + nro + '" value="' + monto + '" data-info=\'' + rowJSON + '\' maxlength="9" style="padding: 3px; margin: 3px; text-align:right; width: 90%;" >';
						} else {
							result = '<span style="padding-right: 7px;">' + roundComasMilesString( importe, 2 ) + '</span>';
						}

						return result;
					}
				},
				{name: "eliminar", index: "eliminar", width: (0.3*widthTable/12), align: "center",
					formatter: function(cellValue, options, rowData) {
						var nro = rowData.nro;
						var rowJSON = JSON.stringify( rowData );
						var htmlElement = '<input disabled id="chkJqGridAsignaciones' + nro + '" name="chkAsignaciones" type="checkbox" value=\'' + rowJSON + '\'  >';

						return htmlElement;
					}
				},
				{name: "codigoAsignacion", index: "codigoAsignacion", width: (1*widthTable/12), hidden: true },     // hidden
				{name: "clasificadorGasto", index: "clasificadorGasto", width: (1*widthTable/12), hidden: true },	// hidden
				{name: "conceptoCantidadPVI", index: "cantidadPVI", width: (1*widthTable/12), hidden: true },	    // hidden
				{name: "tipoFijoPVI", index: "tipoFijoPVI", width: (1*widthTable/12), hidden: true },	            // hidden
				{name: "editable", index: "editable", width: (1*widthTable/12), hidden: true }					    // hidden
			],
			pager : "#divAsignacionPagerTableRSV",
			loadui: "disable"
		});

		// actualizar lista de asignaciones
		fillGrilla( '#tblAsignacionRSV', getAsignacionesList() );
		updateTotalAsignaciones();

	}
}

function updateTotalAsignaciones() {

	var asignaciones = getAsignacionesList();

	if ( !estaDefinido( asignaciones ) || asignaciones.length == 0 ) {
		$('#txtTotalAsignacionesCSV').val('');
	} else {
		var acumulador = 0;
		$.each(asignaciones, function(i, item) {
			acumulador = toNumero( item.importeAsignado ) + acumulador;
		});

		$('#txtTotalAsignacionesCSV').val( roundComasMilesString( acumulador, 2 ) );
	}

}

function updateTotalDesplazamientos() {

	var lista = getDesplazamientosList();

	if ( !estaDefinido( lista ) || lista.length == 0 ) {
		$('#txtTotalDesplazamientosCSV').val('');
	} else {
		var total = calcularTotalDesplazamientos();
		$('#txtTotalDesplazamientosCSV').val( roundComasMilesString( total, 2 ) );
	}
}

function calcularTotalDesplazamientos() {

	var acumulador = 0;
	var desplazamientos = getDesplazamientosList();

	$.each(desplazamientos, function(i, item) {

		if ( esNacional() ) {
			acumulador = toNumero( item.importeViatico ) + acumulador;
		} else { // si es internacional
			acumulador = toNumero( item.totalOtorgado ) + acumulador;
		}

	});

	return roundNumero( acumulador, 2 );
}

function getDesplazamientosList() {
	if ( !estaDefinido( configCSV ) || !estaDefinido( configCSV.registroVO ) )   return null;
	
	return configCSV.registroVO.desplazamientosList;
}

function getAsignacionesList() {
	if ( !estaDefinido( configCSV ) || !estaDefinido( configCSV.registroVO ) )   return null;
	
	return configCSV.registroVO.asignacionesList;
}
 
function esNacional() {
	var selTipoViatico = $('#selTipoViatico').val();
	return selTipoViatico == 'nacional';
}

function esInternacional() {
	var selTipoViatico = $('#selTipoViatico').val();
	return selTipoViatico == 'internacional';
}

function esMayor4h() {
	var selDuracionComision = $('#selDuracionComision').val();
	return selDuracionComision == 'may4h';
}

function esMenorIgual4h() {
	var selDuracionComision = $('#selDuracionComision').val();
	return selDuracionComision == 'men4h';
}
 
function updateDivsDetalleViatico() {

	// oculta o muestra los divs correspondientes a tipo de viatico nacional/internacional, y si es nacional mayor a 4horas o menor igual a 4horas
	if ( esNacional() ) {

		// cambia la moneda por defecto a soles
		// configRSV.moneda = configRSV.constantes.MONEDA_SOLES;
		// $('.lblMoneda').html( configRSV.moneda );
		$('.lblMonedaDesplazamientos').html( 'S/.' );
		$('.lblMonedaAsignaciones').html( 'S/.' );

		// ocultar/visualizar divs
		$('#divTipoDesplazamientoWrapper').show();
		$('#divNacionalWrapper').show();

		if ( esMayor4h() ) {

			// ocultar/visualizar divs
			$('#divInternacionalWrapper').hide();
			$('#divNacionalMayor4Wrapper').show();
			$('#divNacionalMenorIgual4Wrapper').hide();

		} else {	// si es menor o igual a 4 horas

			$('#divInternacionalWrapper').hide();
			$('#divNacionalMayor4Wrapper').hide();
			$('#divNacionalMenorIgual4Wrapper').show();
		}

	} else { // si es internacional

		// cambia la moneda por defecto a soles
		// configRSV.moneda = configRSV.constantes.MONEDA_DOLARES;
		// $('.lblMoneda').html( configRSV.moneda );
		$('.lblMonedaDesplazamientos').html( '($)' );
		$('.lblMonedaAsignaciones').html( '$' );

		$('#divTipoDesplazamientoWrapper').hide();
		$('#divNacionalWrapper').hide();

		$('#divInternacionalWrapper').show();
		$('#divNacionalMayor4Wrapper').hide();
		$('#divNacionalMenorIgual4Wrapper').hide();

	}

	updateEstructuraTablaDesplazamientos();

}


function updateEstructuraTablaDesplazamientos() {

	// actualiza la estructura de columnas de la tabla desplazamientos
	// segun el tipo de viatico (nacional, internacional) y duracion de comision (> 4horas, <= 4horas)
	var table = $('#tblDesplazamientoRSV');

	if ( esNacional() ) {

		// ocultar
		table.jqGrid("hideCol", "lugarDestino");
		table.jqGrid("hideCol", "diasTraslado");
		table.jqGrid("hideCol", "viajeExtGtoTras");
		table.jqGrid("hideCol", "totalOtorgado");

		// mostrar
		table.jqGrid("showCol", "departamento");
		table.jqGrid("showCol", "provincia");


		if ( esMayor4h() ) {

			table.jqGrid("hideCol", "horasViatico");
			table.jqGrid("showCol", "diasViatico");

		} else {	// si es menor o igual a 4 horas

			table.jqGrid("hideCol", "diasViatico");
			table.jqGrid("showCol", "horasViatico");
		}


	} else { // si es internacional

		// ocultar
		table.jqGrid("hideCol", "departamento");
		table.jqGrid("hideCol", "provincia");
		table.jqGrid("hideCol", "horasViatico");

		// mostrar
		table.jqGrid("showCol", "lugarDestino");
		table.jqGrid("showCol", "diasTraslado");
		table.jqGrid("showCol", "viajeExtGtoTras");
		table.jqGrid("showCol", "totalOtorgado");
		table.jqGrid("showCol", "diasViatico");

	}

	triggerResizeEvent();

}

function removeEventElementsConsultarSolicitud() {
	
	removeAllEventsElement("btnAdjuntarViatico");
	removeAllEventsElement("btnImprimirViatico");
	removeAllEventsElement("btnSalirRetornarViatico");	
}

$(window).on("resize", function() {

	resizeTable("tblDesplazamientoRSV");
	resizeTable("tblAsignacionRSV");

	// Inicializando las tablas de los modales
	resizeTable("tblDestino");
	resizeTable("tblColaborador");
	resizeTable("tblConceptoViatico");
	resizeTable("tblCadenaPresupuestal");
	resizeTable("tblVacaciones");
	resizeTable("tblCompensaciones");
	resizeTable("tblLicencias");

});
