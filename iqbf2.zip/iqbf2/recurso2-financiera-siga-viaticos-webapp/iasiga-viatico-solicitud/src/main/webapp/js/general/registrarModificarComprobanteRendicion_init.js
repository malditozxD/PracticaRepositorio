var parametros = new Object();
var validaEstadoGeneral = 0;
var tituloRendicion = " ";
var validaEstadoFechaGeneral = 0;
var conceptoViaticosListGeneral;
var monedaViatico;
function initElementsRegistrarModificarComprobanteRendicion(dataParametrosComprobante) {
	
	parametros.planViajeId = dataParametrosComprobante.planViajeId;
	parametros.secuencial = dataParametrosComprobante.secuencial;
	parametros.estadoLlamada = dataParametrosComprobante.estadoLlamada;
	parametros.origenLlamada = dataParametrosComprobante.origenLlamada;
	parametros.saldoRendir = dataParametrosComprobante.saldoRendir;
	parametros.numeroRegistroColaborador = dataParametrosComprobante.numeroRegistroColaborador;
	removeDuplicateComponents();
	
	if(parametros.estadoLlamada == "C"){
		setTextLabel("tituloComprobante", errorMessageRegistrarComprobante.tituloComprobanteConsulta);}
	else{
		setTextLabel("tituloComprobante", errorMessageRegistrarComprobante.tituloComprobante);}
	
	setInitElementsRegistrarModificarComprobanteRendicion();

	callObtenerDocumentoSustentario(parametros);
	
	setInitDatosRendicionTable();
	setInitDatosComprobantePagoTable();


	$("#divDatosRendicionTable").attr("style", "height: 135px;");
			
}

function setInitElementsRegistrarModificarComprobanteRendicion() {	
	addEventElement("btnCerrarComprobante", "click", clickBtnCerrarComprobante);
	addEventElement("btnGrabarComprobante", "click", clickBtnGrabarComprobante);
	addEventElement("btnGrabarAuxComprobante", "click", clickBtnGrabarAuxComprobante);
	addEventElement("btnCerrarAuxComprobante", "click", clickBtnCerrarAuxComprobante);
	addEventElement("btnSiMensajeComprobante", "click", clickBtnSiMensajeComprobante);
	addEventElement("btnNoMensajeComprobante", "click", clickBtnNoMensajeComprobante);
	addEventElement("btnAceptarMensajeComprobante", "click", clickBtnAceptarMensajeComprobante);
	addEventElement("btnAceptarMensajeWarningComprobante", "click", clickBtnAceptarMensajeWarningComprobante);
	addEventElement("btnAceptarMensajeErrorComprobante", "click",  clickBtnAceptarMensajeErrorComprobante);
	addEventElement("etiquetaFechaDocumentoComprobante", "change", changeEtiquetaFechaDocumentoComprobante);
	addEventElement("selTipoDocumentoComprobante", "change", changeSelTipoDocumentoComprobante);
	addEventElement("selTipoConceptoComprobante", "change", changeSelTipoConceptoComprobante);
	//addEventElement("selTipoConceptoComprobante", "click", changeSelTipoConceptoComprobante);
	//initDateTimePicker("etiquetaFechaDocumentoComprobanteDiv", "dp.change", "changeDate", changeDateEtiquetaFechaDocumentoComprobanteDiv);
	initDateTimePickerUseCurrent("etiquetaFechaDocumentoComprobanteDiv", "dp.change", "changeDate", changeDateEtiquetaFechaDocumentoComprobanteDiv, false );
	setValueInputText("txtSecuenciaComprobante","");
	setValueInputText("etiquetaFechaDocumentoComprobante","");
	//
	$("#etiquetaFechaDocumentoComprobante").trigger("change");
	setTextValueTipoDocumentoComprobante();
	
}

function setInitDatosRendicionTable() {
	var datosRendicionTable = $("#tblDatosRendicion");
	var heightJqGrid = 60;
	setStyleElement("divDatosRendicionTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 1, true));
	if (datosRendicionTable) {
		var datosRendicionTableDiv = $("#divDatosRendicionTable");
		var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.viaticoModalContainer", ".viaticoModalContainerAuxiliar", "width"))/100);
		var widthTable = factorRedimensionamiento*datosRendicionTableDiv.width();
		datosRendicionTable.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			datatype: "local",
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
			    "indice",
				"Moneda",
				"Valor Venta",
				"Monto Base",
				"I.G.V.",
				"-",
				"Exenci&oacute;n I.G.V.",
				"-",
				"Otros Gastos",
				"Valor Total",
				"Monto Total",
				"indAfectoIgv"
			],
			colModel: [
			    {name: "indice", index: "indice", width: (1*widthTable/20), hidden: true},
				{name: "moneda", index: "moneda", width: (2*widthTable/20), align: 'center',
			    	formatter:function(cellvalue, options, rowData){
			    		var moneda=rowData.moneda;
			    		var htmlElement ='<span  id="monedaRendicion">'+moneda+'</span>';
			    		return htmlElement;
			    	}
			    },
				{name: "valorVenta", index: "valorVenta", width: (4*widthTable/20),align: 'right',
					formatter:function(cellvalue, options, rowData){
						var valorVenta=rowData.valorVenta;
						var htmlElement = '<input oncopy="return false" oncut="return false" onpaste="return false" style="text-align: right;" id="valorVenta" onkeypress="return validarCharacterCurrency(event);"  onChange="javascript:onBlurMonto(this);" data-tipo="VV" value="'+valorVenta+'"/ >';
						return htmlElement;
					}	
				},
				{name: "montoBase", index: "montoBase", width: (4*widthTable/20),align: 'right',
					formatter:function(cellvalue, options, rowData){
						var montoBase=rowData.montoBase;
						var htmlElement = '<input oncopy="return false" oncut="return false" onpaste="return false" style="text-align: right; " id="montoBase" onkeypress="return validarCharacterCurrency(event);"  onChange="javascript:onBlurMonto(this);" data-tipo="MB" value="'+montoBase+'"/ >';
						return htmlElement;
					}	
				},
				{name: "igv", index: "igv", width: (3*widthTable/20), align: 'right',
					formatter:function(cellvalue, options, rowData){
						var igv = rowData.igv;
						var htmlElement = '<span id="igv">'+igv+'</span>';
						return htmlElement;
					}
				},
				{name: "cero", index: "cero", width: (3*widthTable/20), align: 'right',
					formatter:function(cellvalue, options, rowData){
						var cero = rowData.cero;
						var htmlElement = '<span id="cero">'+cero+'</span>';
						return htmlElement;
					}
				},
				{name: "exoneracionIgv", index: "exoneracionIgv", width: (4*widthTable/20),align: 'center',
					formatter:function(cellvalue, options, rowData){
						var htmlElement = '<select id="exoneracionIgv"  onchange="cambioIgv();" style="width: 100%;">';												
							for(var i = 0; i< rowData.exoneracionIgv.length ; i++){
								var codigoArgumento = $.trim(rowData.exoneracionIgv[i].cod_argumento);
								var nombreCorto = $.trim(rowData.exoneracionIgv[i].nom_corto);
									htmlElement = htmlElement + '<option  value="'+codigoArgumento+'">'+nombreCorto+'</option>';
							}						
							htmlElement=htmlElement+'</select>';
							//var htmlElement = '<select id="exoneracionIgv"><option  value="01">fuera</option><option  value="01">fuera</option></select>';	
							
						return htmlElement;
					}		
				},
				{name: "exoneracionFija", index: "exoneracionFija", width: (4*widthTable/20),align: 'center',
					formatter:function(cellvalue, options, rowData){
						
						var indAfectoIgv = "I"
						var htmlElement = '<select id="exoneracionFija" disabled>';							
							for(var i = 0; i< rowData.exoneracionIgv.length ; i++){
								var codigoArgumento = $.trim(rowData.exoneracionIgv[i].cod_argumento);
								var nombreCorto = $.trim(rowData.exoneracionIgv[i].nom_corto);
								if (codigoArgumento == indAfectoIgv)
									htmlElement = htmlElement + '<option   value="'+codigoArgumento+'">'+nombreCorto+'</option>';
							}						
							htmlElement=htmlElement+'</select>';
							
						return htmlElement;
					}
				},
				{name: "otroGasto", index: "otroGasto", width: (4*widthTable/20),align: 'right',
					formatter:function(cellvalue, options, rowData){
						var otroGasto=rowData.otroGasto;
						var htmlElement = '<input oncopy="return false" oncut="return false" onpaste="return false" style="text-align: right;" id="otroGasto" onkeypress="return validarCharacterCurrency(event);"  onChange="javascript:onBlurMonto(this);" data-tipo="OG" value="' + otroGasto + '"/ >';
						return htmlElement;
					}	},
				{name: "valorTotal", index: "valorTotal", width: (4*widthTable/20), align: 'center',
					formatter:function(cellvalue, options, rowData){
					var valorTotal=rowData.valorTotal;
					var htmlElement = '<input oncopy="return false" oncut="return false" onpaste="return false" style="text-align: right;" id="valorTotal" onkeypress="return validarCharacterCurrency(event);"  onChange="javascript:onBlurMonto(this);" data-tipo="VT" style="font-align :right;" value="' + valorTotal + '"/ >';
					return htmlElement;
					}	
				},
				{name: "montoTotal", index: "montoTotal", width: (4*widthTable/20), align: 'center',
						formatter:function(cellvalue, options, rowData){
							var montoTotal=rowData.montoTotal;
							var htmlElement = '<input oncopy="return false" oncut="return false" onpaste="return false" style="text-align: right;" id="montoTotal" onkeypress="return validarCharacterCurrency(event);"  onChange="javascript:onBlurMonto(this);" style="font-align :right;" data-tipo="MT"  value="' + montoTotal + '"/ >';
							return htmlElement;
						}	
				},
				{name: "indAfectoIgv", index: "indAfectoIgv", width: (5*widthTable/20), align: 'center', hidden:true}
				
					
			],
			
			caption: "Datos de la rendici&oacute;n",
			//pager: "#divDatosRendicionPagerTable",
			loadui: "disable"
		});
		//datosRendicionTable.clearGridData();
	}
}

function setInitDatosComprobantePagoTable() {
	var datosComprobantePagoTable = $("#tblDatosComprobantePago");
	var heightJqGrid = 90;
	setStyleElement("divDatosComprobantePagoTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 1, true));
	if (datosComprobantePagoTable) {
		var datosComprobantePagoTableDiv = $("#divDatosComprobantePagoTable");
		var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.viaticoModalContainer", ".viaticoModalContainerAuxiliar", "width"))/100);
		var widthTable = factorRedimensionamiento*datosComprobantePagoTableDiv.width();
		datosComprobantePagoTable.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			datatype: "local",
			autowidth: true,
			rowNum:360,
			cmTemplate: {sortable: false},
			colNames: [
			    "indice",
				"Fecha",
				"Alimentaci&oacute;n",
				"Hospedaje",
				"Movilidad",
				"Traslado",
				"Total",
				"fechaDDMMYYYY",
				"rendicionFechaRendicion",
				"rendicionFechaRendicionSinFormato"
			],
			colModel: [
			    {name: "indice", index: "indice", width: (4*widthTable/20), hidden: true},
				{name: "fechaViatico", index: "fechaViatico", width: (5*widthTable/20), align: 'center',
			    	formatter:function(cellvalue, options, rowData){
						var fechaViatico = rowData.fechaViatico;
						var fechaDDMMYYYY = rowData.fechaDDMMYYYY;
						var rendicionFechaRendicion = rowData.rendicionFechaRendicion;
						var rendicionFechaRendicionSinFormato = rowData.rendicionFechaRendicionSinFormato;
						
						var htmlElement = '';
						
						//Cuando
						var idComprobante = getValueInputText("selTipoComprobante");
						var idSelectorConcepto = getValueInputText("selTipoConceptoComprobante");
						if(idSelectorConcepto=='01' && fechaViatico!='Total'){
							htmlElement = '<span  id="fechaViatico_'+fechaDDMMYYYY+'" class="fechaViatico">'+fechaViatico+
							'</span><span style=" color: rgb(68, 157, 165); display: block;" id="rendicionFechaRendicion_'+fechaDDMMYYYY+
							'"  class="rendicionFechaRendicion" data-montofechaformater="'+rendicionFechaRendicion+'" data-montofechasinformater="'+rendicionFechaRendicionSinFormato+
							'" >Mto m&aacute;x por D&iacute;a ('+rendicionFechaRendicion+')</span>';	
						}else{
							htmlElement = '<span  id="fechaViatico_'+fechaDDMMYYYY+'" class="fechaViatico">'+fechaViatico+
							'</span><input type="hidden" id="rendicionFechaRendicion_'+fechaDDMMYYYY+
							'"  class="rendicionFechaRendicion" data-montofechaformater="'+rendicionFechaRendicion+'" data-montofechasinformater="'+rendicionFechaRendicionSinFormato+
							'" />';
						}
						
						return htmlElement;
					}
			    },
				{name: "alimentacion", index: "alimentacion", width: (3*widthTable/20), align: 'center',
					formatter:function(cellvalue, options, rowData){
						var alimentacion = rowData.alimentacion;
						var fechaViatico = rowData.fechaDDMMYYYY;
						var htmlElement = '<input oncopy="return false" oncut="return false" onpaste="return false" style="text-align: right; width: 95%;" onkeypress="return validarCharacterCurrency(event);"  onChange="javascript:onBlurGastoItinerario(this);" id="alimentacion_'+fechaViatico+'" class="alimentacion" value="'+alimentacion+'"/ >';
						return htmlElement;
					}				
				},
				{name: "hospedaje", index: "hospedaje", width: (3*widthTable/20), align: 'center',
					formatter:function(cellvalue, options, rowData){
						var hospedaje = rowData.hospedaje;
						var fechaViatico = rowData.fechaDDMMYYYY;
						var htmlElement = '<input oncopy="return false" oncut="return false" onpaste="return false" style="text-align: right; width: 95%;" onkeypress="return validarCharacterCurrency(event);"  onChange="javascript:onBlurGastoItinerario(this);" id="hospedaje_'+fechaViatico+'" class="hospedaje" value="'+hospedaje+'"/ >';
						return htmlElement;
					}
				},
				{name: "movilidad", index: "movilidad", width: (3*widthTable/20), align: 'center',
					formatter:function(cellvalue, options, rowData){
						var movilidad = rowData.movilidad;
						var fechaViatico = rowData.fechaDDMMYYYY;
						var htmlElement = '<input oncopy="return false" oncut="return false" onpaste="return false" style="text-align: right; width: 95%;"  onkeypress="return validarCharacterCurrency(event);"  onChange="javascript:onBlurGastoItinerario(this);" id="movilidad_'+fechaViatico+'" class="movilidad" value="'+movilidad+'"/ >';
						return htmlElement;
					}				
				},
				{name: "translado", index: "translado", width: (3*widthTable/20), align: 'center',
					formatter:function(cellvalue, options, rowData){
						var translado = rowData.translado;
						var fechaViatico = rowData.fechaDDMMYYYY;
						var htmlElement = '<input oncopy="return false" oncut="return false" onpaste="return false" style="text-align: right; width: 95%;"  onkeypress="return validarCharacterCurrency(event);"  onChange="javascript:onBlurGastoItinerario(this);" id="translado_'+fechaViatico+'" class="translado"  value="'+translado+'"/ >';
						return htmlElement;
					}
				},
				{name: "total", index: "total", width: (3*widthTable/20), align: 'right',
					formatter:function(cellvalue, options, rowData){
						var total = rowData.total;
						var fechaViatico = rowData.fechaDDMMYYYY;
						var htmlElement = '<span  id="total_'+fechaViatico+'" class="total">'+total+'</span>';
						return htmlElement;
					}
				},
				{name: "fechaDDMMYYYY", index: "fechaDDMMYYYY", width: (4*widthTable/20), align: 'center', hidden:true},
				{name: "rendicionFechaRendicion", index: "rendicionFechaRendicion", width: (5*widthTable/20), align: 'center', hidden:true},
				{name: "rendicionFechaRendicionSinFormato", index: "rendicionFechaRendicionSinFormato", width: (5*widthTable/20), align: 'center', hidden:true}
			],
			caption: "Datos del comprobante de pago",
			
			loadui: "disable",
			
			footerrow: true,
			loadComplete: function () {
			    $(this).jqGrid('footerData','set',
			        {fechaViatico:'Total', alimentacion:'' , hospedaje:'', movilidad:'',
			    	translado:'', total:''});
			    //Aquí se crean las variables total_undefined, alimentacion_undefined.. como totalizadores...
			    setHtmlElement("total_undefined", "0.00");//Inicializamos en cero el total de totales.
			}
			
		});
		datosComprobantePagoTable.clearGridData();
	}
}