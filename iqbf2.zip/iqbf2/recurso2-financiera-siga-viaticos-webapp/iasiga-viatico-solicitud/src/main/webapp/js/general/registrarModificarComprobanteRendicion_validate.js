function validarMontoBaseValorVenta(estadoLLamada){
	removeElement("idMensaje");
	var valorVenta = getValueInputText("valorVenta");
	var montoBase = getValueInputText("montoBase");	
	valorVenta = valorVenta.replace(/,/g , '');
	montoBase = montoBase.replace(/,/g , '');	
	var montoTotal = getValueInputText("montoTotal");
	montoTotal = montoTotal.replace(/,/g , '');	
	var valorTotal = getValueInputText("valorTotal");
	valorTotal = valorTotal.replace(/,/g , '');	
	consoleLog("montoBase: " + montoBase);
	var estadoInternoValidar=false;
	if (getValueInputText("selTipoDocumentoComprobante") == "907" || 
	    	getValueInputText("selTipoDocumentoComprobante") == "906" || getValueInputText("selTipoDocumentoComprobante") == "916" ){
		removeElement("idMensaje");
		if(parseFloat(montoBase)==0 && (estadoLLamada == "MB" || estadoLLamada == "OG")){
		  var mensaje = '<div id="idMensaje" class="colorFontRedTableClass">'+errorMessageRegistrarComprobante.montoMayorCero+'</div>';
		  validarDatosRendicion(mensaje);
		  validaEstadoGeneral = 0;
		  estadoInternoValidar = false;
		}else{
			validaEstadoGeneral = 1;
			estadoInternoValidar = true;
		}
		
		if(estadoInternoValidar){
			if(parseFloat(montoTotal) == 0 && estadoLLamada == "MT"){
				removeElement("idMensaje");
				var mensaje = '<div id="idMensaje" class="colorFontRedTableClass">'+errorMessageRegistrarComprobante.montoTotalMayorCero+'</div>';
					consoleLog("mensaje samuel: " + mensaje);
				validarDatosRendicion(mensaje);
				validaEstadoGeneral = 0;
			}else{
				validaEstadoGeneral = 1;
			}
		}
		 
	}else{
		removeElement("idMensaje");
		if(parseFloat(valorVenta)==0 && (estadoLLamada == "VV" || estadoLLamada == "OG")){
			  var mensaje = '<div id="idMensaje" class="colorFontRedTableClass">'+errorMessageRegistrarComprobante.mayorCero+'</div>';
			  validarDatosRendicion(mensaje);
			  validaEstadoGeneral = 0;
			  estadoInternoValidar = false;
		}else{
			validaEstadoGeneral = 1;
			estadoInternoValidar = true;
		}
		if(estadoInternoValidar){
			if(parseFloat(valorTotal) == 0 && estadoLLamada == "VT"){
				removeElement("idMensaje");
				var mensaje = '<div id="idMensaje" class="colorFontRedTableClass">'+errorMessageRegistrarComprobante.mayorCeroTotal+'</div>';
				validarDatosRendicion(mensaje);
				validaEstadoGeneral = 0;
			}else{
				validaEstadoGeneral = 1;
			}
		}
	}
	return validaEstadoGeneral;
}
//SI 
function validarOtroGastoMayorMontoTotal(){
	removeElement("idMensaje");
	var otroGasto = getValueInputText("otroGasto");
	var valorTotal = getValueInputText("valorTotal");
	var montoTotal = getValueInputText("montoTotal");
	valorTotal = valorTotal.replace(/,/g , '');	
	montoTotal = montoTotal.replace(/,/g , '');	
	otroGasto = otroGasto.replace(/,/g , '');
	var  estado = 0;
	if (getValueInputText("selTipoDocumentoComprobante") == "907" || 
	    	getValueInputText("selTipoDocumentoComprobante") == "906" || getValueInputText("selTipoDocumentoComprobante") == "916" ){
		 if(parseFloat(otroGasto) > parseFloat(montoTotal)){
			  var mensaje = '<div id="idMensaje" class="colorFontOrangeClass">'+errorMessageRegistrarComprobante.datosRendicion+'</div>';
			  validarDatosRendicion(mensaje);
			  estado = 0;
		 }else{
			 estado = 1;
		 }
	}
	else{
		if(parseFloat(otroGasto) > parseFloat(valorTotal)){
			  var mensaje = '<div id="idMensaje" class="colorFontOrangeClass">'+errorMessageRegistrarComprobante.datosRendicion+'</div>';
			  validarDatosRendicion(mensaje);
			  estado = 0;
		 }else{
			estado = 1;
		 } 
	}
return estado;
}

function validarMontoxAsignacion(){	
		var montoxTotalAsignacion = getDataAttributeSelect("selTipoConceptoComprobante", "data-monto");
		var montoDeclaracion = getDataAttributeSelect("selTipoConceptoComprobante", "data-montoDeclaracion");
		montoxTotalAsignacion = roundNumero(montoxTotalAsignacion,2);
		var montoTotalDistribucion = getValueText("total_undefined");
		montoTotalDistribucion = montoTotalDistribucion.replace(/,/g , '');	
		montoTotalDistribucion =  parseFloat(montoTotalDistribucion);
		hideElement("divErrorDatosComprobantePagoDistrib");
		hideElement("divErrorDatosComprobantePago");
		
		var monedaViatico =  getValueInputText("monedaViatico");
		
		var montoRendicion = getValueInputText("valorTotal");
		montoRendicion = montoRendicion.replace(/,/g , '');	
		montoRendicion =  parseFloat(montoRendicion);
		
		var montoTotalX1 = getValueInputText("montoTotal");

		if(getValueInputText("selTipoDocumentoComprobante") == "915" || getValueInputText("selTipoDocumentoComprobante")== "067"){
			montoTotalDistribucion = montoRendicion;
		}
		
		//Si el monto es mayor y se trata de una asignacion nacional o internacional
		//if((montoxTotalAsignacion < montoTotalDistribucion) && (parametros.origenLlamada == "V" || (parametros.origenLlamada == "R" && (getValueInputText("selTipoConceptoComprobante") == "01" || getValueInputText("selTipoConceptoComprobante") == "12" ))) ){
		if((montoxTotalAsignacion < montoTotalDistribucion) && (getValueInputText("selTipoConceptoComprobante") == "01" || getValueInputText("selTipoConceptoComprobante") == "12" )){
			  removeElement("idMensaje");
			  var mensaje = '<div id="idMensaje" class="colorFontRedTableClass">'+errorMessageRegistrarComprobante.distribuidoxAsignacion+'</div>';
			  showMessageErrorComprobante("etiquetaErrorDatosComprobantePagoxAsignacion", mensaje, "divErrorDatosComprobantePagoxAsignacion");
			  validaEstadoGeneral = 0;
		}else{
			hideElement("divErrorDatosComprobantePagoxAsignacion");
			validaEstadoGeneral = 1;
		}
		
		if(validaEstadoGeneral == 1){
			//Para el tipo de comprobante declaracion jurada de viaticos calcula con el monto total
			var montoTotalX2 = getValueInputText("montoTotal");
			if(getValueInputText("selTipoDocumentoComprobante") == "907"){
				var montoRendicion = getValueInputText("montoTotal");
				montoRendicion = montoRendicion.replace(/,/g , '');	
				montoRendicion =  parseFloat(montoRendicion);
				
				//Si ya hay error no continuar con la validacion
				if(!esVisible("idMensaje")){
					removeElement("idMensaje");
					if((montoxTotalAsignacion < montoRendicion) && (parametros.origenLlamada == "V" || (parametros.origenLlamada == "R" && (getValueInputText("selTipoConceptoComprobante") == "01" || getValueInputText("selTipoConceptoComprobante") == "12" ))) ){
						var mensaje = '<div id="idMensaje" class="colorFontRedTableClass">'+errorMessageRegistrarComprobante.montoOtorgadoxMontoTotalDocumento+'</div>';
						validarDatosRendicion(mensaje);
						validaEstadoGeneral = 0;
					}else{				
						validaEstadoGeneral = 1;
					}	
				}
				
			}
		}
		
		var montoTotalX3 = getValueInputText("montoTotal");
		
		var idSelectorConcepto = getValueInputText("selTipoConceptoComprobante");
		if(validaEstadoGeneral == 1){
			var strMonto = "valor total";
			var tipoDocumento = getValueInputText("selTipoDocumentoComprobante");
			var montoCalculo = getValueInputText("valorTotal");
			if(tipoDocumento=='906' || tipoDocumento=='907' || tipoDocumento=='916'){
				montoCalculo = getValueInputText("montoTotal");
				strMonto = "monto total";
			}
			
			montoCalculo = montoCalculo.replace(/,/g , '');	
			montoCalculo =  parseFloat(montoCalculo);
			
			var montoValidacion = montoxTotalAsignacion;
			/*if(parametros.estadoLlamada == "E"){
				montoDeclaracion = montoDeclaracion.replace(/,/g , '');	
				montoDeclaracion =  parseFloat(montoDeclaracion);
				montoValidacion = montoDeclaracion;
			}*/
			
			
			if(idSelectorConcepto!='00'&& 
					idSelectorConcepto!='01' && 
					idSelectorConcepto!='12' && (montoValidacion<montoCalculo) && montoCalculo>0){
				removeElement("idMensaje");
				//El <valor total/monto total> del comprobante debe  ser igual a <MONEDA><MONTO_TOPE_CONCEPTO>, por favor corregir
				//TODO: Se quita la validacion
				var submensaje = "El "+strMonto+" del comprobante debe ser menor o igual a "+monedaViatico+" "+montoValidacion+", por favor corregir";
				var mensaje = '<div id="idMensaje" class="colorFontRedTableClass">'+submensaje+'</div>';
				validarDatosRendicion(mensaje);
				validaEstadoGeneral = 0;
			}
		}

}

function validarMontoxAsignacionDeclaracion(){
	//removeElement("")
		var porcentajeDeclaracion = getValueInputText("porcentajeDeclaracion");
		porcentajeDeclaracion = parseFloat(porcentajeDeclaracion);
		var montoxTotalAsignacion = getDataAttributeSelect("selTipoConceptoComprobante", "data-montodeclaracion");
		montoxTotalAsignacion = parseFloat(montoxTotalAsignacion);
		var montoTotalDistribucion = getValueText("total_undefined");
		montoTotalDistribucion = montoTotalDistribucion.replace(/,/g , '');	
		montoTotalDistribucion =  parseFloat(montoTotalDistribucion);
		var monedaViatico =  getValueInputText("monedaViatico");
		var montoRendicion = getValueInputText("valorTotal");
		montoRendicion = montoRendicion.replace(/,/g , '');	
		montoRendicion =  parseFloat(montoRendicion);

		if(getValueInputText("selTipoDocumentoComprobante") == "915" || getValueInputText("selTipoDocumentoComprobante")== "067"){
			montoTotalDistribucion = montoRendicion;
		}
		
		hideElement("divErrorDatosComprobantePagoDistrib");
		hideElement("divErrorDatosComprobantePago");
		var porcentaje = "";
		if(porcentajeDeclaracion == 0.3){
			porcentaje = "30%";
		}else if(porcentajeDeclaracion == 0.2){
			porcentaje = "20%";
		}
		consoleLog("validarMontoxAsignacionDeclaracion: " + (montoxTotalAsignacion*porcentajeDeclaracion) + "  :  " + montoTotalDistribucion);
		if(((montoxTotalAsignacion*porcentajeDeclaracion) < montoTotalDistribucion) && (  (parametros.origenLlamada == "V" &&  getValueInputText("selTipoDocumentoComprobante") == "907") || (parametros.origenLlamada == "R" && (getValueInputText("selTipoConceptoComprobante") == "01" || getValueInputText("selTipoConceptoComprobante") == "12" ) && getValueInputText("selTipoDocumentoComprobante") == "907"))){
			  removeElement("idMensaje");
			  var mensaje = '<div id="idMensaje" class="colorFontRedTableClass">'+(errorMessageRegistrarComprobante.distribuidoxAsignacionDeclaracion).replace("PORCENTAJE", porcentaje)+'</div>';
			  showMessageErrorComprobante("etiquetaErrorDatosComprobantePagoxAsignacion", mensaje, "divErrorDatosComprobantePagoxAsignacion");
			  validaEstadoGeneral = 0;
		}else{
			hideElement("divErrorDatosComprobantePagoxAsignacion");
			validaEstadoGeneral = 1;
		}
		
		if(getValueInputText("selTipoDocumentoComprobante") == "907"){
			var montoRendicion = getValueInputText("montoTotal");
			montoRendicion = montoRendicion.replace(/,/g , '');	
			montoRendicion =  parseFloat(montoRendicion);
			removeElement("idMensaje");
				if(((montoxTotalAsignacion*porcentajeDeclaracion ) < montoRendicion) && 
				   (parametros.origenLlamada == "V" || (parametros.origenLlamada == "R" && (getValueInputText("selTipoConceptoComprobante") == "01" || getValueInputText("selTipoConceptoComprobante") == "12" ))) ){
					
					//comprobantePago.porcentajeDDJJ=El Monto Total de la Declaración Jurada no debe superar el MONEDA MONTOTOPECONCEPTO que corresponde al PORCENTAJE del importe total otorgado
					var montoMensajeError = roundComasMilesString( montoxTotalAsignacion*porcentajeDeclaracion, 2 );
					var mensaje = '<div id="idMensaje" class="colorFontRedTableClass">'+
					(errorMessageRegistrarComprobante.porcentajeDDJJ).replace("MONEDA",monedaViatico).replace("MONTOTOPECONCEPTO", montoMensajeError).replace("PORCENTAJE", porcentaje)+
					'</div>';
					
					validarDatosRendicion(mensaje);
					validaEstadoGeneral = 0;
				}else{					
					validaEstadoGeneral = 1;
				}
		}
}

function validarMontoxFecha(totalxFecha, fecha){
	//if(validaComprobantePago()=="1"){
		hideElement("divErrorDatosComprobantePago");
		hideElement("divErrorDatosComprobantePagoxAsignacion");
		var montoRendicionFechaFormater = $("#rendicionFechaRendicion_"+fecha).data("montofechaformater");
		var montoRendicionFechaSinFormater = $("#rendicionFechaRendicion_"+fecha).data("montofechasinformater");
		var fechaFormater = getValueText("fechaViatico_"+fecha);
		consoleLog("samuel: " + totalxFecha + " montoRendicionFechaSinFormater: " + montoRendicionFechaSinFormater);
		
		if(parseFloat(montoRendicionFechaSinFormater) < parseFloat(totalxFecha)){
			var mensaje = errorMessageRegistrarComprobante.montoFecha;
			mensaje = mensaje.replace("FECHA_TOPE", fechaFormater).replace("MONEDA_MONTO", montoRendicionFechaFormater);
			showMessageErrorComprobante("etiquetaErrorDatosComprobantePagoDistrib", mensaje, "divErrorDatosComprobantePagoDistrib");
			validaEstadoGeneral = 0;
		}else{			
			validaEstadoGeneral = 1;
			hideElement("divErrorDatosComprobantePagoDistrib");		
		}	
		return validaEstadoGeneral;
}

function sumaGeneralDistribucion(){
	hideElement("divErrorDatosComprobantePago");
	hideElement("divErrorDatosComprobantePagoxAsignacion");
	var fechas = new Array();
	var sumaTotal = 0;
	
	$(".total").each(function(){
		var ids = $(this).attr("id");
		ids = ids.split("_")[1];
		if(ids != "undefined")
			fechas.push(ids);
	});
		
		for(i=0; i < fechas.length; i++){
			var total = getValueText("total_"+fechas[i]);//monto total por fecha
			var montoXfecha = $("#rendicionFechaRendicion_"+fechas[i]).data("montofechasinformater");	//monto tope x fecha		
			var montoRendicionFechaFormater = $("#rendicionFechaRendicion_"+fechas[i]).data("montofechaformater");
			var fechaFormater = getValueText("fechaViatico_"+fechas[i]);			
			
			total =  total.replace(/,/g , '');
			//montoXfecha = montoXfecha.replace(/,/g , '');
			if(!esVisible("etiquetaErrorDatosComprobantePagoDistrib")){
				if(parseFloat(montoXfecha) < parseFloat(total)){
					var mensaje = errorMessageRegistrarComprobante.montoFecha;
					mensaje = mensaje.replace("FECHA_TOPE", fechaFormater).replace("MONEDA_MONTO", montoRendicionFechaFormater);
					showMessageErrorComprobante("etiquetaErrorDatosComprobantePagoDistrib", mensaje, "divErrorDatosComprobantePagoDistrib");
					validaEstadoGeneral = 0;
					break;	
				}
				else{
					validaEstadoGeneral = 1;
					hideElement("divErrorDatosComprobantePagoDistrib");
				}
			}
		}
	return validaEstadoGeneral;
}

//SI VALIDAR DONDE SE LLAMA MAS

function validaComprobantePago(){
	hideElement("divErrorDatosComprobantePagoDistrib");	
	hideElement("divErrorDatosComprobantePagoxAsignacion");
	var total_undefined = getValueText("total_undefined");
	total_undefined = total_undefined.replace(/,/g , '');
	total_undefined  = parseFloat(total_undefined);	
    
	 var valorTotal = getValueInputText("valorTotal");
	 	 valorTotal = valorTotal.replace(/,/g , '');
	 	 valorTotal  = parseFloat(valorTotal);
	 	 
	 var montoTotal = getValueInputText("montoTotal");
	 	montoTotal = montoTotal.replace(/,/g , '');
	 	montoTotal  = parseFloat(montoTotal);
	 	consoleLog("valorTotal: " + valorTotal + " total_undefined: " + total_undefined) ;
    
	//Si se trata de una declaracion jurada de viaticos, declaracion jurada de comprobante de pagos o recibo de comprobante del exterior.
	if (getValueInputText("selTipoDocumentoComprobante") == "907" || getValueInputText("selTipoDocumentoComprobante") == "906" || getValueInputText("selTipoDocumentoComprobante") == "916") {
		
		if(getValueInputText("selTipoDocumentoComprobante") == "907" || getValueInputText("selTipoDocumentoComprobante") == "906"){
		
			if(total_undefined != montoTotal){    	
		    	showMessageErrorComprobante('etiquetaErrorDatosComprobantePago', "El monto total distribuido debe ser igual al monto total del documento.", 'divErrorDatosComprobantePago');
		    	validaEstadoGeneral = 0;
		    }else {
		    	hideElement("divErrorDatosComprobantePago");
		    	validaEstadoGeneral = 1;
		    }
			
		}else{
			
			if(total_undefined > montoTotal){    	
		    	showMessageErrorComprobante('etiquetaErrorDatosComprobantePago', errorMessageRegistrarComprobante.distribuido, 'divErrorDatosComprobantePago');
		    	validaEstadoGeneral = 0;
		    }else {
		    	hideElement("divErrorDatosComprobantePago");
		    	validaEstadoGeneral = 1;
		    }
			
		}
		
		
	}else {
		if(total_undefined > valorTotal){    	
	    	showMessageErrorComprobante('etiquetaErrorDatosComprobantePago', errorMessageRegistrarComprobante.distribuido, 'divErrorDatosComprobantePago');
	    	validaEstadoGeneral = 0;
	    }else {
	    	hideElement("divErrorDatosComprobantePago");
	    	validaEstadoGeneral = 1;
	    }
	}	
	return validaEstadoGeneral; 		
}

//SI 
//VALIDAR FECHA DOCUMENTO
function validarFechaTipoDocumento(){
	var codConcepto = getValueInputText("selTipoConceptoComprobante");
	var tipoDocumentoComprobante = getValueInputText("selTipoDocumentoComprobante");
	var fechaDocumentoComprobante = getValueInputText("etiquetaFechaDocumentoComprobante");
	var fechaHoraProgSalida = getValueInputText("fechaHoraProgSalida");
	var fechaHoraProgRetorno = getValueInputText("fechaHoraProgRetorno");
	var fechaHoraEjeSalida = getValueInputText("fechaHoraEjeSalida");
	var fechaHoraEjeRetorno = getValueInputText("fechaHoraEjeRetorno");
	var tipoDestino = getValueInputText("tipoDestino");
	
	//DECLARACION JURADA	
	if(tipoDocumentoComprobante == "907"){
		if(tipoDestino == "01"){
					var fechaInicio = new Date(fechaHoraEjeSalida.split("/")[2],fechaHoraEjeSalida.split("/")[1], fechaHoraEjeSalida.split("/")[0]); 
					var fechaFin = new Date(fechaHoraEjeRetorno.split("/")[2], fechaHoraEjeRetorno.split("/")[1], fechaHoraEjeRetorno.split("/")[0]);
					var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
					
					if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
						var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteDeclaracion;
						showMessageErrorComprobante("etiquetaErrorFechaDocumento", mensajeReplaceFin,"divErrorFechaDocumento");
						validaEstadoGeneral = 0;
						validaEstadoFechaGeneral = 0;
					}	
					else{
						hideElement("divErrorFechaDocumento");
						validaEstadoGeneral = 1;
						validaEstadoFechaGeneral = 1;
					}
			}else if(tipoDestino == "02"){
				var fechaInicio = new Date(fechaHoraEjeSalida.split("/")[2],fechaHoraEjeSalida.split("/")[1], fechaHoraEjeSalida.split("/")[0]); 
					var fechaFin = new Date(fechaHoraEjeRetorno.split("/")[2], fechaHoraEjeRetorno.split("/")[1], fechaHoraEjeRetorno.split("/")[0]);
					var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
					
					if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
						var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteDeclaracion;
						showMessageErrorComprobante("etiquetaErrorFechaDocumento", mensajeReplaceFin,"divErrorFechaDocumento");
						validaEstadoGeneral = 0;
						validaEstadoFechaGeneral = 0;
					}	
					else{
						hideElement("divErrorFechaDocumento");
						validaEstadoGeneral = 1;
						validaEstadoFechaGeneral = 1;
					}
			}

	}else if(tipoDocumentoComprobante == "906" && (codConcepto=='02' || codConcepto=='03' || codConcepto=='36' || codConcepto=='34')){
		//Si se trata de un documento del tipo ddjj de comprobante de pago y el concepto es un tipo de pasaje, entonces solo hay que validar igual que cuando es boleto de viaje.
		var fechaInicio = new Date(fechaHoraEjeSalida.split("/")[2],fechaHoraEjeSalida.split("/")[1], fechaHoraEjeSalida.split("/")[0]); 
		var fechaFin = new Date(fechaHoraEjeRetorno.split("/")[2], fechaHoraEjeRetorno.split("/")[1], fechaHoraEjeRetorno.split("/")[0]);
		var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
		
		if (fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
			var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteBoletoViaje;
			showMessageErrorComprobante("etiquetaErrorFechaDocumento", mensajeReplaceFin,"divErrorFechaDocumento");
			validaEstadoGeneral = 0;
			validaEstadoFechaGeneral = 0;
		}	
		else{
			hideElement("divErrorFechaDocumento");
			validaEstadoGeneral = 1;
			validaEstadoFechaGeneral = 1;
		}
		
	}else if(tipoDocumentoComprobante == "915" || getValueInputText("selTipoDocumentoComprobante") == "067"){
		if(tipoDestino == "01"){
			var fechaInicio = new Date(fechaHoraEjeSalida.split("/")[2],fechaHoraEjeSalida.split("/")[1], fechaHoraEjeSalida.split("/")[0]); 
			var fechaFin = new Date(fechaHoraEjeRetorno.split("/")[2], fechaHoraEjeRetorno.split("/")[1], fechaHoraEjeRetorno.split("/")[0]);
			var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
			
			if (fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
				var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteBoletoViaje;
				showMessageErrorComprobante("etiquetaErrorFechaDocumento", mensajeReplaceFin,"divErrorFechaDocumento");
				validaEstadoGeneral = 0;
				validaEstadoFechaGeneral = 0;
			}	
			else{
				hideElement("divErrorFechaDocumento");
				validaEstadoGeneral = 1;
				validaEstadoFechaGeneral = 1;
			}
		}
	}else{
		if(tipoDestino == "01"){
			var fechaInicio = new Date(fechaHoraEjeSalida.split("/")[2],fechaHoraEjeSalida.split("/")[1], fechaHoraEjeSalida.split("/")[0]); 
			var fechaFin = new Date(fechaHoraEjeRetorno.split("/")[2], fechaHoraEjeRetorno.split("/")[1], fechaHoraEjeRetorno.split("/")[0]);
			var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
			if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime() || fechaFin.getTime() < fechaDocumentoComprobante.getTime()){
				var mensajeReplaceOne = (errorMessageRegistrarComprobante.fechaComprobanteOtros).replace("fechaInicio", fechaHoraEjeSalida);
				var mensajeReplaceFin = mensajeReplaceOne.replace("fechaFin", fechaHoraEjeRetorno);
				showMessageErrorComprobante("etiquetaErrorFechaDocumento", mensajeReplaceFin,"divErrorFechaDocumento");
				validaEstadoGeneral = 0;
				validaEstadoFechaGeneral = 0;
			}
			else {
				validaEstadoGeneral = 1;
				validaEstadoFechaGeneral = 1;
				hideElement("divErrorFechaDocumento");
			}
		}else if(tipoDestino == "02"){
			var fechaInicio = new Date(fechaHoraEjeSalida.split("/")[2],fechaHoraEjeSalida.split("/")[1], fechaHoraEjeSalida.split("/")[0]); 
			var fechaFin = new Date(fechaHoraEjeRetorno.split("/")[2], fechaHoraEjeRetorno.split("/")[1], fechaHoraEjeRetorno.split("/")[0]);
			var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
			if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime() || fechaFin.getTime() < fechaDocumentoComprobante.getTime()){
				var mensajeReplaceOne = (errorMessageRegistrarComprobante.fechaComprobanteOtros).replace("fechaInicio", fechaHoraEjeSalida);
				var mensajeReplaceFin = mensajeReplaceOne.replace("fechaFin", fechaHoraEjeRetorno);
				showMessageErrorComprobante("etiquetaErrorFechaDocumento", mensajeReplaceFin,"divErrorFechaDocumento");
				validaEstadoGeneral = 0;
				validaEstadoFechaGeneral = 0;
			}
			else {
				validaEstadoGeneral = 1;
				validaEstadoFechaGeneral = 1;
				hideElement("divErrorFechaDocumento");
			}
		}
	}

	/*if(tipoDocumentoComprobante == "906" || tipoDocumentoComprobante == "907" || tipoDocumentoComprobante == "916"){		
		if(tipoDestino == "01"){
			var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
			var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
			var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
			
			if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
				var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteDeclaracion;
				showMessageErrorComprobante("etiquetaErrorFechaDocumento", mensajeReplaceFin,"divErrorFechaDocumento");
				validaEstadoGeneral = 0;
				validaEstadoFechaGeneral = 0;
			}	
			else{
				hideElement("divErrorFechaDocumento");
				validaEstadoGeneral = 1;
				validaEstadoFechaGeneral = 1;
			}
		}else if (tipoDestino == "02"){
			var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
			var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
			var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
				if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
					var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteDeclaracion;				
					showMessageErrorComprobante("etiquetaErrorFechaDocumento", mensajeReplaceFin,"divErrorFechaDocumento");
					validaEstadoGeneral = 0;
					validaEstadoFechaGeneral = 0;
				}	
				else{
					validaEstadoGeneral = 1;
					validaEstadoFechaGeneral = 1;
					hideElement("divErrorFechaDocumento");
				}
		}
		
	}else if (tipoDocumentoComprobante == "915" || getValueInputText("selTipoDocumentoComprobante") == "067"){//BOLETO DE VIAJE
		if(tipoDestino == "01"){
			var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
			var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
			var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
			
			if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime() || fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
				var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteBoletoViaje;
				showMessageErrorComprobante("etiquetaErrorFechaDocumento", mensajeReplaceFin,"divErrorFechaDocumento");
				validaEstadoGeneral = 0;
				validaEstadoFechaGeneral = 0;

			}	
			else{
				validaEstadoGeneral = 1;
				validaEstadoFechaGeneral = 1;
				hideElement("divErrorFechaDocumento");
			}
		}else if (tipoDestino == "02"){
			var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
			var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
			var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
				if (fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
					var mensajeReplaceFin = errorMessageRegistrarComprobante.fechaComprobanteBoletoViaje;				
					showMessageErrorComprobante("etiquetaErrorFechaDocumento", mensajeReplaceFin,"divErrorFechaDocumento");
					validaEstadoGeneral = 0;
					validaEstadoFechaGeneral = 0;
				}	
				else{
					validaEstadoGeneral = 1;
					validaEstadoFechaGeneral = 1;
					hideElement("divErrorFechaDocumento");
				}
		}
	}else {		
		if(tipoDestino == "01"){
			var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
			var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
			var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
			if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime() || fechaFin.getTime() < fechaDocumentoComprobante.getTime()){
				var mensajeReplaceOne = (errorMessageRegistrarComprobante.fechaComprobanteOtros).replace("fechaInicio", fechaHoraProgSalida);
				var mensajeReplaceFin = mensajeReplaceOne.replace("fechaFin", fechaHoraProgRetorno);
				showMessageErrorComprobante("etiquetaErrorFechaDocumento", mensajeReplaceFin,"divErrorFechaDocumento");
				validaEstadoGeneral = 0;
				validaEstadoFechaGeneral = 0;
			}
			else {
				validaEstadoGeneral = 1;
				validaEstadoFechaGeneral = 1;
				hideElement("divErrorFechaDocumento");
			}
		}else if (tipoDestino == "02"){
			var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
			var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
			var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
				if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime() || fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
					var mensajeReplaceOne = (errorMessageRegistrarComprobante.fechaComprobanteOtros).replace("fechaInicio", fechaHoraEjeSalida);
					var mensajeReplaceFin = mensajeReplaceOne.replace("fechaFin", fechaHoraEjeRetorno);
					showMessageErrorComprobante("etiquetaErrorFechaDocumento", mensajeReplaceFin,"divErrorFechaDocumento");
					validaEstadoGeneral = 0;
					validaEstadoFechaGeneral = 0;
				}	
				else{
					validaEstadoGeneral = 1;
					validaEstadoFechaGeneral = 1;
					hideElement("divErrorFechaDocumento");
				}
		}
	}*/
	validaFormulario();
}

function validarDatosRendicion(mensaje){
	var mensajeError = mensaje;
	afterElement("tblDatosRendicion", mensajeError);
}

//SI valida RUC
function validaRUC(){

	var ruc = getValueInputText("txtRucComprobante");
	var tipoDocumento = getValueInputText("selTipoDocumentoComprobante");
	var descripcionTipoDocumento = getTextSelect("selTipoDocumentoComprobante");
	if($.trim(ruc) != ""){
		if($.trim(ruc).length==11){
			$.ajax({
	            url: contextPathUrl + "/viatico.htm?action=consultarRuc",
	            data: {
					"ruc": $.trim(ruc)
				},
				type: "post",
				dataType: "json",
				cache: false,
				beforeSend: function() {
					showElement("divLoadingComprobante");
				},
				complete: function() {
					hideElement("divLoadingComprobante");
				},
	            success: function (data) {	            	
	            	if(data.estado){
	            		hideElement("divErrorRUC");	            		
	            		setValueInputText("txtRazonSocialComprobante", data.razonSocial);	      
	            		validaEstadoGeneral = 1;
	            		if(tipoDocumento=="002"){
	            			if(!(data.flagBoleta)){
	            				hideElement("divErrorRUC");
	            				var mensaje = (errorMessageRegistrarComprobante.RUC).replace("XXXXXXXXXXXX", $.trim(ruc)).replace("TIPO_COMPROBANTE",descripcionTipoDocumento);
	            				showMessageErrorComprobante("etiquetaErrorRUC", mensaje, "divErrorRUC");
		        				validaEstadoGeneral = 0; 
	            			}
	            		}
	            		if(tipoDocumento=="001"){
	            			if(!(data.flagFactura)){
	            				hideElement("divErrorRUC");
	            				var mensaje = (errorMessageRegistrarComprobante.RUC).replace("XXXXXXXXXXXX", $.trim(ruc)).replace("TIPO_COMPROBANTE",descripcionTipoDocumento);
	            				showMessageErrorComprobante("etiquetaErrorRUC", mensaje, "divErrorRUC");
		        				validaEstadoGeneral = 0; 
	            			}
	            		}    
	            		
	            	}else  { 	            		
	            		showMessageErrorComprobante("etiquetaErrorRUC", data.mensaje, "divErrorRUC");
	            		setValueInputText("txtRazonSocialComprobante", data.razonSocial); 
	            		validaEstadoGeneral = 0;
	            	}
	            	validaFormulario();
	            },
	            error: function (xhr, textStatus, errorMessage) {	            	
	            }                
	        });
		}else{
			setValueInputText("txtRazonSocialComprobante", "");
			showMessageErrorComprobante("etiquetaErrorRUC", errorMessageRegistrarComprobante.rucMenorOnceDigitos, "divErrorRUC");
			validaEstadoGeneral = 0;
			validaFormulario();
		}
	}else{
		setValueInputText("txtRazonSocialComprobante", "");
		showMessageErrorComprobante("etiquetaErrorRUC", "Debe colocar el n&uacute;mero de RUC", "divErrorRUC");
		validaEstadoGeneral = 0;
		validaFormulario();
	}
	
	
}
//NO quitar el JSP el onblur


//SI implementar en el grabar o editar
function validarNumeroDocumentoRepetido(tipo){
	var estadoRespuesta;
	var tipoDocumento = getValueInputText("selTipoDocumentoComprobante");
	var serie = getValueInputText("txtSerieDocumentoComprobante");
	var numeroDocumento = getValueInputText("txtNumeroDocumentoComprobante");
	var numeroRuc = getValueInputText("txtRucComprobante");
	var secuencia = getValueInputText("txtSecuenciaComprobante");
	var codPlanViaje = getValueInputText("hidCodigoPlanViaje");
	
	if($.trim(tipoDocumento) != "907" && $.trim(tipoDocumento) != "906" && $.trim(tipoDocumento) != "916"){
		if($.trim(tipoDocumento) != "" && $.trim(serie) !=  "" && $.trim(numeroDocumento) != "" && $.trim(numeroRuc) != ""){
			$.ajax({
				url: contextPathUrl + "/viatico.htm?action=validarTipoDocumento",
				data: {
					"tipoDocumento": $.trim(tipoDocumento),
					"serie": $.trim(serie),
					"numeroDocumento": $.trim(numeroDocumento),
					"numeroRuc" :  $.trim(numeroRuc),
					"tipo" :  tipo,
					"secuencia" :  secuencia,
					"codPlanViaje" :  codPlanViaje 
				},
				type: "post",
				dataType: "json",
				cache: false,
				async: false,
				beforeSend: function() {
					showElement("divLoadingNumeroDocumento");
				},
				complete: function() {
					hideElement("divLoadingNumeroDocumento");
				},
				success: function(result) {		
					$("#divMensajeConfirmacionComprobante").modal("hide");
					if(!result.estadoNumeroDocumento){	
						 var mensaje = (errorMessageRegistrarComprobante.numeroDocumento).replace('SERIE',$.trim(serie.toUpperCase())).replace('NRO_DOCUMENTO',$.trim(numeroDocumento.toUpperCase()));
						 setHtmlElement("spaMensajeAdvertenciaComprobante", mensaje);
						 $("#divMensajeAdvertenciaComprobante").modal("show");						 
						 estadoRespuesta = false;
						
					}else{						
						estadoRespuesta = true;
					}
				},
				error: function() {
					consoleLog("Error callObtenerConceptoPlanillaViaticosToComprobante");
				}
			});
		}
	}else{
		estadoRespuesta = true;
	}
	consoleLog("estadoRespuesta: " +  estadoRespuesta);
	 return estadoRespuesta;
}

function validaSustentoLugar(){

	if (getValueInputText("selTipoDocumentoComprobante") == "915" || getValueInputText("selTipoDocumentoComprobante") == "067") {
		if($.trim(getValueInputText("txtSustentoLugarReferenciaComprobante")) == ""){
			showMessageErrorComprobante('etiquetaErrorSustentoLugar', errorMessageRegistrarComprobante.sustentoLugar, 'divErrorSustentoLugar');
			validaEstadoGeneral=0;
		}else{
			hideElement("divErrorSustentoLugar");
			validaEstadoGeneral=1;
		}
	}else if (getValueInputText("selTipoDocumentoComprobante") == "907"){

		var valorAlimentacion = 0;
		var valorHospedaje = 0;
		$(".alimentacion").each(function(){
			valorAlimentacion = valorAlimentacion + parseFloat(($(this).val()).replace(/,/g , ''));			
		});
		
		$(".hospedaje").each(function(){
			valorHospedaje = valorHospedaje + parseFloat(($(this).val()).replace(/,/g , ''));
		});
		
		if( (valorAlimentacion > 0 || valorHospedaje > 0 ) && $.trim(getValueInputText("txtSustentoLugarReferenciaComprobante")) == ""){
			showMessageErrorComprobante('etiquetaErrorSustentoLugar', errorMessageRegistrarComprobante.sustento, 'divErrorSustentoLugar');
			validaEstadoGeneral=0;
		}else{
			hideElement("divErrorSustentoLugar");
			validaEstadoGeneral=1;
		}		
	}else if(getValueInputText("selTipoDocumentoComprobante") == "916"){
		consoleLog("---ingreso---");
		validaEstadoGeneral=1;
	}
	validaFormulario();
}
/*
function validarTipoDocumentoxConcepto(){
	
	$("#selTipoConceptoComprobante option").each(function(){		
			$(this).show();		
	});
	
	if(getValueInputText("selTipoDocumentoComprobante") == "907"){

		$("#selTipoConceptoComprobante option").each(function(){
			if($(this).val() != "00" && ($(this).val() == "01" || $(this).val() == "12" )){
				$(this).show();
			}else{
				$(this).hide();
			}
		});
	}
	consoleLog("validarTipoDocumentoxConcepto: " + getValueInputText("selTipoDocumentoComprobante"));
	if(getValueInputText("selTipoDocumentoComprobante") == "915"){
		$("#selTipoConceptoComprobante option").each(function(){
			consoleLog("samuel: " + $(this).val());
			if($(this).val()!= "00" && ($(this).val() == "01" || $(this).val() == "12" )){
				$(this).hide();
			}else{
				$(this).show();
			}
		});
	}
}*/

function validarTipoDocumentoxConcepto(){

		var tipoConceptoComprobanteSel = $("#selTipoConceptoComprobante");
			tipoConceptoComprobanteSel.empty();
			var optionSelect = $("<option></option>").attr("value", "00").attr("data-clasificadorgasto", "").attr("data-monto", "").attr("data-montoDeclaracion","").text("--Seleccione--");
			tipoConceptoComprobanteSel.append(optionSelect);
			for (var i = 0; i < conceptoViaticosListGeneral.length; i++) {			
						var conceptoPlanillaViaticos = 	conceptoViaticosListGeneral[i];					
							optionSelect = $("<option></option>").attr("id", conceptoPlanillaViaticos.conceptoID).attr("value", conceptoPlanillaViaticos.conceptoID).attr("data-clasificadorgasto", conceptoPlanillaViaticos.clasificadorGasto)
							.attr("data-montoDeclaracion", conceptoPlanillaViaticos.monto).attr("data-monto", conceptoPlanillaViaticos.montoDevolver).text(conceptoPlanillaViaticos.descripcionConcepto + 
							($.trim(conceptoPlanillaViaticos.montoDevolver) == "" ? "" :   " - " + 	$.trim(monedaViatico)+ " "+(conceptoPlanillaViaticos.montoDevolver).toFixed(2)));
							tipoConceptoComprobanteSel.append(optionSelect);
			}


		if(getValueInputText("selTipoDocumentoComprobante") == "907"){

			tipoConceptoComprobanteSel.empty();	
				var optionSelect = $("<option></option>").attr("value", "00").attr("data-clasificadorgasto", "").attr("data-monto", "").attr("data-montoDeclaracion","").text("--Seleccione--");
				tipoConceptoComprobanteSel.append(optionSelect);
			for (var i = 0; i < conceptoViaticosListGeneral.length; i++) {				
					var conceptoPlanillaViaticos = 	conceptoViaticosListGeneral[i];
					if(conceptoPlanillaViaticos.conceptoID != "00" && (conceptoPlanillaViaticos.conceptoID == "01" || conceptoPlanillaViaticos.conceptoID == "12" )){
							optionSelect = $("<option></option>").attr("id", conceptoPlanillaViaticos.conceptoID).attr("value", conceptoPlanillaViaticos.conceptoID).attr("data-clasificadorgasto",
							conceptoPlanillaViaticos.clasificadorGasto).attr("data-montoDeclaracion", conceptoPlanillaViaticos.monto).attr("data-monto", 
							conceptoPlanillaViaticos.montoDevolver).text(conceptoPlanillaViaticos.descripcionConcepto +
							($.trim(conceptoPlanillaViaticos.montoDevolver) == "" ? ""  :   " - "+ $.trim(monedaViatico)+ " "+(conceptoPlanillaViaticos.montoDevolver).toFixed(2) )  );
							tipoConceptoComprobanteSel.append(optionSelect);
					}
				}
		}


		consoleLog("validarTipoDocumentoxConcepto: " + getValueInputText("selTipoDocumentoComprobante"));
		if(getValueInputText("selTipoDocumentoComprobante") == "915"){

				tipoConceptoComprobanteSel.empty();	
				var optionSelect = $("<option></option>").attr("value", "00").attr("data-clasificadorgasto", "").attr("data-monto", "").attr("data-montoDeclaracion","").text("--Seleccione--");
				tipoConceptoComprobanteSel.append(optionSelect);
				for (var i = 0; i < conceptoViaticosListGeneral.length; i++) {
					var conceptoPlanillaViaticos = 	conceptoViaticosListGeneral[i];
					if(conceptoPlanillaViaticos.conceptoID != "00" && (conceptoPlanillaViaticos.conceptoID != "01" && conceptoPlanillaViaticos.conceptoID != "12" )){					
							optionSelect = $("<option></option>").attr("id", conceptoPlanillaViaticos.conceptoID).attr("value", conceptoPlanillaViaticos.conceptoID).attr("data-clasificadorgasto",
							conceptoPlanillaViaticos.clasificadorGasto).attr("data-montoDeclaracion", conceptoPlanillaViaticos.monto).attr("data-monto", 
							conceptoPlanillaViaticos.montoDevolver).text(conceptoPlanillaViaticos.descripcionConcepto +
							($.trim(conceptoPlanillaViaticos.montoDevolver) == "" ? ""  :   " - "+ $.trim(monedaViatico)+ " "+(conceptoPlanillaViaticos.montoDevolver).toFixed(2) )  );
							tipoConceptoComprobanteSel.append(optionSelect);
					}
				}

		}
	}


//SI
function validaFormulario(){
	consoleLog("validaEstadoGeneral: " + validaEstadoGeneral);
	var tipoConcepto = getValueInputText("selTipoConceptoComprobante");
	var clasificadorGasto =  getValueInputText("txtClasificadorGastoComprobante");
	var ruc =  getValueInputText("txtRucComprobante");
	var numeroDocumento =  getValueInputText("txtNumeroDocumentoComprobante");
	var serie =  getValueInputText("txtSerieDocumentoComprobante");
	var fecha =  getValueInputText("etiquetaFechaDocumentoComprobante");	
	var valorVenta = getValueInputText("valorVenta");
	var valorTotal = getValueInputText("valorTotal");
	var montoBase = getValueInputText("montoBase");
	var montoTotal = getValueInputText("montoTotal");
	var tipoDestino = getValueInputText("tipoDestino");	
	var sustentoLugar = getValueInputText("txtSustentoLugarReferenciaComprobante");
	var razonSocialComprobante = getValueInputText("txtRazonSocialComprobante");

	var valorTotalF = getValueInputText("valorTotal");
	var montoTotalF = getValueInputText("montoTotal");
	var total_undefined = getValueText("total_undefined");
		valorTotalF = valorTotalF.replace(/,/g , '');
	 	valorTotalF  = parseFloat(valorTotalF);

		montoTotalF = montoTotalF.replace(/,/g , '');
	 	montoTotalF  = parseFloat(montoTotalF);

		total_undefined = total_undefined.replace(/,/g , '');
	 	total_undefined  = parseFloat(total_undefined);

	//DECLARACION JURADA - COMPROBANTE DE PAGO / DECLARACION JURADA - VIATICOS	
	
	var tipoDocumentoComprobante = getValueInputText("selTipoDocumentoComprobante");
	var fechaDocumentoComprobante = getValueInputText("etiquetaFechaDocumentoComprobante");
	var fechaHoraProgSalida = getValueInputText("fechaHoraProgSalida");
	var fechaHoraProgRetorno = getValueInputText("fechaHoraProgRetorno");
	var fechaHoraEjeSalida = getValueInputText("fechaHoraEjeSalida");
	var fechaHoraEjeRetorno = getValueInputText("fechaHoraEjeRetorno");
	
	consoleLog( "valorVenta: " + valorVenta + " valorTotal " + valorTotal + " fecha " + fecha + " validaEstadoGeneral " + validaEstadoGeneral + " ruc "+ ruc + " numeroDocumento " + numeroDocumento + " serie " + serie + " tipoConcepto " + tipoConcepto + " clasificadorGasto " + clasificadorGasto)
	
	//Si el elemento idMensaje que identifica al mensaje de error existe entonces deshabilitamos el boton grabar.
	if(existsElement("idMensaje") || esVisible("etiquetaErrorSerie")  || esVisible("etiquetaErrorNumeroDocumento") || 
			esVisible("etiquetaErrorDatosComprobantePagoDistrib") || esVisible("etiquetaErrorDatosComprobantePago")){
		validaEstadoGeneral = 0;
	}
	
	
	if (getValueInputText("selTipoDocumentoComprobante") == "907") {
		//Tipo de documento: Declaración Jurada - Viáticos

    	if( $.trim(montoBase) == "0.00" ||  $.trim(montoTotal) == "0.00" || 
    			$.trim(fecha) == "" ||  validaEstadoGeneral == 0  ||  
    			$.trim(numeroDocumento)== "" || $.trim(serie)== ""  ||  
    			($.trim(tipoConcepto) == "" && $.trim(tipoConcepto) == "00") || $.trim(clasificadorGasto) == ""){
    		consoleLog("Deshabilitando botón de grabación por algun dato vacío...");
			disabledElement("btnGrabarComprobante");
			disabledElement("btnGrabarAuxComprobante");			
    	}else{
    		if($.trim(fecha) != ""){
				if(tipoDestino == "01"){
					var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
					var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
					var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
					consoleLog("fechaInicio: " + fechaInicio.getTime()+ " fechaDocumentoComprobante: " + fechaDocumentoComprobante.getTime());
					if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
						consoleLog("Nacional:Deshabilitando botón de grabación por que la fecha de inicio("+fechaHoraProgSalida+") es mayor a la fecha del documento("+fechaDocumentoComprobante+")...");
						disabledElement("btnGrabarComprobante");
						disabledElement("btnGrabarAuxComprobante");	
					}	
					else{
						enabledElement("btnGrabarComprobante");
						enabledElement("btnGrabarAuxComprobante");
					}
				}else if (tipoDestino == "02"){
					var fechaInicio = new Date(fechaHoraEjeSalida.split("/")[2],fechaHoraEjeSalida.split("/")[1], fechaHoraEjeSalida.split("/")[0]); 
					var fechaFin = new Date(fechaHoraEjeRetorno.split("/")[2], fechaHoraEjeRetorno.split("/")[1], fechaHoraEjeRetorno.split("/")[0]);
					var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
						if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
							consoleLog("Internacional:Deshabilitando botón de grabación por que la fecha de inicio("+fechaHoraEjeSalida+") es mayor a la fecha del documento("+fechaDocumentoComprobante+")...");
							disabledElement("btnGrabarComprobante");
							disabledElement("btnGrabarAuxComprobante");	
						}	
						else{
							enabledElement("btnGrabarComprobante");
							enabledElement("btnGrabarAuxComprobante");
						}
				}  
			}

			if((montoTotalF < total_undefined) && montoTotalF > 0){
				consoleLog("Deshabilitando botón de grabación por que el montoTotalF("+montoTotalF+") es menor a total_undefined("+total_undefined+") ...");
				disabledElement("btnGrabarComprobante");
				disabledElement("btnGrabarAuxComprobante");	
			}else{
				enabledElement("btnGrabarComprobante");
				enabledElement("btnGrabarAuxComprobante");
			}

		}
	 
    }
	else if (getValueInputText("selTipoDocumentoComprobante") == "906") {
		//Tipo de documento: Declaración Jurada Comprobante de Pago

    	if( $.trim(montoBase) == "0.00" ||  $.trim(montoTotal) == "0.00" || $.trim(fecha) == "" ||  validaEstadoGeneral == 0  ||  $.trim(numeroDocumento)== "" || $.trim(serie)== ""  ||  ($.trim(tipoConcepto) == "" && $.trim(tipoConcepto) == "00") || $.trim(clasificadorGasto) == ""){
			disabledElement("btnGrabarComprobante");
			disabledElement("btnGrabarAuxComprobante");			
    	}else{
    		if($.trim(fecha) != ""){
				if(tipoDestino == "01"){
					var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
					var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
					var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
					consoleLog("fechaInicio: " + fechaInicio.getTime()+ " fechaDocumentoComprobante: " + fechaDocumentoComprobante.getTime());
					if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime() || fechaFin.getTime() < fechaDocumentoComprobante.getTime()){
						disabledElement("btnGrabarComprobante");
						disabledElement("btnGrabarAuxComprobante");	
					}	
					else{
						enabledElement("btnGrabarComprobante");
						enabledElement("btnGrabarAuxComprobante");
					}
				}else if (tipoDestino == "02"){
					var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
					var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
					var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
						if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime() || fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
							disabledElement("btnGrabarComprobante");
							disabledElement("btnGrabarAuxComprobante");	
						}	
						else{
							enabledElement("btnGrabarComprobante");
							enabledElement("btnGrabarAuxComprobante");
						}
				}  			
					
			}

			if((montoTotalF < total_undefined) && montoTotalF > 0){
						disabledElement("btnGrabarComprobante");
						disabledElement("btnGrabarAuxComprobante");	
			}else{
						enabledElement("btnGrabarComprobante");
						enabledElement("btnGrabarAuxComprobante");
			}

		}
	 
    }
    else if (getValueInputText("selTipoDocumentoComprobante") == "916") {
    	//Tipo de documento: Comprobante del Exterior
    	if( $.trim(montoBase) == "0.00" ||  $.trim(montoTotal) == "0.00" || $.trim(fecha) == "" ||  validaEstadoGeneral == 0  ||  $.trim(numeroDocumento)== "" || $.trim(serie)== ""  ||  ($.trim(tipoConcepto) == "" && $.trim(tipoConcepto) == "00") || $.trim(clasificadorGasto) == ""){
			disabledElement("btnGrabarComprobante");
			disabledElement("btnGrabarAuxComprobante");
		}else{
			if($.trim(fecha) != ""){
				if(tipoDestino == "01"){
					var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
					var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
					var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
					consoleLog("fechaInicio: " + fechaInicio.getTime()+ " fechaDocumentoComprobante: " + fechaDocumentoComprobante.getTime());
					if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime() || fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
						disabledElement("btnGrabarComprobante");
						disabledElement("btnGrabarAuxComprobante");	
					}	
					else{
						enabledElement("btnGrabarComprobante");
						enabledElement("btnGrabarAuxComprobante");
					}
				}else if (tipoDestino == "02"){
					var fechaInicio = new Date(fechaHoraEjeSalida.split("/")[2],fechaHoraEjeSalida.split("/")[1], fechaHoraEjeSalida.split("/")[0]); 
					var fechaFin = new Date(fechaHoraEjeRetorno.split("/")[2], fechaHoraEjeRetorno.split("/")[1], fechaHoraEjeRetorno.split("/")[0]);
					var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
						if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime() || fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
							disabledElement("btnGrabarComprobante");
							disabledElement("btnGrabarAuxComprobante");	
						}	
						else{
							enabledElement("btnGrabarComprobante");
							enabledElement("btnGrabarAuxComprobante");
						}
				}  
			}
			
			if((montoTotalF < total_undefined) && montoTotalF > 0){
				disabledElement("btnGrabarComprobante");
				disabledElement("btnGrabarAuxComprobante");	
			}else{
				enabledElement("btnGrabarComprobante");
				enabledElement("btnGrabarAuxComprobante");
			}
		}
    }
    else if (getValueInputText("selTipoDocumentoComprobante") == "915" || getValueInputText("selTipoDocumentoComprobante") == "067") {
    	//Tipo de comprobante: Boleto de Viaje o Documento de Cobranza de Agencias de Viaje
	    if(tipoDestino == "01"){    		
	    	if( $.trim(sustentoLugar) == "" || $.trim(valorVenta) == "0.00" ||  $.trim(valorTotal) == "0.00" || $.trim(fecha) == "" ||  validaEstadoGeneral == 0 ||  $.trim(ruc) == "" || $.trim(razonSocialComprobante) == "" ||  $.trim(numeroDocumento)== "" || $.trim(serie)== ""  ||  ($.trim(tipoConcepto) == "" && $.trim(tipoConcepto) == "00") || $.trim(clasificadorGasto) == ""){
    			disabledElement("btnGrabarComprobante");
				disabledElement("btnGrabarAuxComprobante");
			}else{				
				if($.trim(fecha) != ""){
					if(tipoDestino == "01"){
						var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
						var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
						var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
						consoleLog("fechaInicio: " + fechaInicio.getTime()+ " fechaDocumentoComprobante: " + fechaDocumentoComprobante.getTime());
						if (fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
							disabledElement("btnGrabarComprobante");
							disabledElement("btnGrabarAuxComprobante");
						}	
						else{
							enabledElement("btnGrabarComprobante");
							enabledElement("btnGrabarAuxComprobante");
						}
					}else if (tipoDestino == "02"){
						var fechaInicio = new Date(fechaHoraEjeSalida.split("/")[2],fechaHoraEjeSalida.split("/")[1], fechaHoraEjeSalida.split("/")[0]); 
						var fechaFin = new Date(fechaHoraEjeRetorno.split("/")[2], fechaHoraEjeRetorno.split("/")[1], fechaHoraEjeRetorno.split("/")[0]);
						var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
							if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime() || fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
								disabledElement("btnGrabarComprobante");
								disabledElement("btnGrabarAuxComprobante");
							}	
							else{
								enabledElement("btnGrabarComprobante");
								enabledElement("btnGrabarAuxComprobante");
							}
					}	
				
				}
				
				
				if($("#divErrorRUC").css("display") == "block"){
					disabledElement("btnGrabarComprobante");
					disabledElement("btnGrabarAuxComprobante");
				}else{
						enabledElement("btnGrabarComprobante");
						enabledElement("btnGrabarAuxComprobante");
				}
			}
	    }else{ if(tipoDestino == "02") {
			    	if( $.trim(sustentoLugar) == "" || $.trim(valorVenta) == "0.00" ||  $.trim(valorTotal) == "0.00" || $.trim(fecha) == "" ||  validaEstadoGeneral == 0  ||  $.trim(numeroDocumento)== "" || $.trim(serie)== ""  ||  ($.trim(tipoConcepto) == "" && $.trim(tipoConcepto) == "00") || $.trim(clasificadorGasto) == ""){
						disabledElement("btnGrabarComprobante");
						disabledElement("btnGrabarAuxComprobante");
					}else{
						   if($.trim(fecha) != ""){	
								if(tipoDestino == "01"){
									var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
									var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
									var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
									consoleLog("fechaInicio: " + fechaInicio.getTime()+ " fechaDocumentoComprobante: " + fechaDocumentoComprobante.getTime());
									if (fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
										disabledElement("btnGrabarComprobante");
										disabledElement("btnGrabarAuxComprobante");
									}	
									else{
										enabledElement("btnGrabarComprobante");
										enabledElement("btnGrabarAuxComprobante");
									}
								}else if (tipoDestino == "02"){
									var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
									var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
									var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
										if (fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
											disabledElement("btnGrabarComprobante");
											disabledElement("btnGrabarAuxComprobante");
										}	
										else{
											enabledElement("btnGrabarComprobante");
											enabledElement("btnGrabarAuxComprobante");
										}
								}				
						   }	
						   
						 if($("#divErrorRUC").css("display") == "block"){
							disabledElement("btnGrabarComprobante");
							disabledElement("btnGrabarAuxComprobante");
							}else{
							enabledElement("btnGrabarComprobante");
							enabledElement("btnGrabarAuxComprobante");
						}
					}
	    
	    		}//SELECCIONE
	    	}
	    }else if(getValueInputText("selTipoDocumentoComprobante") == "000"){

	}
	else {//OTROS
		consoleLog( "valorVenta: " + valorVenta + " valorTotal " + valorTotal + " fecha " + fecha + " validaEstadoGeneral " + validaEstadoGeneral + " ruc "+ ruc + " numeroDocumento " + numeroDocumento + " serie " + serie + " tipoConcepto " + tipoConcepto + " clasificadorGasto " + clasificadorGasto)
		if( $.trim(valorVenta) == "0.00" ||  $.trim(valorTotal) == "0.00" || $.trim(fecha) == "" ||  validaEstadoGeneral == 0 ||  $.trim(ruc) == "" || $.trim(razonSocialComprobante) == ""  ||  $.trim(numeroDocumento)== "" || $.trim(serie)== ""  ||  ($.trim(tipoConcepto) == "" && $.trim(tipoConcepto) == "00") || $.trim(clasificadorGasto) == ""){
			
			
			
			disabledElement("btnGrabarComprobante");
			disabledElement("btnGrabarAuxComprobante");
					
		}else{
			
			if($.trim(fecha) != ""){
				if(tipoDestino == "01"){
					var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
					var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
					var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
					consoleLog("fechaInicio: " + fechaInicio.getTime() + " fechaFin: " +  fechaFin.getTime()  + " fechaDocumentoComprobante: " +fechaDocumentoComprobante.getTime());
					if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime() || fechaFin.getTime() < fechaDocumentoComprobante.getTime()){
						disabledElement("btnGrabarComprobante");
						disabledElement("btnGrabarAuxComprobante");
					}
					else {
						enabledElement("btnGrabarComprobante");
						enabledElement("btnGrabarAuxComprobante");
					}
				}else if (tipoDestino == "02"){
					var fechaInicio = new Date(fechaHoraEjeSalida.split("/")[2],fechaHoraEjeSalida.split("/")[1], fechaHoraEjeSalida.split("/")[0]); 
					var fechaFin = new Date(fechaHoraEjeRetorno.split("/")[2], fechaHoraEjeRetorno.split("/")[1], fechaHoraEjeRetorno.split("/")[0]);
					var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
						if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime() || fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
							disabledElement("btnGrabarComprobante");
							disabledElement("btnGrabarAuxComprobante");
						}	
						else{
							enabledElement("btnGrabarComprobante");
							enabledElement("btnGrabarAuxComprobante");
						}
				}
					
			}	
			var estadoBoton = 0;
			if($.trim(ruc) != ""  && $.trim(razonSocialComprobante) != "" ){	
				if($("#divErrorRUC").css("display") == "block"){
					disabledElement("btnGrabarComprobante");
					disabledElement("btnGrabarAuxComprobante");
					estadoBoton = 0;
				}else{
					enabledElement("btnGrabarComprobante");
					enabledElement("btnGrabarAuxComprobante");
					estadoBoton = 1;
				}
			}
		consoleLog("sigue estadoBoton:"  + estadoBoton + "valorTotalF:" + 
		valorTotalF + " total_undefined: " + total_undefined + " montoTotalF: " + montoTotalF
		+"estado: " + (valorTotalF <total_undefined));
			if(estadoBoton == 1){		

				if((valorTotalF < total_undefined ) && valorTotalF > 0) {
					disabledElement("btnGrabarComprobante");
					disabledElement("btnGrabarAuxComprobante");	
				}else{
					enabledElement("btnGrabarComprobante");
					enabledElement("btnGrabarAuxComprobante");
				}			
			}
		}
    
    }
    
}

function validaNumeroDocumentoSerie(){
		
		var estadoNumeroDocumento = validarNumeroDocumento();
		if(estadoNumeroDocumento == 1){
			validarFormatoNumeroSerie();
		}
	
	validaFormulario();	
}

function validarNumeroDocumento(){
	var numeroDocumento = getUpperCaseValueInputText("txtNumeroDocumentoComprobante");
	
	//divErrorNumeroDocumento
	if($.trim(numeroDocumento) == ""){
		showMessageErrorComprobante("etiquetaErrorNumeroDocumento", errorMessageRegistrarComprobante.numeroDocumentoBlanco, "divErrorNumeroDocumento");
		validaEstadoGeneral = 0;			
	}else{		
		
		var errorNumero = false;
		var numeroDocumentoNumber = toNumero($.trim(numeroDocumento));
		if(numeroDocumentoNumber==0){
			showMessageErrorComprobante("etiquetaErrorNumeroDocumento", errorMessageRegistrarComprobante.numeroDocumentoBlanco, "divErrorNumeroDocumento");
			validaEstadoGeneral = 0;			
		}else{
			showMessageErrorComprobante("etiquetaErrorNumeroDocumento", "" , "divErrorNumeroDocumento");
			hideElement("divErrorNumeroDocumento");
			validaEstadoGeneral = 1;	
		}
			
	}
	return validaEstadoGeneral;
}

function validarFormatoNumeroSerie(){	
	var serie = getValueInputText("txtSerieDocumentoComprobante");
	if($.trim(serie) != ""){
		//valida que el primer caracter sea una letra y los siguientes numeros,
		//entradas validaas: E001, E1245, E, E100, 1000, 001
		//entradas invalidas: EE255, EEE
		var estadoValidacion = validarFirstLetterAfterNumber(serie); 
			if(estadoValidacion){				
				showMessageErrorComprobante("etiquetaErrorSerie", "" , "divErrorNumeroDocumento");
				hideElement("divErrorNumeroDocumento");
				validaEstadoGeneral = 1;
				
				//la serie debe de tener un valor luego de la primera letra,
				var errorSerie = false;
				var serieTrim = $.trim(serie);
				if(serieTrim.length==1){
					
					//Si la serie solo tiene un numero entonces verificar que no sea una letra
					var formatter = /[A-Za-z]/;
					var alfabetico = formatter.test(serie);
					if(alfabetico)errorSerie=true;
					else{
						var serieNumero = toNumero(serieTrim);
						if(serieNumero==0)errorSerie=true;
					}
					
				}else{
					
					var formatter = /[A-Za-z]/;
					var alfabetico = formatter.test(serieTrim.substring(0, 1));//verificamos el primer digito...
					if(alfabetico){
						//Si el primer char es una letra
						serieTrim = serieTrim.substring(1, serieTrim.length);
						var serieNumero = toNumero(serieTrim);
						if(serieNumero==0)errorSerie=true;	
					}else{
						//Si el primer char es un digito, validamos toda la cadena
						var serieNumero = toNumero(serieTrim);
						if(serieNumero==0)errorSerie=true;	
					}
					
				}
				
				
				
				if(errorSerie){
					showMessageErrorComprobante("etiquetaErrorNumeroDocumento", "" , "divErrorNumeroDocumento");
					showMessageErrorComprobante("etiquetaErrorSerie","El número de la serie no tiene el formato correcto." , "divErrorNumeroDocumento");
					validaEstadoGeneral = 0;
				}
				
				
			}else{
					//mostramos el error siempre y cuando se haya ingresado al menos una letra.
					if(serie.length >= 1){
						showMessageErrorComprobante("etiquetaErrorNumeroDocumento", "" , "divErrorNumeroDocumento");
						showMessageErrorComprobante("etiquetaErrorSerie","El número de la serie no tiene el formato correcto." , "divErrorNumeroDocumento");
						validaEstadoGeneral = 0;
					}
			}
	}else{
		showMessageErrorComprobante("etiquetaErrorNumeroDocumento", "" , "divErrorNumeroDocumento");
		showMessageErrorComprobante("etiquetaErrorSerie",errorMessageRegistrarComprobante.serie , "divErrorNumeroDocumento");
		validaEstadoGeneral = 0;
	}
	return validaEstadoGeneral;
	
}