function initElementsBuscarDestino(idElementCallModal) {
	
	setInitElementsBuscarDestino();
	setInitDestinoTable(idElementCallModal);
}

function setInitElementsBuscarDestino() {
	
	setValueInputText("selTipoBusquedaBuscarDestino", "00");
	setValueInputText("txtDestinoDetalle", "");
	setHtmlElement("divDestinoPagerTable_left", "");
	hideElement("divErrorBuscarDestino");
	disabledElement("txtDestinoDetalle");
	disabledElement("btnBuscarDestino");
	disabledElement("btnAceptarBuscarDestino");
	addEventElement("btnBuscarDestino", "click", clickBtnBuscarDestino);
	addEventElement("btnBuscarTodosDestinos", "click", clickBtnBuscarTodosDestinos);
	addEventElement("btnAceptarBuscarDestino", "click", clickBtnAceptarBuscarDestino);
	addEventElement("btnCancelarBuscarDestino", "click", clickBtnCancelarBuscarDestino);
	addEventElement("selTipoBusquedaBuscarDestino", "change", changeSelTipoBusquedaBuscarDestino);
}

function removeEventElementsBuscarDestino() {
	
	removeAllEventsElement("btnAceptarBuscarDestino");
	removeAllEventsElement("btnCancelarBuscarDestino");
	removeAllEventsElement("btnBuscarDestino");
	removeAllEventsElement("btnBuscarTodosDestinos");
	removeAllEventsElement("selTipoBusquedaBuscarDestino");
}

function removeDestinoTable() {
	var htmlElement = "<table id=\"tblDestino\"></table>";
	htmlElement += "<div id=\"divDestinoPagerTable\" class=\"jqGridViaticoPagerClass\"></div>";
	setHtmlElement("divDestinoTable", htmlElement);
}

function setInitDestinoTable(idElementCallModal) {
	
	var destinoTable = $("#tblDestino");
	
	if (destinoTable) {
		
		var destinoTableDiv = $("#" + idElementCallModal);
		var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.viaticoModalContainer", ".viaticoModalContainerAuxiliar", "width"))/100);
		var widthTable = factorRedimensionamiento*destinoTableDiv.width();
		
		destinoTable.jqGrid({
			width: widthTable,
			height: 200,
			datatype: "local",
			rowNum: 10,
			rowList: [10, 20],
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames:[
				"Nro",
				"Codigo Departamento",
				"Departamento",
				"Codigo Provincia",
				"Provincia",
				"Codigo Ubigeo",
				"Codigo Lugar",
				"Ubigeo"
			],
			colModel:[
				{name: "numSecuencial", index: "numSecuencial", width: (1.4*widthTable/12)},
				{name: "codigoDepartamento", index: "codigoDepartamento", width: (1*widthTable/12), hidden: true},
				{name: "descripcionDepartamento", index: "descripcionDepartamento", width: (3.4*widthTable/12)},
				{name: "codigoProvincia", index: "codigoProvincia", width: (1*widthTable/12), hidden: true},
				{name: "descripcionProvincia", index: "descripcionProvincia", width: (3.4*widthTable/12)},
				{name: "codigoUbigeo", index: "codigoUbigeo", width: (1*widthTable/12), hidden: true},
				{name: "codigoLugar", index: "codigoLugar", width: (1*widthTable/12), hidden: true},
				{name: "nombreLugar", index: "nombreLugar", width: (3.4*widthTable/12)}
			],
			pager : "#divDestinoPagerTable",
			loadui: "disable"
		});
	}
}

function clickBtnAceptarBuscarDestino() {
	
	var destinoTable = $("#tblDestino");
	var rowId = destinoTable.jqGrid("getGridParam", "selrow");
	
	if (rowId == null) {
		setHtmlElement("divDestinoPagerTable_left", errorMessageBuscarDestino.seleccionarRegistro);
	}
	else {
		
		var rowData = destinoTable.getRowData(rowId);
			
		callObtenerDetalleCompletoLugar(rowData);
		
		removeEventElementsBuscarDestino();
		removeDestinoTable();
		
		$('#divBuscarDestino').modal('hide');
	}
}

function clickBtnCancelarBuscarDestino() {
	removeEventElementsBuscarDestino();
	removeDestinoTable();
	$('#divBuscarDestino').modal('hide');
	
	if (typeof buscarDestinoService != "undefined" &&  typeof buscarDestinoService.eventos != "undefined" && typeof buscarDestinoService.eventos.eventoCancelar != "undefined") {
		buscarDestinoService.eventos.eventoCancelar();					
	}	
}

function clickBtnBuscarDestino() {
	
	var flagParametrosValidos = true;
	var errorMessage = "";
	setHtmlElement("divDestinoPagerTable_left", "");
	hideElement("divErrorBuscarDestino");
	
	if (flagParametrosValidos && getValueInputText("selTipoBusquedaBuscarDestino") == "00") {
		errorMessage = errorMessageBuscarDestino.seleccionarTipoBusqueda;
		flagParametrosValidos = false;
	}
	
	if (flagParametrosValidos && trimText(getValueInputText("txtDestinoDetalle")) == "") {
		errorMessage = errorMessageBuscarDestino.completarDescripcion;
		flagParametrosValidos = false;
	}
	
	if (flagParametrosValidos && trimText(getValueInputText("txtDestinoDetalle")).length < 2) {
		errorMessage = errorMessageBuscarDestino.cantidadMinimaDescripcion;
		flagParametrosValidos = false;
	}
	
	if (flagParametrosValidos) {
		callObtenerLugarByDescripcion("0");
	}
	else {
		showMessageErrorBuscarDestino(errorMessage);
	}
}

function clickBtnBuscarTodosDestinos() {
	
	setValueInputText("selTipoBusquedaBuscarDestino", "00");
	setValueInputText("txtDestinoDetalle", "");
	setHtmlElement("divDestinoPagerTable_left", "");
	hideElement("divErrorBuscarDestino");
	disabledElement("txtDestinoDetalle");
	disabledElement("btnBuscarDestino");
	callObtenerLugarByDescripcion("1");
}

function changeSelTipoBusquedaBuscarDestino() {
	
	var destinoTable = $("#tblDestino");
	destinoTable.clearGridData();
	setValueInputText("txtDestinoDetalle", "");
	setHtmlElement("divDestinoPagerTable_left", "");
	hideElement("divErrorBuscarDestino");
	disabledElement("btnAceptarBuscarDestino");
	
	if (getValueInputText("selTipoBusquedaBuscarDestino") == "00") {
		disabledElement("txtDestinoDetalle");
		var estadoCantidadCaracteres = validaCantidadCaracteres();
		if(estadoCantidadCaracteres){
			disabledElement("btnBuscarDestino");}
		else{
			disabledElement("btnBuscarDestino");
		}
	}
	else {
		enabledElement("txtDestinoDetalle");
		var estadoCantidadCaracteres = validaCantidadCaracteres();
		if(estadoCantidadCaracteres){
			enabledElement("btnBuscarDestino");}
		else{
			disabledElement("btnBuscarDestino");
		}
	}
}

function callObtenerLugarByDescripcion(indicadorBotonBuscar) {
	
	setTimeout(function(){
	
		var dataPost = {
			"codigoTipoBusqueda": getValueInputText("selTipoBusquedaBuscarDestino"),
			"descripcionDestino": getUpperCaseValueInputText("txtDestinoDetalle"),
			"indicadorBotonBuscar": indicadorBotonBuscar
		};
		
		// si viene definido el servicio y el parametro puntoPartida, agregar mas filtros al query para excluir el punto de partida
		if (typeof buscarDestinoService != "undefined" &&  typeof buscarDestinoService.data != "undefined" && typeof buscarDestinoService.data.puntoPartida != "undefined") {
			dataPost.puntoPartidaCodigoDepartamento = $.trim( buscarDestinoService.data.puntoPartida.codigoDepartamento );
			dataPost.puntoPartidaCodigoProvincia = $.trim( buscarDestinoService.data.puntoPartida.codigoProvincia );
		}
	
		var destinoTable = $("#tblDestino");
		destinoTable.clearGridData();
		setHtmlElement("divDestinoPagerTable_left", "");
		disabledElement("btnAceptarBuscarDestino");
		$.ajax({
			url: contextPathUrl + "/viatico.htm?action=obtenerLugaresByDescripcion",
			type: "post",
			dataType: "json",
			cache: false,
			data: dataPost,
			beforeSend: function() {
				showElement("divLoadingBuscarDestino");
			},
			complete: function() {
				hideElement("divLoadingBuscarDestino");
			},
			success: function(result) {

				var lugarList = result.lugarList;
				
				if (lugarList != null && lugarList.length > 0) {
					
					for (var i = 0; i < lugarList.length; i++) {
						
						var lugar = lugarList[i];
						
						var datarow = {
							numSecuencial: (i + 1),
							codigoDepartamento: lugar.codigoDepartamento,
							descripcionDepartamento: lugar.descripcionDepartamento,
							codigoProvincia: lugar.codigoProvincia,
							descripcionProvincia: lugar.descripcionProvincia,
							codigoUbigeo: lugar.codigoUbigeo,
							codigoLugar: lugar.codigoLugar,
							nombreLugar: lugar.nombreLugar
						};
						
						destinoTable.jqGrid("addRowData", datarow.numSecuencial, datarow);
					}
					
					destinoTable.trigger("reloadGrid");
					enabledElement("btnAceptarBuscarDestino");
					
				} else {
					setHtmlElement("divDestinoPagerTable_left", errorMessageBuscarDestino.sinRegistrosBusqueda);
				}
			},
			error: function() {
				consoleLog("Error callObtenerLugarByDescripcion");
			}
		});
	}, 500);
}

function validaCantidadCaracteres(){
	var destinoDetalle = getValueInputText("txtDestinoDetalle");
	if(destinoDetalle.length == 0){
		disabledElement("btnBuscarDestino");
		return false;
	}else{
		enabledElement("btnBuscarDestino");
		return true;
	}
}

function callObtenerDetalleCompletoLugar(rowData) {
	
	var codigoDepartamento = rowData["codigoDepartamento"];
	var codigoProvincia = rowData["codigoProvincia"];
	var codigoUbigeo = rowData["codigoUbigeo"];
	var codigoLugar = rowData["codigoLugar"];
	
	setHtmlElement("divDestinoPagerTable_left", "");
	
	$.ajax({
		url: contextPathUrl + "/viatico.htm?action=obtenerDetalleCompletoLugar",
		data: {
			"codigoDepartamento": codigoDepartamento,
			"codigoProvincia": codigoProvincia,
			"codigoUbigeo":  codigoUbigeo,
			"codigoLugar": codigoLugar			
		},
		type: "post",
		dataType: "json",
		cache: false,
		success: function(result) {
			
			// si el evento after esta definido en el servicio
			if (typeof buscarDestinoService != "undefined" &&  typeof buscarDestinoService.eventos != "undefined" && typeof buscarDestinoService.eventos.eventoAfter != "undefined") {
				
				var departamentoList = result.departamentoList;
				var provinciaList = result.provinciaList;
				
				if (departamentoList != null && departamentoList.length > 0 && provinciaList != null && provinciaList.length > 0) {
					
					var paramsAfter = {
						'departamentoList' : departamentoList,
						'provinciaList': provinciaList,
						'codigoDepartamento': codigoDepartamento,
						'codigoProvincia': codigoProvincia,
						'codigoUbigeo':  codigoUbigeo,
						'codigoLugar': codigoLugar
					};
					
					buscarDestinoService.eventos.eventoAfter(paramsAfter);
					
				} else {
				
					setHtmlElement("divDestinoPagerTable_left", "Por favor intente nuevamente.");
				}
				
			} else {
				
				// NOTA IMPORTANTE: se dejo tal y como estaba antes
				var departamentoList = result.departamentoList;
				var provinciaList = result.provinciaList;
				
				if (departamentoList != null && departamentoList.length > 0 && provinciaList != null && provinciaList.length > 0) {
					
					// Componentes que pertencen a la ventana que llama al modal
					var departamentoSel = $("#selDepartamento");
					departamentoSel.empty();
					for (var i = 0; i < departamentoList.length; i++) {
						var departamento = departamentoList[i];
						var optionSelect = $("<option></option>").attr("value", departamento.codiDepaDpt).text(departamento.nombDptoDpt);
						departamentoSel.append(optionSelect);
					}
					setValueInputText("selDepartamento", codigoDepartamento);
					enabledElement("selDepartamento");
					
					var provinciaSel = $("#selProvincia");
					provinciaSel.empty();
					for (var i = 0; i < provinciaList.length; i++) {
						var provincia = provinciaList[i];
						var optionSelect = $("<option></option>").attr("value", provincia.codiProvTpr).text(provincia.nombProvTpr);
						provinciaSel.append(optionSelect);
					}
					setValueInputText("selProvincia", codigoProvincia);
					enabledElement("selProvincia");
					
					//Funciones que pertenecen a la ventana que llama al modal
					habilitarDeshabilitarBtnNuevaRuta();
					
				} else {
					setHtmlElement("divDestinoPagerTable_left", "Por favor intentente nuevamente.");
				}
				
			}	
			 
		},
		error: function() {
			consoleLog("Error callObtenerDetalleCompletoLugar");
		}
	});
}


function showMessageErrorBuscarDestino(errorMessage) {
	setHtmlElement("etiquetaErrorBuscarDestino", errorMessage);
	showElement("divErrorBuscarDestino");
}