function initElementsBuscarCadenaPresupuestal(idElementCallModal, uuooValue, uuooDetalleValue, codigoDependencia) {
	
	setInitElementsBuscarCadenaPresupuestal(uuooValue, uuooDetalleValue, codigoDependencia);
	setInitCadenaPresupuestalTable(idElementCallModal);
	callObtenerMetas(codigoDependencia);
}

function removeEventElementsBuscarCadenaPresupuestal() {
	removeAllEventsElement("btnAceptarCadenaPresupuestal");
	removeAllEventsElement("btnCancelarCadenaPresupuestal");
}

function removeCadenaPresupuestalTable() {
	var htmlElement = "<table id=\"tblCadenaPresupuestal\"></table>";
	htmlElement += "<div id=\"divCadenaPresupuestalPagerTable\" class=\"jqGridViaticoPagerClass\"></div>";
	setHtmlElement("divCadenaPresupuestalTable", htmlElement);
}

function setInitElementsBuscarCadenaPresupuestal(uuooValue, uuooDetalleValue, codigoDependencia) {
	setValueInputText("txtUUOOCadenaPresupuestal", uuooValue);
	setValueInputText("txtUUOODetalleCadenaPresupuestal", uuooDetalleValue);
	setValueInputText("hidCodigoDependenciaCadenaPresupuestal", codigoDependencia);
	disabledElement("btnAceptarCadenaPresupuestal");
	addEventElement("btnAceptarCadenaPresupuestal", "click", clickBtnAceptarBuscarCadenaPresupuestal);
	addEventElement("btnCancelarCadenaPresupuestal", "click", clickBtnCancelarBuscarCadenaPresupuestal);
	consoleLog("LLamando ajax - Cadena Presupuestal");
}

function setInitCadenaPresupuestalTable(idElementCallModal) {
	var cadenaPresupuestalTable = $("#tblCadenaPresupuestal");
	if (cadenaPresupuestalTable) {
		//Para el DivWitdh se utilizo un componente que llama al modal
		var cadenaPresupuestalTableDiv = $("#" + idElementCallModal);
		var factorRedimensionamiento = Number(parseFloat(getValueStyleElementBySelector(".container.viaticoModalContainer", ".viaticoModalContainerAuxiliar", "width"))/100);
		var widthTable = factorRedimensionamiento*cadenaPresupuestalTableDiv.width();
		cadenaPresupuestalTable.jqGrid({
			width: widthTable,
			height: 200,
			datatype: "local",
			rowNum: 10,
			rowList: [10, 20],
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames:[
				"C&oacute;digo",			// hidden
				"Codigo Dependencia",	// hidden
				"codigoMetaPresupuestal",
				"Meta"
			],
			colModel:[
				{name: "secuFuncSfu", index: "secuFuncSfu", width: (2*widthTable/12)},
				{name: "codigoDependencia", index: "codigoDependencia", width: (2*widthTable/12), hidden: true},
				{name: "codigoMetaPresupuestal", index: "codigoMetaPresupuestal", width: (2*widthTable/12), hidden : true},
				{name: "metaPresupuestal", index: "metaPresupuestal", width: (10*widthTable/12)}
			],
			pager : "#divCadenaPresupuestalPagerTable",
			loadui: "disable"
		});
	}
}

function clickBtnAceptarBuscarCadenaPresupuestal() {
	
	var cadenaPresupuestalTable = $("#tblCadenaPresupuestal");
	var rowId = cadenaPresupuestalTable.jqGrid("getGridParam", "selrow");
	if (rowId == null) {
		setHtmlElement("divCadenaPresupuestalPagerTable_left", errorMessageCadenaPresupuestal.seleccionarRegistro);
	}
	else {

		var rowData = cadenaPresupuestalTable.getRowData(rowId);
		
		// si el evento after esta definido en el servicio
		if (typeof buscarCadenaPresupuestalService != "undefined" &&  typeof buscarCadenaPresupuestalService.eventos != "undefined" && typeof buscarCadenaPresupuestalService.eventos.eventoAfter != "undefined") {
			
			buscarCadenaPresupuestalService.eventos.eventoAfter(rowData);
			
		} else {
			
			// NOTA IMPORTANTE: se dejo tal y como estaba antes			
			setValueInputText("hidSecuFuncSfu", rowData["secuFuncSfu"]);
			setValueInputText("txtActividad", rowData["codigoMetaPresupuestal"] + " " + rowData["metaPresupuestal"]);		
		}		
		
		removeEventElementsBuscarCadenaPresupuestal();
		removeCadenaPresupuestalTable();
		$("#divCadenaPresupuestal").modal("hide");
	}
}

function clickBtnCancelarBuscarCadenaPresupuestal() {
	removeEventElementsBuscarCadenaPresupuestal();
	removeCadenaPresupuestalTable();
	$("#divCadenaPresupuestal").modal("hide");
}

function callObtenerMetas(codigoDependencia) {
	
	setTimeout(function(){
		
		consoleLog("codigoDependencia: " + codigoDependencia);
		
		var cadenaPresupuestalTable = $("#tblCadenaPresupuestal");
		cadenaPresupuestalTable.clearGridData();
		$.ajax({
			url: contextPathUrl + "/viatico.htm?action=obtenerMetas",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codigoDependencia": codigoDependencia
			},
			beforeSend: function() {
				showElement("divLoadingBuscarCadenaPresupuestal");
			},
			complete: function() {
				hideElement("divLoadingBuscarCadenaPresupuestal");
			},
			success: function(result) {
				var metasList = result.metasList;
				if (metasList != null && metasList.length > 0) {
					for (var i = 0; i < metasList.length; i++) {
						var metas = metasList[i];
						var datarow = {
							secuFuncSfu: metas.secuFuncSfu,
							codigoDependencia: metas.codiDepeTde,
							codigoMetaPresupuestal: metas.codiLargMet,
							metaPresupuestal: metas.codiLargMet + " " +metas.descLargMet
						};
						cadenaPresupuestalTable.jqGrid("addRowData", metas.secuFuncSfu, datarow);
					}
					cadenaPresupuestalTable.trigger("reloadGrid");
					enabledElement("btnAceptarCadenaPresupuestal");
				}
				else {
					setHtmlElement("divCadenaPresupuestalPagerTable_left", errorMessageCadenaPresupuestal.sinRegistrosBusqueda);
				}
			},
			error: function() {
				consoleLog("Error callObtenerMetas");
			}
		});
	}, 500);
}