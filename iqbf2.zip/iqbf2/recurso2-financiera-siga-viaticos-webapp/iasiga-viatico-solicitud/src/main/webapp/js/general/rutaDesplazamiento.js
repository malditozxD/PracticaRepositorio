/// <reference path="../general/common.js" />
/// <reference path="D:\jcfr\data\ts-definitions\DefinitelyTyped-master\jquery\jquery.d.ts" />

function initElementsCrearNuevaRuta( departamentoOrigen, provinciaOrigen, codColaborador, nroDiasHorasRestantes ) {

	// codigos departamento y provincia de origen/punto partida, 
	// para no mostrar en los combos en el agregar desplazamiento cuando es viatico nacional
	configRSV.puntoPartida.codigoDepartamento = departamentoOrigen;
	configRSV.puntoPartida.codigoProvincia = provinciaOrigen;
	
	setValueInputText( 'hidCodigoColaboradorDesplazamiento' , $.trim( codColaborador ) );
	setValueInputText( 'hidNroDiasHorasRestantesDesplazamiento' , $.trim( nroDiasHorasRestantes ) );
	
	removeDuplicateComponents();
	setInitElementsCrearNuevaRuta();

	// darle un tiempo a que termine la carga del popup
	setTimeout( function() {
		$('#selRutaMedioTransporte').focus();		
	}, 500 );
}

function setInitElementsCrearNuevaRuta() {

	// limpiar campos al inicio
	setValueInputText( 'txtRutaImporte' , '' );
	setValueInputText( 'txtRutaDiasTraslado' , '' );
	setValueInputText( 'txtRutaDiasViaticos' , '' );
	setValueInputText( 'txtRutaDiasViaticosNacional' , '' );
	setValueInputText( 'txtRutaHorasViaticosNacional' , '' );

	// limpia campos del importe diario calculado
	limpiarCamposImporteDiario();
	
	// limpiar texto de error y ocultar el div de error
	hideMessageErrorCrearNuevaRuta();

	// eventos: combos
	addEventElement("selRutaMedioTransporte", "change", changeSelRutaMedioTransporte);
	addEventElement("selRutalugar", "change", changeSelRutalugar);
	addEventElement("selRutaTipoTarifa", "change", changeSelRutaTipoTarifa);
	addEventElement("selDepartamentoRuta", "change", changeSelDepartamentoRuta);
	addEventElement("selProvinciaRuta", "change", changeSelProvinciaRuta);

	// eventos: cajas de texto
	addEventElement("txtRutaPorcentaje", "focusout", blurTxtRutaPorcentaje);
	addEventElement("txtRutaImporte", "focusout", blurTxtRutaImporte);

	addEventElement("txtRutaDiasViaticos", "focusout", onBlurTxtRutaDiasViaticos); // número de días viático internacional 
	addEventElement("txtRutaDiasViaticosNacional", "focusout", onBlurTxtRutaDiasViaticosNacional); // número de días viático nacional mayor a 4 horas
	addEventElement("txtRutaHorasViaticosNacional", "focusout", onBlurTxtRutaHorasViaticosNacional);  // número de horas viático nacional menor igual a 4 horas

	addEventElement("txtRutaDiasTraslado", "focusout", onBlurTxtRutaDiasTraslado);

	// eventos: botones
	addEventElement("btnAceptarCrearNuevaRuta", "click", clickBtnAceptarCrearNuevaRuta);
	addEventElement("btnCancelarCrearNuevaRuta", "click", clickBtnCancelarCrearNuevaRuta);
	addEventElement("btnConsultarLugarRuta", "click", clickBtnConsultarLugarRuta);

	// mostrar los controles que corresponen si es nacional (combos con el mapa) o si es internacional
	cargarControlesNacionalInternacional();

	// llenar combos de nacional / internacional
	cargarComboPopupMedioTranporte();
	cargarComboPopupLugares();
	cargarComboPopupTarifas();

	// ayudar con la precarga del medio de transporte segun el tipo de viatico
	preCargaMedioTransporte();

	// ayudar con la precarga del número de días restantes
	preCargaNroDiasHorasRestantes();

	// limpia los combos de departamento y provincia
	changeSelRutaMedioTransporte();

	// actualiza ruta y porcentaje segun el combo tipo de tarifa
	changeSelRutaTipoTarifa();

	// iniciar los combos de departamento
	callAjaxObtenerDepartamentoRuta();
}

function preCargaMedioTransporte() {

	var selTipoViatico = $('#selTipoViatico').val();
	var selDuracionComision = $('#selDuracionComision').val();

	// nacional
	if ( selTipoViatico == 'nacional' ) {

		if ( selDuracionComision == 'may4h' ) {	// si es mayor a 4 horas

			$( '#selRutaMedioTransporte' ).val( configRSV.constantes.MEDIO_TRANSPORTE_TERRESTRE );

		} else { // si es menor o igual a 4 horas

			$( '#selRutaMedioTransporte' ).val( configRSV.constantes.MEDIO_TRANSPORTE_TERRESTRE );

		}

	} else {	// internacional
		$( '#selRutaMedioTransporte' ).val( configRSV.constantes.MEDIO_TRANSPORTE_AEREO );
	}
}

function preCargaNroDiasHorasRestantes() {

	// puede venir en blanco, o el numero de dias seteado
	var nroDiasHorasRestantes = getTrimValue( '#hidNroDiasHorasRestantesDesplazamiento' );

	var selTipoViatico = $('#selTipoViatico').val();
	var selDuracionComision = $('#selDuracionComision').val();

	// nacional
	if ( selTipoViatico == 'nacional' ) {

		if ( selDuracionComision == 'may4h' ) {	// si es mayor a 4 horas

			$( '#txtRutaDiasViaticosNacional' ).val( nroDiasHorasRestantes );

		} else { // si es menor o igual a 4 horas

			$( '#txtRutaHorasViaticosNacional' ).val( nroDiasHorasRestantes );

		}

	} else {	// internacional

		var txtRutaDiasViaticos = getTrimValue( '#txtRutaDiasViaticos' );
		
		$( '#txtRutaDiasViaticos' ).val( nroDiasHorasRestantes );

	}
}

function cargarControlesNacionalInternacional() {

	// mostrar los controles que corresponen si es nacional (combos con el mapa) o si es internacional
	var selTipoViatico = $('#selTipoViatico').val();
	var selDuracionComision = $('#selDuracionComision').val();

	if ( selTipoViatico == 'nacional' ) {

		$('#divRutaNacional').show();
		$('#divRutaInternacional').hide();

		// si es mayor a 4 horas
		if ( selDuracionComision == 'may4h' ) {

			$('#divRutaNacionalHorasMen4h').hide();
			$('#divRutaNacionalHorasMay4h').show();

		} else {	// si es menor o igual a 4 horas

			$('#divRutaNacionalHorasMay4h').hide();
			$('#divRutaNacionalHorasMen4h').show();
		}

	} else {
		$('#divRutaInternacional').show();
		$('#divRutaNacional').hide();
	}
}

function removeEventElementsCrearNuevaRuta() {
	
	removeAllEventsElement("selRutaMedioTransporte");
	removeAllEventsElement("selRutalugar");
	removeAllEventsElement("selRutaTipoTarifa");
	removeAllEventsElement("selDepartamentoRuta");
	removeAllEventsElement("selProvinciaRuta");
	removeAllEventsElement("btnAceptarCrearNuevaRuta");
	removeAllEventsElement("btnCancelarCrearNuevaRuta");
	removeAllEventsElement("btnConsultarLugarRuta");
	removeAllEventsElement("txtRutaPorcentaje");
	removeAllEventsElement("txtRutaDiasViaticos");	// viaticos internacional
	removeAllEventsElement("txtRutaDiasViaticosNacional");	// viaticos nacional mayor a 4h
	removeAllEventsElement("txtRutaHorasViaticosNacional"); // viaticos nacional menor o igual a 4h
}

function blurTxtRutaImporte() {

	var txtRutaImporte = getTrimValue( '#txtRutaImporte' );	
	var hidViaticoMontoDiario = getTrimValue( '#hidViaticoMontoDiario' );	
	
	hideMessageErrorCrearNuevaRuta();
	
	// que importe sea mayor a 0 (se esta agregando la validacion si no ingresa nada)
	if ( txtRutaImporte == '' || !( toNumero( txtRutaImporte ) > 0 ) ) {
	
		showMessageErrorCrearNuevaRuta( configRSV.mensajes.importeDebeSerMayorACero );			
		return;
	}

	// que importe no supere el maximo permitido	
	if ( hidViaticoMontoDiario != '' ) {
		if ( toNumero( txtRutaImporte ) > toNumero( hidViaticoMontoDiario ) ) {
			
			var msg = configRSV.mensajes.elImporteNoDebeSuperarElTipoMonedaMontoMaximo;
			msg = msg.replace( /TIPO_MONEDA/g, configRSV.moneda );
			msg = msg.replace( /MONTO_MAXIMO/g, hidViaticoMontoDiario );

			showMessageErrorCrearNuevaRuta( msg );			
			return;
		}
	}
}

function handleNumeroMayorIgualCero( controlID, valorDefaultSiEsNegativo ) {

	// funcion que extrae el valor de 'controlID', y si es un numero negativo, toma el valor de 'valorDefaultSiEsNegativo'
	var controlValue = getTrimValue( controlID );
	var valorDefault = estaDefinido( valorDefaultSiEsNegativo ) ? $.trim( valorDefaultSiEsNegativo ) : '';

	// si no es numero y no es >= 0, setear el valor por default en el controlID
	if ( !( esNumero( controlValue ) && toNumero( controlValue ) >= 0 ) ) {

		controlValue = valorDefault;

		$( controlID ).val( controlValue );
	}
	
	return controlValue;
}

function blurTxtRutaPorcentaje() {

	// evaluar que lo ingresado sea >= 0
	var txtRutaPorcentaje = handleNumeroMayorIgualCero( '#txtRutaPorcentaje', '0' );

	if ( !esNumero( txtRutaPorcentaje ) || toNumero( txtRutaPorcentaje ) < 0 ) {
		txtRutaPorcentaje = '0';
		setValueInputText( 'txtRutaPorcentaje', txtRutaPorcentaje );
	}
	
	// actualizar caja de texto con importe $
	updateImporteViaticoInternacional();

	var porcentaje = $.trim( obtenerAtributoComboTipoTarifa( 'data-porcentaje' ) );
	
	hideMessageErrorCrearNuevaRuta();
	
	// que porcentaje no supere el maximo permitido
	if ( txtRutaPorcentaje != '' && porcentaje != '' ) {
		if ( toNumero( txtRutaPorcentaje ) > toNumero( porcentaje ) ) {
			
			var msg = configRSV.mensajes.noSePuedeRegistrarPorcMayorAlMaximoPermitido;
			msg = msg.replace( /PORC_MAXIMO/g, porcentaje );

			showMessageErrorCrearNuevaRuta( msg );			
			return;
		}
	}
	
	// que porcentaje sea mayor a 0
	if ( txtRutaPorcentaje != '' ) {
		if ( !( toNumero( txtRutaPorcentaje ) > 0 ) ) {
		
			showMessageErrorCrearNuevaRuta( configRSV.mensajes.noSePuedeRegistrarPorcIgualACero );			
			return;
		}
	}	
}

function onBlurTxtRutaDiasTraslado() {

	// evaluar que lo ingresado sea >= 0
	var txtRutaDiasTraslado = handleNumeroMayorIgualCero( '#txtRutaDiasTraslado', '0' );

	hideMessageErrorCrearNuevaRuta();
	
	if ( txtRutaDiasTraslado != '' ) {

		var selRutalugar = getTrimValue( '#selRutalugar' );

		// solo si escogio lugar
		if ( selRutalugar != '' ) {

			var rutaDiasTrasladoMax = obtenerAtributoComboLugar( 'data-diastraslado' );

			if ( toNumero( txtRutaDiasTraslado ) > toNumero( rutaDiasTrasladoMax )  ) {

				var msg = configRSV.mensajes.topeMaxAsigDiasTraslado;
				msg = msg.replace( /NRO_DIAS/g, rutaDiasTrasladoMax );

				showMessageErrorCrearNuevaRuta( msg );
				return;
			}
		}

	}
}

function onBlurTxtRutaDiasViaticos() {

	// evaluar que lo ingresado sea >= 0
	var txtRutaDiasViaticos = handleNumeroMayorIgualCero( '#txtRutaDiasViaticos', '0' );
	
	hideMessageErrorCrearNuevaRuta();

	if ( hayDiasHorasRestantes() ) {

		// nro de dias maximo sugerido
		var nroDiasComisionSugerido = obtenerNumeroDiasHorasComisionDesplazamiento();		

		// que no se pase de lo sugerido
		if ( txtRutaDiasViaticos == '' || 
			toNumero( txtRutaDiasViaticos ) <= 0.0 ||
			toNumero( txtRutaDiasViaticos ) > toNumero( nroDiasComisionSugerido ) ) {
			
			var msg = configRSV.mensajes.debeIngresarDiasParaDesplazamiento;
			msg = msg.replace( /NRO_DIAS/g, nroDiasComisionSugerido );		
			
			showMessageErrorCrearNuevaRuta( msg );
			return;
		}	

	} else {

		// que no ingrese ceros
		if ( txtRutaDiasViaticos == '' || 
			toNumero( txtRutaDiasViaticos ) <= 0.0) {
			
			showMessageErrorCrearNuevaRuta( 'Debe ingresar la cantidad de d&iacute;as y este debe ser mayor a cero' );
			return;
		}	

		// validacion adicional (que los dias de desplazamiento ingreso mas lo de la grilla no supere lo programado)
		var nroDiasHorasComision = obtenerNumeroDiasHorasComision();
		var nroDiasHorasDesplazamiento = calcularDiasHorasDesplazamiento();		// lo ingresado en la grilla

		if ( esNumero( nroDiasHorasComision ) && esNumero( nroDiasHorasDesplazamiento ) && esNumero( txtRutaDiasViaticos ) ) {

			var sumaDesplazamientos = toNumero( nroDiasHorasDesplazamiento ) + toNumero( txtRutaDiasViaticos );
			if ( sumaDesplazamientos > toNumero( nroDiasHorasComision ) ) {

				showMessageErrorCrearNuevaRuta( 'La cantidad total de d&iacute;as supera la cantidad de d&iacute;as del detalle de la solicitud, verificar' );
				return;
			}
		}

	}

}

function onBlurTxtRutaDiasViaticosNacional() {

	// evaluar que lo ingresado sea >= 0
	var txtRutaDiasViaticosNacional = handleNumeroMayorIgualCero( '#txtRutaDiasViaticosNacional', '0' );

	hideMessageErrorCrearNuevaRuta();

	if ( hayDiasHorasRestantes() ) {

		// nro de dias maximo sugerido
		var nroDiasComisionSugerido = obtenerNumeroDiasHorasComisionDesplazamiento();

		// que no se pase de lo sugerido
		if ( txtRutaDiasViaticosNacional == '' || 
			toNumero( txtRutaDiasViaticosNacional ) <= 0.0 ||
			toNumero( txtRutaDiasViaticosNacional ) > toNumero( nroDiasComisionSugerido ) ) {
			
			var msg = configRSV.mensajes.debeIngresarDiasParaDesplazamiento;
			msg = msg.replace( /NRO_DIAS/g, nroDiasComisionSugerido );		
			
			showMessageErrorCrearNuevaRuta( msg );
			return;
		}		

	} else {

		// que no ingrese ceros
		if ( txtRutaDiasViaticosNacional == '' || 
			toNumero( txtRutaDiasViaticosNacional ) <= 0.0 ) {
			
			showMessageErrorCrearNuevaRuta( 'Debe ingresar la cantidad de d&iacute;as y este debe ser mayor a cero' );
			return;
		}		

		// validacion adicional (que los dias de desplazamiento ingreso mas lo de la grilla no supere lo programado)
		var nroDiasHorasComision = obtenerNumeroDiasHorasComision();
		var nroDiasHorasDesplazamiento = calcularDiasHorasDesplazamiento();					// lo ingresado en la grilla

		if ( esNumero( nroDiasHorasComision ) && esNumero( nroDiasHorasDesplazamiento ) && esNumero( txtRutaDiasViaticosNacional ) ) {

			var sumaDesplazamientos = toNumero( nroDiasHorasDesplazamiento ) + toNumero( txtRutaDiasViaticosNacional );
			if ( sumaDesplazamientos > toNumero( nroDiasHorasComision ) ) {

				showMessageErrorCrearNuevaRuta( 'La cantidad total de d&iacute;as supera la cantidad de d&iacute;as del detalle de la solicitud, verificar' );
				return;
			}
		}

	}
	
}

function onBlurTxtRutaHorasViaticosNacional() {

	// evaluar que lo ingresado sea >= 0
	var txtRutaHorasViaticosNacional = handleNumeroMayorIgualCero( '#txtRutaHorasViaticosNacional', '0' );

	hideMessageErrorCrearNuevaRuta();
	
	if ( hayDiasHorasRestantes() ) {

		// numero de horas sugerido
		var nroHorasComisionSugerido = obtenerNumeroDiasHorasComisionDesplazamiento();

		// que no se pase de lo sugerido
		if ( txtRutaHorasViaticosNacional == '' || 
			toNumero( txtRutaHorasViaticosNacional ) <= 0.0 ||
			toNumero( txtRutaHorasViaticosNacional ) > toNumero( nroHorasComisionSugerido ) ) {
			
			var msg = configRSV.mensajes.debeIngresarHorasParaDesplazamiento;
			msg = msg.replace( /NRO_HORAS/g, nroHorasComisionSugerido );		
			
			showMessageErrorCrearNuevaRuta( msg );
			return;
		}

	} else {

		// que no ingrese ceros
		if ( txtRutaHorasViaticosNacional == '' ||
			toNumero( txtRutaHorasViaticosNacional ) <= 0.0 ) {
			showMessageErrorCrearNuevaRuta( configRSV.mensajes.noPuedeRegistrarCantidadHorasIgualCero );
			return;
		}		

		// validacion adicional (que las horas de desplazamiento ingreso mas lo de la grilla no supere lo programado)
		var nroDiasHorasComision = obtenerNumeroDiasHorasComision();
		var nroDiasHorasDesplazamiento = calcularDiasHorasDesplazamiento();					// lo ingresado en la grilla

		if ( esNumero( nroDiasHorasComision ) && esNumero( nroDiasHorasDesplazamiento ) && esNumero( txtRutaHorasViaticosNacional ) ) {
			
			var sumaDesplazamientos = toNumero( nroDiasHorasDesplazamiento ) + toNumero( txtRutaHorasViaticosNacional );
			if ( sumaDesplazamientos > toNumero( nroDiasHorasComision ) ) {

				showMessageErrorCrearNuevaRuta( 'La cantidad total de horas supera la cantidad de horas del detalle de la solicitud, verificar' );
				return;
			}
		}	

	}

}

function clickBtnConsultarLugarRuta() {

	// ocultamos el popup actual para mostrar el popup buscar ubigeo en primer plano
	$( '#divCrearNuevaRuta' ).modal( "hide" );

	// creamos y configuramos el servicio (datos, eventos)
	buscarDestinoService = new BuscarDestinoService( {
		'puntoPartida': {
			'codigoDepartamento' : configRSV.puntoPartida.codigoDepartamento,
			'codigoProvincia' : configRSV.puntoPartida.codigoProvincia
		}
	}, {
		'eventoAfter': buscarDestinoAfterRuta,
		'eventoCancelar': buscarDestinoCancelarRuta
	});

	initElementsBuscarDestino("divDesplazamientoTableRSV");
	$( '#divBuscarDestino' ).modal( 'show' );
	triggerResizeEvent();

}

function buscarDestinoCancelarRuta() {
	$( '#divCrearNuevaRuta' ).modal( "show" );
}

function buscarDestinoAfterRuta(paramsAfter) {

	$( '#divCrearNuevaRuta' ).modal( "show" );

	// listas de departamentos y provincias
	var departamentoList = paramsAfter.departamentoList;
	var provinciaList = paramsAfter.provinciaList;

	// lo seleccionado en la ventana popup
	var codigoDepartamento = paramsAfter.codigoDepartamento;
	var codigoProvincia = paramsAfter.codigoProvincia;
	var codigoUbigeo = paramsAfter.codigoUbigeo;
	var codigoLugar = paramsAfter.codigoLugar;

	// llenando el combo de departamentos segun lo que se selecciono en la ventana popup
	var departamentoSel = $( '#selDepartamentoRuta' );
	departamentoSel.empty();
	for (var i = 0; i < departamentoList.length; i++) {
		var departamento = departamentoList[i];
		var optionSelect = $( '<option></option>' ).attr("value", departamento.codiDepaDpt).text(departamento.nombDptoDpt);
		departamentoSel.append(optionSelect);
	}
	setValueInputText("selDepartamentoRuta", codigoDepartamento);
	enabledElement("selDepartamentoRuta");

	// llenando el combo de provincias segun lo que se selecciono en la ventanta popup
	var provinciaSel = $( '#selProvinciaRuta' );
	provinciaSel.empty();
	for (var i = 0; i < provinciaList.length; i++) {
		var provincia = provinciaList[i];
		var optionSelect = $( '<option></option>' ).attr("value", provincia.codiProvTpr).text(provincia.nombProvTpr);
		provinciaSel.append(optionSelect);
	}
	setValueInputText("selProvinciaRuta", codigoProvincia);
	enabledElement("selProvinciaRuta");

	// guardar en un hidden el codigo de lugar
	setValueInputText("hidCodigoPuntoPartidaRuta", codigoLugar);

	// actualizar el boton de agregar desplazamiento
	updateBotonAgregarDesplazamientoRuta();
	
	// buscar el importe diario nacional
	obtenerCamposImporteDiarioNacional( codigoDepartamento, codigoProvincia );
}

function clickBtnAceptarCrearNuevaRuta() {
	hideMessageErrorCrearNuevaRuta();

	var result = validarDesplazamiento();

	if ( result.hayError ) {
		
		showMessageErrorCrearNuevaRuta( result.msgError );

		if ( estaDefinido( result.queryControlFocus ) ) {
			darFoco( result.queryControlFocus );
		}		
		
		return;
	}

	callAjaxValidarDesplazamiento();

	if ( isBrowserInternetExplorer() ) {
		triggerResizeEvent();
	}

}

function clickBtnCancelarCrearNuevaRuta() {
	
	removeEventElementsCrearNuevaRuta();

	$( '#divCrearNuevaRuta' ).modal( 'hide' );

	if ( isBrowserInternetExplorer() ) {
		triggerResizeEvent();
	}
}

function changeSelDepartamentoRuta() {

	setValueInputText( 'selProvinciaRuta', '00' );
	setValueInputText( 'hidCodigoPuntoPartidaRuta' , '' );

	disabledElement( 'selProvinciaRuta' );

	// limpia campos del importe diario calculado
	limpiarCamposImporteDiario();

	updateBotonAgregarDesplazamientoRuta();

	var selDepartamentoValue = $( '#selDepartamentoRuta' ).val();
	if ( selDepartamentoValue != "00") {
		// muestra las provincias, ignorando la provincia de punto de partida
		callAjaxObtenerProvinciaRuta( selDepartamentoValue, configRSV.puntoPartida.codigoDepartamento, configRSV.puntoPartida.codigoProvincia );
	}
}

function changeSelProvinciaRuta() {

	setValueInputText( 'hidCodigoPuntoPartidaRuta' , '' );

	// limpia campos del importe diario calculado
	limpiarCamposImporteDiario();

	var provinciaSel = $( '#selProvinciaRuta' ).val();
	var departamentoSel = $( '#selDepartamentoRuta' ).val();

	if (provinciaSel != "00") {

		// obtener el codigo de ruta
		callAjaxObtenerLugarByCodigoRuta( departamentoSel, provinciaSel );

		// obtener el importe diario nacional
		obtenerCamposImporteDiarioNacional( departamentoSel, provinciaSel );

	} else {
		updateBotonAgregarDesplazamientoRuta();
	}
}

function updateBotonAgregarDesplazamientoRuta() {

	var selDepartamentoRuta = getTrimValue( '#selDepartamentoRuta' );
	var selProvinciaRuta = getTrimValue( '#selProvinciaRuta' );
	var hidCodigoPuntoPartidaRuta = getTrimValue( '#hidCodigoPuntoPartidaRuta' );

	// var activar = hidCodigoPuntoPartidaRuta != '' && selDepartamentoRuta != '00' && selProvinciaRuta != '00';

	// ahora siempre esta activo para evidenciar mensajes
	var activar = true;

	$('#btnAceptarCrearNuevaRuta').prop( 'disabled', !activar );
}

function updateImporteViaticoInternacional() {

	// recoge el monto diario del hidden que el ajax callAjaxObtenerImporteDiario() trajo
	var montoDiario = getTrimValue( '#hidViaticoMontoDiario' );
	var txtRutaPorcentaje = getTrimValue( '#txtRutaPorcentaje' );

	// solo si hay monto diario en el hidden (puede que el combo lugar este en 'seleccione')
	if ( montoDiario != '' && txtRutaPorcentaje != '' ) {
		var montoDiarioNumber = toNumero( montoDiario );
		var porcentaje = toNumero( txtRutaPorcentaje ) / 100.00;

		$( '#txtRutaImporte' ).val( roundComasMilesString( montoDiarioNumber *  porcentaje, 2 ) );

	} else {
		// consoleLog( 'monto diario y porcentaje no son numeros' );
		$( '#txtRutaImporte' ).val( '0' );
	}
}

function changeSelRutaMedioTransporte() {

	//  limpia los campos de nacional
	setValueInputText( 'selDepartamentoRuta', '00' );
	setValueInputText( 'selProvinciaRuta', '00' );
	setValueInputText( 'hidCodigoPuntoPartidaRuta' , '' );
	// setValueInputText( 'txtRutaDiasViaticosNacional' , '' );
	// setValueInputText( 'txtRutaHorasViaticosNacional' , '' );

	disabledElement( 'selProvinciaRuta' );
	enabledElement( 'btnAceptarCrearNuevaRuta' );

	// limpia los campos de internacional
	var selRutaMedioTransporte = getTrimValue( '#selRutaMedioTransporte' );
	
	// si es seleccione ( en blanco )
	if ( selRutaMedioTransporte ==  '' ) {
		// setValueInputText( 'txtRutaImporte' , '' );
		// setValueInputText( 'txtRutaDiasViaticos' , '' );
		// setValueInputText( 'txtRutaDiasTraslado' , '' );
		
		// limpia campos del importe diario calculado
		limpiarCamposImporteDiario();
	}
}

function limpiarCamposImporteDiario() {

	setValueInputText( 'hidViaticoCodigoConcepto' , '' );
	setValueInputText( 'hidViaticoDescripcionConcepto' , '' );
	setValueInputText( 'hidViaticoClasificadorGasto' , '' );
	setValueInputText( 'hidViaticoMontoDiario' , '' );
	setValueInputText( 'hidViaticoCantidadPVI' , '' );
}

function obtenerCamposImporteDiarioNacional( codigoDepartamento, codigoProvincia ) {

	callAjaxObtenerImporteDiario( $('#selTipoViatico').val(), codigoDepartamento, codigoProvincia, '' );
}

function obtenerCamposImporteDiarioInternacional() {

	var codigoUbigeo = obtenerAtributoComboLugar( 'data-codigoubigeo' );
	var diastraslado = obtenerAtributoComboLugar( 'data-diastraslado' );

	if ( codigoUbigeo != '' ) {
		callAjaxObtenerImporteDiario( $('#selTipoViatico').val(), '', '', codigoUbigeo );
	}

	$( '#txtRutaDiasTraslado' ).val( diastraslado );
}

function obtenerAtributoComboLugar( nombreAtributo ) {
	// NOTA: el combo lugar guarda los atributos: data-diastraslado, data-codigoubigeo

	// si ha seleccionado lugar
	var selRutalugar = getTrimValue( '#selRutalugar' );
	if ( selRutalugar != '' ) {

		// se recoge el <option seleccionado
		var optionSelected = $('#selRutalugar option:selected');
		if ( optionSelected.length ) {
			return $.trim( optionSelected.attr( nombreAtributo ) );
		}

	}

	return '';
}

function obtenerAtributoComboTipoTarifa( nombreAtributo ) {
	// NOTA: el combo tipo tarifa guarda los atributos: data-porcentaje

	// si ha seleccionado lugar
	var selRutaTipoTarifa = getTrimValue( '#selRutaTipoTarifa' );
	if ( selRutaTipoTarifa != '' ) {

		// se recoge el <option seleccionado
		var optionSelected = $('#selRutaTipoTarifa option:selected');
		if ( optionSelected.length ) {
			return $.trim( optionSelected.attr( nombreAtributo ) );
		}
	}

	return '';
}

function changeSelRutalugar() {

	hideMessageErrorCrearNuevaRuta();
	
	// limpia campos del importe diario calculado
	limpiarCamposImporteDiario();

	var selRutalugar = getTrimValue( '#selRutalugar' );

	// si es seleccione ( en blanco )
	if ( selRutalugar ==  '' ) {

		setValueInputText( 'txtRutaImporte' , '0' );

		// setValueInputText( 'txtRutaDiasViaticos' , '' );
		// setValueInputText( 'txtRutaDiasTraslado' , '' );

	} else {

		obtenerCamposImporteDiarioInternacional();
	}
}

function changeSelRutaTipoTarifa() {

	hideMessageErrorCrearNuevaRuta();

	var optionSelected = $('#selRutaTipoTarifa option:selected');

	if ( optionSelected.length ) {

		// por default
		setValueInputText( 'txtRutaPorcentaje' , '' );
		enabledElement( 'txtRutaPorcentaje' );

		setValueInputText( 'txtRutaImporte' , '' );
		disabledElement( 'txtRutaImporte' );

		var selRutaTipoTarifaVal = $('#selRutaTipoTarifa').val();

		// si no seleccionada nada
		if ( selRutaTipoTarifaVal == '' ) {

			// el porcentaje se deshabilita
			setValueInputText( 'txtRutaPorcentaje' , '' );
			disabledElement( 'txtRutaPorcentaje' );

			// limpiamos campos y el importe de deshabilita
			setValueInputText( 'txtRutaImporte' , '0' );
			// setValueInputText( 'txtRutaDiasViaticos' , '' );
			// setValueInputText( 'txtRutaDiasTraslado' , '' );

			disabledElement( 'txtRutaImporte' );

		} else {

			// se pasa el % del combo a la caja de texto
			var porcentaje = optionSelected.attr( 'data-porcentaje' );
			setValueInputText( 'txtRutaPorcentaje' , $.trim( porcentaje ) );

			// como cambio el % actualizar el importe
			updateImporteViaticoInternacional();

			// solo tipo de tarifa es 'OTROS'
			if ( selRutaTipoTarifaVal == configRSV.constantes.RUTA_TIPO_TARIFA_OTROS ) {

				// el porcentaje se deshabilita
				setValueInputText( 'txtRutaPorcentaje' , '' );
				disabledElement( 'txtRutaPorcentaje' );

				// el importe se habilita
				setValueInputText( 'txtRutaImporte' , '' );
				enabledElement( 'txtRutaImporte' );

			}

		}

	}

}

function cargarComboPopupMedioTranporte() {

	var mediosTransporteList = configRSV.mediosTransporte;

	var selRutaMedioTransporte = $( '#selRutaMedioTransporte' );

	if (mediosTransporteList != null && mediosTransporteList.length > 0) {
		selRutaMedioTransporte.empty();

		// crear un option vacio 'seleccione'
		selRutaMedioTransporte.append( $( '<option></option>' ).attr( 'value', '' ).text( ' --Seleccione-- ' ) );

		for (var i = 0; i < mediosTransporteList.length; i++) {
			var medioTransporte = mediosTransporteList[i];

			var optionSelect = $( '<option></option>' ).attr( 'value', medioTransporte.codigo ).text( $.trim( medioTransporte.descripcion ).toUpperCase() );

			selRutaMedioTransporte.append(optionSelect);
		}

		enabledElement( 'selRutaMedioTransporte' );

		// carga por default GENERAL
		selRutaMedioTransporte.val( configRSV.constantes.MEDIO_TRANSPORTE_AEREO );
	}

}

function cargarComboPopupLugares() {

	var lugaresList = configRSV.lugares;

	var selRutalugar = $( '#selRutalugar' );

	if (lugaresList != null && lugaresList.length > 0) {
		selRutalugar.empty();

		// crear un option vacio 'seleccione'
		selRutalugar.append( $( '<option></option>' ).attr( 'value', '' ).attr( 'data-diastraslado', '' ).attr( 'data-codigoubigeo', '' ).text( ' --Seleccione-- ' ) );

		for (var i = 0; i < lugaresList.length; i++) {
			var lugar = lugaresList[i];

			var optionSelect = $( '<option></option>' ).attr( 'value', lugar.codigoLugar ).text( lugar.nombreLugar );

			// se agrega meta info
			optionSelect.attr( 'data-diastraslado',  lugar.diasTraslado);
			optionSelect.attr( 'data-codigoubigeo',  lugar.codigoUbigeo);

			selRutalugar.append(optionSelect);
		}

		enabledElement( 'selRutalugar' );
	}
}

function cargarComboPopupTarifas() {

	var tarifasList = configRSV.tarifas;

	var selRutaTipoTarifa = $( '#selRutaTipoTarifa' );

	if (tarifasList != null && tarifasList.length > 0) {
		selRutaTipoTarifa.empty();

		// crear un option vacio 'seleccione'
		selRutaTipoTarifa.append( $( '<option></option>' ).attr( 'value', '' ).attr( 'data-porcentaje', '' ).text( ' --Seleccione-- ' ) );

		for (var i = 0; i < tarifasList.length; i++) {
			var tarifa = tarifasList[i];

			var optionSelect = $( '<option></option>' ).attr( 'value', tarifa.codigo ).text( tarifa.descripcion );

			// se agrega meta info
			optionSelect.attr( 'data-porcentaje',  tarifa.porcentaje);

			selRutaTipoTarifa.append(optionSelect);
		}

		// carga por default GENERAL
		selRutaTipoTarifa.val( configRSV.constantes.RUTA_TIPO_TARIFA_GENERAL );
	}
}

function crearNuevoDesplazamiento() {
	// en desplazamiento se guardan todos los campos ya sea nacional (mayor o menor a 4h) o internacional.
	// a la derecha del campoo, se coloca a cual tipo de viatico / duracion comision pertenece y si es hidden o no
	var desplazamiento = {
		"medioTransporte": '',																// todos
		"departamento": '',																	// nacional
		"provincia": '',																	// nacional
		"lugarDestino": '',																	// internacional
		"diasViatico": '',																	// nacional > 4 horas, e internacional
		"horasViatico": '',																	// nacional <= 4horas
		"importeDiario": '',																// todos
		"importeDiarioTope": '',															// todos
		"importeViatico": '',																// todos
		"diasTraslado": '',																	// internacional
		"diasTrasladoTope": '',																// internacional
		"viajeExtGtoTras": '',																// internacional
		"viajeExtGtoTrasTope": '',															// internacional
		"totalOtorgado": '',																// internacional
		"codigoMedioTransporte": '',														// todos
		"codigoProvincia": '',																// nacional hidden
		"codigoDepartamento": '',															// nacional hidden
		"codigoLugar": '',																	// nacional hidden
		"codigoLugarDestino": '',															// internacional hidden
		"codigoTarifario": '',														   	    // internacional hidden
		"porcentajeTarifario": ''															// internacional hidden
	};

	var selTipoViatico = $('#selTipoViatico').val();
	var selDuracionComision = $('#selDuracionComision').val();

	// si es nacional
	if ( selTipoViatico == 'nacional' ) {

		desplazamiento.medioTransporte = $.trim( $('#selRutaMedioTransporte option:selected').text() ).toUpperCase();
		desplazamiento.codigoMedioTransporte = $('#selRutaMedioTransporte').val();

		desplazamiento.departamento = $('#selDepartamentoRuta option:selected').text();
		desplazamiento.provincia = $('#selProvinciaRuta option:selected').text();
		desplazamiento.codigoProvincia = $('#selProvinciaRuta').val();
		desplazamiento.codigoDepartamento = $('#selDepartamentoRuta').val();
		desplazamiento.codigoLugar = $('#hidCodigoPuntoPartidaRuta').val();
		
		// si es mayor a 4 horas
		if ( selDuracionComision == 'may4h' ) {

			desplazamiento.diasViatico = toNumero( $('#txtRutaDiasViaticosNacional').val() );
			desplazamiento.importeDiario =  roundString( toNumero( $('#hidViaticoMontoDiario').val() ), 1 );
			desplazamiento.importeDiarioTope = roundString( toNumero( $('#hidViaticoMontoDiario').val() ), 2 );

			// campos calculados:

			// importeViatico = diasViatico * importeDiario
			desplazamiento.importeViatico = roundString( toNumero(desplazamiento.diasViatico) * toNumero(desplazamiento.importeDiario), 1 );

		} else {	// si es menor o igual a 4 horas

			// las horas se redondean a 1 digito y los importes diario y diario tope se dividen entre 24 horas
			desplazamiento.horasViatico = roundString( toNumero( $('#txtRutaHorasViaticosNacional').val() ), 1 );
			desplazamiento.importeDiario = roundString( toNumero( $('#hidViaticoMontoDiario').val() ) / 24.0, 1 );
			desplazamiento.importeDiarioTope = roundString( toNumero( $('#hidViaticoMontoDiario').val() ) / 24.0, 2 );

			// campos calculados:

			// importeViatico = diasViatico * importeDiario
			desplazamiento.importeViatico = roundString( toNumero(desplazamiento.horasViatico) * toNumero(desplazamiento.importeDiario), 1 );
		}

	} else { // si es internacional

		desplazamiento.medioTransporte = $.trim( $('#selRutaMedioTransporte option:selected').text() ).toUpperCase();
		desplazamiento.codigoMedioTransporte = $('#selRutaMedioTransporte').val();

		desplazamiento.lugarDestino = $('#selRutalugar option:selected').text();
		desplazamiento.diasViatico = toNumero( $('#txtRutaDiasViaticos').val() );
		desplazamiento.diasTraslado = toNumero( $('#txtRutaDiasTraslado').val(), 0 ); // dias de traslado es opcional, 0 sino ingresa nada
		desplazamiento.diasTrasladoTope = toNumero( obtenerAtributoComboLugar( 'data-diastraslado' ), 0 );
		desplazamiento.viajeExtGtoTras = roundString( toNumero( $('#hidViaticoMontoDiario').val() ), 2 );
		desplazamiento.viajeExtGtoTrasTope = roundString( toNumero( $('#hidViaticoMontoDiario').val() ), 2 );
		desplazamiento.codigoLugarDestino = $('#selRutalugar').val();
		desplazamiento.importeDiario = roundString( toNumero( $('#txtRutaImporte').val().replace(/,/g , '') ), 1 );
		desplazamiento.importeDiarioTope = roundString( toNumero( $('#hidViaticoMontoDiario').val() ), 2 );

		desplazamiento.codigoTarifario = getTrimValue( '#selRutaTipoTarifa' );
		
		desplazamiento.porcentajeTarifario = getTrimValue( '#txtRutaPorcentaje' );
		if ( desplazamiento.porcentajeTarifario != '' ) {
			desplazamiento.porcentajeTarifario = toNumero( desplazamiento.porcentajeTarifario ) / 100.0;
		}
		
		// campos calculados:

		// importeViatico = diasViatico * importeDiario
		desplazamiento.importeViatico = roundString( toNumero(desplazamiento.diasViatico) * toNumero(desplazamiento.importeDiario), 1 );

		var viajeExtraPorDiasTraslado = roundString( toNumero(desplazamiento.viajeExtGtoTras) * toNumero(desplazamiento.diasTraslado), 2 );

		// importeViatico + viajeExtGtoTras * diasTraslado
		desplazamiento.totalOtorgado = roundString( toNumero( desplazamiento.importeViatico ) + toNumero( viajeExtraPorDiasTraslado ), 2 );
	}

	// recoger lista de desplazamientos
	var desplazamientos = getDesplazamientosList();

	// agregar a la lista de desplazamientos
	desplazamientos.push( desplazamiento );

	// actualizar grilla de desplazamientos
	fillGrilla( '#tblDesplazamientoRSV', getDesplazamientosList() );
	updateTotalDesplazamientos();

	// activa/desactiva la seccion de la botonera
	updateEstadosPanelBotones();

	removeEventElementsCrearNuevaRuta();

	$( '#divCrearNuevaRuta' ).modal( 'hide' );
}

function calcularImporteDiarioTopeInternacional() {
	// NOTA: usar este metodo si piden cambiar el importe diario total segun el tipo de tarifa y porcentaje (ignorando lo que esta en escala de viaticos)

	var importeTope = '0.00';

	var montoDiario = getTrimValue( '#hidViaticoMontoDiario' );
	var optionSelected = $('#selRutaTipoTarifa option:selected');
	
	if ( montoDiario != '' && optionSelected.length ) {

		var porcentaje = $.trim( optionSelected.attr( 'data-porcentaje' ) );

		if ( porcentaje != '' ) {

			var montoDiarioNumber = toNumero( montoDiario );
			var porcentajeNumber = toNumero( porcentaje ) / 100.00;

			importeTope = roundString( montoDiarioNumber * porcentajeNumber, 2 );

		}

	}

	 return importeTope;
}

function validarDesplazamiento() {

	var result = {
		'hayError': false,
		'msgError': '',
		'queryControlFocus': null
	};

	hideMessageErrorCrearNuevaRuta();

	var selTipoViatico = $( '#selTipoViatico' ).val();
	var selDuracionComision = $( '#selDuracionComision' ).val();
	var desplazamientos = getDesplazamientosList();

	// nacional
	if ( selTipoViatico == 'nacional' ) {

		var selProvinciaRuta = getTrimValue( '#selProvinciaRuta' );
		var selDepartamentoRuta = getTrimValue( '#selDepartamentoRuta' );
		var selRutaMedioTransporte = getTrimValue( '#selRutaMedioTransporte' );
		
		// validacion adicional (el F2 no considera validar el ingreso de medio de transporte)
		if ( selRutaMedioTransporte == '' ) {
			result.hayError = true;
			result.msgError = configRSV.mensajes.debeSeleccionarMedioTransporte;
			result.queryControlFocus = '#selRutaMedioTransporte';

			return result;
		}		
		
		// que ingrese departamento
		if ( selDepartamentoRuta == '00' ) {
			result.hayError = true;
			result.msgError = configRSV.mensajes.seleccioneDepartamentoOrigen;
			result.queryControlFocus = '#selDepartamentoRuta';
			
			return result;
		}

		// que ingrese provincia
		if ( selProvinciaRuta == '00' ) {
			result.hayError = true;
			result.msgError = configRSV.mensajes.debeSeleccionarProvinciaDelDesplazamiento;
			result.queryControlFocus = '#selProvinciaRuta';

			return result;
		}
		
		if ( selDuracionComision == 'may4h' ) {	// si es mayor a 4 horas

			// numero de dias ingresados en el popup
			var txtRutaDiasViaticosNacional = getTrimValue( '#txtRutaDiasViaticosNacional' );

			// numero de dias sugerido
			var nroDiasComisionSugerido = obtenerNumeroDiasHorasComisionDesplazamiento();			

			if ( hayDiasHorasRestantes() ) {

				// que no pase lo sugerido
				if ( txtRutaDiasViaticosNacional == '' ||  
					toNumero( txtRutaDiasViaticosNacional ) <= 0.0 ||
					toNumero( txtRutaDiasViaticosNacional ) > toNumero( nroDiasComisionSugerido ) ) {
					
					var msg = configRSV.mensajes.debeIngresarDiasParaDesplazamiento;
					msg = msg.replace( /NRO_DIAS/g, nroDiasComisionSugerido );					
					
					result.hayError = true;
					result.msgError = msg;
					result.queryControlFocus = '#txtRutaDiasViaticosNacional';

					return result;
				}				

			} else {

				// que no ingrese ceros
				if ( txtRutaDiasViaticosNacional == '' || 
					toNumero( txtRutaDiasViaticosNacional ) <= 0.0 ) {
					
					result.hayError = true;
					result.msgError = 'Debe ingresar la cantidad de d&iacute;as y este debe ser mayor a cero';
					result.queryControlFocus = '#txtRutaDiasViaticosNacional';

					return result;
				}				

				// validacion adicional (que los dias de desplazamiento ingreso mas lo de la grilla no supere lo programado)
				var nroDiasHorasComision = obtenerNumeroDiasHorasComision();
				var nroDiasHorasDesplazamiento = calcularDiasHorasDesplazamiento();					// lo ingresado en la grilla				

				if ( esNumero( nroDiasHorasComision ) && esNumero( nroDiasHorasDesplazamiento ) && esNumero( txtRutaDiasViaticosNacional ) ) {

					var sumaDesplazamientos = toNumero( nroDiasHorasDesplazamiento ) + toNumero( txtRutaDiasViaticosNacional );
					if ( sumaDesplazamientos > toNumero( nroDiasHorasComision ) ) {

						result.hayError = true;
						result.msgError = 'La cantidad total de d&iacute;as supera la cantidad de d&iacute;as del detalle de la solicitud, verificar';
						result.queryControlFocus = '#txtRutaDiasViaticosNacional';

						return result;
					}

				}

			}

		} else {  // si es menor o igual a 4 horas

			// numero de horas ingresado en el popup
			var txtRutaHorasViaticosNacional = getTrimValue( '#txtRutaHorasViaticosNacional' );

			// numero de horas sugerido
			var nroHorasComisionSugerido = obtenerNumeroDiasHorasComisionDesplazamiento();

			if ( hayDiasHorasRestantes() ) {
				
				// validación adicional
				if ( txtRutaHorasViaticosNacional == '' || 
					toNumero( txtRutaHorasViaticosNacional ) <= 0.0 ||
					toNumero( txtRutaHorasViaticosNacional ) > toNumero( nroHorasComisionSugerido ) ) {
					
					var msg = configRSV.mensajes.debeIngresarHorasParaDesplazamiento;
					msg = msg.replace( /NRO_HORAS/g, nroHorasComisionSugerido );		
					
					result.hayError = true;
					result.msgError = msg;
					result.queryControlFocus = '#txtRutaHorasViaticosNacional';
					
					return result;
				}					

			} else {

				// que no ingrese ceros
				if ( txtRutaHorasViaticosNacional == '' || 
					toNumero( txtRutaHorasViaticosNacional ) <= 0.0 ) {
					
					result.hayError = true;
					result.msgError = configRSV.mensajes.noPuedeRegistrarCantidadHorasIgualCero;
					result.queryControlFocus = '#txtRutaHorasViaticosNacional';

					return result;
				}				

				var nroDiasHorasDesplazamiento = calcularDiasHorasDesplazamiento();

				if ( esNumero( nroDiasHorasDesplazamiento ) && esNumero( txtRutaHorasViaticosNacional ) ) {
					
					var sumaDesplazamientos = toNumero( nroDiasHorasDesplazamiento ) + toNumero( txtRutaHorasViaticosNacional );
					if ( sumaDesplazamientos > toNumero( nroDiasHorasComision ) ) {

						result.hayError = true;
						result.msgError = 'La cantidad total de horas supera la cantidad de horas del detalle de la solicitud, verificar';
						result.queryControlFocus = '#txtRutaHorasViaticosNacional';

						return result;
					}

				}

			}

		}		

		// desplazamiento repetido
		var hidCodigoPuntoPartidaRuta = $('#hidCodigoPuntoPartidaRuta').val();
		var posDesplazamiento = indexOfDesplazamientoNacional( desplazamientos, hidCodigoPuntoPartidaRuta );

		if ( posDesplazamiento >= 0 ) {
			result.hayError = true;
			result.msgError = configRSV.mensajes.desplazamientoYaFueRegistrado;
			result.queryControlFocus = '#selProvinciaRuta';

			return result;
		}

	} else { // internacional

		var selRutalugar = getTrimValue( '#selRutalugar' );
		var selRutaTipoTarifa = getTrimValue( '#selRutaTipoTarifa' );
		var selRutaMedioTransporte = getTrimValue( '#selRutaMedioTransporte' );
		var txtRutaDiasViaticos = getTrimValue( '#txtRutaDiasViaticos' );
		var txtRutaImporte = getTrimValue( '#txtRutaImporte' );
		var txtRutaDiasTraslado = getTrimValue( '#txtRutaDiasTraslado' );
		var txtRutaPorcentaje = getTrimValue( '#txtRutaPorcentaje' );
		var hidViaticoMontoDiario = getTrimValue( '#hidViaticoMontoDiario' );

		// quitando las ',' de los montos
		if ( txtRutaImporte != '' ) {
			txtRutaImporte =  txtRutaImporte.replace(/,/g , '');
		}		
		
		if ( selRutaMedioTransporte == '' ) {
			result.hayError = true;
			result.msgError = configRSV.mensajes.debeSeleccionarMedioTransporte;
			result.queryControlFocus = '#selRutaMedioTransporte';

			return result;
		}		
		
		if ( selRutalugar == '' ) {
			result.hayError = true;
			result.msgError = configRSV.mensajes.debeSeleccionarLugar;
			result.queryControlFocus = '#selRutalugar';

			return result;
		}
		
		// validacion adiciona (el F2 no considera validar el tipo de tarifa,
		// valida el monto, si tipo de tarifa no se ingreso el monto no tiene valor valido)
		if ( selRutaTipoTarifa == '' ) {
			result.hayError = true;
			result.msgError = configRSV.mensajes.debeSeleccionarTarifa;
			result.queryControlFocus = '#selRutaTipoTarifa';

			return result;
		}		
		
		if ( hayDiasHorasRestantes() ) {

			// que ingrese dentro del rango de lo sugerido
			var nroDiasComisionSugerido = obtenerNumeroDiasHorasComisionDesplazamiento();
			
			if ( txtRutaDiasViaticos == '' || 
				toNumero( txtRutaDiasViaticos ) <= 0.0 ||
				toNumero( txtRutaDiasViaticos ) > toNumero( nroDiasComisionSugerido ) ) {
				
				var msg = configRSV.mensajes.debeIngresarDiasParaDesplazamiento;
				msg = msg.replace( /NRO_DIAS/g, nroDiasComisionSugerido );				
				
				result.hayError = true;
				result.msgError = msg;
				result.queryControlFocus = '#txtRutaDiasViaticos';

				return result;
			}	

		} else {

			var nroDiasComisionSugerido = obtenerNumeroDiasHorasComisionDesplazamiento();

			// que no ingrese ceros
			if ( toNumero( txtRutaDiasViaticos ) <= 0.0 ) {
				
				result.hayError = true;
				result.msgError = 'Debe ingresar la cantidad de d&iacute;as y este debe ser mayor a cero';
				result.queryControlFocus = '#txtRutaDiasViaticos';

				return result;
			}			

			var nroDiasHorasComision = obtenerNumeroDiasHorasComision();
			var nroDiasHorasDesplazamiento = calcularDiasHorasDesplazamiento();		// lo ingresado en la grilla

			if ( esNumero( nroDiasHorasComision ) && esNumero( nroDiasHorasDesplazamiento ) && esNumero( txtRutaDiasViaticos ) ) {

				var sumaDesplazamientos = toNumero( nroDiasHorasDesplazamiento ) + toNumero( txtRutaDiasViaticos );
				if ( sumaDesplazamientos > toNumero( nroDiasHorasComision ) ) {

					result.hayError = true;
					result.msgError = 'La cantidad total de d&iacute;as supera la cantidad de d&iacute;as del detalle de la solicitud, verificar';
					result.queryControlFocus = '#txtRutaDiasViaticos';

					return result;
				}

			}

		}

	

		// que porcentaje sea mayor a 0
		if ( txtRutaPorcentaje != '' ) {
			if ( !( toNumero( txtRutaPorcentaje ) > 0 ) ) {
			
				result.hayError = true;
				result.msgError = configRSV.mensajes.noSePuedeRegistrarPorcIgualACero;
				result.queryControlFocus = '#txtRutaPorcentaje';

				return result;				
			}
		}			

		// NOTA: aquí ya valida que no ingrese texto
		if ( txtRutaImporte == '' || toNumero( txtRutaImporte ) <= 0.0 ) {
			result.hayError = true;
			result.msgError = configRSV.mensajes.importeDebeSerMayorACero;
			result.queryControlFocus = '#txtRutaImporte';

			return result;
		}

		// desplazamiento repetido
		var selRutalugar = getTrimValue( '#selRutalugar' );
		var posDesplazamiento = indexOfDesplazamientoInternacional( desplazamientos, selRutalugar );

		if ( posDesplazamiento >= 0 ) {
			result.hayError = true;
			result.msgError = configRSV.mensajes.lugarSeleccionadoYaFueRegistradoCorregir;
			result.queryControlFocus = '#selRutalugar';

			return result;
		}

		// validacion adicional (validación de de tipo)
		if ( txtRutaDiasTraslado != '' && !esNumero( txtRutaDiasTraslado ) ) {
			result.hayError = true;
			result.msgError = 'D&iacute;as de traslado debe ser un n&uacute;mero';
			result.queryControlFocus = '#txtRutaDiasTraslado';

			return result;
		}		
		
		// validacion adicional (que no ingrese dias de traslado superiores al maximo) porque en el F2 solo considera esta validacion al salir del foco
		// si ingreso dias de traslado y escogio ruta (para poder obtener el maximo de dias para traslado)
		if ( txtRutaDiasTraslado != '' && selRutalugar != '' ) {

			var rutaDiasTrasladoMax = obtenerAtributoComboLugar( 'data-diastraslado' );

			if ( toNumero( txtRutaDiasTraslado ) > toNumero( rutaDiasTrasladoMax )  ) {

				var msg = configRSV.mensajes.topeMaxAsigDiasTraslado;
				msg = msg.replace( /NRO_DIAS/g, rutaDiasTrasladoMax );

				result.hayError = true;
				result.msgError = msg;
				result.queryControlFocus = '#txtRutaDiasTraslado';

				return result;
			}

		}
		
		// validacion adicional (que no ingrese porcentaje superiores al maximo) porque en el F2 solo considera esta validacion al salir del foco
		var porcentaje = $.trim( obtenerAtributoComboTipoTarifa( 'data-porcentaje' ) );
		if ( txtRutaPorcentaje != '' && porcentaje != '' ) {
			if ( toNumero( txtRutaPorcentaje ) > toNumero( porcentaje ) ) {
				
				var msg = configRSV.mensajes.noSePuedeRegistrarPorcMayorAlMaximoPermitido;
				msg = msg.replace( /PORC_MAXIMO/g, porcentaje );

				result.hayError = true;
				result.msgError = msg;
				result.queryControlFocus = '#txtRutaPorcentaje';

				return result;	
				
			}
		}
		
		// validacion adicional	(que porcentaje sea mayor a 0) porque en el F2 solo considera esta validacion al salir del foco
		if ( txtRutaPorcentaje != '' ) {
			if ( !( toNumero( txtRutaPorcentaje ) > 0 ) ) {
				
				result.hayError = true;
				result.msgError = configRSV.mensajes.noSePuedeRegistrarPorcIgualACero;
				result.queryControlFocus = '#txtRutaPorcentaje';
				
				return result;	
			}
		}
		
		// validacion adicional (que importe no supere el maximo permitido)
		if ( hidViaticoMontoDiario != '' ) {
			if ( toNumero( txtRutaImporte ) > toNumero( hidViaticoMontoDiario ) ) {
				
				var msg = configRSV.mensajes.elImporteNoDebeSuperarElTipoMonedaMontoMaximo;
				msg = msg.replace( /TIPO_MONEDA/g, configRSV.moneda );
				msg = msg.replace( /MONTO_MAXIMO/g, hidViaticoMontoDiario );

				result.hayError = true;
				result.msgError = msg;
				result.queryControlFocus = '#txtRutaImporte';
				
				return result;	
			}
		}		
		
	}

	return result;
}

function indexOfDesplazamientoNacional( lista, codigoLugarBuscar ) {

	var pos = -1;

	if ( isNullOrUndefined( lista ) || lista.length == 0 ) return pos;

	$.each(lista, function(i, item) {

		// criterios de comparacion
		if ( $.trim( item.codigoLugar ) == $.trim( codigoLugarBuscar ) ) {

			pos = i;
			return false; // break
		}

	});

	return pos;
}

function indexOfDesplazamientoInternacional( lista, codigoLugarDestino ) {

	var pos = -1;

	if ( isNullOrUndefined( lista ) || lista.length == 0 ) return pos;

	$.each(lista, function(i, item) {

		// criterios de comparacion
		if ( $.trim( item.codigoLugarDestino ) == $.trim( codigoLugarDestino ) ) {

			pos = i;
			return false; // break
		}

	});

	return pos;
}

function showMessageErrorCrearNuevaRuta(errorMessage) {
	setHtmlElement( 'etiquetaErrorCrearNuevaRuta' , errorMessage);
	showElement( 'divErrorCrearNuevaRuta' );
}

function hideMessageErrorCrearNuevaRuta() {
	setHtmlElement( 'etiquetaErrorCrearNuevaRuta', '');
	hideElement( 'divErrorCrearNuevaRuta' );
}

function callAjaxValidarDesplazamiento() {

	var dataPost = { };

	// campos comunes a ambos (nacional internacional)
	dataPost.selTipoViatico = $('#selTipoViatico').val();
	dataPost.selDuracionComision = $('#selDuracionComision').val();

	dataPost.selRutaMedioTransporte = $('#selRutaMedioTransporte').val();

	dataPost.desplazamientos = configRSV.desplazamientos;

	dataPost.hidViaticoCodigoConcepto = $('#hidViaticoCodigoConcepto').val();
	dataPost.hidViaticoDescripcionConcepto = $('#hidViaticoDescripcionConcepto').val();
	dataPost.hidViaticoClasificadorGasto = $('#hidViaticoClasificadorGasto').val();
	dataPost.hidViaticoMontoDiario = $('#hidViaticoMontoDiario').val();
	dataPost.hidViaticoCantidadPVI = $('#hidViaticoCantidadPVI').val();


	if ( dataPost.selTipoViatico == 'nacional' ) {
		
		// campos adicionales para nacional
		dataPost.selDepartamentoRuta = $('#selDepartamentoRuta').val();
		dataPost.selProvinciaRuta = $('#selProvinciaRuta').val();
		dataPost.txtRutaDiasViaticosNacional = $('#txtRutaDiasViaticosNacional').val();
	}

	if ( dataPost.selTipoViatico == 'internacional' ) {
		
		// campos adicionales para internacional
		dataPost.selRutalugar = $('#selRutalugar').val();
		dataPost.selRutalugarDiasTrasladoMax = obtenerAtributoComboLugar( 'data-diastraslado' );
		dataPost.selRutalugarCodigoUbigeo = obtenerAtributoComboLugar( 'data-codigoubigeo' );

		dataPost.selRutaTipoTarifa = $('#selRutaTipoTarifa').val();
		dataPost.selRutaTipoTarifaPorcentajeMax = obtenerAtributoComboTipoTarifa( 'data-porcentaje' );

		dataPost.txtRutaPorcentaje = $('#txtRutaPorcentaje').val();
		dataPost.txtRutaImporte = $('#txtRutaImporte').val().replace(/,/g , '');
		dataPost.txtRutaDiasViaticos = $('#txtRutaDiasViaticos').val();
		dataPost.txtRutaDiasTraslado = $('#txtRutaDiasTraslado').val();
	}

	$.ajax({
		url: contextPathUrl + "/registrarSolicitud.htm?action=validarDesplazamiento",
		data: dataPost,
		type: "post",
		dataType: "json",
		cache: false,
		beforeSend: function() {
			// bloquearScreen();
			// showElement("divLoadingCrearNuevaRuta");
		},
		complete: function() {
			// desbloquearScreen();
			// hideElement("divLoadingCrearNuevaRuta");
		},
		success: function(result) {

			if ( huboErrorAjax( result ) ) {
				handleErrorAjax( result );
				return;
			}

			if ( result.validacionOk == 'si' ) {

				crearNuevoDesplazamiento();

			} else {
				// mostrar el mensaje personalizado al usuario
				showMessageErrorCrearNuevaRuta(result.validacionMsg);
				return;
			}

		},
		error: function( error ) {
			handleError( error );
		}
	});

}

function callAjaxObtenerLugarByCodigoRuta(codigoDepartamentoRuta, codigoProvinciaRuta) {

	$.ajax({
		url: contextPathUrl + "/viatico.htm?action=obtenerLugaresByCodigo",
		type: "post",
		dataType: "json",
		cache: false,
		data: {
			"codigoDepartamento": codigoDepartamentoRuta,
			"codigoProvincia": codigoProvinciaRuta
		},
		beforeSend: function() {
			// bloquearScreen();
			// showElement("divLoadingCrearNuevaRuta");
		},
		complete: function() {
			// desbloquearScreen();
			// hideElement("divLoadingCrearNuevaRuta");
			updateBotonAgregarDesplazamientoRuta();
		},
		success: function(result) {

			if ( huboErrorAjax( result ) ) {
				handleErrorAjax( result );
				return;
			}

			var codigoLugar = $.trim( result.codigoLugar );
			var codigoUbigeo = $.trim( result.codigoUbigeo );

			// hay casos que la tabla txxx8lugarubigeo no contiene todas las combinaciones departamento/provincia y trae blancos
			/*
			if ( codigoLugar == '' ) {
				consoleLog( 'no existe lugar para el departamento y provincia seleccionados: ' + codigoDepartamentoRuta + " " + codigoProvinciaRuta );
			}
			*/
			$('#hidCodigoPuntoPartidaRuta').val( codigoLugar );

		},
		error: function( error ) {
			handleError( error );
		}
	});
}

function callAjaxObtenerImporteDiario(tipoViatico, codigoDepartamentoRuta, codigoProvinciaRuta, codigoUbigeo) {

	hideMessageErrorCrearNuevaRuta();

	$.ajax({
		url: contextPathUrl + "/solicitud.htm?action=obtenerImporteDiario",
		type: "post",
		dataType: "json",
		cache: false,
		data: {
			"tipoViatico": tipoViatico,
			"codigoDepartamento": codigoDepartamentoRuta,
			"codigoProvincia": codigoProvinciaRuta,
			"codigoUbigeo": codigoUbigeo,
			"codColaborador": getValueInputText( 'hidCodigoColaboradorDesplazamiento'),
			"provinciaPuntoPartida": $.trim( configRSV.puntoPartida.codigoProvincia ),
			"departamentoPuntoPartida": $.trim( configRSV.puntoPartida.codigoDepartamento )
		},
		beforeSend: function() {
			// bloquearScreen();
			// showElement("divLoadingCrearNuevaRuta");
		},
		complete: function() {
			// desbloquearScreen();
			// hideElement("divLoadingCrearNuevaRuta");
		},
		success: function(result) {

			if ( huboErrorAjax( result ) ) {
				handleErrorAjax( result ); 
				return;
			}

			if ( result.hayImporte == 'no' ) {
			
				showMessageErrorCrearNuevaRuta( 'Importe diario no ha sido configurado para este lugar' );

			} else if ( result.hayImporte == 'si' ) {

				// para nacional solo basta con guardar los datos en los hidden
				setValueInputText( 'hidViaticoCodigoConcepto', $.trim( result.codigoConcepto ) );
				setValueInputText( 'hidViaticoDescripcionConcepto', $.trim( result.descripcionConcepto ) );
				setValueInputText( 'hidViaticoClasificadorGasto', $.trim( result.clasificadorGasto ) );
				setValueInputText( 'hidViaticoMontoDiario', $.trim( result.montoDiario ) );
				setValueInputText( 'hidViaticoCantidadPVI', $.trim( result.cantidadPVI ) ); // NOTA: no se que hace aun este campo

				// para internacional se debe hacer un calculo adicional del importe
				if ( tipoViatico == 'internacional' ) {
					updateImporteViaticoInternacional();
				}
			}

		},
		error: function( error ) {
			handleError( error );			
		}
	});
}

function callAjaxObtenerDepartamentoRuta() {
	// este metodo esta en registrarModificarSolicitud-rest.js
	callAjaxObtenerDepartamento( 'selDepartamentoRuta' );
}

function callAjaxObtenerProvinciaRuta( selDepartamentoValue, departamentoOrigen, provinciaOrigen ) {
	
	$.ajax({
		url: contextPathUrl + "/parametros.htm?action=obtenerProvincias",
		type: "post",
		dataType: "json",
		cache: false,
		data: {
			"codigoDepartamento": selDepartamentoValue
		},
		beforeSend: function() {
			// bloquearScreen();
			// showElement("divLoadingCrearNuevaRuta");
		},
		complete: function() {
			// desbloquearScreen();
			// hideElement("divLoadingCrearNuevaRuta");
		},
		success: function(result) {
			var provinciaList = result.provinciaList;
			if (provinciaList != null && provinciaList.length > 0) {
				
				var provinciaSel = $( '#selProvinciaRuta' );
				provinciaSel.empty();
				
				var selDepartamentoRutaSelect = $( '#selDepartamentoRuta' ).val();
				
				for (var i = 0; i < provinciaList.length; i++) {
					var provincia = provinciaList[i];
					
					var agregar = !(departamentoOrigen == selDepartamentoRutaSelect && provinciaOrigen == provincia.codiProvTpr);
						
					if ( agregar ) {
						
						var optionSelect = $( '<option></option>' ).attr("value", provincia.codiProvTpr).text(provincia.nombProvTpr);
						provinciaSel.append(optionSelect);
					}
					
				}
				
				enabledElement( 'selProvinciaRuta' );
			}
		},
		error: function( error ) {
			handleError( error );
		}
	});	
}

function obtenerNumeroDiasHorasComisionDesplazamiento() {

	// en esta ventana puede que venga un número de días restantes sugerido,
	// si ese fuera el caso mostrar este número, 
	// sino mostrar el máximo permitido en lo programado
	var nroDiasHorasRestantes = getTrimValue( '#hidNroDiasHorasRestantesDesplazamiento' );

	if ( esNumero( nroDiasHorasRestantes ) ) {
		return nroDiasHorasRestantes;
	}

	// por default retornar el número de días/horas máximo programado
	return obtenerNumeroDiasHorasComision();
}

function hayDiasHorasRestantes() {

	// determina si hay dias/horas restantes para ingresar, 
	// de modo que se pueda personalizar el mensaje de ingresar solo en el rango permitido, o si ya supero el maximo

	// recuperar lo sugerido
	var nroDiasHorasRestantes = getTrimValue( '#hidNroDiasHorasRestantesDesplazamiento' );

	return esNumero( nroDiasHorasRestantes );
}
