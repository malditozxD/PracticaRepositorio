var clickBtnAceptarMensajeError = function(){
	$("#divMensajeErrorPdfFirmado").modal("hide");//quitamos el mensaje de error
};


var numArchivoPdfFirmado = null;
var listaArchivosPdfFirmados = null;
var clickBtnSiConfirmaFirmaElectronica = function(){
	
	numArchivoPdfFirmado = null;
	listaArchivosPdfFirmados = null;
	
	firmarDeclaracionJurada(function(resultado){
		//Aquí el resultado luego de procesar la firma electronica
		$("#divMensajeConfirmaPdfFirmado").modal("hide");
		if(resultado.firmaValidaYGrabada){			
			
			if(tipoProcesamiento!=null && tipoProcesamiento == "M"){
				
				listaArchivosPdfFirmados = resultado.archivos;//retorna una lista de mapas [{numArchivo:00000001,tipDocumento:017,numDocumento:20165E2302R000053},{numArchivo:00000002,tipDocumento:914,numDocumento:20165E2302R000053}]
				functionAfterSignMasiva();	
			}else{
				//Procesamiento individual
				numArchivoPdfFirmado = resultado.numArchivo;
				//TODO, afinar aqui
				//alert("Firma realizada");
				functionAfterSign();
			}
			
		}else{
			$("#spaMensajeAlertaErrorPdfFirmado").html("Ocurrió un error al firmar el/los documentos.");
			$("#divMensajeErrorPdfFirmado").modal("show");
		}
	});
};

var clickBtnNoConfirmaFirmaElectronica = function(){
	$("#divMensajeConfirmaPdfFirmado").modal("hide");//quitamos el mensaje de error
};


var clickBtnCancelarFirmaElectronica = function(){
	$("#divFormularioFirmaElectronica").modal("hide");//quitamos la pantalla de firma electronica
};


//funciones a ejecutar para cada proceso de negocio

var functionAfterSign = null;
var functionGenerateDataSign = null;
var functionAfterSignMasiva = null;

var setDatosFirmaElectronica = function(dataSign, afterSign, afterSignMasiva){
	functionGenerateDataSign = dataSign;
	functionAfterSign = afterSign;
	functionAfterSignMasiva = afterSignMasiva;
};


var clickBtnAceptarFirmaElectronica = function(){
	//1. Validar de que la firma sea correcta
	validarUsuarioLdap();
};

var generaMensaje = function(){
	var datosFirma = generateDataFirma();
	
	var mensajeParcial = "";
	
	if(tipoProcesamiento!=null && tipoProcesamiento == "M"){
		
		var cantidad = datosFirma["listaDocumentos"].split(",").length;
		if("043"==datosFirma["tipDocumento"])mensajeParcial = cantidad+" Planillas de Viáticos.";
		else if("048"==datosFirma["tipDocumento"])mensajeParcial = cantidad+" Rendicion de Planillas.";
		
	}else{
		
		if("043"==datosFirma["tipDocumento"])mensajeParcial = "la Planilla de Vi\u00E1tico N\u00B0 "+datosFirma["variableImprimirSendPost"];
		else if("048"==datosFirma["tipDocumento"])mensajeParcial = "la Rendici\u00F3n de Planilla N\u00B0 "+datosFirma["variableImprimirSendPost"];	
	}
	
	var mensaje = "Mediante la aceptaci\u00F3n del siguiente proceso usted est\u00E1 firmando electr\u00F3nicamente "+mensajeParcial;
	
	
	return mensaje;
};


var validarUsuarioLdap = function() {
	var dataJson = functionGenerateDataSign();
	$.ajax({
		url: contextPathUrl + "/firmaElectronica.htm?action=usuarioLdapValido",
		type: "post",
		dataType: "json",
		cache: false,
		data: dataJson,
		success: function(result) {
			$("#divFormularioFirmaElectronica").modal("hide");
			if(result.usuarioValido){
				
				//$("#spaMensajeConfirmaPdfFirmado").html(generaMensaje());
				//$("#divMensajeConfirmaPdfFirmado").modal("show");
				
				//Aquí realizar el procesamiento de la firma
				clickBtnSiConfirmaFirmaElectronica();
				
			}else{
				//Mostramos mensaje de error y termina el CUS
				$("#spaMensajeAlertaErrorPdfFirmado").html("La contrase\u00F1a es incorrecta, este debe ser igual al usado para acceder a la intranet");
				$("#divMensajeErrorPdfFirmado").modal("show");
			}
			
		},
		error: function() {
		}
	});
};


var firmarDeclaracionJurada = function(firmarDeclaracionJuradaCallback) {
	var dataJson = functionGenerateDataSign();
	$.ajax({
		url: contextPathUrl + "/firmaElectronica.htm?action=validarFirmaPassword",
		type: "post",
		dataType: "json",
		cache: false,
		data: dataJson,
		beforeSend: function() {
			showElement("divLoadingEnviarDeclaracion");
			$("#btnAceptarFirmaElectronica").addClass("divLoadingCompleteRowClase");
			$("#btnCancelarFirmaElectronica").addClass("divLoadingCompleteRowClase");
			showModalElement("divScreenBlock");
		},
		complete: function() {
			hideElement("divLoadingEnviarDeclaracion");
			$("#btnAceptarFirmaElectronica").removeClass("divLoadingCompleteRowClase");
			$("#btnCancelarFirmaElectronica").removeClass("divLoadingCompleteRowClase");
			hideModalElement("divScreenBlock");
		},
		success: function(result) {
			firmarDeclaracionJuradaCallback(result);
		},
		error: function() {
		}
	});
};





var descargarPdfFirmado = function(tipDocumento,numDocumento){
	$("#tipDocumentoFirmado").val(tipDocumento);
	$("#numDocumentoFirmado").val(numDocumento);
	existeDocumentoFirmado(tipDocumento,numDocumento,existeDocumentoFirmadoCallback);
};


var existeDocumentoFirmadoCallback = function(resultado){
	var existe = resultado.existe;
	if(existe){
		$("#formDescargarPdfFirmado").submit();	
	}else{
		
		$("#spaMensajeAlertaErrorPdfFirmado").html("No es posible mostrar el reporte debido a que no ha sido firmado electrónicamente");
		showModalElement("divMensajeErrorPdfFirmado");	
		
	}
};


var existeDocumentoFirmado = function(tipDocumento, numDocumento, callback) {
	$.ajax({
		url: contextPathUrl + "/firmaElectronica.htm?action=existeDocumentoFirmado",
		type: "post",
		dataType: "json",
		cache: false,
		data: {
			"tipDocumento": tipDocumento,
			"numDocumento": numDocumento
		},
		success: callback,
		error: function() {
		}
	});
};

var tipoProcesamiento = "I";//Individual, Masivo
var firmaElectronicaValida = function(firmaElectronicaValidaCallback,tipoProcesamientoParam) {
	var dataJson = functionGenerateDataSign();
	tipoProcesamiento = "I";//por default es individual.
	if(tipoProcesamientoParam!=null)
		tipoProcesamiento = tipoProcesamientoParam;
	
	$.ajax({
		url: contextPathUrl + "/firmaElectronica.htm?action=firmaUsuarioValida",
		type: "post",
		dataType: "json",
		data: dataJson,
		cache: false,
		success: function(result) {
			firmaElectronicaValidaCallback(result);
		},
		error: function() {
		}
	});
};


var resultadoProcessVerificaFirma = function(resultado){
	if(resultado.firmaValida){
		//Aquí mandar mensaje de confirmacion
		//$("#divFormularioFirmaElectronica").modal("show");//mostramos la pantalla de firma
		$("#spaMensajeConfirmaPdfFirmado0").html(generaMensaje());
		$("#divMensajeConfirmaPdfFirmado0").modal("show");
		
	}else{
		//Mostramos mensaje de error y termina el CUS
		$("#spaMensajeAlertaErrorPdfFirmado").html(resultado.mensajeError);
		$("#divMensajeErrorPdfFirmado").modal("show");
	}
};


var nextFunctionFirma = null;
var autorizacion = false;
var showMensajePreviaConfirmacionFirma = function(codPlanilla,nextFunction,esAutorizacion){
	autorizacion = false;
	if(esAutorizacion!=null){
		autorizacion = esAutorizacion;
	}
	nextFunctionFirma = nextFunction;
	$("#spaMensajeConfirmaPdfFirmado2").html("\u00BFEst\u00E1 usted seguro de firmar electr\u00F3nicamente la Planilla N\u00B0 "+codPlanilla+"\u003F");
	showModalElement("divMensajeConfirmaPdfFirmado2");//mensaje modal de la firma
};


var showMensajePreviaConfirmacionRendicionFirma = function(codRendicion,nextFunction){
	nextFunctionFirma = nextFunction;
	$("#spaMensajeConfirmaPdfFirmado2").html("\u00BFEst\u00E1 usted seguro de firmar electr\u00F3nicamente la Rendici\u00F3n N\u00B0 "+codRendicion+"\u003F");
	showModalElement("divMensajeConfirmaPdfFirmado2");//mensaje modal de la firma
};

var clickBtnSiConfirmaFirmaElectronica2 = function(){
	$("#divMensajeConfirmaPdfFirmado2").modal("hide");
	nextFunctionFirma();
};


var clickBtnNoConfirmaFirmaElectronica2 = function(){
	$("#divMensajeConfirmaPdfFirmado2").modal("hide");
	if(autorizacion!=null && autorizacion){
		//TODO: Mostrar pantalla
		//var flagLimpiarDatosColaboradorBuscarUUOO = true;
		initElementsBuscarUUOOAutoriza("divBandejaSolicitudTable");
		$("#divBuscarUUOOAutoriza").modal("show");
	}
};


//Antes de mostrar la firma electronica...
var clickBtnSiConfirmaFirmaElectronica0 = function(){
	$("#divMensajeConfirmaPdfFirmado0").modal("hide");
	$("#divFormularioFirmaElectronica").modal("show");//mostramos la pantalla de firma	
};


var clickBtnNoConfirmaFirmaElectronica0 = function(){
	$("#divMensajeConfirmaPdfFirmado0").modal("hide");
};





