function changeDateEtiquetaFechaDocumentoComprobanteDiv(){
	validarFechaTipoDocumento();
}

function clickBtnCerrarComprobante() {
	removeEventElementsRegistrarModificarComprobanteRendicion();
	removeTablesRegistrarModificarComprobanteRendicion();
    hideModalElement("divRegistrarModificarComprobanteRendicion");
}
function clickBtnCerrarAuxComprobante(){
	removeEventElementsRegistrarModificarComprobanteRendicion();
	removeTablesRegistrarModificarComprobanteRendicion();
    hideModalElement("divRegistrarModificarComprobanteRendicion");
}

function changeSelTipoDocumentoComprobante() {
	selTipoDocumentoComprobante();
    setTextValueTipoDocumentoComprobante();    	
}



function setTextValueTipoDocumentoComprobante(){

	//DECLARACION JURADA - COMPROBANTE DE PAGO / DECLARACION JURADA - VIATICOS
    if (getValueInputText("selTipoDocumentoComprobante") == "907" || getValueInputText("selTipoDocumentoComprobante") == "906") {
 		setValueInputText("txtRucComprobante", "");
 		setValueInputText("txtRazonSocialComprobante", "");
 		setValueInputText("txtSerieDocumentoComprobante", "0000");
 		setValueInputText("txtNumeroDocumentoComprobante", "00000000");
 		setValueInputText("txtClasificadorGastoComprobante", "");
 		initSelectOption("selTipoConceptoComprobante",0);
 		tituloRendicion = "Datos de la rendici&oacute;n";
 		$("#gview_tblDatosRendicion .ui-jqgrid-title").html(tituloRendicion);
    }//COMPROBANTE DEL EXTERIOR
    else if (getValueInputText("selTipoDocumentoComprobante") == "916") {
    	setValueInputText("txtSerieDocumentoComprobante", "0000");
 		setValueInputText("txtNumeroDocumentoComprobante", "00000000");
 		setValueInputText("txtRucComprobante", "");
 		setValueInputText("txtRazonSocialComprobante", "");
 		setValueInputText("txtClasificadorGastoComprobante", "");
 		initSelectOption("selTipoConceptoComprobante",0);
 		tituloRendicion = "Datos de la rendici&oacute;n";
 		$("#gview_tblDatosRendicion .ui-jqgrid-title").html(tituloRendicion);
    }//BOLETO DE VIAJE
    else if (getValueInputText("selTipoDocumentoComprobante") == "915" || getValueInputText("selTipoDocumentoComprobante") == "067") {
    	setValueInputText("txtSerieDocumentoComprobante", "");
 		setValueInputText("txtNumeroDocumentoComprobante", "");
 		setValueInputText("txtRucComprobante", "");
 		setValueInputText("txtRazonSocialComprobante", "");
 		setValueInputText("txtClasificadorGastoComprobante", "");
 		initSelectOption("selTipoConceptoComprobante",0);
 		tituloRendicion = "Datos de la rendici&oacute;n";
 		$("#gview_tblDatosRendicion .ui-jqgrid-title").html(tituloRendicion);
    }//SELECCIONE
	else if(getValueInputText("selTipoDocumentoComprobante") == "000"){
		setValueInputText("txtSerieDocumentoComprobante", "");
 		setValueInputText("txtNumeroDocumentoComprobante", "");
 		setValueInputText("txtClasificadorGastoComprobante", "");
 		initSelectOption("selTipoConceptoComprobante",0);
 		setValueInputText("txtRucComprobante", "");
 		setValueInputText("txtRazonSocialComprobante", "");
 		setValueInputText("txtSecuenciaComprobante","");
 		
	}
	else {//OTROS
		tituloRendicion = " ";
		setValueInputText("txtSerieDocumentoComprobante", "");
 		setValueInputText("txtNumeroDocumentoComprobante", "");
 		setValueInputText("txtRucComprobante", "");
 		setValueInputText("txtRazonSocialComprobante", "");
 		setValueInputText("txtClasificadorGastoComprobante", "");
 		initSelectOption("selTipoConceptoComprobante",0);
 		$("#gview_tblDatosRendicion .ui-jqgrid-title").html(tituloRendicion);
	}
    setValueInputText("montoBase", "0.00");
    setValueInputText("valorVenta", "0.00");
    setValueInputText("otroGasto", "0.00");
    setValueInputText("valorTotal", "0.00");
    setValueInputText("montoTotal", "0.00");
	setValueInputTextClass("alimentacion", "0.00");
	setValueInputTextClass("hospedaje", "0.00");
	setValueInputTextClass("movilidad", "0.00");
	setValueInputTextClass("translado", "0.00");
	setHtmlElementClass("total", "0.00");
	setHtmlElement("igv","0.00");
    setValueInputText("txtSustentoLugarReferenciaComprobante", "");
}

function selTipoDocumentoComprobante(){
	//DECLARACION JURADA - COMPROBANTE DE PAGO / DECLARACION JURADA - VIATICOS
	consoleLog("codigoDocumentoComprobante: " + getValueInputText("selTipoDocumentoComprobante"));
	showElement("divSustentoLugarReferenciaComprobante");
	var estadoDDJJ = getValueInputText("estadoDDJJ");
	if (getValueInputText("selTipoDocumentoComprobante") == "907" || getValueInputText("selTipoDocumentoComprobante") == "906") {
    	
		     	var tipoDestino = getValueInputText("tipoDestino");
				if(tipoDestino=="01"){
					
					if(getValueInputText("selTipoDocumentoComprobante") == "907"){
		
						if(estadoDDJJ=="true" || (parametros.estadoLlamada == "E" || parametros.estadoLlamada == "C")){
								setTextLabel("lblSustentoLugarReferenciaComprobante", "Sustento/Lugar:");
								showElement("divDatosComprobantePagoTable");
								if (getValueInputText("selTipoDocumentoComprobante") == "907" ){
									enabledElement("txtSustentoLugarReferenciaComprobante");}
								else if(getValueInputText("selTipoDocumentoComprobante") == "906"){
									disabledElement("txtSustentoLugarReferenciaComprobante");
									hideElement("divSustentoLugarReferenciaComprobante");
								}	
								
								disabledElement("txtRucComprobante");
								disabledElement("txtRazonSocialComprobante");
								disabledElement("txtSecuenciaComprobante");
								disabledElement("txtSerieDocumentoComprobante");
								disabledElement("txtNumeroDocumentoComprobante");
								enabledElement("etiquetaFechaDocumentoComprobante");
								enabledElement("selTipoConceptoComprobante");
								disabledElement("txtClasificadorGastoComprobante");
								enabledElement("btnGrabarComprobante");	

								enabledElement("montoBase");
								enabledElement("valorVenta");
								enabledElement("exoneracionIgv");
								enabledElement("otroGasto");
								enabledElement("valorTotal");
								enabledElement("montoTotal");

								consoleLog("bloquedo");
								ocultarMostrarColumna("tblDatosRendicion", "showCol", "moneda");
								ocultarMostrarColumna("tblDatosRendicion", "hideCol", "valorVenta");
								ocultarMostrarColumna("tblDatosRendicion", "showCol", "montoBase");
								ocultarMostrarColumna("tblDatosRendicion", "hideCol", "igv");
								ocultarMostrarColumna("tblDatosRendicion", "showCol", "cero");
								ocultarMostrarColumna("tblDatosRendicion", "hideCol", "exoneracionIgv");
								ocultarMostrarColumna("tblDatosRendicion", "showCol", "exoneracionFija");
								ocultarMostrarColumna("tblDatosRendicion", "showCol", "otroGasto");
								ocultarMostrarColumna("tblDatosRendicion", "hideCol", "valorTotal");
								ocultarMostrarColumna("tblDatosRendicion", "showCol", "montoTotal");	
						
						}else
		
							if(estadoDDJJ=="false" && parametros.estadoLlamada == "N"){
		
							var mensaje = (errorMessageRegistrarComprobante.unoDDJJ).replace("DOCUMENTO", getUpperCaseTextSelect("selTipoDocumentoComprobante"))
							setHtmlElement("spaMensajeAdvertenciaComprobante", mensaje);	
							$("#divMensajeAdvertenciaComprobante").modal("show");
							bloqueoParametrosDocumentoComprobanteXAdventencia();
						}
						
					}else if(getValueInputText("selTipoDocumentoComprobante") == "906"){
							 	
							setTextLabel("lblSustentoLugarReferenciaComprobante", "Sustento/Lugar:");
							showElement("divDatosComprobantePagoTable");
							if (getValueInputText("selTipoDocumentoComprobante") == "907" ){
								enabledElement("txtSustentoLugarReferenciaComprobante");}
							else if(getValueInputText("selTipoDocumentoComprobante") == "906"){
								disabledElement("txtSustentoLugarReferenciaComprobante");
								hideElement("divSustentoLugarReferenciaComprobante");
							}	
							
							disabledElement("txtRucComprobante");
							disabledElement("txtRazonSocialComprobante");
							disabledElement("txtSecuenciaComprobante");
							disabledElement("txtSerieDocumentoComprobante");
							disabledElement("txtNumeroDocumentoComprobante");
							enabledElement("etiquetaFechaDocumentoComprobante");
							enabledElement("selTipoConceptoComprobante");
							disabledElement("txtClasificadorGastoComprobante");
							enabledElement("btnGrabarComprobante");	

							enabledElement("montoBase");
							enabledElement("valorVenta");
							enabledElement("exoneracionIgv");
							enabledElement("otroGasto");
							enabledElement("valorTotal");
							enabledElement("montoTotal");

							ocultarMostrarColumna("tblDatosRendicion", "showCol", "moneda");
							ocultarMostrarColumna("tblDatosRendicion", "hideCol", "valorVenta");
							ocultarMostrarColumna("tblDatosRendicion", "showCol", "montoBase");
							ocultarMostrarColumna("tblDatosRendicion", "hideCol", "igv");
							ocultarMostrarColumna("tblDatosRendicion", "showCol", "cero");
							ocultarMostrarColumna("tblDatosRendicion", "hideCol", "exoneracionIgv");
							ocultarMostrarColumna("tblDatosRendicion", "showCol", "exoneracionFija");
							ocultarMostrarColumna("tblDatosRendicion", "showCol", "otroGasto");
							ocultarMostrarColumna("tblDatosRendicion", "hideCol", "valorTotal");
							ocultarMostrarColumna("tblDatosRendicion", "showCol", "montoTotal");	
					
					}
					
				}else if(tipoDestino=="02"){
					if(getValueInputText("selTipoDocumentoComprobante") == "907"){
								   
						if(estadoDDJJ=="true" || (parametros.estadoLlamada == "E" || parametros.estadoLlamada == "C")){
						 	
										setTextLabel("lblSustentoLugarReferenciaComprobante", "Sustento/Lugar:");
										showElement("divDatosComprobantePagoTable");
										if (getValueInputText("selTipoDocumentoComprobante") == "907" ){
											enabledElement("txtSustentoLugarReferenciaComprobante");}
										else if(getValueInputText("selTipoDocumentoComprobante") == "906"){
											disabledElement("txtSustentoLugarReferenciaComprobante");
											hideElement("divSustentoLugarReferenciaComprobante");
										}	
										
										disabledElement("txtRucComprobante");
										disabledElement("txtRazonSocialComprobante");
										disabledElement("txtSecuenciaComprobante");
										disabledElement("txtSerieDocumentoComprobante");
										disabledElement("txtNumeroDocumentoComprobante");
										enabledElement("etiquetaFechaDocumentoComprobante");
										enabledElement("selTipoConceptoComprobante");
										disabledElement("txtClasificadorGastoComprobante");
										enabledElement("btnGrabarComprobante");	

										enabledElement("montoBase");
										enabledElement("valorVenta");
										enabledElement("exoneracionIgv");
										enabledElement("otroGasto");
										enabledElement("valorTotal");
										enabledElement("montoTotal");

										ocultarMostrarColumna("tblDatosRendicion", "showCol", "moneda");
										ocultarMostrarColumna("tblDatosRendicion", "hideCol", "valorVenta");
										ocultarMostrarColumna("tblDatosRendicion", "showCol", "montoBase");
										ocultarMostrarColumna("tblDatosRendicion", "hideCol", "igv");
										ocultarMostrarColumna("tblDatosRendicion", "showCol", "cero");
										ocultarMostrarColumna("tblDatosRendicion", "hideCol", "exoneracionIgv");
										ocultarMostrarColumna("tblDatosRendicion", "showCol", "exoneracionFija");
										ocultarMostrarColumna("tblDatosRendicion", "showCol", "otroGasto");
										ocultarMostrarColumna("tblDatosRendicion", "hideCol", "valorTotal");
										ocultarMostrarColumna("tblDatosRendicion", "showCol", "montoTotal");	
								
								}else if(estadoDDJJ=="false" && parametros.estadoLlamada == "N"){
									var mensaje = (errorMessageRegistrarComprobante.unoDDJJ).replace("DOCUMENTO", getUpperCaseTextSelect("selTipoDocumentoComprobante"))
									setHtmlElement("spaMensajeAdvertenciaComprobante", mensaje);	
									$("#divMensajeAdvertenciaComprobante").modal("show");
									bloqueoParametrosDocumentoComprobanteXAdventencia();
								}
						
								
							}else if(getValueInputText("selTipoDocumentoComprobante") == "906"){
								
								
								setTextLabel("lblSustentoLugarReferenciaComprobante", "Sustento/Lugar:");
								showElement("divDatosComprobantePagoTable");
								if (getValueInputText("selTipoDocumentoComprobante") == "907" ){
									enabledElement("txtSustentoLugarReferenciaComprobante");}
								else if(getValueInputText("selTipoDocumentoComprobante") == "906"){
									disabledElement("txtSustentoLugarReferenciaComprobante");
									hideElement("divSustentoLugarReferenciaComprobante");
								}	
								
								disabledElement("txtRucComprobante");
								disabledElement("txtRazonSocialComprobante");
								disabledElement("txtSecuenciaComprobante");
								disabledElement("txtSerieDocumentoComprobante");
								disabledElement("txtNumeroDocumentoComprobante");
								enabledElement("etiquetaFechaDocumentoComprobante");
								enabledElement("selTipoConceptoComprobante");
								disabledElement("txtClasificadorGastoComprobante");
								enabledElement("btnGrabarComprobante");	

								enabledElement("montoBase");
								enabledElement("valorVenta");
								enabledElement("exoneracionIgv");
								enabledElement("otroGasto");
								enabledElement("valorTotal");
								enabledElement("montoTotal");

								ocultarMostrarColumna("tblDatosRendicion", "showCol", "moneda");
								ocultarMostrarColumna("tblDatosRendicion", "hideCol", "valorVenta");
								ocultarMostrarColumna("tblDatosRendicion", "showCol", "montoBase");
								ocultarMostrarColumna("tblDatosRendicion", "hideCol", "igv");
								ocultarMostrarColumna("tblDatosRendicion", "showCol", "cero");
								ocultarMostrarColumna("tblDatosRendicion", "hideCol", "exoneracionIgv");
								ocultarMostrarColumna("tblDatosRendicion", "showCol", "exoneracionFija");
								ocultarMostrarColumna("tblDatosRendicion", "showCol", "otroGasto");
								ocultarMostrarColumna("tblDatosRendicion", "hideCol", "valorTotal");
								ocultarMostrarColumna("tblDatosRendicion", "showCol", "montoTotal");					
								
							}	
				} 
			
		$("#monedaRendicion").trigger("click");
	}//COMPROBANTE DEL EXTERIOR
    else if (getValueInputText("selTipoDocumentoComprobante") == "916" ) {

				setTextLabel("lblSustentoLugarReferenciaComprobante", "Referencias:");
				showElement("divDatosComprobantePagoTable");
				enabledElement("txtSustentoLugarReferenciaComprobante");
				disabledElement("txtRucComprobante");
				disabledElement("txtRazonSocialComprobante");
				disabledElement("txtSecuenciaComprobante");
				disabledElement("txtSerieDocumentoComprobante");
				disabledElement("txtNumeroDocumentoComprobante");
				enabledElement("etiquetaFechaDocumentoComprobante");
				enabledElement("selTipoConceptoComprobante");
				disabledElement("txtClasificadorGastoComprobante");
				enabledElement("btnGrabarComprobante");	

				enabledElement("montoBase");
				enabledElement("valorVenta");
				enabledElement("exoneracionIgv");
				enabledElement("otroGasto");
				enabledElement("valorTotal");
				enabledElement("montoTotal");

				ocultarMostrarColumna("tblDatosRendicion", "showCol", "moneda");
				ocultarMostrarColumna("tblDatosRendicion", "hideCol", "valorVenta");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "montoBase");
				ocultarMostrarColumna("tblDatosRendicion", "hideCol", "igv");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "cero");
				ocultarMostrarColumna("tblDatosRendicion", "hideCol", "exoneracionIgv");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "exoneracionFija");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "otroGasto");
				ocultarMostrarColumna("tblDatosRendicion", "hideCol", "valorTotal");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "montoTotal");
		$("#monedaRendicion").trigger("click");
	}//BOLETO DE VIAJE
    else if (getValueInputText("selTipoDocumentoComprobante") == "915" ||  getValueInputText("selTipoDocumentoComprobante") == "067") {

				setTextLabel("lblSustentoLugarReferenciaComprobante", "Lugar:");
				hideElement("divDatosComprobantePagoTable");
				enabledElement("txtSustentoLugarReferenciaComprobante");
				if(getValueInputText("tipoDestino")=="01"){
					enabledElement("txtRucComprobante");}
				else if(getValueInputText("tipoDestino")=="02"){
					disabledElement("txtRucComprobante");
				}
				
				disabledElement("txtRazonSocialComprobante");
				disabledElement("txtSecuenciaComprobante");
				enabledElement("txtSerieDocumentoComprobante");
				enabledElement("txtNumeroDocumentoComprobante");
				enabledElement("etiquetaFechaDocumentoComprobante");
				enabledElement("selTipoConceptoComprobante");
				disabledElement("txtClasificadorGastoComprobante");
				enabledElement("btnGrabarComprobante");

				enabledElement("montoBase");
				enabledElement("valorVenta");
				enabledElement("exoneracionIgv");
				enabledElement("otroGasto");
				enabledElement("valorTotal");
				enabledElement("montoTotal");

				ocultarMostrarColumna("tblDatosRendicion", "showCol", "moneda");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "valorVenta");
				ocultarMostrarColumna("tblDatosRendicion", "hideCol", "montoBase");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "igv");
				ocultarMostrarColumna("tblDatosRendicion", "hideCol", "cero");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "exoneracionIgv");
				ocultarMostrarColumna("tblDatosRendicion", "hideCol", "exoneracionFija");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "otroGasto");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "valorTotal");
				ocultarMostrarColumna("tblDatosRendicion", "hideCol", "montoTotal");
			$("#monedaRendicion").trigger("click");
		//SELECCIONE
	}else if(getValueInputText("selTipoDocumentoComprobante") == "000"){
		setTextLabel("lblSustentoLugarReferenciaComprobante", "Sustento de cambio de monto:");
		disabledElement("txtRucComprobante");
		disabledElement("txtRazonSocialComprobante");
		disabledElement("txtSecuenciaComprobante");
		disabledElement("txtSerieDocumentoComprobante");
		disabledElement("txtNumeroDocumentoComprobante");
		disabledElement("etiquetaFechaDocumentoComprobante");
		disabledElement("selTipoConceptoComprobante");
		disabledElement("txtClasificadorGastoComprobante");
		disabledElement("txtSustentoLugarReferenciaComprobante");
		hideElement("divSustentoLugarReferenciaComprobante");
		disabledElement("btnGrabarComprobante");
		disabledElement("btnGrabarAuxComprobante");
		enabledElement("selTipoDocumentoComprobante");
		disabledElement("montoBase");
		disabledElement("valorVenta");
		disabledElement("exoneracionIgv");
		disabledElement("otroGasto");
		disabledElement("valorTotal");
		disabledElement("montoTotal");
		hideElementByClass("rendicionFechaRendicion");
		disabledElementForClass("alimentacion");
		disabledElementForClass("hospedaje");
		disabledElementForClass("movilidad");
		disabledElementForClass("translado");
		ocultarMostrarColumna("tblDatosRendicion", "showCol", "moneda");
		ocultarMostrarColumna("tblDatosRendicion", "showCol", "valorVenta");
		ocultarMostrarColumna("tblDatosRendicion", "hideCol", "montoBase");
		ocultarMostrarColumna("tblDatosRendicion", "showCol", "igv");
		ocultarMostrarColumna("tblDatosRendicion", "hideCol", "cero");
		ocultarMostrarColumna("tblDatosRendicion", "showCol", "exoneracionIgv");
		ocultarMostrarColumna("tblDatosRendicion", "hideCol", "exoneracionFija");
		ocultarMostrarColumna("tblDatosRendicion", "showCol", "otroGasto");
		ocultarMostrarColumna("tblDatosRendicion", "showCol", "valorTotal");
		ocultarMostrarColumna("tblDatosRendicion", "hideCol", "montoTotal");	
	}
	else {//OTROS		

			$("#divMensajeAdvertenciaComprobante").modal("hide");
				setTextLabel("lblSustentoLugarReferenciaComprobante", "Sustento de cambio de monto:");
				showElement("divDatosRendicionTable");
				//showElement("divSustentoLugarReferenciaComprobante");
				showElement("divDatosComprobantePagoTable");
				disabledElement("txtSustentoLugarReferenciaComprobante");
				hideElement("divSustentoLugarReferenciaComprobante");
				disabledElement("txtSecuenciaComprobante");
				enabledElement("txtSerieDocumentoComprobante");
				enabledElement("txtNumeroDocumentoComprobante");
				enabledElement("txtRucComprobante");
				enabledElement("selTipoConceptoComprobante");
				enabledElement("btnGrabarComprobante");
				enabledElement("etiquetaFechaDocumentoComprobante");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "moneda");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "valorVenta");
				ocultarMostrarColumna("tblDatosRendicion", "hideCol", "montoBase");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "igv");
				ocultarMostrarColumna("tblDatosRendicion", "hideCol", "cero");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "exoneracionIgv");
				ocultarMostrarColumna("tblDatosRendicion", "hideCol", "exoneracionFija");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "otroGasto");
				ocultarMostrarColumna("tblDatosRendicion", "showCol", "valorTotal");
				ocultarMostrarColumna("tblDatosRendicion", "hideCol", "montoTotal");
				enabledElement("montoBase");
				enabledElement("valorVenta");
				enabledElement("exoneracionIgv");
				enabledElement("otroGasto");
				enabledElement("valorTotal");
				enabledElement("montoTotal");
			$("#monedaRendicion").trigger("click");
	}
	if(parametros.estadoLlamada == "N"){
		validarTipoDocumentoxConcepto();
	}
    
	
	//si el tipo de concepto es distinto a 01 y distinto a 12 entonces
	var conceptoId = getValueInputText("selTipoConceptoComprobante");
	if(!(conceptoId=='01' || conceptoId=='12')){
		hideElement("divDatosComprobantePagoTable");	
	}
	
	disabledElement("btnGrabarComprobante");
	disabledElement("btnGrabarAuxComprobante");
    disabledElement("alimentacion_undefined");
    disabledElement("hospedaje_undefined");
    disabledElement("movilidad_undefined");
    disabledElement("translado_undefined");
    setHtmlElement("rendicionFechaRendicion_undefined","");
    removeElement("idMensaje");
    hideElement("divErrorRUC");
    hideElement("divErrorNumeroDocumento");
    hideElement("divErrorFechaDocumento");
    hideElement("divErrorSustentoLugar");
    hideElement("divErrorDatosComprobantePago"); 
    hideElement("divErrorDatosComprobantePagoDistrib");
    hideElement("divErrorDatosComprobantePagoxAsignacion");
    
    validaEstadoGeneral = 0;
    resizeTable("tblDatosRendicion");
}


function changeSelTipoConceptoComprobante() {
	var clasificadorGasto = getDataAttributeSelect("selTipoConceptoComprobante", "data-clasificadorgasto");
	var monto = getDataAttributeSelect("selTipoConceptoComprobante", "data-monto");
	setValueInputText("txtClasificadorGastoComprobante", clasificadorGasto);
	var idSelectorConcepto = getValueInputText("selTipoConceptoComprobante");
	
	if($.trim(idSelectorConcepto) != ""){
		if(idSelectorConcepto == "01" || idSelectorConcepto == "12"){
			showElementByClass("rendicionFechaRendicion");
			
			//Al cambiar el tipo de concepto se realiza la validacion de suma general de distribucion...
			var estadoSumaGeneralDistribucion = 1;
			if(idSelectorConcepto=='01'){
				//Solo si se trata de una asignacion nacional validamos que se realice una suma distribuida correcta.
				estadoSumaGeneralDistribucion = sumaGeneralDistribucion();	
			}
			
			if(estadoSumaGeneralDistribucion==1){
				var indExtDDJJ =  getValueInputText("indExtDDJJ");
				
				if(indExtDDJJ=="0"){
					if (getValueInputText("selTipoDocumentoComprobante") == "907" || getValueInputText("selTipoDocumentoComprobante") == "906"){
						validarMontoxAsignacionDeclaracion();
					}else{
						validarMontoxAsignacion();
					}
				}else if(indExtDDJJ=="1"){
					validarMontoxAsignacion();
				}
			}
			showElement("divDatosComprobantePagoTable");
			
			
		}else if(idSelectorConcepto == "00"){
			setValueInputTextClass("alimentacion", "0.00");
			setValueInputTextClass("hospedaje", "0.00");
			setValueInputTextClass("movilidad", "0.00");
			setValueInputTextClass("translado", "0.00");
			setHtmlElementClass("total", "0.00");
			removeElement("idMensaje");
			hideElementByClass("rendicionFechaRendicion");
			hideElement("divErrorDatosComprobantePagoDistrib");
			hideElement("divErrorDatosComprobantePago");
			hideElement("divErrorDatosComprobantePagoxAsignacion");
			showElement("divDatosComprobantePagoTable");
		} else{
				hideElementByClass("rendicionFechaRendicion");
				hideElement("divDatosComprobantePagoTable");
				validarMontoxAsignacion();
		}
		
	}else{
		hideElementByClass("rendicionFechaRendicion");
	}
	
	validaFormulario();
	
	$("#tblDatosComprobantePago").trigger("reloadGrid");
	
	if($.trim(idSelectorConcepto) == "01" || $.trim(idSelectorConcepto) == "12"){
		enabledElementForClass("alimentacion");
		enabledElementForClass("hospedaje");
		enabledElementForClass("movilidad");
		enabledElementForClass("translado");
		disabledElement("alimentacion_undefined");
		disabledElement("hospedaje_undefined");
		disabledElement("movilidad_undefined");
		disabledElement("translado_undefined");
		sumaValoresIteracionFooter();
	}
	
	//Aquí validamos si el concepto y comprobante coincide como para ocultarlo
	var selCon = $.trim(idSelectorConcepto);
	mostrarSustentoLugar(selCon);
	
	validarFechaTipoDocumento();//Validamos la fecha cada vez que cambiamos el tipo de concepto.
	
}

function mostrarSustentoLugar(selCon){
	var tipoDoc = getValueInputText("selTipoDocumentoComprobante")
	var tipoComprobanteAllow = ["001","002","005","012","067","091","904","906","910"];
	if( ((selCon!='01' && selCon!='12') && $.inArray(tipoDoc, tipoComprobanteAllow)>=0) || selCon=='00' ){
		hideElement("divSustentoLugarReferenciaComprobante");
	}else{
		
		/*var etiqueta =getTextLabel("lblSustentoLugarReferenciaComprobante");
		if(etiqueta!="Sustento de cambio de monto:"){
			showElement("divSustentoLugarReferenciaComprobante");	
		}*/
	}
}




function clickBtnGrabarComprobante(){
	var tipoConcepto = getValueInputText("selTipoConceptoComprobante");
	var clasificadorGasto =  getValueInputText("txtClasificadorGastoComprobante");
	var ruc =  getValueInputText("txtRucComprobante");
	var numeroDocumento =  getValueInputText("txtNumeroDocumentoComprobante");
	var serie =  getValueInputText("txtSerieDocumentoComprobante");
	//var fecha =  getValueInputText("etiquetaFechaDocumentoComprobante");	
	var valorVenta = getValueInputText("valorVenta");
	var valorTotal = getValueInputText("valorTotal");
	var montoBase = getValueInputText("montoBase");
	var montoTotal = getValueInputText("montoTotal");
	var tipoDestino = getValueInputText("tipoDestino");	
	var sustentoLugar = getValueInputText("txtSustentoLugarReferenciaComprobante");
	var razonSocialComprobante = getValueInputText("txtRazonSocialComprobante");
	var tipoDocumentoComprobante = getValueInputText("selTipoDocumentoComprobante");
	var fechaDocumentoComprobante = getValueInputText("etiquetaFechaDocumentoComprobante");
	var fechaHoraProgSalida = getValueInputText("fechaHoraProgSalida");
	var fechaHoraProgRetorno = getValueInputText("fechaHoraProgRetorno");
	var fechaHoraEjeSalida = getValueInputText("fechaHoraEjeSalida");
	var fechaHoraEjeRetorno = getValueInputText("fechaHoraEjeRetorno");
	var tipoDestino = getValueInputText("tipoDestino");
	var indExtDDJJ = getValueInputText("indExtDDJJ");
	var estadoDDJJ = getValueInputText("estadoDDJJ");
	var saldoRendir = parametros.saldoRendir;
	
	var total_undefined = getValueText("total_undefined");
		total_undefined = total_undefined.replace(/,/g , '');
		total_undefined  = parseFloat(total_undefined);	
    
	var valorTotal = getValueInputText("valorTotal");
	 	valorTotal = valorTotal.replace(/,/g , '');
	 	valorTotal  = parseFloat(valorTotal);
	 	 
	var montoTotal = getValueInputText("montoTotal");
		montoTotal = montoTotal.replace(/,/g , '');
		montoTotal  = parseFloat(montoTotal);
				
		// si es una declaracion jurada de viaticos(907) o una declaracion jurada de comprobante de pago(906)
		if (getValueInputText("selTipoDocumentoComprobante") == "907" || getValueInputText("selTipoDocumentoComprobante") == "906"){
			
			//Si es una DECLARACION JURADA DE VIÁTICOS
			if(getValueInputText("selTipoDocumentoComprobante") == "907" ){
				var estadoGrabado = "0";
					if($.trim(clasificadorGasto)==""){
						setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.concepto);
						$("#divMensajeAdvertenciaComprobante").modal("show");
						estadoGrabado = "0";
					}else if ($.trim(montoTotal)=="0.00"){	
						setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.montoTotalMayorCero);
						$("#divMensajeAdvertenciaComprobante").modal("show");
						estadoGrabado = "0";
					}else if (total_undefined != montoTotal && (tipoConcepto=='01' || tipoConcepto=='12')){
						//setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.distribuido);
						setHtmlElement("spaMensajeAdvertenciaComprobante", "El monto total distribuido debe ser igual al monto total del documento.");
						$("#divMensajeAdvertenciaComprobante").modal("show");
						estadoGrabado = "0";
					}else if(total_undefined==0 && (tipoConcepto=='01' || tipoConcepto=='12')){
						setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.messageTotalDistribucion);
						$("#divMensajeAdvertenciaComprobante").modal("show");
						estadoGrabado = "0";
					}else if(fechaDocumentoComprobante != ""){
							var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
							var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
							var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
							if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
								var mensaje = errorMessageRegistrarComprobante.fechaComprobanteDeclaracion;
								setHtmlElement("spaMensajeAdvertenciaComprobante", mensaje);
								$("#divMensajeAdvertenciaComprobante").modal("show");
								estadoGrabado = "0";
							}else{
								estadoGrabado = "1";
							}
					}
					
					if(estadoGrabado == "1"){
						setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
						$("#divMensajeConfirmacionComprobante").modal("show");
					}
				
			}
			else if(getValueInputText("selTipoDocumentoComprobante") == "906" ){
				//Si es una DECLARACION JURADA DE COMPROBANTE DE PAGO
				var estadoGrabado = "0";
				if($.trim(clasificadorGasto)==""){
	    			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.concepto);
	    			$("#divMensajeAdvertenciaComprobante").modal("show");
	    		}else if ($.trim(montoTotal)=="0.00"){		
	    			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.montoTotalMayorCero);
	    			$("#divMensajeAdvertenciaComprobante").modal("show");
	    		}else if (total_undefined != montoTotal && (tipoConcepto=='01' || tipoConcepto=='12')){
	    	    	//setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.distribuido);
	    	    	setHtmlElement("spaMensajeAdvertenciaComprobante", "El monto total distribuido debe ser igual al monto total del documento.");
	    			$("#divMensajeAdvertenciaComprobante").modal("show");  	    
	    	    	
	    	    }else if(total_undefined==0 && (tipoConcepto=='01' || tipoConcepto=='12')){
			    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.messageTotalDistribucion);
					$("#divMensajeAdvertenciaComprobante").modal("show");
			    }else if(fechaDocumentoComprobante != ""){
							var fechaInicio = new Date(fechaHoraEjeSalida.split("/")[2],fechaHoraEjeSalida.split("/")[1], fechaHoraEjeSalida.split("/")[0]); 
							var fechaFin = new Date(fechaHoraEjeRetorno.split("/")[2], fechaHoraEjeRetorno.split("/")[1], fechaHoraEjeRetorno.split("/")[0]);
							var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
							
							//Se valida la fecha del comprobante cuando no pertenece al concepto de tipo pasaje
							if ((fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) && !(tipoConcepto=='02' || tipoConcepto=='03' || tipoConcepto=='36' || tipoConcepto=='34') ) {
								var mensaje = errorMessageRegistrarComprobante.fechaComprobanteDeclaracion;
								setHtmlElement("spaMensajeAdvertenciaComprobante", mensaje);
								$("#divMensajeAdvertenciaComprobante").modal("show");
								estadoGrabado = "0";
							}else{
								estadoGrabado = "1";
							}
				}

				if(estadoGrabado == "1"){
						setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
						$("#divMensajeConfirmacionComprobante").modal("show");
					}
			}
			
		}else if (getValueInputText("selTipoDocumentoComprobante") == "916") {
			//Si es un COMPROBANTE DEL EXTERIOR(916) PARA VIATICOS INTERNACIONALES....
			var estadoGrabado = "0";
			if($.trim(clasificadorGasto)==""){
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.concepto);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
			}else if ($.trim(montoTotal)=="0.00"){		
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.montoTotalMayorCero);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
			}else if (total_undefined > montoTotal){
		    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.distribuido);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
		    }else if(total_undefined==0 && (tipoConcepto=='01' || tipoConcepto=='12')){
		    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.messageTotalDistribucion);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
		    }else if(fechaDocumentoComprobante != ""){
					var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
					var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
					var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
					
					if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
						var mensaje = errorMessageRegistrarComprobante.fechaComprobanteDeclaracion;
						setHtmlElement("spaMensajeAdvertenciaComprobante", mensaje);
						$("#divMensajeAdvertenciaComprobante").modal("show");
					}else{
							estadoGrabado = "1";
						}
			} 
					
			if(estadoGrabado == "1"){
		    	setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
    			$("#divMensajeConfirmacionComprobante").modal("show");
		    }



		}else if (getValueInputText("selTipoDocumentoComprobante") == "915" ||  getValueInputText("selTipoDocumentoComprobante") == "067") {
			//Si es un BOLETO DE VIAJE(915) O DOCUMENTO DE COBRANZA DE AGENCIA DE VIAJES.
			var estadoGrabado = "0";
			if($.trim(clasificadorGasto)==""){
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.concepto);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
			}else if ($.trim(valorTotal)=="0.00"){		
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.mayorCeroTotal);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
			}if ($.trim(sustentoLugar)==""){
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.sustentoLugar);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
			}else if($.trim(ruc) == ""){
						var mensaje = "Debe colocar el número de RUC.";
						setHtmlElement("spaMensajeAdvertenciaComprobante", mensaje);
						$("#divMensajeAdvertenciaComprobante").modal("show");
						estadoGrabado = "0";
			}else if($.trim(ruc) != "" && $.trim(razonSocialComprobante) == ""){				
						var mensaje = "No ingreso RUC valido.";
						setHtmlElement("spaMensajeAdvertenciaComprobante", mensaje);
						$("#divMensajeAdvertenciaComprobante").modal("show");
						estadoGrabado = "0";
			}else if(fechaDocumentoComprobante != ""){
				var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
				var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
				var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
			
				if (fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
					var mensaje = errorMessageRegistrarComprobante.fechaComprobanteBoletoViaje;				
					setHtmlElement("spaMensajeAdvertenciaComprobante", mensaje);
						$("#divMensajeAdvertenciaComprobante").modal("show");
					estadoGrabado = "0";
				}else{
					estadoGrabado = "1";
				}
			}
			
			if(estadoGrabado == "1"){
		    	setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
    			$("#divMensajeConfirmacionComprobante").modal("show");
		    }
		}else if (getValueInputText("selTipoDocumentoComprobante") == "000"){
			
		}else{
			var estadoGrabado = "0";
			if($.trim(serie)==""){
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.serie);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
			}else if($.trim(numeroDocumento)==""){
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.numeroDocumento);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
			}else if($.trim(clasificadorGasto)==""){
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.concepto);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
			}else if ($.trim(valorTotal)=="0.00"){		
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.mayorCeroTotal);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
			}else if (total_undefined > valorTotal){
		    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.distribuido);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
		    }else if(total_undefined==0  && (tipoConcepto=='01' || tipoConcepto=='12')){
		    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.messageTotalDistribucion);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
		    }else if($.trim(ruc) == ""){
						var mensaje = "Debe colocar el número de RUC.";
						setHtmlElement("spaMensajeAdvertenciaComprobante", mensaje);
						$("#divMensajeAdvertenciaComprobante").modal("show");
						estadoGrabado = "0";
			}else if($.trim(ruc) != "" && $.trim(razonSocialComprobante) == ""){				
						var mensaje = "No ingreso RUC valido.";
						setHtmlElement("spaMensajeAdvertenciaComprobante", mensaje);
						$("#divMensajeAdvertenciaComprobante").modal("show");
						estadoGrabado = "0";
			}else if(fechaDocumentoComprobante != ""){
		    	var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
				var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
				var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
					if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime() || fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
						var mensajeFecha = errorMessageRegistrarComprobante.fechaComprobanteDeclaracion;
						setHtmlElement("spaMensajeAdvertenciaComprobante", mensajeFecha);
						$("#divMensajeAdvertenciaComprobante").modal("show");
						estadoGrabado = "0";
					}else{
						estadoGrabado = "1";
					}
		    }
			
		    if(estadoGrabado=="1"){
		    	setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
    			$("#divMensajeConfirmacionComprobante").modal("show");
		    }
			
		}
		
		//TODO: Quitar esto... para revisar porque no está validando correctamente el monto total distribuido.
		estadoGrabado = "0";
}

function clickBtnGrabarAuxComprobante(){
	var tipoConcepto = getValueInputText("selTipoConceptoComprobante");
	var clasificadorGasto =  getValueInputText("txtClasificadorGastoComprobante");
	var ruc =  getValueInputText("txtRucComprobante");
	var numeroDocumento =  getValueInputText("txtNumeroDocumentoComprobante");
	var serie =  getValueInputText("txtSerieDocumentoComprobante");
	//var fecha =  getValueInputText("etiquetaFechaDocumentoComprobante");	
	var valorVenta = getValueInputText("valorVenta");
	var valorTotal = getValueInputText("valorTotal");
	var montoBase = getValueInputText("montoBase");
	var montoTotal = getValueInputText("montoTotal");
	var tipoDestino = getValueInputText("tipoDestino");	
	var sustentoLugar = getValueInputText("txtSustentoLugarReferenciaComprobante");
	var razonSocialComprobante = getValueInputText("txtRazonSocialComprobante");
	var tipoDocumentoComprobante = getValueInputText("selTipoDocumentoComprobante");
	var fechaDocumentoComprobante = getValueInputText("etiquetaFechaDocumentoComprobante");
	var fechaHoraProgSalida = getValueInputText("fechaHoraProgSalida");
	var fechaHoraProgRetorno = getValueInputText("fechaHoraProgRetorno");
	var fechaHoraEjeSalida = getValueInputText("fechaHoraEjeSalida");
	var fechaHoraEjeRetorno = getValueInputText("fechaHoraEjeRetorno");
	var tipoDestino = getValueInputText("tipoDestino");
	var indExtDDJJ = getValueInputText("indExtDDJJ");
	var estadoDDJJ = getValueInputText("estadoDDJJ");
	var saldoRendir = parametros.saldoRendir;
	
	var total_undefined = getValueText("total_undefined");
		total_undefined = total_undefined.replace(/,/g , '');
		total_undefined  = parseFloat(total_undefined);	
    
	var valorTotal = getValueInputText("valorTotal");
	 	valorTotal = valorTotal.replace(/,/g , '');
	 	valorTotal  = parseFloat(valorTotal);
	 	 
	var montoTotal = getValueInputText("montoTotal");
		montoTotal = montoTotal.replace(/,/g , '');
		montoTotal  = parseFloat(montoTotal);
				
		if (getValueInputText("selTipoDocumentoComprobante") == "907" || getValueInputText("selTipoDocumentoComprobante") == "906"){
			
			if(getValueInputText("selTipoDocumentoComprobante") == "907" ){
				var estadoGrabado = "0";
					if($.trim(clasificadorGasto)==""){
						setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.concepto);
						$("#divMensajeAdvertenciaComprobante").modal("show");
						estadoGrabado = "0";
					}else if ($.trim(montoTotal)=="0.00"){	
						setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.montoTotalMayorCero);
						$("#divMensajeAdvertenciaComprobante").modal("show");
						estadoGrabado = "0";
					}else if (total_undefined > montoTotal){
						setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.distribuido);
						$("#divMensajeAdvertenciaComprobante").modal("show");
						estadoGrabado = "0";
					}else if(total_undefined==0){
						setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.messageTotalDistribucion);
						$("#divMensajeAdvertenciaComprobante").modal("show");
						estadoGrabado = "0";
					}else if(fechaDocumentoComprobante != ""){
							var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
							var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
							var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
							if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
								var mensaje = errorMessageRegistrarComprobante.fechaComprobanteDeclaracion;
								setHtmlElement("spaMensajeAdvertenciaComprobante", mensaje);
								$("#divMensajeAdvertenciaComprobante").modal("show");
								estadoGrabado = "0";
							}else{
								estadoGrabado = "1";
							}
					}
					
					if(estadoGrabado == "1"){
						setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
						$("#divMensajeConfirmacionComprobante").modal("show");
					}
				
			}else if(getValueInputText("selTipoDocumentoComprobante") == "906" ){
				var estadoGrabado = "0";
				if($.trim(clasificadorGasto)==""){
	    			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.concepto);
	    			$("#divMensajeAdvertenciaComprobante").modal("show");
	    		}else if ($.trim(montoTotal)=="0.00"){		
	    			setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.montoTotalMayorCero);
	    			$("#divMensajeAdvertenciaComprobante").modal("show");
	    		}else if (total_undefined > montoTotal){
	    	    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.distribuido);
	    			$("#divMensajeAdvertenciaComprobante").modal("show");  	    
	    	    	
	    	    }else if(total_undefined==0){
			    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.messageTotalDistribucion);
					$("#divMensajeAdvertenciaComprobante").modal("show");
			    }else if(fechaDocumentoComprobante != ""){
							var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
							var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
							var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
							
							if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
								var mensaje = errorMessageRegistrarComprobante.fechaComprobanteDeclaracion;
								setHtmlElement("spaMensajeAdvertenciaComprobante", mensaje);
								$("#divMensajeAdvertenciaComprobante").modal("show");
								estadoGrabado = "0";
							}else{
								estadoGrabado = "1";
							}
				}

				if(estadoGrabado == "1"){
						setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
						$("#divMensajeConfirmacionComprobante").modal("show");
					}
			}
			
		}else if (getValueInputText("selTipoDocumentoComprobante") == "916") {
			var estadoGrabado = "0";
			if($.trim(clasificadorGasto)==""){
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.concepto);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
			}else if ($.trim(montoTotal)=="0.00"){		
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.montoTotalMayorCero);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
			}else if (total_undefined > montoTotal){
		    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.distribuido);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
		    }else if(total_undefined==0){
		    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.messageTotalDistribucion);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
		    }else if(fechaDocumentoComprobante != ""){
					var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
					var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
					var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
					
					if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime()) {
						var mensaje = errorMessageRegistrarComprobante.fechaComprobanteDeclaracion;
						setHtmlElement("spaMensajeAdvertenciaComprobante", mensaje);
						$("#divMensajeAdvertenciaComprobante").modal("show");
					}else{
							estadoGrabado = "1";
						}
			} 
					
			if(estadoGrabado == "1"){
		    	setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
    			$("#divMensajeConfirmacionComprobante").modal("show");
		    }



		}else if (getValueInputText("selTipoDocumentoComprobante") == "915" ||  getValueInputText("selTipoDocumentoComprobante") == "067") {
			var estadoGrabado = "0";
			if($.trim(clasificadorGasto)==""){
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.concepto);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
			}else if ($.trim(valorTotal)=="0.00"){		
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.mayorCeroTotal);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
			}if ($.trim(sustentoLugar)==""){
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.sustentoLugar);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
			}else if($.trim(ruc) == ""){
						var mensaje = "Debe colocar el número de RUC.";
						setHtmlElement("spaMensajeAdvertenciaComprobante", mensaje);
						$("#divMensajeAdvertenciaComprobante").modal("show");
						estadoGrabado = "0";
			}else if($.trim(ruc) != "" && $.trim(razonSocialComprobante) == ""){				
						var mensaje = "No ingreso RUC valido.";
						setHtmlElement("spaMensajeAdvertenciaComprobante", mensaje);
						$("#divMensajeAdvertenciaComprobante").modal("show");
						estadoGrabado = "0";
			}else if(fechaDocumentoComprobante != ""){
				var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
				var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
				var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
			
				if (fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
					var mensaje = errorMessageRegistrarComprobante.fechaComprobanteBoletoViaje;				
					setHtmlElement("spaMensajeAdvertenciaComprobante", mensaje);
						$("#divMensajeAdvertenciaComprobante").modal("show");
					estadoGrabado = "0";
				}else{
					estadoGrabado = "1";
				}
			}
			
			if(estadoGrabado == "1"){
		    	setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
    			$("#divMensajeConfirmacionComprobante").modal("show");
		    }
		}else if (getValueInputText("selTipoDocumentoComprobante") == "000"){
			
		}else{
			var estadoGrabado = "0";
			if($.trim(serie)==""){
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.serie);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
			}else if($.trim(numeroDocumento)==""){
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.numeroDocumento);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
			}else if($.trim(clasificadorGasto)==""){
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.concepto);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
			}else if ($.trim(valorTotal)=="0.00"){		
				setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.mayorCeroTotal);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
			}else if (total_undefined > valorTotal){
		    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.distribuido);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
		    }else if(total_undefined==0){
		    	setHtmlElement("spaMensajeAdvertenciaComprobante", errorMessageRegistrarComprobante.messageTotalDistribucion);
				$("#divMensajeAdvertenciaComprobante").modal("show");
				estadoGrabado = "0";
		    }else if($.trim(ruc) == ""){
						var mensaje = "Debe colocar el número de RUC.";
						setHtmlElement("spaMensajeAdvertenciaComprobante", mensaje);
						$("#divMensajeAdvertenciaComprobante").modal("show");
						estadoGrabado = "0";
			}else if($.trim(ruc) != "" && $.trim(razonSocialComprobante) == ""){				
						var mensaje = "No ingreso RUC valido.";
						setHtmlElement("spaMensajeAdvertenciaComprobante", mensaje);
						$("#divMensajeAdvertenciaComprobante").modal("show");
						estadoGrabado = "0";
			}else if(fechaDocumentoComprobante != ""){
		    	var fechaInicio = new Date(fechaHoraProgSalida.split("/")[2],fechaHoraProgSalida.split("/")[1], fechaHoraProgSalida.split("/")[0]); 
				var fechaFin = new Date(fechaHoraProgRetorno.split("/")[2], fechaHoraProgRetorno.split("/")[1], fechaHoraProgRetorno.split("/")[0]);
				var fechaDocumentoComprobante = new Date(fechaDocumentoComprobante.split("/")[2],fechaDocumentoComprobante.split("/")[1],fechaDocumentoComprobante.split("/")[0] );
					if (fechaInicio.getTime() > fechaDocumentoComprobante.getTime() || fechaFin.getTime() < fechaDocumentoComprobante.getTime()) {
						var mensajeFecha = errorMessageRegistrarComprobante.fechaComprobanteDeclaracion;
						setHtmlElement("spaMensajeAdvertenciaComprobante", mensajeFecha);
						$("#divMensajeAdvertenciaComprobante").modal("show");
						estadoGrabado = "0";
					}else{
						estadoGrabado = "1";
					}
		    }
			
		    if(estadoGrabado=="1"){
		    	setHtmlElement("spaMensajeConfirmacionTituloComprobante", errorMessageRegistrarComprobante.mensajeConfirmacion);
    			$("#divMensajeConfirmacionComprobante").modal("show");
		    }
			
		}
}

function clickBtnSiMensajeComprobante(){
	callGrabarEditarComprobantePago(parametros);
}

function clickBtnNoMensajeComprobante(){
	$("#divMensajeConfirmacionComprobante").modal("hide");
}

function clickBtnAceptarMensajeWarningComprobante(){
	$("#divMensajeAdvertenciaComprobante").modal("hide");
}

function clickBtnAceptarMensajeComprobante(){	
	$("#divRegistrarModificarComprobanteRendicion").modal("hide");
	$("#divMensajeInfomativoComprobante").modal("hide");
	removeEventElementsRegistrarModificarComprobanteRendicion();
}

function clickBtnAceptarMensajeErrorComprobante(){
	$("#divMensajeErrorComprobante").modal("hide");	
}

function changeEtiquetaFechaDocumentoComprobante(){
	changeDateEtiquetaFechaDocumentoComprobanteDiv();
}