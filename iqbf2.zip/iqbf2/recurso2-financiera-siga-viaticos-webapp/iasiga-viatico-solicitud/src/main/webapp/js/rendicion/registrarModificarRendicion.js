function initElementsRegistrarModificarRendicion() {
	removeDuplicateComponents();
	setInitElementsRegistrarModificarRendicion();
	setInitComprobanteTable(getValueInputText("hidMoneda"));
	setInitRendicionTable(getValueInputText("hidMoneda"));
	if (getValueInputText("hidCodigoCanalAtencion") == "R") {
		setInitDepositoTable();
		if (getValueInputText("hidFlagAsociadoRIC") == "1") {
			setInitRICTable();
		}
	}
	callObtenerComprobantesAsignacionesPapeletasRics();
}

function setInitElementsRegistrarModificarRendicion() {
	
	setValueInputText("selIndicadorDDJJ", getValueInputText("hidIndicadorExteriorDDJJ"));
	setValueInputText("selIndicadorDevolucionMenorGasto", getValueInputText("hidIndicadorMenorGasto"));
	setValueInputText("hidFechaMaximaDate", "31/12/" + getNextYear());
	hideElement("divHiddenImprimirPost");
	if (getValueInputText("hidFlagMostrarImprimir") != "1") {
		hideElement("btnImprimirRendicion");
	}
	addEventElement("divRendicionHeadingPanel", "click", clickDivRendicionHeadingPanel);
	addEventElement("divDevolucionHeadingPanel", "click", clickDivDevolucionHeadingPanel);
	addEventElement("btnConsultarAsistencia", "click", clickBtnConsultarAsistencia);
	addEventElement("btnAgregarRendicion", "click", clickBtnAgregarRendicion);
	addEventElement("btnVerDetalleRendicion", "click", clickBtnVerDetalleRendicion);
    addEventElement("btnAgregarDevolucion", "click", clickBtnAgregarDevolucion);
    addEventElement("btnGrabarRendicion", "click", clickBtnGrabarRendicion);
    addEventElement("btnAdjuntarRendicion", "click", clickBtnAdjuntarRendicion);
    addEventElement("btnCerrarRendicion", "click", clickBtnCerrarRendicion);
    addEventElement("btnImprimirRendicion", "click", clickBtnImprimirRendicion);
	addEventElement("btnRetornarRendicion", "click", clickBtnRetornarRendicion);
	
	addEventElement("etiquetaFechaHoraSalidaItinerarioEjecutado", "change", changeEtiquetaFechaHoraSalidaItinerarioEjecutado);
	addEventElement("etiquetaFechaHoraRetornoItinerarioEjecutado", "change", changeEtiquetaFechaHoraRetornoItinerarioEjecutado);

	if (getValueInputText("hidFlagMenorIgual4Horas") != "1") {		
		initDateTimePickerWithMaxDate("etiquetaFechaHoraSalidaItinerarioEjecutadoDiv", "dp.change", "changeDate", changeDateEtiquetaFechaHoraSalidaItinerarioEjecutadoDiv, formatEspDateToEngFormatDate(getValueInputText("hidFechaMaximaDate")));
		initDateTimePickerWithMaxDate("etiquetaFechaHoraRetornoItinerarioEjecutadoDiv", "dp.change", "changeDate", changeDateEtiquetaFechaHoraRetornoItinerarioEjecutadoDiv, formatEspDateToEngFormatDate(getValueInputText("hidFechaMaximaDate")));		
	}
	else {
		var fechaSalidaEjecutada = formatEspDateToEngFormatDate(getValueInputText("hidFechaSalidaEjecutada"));
		var fechaRetornoEjecutada = formatEspDateToEngFormatDate(getValueInputText("hidFechaRetornoEjecutada"));
		
		initDateTimePickerWithMinDateMaxDate("etiquetaFechaHoraSalidaItinerarioEjecutadoDiv", "dp.change", "changeDate", changeDateEtiquetaFechaHoraSalidaItinerarioEjecutadoDiv, fechaSalidaEjecutada, fechaSalidaEjecutada);
		initDateTimePickerWithMinDateMaxDate("etiquetaFechaHoraRetornoItinerarioEjecutadoDiv", "dp.change", "changeDate", changeDateEtiquetaFechaHoraRetornoItinerarioEjecutadoDiv, fechaRetornoEjecutada, fechaRetornoEjecutada);
	}
	
	//JMCR-ME Hora < 4 Rendicion	
	
	enabledElement("etiquetaHoraSalidaEventoProgramado");
	enabledElement("etiquetaHoraRetornoEventoProgramado");		
	enabledElement("etiquetaHoraSalidaItinerarioEjecutado");
	enabledElement("etiquetaHoraRetornoItinerarioEjecutado");
	
	hideElement("etiquetaHoraSalidaEventoProgramado");
	hideElement("etiquetaHoraRetornoEventoProgramado");
	hideElement("etiquetaHoraSalidaItinerarioEjecutado");
	hideElement("etiquetaHoraRetornoItinerarioEjecutado");	
	hideElement("lblEtiquetaHoraSalidaItinerarioEjecutado");
	hideElement("lblEtiquetaHoraRetornoItinerarioEjecutado");	
	
	disabledElement("etiquetaHoraSalidaEventoProgramado");
	disabledElement("etiquetaHoraRetornoEventoProgramado");		
	disabledElement("etiquetaHoraSalidaItinerarioEjecutado");
	disabledElement("etiquetaHoraRetornoItinerarioEjecutado");		
	
	if (getValueInputText("hidFlagMenorIgual4Horas") == "1") {		
		disabledElement("etiquetaFechaHoraSalidaItinerarioEjecutado");
		disabledElement("etiquetaFechaHoraRetornoItinerarioEjecutado");		
		
		enabledElement("etiquetaHoraSalidaEventoProgramado");
		enabledElement("etiquetaHoraRetoEventoProgramado");		
		enabledElement("etiquetaHoraSalidaItinerarioEjecutado");
		enabledElement("etiquetaHoraRetornoItinerarioEjecutado");
		
		showElement("etiquetaHoraSalidaEventoProgramado");
		showElement("etiquetaHoraRetornoEventoProgramado");
		showElement("etiquetaHoraSalidaItinerarioEjecutado");
		showElement("etiquetaHoraRetornoItinerarioEjecutado");
		showElement("lblEtiquetaHoraSalidaItinerarioEjecutado");
		showElement("lblEtiquetaHoraRetornoItinerarioEjecutado");
		
		disabledElement("etiquetaHoraSalidaEventoProgramado");
		disabledElement("etiquetaHoraRetornoEventoProgramado");
		
		addEventElement("etiquetaHoraSalidaItinerarioEjecutado", "change", changeDateEtiquetaFechaHoraSalidaItinerarioEjecutadoDiv);
		addEventElement("etiquetaHoraRetornoItinerarioEjecutado", "change", changeDateEtiquetaFechaHoraRetornoItinerarioEjecutadoDiv);
	}
	else {
	}
	//JMCR-ME Hora < 4 Rendicion	
	
	addEventElement("selIndicadorDDJJ", "change", changeSelIndicadorDDJJ);
	addEventElement("selIndicadorDevolucionMenorGasto", "change", changeSelIndicadorDevolucionMenorGasto);
	
	addEventElement("btnAceptarMensajeConfirmacionRegistrarModificarRendicion", "click", clickBtnAceptarMensajeConfirmacionRegistrarModificarRendicion);
	addEventElement("btnAceptarMensajeConfirmacionErrorRegistrarModificarRendicion", "click", clickBtnAceptarMensajeConfirmacionErrorRegistrarModificarRendicion);
	
	addEventElement("btnSiEliminarComprobanteRegistrarModificarRendicion", "click", clickBtnSiEliminarComprobanteRegistrarModificarRendicion);
	addEventElement("btnNoEliminarComprobanteRegistrarModificarRendicion", "click", clickBtnNoEliminarComprobanteRegistrarModificarRendicion);
	addEventElement("btnSiEliminarDepositoRegistrarModificarRendicion", "click", clickBtnSiEliminarDepositoRegistrarModificarRendicion);
	addEventElement("btnNoEliminarDepositoRegistrarModificarRendicion", "click", clickBtnNoEliminarDepositoRegistrarModificarRendicion);
	addEventElement("btnSiRegistrarRendicionRegistrarModificarRendicion", "click", clickBtnSiRegistrarRendicionRegistrarModificarRendicion);
	addEventElement("btnNoRegistrarRendicionRegistrarModificarRendicion", "click", clickBtnNoRegistrarRendicionRegistrarModificarRendicion);
	addEventElement("btnSiCerrarRendicionRegistrarModificarRendicion", "click", clickBtnSiCerrarRendicionRegistrarModificarRendicion);
	addEventElement("btnNoCerrarRendicionRegistrarModificarRendicion", "click", clickBtnNoCerrarRendicionRegistrarModificarRendicion);
	
	setDatosFirmaElectronica(generateDataFirma,callCerrarRendicion);
}

function setInitComprobanteTable(monedaViatico) {
	
	var comprobanteTable = $("#tblComprobante");
	var heightJqGrid = 200;
	setStyleElement("divComprobanteTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 2, true));
	if (comprobanteTable) {
		var comprobanteTableDiv = $("#divComprobanteTable");
		var widthTable = comprobanteTableDiv.width();
		comprobanteTable.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Codigo Plan Viaje",
				"Secuencial",
				"Concepto ID",
				"",
				"Id",
				"Codigo Tipo Documento",
				"Tipo Doc.",
				"Serie",
				"Nro. Documento",
				"Fecha Doc.",
				"Proveedor/Empleado",
				"Monto Doc",
				"Monto Doc. " + monedaViatico,
				"Monto Rendido",
				"Monto Rendido " + monedaViatico,
				"Flag Rendicion Total",
				"Acción"
			],
			colModel: [
				{name: "planViajeId", index: "planViajeId", width: (1*widthTable/20), hidden: true},
				{name: "secuencial", index: "secuencial", width: (1*widthTable/20), hidden: true},
				{name: "conceptoId", index: "conceptoId", width: (1*widthTable/20), hidden: true},
				{name: "columna01", index: "columna01", width: (0.5*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "";
						if (rowData.flagRendicionTotal == "0") {
							htmlElement = "<input id=\"chkJqGridComprobante" + rowData.secuencial + "\" name=\"chkJqGridComprobante\" class=\"chkJqGridComprobanteClass\" type=\"checkbox\" value=\"" + rowData.secuencial + "\" onclick=\"javascript:clickCheckboxJqGridComprobante('" + rowData.secuencial + "');\" />";
						}
						return htmlElement;
					}
				},
				{name: "identificador", index: "identificador", width: (0.5*widthTable/20), align: "right"},
				{name: "tipoDocumento", index: "tipoDocumento", width: (1*widthTable/20), hidden: true},
				{name: "descripcionTipoDocumento", index: "descripcionTipoDocumento", width: (4.2*widthTable/20)},
				{name: "serie", index: "serie", width: (1.7*widthTable/20)},
				{name: "numeroDocumento", index: "numeroDocumento", width: (2*widthTable/20)},
				{name: "fechaDocumento", index: "fechaDocumento", width: (1.8*widthTable/20), align: "center"},
				{name: "nombreRazonSocial", index: "nombreRazonSocial", width: (3.7*widthTable/20)},
				{name: "montoTotal", index: "montoTotal", width: (1*widthTable/20), hidden: true},
				{name: "montoTotalFormateado", index: "montoTotalFormateado", width: (1.7*widthTable/20), align: "right"},
				{name: "mtoReconocido", index: "mtoReconocido", width: (1*widthTable/20), hidden: true},
				{name: "mtoReconocidoFormateado", index: "mtoReconocidoFormateado", width: (1.9*widthTable/20), align: "right"},
				{name: "flagRendicionTotal", index: "flagRendicionTotal", width: (1*widthTable/20), hidden: true},
				{name: "accion", index: "accion", width: (2*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "";
						if (rowData.flagRendicionTotal == "0") {
							var linkEditarComprobante = "<a class=\"jqGridViaticoLinkClass\" onclick=\"javascript:clickLinkEditarComprobante('" + rowData.secuencial + "');\">";
							linkEditarComprobante += "<img border=\"0\" title=\"editar\" width=\"14\" height=\"15\" src=\"/a/imagenes/sigad/acciones/edit.gif\">";
							linkEditarComprobante += "</a>";
							var linkEliminarComprobante = "<a class=\"jqGridViaticoLinkClass\" onclick=\"javascript:clickLinkEliminarComprobante('" + rowData.secuencial + "');\">";
							linkEliminarComprobante += "<img border=\"0\" title=\"eliminar\" width=\"14\" height=\"15\" src=\"/a/imagenes/sigad/acciones/delete.png\">";
							linkEliminarComprobante += "</a>";
							htmlElement = linkEditarComprobante + "&nbsp;&nbsp;" + linkEliminarComprobante;
						}
						return htmlElement;
					}
				}
			],
			rowattr: function(dataTable) {
				if (dataTable.flagRendicionTotal == "1") {
					return {"class": "boldFontTableClass"};
				}
			},
			caption: "Registro de Comprobantes",
			pager: "#divComprobantePagerTable",
			loadui: "disable"
		});
		comprobanteTable.clearGridData();
	}
}

function setInitRendicionTable(monedaViatico) {
	
	var rendicionTable = $("#tblRendicion");
	var heightJqGrid = 200;
	setStyleElement("divRendicionTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 1, true));
	if (rendicionTable) {
		var rendicionTableDiv = $("#divRendicionTable");
		var widthTable = rendicionTableDiv.width();
		rendicionTable.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Codigo Plan Viaje",
				"Secuencial",
				"Cod.",
				"Asignación",
				"Entregado&nbsp;" + monedaViatico,
				"Rendido&nbsp;" + monedaViatico,
				"x Devolver&nbsp;" + monedaViatico,
				"Devuelto&nbsp;" + monedaViatico,
				"Flag Monto Devolver Negativo",
				"Flag Concepto Total"
			],
			colModel: [
				{name: "planViajeID", index: "planViajeID", width: (1*widthTable/20), hidden: true},
				{name: "secuencial", index: "secuencial", width: (1*widthTable/20), hidden: true},
				{name: "conceptoID", index: "conceptoID", width: (2*widthTable/20), align: "center"},
				{name: "descripcionConcepto", index: "descripcionConcepto", width: (6*widthTable/20)},
				{name: "monto", index: "monto", width: (3*widthTable/20), align: "right"},
				{name: "montoRendido", index: "montoRendido", width: (3*widthTable/20), align: "right"},
				{name: "montoDevolver", index: "montoDevolver", width: (3*widthTable/20), align: "right",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = rowData.montoDevolver;
						/*
						if (rowData.flagMontoDevolverNegativo == "1") {
							htmlElement = "<span class=\"colorFontGreen2TableClass\">" + rowData.montoDevolver + "</span>";
						}
						*/
						return htmlElement;
					}
				},
				{name: "montoDevueltoVoucherRIC", index: "montoDevueltoVoucherRIC", width: (3*widthTable/20), align: "right"},
				{name: "flagMontoDevolverNegativo", index: "flagMontoDevolverNegativo", width: (1*widthTable/20), hidden: true},
				{name: "flagPlanViajeConceptoTotal", index: "flagPlanViajeConceptoTotal", width: (1*widthTable/20), hidden: true}
			],
			rowattr: function(dataTable) {
				if (dataTable.flagPlanViajeConceptoTotal == "1") {
					return {"class": "boldFontTableClass"};
				}
			},
			caption: "Detalle de Rendición",
			pager: "#divRendicionPagerTable",
			loadui: "disable"
		});
		rendicionTable.clearGridData();
	}
}

function setInitDepositoTable() {
	
	var depositoTable = $("#tblDeposito");
	var heightJqGrid = 200;
	setStyleElement("divDepositoTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 1, true));
	if (depositoTable) {
		var depositoTableDiv = $("#divDepositoTable");
		var widthTable = depositoTableDiv.width();
		var linkEliminarPapeletaDeposito = "<a class=\"jqGridViaticoLinkClass\" onclick=\"javascript:clickLinkEliminarPapeletaDeposito();\">";
		linkEliminarPapeletaDeposito += "<img border=\"0\" title=\"eliminar\" width=\"17\" height=\"20\" src=\"/a/imagenes/sigad/acciones/delete.png\">";
		linkEliminarPapeletaDeposito += "</a>";
		depositoTable.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Codigo Boleta Deposito",
				"Banco",
				"Nro. Cuenta",
				"Fecha Voucher",
				"Nro. Operación",
				"T.C.",
				"Importe",
				"Importe",
				"RIC Asociado",
				"Flag Asociado RIC",
				"Flag Papeleta Total",
				linkEliminarPapeletaDeposito
			],
			colModel: [
				{name: "codigoBoletaDeposito", index: "codigoBoletaDeposito", width: (1*widthTable/20), hidden: true},
				{name: "nombreBanco", index: "nombreBanco", width: (4*widthTable/20)},
				{name: "numeroCuentaBanco", index: "numeroCuentaBanco", width: (3*widthTable/20)},
				{name: "fechaVoucher", index: "fechaVoucher", width: (2*widthTable/20), align: "center"},
				{name: "numeroOperacion", index: "numeroOperacion", width: (3.5*widthTable/20)},
				{name: "valorTipoCambio", index: "valorTipoCambio", width: (1.5*widthTable/20), align: "right"},
				{name: "montoDeposito", index: "montoDeposito", width: (1*widthTable/20), hidden: true},
				{name: "montoDepositoFormateado", index: "montoDepositoFormateado", width: (2*widthTable/20), align: "right"},
				{name: "reciboIngresoCajaAsosiado", index: "reciboIngresoCajaAsosiado", width: (3*widthTable/20)},
				{name: "flagAsociadoRIC", index: "flagAsociadoRIC", width: (1*widthTable/20), hidden: true},
				{name: "flagPapeletaTotal", index: "flagPapeletaTotal", width: (1*widthTable/20), hidden: true},
				{name: "eliminar", index: "eliminar", width: (1*widthTable/20), align: "center",
					formatter: function(cellValue, options, rowData) {
						var htmlElement = "";
						if (rowData.flagPapeletaTotal == "0") {
							if (rowData.flagAsociadoRIC == "0") {
								htmlElement = "<input id=\"rbtnJqGridDeposito" + cellValue + "\" name=\"rbtnJqGridDeposito\" class=\"rbtnJqGridDepositoClass\" type=\"radio\" value=\"" + cellValue + "\" onclick=\"javascript:clickRadioButtonJqGridDeposito('" + cellValue + "');\" />";
							}
							else {
								htmlElement = "<input id=\"rbtnJqGridDeposito" + cellValue + "\" name=\"rbtnJqGridDeposito\" class=\"rbtnJqGridDepositoClass\" type=\"radio\" value=\"" + cellValue + "\" onclick=\"javascript:clickRadioButtonJqGridDeposito('" + cellValue + "');\" disabled />";
							}
						}
						return htmlElement;
					}
				}
			],
			rowattr: function(dataTable) {
				if (dataTable.flagPapeletaTotal == "1") {
					return {"class": "boldFontTableClass"};
				}
			},
			caption: "Voucher de Depósito",
			pager: "#divDepositoPagerTable",
			loadui: "disable"
		});
		depositoTable.clearGridData();
	}
}

function setInitRICTable() {
	
	var ricTable = $("#tblRIC");
	var heightJqGrid = 200;
	setStyleElement("divRICTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 1, true));
	if (ricTable) {
		var ricTableDiv = $("#divRICTable");
		var widthTable = ricTableDiv.width();
		ricTable.jqGrid({
			width: widthTable,
			height: heightJqGrid,
			autowidth: true,
			cmTemplate: {sortable: false},
			colNames: [
				"Secuencia RIC",
				"Nro. RIC",
				"Fecha Generación",
				"Monto Numerico",
				"Monto",
				"Clasificador",
				"Flag Comprobante Total",
				"Observación"
			],
			colModel: [
				{name: "secuenciaRIC", index: "secuenciaRIC", width: (1*widthTable/30), hidden: true},
				{name: "numeroDocumento", index: "numeroDocumento", width: (3*widthTable/30)},
				{name: "fechaGeneracion", index: "fechaGeneracion", width: (4*widthTable/30), align: "center"},
				{name: "monto", index: "monto", width: (1*widthTable/30), hidden: true},
				{name: "montoFormateado", index: "montoFormatedado", width: (3*widthTable/30), align: "right"},
				{name: "clasificador", index: "clasificador", width: (10*widthTable/30)},
				{name: "flagComprobanteTotal", index: "flagComprobanteTotal", width: (1*widthTable/30), hidden: true},
				{name: "observacion", index: "observacion", width: (10*widthTable/30)}
			],
			rowattr: function(dataTable) {
				if (dataTable.flagComprobanteTotal == "1") {
					return {"class": "boldFontTableClass"};
				}
			},
			caption: "Detalle de RIC",
			pager: "#divRICPagerTable",
			loadui: "disable"
		});
		ricTable.clearGridData();
	}
}

function clickDivRendicionHeadingPanel() {
	if (getValueInputText("hidEstadoRendicionPanel") == "maximize") {
		setValueInputText("hidEstadoRendicionPanel", "minimize");
		setSrcImageElement("imgRendicionHeadingPanel", minimizeURL);
		hideElement("divRendicionBodyPanel");
	}
	else if (getValueInputText("hidEstadoRendicionPanel") == "minimize") {
		setValueInputText("hidEstadoRendicionPanel", "maximize");
		setSrcImageElement("imgRendicionHeadingPanel", maximizeURL);
		showElement("divRendicionBodyPanel");
		triggerResizeEvent();
	}
}

function clickDivDevolucionHeadingPanel() {
	if (getValueInputText("hidEstadoDevolucionPanel") == "maximize") {
		setValueInputText("hidEstadoDevolucionPanel", "minimize");
		setSrcImageElement("imgDevolucionHeadingPanel", minimizeURL);
		hideElement("divDevolucionBodyPanel");
	}
	else if (getValueInputText("hidEstadoDevolucionPanel") == "minimize") {
		setValueInputText("hidEstadoDevolucionPanel", "maximize");
		setSrcImageElement("imgDevolucionHeadingPanel", maximizeURL);
		showElement("divDevolucionBodyPanel");
		triggerResizeEvent();
	}
}

function clickBtnConsultarAsistencia() {
	
	var fechaInicial = getCurrentDateFormatEsp();
	var fechaFinal = getCurrentDateFormatEsp();
	if (getValueInputText("hidTipoDestino") == "01") {
		fechaInicial = getValueInputText("etiquetaFechaHoraSalidaEventoProgramado");
		fechaFinal = getValueInputText("etiquetaFechaHoraRetornoEventoProgramado");

		//JMCR-ME Hora < 4 Rendicion
		horaInicial = getValueInputText("etiquetaHoraSalidaEventoProgramado");
		horaFinal = getValueInputText("etiquetaHoraRetornoEventoProgramado");
		//JMCR-ME Hora < 4 Rendicion
	}
	else {
		fechaInicial = getValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado");
		fechaFinal = getValueInputText("etiquetaFechaHoraRetornoItinerarioEjecutado");

		//JMCR-ME Hora < 4 Rendicion
		horaInicial = getValueInputText("etiquetaHoraSalidaItinerarioEjecutado");
		horaFinal = getValueInputText("etiquetaHoraRetornoItinerarioEjecutado");
		//JMCR-ME Hora < 4 Rendicion
	}
	initElementsReportarAsistencia("divComprobanteTable", getValueInputText("txtNroRegistro"), fechaInicial, fechaFinal, getValueInputText("txtNombreColaborador"));
	showModalElement("divReporteAsistencia");
	triggerResizeEvent();
}

function clickBtnAgregarRendicion() {
	if (validarAgregarRendicion()) {
		var dataParametrosComprobante = new Object();
		dataParametrosComprobante.planViajeId = getValueInputText("hidCodigoPlanViaje");
		dataParametrosComprobante.estadoLlamada = "N";
		dataParametrosComprobante.secuencial = "";
		dataParametrosComprobante.origenLlamada = "V";
        dataParametrosComprobante.saldoRendir = getValueInputText("hidMontoRendirTotal");
		dataParametrosComprobante.numeroRegistroColaborador = getValueInputText("txtNroRegistro");
		initElementsRegistrarModificarComprobanteRendicion(dataParametrosComprobante);
	    showModalElement("divRegistrarModificarComprobanteRendicion");
	    triggerResizeEvent();
	    triggerResizeEventTooSlow();
	}
}

function clickBtnVerDetalleRendicion() {
	initElementsConsultarGastoDetalle("divComprobanteTable", getValueInputText("hidCodigoPlanViaje"), getValueInputText("hidValueChkJqGridComprobante"), getValueInputText("hidMoneda"));
    showModalElement("divConsultarGastoDetalle");
	triggerResizeEvent();
}

function clickBtnAgregarDevolucion() {
	if (validarAgregarDevolucion()) {
		initElementsRegistrarBoletaDeposito();
	    showModalElement("divRegistrarBoletaDeposito");
	}
}

function clickBtnGrabarRendicion() {
	if (validarGrabarRendicion()) {
		showModalElement("divMensajeConfirmacionRegistrarRendicionRegistrarModificarRendicion");
	}
}

function clickBtnAdjuntarRendicion() {
	
	var dataParametrosArchivo = new Object();
	dataParametrosArchivo.planViajeId = getValueInputText("hidCodigoPlanViaje");
    dataParametrosArchivo.codigoBoleto = "";
    dataParametrosArchivo.estadoOrigen = "V";
    dataParametrosArchivo.estadoLLamada = "R";
    dataParametrosArchivo.numeroRegistroColaborador = getValueInputText("txtNroRegistro");
    dataParametrosArchivo.paginaOrigen = "PRINCIPAL";
    initElementsConsultarRegistrarEliminarArchivo(dataParametrosArchivo);
    showModalElement("divAdjuntarDocumento");
    triggerResizeEvent();
}


var generateDataFirma = function(){
	var pass = $("#txtPasswordUsuario").val();
	var variableImprimirSendPost = $("#txtNroPlanilla").val();
	var dataFirmaJson = {
		"variableImprimirSendPost": variableImprimirSendPost,
		"tipDocumento": "048",
		"tipProceso": "C",
		"txtPasswordUsuario": pass
	};
	return dataFirmaJson;
};

function clickBtnCerrarRendicion() {
	//showModalElement("divMensajeConfirmacionCerrarRendicionRegistrarModificarRendicion");
	var codRendicion = $("#txtNroPlanilla").val();
	
	//antes de firmar validamos...
	var esMenorGasto = getValueInputText("selIndicadorDevolucionMenorGasto");
	if("S"==esMenorGasto)setValueInputText("hidFlagRegistroComprobante", "-1");//no validamos los comprobantes ...
	
	showMensajePreviaConfirmacionRendicionFirma(codRendicion,function(){
		//showModalElement("divMensajeAutorizaEnviar");//mensaje modal de la firma	
		
		$("#txtPasswordUsuario").val("");
		firmaElectronicaValida(resultadoProcessVerificaFirma);
		
	});
}

function clickBtnImprimirRendicion() {
	  /*  var formPost = $("#formImprimirPost");
    formPost.find("input[name='action']").val("imprimirRendicionViatico");
    //formPost.find("input[name='action']").val("imprimirRendicionDeclaracionJurada");
    //formPost.find("input[name='action']").val("imprimirRendicionDeclaracionJuradaPermanencia");
    formPost.find("input[name='codPlanilla']").val(getTrimValue("#txtNroPlanilla"));
    formPost.submit();*/
	initElementsImpresion();
    showModalElement("divImpresion");
}

function clickBtnRetornarRendicion() {
	window.history.back();
}

function changeEtiquetaFechaHoraSalidaItinerarioEjecutado() {
	if (isBrowserInternetExplorer()) {
		if (trimText(getValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado")) != "" && isValidoFormatDate(getValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado"))) {
			if (isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado")), formatEspDateToEngFormatDate(getValueInputText("hidFechaMaximaDate")))) {
				setValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado", "");
			}
		}
		else {
			setValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado", "");
		}
		changeDateEtiquetaFechaHoraSalidaItinerarioEjecutadoDiv();
	}
}

function changeEtiquetaFechaHoraRetornoItinerarioEjecutado() {
	if (isBrowserInternetExplorer()) {
		if (trimText(getValueInputText("etiquetaFechaHoraRetornoItinerarioEjecutado")) != "" && isValidoFormatDate(getValueInputText("etiquetaFechaHoraRetornoItinerarioEjecutado"))) {
			if (isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaHoraRetornoItinerarioEjecutado")), formatEspDateToEngFormatDate(getValueInputText("hidFechaMaximaDate")))) {
				setValueInputText("etiquetaFechaHoraRetornoItinerarioEjecutado", "");
			}
		}
		else {
			setValueInputText("etiquetaFechaHoraRetornoItinerarioEjecutado", "");
		}
		changeDateEtiquetaFechaHoraRetornoItinerarioEjecutadoDiv();
	}
}

function changeDateEtiquetaFechaHoraSalidaItinerarioEjecutadoDiv() {
	
	var dataValidacion = validarNoExistenComprobantesDepositos();
	if (dataValidacion.flagNoExistenComprobantesDepositos) {
		setValueInputText("hidFechaSalidaEjecutadaAnterior", getValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado"));
		if (getValueInputText("hidTipoDestino") == "01") {
			validarFechaSalidaEjecutado();
		}
		else {
			validarFechaSalidaItinerario();
		}
	}
	else {
		showMensajeConfirmacionAplicativoWithBody(dataValidacion.idDivModalErrorMessage, dataValidacion.idDivTituloPanelErrorMessage, dataValidacion.idDivBodyPanelErrorMessage, dataValidacion.idEtiquetaErrorMessage, dataValidacion.errorMessageTitulo, dataValidacion.errorMessageBody);
		destroyDateTimePicker("etiquetaFechaHoraSalidaItinerarioEjecutadoDiv");
		setValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado", getValueInputText("hidFechaSalidaEjecutadaAnterior"));
		recreateDateTimePicker("etiquetaFechaHoraSalidaItinerarioEjecutadoDiv", "dp.change", changeDateEtiquetaFechaHoraSalidaItinerarioEjecutadoDiv, formatEspDateToEngFormatDate(getValueInputText("hidFechaMaximaDate")));
	}
}

function changeDateEtiquetaFechaHoraRetornoItinerarioEjecutadoDiv() {
	
	var dataValidacion = validarNoExistenComprobantesDepositos();
	if (dataValidacion.flagNoExistenComprobantesDepositos) {
		setValueInputText("hidFechaRetornoEjecutadaAnterior", getValueInputText("etiquetaFechaHoraRetornoItinerarioEjecutado"));
		if (getValueInputText("hidTipoDestino") == "01") {
			validarFechaRetornoEjecutado();
		}
		else {
			validarFechaRetornoItinerario();
		}
	}
	else {
		showMensajeConfirmacionAplicativoWithBody(dataValidacion.idDivModalErrorMessage, dataValidacion.idDivTituloPanelErrorMessage, dataValidacion.idDivBodyPanelErrorMessage, dataValidacion.idEtiquetaErrorMessage, dataValidacion.errorMessageTitulo, dataValidacion.errorMessageBody);
		destroyDateTimePicker("etiquetaFechaHoraRetornoItinerarioEjecutadoDiv");
		setValueInputText("etiquetaFechaHoraRetornoItinerarioEjecutado", getValueInputText("hidFechaRetornoEjecutadaAnterior"));
		recreateDateTimePicker("etiquetaFechaHoraRetornoItinerarioEjecutadoDiv", "dp.change", changeDateEtiquetaFechaHoraRetornoItinerarioEjecutadoDiv, formatEspDateToEngFormatDate(getValueInputText("hidFechaMaximaDate")));
	}
}



//JMCR-ME Hora < 4 Rendicion	

/*function changeEtiquetaHoraSalidaItinerarioEjecutado() {

	if (getValueInputText("hidTipoDestino") == "01" && getValueInputText("hidFlagMenorIgual4Horas") == "1") {
		validarDiferenciaHoraSalidaRetornoEjecutado();
	}
}

function changeEtiquetaHoraRetornoItinerarioEjecutado() {

	if (getValueInputText("hidTipoDestino") == "01" && getValueInputText("hidFlagMenorIgual4Horas") == "1") {
		validarDiferenciaHoraSalidaRetornoEjecutado();
	}
}*/

//JMCR-ME Hora < 4 Rendicion	



function changeSelIndicadorDDJJ() {
	var dataValidacion = validarNoExistenComprobantesDepositos();
	if (!dataValidacion.flagNoExistenComprobantesDepositos) {
		showMensajeConfirmacionAplicativoWithBody(dataValidacion.idDivModalErrorMessage, dataValidacion.idDivTituloPanelErrorMessage, dataValidacion.idDivBodyPanelErrorMessage, dataValidacion.idEtiquetaErrorMessage, dataValidacion.errorMessageTitulo, dataValidacion.errorMessageBody);
		setValueInputText("selIndicadorDDJJ", getValueInputText("hidIndicadorExteriorDDJJ"));
	}
}

function changeSelIndicadorDevolucionMenorGasto() {
	var dataValidacion = validarNoExistenComprobantesDepositos();
	disabledElement("btnCerrarRendicion");
}

function clickBtnAceptarMensajeConfirmacionRegistrarModificarRendicion() {
	hideModalElement("divMensajeConfirmacionRegistrarModificarRendicion");
}

function clickBtnAceptarMensajeConfirmacionErrorRegistrarModificarRendicion() {
	hideModalElement("divMensajeConfirmacionErrorRegistrarModificarRendicion");
}

function clickBtnSiEliminarComprobanteRegistrarModificarRendicion() {
	hideModalElement("divMensajeConfirmacionEliminarComprobanteRegistrarModificarRendicion");
	callEliminarComprobante();
}

function clickBtnNoEliminarComprobanteRegistrarModificarRendicion() {
	setValueInputText("hidSecuencialEliminarComprobanteRegistrarModificarRendicion", "");
	setValueInputText("hidConceptoIdEliminarComprobanteRegistrarModificarRendicion", "");
	setValueInputText("hidMtoReconocidoEliminarComprobanteRegistrarModificarRendicion", "");
	hideModalElement("divMensajeConfirmacionEliminarComprobanteRegistrarModificarRendicion");
}

function clickBtnSiEliminarDepositoRegistrarModificarRendicion() {
	hideModalElement("divMensajeConfirmacionEliminarDepositoRegistrarModificarRendicion");
	callDesasociarPapeletaDeposito();
}

function clickBtnNoEliminarDepositoRegistrarModificarRendicion() {
	hideModalElement("divMensajeConfirmacionEliminarDepositoRegistrarModificarRendicion");
}

function clickBtnSiRegistrarRendicionRegistrarModificarRendicion() {
	hideModalElement("divMensajeConfirmacionRegistrarRendicionRegistrarModificarRendicion");
	callRegistrarRendicion();
}

function clickBtnNoRegistrarRendicionRegistrarModificarRendicion() {
	hideModalElement("divMensajeConfirmacionRegistrarRendicionRegistrarModificarRendicion");
}

function clickBtnSiCerrarRendicionRegistrarModificarRendicion() {
	hideModalElement("divMensajeConfirmacionCerrarRendicionRegistrarModificarRendicion");
	callCerrarRendicion();
}

function clickBtnNoCerrarRendicionRegistrarModificarRendicion() {
	hideModalElement("divMensajeConfirmacionCerrarRendicionRegistrarModificarRendicion");
}

function clickCheckboxJqGridComprobante(secuencial) {
	
	var jqGridComprobanteChk = $("input#chkJqGridComprobante" + secuencial);
	var jqGridComprobanteChkAnother = $("input.chkJqGridComprobanteClass").not("input#chkJqGridComprobante" + secuencial);
	
	if (jqGridComprobanteChk.is(":checked")) {
		setValueInputText("hidValueChkJqGridComprobante", secuencial);
		jqGridComprobanteChkAnother.attr("disabled", "disabled");
	}
	else {
		setValueInputText("hidValueChkJqGridComprobante", "");
		jqGridComprobanteChkAnother.removeAttr("disabled", "disabled");
	}
}

function clickLinkEditarComprobante(secuencial) {
	
	var dataParametrosComprobante = new Object();
	dataParametrosComprobante.planViajeId = getValueInputText("hidCodigoPlanViaje");
	dataParametrosComprobante.estadoLlamada = "E";
	dataParametrosComprobante.secuencial = secuencial;
	dataParametrosComprobante.origenLlamada = "V";
	dataParametrosComprobante.saldoRendir = getValueInputText("hidMontoRendirTotal");
	dataParametrosComprobante.numeroRegistroColaborador = getValueInputText("txtNroRegistro");
	initElementsRegistrarModificarComprobanteRendicion(dataParametrosComprobante);
    showModalElement("divRegistrarModificarComprobanteRendicion");
    triggerResizeEvent();
    triggerResizeEventTooSlow();
}

function clickLinkEliminarComprobante(secuencial) {
	
	var comprobanteTable = $("#tblComprobante");
	var rowData = comprobanteTable.getRowData(secuencial);
	setValueInputText("hidSecuencialEliminarComprobanteRegistrarModificarRendicion", secuencial);
	setValueInputText("hidConceptoIdEliminarComprobanteRegistrarModificarRendicion", rowData.conceptoId);
	setValueInputText("hidMtoReconocidoEliminarComprobanteRegistrarModificarRendicion", rowData.mtoReconocido);
	showModalElement("divMensajeConfirmacionEliminarComprobanteRegistrarModificarRendicion");
}

function clickLinkEliminarPapeletaDeposito() {
	
	if (getValueInputText("hidValueRadioButtonJqGridDeposito") == "") {
		showMensajeConfirmacionAplicativoWithoutBody("divMensajeConfirmacionErrorRegistrarModificarRendicion", "divTituloPanelMensajeConfirmacionErrorRegistrarModificarRendicion", "divBodyPanelMensajeConfirmacionErrorRegistrarModificarRendicion", errorMessageRegistrarModificarRendicion.seleccionarVoucherDeposito);
	}
	else {
		showModalElement("divMensajeConfirmacionEliminarDepositoRegistrarModificarRendicion");
	}
}

function clickRadioButtonJqGridDeposito(codigoBoletaDeposito) {
	
	var depositoTable = $("#tblDeposito");
	var rowData = depositoTable.getRowData(codigoBoletaDeposito);
	setValueInputText("hidValueRadioButtonJqGridDeposito", codigoBoletaDeposito);
	setValueInputText("hidMontoDepositoJqGridDeposito", rowData.montoDeposito);
}

function validarFechaSalidaEjecutado() {
	
	var flagFechaValida = true;
	var errorMessage = "";
	hideElement("divErrorFechaSalidaDatosGeneralesRegistrarModificarRendicion");
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaHoraSalidaEventoProgramado")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRegistrarModificarRendicion.fechaSalidaEjecucionMenorFechaProgramada;
	}
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaHoraRetornoEventoProgramado")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRegistrarModificarRendicion.fechaSalidaEjecucionMayorFechaRetornoProgramada;
	}
	
	if (!flagFechaValida) {
		setValueInputText("hidFlagFechaHoraSalidaValida", "0");
		showMessageErrorFechaSalidaRegistrarModificarRendicion(errorMessage);
	}
	else {
		if (trimText(getValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado")) != "") {
			setValueInputText("hidFlagFechaHoraSalidaValida", "1");
			if (trimText(getValueInputText("etiquetaFechaHoraRetornoItinerarioEjecutado")) != "") {
				validarFechaRetornoEjecutado();
			}
		}
		else {
			setValueInputText("hidFlagFechaHoraSalidaValida", "0");
		}
	}
}

function validarFechaSalidaItinerario() {
	
	var flagFechaValida = true;
	var errorMessage = "";
	hideElement("divErrorFechaSalidaDatosGeneralesRegistrarModificarRendicion");
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaHoraSalidaEventoProgramado")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRegistrarModificarRendicion.fechaSalidaItinerarioMayorFechaEvento;
	}
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaHoraRetornoEventoProgramado")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRegistrarModificarRendicion.fechaSalidaItinerarioMayorFechaRetornoEvento;
	}
	
	if (!flagFechaValida) {
		setValueInputText("hidFlagFechaHoraSalidaValida", "0");
		showMessageErrorFechaSalidaRegistrarModificarRendicion(errorMessage);
	}
	else {
		if (trimText(getValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado")) != "") {
			setValueInputText("hidFlagFechaHoraSalidaValida", "1");
			if (trimText(getValueInputText("etiquetaFechaHoraRetornoItinerarioEjecutado")) != "") {
				validarFechaRetornoItinerario();
			}
		}
		else {
			setValueInputText("hidFlagFechaHoraSalidaValida", "0");
		}
	}
}

function validarFechaRetornoEjecutado() {
	
	var flagFechaValida = true;
	var errorMessage = "";
	hideElement("divErrorFechaRetornoDatosGeneralesRegistrarModificarRendicion");
		
	if (getValueInputText("hidFlagMenorIgual4Horas") == "1") {
		if (flagFechaValida && !isDate1EqualsThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaHoraRetornoItinerarioEjecutado")))) {
			flagFechaValida = false;
			errorMessage = errorMessageRegistrarModificarRendicion.fechaSalidaFechaRetornoEjecucionIguales;
		}
		
		//function compararHoras( hora1, hora2 ) 
		//	if ( h1 >  h2 ) return 1;	// 1
		//	if ( h1 <  h2 ) return 2;	// 2	
		//	else return 0;
		
		//function roundDiferenciaHoras( horaMayorHHMM, horaMenorHHMM, 2 )
		
		// function validateHour(timeStr);
		//JMCR-ME Hora < 4 Rendicion
		
		var horaSalida = getValueInputText("etiquetaHoraSalidaItinerarioEjecutado");
		var horaRetorno = getValueInputText("etiquetaHoraRetornoItinerarioEjecutado");
		
		if (!validateHour(horaSalida) || !validateHour(horaRetorno)) {
			flagFechaValida = false;
			errorMessage = errorMessageRegistrarModificarRendicion.horaSalidaRetornoEjecucionFormato;	
		}
		
		if (flagFechaValida && compararHoras(horaSalida, horaRetorno) != 2) {
			flagFechaValida = false;
			errorMessage = errorMessageRegistrarModificarRendicion.horaSalidaHoraRetornoEjecucionMayor;
		}
		
		if (flagFechaValida && (roundDiferenciaHoras(horaRetorno, horaSalida, 2) > 4)) {
			flagFechaValida = false;
			errorMessage = errorMessageRegistrarModificarRendicion.horaSalidaHoraRetornoEjecucion4h;
		}
		//JMCR-ME Hora < 4 Rendicion
	}
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaHoraRetornoItinerarioEjecutado")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaHoraRetornoEventoProgramado")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRegistrarModificarRendicion.fechaRetornoEjecucionMayorFechaProgramada;
	}
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaHoraSalidaEventoProgramado")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaHoraRetornoItinerarioEjecutado")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRegistrarModificarRendicion.fechaRetornoEjecucionMenorFechaSalidaProgramada;
	}
	
	if (!flagFechaValida) {
		setValueInputText("hidFlagFechaHoraRetornoValida", "0");
		showMessageErrorFechaRetornoRegistrarModificarRendicion(errorMessage);
	}
	else {
		if (trimText(getValueInputText("etiquetaFechaHoraRetornoItinerarioEjecutado")) != "") {
			if (trimText(getValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado")) != "") {
				validarFechaRetornoMayorIgualFechaSalidaItinerarioEjecutado();
			}
		}
		else {
			setValueInputText("hidFlagFechaHoraRetornoValida", "0");
		}
	}
}

function validarFechaRetornoItinerario() {
	
	var flagFechaValida = true;
	var errorMessage = "";
	hideElement("divErrorFechaRetornoDatosGeneralesRegistrarModificarRendicion");
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaHoraRetornoEventoProgramado")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaHoraRetornoItinerarioEjecutado")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRegistrarModificarRendicion.fechaRetornoItinerarioMenorFechaEvento;
	}
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaHoraSalidaEventoProgramado")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaHoraRetornoItinerarioEjecutado")))) {
		flagFechaValida = false;
		errorMessage = errorMessageRegistrarModificarRendicion.fechaRetornoItinerarioMenorFechaSalidaEvento;
	}
	
	if (!flagFechaValida) {
		setValueInputText("hidFlagFechaHoraRetornoValida", "0");
		showMessageErrorFechaRetornoRegistrarModificarRendicion(errorMessage);
	}
	else {
		if (trimText(getValueInputText("etiquetaFechaHoraRetornoItinerarioEjecutado")) != "") {
			if (trimText(getValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado")) != "") {
				validarFechaRetornoMayorIgualFechaSalidaItinerarioEjecutado();
			}
		}
		else {
			setValueInputText("hidFlagFechaHoraRetornoValida", "0");
		}
	}
}

function validarFechaRetornoMayorIgualFechaSalidaItinerarioEjecutado() {
	
	var flagFechaValida = true;
	var errorMessage = "";
	hideElement("divErrorFechaRetornoDatosGeneralesRegistrarModificarRendicion");
	
	if (flagFechaValida && isDate1GreaterThanDate2(formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado")), formatEspDateToEngFormatDate(getValueInputText("etiquetaFechaHoraRetornoItinerarioEjecutado")))) {
		flagFechaValida = false;
		if (getValueInputText("hidTipoDestino") == "01") {
			errorMessage = errorMessageRegistrarModificarRendicion.fechaRetornoMenorFechaSalidaEjecucion;
		}
		else {
			errorMessage = errorMessageRegistrarModificarRendicion.fechaRetornoMenorFechaSalidaItinerario;
		}
	}
	
	if (!flagFechaValida) {
		setValueInputText("hidFlagFechaHoraRetornoValida", "0");
		showMessageErrorFechaRetornoRegistrarModificarRendicion(errorMessage);
	}
	else {
		setValueInputText("hidFlagFechaHoraRetornoValida", "1");
	}
}

function validarAgregarRendicion() {
	
	var dataValidacion;
	
	dataValidacion = validarCamposNoVaciosAgregarRendicionDevolucion();
	if (!dataValidacion.flagCamposNoVacios) {
		showMensajeConfirmacionAplicativoWithBody(dataValidacion.idDivModalErrorMessage, dataValidacion.idDivTituloPanelErrorMessage, dataValidacion.idDivBodyPanelErrorMessage, dataValidacion.idEtiquetaErrorMessage, dataValidacion.errorMessageTitulo, dataValidacion.errorMessageBody);
		return false;
	}
	
	dataValidacion = validarFechaSalidaRetornoEIValidas();
	if (!dataValidacion.flagFechaSalidaRetornoEIValidas) {
		showMensajeConfirmacionAplicativoWithBody(dataValidacion.idDivModalErrorMessage, dataValidacion.idDivTituloPanelErrorMessage, dataValidacion.idDivBodyPanelErrorMessage, dataValidacion.idEtiquetaErrorMessage, dataValidacion.errorMessageTitulo, dataValidacion.errorMessageBody);
		return false;
	}
	
	dataValidacion = validarNoExistenCambiosRendicion();
	if (!dataValidacion.flagNoExistenCambiosRendicion) {
		showMensajeConfirmacionAplicativoWithBody(dataValidacion.idDivModalErrorMessage, dataValidacion.idDivTituloPanelErrorMessage, dataValidacion.idDivBodyPanelErrorMessage, dataValidacion.idEtiquetaErrorMessage, dataValidacion.errorMessageTitulo, dataValidacion.errorMessageBody);
		return false;
	}

	dataValidacion = validarMontoCeroDevolucion();
	if(dataValidacion.flagMontoDevolucionZero){
		showMensajeConfirmacionAplicativoWithBody(dataValidacion.idDivModalErrorMessage, dataValidacion.idDivTituloPanelErrorMessage, dataValidacion.idDivBodyPanelErrorMessage, dataValidacion.idEtiquetaErrorMessage, dataValidacion.errorMessageTitulo, dataValidacion.errorMessageBody);
		return false;
	}
	
	return true;
}

function validarMontoCeroDevolucion(){
	var errorMessage = '';
	var flagMontoDevolucionZero = false;
	var registros = $("#tblRendicion").getGridParam("reccount");
	var montoDevolver = $("#tblRendicion").jqGrid('getCol', 'montoDevolver', false, 'sum');
	if(registros>0 && montoDevolver==0){
		flagMontoDevolucionZero = true;
		errorMessage = 'No es posible registrar un nuevo comprobante debido a que ya no existe saldo por devolver.';
	}
	
	var dataValidacion = {
		flagMontoDevolucionZero: flagMontoDevolucionZero,
		idDivModalErrorMessage: "divMensajeConfirmacionErrorRegistrarModificarRendicion",
		idDivTituloPanelErrorMessage: "divTituloPanelMensajeConfirmacionErrorRegistrarModificarRendicion",
		idDivBodyPanelErrorMessage: "divBodyPanelMensajeConfirmacionErrorRegistrarModificarRendicion",
		idEtiquetaErrorMessage: "etiquetaErrorMensajeConfirmacionErrorRegistrarModificarRendicion",
		errorMessageTitulo: "Error",
		errorMessageBody: errorMessage
	};
	return dataValidacion;
}

function validarAgregarDevolucion() {
	
	var dataValidacion;
	
	dataValidacion = validarCamposNoVaciosAgregarRendicionDevolucion();
	if (!dataValidacion.flagCamposNoVacios) {
		showMensajeConfirmacionAplicativoWithBody(dataValidacion.idDivModalErrorMessage, dataValidacion.idDivTituloPanelErrorMessage, dataValidacion.idDivBodyPanelErrorMessage, dataValidacion.idEtiquetaErrorMessage, dataValidacion.errorMessageTitulo, dataValidacion.errorMessageBody);
		return false;
	}
	
	dataValidacion = validarFechaSalidaRetornoEIValidas();
	if (!dataValidacion.flagFechaSalidaRetornoEIValidas) {
		showMensajeConfirmacionAplicativoWithBody(dataValidacion.idDivModalErrorMessage, dataValidacion.idDivTituloPanelErrorMessage, dataValidacion.idDivBodyPanelErrorMessage, dataValidacion.idEtiquetaErrorMessage, dataValidacion.errorMessageTitulo, dataValidacion.errorMessageBody);
		return false;
	}
	
	dataValidacion = validarNoExistenCambiosRendicion();
	if (!dataValidacion.flagNoExistenCambiosRendicion) {
		showMensajeConfirmacionAplicativoWithBody(dataValidacion.idDivModalErrorMessage, dataValidacion.idDivTituloPanelErrorMessage, dataValidacion.idDivBodyPanelErrorMessage, dataValidacion.idEtiquetaErrorMessage, dataValidacion.errorMessageTitulo, dataValidacion.errorMessageBody);
		return false;
	}
	
	return true;
}

function validarGrabarRendicion() {
	
	var dataValidacion;
	
	dataValidacion = validarFechaSalidaRetornoEIValidas();
	if (!dataValidacion.flagFechaSalidaRetornoEIValidas) {
		showMensajeConfirmacionAplicativoWithBody(dataValidacion.idDivModalErrorMessage, dataValidacion.idDivTituloPanelErrorMessage, dataValidacion.idDivBodyPanelErrorMessage, dataValidacion.idEtiquetaErrorMessage, dataValidacion.errorMessageTitulo, dataValidacion.errorMessageBody);
		return false;
	}
	
	return true;
}

function validarCamposNoVaciosAgregarRendicionDevolucion() {
	
	var flagCamposNoVacios = true;
	var errorMessage = "";
	
	if (flagCamposNoVacios && trimText(getValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado")) == "") {
		flagCamposNoVacios = false;
		if (getValueInputText("hidTipoDestino") == "01") {
			errorMessage = errorMessageRegistrarModificarRendicion.completarFechaSalidaEjecucion;
			//JMCR-ME Hora < 4 Rendicion
			if (getValueInputText("hidFlagMenorIgual4Horas") == "1" && trimText(getValueInputText("etiquetaHoraSalidaItinerarioEjecutado")) == "") {
				errorMessage = errorMessageRegistrarModificarRendicion.completarFechaSalidaEjecucion;
			}
			//JMCR-ME Hora < 4 Rendicion	
		}
		else {
			errorMessage = errorMessageRegistrarModificarRendicion.completarFechaSalidaItinerario;
		}
	}
	
	if (flagCamposNoVacios && trimText(getValueInputText("etiquetaFechaHoraRetornoItinerarioEjecutado")) == "") {
		flagCamposNoVacios = false;
		if (getValueInputText("hidTipoDestino") == "01") {
			errorMessage = errorMessageRegistrarModificarRendicion.completarFechaRetornoEjecucion;
			//JMCR-ME Hora < 4 Rendicion
			if (getValueInputText("hidFlagMenorIgual4Horas") == "1" && trimText(getValueInputText("etiquetaHoraRetornoItinerarioEjecutado")) == "") {
				errorMessage = errorMessageRegistrarModificarRendicion.completarFechaRetornoEjecucion;
			}
			//JMCR-ME Hora < 4 Rendicion	
		}
		else {
			errorMessage = errorMessageRegistrarModificarRendicion.completarFechaRetornoItinerario;
		}
	}
	
	var dataValidacion = {
		flagCamposNoVacios: flagCamposNoVacios,
		idDivModalErrorMessage: "divMensajeConfirmacionErrorRegistrarModificarRendicion",
		idDivTituloPanelErrorMessage: "divTituloPanelMensajeConfirmacionErrorRegistrarModificarRendicion",
		idDivBodyPanelErrorMessage: "divBodyPanelMensajeConfirmacionErrorRegistrarModificarRendicion",
		idEtiquetaErrorMessage: "etiquetaErrorMensajeConfirmacionErrorRegistrarModificarRendicion",
		errorMessageTitulo: "Error",
		errorMessageBody: errorMessage
	};
	return dataValidacion;
}

function validarFechaSalidaRetornoEIValidas() {
	
	var flagFechaSalidaRetornoEIValidas = true;
	var errorMessage = "";
	
	if (flagFechaSalidaRetornoEIValidas && trimText(getValueInputText("hidFlagFechaHoraSalidaValida")) == "0") {
		flagFechaSalidaRetornoEIValidas = false;
		if (getValueInputText("hidTipoDestino") == "01") {
			errorMessage = errorMessageRegistrarModificarRendicion.completarFechaSalidaEjecucionValida;
		}
		else {
			errorMessage = errorMessageRegistrarModificarRendicion.completarFechaSalidaItinerarioValida;
		}
	}
	
	if (flagFechaSalidaRetornoEIValidas && trimText(getValueInputText("hidFlagFechaHoraRetornoValida")) == "0") {
		flagFechaSalidaRetornoEIValidas = false;
		if (getValueInputText("hidTipoDestino") == "01") {
			errorMessage = errorMessageRegistrarModificarRendicion.completarFechaRetornoEjecucionValida;
		}
		else {
			errorMessage = errorMessageRegistrarModificarRendicion.completarFechaRetornoItinerarioValida;
		}
	}
	
	var dataValidacion = {
		flagFechaSalidaRetornoEIValidas: flagFechaSalidaRetornoEIValidas,
		idDivModalErrorMessage: "divMensajeConfirmacionErrorRegistrarModificarRendicion",
		idDivTituloPanelErrorMessage: "divTituloPanelMensajeConfirmacionErrorRegistrarModificarRendicion",
		idDivBodyPanelErrorMessage: "divBodyPanelMensajeConfirmacionErrorRegistrarModificarRendicion",
		idEtiquetaErrorMessage: "etiquetaErrorMensajeConfirmacionErrorRegistrarModificarRendicion",
		errorMessageTitulo: "Error",
		errorMessageBody: errorMessage
	};
	return dataValidacion;
}



function validarNoExistenComprobantesDepositos() {
	
	var flagNoExistenComprobantesDepositos = true;
	var errorMessage = "";
	var comprobanteTable = $("#tblComprobante");
	var depositoTable = $("#tblDeposito");
	var numRowsComprobanteTable = comprobanteTable.jqGrid("getGridParam", "records")
	var numRowsDepositoTable = depositoTable.jqGrid("getGridParam", "records")
	
	if (flagNoExistenComprobantesDepositos && numRowsComprobanteTable > 0) {
		flagNoExistenComprobantesDepositos = false;
		if (getValueInputText("hidTipoDestino") == "01") {
			errorMessage = errorMessageRegistrarModificarRendicion.existenComprobantesRangoFechaEjecucion;
		}
		else {
			errorMessage = errorMessageRegistrarModificarRendicion.existenComprobantesRangoFechaItinerario;
		}
	}
	
	if (getValueInputText("hidCodigoCanalAtencion") == "R") {
		if (flagNoExistenComprobantesDepositos && numRowsDepositoTable > 0) {
			flagNoExistenComprobantesDepositos = false;
			if (getValueInputText("hidTipoDestino") == "01") {
				errorMessage = errorMessageRegistrarModificarRendicion.existenVoucherDepositoRangoFechaEjecucion;
			}
			else {
				errorMessage = errorMessageRegistrarModificarRendicion.existenVoucherDepositoRangoFechaItinerario;
			}
		}
	}
	
	var dataValidacion = {
		flagNoExistenComprobantesDepositos: flagNoExistenComprobantesDepositos,
		idDivModalErrorMessage: "divMensajeConfirmacionErrorRegistrarModificarRendicion",
		idDivTituloPanelErrorMessage: "divTituloPanelMensajeConfirmacionErrorRegistrarModificarRendicion",
		idDivBodyPanelErrorMessage: "divBodyPanelMensajeConfirmacionErrorRegistrarModificarRendicion",
		idEtiquetaErrorMessage: "etiquetaErrorMensajeConfirmacionErrorRegistrarModificarRendicion",
		errorMessageTitulo: "Error",
		errorMessageBody: errorMessage
	};
	return dataValidacion;
}

function validarNoExistenCambiosRendicion() {
	
	var flagNoExistenCambiosRendicion = true;
	var errorMessage = "";
	
	if (getValueInputText("hidTipoDestino") == "02") {
		if (flagNoExistenCambiosRendicion && getValueInputText("hidIndicadorExteriorDDJJ") != getValueInputText("selIndicadorDDJJ")) {
			flagNoExistenCambiosRendicion = false;
			errorMessage = errorMessageRegistrarModificarRendicion.grabarRendicion;
		}
	}
	
	if (getValueInputText("hidCodigoCanalAtencion") == "C") {
		if (flagNoExistenCambiosRendicion && getValueInputText("hidIndicadorMenorGasto") != getValueInputText("selIndicadorDevolucionMenorGasto")) {
			flagNoExistenCambiosRendicion = false;
			errorMessage = errorMessageRegistrarModificarRendicion.grabarRendicion;
		}
	}
	
	if (flagNoExistenCambiosRendicion && (getValueInputText("hidFechaSalidaEjecutada") != getValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado") ||
			getValueInputText("hidHoraSalidaEjecutada") != getValueInputText("etiquetaHoraSalidaItinerarioEjecutado")) ) { //JMCR-ME Hora < 4 Rendicion	
		flagNoExistenCambiosRendicion = false;
		errorMessage = errorMessageRegistrarModificarRendicion.grabarRendicion;
	}
	
	if (flagNoExistenCambiosRendicion && (getValueInputText("hidFechaRetornoEjecutada") != getValueInputText("etiquetaFechaHoraRetornoItinerarioEjecutado") || 
			getValueInputText("hidHoraRetornoEjecutada") != getValueInputText("etiquetaHoraRetornoItinerarioEjecutado")) ) { //JMCR-ME Hora < 4 Rendicion	
		flagNoExistenCambiosRendicion = false;
		errorMessage = errorMessageRegistrarModificarRendicion.grabarRendicion;
	}
	
	var dataValidacion = {
		flagNoExistenCambiosRendicion: flagNoExistenCambiosRendicion,
		idDivModalErrorMessage: "divMensajeConfirmacionErrorRegistrarModificarRendicion",
		idDivTituloPanelErrorMessage: "divTituloPanelMensajeConfirmacionErrorRegistrarModificarRendicion",
		idDivBodyPanelErrorMessage: "divBodyPanelMensajeConfirmacionErrorRegistrarModificarRendicion",
		idEtiquetaErrorMessage: "etiquetaErrorMensajeConfirmacionErrorRegistrarModificarRendicion",
		errorMessageTitulo: "Error",
		errorMessageBody: errorMessage
	};
	return dataValidacion;	
}

function habilitarDeshabilitarCerrarRendicion() {
	if (getValueInputText("hidFlagHabilitarCerrarRendicion") == "1" && 
			getValueInputText("hidFlagCVRHabilitarCerrarRendicion") == "1" && !esRegistrador) {
		enabledElement("btnCerrarRendicion");
	}
	else {
		disabledElement("btnCerrarRendicion");
	}
}

function habilitarDeshabilitarComponentesRendicionCerrada() {
	enabledElement("btnImprimirRendicion");
	disabledElement("etiquetaFechaHoraSalidaItinerarioEjecutado");
	//disabledElement("spanFechaHoraSalidaItinerarioEjecutado");
	disabledElement("etiquetaFechaHoraRetornoItinerarioEjecutado");
	//disabledElement("spanFechaHoraRetornoItinerarioEjecutado");
	
	//JMCR-ME Hora < 4 Rendicion	
	disabledElement("etiquetaHoraSalidaItinerarioEjecutado");
	disabledElement("etiquetaHoraRetornoItinerarioEjecutado");
	//JMCR-ME Hora < 4 Rendicion	
	
	disabledElement("selIndicadorDDJJ");
	disabledElement("selIndicadorDevolucionMenorGasto");
	disabledElement("btnAgregarRendicion");
	disabledElement("btnAgregarDevolucion");
	disabledElement("btnGrabarRendicion");
	disabledElement("btnAdjuntarRendicion");
	disabledElement("btnCerrarRendicion");
	uncheckElementForClass("rbtnJqGridDepositoClass");
	disabledElementForClass("rbtnJqGridDepositoClass");
	removeAttributeElementBySelector(".jqGridViaticoLinkClass", "onclick");
}

function callRegistrarRendicion() {
	
	setTimeout(function() {
		//JMCR-ME Hora < 4 Rendicion	
		if (getValueInputText("hidFlagMenorIgual4Horas") == "1") {
			enabledElement("etiquetaFechaHoraSalidaItinerarioEjecutado");
			enabledElement("etiquetaFechaHoraRetornoItinerarioEjecutado");
		}
		
		var fecSalidaEjecutada = getValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado");
		var fecRetornoEjecutada = getValueInputText("etiquetaFechaHoraRetornoItinerarioEjecutado");

		if (getValueInputText("hidFlagMenorIgual4Horas") == "1") {
			disabledElement("etiquetaFechaHoraSalidaItinerarioEjecutado");
			disabledElement("etiquetaFechaHoraRetornoItinerarioEjecutado");
		}		
		//JMCR-ME Hora < 4 Rendicion	
		
		$.ajax({
			url: contextPathUrl + "/registrarRendicion.htm?action=registrarRendicion",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codPlanViaje": getValueInputText("hidCodigoPlanViaje"),
				"fechaRegistroRendicion": getValueInputText("hidFechaRegistroRendicion"),
				//JMCR-ME Hora < 4 Rendicion	
				"fecSalidaEjecutada": fecSalidaEjecutada,
				"fecRetornoEjecutada": fecRetornoEjecutada,
				"horaSalidaEjecutada": getValueInputText("etiquetaHoraSalidaItinerarioEjecutado"),
				"horaRetornoEjecutada": getValueInputText("etiquetaHoraRetornoItinerarioEjecutado"),
				//JMCR-ME Hora < 4 Rendicion	
				"montoDevueltoComprobanteTotal": getValueInputText("hidMontoDevueltoComprobanteTotal"),
				"montoDevueltoVoucherRICTotal": getValueInputText("hidMontoDevueltoVoucherRICTotal"),
				"indicadorExteriorDDJJ": getValueInputText("selIndicadorDDJJ"),
				"indicadorMenorGasto": getValueInputText("selIndicadorDevolucionMenorGasto"),
				"tipoDestino": getValueInputText("hidTipoDestino"),
				"flagMenorIgual4Horas": getValueInputText("hidFlagMenorIgual4Horas"),
				"flagDeclaracion": getValueInputText("hidFlagDeclaracion"),
				"numeroDeclaracionViatico": getValueInputText("hidNumeroDeclaracionViatico"),
				"montoDeclaracionTotal": getValueInputText("hidMontoDeclaracionTotal"),
				"montoDeclaracionViatico": getValueInputText("hidMontoDeclaracionViatico"),
				"montoAsignadoTotal": getValueInputText("hidMontoRendirTotal"),
				"montoAsignacionViatico": getValueInputText("hidMontoAsignacionViatico"),
				"simboloMoneda": getValueInputText("hidMoneda"),
				"codigoRegistrador": getValueInputText("hidCodigoRegistrador"),
				"codigoSedeRegistrador": getValueInputText("hidCodigoSedeRegistrador")
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showModalElement("divMensajeConfirmacionLoadingRegistrarModificarRendicion");
			},
			complete: function() {
				hideModalElement("divMensajeConfirmacionLoadingRegistrarModificarRendicion");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var codigoOperacion = result.codigoOperacion;
				var flagHabilitarCerrarRendicion = result.flagHabilitarCerrarRendicion;
				var errorMessage = result.errorMessage;
				var successMessage = result.successMessage;
				if (codigoOperacion != null && codigoOperacion == "00") {
					setValueInputText("hidFechaSalidaEjecutada", getValueInputText("etiquetaFechaHoraSalidaItinerarioEjecutado"));
					setValueInputText("hidFechaRetornoEjecutada", getValueInputText("etiquetaFechaHoraRetornoItinerarioEjecutado"));
					//JMCR-ME Hora < 4 Rendicion	
					setValueInputText("hidHoraSalidaEjecutada", getValueInputText("etiquetaHoraSalidaItinerarioEjecutado"));
					setValueInputText("hidHoraRetornoEjecutada", getValueInputText("etiquetaHoraRetornoItinerarioEjecutado"));
					//JMCR-ME Hora < 4 Rendicion	
					setValueInputText("hidIndicadorExteriorDDJJ", getValueInputSelect("selIndicadorDDJJ", "0"));
					setValueInputText("hidIndicadorMenorGasto", getValueInputSelect("selIndicadorDevolucionMenorGasto", "N"));
					setValueInputText("hidFlagHabilitarCerrarRendicion", flagHabilitarCerrarRendicion);
					showMensajeConfirmacionAplicativoWithoutBody("divMensajeConfirmacionRegistrarModificarRendicion", "divTituloPanelMensajeConfirmacionRegistrarModificarRendicion", "divBodyPanelMensajeConfirmacionRegistrarModificarRendicion", successMessage);
					habilitarDeshabilitarCerrarRendicion();
					callObtenerComprobantesAsignacionesPapeletasRics();
				}
				else {
					showMensajeConfirmacionAplicativoWithoutBody("divMensajeConfirmacionErrorRegistrarModificarRendicion", "divTituloPanelMensajeConfirmacionErrorRegistrarModificarRendicion", "divBodyPanelMensajeConfirmacionErrorRegistrarModificarRendicion", errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callRegistrarRendicion");
			}
		});
	}, 500);
}

function callCerrarRendicion() {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/registrarRendicion.htm?action=cerrarRendicion",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codPlanViaje": getValueInputText("hidCodigoPlanViaje"),
				"flagHabilitarCerrarRendicion": getValueInputText("hidFlagHabilitarCerrarRendicion"),
				"flagCVRHabilitarCerrarRendicion": getValueInputText("hidFlagCVRHabilitarCerrarRendicion"),
				"flagRegistroComprobante": getValueInputText("hidFlagRegistroComprobante"),
				"flagRegistroVoucher": getValueInputText("hidFlagRegistroVoucher"),
				"flagRegistroRIC": getValueInputText("hidFlagRegistroRIC"),
				"montoDevueltoComprobanteTotal": getValueInputText("hidMontoDevueltoComprobanteTotal"),
				"montoDevueltoVoucherRICTotal": getValueInputText("hidMontoDevueltoVoucherRICTotal"),
				"codigoRegistrador": getValueInputText("hidCodigoRegistrador"),
				"codigoSedeRegistrador": getValueInputText("hidCodigoSedeRegistrador")
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showModalElement("divMensajeConfirmacionLoadingRegistrarModificarRendicion");
			},
			complete: function() {
				hideModalElement("divMensajeConfirmacionLoadingRegistrarModificarRendicion");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var codigoOperacion = result.codigoOperacion;
				var errorMessage = result.errorMessage;
				var successMessage = result.successMessage;
				if (codigoOperacion != null && codigoOperacion == "00") {
					var descripcionEstadoRendicion = result.descripcionEstadoRendicion;
					setValueInputText("txtEstado", descripcionEstadoRendicion);
					showMensajeConfirmacionAplicativoWithoutBody("divMensajeConfirmacionRegistrarModificarRendicion", "divTituloPanelMensajeConfirmacionRegistrarModificarRendicion", "divBodyPanelMensajeConfirmacionRegistrarModificarRendicion", successMessage);
					habilitarDeshabilitarComponentesRendicionCerrada();
				}
				else {
					showMensajeConfirmacionAplicativoWithoutBody("divMensajeConfirmacionErrorRegistrarModificarRendicion", "divTituloPanelMensajeConfirmacionErrorRegistrarModificarRendicion", "divBodyPanelMensajeConfirmacionErrorRegistrarModificarRendicion", errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callCerrarRendicion");
			}
		});
	}, 500);
}

function callObtenerComprobantesAsignacionesPapeletasRics() {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/registrarRendicion.htm?action=obtenerComprobantesAsignacionesPapeletasRics",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codigoPlanViaje": getValueInputText("hidCodigoPlanViaje"),
				"montoRendirTotal": getValueInputText("hidMontoRendirTotal"),
				"simboloMoneda": getValueInputText("hidMoneda"),
				"indicadorMenorGasto": getValueInputText("selIndicadorDevolucionMenorGasto")
			},
			beforeSend: function() {
				/*
				showModalElement("divScreenBlock");
				showModalElement("divMensajeConfirmacionLoadingRegistrarModificarRendicion");
				*/
			},
			complete: function() {
				/*
				hideModalElement("divMensajeConfirmacionLoadingRegistrarModificarRendicion");
				hideModalElement("divScreenBlock");
				*/
			},
			success: function(result) {
				var codigoConsulta = result.codigoConsulta;
				var errorMessage = result.errorMessage;
				if (codigoConsulta != null && codigoConsulta == "00") {
					var rendicionVO = result.rendicionVO;
					var planViajeRendicionList = rendicionVO.planViajeRendicionList;
					var planViajeConceptoList = rendicionVO.planViajeConceptoList;
					var papeletaDepositoList = rendicionVO.papeletaDepositoList;
					var comprobanteIngresoList = rendicionVO.comprobanteIngresoList;
					var flagCVRHabilitarCerrarRendicion = rendicionVO.flagCVRHabilitarCerrarRendicion;
					setValueInputText("hidFlagCVRHabilitarCerrarRendicion", flagCVRHabilitarCerrarRendicion);
					habilitarDeshabilitarCerrarRendicion();
					actualizarMontosRegistrarModificarRendicion(rendicionVO);
					showComprobantesRegistrarModificarRendicion(planViajeRendicionList);
					showAsignacionConceptoRegistrarModificarRendicion(planViajeConceptoList);
					
					if (getValueInputText("hidCodigoCanalAtencion") == "R") {
						showPapeletasDepositoRegistrarModificarRendicion(papeletaDepositoList);
						if (getValueInputText("hidFlagAsociadoRIC") == "1") {
							showRecibosIngresoCaja(comprobanteIngresoList);
						}
					}
					if (getValueInputText("hidCodigoEstadoRendicion") == "02") {
						habilitarDeshabilitarComponentesRendicionCerrada();
					}
				}
				else {
					showMensajeConfirmacionAplicativoWithoutBody("divMensajeConfirmacionErrorRegistrarModificarRendicion", "divTituloPanelMensajeConfirmacionErrorRegistrarModificarRendicion", "divBodyPanelMensajeConfirmacionErrorRegistrarModificarRendicion", errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callObtenerComprobantesAsignacionesPapeletasRics");
			}
		});
	}, 500);
}

function callEliminarComprobante() {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/registroGeneral.htm?action=eliminarComprobante",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"planViajeId": getValueInputText("hidCodigoPlanViaje"),
				"secuencial": getValueInputText("hidSecuencialEliminarComprobanteRegistrarModificarRendicion"),
				"conceptoId": getValueInputText("hidConceptoIdEliminarComprobanteRegistrarModificarRendicion"),
				"mtoReconocido": getValueInputText("hidMtoReconocidoEliminarComprobanteRegistrarModificarRendicion"),
				"codigoPaginaCaller": getValueInputText("hidCodigoPaginaCaller")
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showModalElement("divMensajeConfirmacionLoadingRegistrarModificarRendicion");
			},
			complete: function() {
				hideModalElement("divMensajeConfirmacionLoadingRegistrarModificarRendicion");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var codigoOperacion = result.codigoOperacion;
				var errorMessage = result.errorMessage;
				var successMessage = result.successMessage;
				if (codigoOperacion != null && codigoOperacion == "00") {
					setValueInputText("hidSecuencialEliminarComprobanteRegistrarModificarRendicion", "");
					setValueInputText("hidConceptoIdEliminarComprobanteRegistrarModificarRendicion", "");
					setValueInputText("hidMtoReconocidoEliminarComprobanteRegistrarModificarRendicion", "");
					setValueInputText("hidFlagHabilitarCerrarRendicion", "0");
					showMensajeConfirmacionAplicativoWithoutBody("divMensajeConfirmacionRegistrarModificarRendicion", "divTituloPanelMensajeConfirmacionRegistrarModificarRendicion", "divBodyPanelMensajeConfirmacionRegistrarModificarRendicion", successMessage);
					callObtenerComprobantesAsignacionesPapeletasRics();
				}
				else {
					showMensajeConfirmacionAplicativoWithoutBody("divMensajeConfirmacionErrorRegistrarModificarRendicion", "divTituloPanelMensajeConfirmacionErrorRegistrarModificarRendicion", "divBodyPanelMensajeConfirmacionErrorRegistrarModificarRendicion", errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callEliminarComprobante");
			}
		});
	}, 500);
}

function callDesasociarPapeletaDeposito() {
	
	setTimeout(function() {
		$.ajax({
			url: contextPathUrl + "/registrarRendicion.htm?action=desasociarPapeletaDeposito",
			type: "post",
			dataType: "json",
			cache: false,
			data: {
				"codigoBoletaDeposito": getValueInputText("hidValueRadioButtonJqGridDeposito"),
				"codigoPlanViaje": getValueInputText("hidCodigoPlanViaje"),
				"montoDeposito": getValueInputText("hidMontoDepositoJqGridDeposito"),
				"tipoDestino": getValueInputText("hidTipoDestino")
			},
			beforeSend: function() {
				showModalElement("divScreenBlock");
				showModalElement("divMensajeConfirmacionLoadingRegistrarModificarRendicion");
			},
			complete: function() {
				hideModalElement("divMensajeConfirmacionLoadingRegistrarModificarRendicion");
				hideModalElement("divScreenBlock");
			},
			success: function(result) {
				var codigoOperacion = result.codigoOperacion;
				var errorMessage = result.errorMessage;
				var successMessage = result.successMessage;
				if (codigoOperacion != null && codigoOperacion == "00") {
					setValueInputText("hidValueRadioButtonJqGridDeposito", "");
					showMensajeConfirmacionAplicativoWithoutBody("divMensajeConfirmacionRegistrarModificarRendicion", "divTituloPanelMensajeConfirmacionRegistrarModificarRendicion", "divBodyPanelMensajeConfirmacionRegistrarModificarRendicion", successMessage);
					setValueInputText("hidFlagHabilitarCerrarRendicion", "0");
					callObtenerComprobantesAsignacionesPapeletasRics();
				}
				else {
					showMensajeConfirmacionAplicativoWithoutBody("divMensajeConfirmacionErrorRegistrarModificarRendicion", "divTituloPanelMensajeConfirmacionErrorRegistrarModificarRendicion", "divBodyPanelMensajeConfirmacionErrorRegistrarModificarRendicion", errorMessage);
				}
			},
			error: function() {
				consoleLog("Error callObtenerPapeletasDeposito");
			}
		});
	}, 500);
}

function actualizarMontosRegistrarModificarRendicion(rendicionVO) {
	
	setValueInputText("hidMontoComprobanteTotal", rendicionVO.montoComprobanteTotal);
	setValueInputText("hidMontoDeclaracionTotal", rendicionVO.montoDeclaracionTotal);
	setValueInputText("hidMontoDeclaracionViatico", rendicionVO.montoDeclaracionViatico);
	setValueInputText("hidMontoDepositoTotal", rendicionVO.montoDepositoTotal);
	setValueInputText("hidMontoRICTotal", rendicionVO.montoRICTotal);
	setValueInputText("hidMontoDevolver", rendicionVO.montoDevolver);
	setValueInputText("hidMontoDevueltoComprobanteTotal", rendicionVO.montoDevueltoComprobanteTotal);
	setValueInputText("hidMontoDevueltoVoucherRICTotal", rendicionVO.montoDevueltoVoucherRICTotal);
	setValueInputText("hidMontoComprobanteTotalFormateado", rendicionVO.montoComprobanteTotalFormateado);
	setValueInputText("hidMontoDeclaracionTotalFormateado", rendicionVO.montoDeclaracionTotalFormateado);
	setValueInputText("hidMontoDeclaracionViaticoFormateado", rendicionVO.montoDeclaracionViaticoFormateado);
	setValueInputText("hidMontoDepositoTotalFormateado", rendicionVO.montoDepositoTotalFormateado);
	setValueInputText("hidMontoRICTotalFormateado", rendicionVO.montoRICTotalFormateado);
	setValueInputText("hidMontoDevolverFormateado", rendicionVO.montoDevolverFormateado);
	setValueInputText("hidFlagDeclaracion", rendicionVO.flagDeclaracion);
	setValueInputText("hidNumeroDeclaracionViatico", rendicionVO.numeroDeclaracionViatico);
}

function showComprobantesRegistrarModificarRendicion(planViajeRendicionArray) {
	
	var comprobanteTable = $("#tblComprobante");
	comprobanteTable.clearGridData();
	if (planViajeRendicionArray != null && planViajeRendicionArray.length > 0) {
		setValueInputText("hidFlagRegistroComprobante", "1");
		for (var i = 0; i < planViajeRendicionArray.length; i++) {
			var comprobante = planViajeRendicionArray[i];
			var identificador = i + 1;
			if (comprobante.flagRendicionTotal == "1") {
				identificador = "";
			}
			var datarow = {
				planViajeId: comprobante.planViajeId,
				secuencial: comprobante.secuencial,
				conceptoId: comprobante.conceptoId,
				columna01: "",
				identificador: identificador,
				tipoDocumento: comprobante.tipoDocumento,
				descripcionTipoDocumento: comprobante.descripcionTipoDocumento,
				serie: comprobante.serie,
				numeroDocumento: comprobante.numeroDocumento,
				fechaDocumento: comprobante.fechaDocumentoFormateada,
				nombreRazonSocial: comprobante.nombreRazonSocial,
				montoTotal: comprobante.montoTotal,
				montoTotalFormateado: comprobante.montoTotalFormateado,
				mtoReconocido: comprobante.mtoReconocido,
				mtoReconocidoFormateado: comprobante.mtoReconocidoFormateado,
				flagRendicionTotal: comprobante.flagRendicionTotal,
				accion: comprobante.secuencial
			};
			comprobanteTable.jqGrid("addRowData", datarow.secuencial, datarow);
		}
		comprobanteTable.trigger("reloadGrid");
	}
	else {
		setValueInputText("hidFlagRegistroComprobante", "0");
	}
}

function showAsignacionConceptoRegistrarModificarRendicion(planViajeConceptoArray) {
	
	var rendicionTable = $("#tblRendicion");
	rendicionTable.clearGridData();
	if (planViajeConceptoArray != null && planViajeConceptoArray.length > 0) {
		for (var i = 0; i < planViajeConceptoArray.length; i++) {
			var asignacionConcepto = planViajeConceptoArray[i];
			if (i == 0) {
				//Nota asignacionConcepto.monto, no tiene valor para la ultima fila
				setValueInputText("hidMontoAsignacionViatico", asignacionConcepto.monto);
				setValueInputText("hidMontoAsignacionViaticoFormateado", asignacionConcepto.montoFormateado);
			}
			var identificador = i + 1;
			var datarow = {
				planViajeID: asignacionConcepto.planViajeID,
				secuencial: identificador,
				conceptoID: asignacionConcepto.conceptoID,
				descripcionConcepto: asignacionConcepto.descripcionConcepto,
				monto: asignacionConcepto.montoFormateado,
				montoRendido: asignacionConcepto.montoRendidoFormateado==null?"0.00":asignacionConcepto.montoRendidoFormateado,
				montoDevolver: asignacionConcepto.montoDevolverFormateado,
				montoDevueltoVoucherRIC: asignacionConcepto.montoDevueltoVoucherRICFormateado,
				flagMontoDevolverNegativo: asignacionConcepto.flagMontoDevolverNegativo,
				flagPlanViajeConceptoTotal: asignacionConcepto.flagPlanViajeConceptoTotal
			};
			rendicionTable.jqGrid("addRowData", datarow.secuencial, datarow);
		}
		rendicionTable.trigger("reloadGrid");
	}
}

function showPapeletasDepositoRegistrarModificarRendicion(papeletaDepositoArray) {
	
	var depositoTable = $("#tblDeposito");
	depositoTable.clearGridData();
	if (papeletaDepositoArray != null && papeletaDepositoArray.length > 0) {
		setValueInputText("hidFlagRegistroVoucher", "1");
		for (var i = 0; i < papeletaDepositoArray.length; i++) {
			var papeleta = papeletaDepositoArray[i];
			var datarow = {
				codigoBoletaDeposito: papeleta.codigoBoletaDeposito,
				nombreBanco: papeleta.nombreBanco,
				numeroCuentaBanco: papeleta.numeroCuentaBanco,
				fechaVoucher: papeleta.fechaVoucher,
				numeroOperacion: papeleta.numeroOperacion,
				valorTipoCambio: papeleta.valorTipoCambioFormateado,
				montoDeposito: papeleta.montoDeposito,
				montoDepositoFormateado: papeleta.montoDepositoFormateado,
				reciboIngresoCajaAsosiado: papeleta.reciboIngresoCajaAsosiado,
				flagAsociadoRIC: papeleta.flagAsociadoRIC,
				flagPapeletaTotal: papeleta.flagPapeletaTotal,
				eliminar: papeleta.codigoBoletaDeposito
			};
			depositoTable.jqGrid("addRowData", datarow.codigoBoletaDeposito, datarow);
		}
		depositoTable.trigger("reloadGrid");
	}
	else {
		setValueInputText("hidFlagRegistroVoucher", "0");
	}
}

function showRecibosIngresoCaja(comprobanteIngresoArray) {
	
	var ricTable = $("#tblRIC");
	ricTable.clearGridData();
	if (comprobanteIngresoArray != null && comprobanteIngresoArray.length > 0) {
		setValueInputText("hidFlagRegistroRIC", "1");
		for (var i = 0; i < comprobanteIngresoArray.length; i++) {
			var comprobante = comprobanteIngresoArray[i];
			var secuenciaRIC = i + 1;
			var datarow = {
				secuenciaRIC: secuenciaRIC,
				numeroDocumento: comprobante.numeroDocumento,
				fechaGeneracion: comprobante.fechaGeneracionFormateada,
				monto: comprobante.monto,
				montoFormateado: comprobante.montoFormateado,
				clasificador: comprobante.clasificador,
				flagComprobanteTotal: comprobante.flagComprobanteTotal,
				observacion: comprobante.observacion
			};
			ricTable.jqGrid("addRowData", datarow.secuenciaRIC, datarow);
		}
		ricTable.trigger("reloadGrid");
	}
	else {
		setValueInputText("hidFlagRegistroRIC", "0");
	}
}

function showMessageErrorFechaSalidaRegistrarModificarRendicion(errorMessage) {
	setHtmlElement("etiquetaErrorFechaSalidaDatosGeneralesRegistrarModificarRendicion", errorMessage);
	showElement("divErrorFechaSalidaDatosGeneralesRegistrarModificarRendicion");
}

function showMessageErrorFechaRetornoRegistrarModificarRendicion(errorMessage) {
	setHtmlElement("etiquetaErrorFechaRetornoDatosGeneralesRegistrarModificarRendicion", errorMessage);
	showElement("divErrorFechaRetornoDatosGeneralesRegistrarModificarRendicion");
}

function showMensajeConfirmacionAplicativoWithoutBody(idDivModalMessage, idDivTituloPanelMessage, idDivBodyPanelMessage, messageTitulo) {
	hideElement(idDivBodyPanelMessage);
	setHtmlElement(idDivTituloPanelMessage, messageTitulo);
	showModalElement(idDivModalMessage);
}

function showMensajeConfirmacionAplicativoWithBody(idDivModalMessage, idDivTituloPanelMessage, idDivBodyPanelMessage, idEtiquetaMessage, messageTitulo, messageBody) {
	showElement(idDivBodyPanelMessage);
	setHtmlElement(idDivTituloPanelMessage, messageTitulo);
	setHtmlElement(idEtiquetaMessage, messageBody);
	showModalElement(idDivModalMessage);
}

/*Inicio Codigo - Reutilizacion comprobantePago*/
var comprobantePagoBeforeMethod = function() {
	
};

var comprobantePagoAfterMethod = function(codPlanViaje) {
	setValueInputText("hidFlagHabilitarCerrarRendicion", "0");
	callObtenerComprobantesAsignacionesPapeletasRics();
};

var comprobantePagoService = new ComprobantePagoService(comprobantePagoBeforeMethod, comprobantePagoAfterMethod);
/*Fin Codigo - Reutilizacion comprobantePago*/

/*Inicio Codigo - Reutilizacion adjuntarDocumento*/
var adjuntarDocumentoBeforeMethod = function() {
};

var adjuntarDocumentoAfterMethod = function(data) {
};

var adjuntarDocumentoService = new AdjuntarDocumentoService(adjuntarDocumentoBeforeMethod, adjuntarDocumentoAfterMethod);
/*Fin Codigo - Reutilizacion adjuntarDocumento*/

$(window).on("resize", function() {
	resizeTable("tblComprobante");
	resizeTable("tblRendicion");
	resizeTable("tblDeposito");
	resizeTable("tblRIC");
	//Inicializando las tablas de los modales
	resizeTable("tblVacaciones");
	resizeTable("tblCompensaciones");
	resizeTable("tblLicencias");
	resizeTable("tblDatosRendicion");
	resizeTable("tblDatosComprobantePago");
	resizeTable("tblAsignacionViatico");
	resizeTable("tblPasajeTasaEmbarque");
	resizeTable("tblArchivo");
});