function initElementsConsultarAsistencia() {
	setInitElementsConsultarAsistencia();
}

function setInitElementsConsultarAsistencia() {
	
	addEventElement("btnCerrarConsultarAsistencia", "click", clickBtnCerrarConsultarAsistencia);
}

function removeEventElementsConsultarAsistencia() {
	removeAllEventsElement("btnCerrarConsultarAsistencia");
}

function clickBtnCerrarConsultarAsistencia() {
	removeEventElementsConsultarAsistencia();
	$("#divConsultarAsistencia").modal("hide");
}