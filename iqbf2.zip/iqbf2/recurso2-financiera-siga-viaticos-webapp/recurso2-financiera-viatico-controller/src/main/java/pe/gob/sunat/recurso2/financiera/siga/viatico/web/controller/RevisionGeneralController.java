package pe.gob.sunat.recurso2.financiera.siga.viatico.web.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;

import pe.gob.sunat.recurso2.administracion.siga.util.FormatoUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.SolicitudDTO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.reembolso.service.RegistroReembolsoService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.reembolso.service.RevisionReembolsoService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoConsultaService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoMensajeriaService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.service.RegistroSolicitudService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.service.RevisionSolicitudService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ReembolsoConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ResourceBundleUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.SolicitudConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;

/**
 * Controller que contiene los metodos generales de una revision de documento.
 * 
 * @author Jorge Ponce.
 */
public class RevisionGeneralController extends BaseController {

	protected final Log log = LogFactory.getLog(getClass());
	private RevisionSolicitudService revisionSolicitudService;
	private RevisionReembolsoService revisionReembolsoService;
	private ViaticoConsultaService viaticoConsultaService;
	private ViaticoMensajeriaService viaticoMensajeriaService;
	private RegistroSolicitudService registroSolicitudService;
	private RegistroReembolsoService registroReembolsoService;
	
	public RevisionSolicitudService getRevisionSolicitudService() {
		return revisionSolicitudService;
	}

	public void setRevisionSolicitudService(RevisionSolicitudService revisionSolicitudService) {
		this.revisionSolicitudService = revisionSolicitudService;
	}

	public RevisionReembolsoService getRevisionReembolsoService() {
		return revisionReembolsoService;
	}

	public void setRevisionReembolsoService(RevisionReembolsoService revisionReembolsoService) {
		this.revisionReembolsoService = revisionReembolsoService;
	}

	public ViaticoConsultaService getViaticoConsultaService() {
		return viaticoConsultaService;
	}

	public void setViaticoConsultaService(ViaticoConsultaService viaticoConsultaService) {
		this.viaticoConsultaService = viaticoConsultaService;
	}

	public ViaticoMensajeriaService getViaticoMensajeriaService() {
		return viaticoMensajeriaService;
	}

	public void setViaticoMensajeriaService(ViaticoMensajeriaService viaticoMensajeriaService) {
		this.viaticoMensajeriaService = viaticoMensajeriaService;
	}

	public RegistroSolicitudService getRegistroSolicitudService() {
		return registroSolicitudService;
	}

	public void setRegistroSolicitudService(RegistroSolicitudService registroSolicitudService) {
		this.registroSolicitudService = registroSolicitudService;
	}

	public RegistroReembolsoService getRegistroReembolsoService() {
		return registroReembolsoService;
	}

	public void setRegistroReembolsoService(
			RegistroReembolsoService registroReembolsoService) {
		this.registroReembolsoService = registroReembolsoService;
	}

	/**
	 * Metodo que permite observar un documento.
	 * 
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	public ModelAndView observarDocumento(HttpServletRequest request, HttpServletResponse response) {

		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoOperacion = SolicitudConstantes.ERROR_OPERACION;
		String errorMessage = SolicitudConstantes.CADENA_VACIA;

		try {
			log.debug(RevisionGeneralController.class.getSimpleName() + ".observarDocumento");
			String codPlanViaje = request.getParameter("codPlanViaje");
			String observacionAutorizador = request.getParameter("observacionAutorizador");
			String codPerAutoriza = request.getParameter("codPerAutoriza");
			String codigoSedeAutorizador = request.getParameter("codigoSedeAutorizador");
			String expedientePlanViaje = request.getParameter("expedientePlanViaje");
			String codigoPaginaCaller = request.getParameter("codigoPaginaCaller");
			codPlanViaje = FormatoUtil.validarEmptyToNull(codPlanViaje);
			codigoPaginaCaller = FormatoUtil.validarEmptyToNull(codigoPaginaCaller);

			if (codPlanViaje != null && codigoPaginaCaller != null) {
				setAuditoriaBeanHolder(request, response);
				if (ViaticoConstantes.PAGE_CALLER_BANDEJA_SOLICITUD_AUTORIZADOR.equals(codigoPaginaCaller)) {
					codigoOperacion = revisionSolicitudService.observarSolicitud(codPlanViaje, observacionAutorizador, codPerAutoriza, codigoSedeAutorizador, expedientePlanViaje);
					if (SolicitudConstantes.EXITO_OPERACION.equals(codigoOperacion)) {
						SolicitudDTO solicitudDTO = viaticoConsultaService.obtenerPlanViajeToNotificacion(codPlanViaje);
						viaticoMensajeriaService.enviarNotificacionObservacionSolicitud(solicitudDTO);
					}
				}
				else if (ViaticoConstantes.PAGE_CALLER_BANDEJA_REEMBOLSO_AUTORIZADOR.equals(codigoPaginaCaller)) {
					codigoOperacion = revisionReembolsoService.observarReembolso(codPlanViaje, observacionAutorizador, codPerAutoriza, codigoSedeAutorizador, expedientePlanViaje);
					if (ReembolsoConstantes.EXITO_OPERACION.equals(codigoOperacion)) {
						/*Enviar Notificacion*/
						SolicitudDTO solicitudDTO = viaticoConsultaService.obtenerPlanViajeToNotificacion(codPlanViaje);
						viaticoMensajeriaService.enviarObservacionSolicitudReembolso(solicitudDTO);
					}
				}
			}
			log.debug(RevisionGeneralController.class.getSimpleName() + ".observarDocumento.fin");

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			errorMessage = ResourceBundleUtil.getMessage(SolicitudConstantes.MENSAJE_ERROR_GENERICO);
		}

		respuesta.put("codigoOperacion", codigoOperacion);
		respuesta.put("errorMessage", errorMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}

	/**
	 * Metodo que permite anular un documento.
	 * 
	 * @author Jorge Ponce.
	 * @param request: objeto de la clase HttpServletRequest.
	 * @param response: objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	public ModelAndView anularDocumento(HttpServletRequest request, HttpServletResponse response) {

		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoOperacion = SolicitudConstantes.ERROR_OPERACION;
		String errorMessage = SolicitudConstantes.CADENA_VACIA;

		try {
			log.debug(RevisionGeneralController.class.getSimpleName() + ".anularDocumento");
			String codPlanViaje = request.getParameter("codPlanViaje");
			String codigoPlanilla = request.getParameter("codigoPlanilla");
			String observacionAnulacion = request.getParameter("observacionAnulacion");
			String expedientePlanViaje = request.getParameter("expedientePlanViaje");
			String codigoPaginaCaller = request.getParameter("codigoPaginaCaller");
			codPlanViaje = FormatoUtil.validarEmptyToNull(codPlanViaje);
			codigoPlanilla = FormatoUtil.validarEmptyToNull(codigoPlanilla);
			codigoPaginaCaller = FormatoUtil.validarEmptyToNull(codigoPaginaCaller);

			if ((codPlanViaje != null || codigoPlanilla != null) && codigoPaginaCaller != null) {
				
				setAuditoriaBeanHolder(request, response);
				
				if (ViaticoConstantes.PAGE_CALLER_BANDEJA_SOLICITUD_AUTORIZADOR.equals(codigoPaginaCaller)) {
					
					String codigoColaborador = request.getParameter("codigoColaborador");
					String codigoSedeColaborador = request.getParameter("codigoSedeColaborador");
					codigoOperacion = revisionSolicitudService.anularSolicitud(codPlanViaje, observacionAnulacion, codigoColaborador, codigoSedeColaborador, expedientePlanViaje);
					if (SolicitudConstantes.EXITO_OPERACION.equals(codigoOperacion)) {
						SolicitudDTO solicitudDTO = viaticoConsultaService.obtenerPlanViajeToNotificacion(codPlanViaje);
						viaticoMensajeriaService.enviarNotificacionAnulacionSolicitud(solicitudDTO);
					}
				}
				else if (ViaticoConstantes.PAGE_CALLER_BANDEJA_SOLICITUD_COLABORADOR.equals(codigoPaginaCaller)) {
					// PAGE_CALLER_BANDEJA_SOLICITUD_COLABORADOR: anular solicitud desde la bandeja - CUS09
					if (StringUtils.isBlank(expedientePlanViaje)) {
						// valida que tenga asociado un expediente
						codigoOperacion = SolicitudConstantes.ERROR_OPERACION_PLANILLA_NO_TIENE_EXPEDIENTE;
						errorMessage = ResourceBundleUtil.getMessage(SolicitudConstantes.MENSAJE_ERROR_ANULAR_DOCUMENTO_PLANILLA_NO_TIENE_EXPEDIENTE);
					} else {
						// datos del registrador (usuario en session)
						String codigoColaborador = StringUtils.trimToNull(request.getParameter("codigoColaborador"));
						// anular la solicitud
						codigoOperacion = registroSolicitudService.anularSolicitud(codPlanViaje, observacionAnulacion, expedientePlanViaje, codigoColaborador);
						// enviar notificacion
						if (StringUtils.equals(codigoOperacion, SolicitudConstantes.EXITO_OPERACION)) {
							SolicitudDTO solicitudDTO = viaticoConsultaService.obtenerPlanViajeToNotificacion(codPlanViaje);
							viaticoMensajeriaService.enviarAnulacionSolicitud(solicitudDTO);
						}
					}
				}
				else if (ViaticoConstantes.PAGE_CALLER_BANDEJA_REEMBOLSO_COLABORADOR.equals(codigoPaginaCaller)) {
					// PAGE_CALLER_BANDEJA_SOLICITUD_COLABORADOR: anular solicitud desde la bandeja - CUS09
					if (StringUtils.isBlank(expedientePlanViaje)) {
						// valida que tenga asociado un expediente
						codigoOperacion = SolicitudConstantes.ERROR_OPERACION_PLANILLA_NO_TIENE_EXPEDIENTE;
						errorMessage = ResourceBundleUtil.getMessage(SolicitudConstantes.MENSAJE_ERROR_ANULAR_DOCUMENTO_PLANILLA_NO_TIENE_EXPEDIENTE);
					} else {
						// datos del registrador (usuario en session)
						String codigoColaborador = StringUtils.trimToNull(request.getParameter("codigoColaborador"));
						// anular la solicitud
						codigoOperacion = registroReembolsoService.anularReembolsoRevision(codPlanViaje, observacionAnulacion, expedientePlanViaje, codigoColaborador);
						// enviar notificacion
						/*if (StringUtils.equals(codigoOperacion, SolicitudConstantes.EXITO_OPERACION)) {
							SolicitudDTO solicitudDTO = viaticoConsultaService.obtenerPlanViajeToNotificacion(codPlanViaje);
							viaticoMensajeriaService.enviarAnulacionSolicitud(solicitudDTO);
						}*/
					}
				}
				else if (ViaticoConstantes.PAGE_CALLER_BANDEJA_REEMBOLSO_AUTORIZADOR.equals(codigoPaginaCaller)) {
					String codigoColaborador = request.getParameter("codigoColaborador");
					String codigoSedeColaborador = request.getParameter("codigoSedeColaborador");
					codigoOperacion = revisionReembolsoService.anularReembolso(codPlanViaje, observacionAnulacion, codigoColaborador, codigoSedeColaborador, expedientePlanViaje);
					if (ReembolsoConstantes.EXITO_OPERACION.equals(codigoOperacion)) {
						/*Enviar Notificacion*/
						SolicitudDTO solicitudDTO = viaticoConsultaService.obtenerPlanViajeToNotificacion(codPlanViaje);
						viaticoMensajeriaService.enviarNotificacionAnulacionDeSolicitudDeReembolso(solicitudDTO);
					}
				}
			}
			log.debug(RevisionGeneralController.class.getSimpleName() + ".anularDocumento.fin");

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			errorMessage = ResourceBundleUtil.getMessage(SolicitudConstantes.MENSAJE_ERROR_GENERICO);
		}

		respuesta.put("codigoOperacion", codigoOperacion);
		respuesta.put("errorMessage", errorMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}

}
