package pe.gob.sunat.recurso2.financiera.siga.viatico.web.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.recurso2.administracion.siga.archivo.model.bean.RegistroArchivosFisicoBean;
import pe.gob.sunat.recurso2.administracion.siga.archivo.service.RegistroArchivosService;
import pe.gob.sunat.recurso2.administracion.siga.expediente.model.bean.ExpedienteInternoAccionBean;
import pe.gob.sunat.recurso2.administracion.siga.expediente.service.RegistroExpedienteService;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroGeneralService;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.administracion.siga.ubigeo.model.bean.TDepartamentosBean;
import pe.gob.sunat.recurso2.administracion.siga.ubigeo.model.bean.TProvinciasBean;
import pe.gob.sunat.recurso2.administracion.siga.util.FormatoUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.NumeroUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ConceptoPlanillaViaticosBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.CuentaCorrienteBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.LicenciaBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.MetasBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PapeletaDepositoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeRendicionBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.TXXX8LugarUbigeoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.TipoDocumentoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.VacacionBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dto.DocumentoSustentarioDTO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.rendicion.service.ConsultaRendicionService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoConsultaService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoGeneralService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.service.ConsultaSolicitudService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.RendicionConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ResourceBundleUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.view.DocumentoSustentarioVO;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

/**
 * Controller que contiene los metodos generales a usar en los diferentes CUS.
 * 
 * @author Juan Saccatoma.
 */
public class ConsultaGeneralController extends BaseController {

	protected final Log log = LogFactory.getLog(getClass());

	private RegistroGeneralService registroGeneralService;
	private ViaticoGeneralService viaticoGeneralService;
	private ViaticoConsultaService viaticoConsultaService;
	private ViaticoService viaticoService;
	private ConsultaSolicitudService consultaSolicitudService;
	private RegistroPersonalService registroPersonalService;
	private RegistroArchivosService registroArchivosService;
	private ConsultaRendicionService consultaRendicionService;
	private RegistroExpedienteService registroExpedienteService;
	
	public RegistroGeneralService getRegistroGeneralService() {
		return registroGeneralService;
	}

	public void setRegistroGeneralService(RegistroGeneralService registroGeneralService) {
		this.registroGeneralService = registroGeneralService;
	}

	public ViaticoGeneralService getViaticoGeneralService() {
		return viaticoGeneralService;
	}

	public void setViaticoGeneralService(ViaticoGeneralService viaticoGeneralService) {
		this.viaticoGeneralService = viaticoGeneralService;
	}

	public ViaticoConsultaService getViaticoConsultaService() {
		return viaticoConsultaService;
	}

	public void setViaticoConsultaService(ViaticoConsultaService viaticoConsultaService) {
		this.viaticoConsultaService = viaticoConsultaService;
	}

	public ViaticoService getViaticoService() {
		return viaticoService;
	}

	public void setViaticoService(ViaticoService viaticoService) {
		this.viaticoService = viaticoService;
	}

	public ConsultaSolicitudService getConsultaSolicitudService() {
		return consultaSolicitudService;
	}

	public void setConsultaSolicitudService(ConsultaSolicitudService consultaSolicitudService) {
		this.consultaSolicitudService = consultaSolicitudService;
	}

	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}

	public RegistroArchivosService getRegistroArchivosService() {
		return registroArchivosService;
	}

	public void setRegistroArchivosService(RegistroArchivosService registroArchivosService) {
		this.registroArchivosService = registroArchivosService;
	}

	public ConsultaRendicionService getConsultaRendicionService() {
		return consultaRendicionService;
	}

	public void setConsultaRendicionService(ConsultaRendicionService consultaRendicionService) {
		this.consultaRendicionService = consultaRendicionService;
	}

	public RegistroExpedienteService getRegistroExpedienteService() {
		return registroExpedienteService;
	}

	public void setRegistroExpedienteService(RegistroExpedienteService registroExpedienteService) {
		this.registroExpedienteService = registroExpedienteService;
	}

	/**
	 * Carga la Pagina de Login
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 */
	public ModelAndView mostrarLogin(HttpServletRequest request, HttpServletResponse response) {
		
		if (log.isDebugEnabled()) {
			log.debug("debug Inicio - ConsultaGeneralController.mostrarLogin");
		}
		try {
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			log.debug("Usuario" + usuarioBean.getLogin());
			log.debug("Registro" + usuarioBean.getNroRegistro());
			return new ModelAndView("general/login");
			
		} catch (ServiceException ex) {
			log.error("Error en ConsultaGeneralController.mostrarLogin: " + ex.getMessage(), ex);
			throw new ServiceException(this, ex);
			
		} finally {
			if (log.isDebugEnabled()) {
				log.debug("Fin - RqnpController.mostrarLogin");
			}
		}
	}

	/**
	 * Valida el Ingreso de Usuario y Carga la pagina de menú
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 */
	public ModelAndView iniciarSesion(HttpServletRequest request, HttpServletResponse response) {
		
		if (log.isDebugEnabled()) {
			log.debug("debug Inicio - RqnpController.iniciarSesion");
		}
		
		boolean is_ok = true;
		String tipo_error = "";

		try {
			String login = StringUtils.trimToEmpty(request.getParameter("username"));
			String clave = StringUtils.trimToEmpty(request.getParameter("password"));
			String errorMessageLogin = ViaticoConstantes.CADENA_VACIA;
			
			if ("".equals(login)) {
				is_ok = false;
				tipo_error = "01";
			} else if (!login.toUpperCase().equals(clave.toUpperCase())) {
				is_ok = false;
				tipo_error = "02";
			} else {
				login = login.trim();

				UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
				MaestroPersonalBean maestroPersonal = registroPersonalService.obtenerPersonaxRegistro(login);
				
				if (maestroPersonal != null) {
					usuarioBean.setLogin(login);
					usuarioBean.setApeMaterno(maestroPersonal.getApellido_materno());
					usuarioBean.setApePaterno(maestroPersonal.getApellido_paterno());
					usuarioBean.setNombres(maestroPersonal.getNombre());
					usuarioBean.setNombreCompleto(maestroPersonal.getNombre_completo());
					usuarioBean.setCodDepend(maestroPersonal.getCodigoDependencia());
					usuarioBean.setCodUO(maestroPersonal.getUuoo());
					usuarioBean.setNroRegistro(maestroPersonal.getNumero_registro());
					log.debug("registro: " + maestroPersonal.getNumero_registro());
					WebUtils.setSessionAttribute(request, "usuarioBean", usuarioBean);
					WebUtils.setSessionAttribute(request, "maestroPersonalBean", maestroPersonal);
					
				} else {
					is_ok = false;
					tipo_error = "03";
				}

			}
			
			if (is_ok) {
				return new ModelAndView("general/menu");
			} else {
				Exception ex = new Exception("");
				if ("01".equals(tipo_error)) {
					ex = new Exception("Ingrese Usuario.");
					errorMessageLogin = "Ingrese Usuario.";
				} else if ("02".equals(tipo_error)) {
					ex = new Exception("Usuario o Contraseña incorrecta.");
					errorMessageLogin = "Usuario o Contraseña incorrecta.";
				} else if ("03".equals(tipo_error)) {
					ex = new Exception("No existe los datos de personal.");
					errorMessageLogin = "No existe los datos de personal.";
				}
				request.setAttribute("showErrorMessage", "1");
				request.setAttribute("hideAccionMessage", "1");
				request.setAttribute("excepAttr", ex);
				request.setAttribute("errorMessageLogin", errorMessageLogin);
				return new ModelAndView("general/login");
			}
			
		} catch (ServiceException ex) {
			log.error("Error en RqnpController.iniciarSesion: " + ex.getMessage(), ex);
			throw new ServiceException(this, ex);
			
		} catch (Exception ex) {
			log.error("Error en RqnpController.iniciarSesion: " + ex.getMessage(), ex);
			throw new ServiceException(this, ex);
			
		} finally {
			if (log.isDebugEnabled()) {
				log.debug("Fin - RqnpController.iniciarSesion");
			}
		}
	}

	public ModelAndView menu(HttpServletRequest request, HttpServletResponse response) {
		return new ModelAndView("general/menu");
	}

	public ModelAndView obtenerLugaresByCodigo(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			log.debug(getClass().getName() + " Inicio del metodo obtenerLugaresByCodigo");

			String codigoDepartamento = StringUtils.trimToNull(request.getParameter("codigoDepartamento"));
			String codigoProvincia = StringUtils.trimToNull(request.getParameter("codigoProvincia"));

			List<TXXX8LugarUbigeoBean> lugarList = viaticoGeneralService.obtenerLugaresByCodigo(codigoDepartamento, codigoProvincia);

			respuesta.put("codigoLugar", StringUtils.EMPTY);
			respuesta.put("codigoUbigeo", StringUtils.EMPTY);

			if (CollectionUtils.isNotEmpty(lugarList)) {
				respuesta.put("codigoLugar", StringUtils.trimToEmpty(lugarList.get(0).getCodigoLugar()));
				respuesta.put("codigoUbigeo", StringUtils.trimToEmpty(lugarList.get(0).getCodigoUbigeo()));
			}

			respuesta.put("error", "no");
			respuesta.put("msgError", StringUtils.EMPTY);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {

			log.error(e.getMessage(), e);

			// INDICADORES QUE LA PETICION AJAX CULMINO CON ERRORES.
			// NOTA: El key msgError se usa como mensaje generico de error no manejable. 
			//       Otros keys del mapa respuesta se usan para personalizar los mensajes de negocio visibles al usuario.
			respuesta.put("error", "si");
			respuesta.put("msgError", ViaticoConstantes.MSG_ERROR_OPERACION_NO_EFECTUADA);

			modelAndView = new ModelAndView(getJsonView(), respuesta);
		}

		return modelAndView;
	}

	/**
	 * @author jponce
	 * @return Obtiene la lista de Lugares para el Ubigeo en JSon - Filtro: descripcion
	 * @throws Exception
	 */
	public ModelAndView obtenerLugaresByDescripcion(HttpServletRequest request, HttpServletResponse response) {

		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;

		try {

			log.debug(getClass().getName() + " Inicio del metodo obtenerLugaresByDescripcion");

			String codigoTipoBusqueda = request.getParameter("codigoTipoBusqueda");
			String descripcionDestino = request.getParameter("descripcionDestino");
			String indicadorBotonBuscar = request.getParameter("indicadorBotonBuscar");

			// parametros opcionales de punto de partida (para no incluirlo en los resultados)
			String puntoPartidaCodigoDepartamento = StringUtils.trimToEmpty(request.getParameter("puntoPartidaCodigoDepartamento"));
			String puntoPartidaCodigoProvincia = StringUtils.trimToEmpty(request.getParameter("puntoPartidaCodigoProvincia"));

			String descripcionDepartamento = null;
			String descripcionProvincia = null;
			String descripcionLugar = null;

			if (ViaticoConstantes.INDICADOR_BUSCAR_TD_INDIVIDUALMENTE.equals(indicadorBotonBuscar)) {

				descripcionDestino = StringUtils.trimToNull(descripcionDestino);
				if (ViaticoConstantes.CODIGO_TD_DEPARTAMENTO.equals(codigoTipoBusqueda)) {
					descripcionDepartamento = descripcionDestino;
				} else if (ViaticoConstantes.CODIGO_TD_PROVINCIA.equals(codigoTipoBusqueda)) {
					descripcionProvincia = descripcionDestino;
				} else if (ViaticoConstantes.CODIGO_TD_UBIGEO.equals(codigoTipoBusqueda)) {
					descripcionLugar = descripcionDestino;
				}
			}

			List<TXXX8LugarUbigeoBean> lugarList = viaticoGeneralService.obtenerLugaresByDescripcion(descripcionDepartamento, descripcionProvincia, descripcionLugar);

			if (CollectionUtils.isNotEmpty(lugarList)) {

				// filtrar el punto de partida (se escogio remover el item, antes de crear una nueva lista)
				if (StringUtils.isNotBlank(puntoPartidaCodigoDepartamento) && StringUtils.isNotBlank(puntoPartidaCodigoProvincia)) {

					List<TXXX8LugarUbigeoBean> lugarListFiltro = new ArrayList<TXXX8LugarUbigeoBean>(lugarList.size());

					for (TXXX8LugarUbigeoBean lugar : lugarList) {

						if (!(StringUtils.equals(lugar.getCodigoDepartamento(), puntoPartidaCodigoDepartamento) && StringUtils.equals(lugar.getCodigoProvincia(), puntoPartidaCodigoProvincia))) {

							lugarListFiltro.add(lugar);

						}

					}

					lugarList = lugarListFiltro;

				}
			}

			respuesta.put("lugarList", lugarList);

			viewPage = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}

		return viewPage;
	}

	/**
	 * @author jponce
	 * @return Obtiene el detalle completo del Lugar: Lista de Departamento, Provincia, Distrito, Lugar en JSon.
	 * @throws Exception
	 */
	public ModelAndView obtenerDetalleCompletoLugar(HttpServletRequest request, HttpServletResponse response) {

		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;

		try {

			log.debug(getClass().getName() + " Inicio del metodo obtenerDetalleCompletoLugar");

			String codigoDepartamento = StringUtils.trimToNull(request.getParameter("codigoDepartamento"));
			String codigoProvincia = StringUtils.trimToNull(request.getParameter("codigoProvincia"));

			ArrayList<TProvinciasBean> provinciaList = null;
			ArrayList<TDepartamentosBean> departamentoList = null;

			if (codigoDepartamento != null && codigoProvincia != null) {

				departamentoList = registroGeneralService.obtenerDepartamentos();
				if (departamentoList != null && !departamentoList.isEmpty()) {
					TDepartamentosBean tDepartamentosBean = new TDepartamentosBean();
					tDepartamentosBean.setCodiDepaDpt(ViaticoConstantes.CODIGO_00);
					tDepartamentosBean.setNombDptoDpt(ViaticoConstantes.SELECCIONE);
					departamentoList.add(0, tDepartamentosBean);
				}

				provinciaList = registroGeneralService.obtenerProvincias(codigoDepartamento);
				if (provinciaList != null && !provinciaList.isEmpty()) {
					TProvinciasBean tProvinciasBean = new TProvinciasBean();
					tProvinciasBean.setCodiProvTpr(ViaticoConstantes.CODIGO_00);
					tProvinciasBean.setNombProvTpr(ViaticoConstantes.SELECCIONE);
					provinciaList.add(0, tProvinciasBean);
				}

			}

			respuesta.put("departamentoList", departamentoList);
			respuesta.put("provinciaList", provinciaList);

			viewPage = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}

		return viewPage;
	}

	/**
	 * @author jponce
	 * @return Obtiene la lista de tipo de documentos para el registro de comprobantes de rendicion en JSon.
	 * @throws Exception
	 */
	public ModelAndView obtenerTipoDocumentoToComprobante(HttpServletRequest request, HttpServletResponse response) {
		log.debug(ConsultaGeneralController.class.getSimpleName() + ".obtenerTipoDocumentoToComprobante");
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		try {
			String idPlanViaje = request.getParameter("idPlanViaje");
			idPlanViaje = StringUtils.trimToNull(idPlanViaje);
			log.debug("idPlanViaje: " + idPlanViaje);
			List<TipoDocumentoBean> tipoDocumentoList = new ArrayList<TipoDocumentoBean>();
			List<TipoDocumentoBean> tipoDocumentoListAux = new ArrayList<TipoDocumentoBean>();
			PlanViajeBean planViaje = consultaSolicitudService.buscarPlanViaje(idPlanViaje);
			Integer inicio = ViaticoConstantes.CERO_INT;

			if (planViaje != null) {
				/*
				 * if(planViaje.getIndicadorExtDdjj().equals(ViaticoConstantes.UNO)){ tipoDocumentoList = viaticoGeneralService.obtenerTipoDocumentoToComprobante(); for(inicio = 0; inicio < tipoDocumentoList.size() ;inicio++){
				 * 
				 * if(tipoDocumentoList.get(inicio).getCodigoTipoDocumento().equals(ViaticoConstantes.TIPO_DOCUMENTO_DECLARACION_COMPROBANTE_PAGO) || tipoDocumentoList.get(inicio).getCodigoTipoDocumento().equals(ViaticoConstantes.TIPO_DOCUMENTO_DECLARACION_VIATICO)){
				 * tipoDocumentoListAux.add(tipoDocumentoList.get(inicio)); } if(planViaje.getTipoDestino().equals(ViaticoConstantes.TIPO_COMISION_INTERNACIONAL)){ if(tipoDocumentoList.get(inicio).getCodigoTipoDocumento().equals(ViaticoConstantes.TIPO_DOCUMENTO_COMPROBANTE_EXTERIOR))
				 * tipoDocumentoListAux.add(tipoDocumentoList.get(inicio));
				 * 
				 * } } } else
				 */

				// if(planViaje.getIndicadorExtDdjj().equals(ViaticoConstantes.CERO)){
				tipoDocumentoList = viaticoGeneralService.obtenerTipoDocumentoToComprobante();

				for (inicio = 0; inicio < tipoDocumentoList.size(); inicio++) {
					if (ViaticoConstantes.TIPO_COMISION_NACIONAL.equals(planViaje.getTipoDestino())) {
						if (!ViaticoConstantes.TIPO_DOCUMENTO_COMPROBANTE_EXTERIOR.equals(tipoDocumentoList.get(inicio).getCodigoTipoDocumento())) tipoDocumentoListAux.add(tipoDocumentoList.get(inicio));

					} else if (ViaticoConstantes.TIPO_COMISION_INTERNACIONAL.equals(planViaje.getTipoDestino())) {
						// if(tipoDocumentoList.get(inicio).getCodigoTipoDocumento().equals(ViaticoConstantes.TIPO_DOCUMENTO_COMPROBANTE_EXTERIOR))
						tipoDocumentoListAux.add(tipoDocumentoList.get(inicio));
					}
				}

				// }
			} else {
				tipoDocumentoListAux = null;
			}

			respuesta.put("tipoDocumentoList", tipoDocumentoListAux);

			viewPage = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {
			log.error("Error obtenerTipoDocumentoToComprobante", e);
		}

		return viewPage;
	}

	/**
	 * @author jponce
	 * @return Obtiene la lista de conceptos para el registro de comprobantes de rendicion en JSon.
	 * @throws Exception
	 */
	public ModelAndView obtenerConceptoPlanillaViaticosToComprobante(HttpServletRequest request, HttpServletResponse response) {

		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;

		try {
			log.debug(ConsultaGeneralController.class.getSimpleName() + ".obtenerConceptoPlanillaViaticosToComprobante");
			String idPlanViaje = request.getParameter("idPlanViaje");
			log.debug("idPlanViaje: " + idPlanViaje);
			idPlanViaje = ViaticoUtil.validarEmptyToNull(idPlanViaje);
			if (idPlanViaje != null) {
				ArrayList<ConceptoPlanillaViaticosBean> conceptoPlanillaViaticosList = viaticoService.obtenerConceptoPlanillaViaticosToComprobante(idPlanViaje);
				respuesta.put("conceptoPlanillaViaticosList", conceptoPlanillaViaticosList);
			}
			viewPage = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}

		return viewPage;
	}

	/**
	 * @return Obtiene la lista de conceptos de viaticos - Filtro: codigo y descripcion
	 * @throws Exception
	 */
	public ModelAndView obtenerConceptosByDescripcion(HttpServletRequest request, HttpServletResponse response) {

		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;

		try {

			log.debug(getClass().getName() + " Inicio del metodo obtenerConceptosByDescripcion");

			String codigoTipoBusqueda = request.getParameter("codigoTipoBusqueda");
			String filtro = request.getParameter("descripcionConceptoViatico");
			String indicadorBotonBuscar = request.getParameter("indicadorBotonBuscar");
			String nacionalInternacional = StringUtils.trimToNull(request.getParameter("nacionalInternacional")); // nacional, internacional, null

			// lista (opcional) de conceptos de viaticos (para no incluirlo en los resultados)
			String listaConceptosExcluirJSON = StringUtils.trimToEmpty(request.getParameter("listaConceptosExcluirJSON"));

			String codigo = null;
			String descripcion = null;

			if (ViaticoConstantes.BUSCAR_CONCEPTO_VIATICO_INDIVIDUALMENTE.equals(indicadorBotonBuscar)) {

				filtro = StringUtils.trimToNull(filtro);
				if (ViaticoConstantes.BUSCAR_CONCEPTO_VIATICO_CODIGO_CONCEPTO.equals(codigoTipoBusqueda)) {
					codigo = filtro;
				} else if (ViaticoConstantes.BUSCAR_CONCEPTO_VIATICO_NOMBRE_CONCEPTO.equals(codigoTipoBusqueda)) {
					descripcion = filtro;
				}
			}

			List<ConceptoPlanillaViaticosBean> conceptoList = null;

			if (StringUtils.equals(nacionalInternacional, ViaticoConstantes.BUSCAR_CONCEPTO_VIATICO_FILTRO_NACIONAL)) {

				// búsqueda conceptos nacionales
				conceptoList = viaticoService.obtenerConceptosViaticoNacional(codigo, descripcion);

			} else if (StringUtils.equals(nacionalInternacional, ViaticoConstantes.BUSCAR_CONCEPTO_VIATICO_FILTRO_INTERNACIONAL)) {

				// búsqueda conceptos internacionales
				conceptoList = viaticoService.obtenerConceptosViaticoInternacional(codigo, descripcion);

			} else {

				// búsqueda normal
				conceptoList = viaticoService.obtenerConceptosViatico(codigo, descripcion);
			}

			// si hay conceptos a excluir y hay items en la lista de conceptos resultante
			if (StringUtils.isNotBlank(listaConceptosExcluirJSON) && CollectionUtils.isNotEmpty(conceptoList)) {

				// lista de conceptos a excluir
				@SuppressWarnings("unchecked")
				List<String> listaConceptosExcluir = (List<String>) SojoUtil.fromJson(listaConceptosExcluirJSON);

				if (CollectionUtils.isNotEmpty(listaConceptosExcluir)) {

					// lista con filtro
					List<ConceptoPlanillaViaticosBean> conceptoListFiltro = new ArrayList<ConceptoPlanillaViaticosBean>(conceptoList.size());

					for (ConceptoPlanillaViaticosBean concepto : conceptoList) {

						// buscar el concepto en la lista de conceptos a excluir
						boolean existeEnListaExcluir = false;
						for (String conceptoExcluir : listaConceptosExcluir) {
							if (StringUtils.equals(concepto.getCodigoConcepto(), conceptoExcluir)) {
								existeEnListaExcluir = true;
								break;
							}
						}

						if (!existeEnListaExcluir) {
							conceptoListFiltro.add(concepto);
						}

					}

					// asignar la lista con filtros a la lista de conceptos resultantes
					conceptoList = conceptoListFiltro;

				}

			}

			respuesta.put("conceptoList", conceptoList);

			viewPage = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}

		return viewPage;
	}

	/**
	 * @return Obtiene las Metas (Cadena Presupuestal) en JSON
	 * @throws Exception
	 */
	public ModelAndView obtenerMetas(HttpServletRequest request, HttpServletResponse response) {

		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;

		try {

			log.debug(getClass().getName() + " Inicio del metodo obtenerMetas");

			String codigoDependencia = StringUtils.trimToNull(request.getParameter("codigoDependencia"));
			String ordenarPor = StringUtils.trimToNull(request.getParameter("ordenarPor"));

			List<MetasBean> metasList = null;
			if (codigoDependencia != null) {
				metasList = viaticoGeneralService.obtenerMetas(codigoDependencia, ViaticoUtil.formatDateToDateYYYY(new Date()), ordenarPor);
			}

			respuesta.put("metasList", metasList);
			viewPage = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}

		return viewPage;
	}

	/**
	 * @return Obtiene la lista de asistencia de un empleado en JSon - Filtro: Numero Registro, Fecha de Asistencia
	 * @throws Exception
	 */
	public ModelAndView obtenerAsistenciaEmpleado(HttpServletRequest request, HttpServletResponse response) {

		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;

		try {

			log.debug(getClass().getName() + " Inicio del metodo obtenerAsistenciaEmpleado");

			String numeroRegistro = StringUtils.trimToNull(request.getParameter("numeroRegistro"));
			String fechaInicial = StringUtils.trimToEmpty(request.getParameter("fechaInicial"));
			String fechaFinal = StringUtils.trimToEmpty(request.getParameter("fechaFinal"));

			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

			// parametros de la busqueda
			Map<String, Object> params = new HashMap<String, Object>();

			params.put("est_id", ViaticoConstantes.ACTIVO);
			params.put("numeroRegistro", numeroRegistro);

			if (FechaBean.validaFormato(fechaInicial, FechaBean.FORMATO_DEFAULT)) {
				params.put("fechaInicial", sdf.parse(fechaInicial));
			}
			if (FechaBean.validaFormato(fechaFinal, FechaBean.FORMATO_DEFAULT)) {
				params.put("fechaFinal", sdf.parse(fechaFinal));
			}

			List<VacacionBean> vacacionList = viaticoGeneralService.listarVacaciones(params);
			List<LicenciaBean> compensacionList = viaticoGeneralService.listarCompensacion(params);
			List<LicenciaBean> licenciaList = viaticoGeneralService.listarLicencias(params);

			respuesta.put("vacacionList", vacacionList);
			respuesta.put("compensacionList", compensacionList);
			respuesta.put("licenciaList", licenciaList);

			viewPage = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}

		return viewPage;
	}

	/**
	 * Metodo que permite obtener las cuentas corriente.
	 * 
	 * @author Jorge Ponce
	 * @param request: objeto de la clase HttpServletRequest.
	 * @param response: objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView)
	 * @see ModelAndView
	 */
	public ModelAndView obtenerCuentasCorriente(HttpServletRequest request, HttpServletResponse response) {

		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;

		try {
			log.debug(ConsultaGeneralController.class.getSimpleName() + ".obtenerCuentaCorriente");
			ArrayList<CuentaCorrienteBean> cuentaCorrienteList = null;
			String tipoDestino = request.getParameter("tipoDestino");
			tipoDestino = FormatoUtil.validarEmptyToNull(tipoDestino);

			if (tipoDestino != null) {
				cuentaCorrienteList = viaticoGeneralService.obtenerCuentasCorriente(tipoDestino);
			}

			respuesta.put("cuentaCorrienteList", cuentaCorrienteList);
			viewPage = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}

		return viewPage;
	}

	/**
	 * Metodo que permite obtener los datos del documento de sustentatorio.
	 * 
	 * @author Samuel Dionisio
	 * @param request: objeto de la clase HttpServletRequest.
	 * @param response: objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView)
	 * @see ModelAndView
	 */
	public ModelAndView obtenerDocumentoSustentario(HttpServletRequest request, HttpServletResponse response) {
		log.debug(getClass().getName() + " Inicio del metodo obtenerDatosGatos");
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		boolean estadoDocumentoSustentario = false;
		String mensajeRespuesta = RendicionConstantes.CADENA_VACIA;
		DocumentoSustentarioVO documentoSustentarioVO = new DocumentoSustentarioVO();
		try {
			String planViajeId = request.getParameter("idPlanViaje");
			planViajeId = FormatoUtil.validarEmptyToNull(planViajeId);
			String secuencia = request.getParameter("secuencia");
			secuencia = FormatoUtil.validarEmptyToNull(secuencia);
			
			if (planViajeId != null) {
				mensajeRespuesta = "OK";
				DocumentoSustentarioDTO documentoSustentarioDto = viaticoConsultaService.obtenerDocumentoSustentario(planViajeId, secuencia);
				estadoDocumentoSustentario = documentoSustentarioDto.isEstadoDocumentoSustentario();

				if (estadoDocumentoSustentario) {
					log.debug("Editar Documento sustentario.");
					documentoSustentarioVO.setListaPlanViajeRendicion(documentoSustentarioDto.getListaPlanViajeRendicion());
					documentoSustentarioVO.setMoneda(documentoSustentarioDto.getMoneda());
					documentoSustentarioVO.setListaExoneracion(documentoSustentarioDto.getListaExoneracion());
					documentoSustentarioVO.setListaPlanViajeInformeDitrib(documentoSustentarioDto.getListaPlanViajeInformeDistrib());
					
				} else {
					log.debug("Nuevo Documento sustentario.");
					documentoSustentarioVO.setMoneda(documentoSustentarioDto.getMoneda());
					documentoSustentarioVO.setListaExoneracion(documentoSustentarioDto.getListaExoneracion());
					documentoSustentarioVO.setListaPlanViajeInformeDitrib(documentoSustentarioDto.getListaPlanViajeInformeDistrib());
					
				}

				boolean estadoDDJJ = false;
				String tipoDocumento = ViaticoConstantes.TIPO_DOCUMENTO_DECLARACION_VIATICO;
				PlanViajeRendicionBean planViajeRendicion = new PlanViajeRendicionBean();
				planViajeRendicion.setPlanViajeId(planViajeId);
				planViajeRendicion.setTipoDocumento(tipoDocumento);
				estadoDDJJ = !viaticoGeneralService.existeRendicion(planViajeRendicion);

				documentoSustentarioVO.setIgv(documentoSustentarioDto.getIgv());
				documentoSustentarioVO.setMensajeRepuesta(mensajeRespuesta);
				documentoSustentarioVO.setEstadoDocumentoSustentario(estadoDocumentoSustentario);
				documentoSustentarioVO.setPlanViajeBean(documentoSustentarioDto.getPlanViajeBean());
				documentoSustentarioVO.setEstadoDDJJ(estadoDDJJ);
				documentoSustentarioVO.setMontoTotalRendicion(documentoSustentarioDto.getMontoTotalRendicion());
				documentoSustentarioVO.setTipoDocumentoList(documentoSustentarioDto.getTipoDocumentoList());
				documentoSustentarioVO.setPlanViajeConceptoList(documentoSustentarioDto.getPlanViajeConceptoList());
				documentoSustentarioVO.setPorcentajeDeclaracion(documentoSustentarioDto.getPorcentajeDeclaracion());
			} else {
				mensajeRespuesta = "No tiene codigo de planilla.";
				documentoSustentarioVO.setMensajeRepuesta(mensajeRespuesta);
			}

			respuesta.put("documentoSustentarioVO", documentoSustentarioVO);
			viewPage = new ModelAndView(getJsonView(), respuesta);
			log.debug(getClass().getName() + " Fin del metodo obtenerDatosGatos");
		} catch (Exception e) {
			log.error("Error obtenerDocumentoSustentario", e);
		}
		return viewPage;
	}

	public ModelAndView validarTipoDocumento(HttpServletRequest request, HttpServletResponse response) {
		log.debug(getClass().getName() + " Inicio del metodo validarTipoDocumento");
		ModelAndView view = new ModelAndView();
		Map<String, Object> respuesta = new HashMap<String, Object>();
		String tipoDocumento = request.getParameter("tipoDocumento");
		tipoDocumento = FormatoUtil.validarEmptyToNull(tipoDocumento);
		String serie = request.getParameter("serie");
		serie = FormatoUtil.validarEmptyToNull(serie);
		String numeroDocumento = request.getParameter("numeroDocumento");
		numeroDocumento = FormatoUtil.validarEmptyToNull(numeroDocumento);
		String numeroRuc = request.getParameter("numeroRuc");
		numeroRuc = FormatoUtil.validarEmptyToNull(numeroRuc);
		String tipo = request.getParameter("tipo");//N:Se trata de un registro nuevo, E:Edición, hay que validar que el registro no tome en cuenta el registro enviado pero para otros registros.
		
		PlanViajeRendicionBean planViajeRendicion = new PlanViajeRendicionBean();
		planViajeRendicion.setTipoDocumento(tipoDocumento);
		planViajeRendicion.setSerie(serie);
		planViajeRendicion.setNumeroDocumento(numeroDocumento);//completamos a 12 caracteres para que busque el correcto
		planViajeRendicion.setRuc(numeroRuc);
		if("E".equals(tipo)){
			planViajeRendicion.setSecuencial(new Integer(request.getParameter("secuencia")));
			planViajeRendicion.setPlanViajeId(request.getParameter("codPlanViaje"));
		}
		
		try {
			boolean estadoNumeroDocumento = viaticoGeneralService.validarNumeroDocumento(planViajeRendicion);
			respuesta.put("estadoNumeroDocumento", estadoNumeroDocumento);
		} catch (Exception e) {
			log.error("Error validarTipoDocumento", e);
		} finally {
			log.debug(getClass().getName() + " Fin del metodo validarTipoDocumento");
		}

		view = new ModelAndView(getJsonView(), respuesta);
		return view;
	}

	
	@SuppressWarnings("unused")
	public ModelAndView consultarRuc(HttpServletRequest request, HttpServletResponse response) {
		log.debug(getClass().getName() + " Inicio del metodo consultarRuc");
		ModelAndView view = new ModelAndView();
		Map<String, Object> resultado = new HashMap<String, Object>();
		String ruc = request.getParameter("ruc");
		/*String serie = request.getParameter("txtSerieDocumentoComprobante");
		serie = FormatoUtil.validarEmptyToNull(serie);
		String numeroDocumento = request.getParameter("txtNumeroDocumentoComprobante");
		numeroDocumento = FormatoUtil.validarEmptyToNull(numeroDocumento);*/
		
		
		ruc = FormatoUtil.validarEmptyToNull(ruc);
		//String tipoDocumento = request.getParameter("tipoDocumento");
		boolean estado = false;
		if(StringUtils.isNotEmpty(ruc)){
			try {
				URL url = new URL(ViaticoConstantes.URL_DESARROLLO_CONTRIBUYENTE + ruc);
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				conn.setRequestMethod("GET");
				conn.setRequestProperty("Accept", "application/json");
				
				
				if(conn != null){
						if (conn.getResponseCode() != 200) {
							// throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
							String mensajeError = "No ingreso RUC valido.";
							resultado.put("mensaje", mensajeError);
							estado = false;
							resultado.put("estado", estado);
							log.debug("Error: No se encontro el la URL, ya que el RUC no se encuenta en la base de datos.");
							// throw new RuntimeException("Get mensaje: " + conn.getInputStream());
						} else if (conn.getResponseCode() == 200) {
							BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
							String estadoRUC = "true";
							String output = ViaticoConstantes.CADENA_VACIA;
							
							if(br != null){
								while ((output = br.readLine()) != null) {
									JSONObject json = JSONObject.fromObject(output);
										if(json != null){
											estadoRUC = json.get("esActivo").toString().trim();
											resultado.put("razonSocial", json.get("ddpNombre").toString().trim());
										}									
								}
							}
							if(StringUtils.isNotEmpty(estadoRUC)){
							//log.debug("samuel: " + estadoRUC);
								resultado.put("estado", true);
										if (("true").equals((estadoRUC.trim()))) {
											
											final String rucFINAL = ruc;
											
											new Thread(new Runnable() {
												
												@Override
												public void run() {
													try {
														viaticoGeneralService.validarPadronRUC(rucFINAL);
													} catch (Exception e) {
														log.error("Error validarPadronRUC", e);
													}	
													
												}
											}).start();
											
																		
													try{
														URL urlComprobante = new URL(ViaticoConstantes.URL_DESARROLLO_COMPROBANTE+rucFINAL);
														HttpURLConnection connComprobante = (HttpURLConnection) urlComprobante.openConnection();
														connComprobante.setRequestMethod("GET");
														connComprobante.setRequestProperty("Accept", "application/json");
														
														if (connComprobante.getResponseCode() != 200) {
															throw new RuntimeException("Failed : HTTP error code : " + connComprobante.getResponseCode());
														}
														BufferedReader brconnComprobante = new BufferedReader(new InputStreamReader((connComprobante.getInputStream())));
								
														String outputComprobante;
														
														
														JSONArray jsonArray = new JSONArray();
														while ((outputComprobante = brconnComprobante.readLine()) != null) {	
															jsonArray = JSONArray.fromObject(outputComprobante);								
														}					
														
														@SuppressWarnings("unchecked")
														List<Map<String,Object>> mapComprobante = jsonArray;
														
														boolean flagFactura = false;
														boolean flagBoleta = false;
														if(CollectionUtils.isNotEmpty(mapComprobante)){
															for(Map<String,Object> comprobanteMap :  mapComprobante){
																if(comprobanteMap != null){
																	if(comprobanteMap.get("codTipoDoc") != null){
																		if(comprobanteMap.get("codTipoDoc").toString().trim().equals("01") && !flagFactura){
																			flagFactura = true;
																			resultado.put("flagFactura", flagFactura);
																		}
																		if (comprobanteMap.get("codTipoDoc").toString().trim().equals("03") && !flagBoleta){
																			flagBoleta = true;
																			resultado.put("flagBoleta", flagBoleta);
																		}
																	}else{
																		resultado.put("flagFactura", flagFactura);
																		resultado.put("flagBoleta", flagBoleta);
																	}
																}else{
																	resultado.put("flagFactura", flagFactura);
																	resultado.put("flagBoleta", flagBoleta);
																}
															}
														}else{
															resultado.put("flagFactura", flagFactura);
															resultado.put("flagBoleta", flagBoleta);
														}								
														
														connComprobante.disconnect();
													}catch (Exception e) {
														resultado.put("estado", false);
														log.error("Error consulta " + ViaticoConstantes.URL_DESARROLLO_COMPROBANTE, e);
														
													}																			
													
					
									} else if (("false").equals((estadoRUC.trim()))) {
										estado = false;
										resultado.put("estado", estado);
										String mensajeError = "No se encuentra activo el RUC";
										resultado.put("mensaje", mensajeError);
										resultado.put("razonSocial", ViaticoConstantes.CADENA_VACIA);
									}
							
							}
							
						}
			
						conn.disconnect();
				}else{
					String mensajeError = "Debe colocar n&uacute;mero RUC";
					resultado.put("mensaje", mensajeError);
					estado = false;
					resultado.put("estado", estado);
				}
				
			} catch (MalformedURLException e) {
				log.error("Error consulta url ", e);
			} catch (IOException e) {
				String mensajeError = "No ingreso RUC valido.";
				resultado.put("mensaje", mensajeError);
				estado = false;
				resultado.put("estado", estado);
				log.error("Error consulta url IOException", e);
			} finally {
				log.debug(getClass().getName() + " Fin del metodo consultarRuc");
			}

	}else{
		String mensajeError = "Debe colocar n&uacute;mero RUC";
		resultado.put("mensaje", mensajeError);
		estado = false;
		resultado.put("estado", estado);
	}
		view = new ModelAndView(getJsonView(), resultado);
		return view;
	}

	/**
	 * el metodo devolvera si hay o no tipo DDJJ - viaticos
	 * 
	 * @author Samuel Dionisio
	 * @see ModelAndView
	 * @param request : de la clase HttpServletRequest
	 * @param response : de la clase HttpServletResponse
	 * @return Devuelve estado comprobante pago
	 * @param codPlanViaje : codigo plan viaje
	 * @throws Exception
	 */
	/*
	 * public ModelAndView validarEstadoComprobantePagoDDJJViatico(HttpServletRequest request,HttpServletResponse response) throws Exception { ModelAndView view = new ModelAndView(); Map<String, Object> respuesta = new HashMap<String, Object>(); boolean estado = false;
	 * 
	 * String planViajeId = request.getParameter("planViajeId"); String tipoDocumento = ViaticoConstantes.TIPO_DOCUMENTO_DECLARACION_VIATICO; PlanViajeRendicionBean planViajeRendicion = new PlanViajeRendicionBean(); planViajeRendicion.setPlanViajeId(planViajeId);
	 * planViajeRendicion.setTipoDocumento(tipoDocumento); estado = viaticoGeneralService.validarNumeroDocumento(planViajeRendicion);
	 * 
	 * respuesta.put("estado", estado);
	 * 
	 * view = new ModelAndView(getJsonView(), respuesta); return view; }
	 */

	/**
	 * @author Samuel Dionisio
	 * @see ModelAndView
	 * @param request : de la clase HttpServletRequest
	 * @param response : de la clase HttpServletResponse
	 * @return Devuelve lista de archivos adjuntos en json
	 * @param numeroRegitroArchivo : Numero de Registro de Archivo
	 * @throws Exception
	 */
	public ModelAndView obtenerDatosArchivoAdjunto(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map<String, Object> respuesta = new HashMap<String, Object>();
		Map<String, Object> parmSearch = new HashMap<String, Object>();
		ModelAndView viewPage = null;

		try {
			log.debug("Iniciando Registrador -- getCargaArchivosAdjuntos");

			String codigoBoletaDeposito = StringUtils.trimToNull(request.getParameter("codigoBoleto"));
			String planViajeId = StringUtils.trimToNull(request.getParameter("idPlanViaje"));
			String numeroRegitroColaborador = StringUtils.trimToNull(request.getParameter("numeroRegitroColaborador"));
			String paginaOrigen = StringUtils.trimToNull(request.getParameter("paginaOrigen"));

			// aqui buscar vaucher

			MaestroPersonalBean maestroPersonal = registroPersonalService.obtenerPersonaxRegistro(numeroRegitroColaborador);
			String comisionado = maestroPersonal.getNumero_registro() + " - " + maestroPersonal.getNombre_completo();
			String uuoo = maestroPersonal.getCodigoDependencia() + " - " + maestroPersonal.getDependencia();
			log.debug("comisionado: " + comisionado);
			log.debug("uuoo: " + uuoo);

			PlanViajeBean planViaje = consultaSolicitudService.buscarPlanViaje(planViajeId);
			log.debug("codigoPlanilla: " + planViaje.getCodPlanilla());
			log.debug("montoTotal: " + planViaje.getMoneda() + " " + planViaje.getMontoTotal());

			PapeletaDepositoBean papeletaDeposito = new PapeletaDepositoBean();
			if (!StringUtils.isEmpty(codigoBoletaDeposito)) {
				papeletaDeposito = consultaRendicionService.obtenerPapeletaDeposito(codigoBoletaDeposito);
			}

			respuesta.put("comisionado", comisionado);
			respuesta.put("uuoo", uuoo);

			respuesta.put("codigoPlanilla", planViaje.getCodPlanilla());
			respuesta.put("montoTotal", planViaje.getMoneda() + " " + planViaje.getMontoTotal());

			if (ViaticoConstantes.PAGINA_PRINCIPAL.equals(paginaOrigen)) {
				parmSearch.put("num_reg", planViaje.getNumeroRegistroArchivo());
			} else if (ViaticoConstantes.PAGINA_SECUNDARIA.equals(paginaOrigen)) {
				parmSearch.put("num_reg", papeletaDeposito.getNumeroRegistroArchivo());
			}

			List<RegistroArchivosFisicoBean> listArchivosAdjuntos = (List<RegistroArchivosFisicoBean>) registroArchivosService.listarArchivosAdjuntos(parmSearch);
			parmSearch.clear();

			respuesta.put("listArchivosAdjuntos", listArchivosAdjuntos);
			viewPage = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {
			log.error("Error obtenerDatosArchivoAdjunto", e);
		}
		return viewPage;

	}

	/**
	 * Descargar Archivos Adjuntos de los item
	 * 
	 * @see ModelAndView
	 * @param request : de la clase HttpServletRequest
	 * @param response : de la clase HttpServletResponse
	 * @param sec_reg : obtenida del request.getParameter
	 * @return ModelAndView
	 **/
	public ModelAndView descargarArchivoAdjunto(HttpServletRequest request, HttpServletResponse response) {
		if (log.isDebugEnabled()) {
			log.debug("debug Inicio - ConsultaGeneralController.descargarArchivoAdjunto");
		}
		Map<String, Object> params = new HashMap<String, Object>();

		try {
			String secuenciaReg = StringUtils.trim(request.getParameter("secuenciaReg"));

			params.put("sec_reg", secuenciaReg);
			RegistroArchivosFisicoBean archivo = registroArchivosService.recuperarArchivo(params);

			response.setContentType("application/octet-stream");
			response.setHeader("Content-Disposition", "attachment;filename=" + archivo.getFile_name());

			OutputStream os = response.getOutputStream();

			os.write(archivo.getData());

			os.flush();
			os.close();
			return null;
		} catch (ServiceException ex) {
			log.error("Error en RegistroArchivosController.descargarArchivo: " + ex.getMessage(), ex);
			throw new ServiceException(this, ex);
		} catch (Exception ex) {
			log.error("Error en RegistroArchivosController.descargarArchivo: " + ex.getMessage(), ex);
			throw new ServiceException(this, ex);
		} finally {
			if (log.isDebugEnabled()) {
				log.debug("Fin - RegistroArchivosController.descargarArchivo");
			}
		}

	}

	/**
	 * Obtener lista tipo Documento.
	 * 
	 * @author Eduardo Marchena
	 * @see ModelAndView
	 * @param request : de la clase HttpServletRequest
	 * @param response : de la clase HttpServletResponse
	 * @param aplicacion : obtenida del request.getParameter
	 * @param modulo : obtenida del request.getParameter
	 * @return objeto view de la clase ModelAndView tipo Json con lista de tipo de documento
	 **/
	@SuppressWarnings("unchecked")
	public ModelAndView obtenerTipoDocumento(HttpServletRequest request, HttpServletResponse response) {
		if (log.isDebugEnabled()) {
			log.debug("Inicio -  RegistroArchivosController.getTipoDocumento");
		}
		Map<String, Object> respuesta = new HashMap<String, Object>();
		Map<String, Object> params = new HashMap<String, Object>();
		List<Map<String, Object>> listTiposDocumentos = new ArrayList<Map<String, Object>>();
		ModelAndView viewPage = null;

		try {

			params.put("cod_app", ViaticoConstantes.APLICACION_SERVICIOS);
			params.put("cod_mod", ViaticoConstantes.MODULO_VIATICOS);
			listTiposDocumentos = (List<Map<String, Object>>) registroArchivosService.listarTipoArchivos(params);
			respuesta.put("listTiposDocumentos", listTiposDocumentos);

			viewPage = new ModelAndView(getJsonView(), respuesta);

		} catch (ServiceException ex) {
			log.error("Error en  RegistroArchivosController.getTipoDocumento: " + ex.getMessage(), ex);
			throw new ServiceException(this, ex);
		} catch (Exception ex) {
			log.error("Error en  RegistroArchivosController.getTipoDocumento: " + ex.getMessage(), ex);
			throw new ServiceException(this, ex);
		} finally {
			if (log.isDebugEnabled()) {
				log.debug("Fin -  RegistroArchivosController.getTipoDocumento");
			}
		}
		return viewPage;
	}
	
	/**
	 * Metodo que permite consultar el seguimiento.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	public ModelAndView consultarSeguimiento(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoConsulta = ViaticoConstantes.ERROR_CONSULTA;
		String errorMessage = ViaticoConstantes.CADENA_VACIA;
		
		try {
			log.debug(ConsultaGeneralController.class.getSimpleName() + ".consultarSeguimiento");
			String codPlanViaje = request.getParameter("codPlanViaje");
			String numeroExpediente = request.getParameter("numeroExpediente");
			codPlanViaje = FormatoUtil.validarEmptyToNull(codPlanViaje);
			numeroExpediente = FormatoUtil.validarEmptyToNull(numeroExpediente);
			if (codPlanViaje != null) {
				PlanViajeBean planViajeBean = viaticoConsultaService.obtenerPlanViajeToSeguimiento(codPlanViaje);
				if (planViajeBean != null) {
					planViajeBean.setMtoTotalFormateado(NumeroUtil.formatearMonedaMontoToDecimal(planViajeBean.getMoneda(), 2, planViajeBean.getMtoTotal()));
					codigoConsulta = ViaticoConstantes.ERROR_CONSULTA_SIN_SEGUIMIENTO;
				}
				
				if (numeroExpediente != null) {
					ArrayList<ExpedienteInternoAccionBean> expedienteInternoAccionList = (ArrayList<ExpedienteInternoAccionBean>) registroExpedienteService.listaSecuenciaExpediente(numeroExpediente);
					ArrayList<ExpedienteInternoAccionBean> expedienteInternoAccionAuxList = null;
					if (expedienteInternoAccionList != null && !expedienteInternoAccionList.isEmpty()) {
						expedienteInternoAccionAuxList = new ArrayList<ExpedienteInternoAccionBean>();
						for (ExpedienteInternoAccionBean expedienteInternoAccionBean : expedienteInternoAccionList) {
							expedienteInternoAccionBean.setDes_accion(FormatoUtil.getUppperCaseText(expedienteInternoAccionBean.getDes_accion()));
							expedienteInternoAccionBean.setNom_emp(FormatoUtil.getUppperCaseText(expedienteInternoAccionBean.getNom_emp()));
							expedienteInternoAccionBean.setObservacion(FormatoUtil.getUppperCaseText(expedienteInternoAccionBean.getObservacion()));
							expedienteInternoAccionBean.setNom_estado(FormatoUtil.getUppperCaseText(expedienteInternoAccionBean.getNom_estado()));
							expedienteInternoAccionAuxList.add(expedienteInternoAccionBean);
						}
						codigoConsulta = ViaticoConstantes.EXITO_CONSULTA;
					}
					respuesta.put("expedienteInternoAccionList", expedienteInternoAccionAuxList);
				}
				respuesta.put("planViajeBean", planViajeBean);
			}
			log.debug(ConsultaGeneralController.class.getSimpleName() + ".consultarSeguimiento.fin");
			
		} catch (Exception ex) {
			errorMessage = ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO);
			log.error(ex.getMessage(), ex);
		}
		
		respuesta.put("codigoConsulta", codigoConsulta);
		respuesta.put("errorMessage", errorMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}

}