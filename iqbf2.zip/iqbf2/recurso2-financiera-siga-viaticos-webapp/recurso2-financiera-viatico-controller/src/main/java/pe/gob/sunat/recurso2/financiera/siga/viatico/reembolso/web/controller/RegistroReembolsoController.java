package pe.gob.sunat.recurso2.financiera.siga.viatico.reembolso.web.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.BeanUtilsBean;
import org.apache.commons.beanutils.PropertyUtilsBean;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.recurso2.administracion.siga.archivo.model.bean.RegistroArchivosFisicoBean;
import pe.gob.sunat.recurso2.administracion.siga.archivo.service.RegistroArchivosService;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.DependenciaBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroDependenciasService;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroGeneralService;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.administracion.siga.util.FechaUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.FormatoUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.NumeroUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ClaveValorBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ConceptoPlanillaViaticosBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.MetasBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeConceptoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeDestinoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeInformeDistribBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeRendicionBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.SolicitudDTO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.TXXX8LugarUbigeoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.TipoCambioBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.reembolso.service.ConsultaReembolsoService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.reembolso.service.RegistroReembolsoService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.rendicion.service.ConsultaRendicionService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoConsultaService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoGeneralService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoMensajeriaService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoReporteService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.service.ConsultaSolicitudService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ReembolsoConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ReembolsoUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.RendicionConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ResourceBundleUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.controller.BaseController;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.singleton.ViaticosProcesoSingleton;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.singleton.ViaticosTarifarioSingleton;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.view.ReembolsoVO;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

/**
 * La clase RegistroReembolsoController realiza las validaciones y transacciones para la pagina de registro una solicitud de reembolso.
 * 
 * @author Juan Farro
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
public class RegistroReembolsoController extends BaseController {

	/** Declaracion del log para realizar los debug, info, error, etc. */
	protected final Log log = LogFactory.getLog(getClass());

	/** Declaracion del servicio viaticoService. */
	private ViaticoService viaticoService;

	/** Declaracion del servicio viaticoGeneralService. */
	private ViaticoGeneralService viaticoGeneralService;

	/** Declaracion del servicio registroGeneralService. */
	private RegistroGeneralService registroGeneralService;

	/** Declaracion del servicio registroPersonalService. */
	private RegistroPersonalService registroPersonalService;

	/** Declaracion del servicio registroReembolsoService. */
	private RegistroReembolsoService registroReembolsoService;

	/** Declaracion del servicio consultaSolicitudService. */
	private ConsultaSolicitudService consultaSolicitudService;

	/** Declaracion del servicio consultaRendicionService. */
	private ConsultaRendicionService consultaRendicionService;

	/** Declaracion del servicio consultaReembolsoService. */
	private ConsultaReembolsoService consultaReembolsoService;

	/** Declaracion del servicio viaticoReporteService. */
	private ViaticoReporteService viaticoReporteService;

	/** Declaracion del servicio ViaticoConsultaService. */
	private ViaticoConsultaService viaticoConsultaService;

	/** Declaracion del servicio viaticoMensajeriaService. */
	private ViaticoMensajeriaService viaticoMensajeriaService;

	/** Declaracion del servicio registroArchivosService. */
	private RegistroArchivosService registroArchivosService;

	/** Declaracion del servicio viaticosProcesoSingleton. */
	private ViaticosProcesoSingleton viaticosProcesoSingleton;

	/** Declaracion del servicio viaticosTarifarioSingleton. */
	private ViaticosTarifarioSingleton viaticosTarifarioSingleton;

	/** Declaracion del servicio registroDependenciasService. */
	private RegistroDependenciasService registroDependenciasService;

	public ViaticoService getViaticoService() {
		return viaticoService;
	}

	public void setViaticoService(ViaticoService viaticoService) {
		this.viaticoService = viaticoService;
	}

	public ViaticoGeneralService getViaticoGeneralService() {
		return viaticoGeneralService;
	}

	public void setViaticoGeneralService(ViaticoGeneralService viaticoGeneralService) {
		this.viaticoGeneralService = viaticoGeneralService;
	}

	public RegistroGeneralService getRegistroGeneralService() {
		return registroGeneralService;
	}

	public void setRegistroGeneralService(RegistroGeneralService registroGeneralService) {
		this.registroGeneralService = registroGeneralService;
	}

	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}

	public RegistroReembolsoService getRegistroReembolsoService() {
		return registroReembolsoService;
	}

	public void setRegistroReembolsoService(RegistroReembolsoService registroReembolsoService) {
		this.registroReembolsoService = registroReembolsoService;
	}

	public ConsultaSolicitudService getConsultaSolicitudService() {
		return consultaSolicitudService;
	}

	public void setConsultaSolicitudService(ConsultaSolicitudService consultaSolicitudService) {
		this.consultaSolicitudService = consultaSolicitudService;
	}

	public ViaticoReporteService getViaticoReporteService() {
		return viaticoReporteService;
	}

	public void setViaticoReporteService(ViaticoReporteService viaticoReporteService) {
		this.viaticoReporteService = viaticoReporteService;
	}

	public ViaticoMensajeriaService getViaticoMensajeriaService() {
		return viaticoMensajeriaService;
	}

	public void setViaticoMensajeriaService(ViaticoMensajeriaService viaticoMensajeriaService) {
		this.viaticoMensajeriaService = viaticoMensajeriaService;
	}

	public ViaticoConsultaService getViaticoConsultaService() {
		return viaticoConsultaService;
	}

	public void setViaticoConsultaService(ViaticoConsultaService viaticoConsultaService) {
		this.viaticoConsultaService = viaticoConsultaService;
	}

	public ConsultaRendicionService getConsultaRendicionService() {
		return consultaRendicionService;
	}

	public void setConsultaRendicionService(ConsultaRendicionService consultaRendicionService) {
		this.consultaRendicionService = consultaRendicionService;
	}

	public ConsultaReembolsoService getConsultaReembolsoService() {
		return consultaReembolsoService;
	}

	public void setConsultaReembolsoService(ConsultaReembolsoService consultaReembolsoService) {
		this.consultaReembolsoService = consultaReembolsoService;
	}

	public RegistroArchivosService getRegistroArchivosService() {
		return registroArchivosService;
	}

	public void setRegistroArchivosService(RegistroArchivosService registroArchivosService) {
		this.registroArchivosService = registroArchivosService;
	}

	public ViaticosProcesoSingleton getViaticosProcesoSingleton() {
		return viaticosProcesoSingleton;
	}

	public void setViaticosProcesoSingleton(ViaticosProcesoSingleton viaticosProcesoSingleton) {
		this.viaticosProcesoSingleton = viaticosProcesoSingleton;
	}

	public ViaticosTarifarioSingleton getViaticosTarifarioSingleton() {
		return viaticosTarifarioSingleton;
	}

	public void setViaticosTarifarioSingleton(ViaticosTarifarioSingleton viaticosTarifarioSingleton) {
		this.viaticosTarifarioSingleton = viaticosTarifarioSingleton;
	}

	public RegistroDependenciasService getRegistroDependenciasService() {
		return registroDependenciasService;
	}

	public void setRegistroDependenciasService(RegistroDependenciasService registroDependenciasService) {
		this.registroDependenciasService = registroDependenciasService;
	}

	/**
	 * Metodo que permite cargar la pagina de registro de viatico.
	 * 
	 * @author Juan Farro
	 * @see ModelAndView
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView mostrarRegistrarViatico(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;

		boolean customMessage = false;
		String errorMessage = StringUtils.EMPTY;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			log.debug(getClass().getName() + " Inicio del metodo mostrarRegistrarViatico");

			// view object con toda la informacion a mostrar en la pantalla de registro de una solicitud
			ReembolsoVO registroVO = new ReembolsoVO();

			// usuario en session
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");

			// datos del colaborador que esta en session
			MaestroPersonalBean colaborador = registroPersonalService.obtenerPersonaxRegistro(usuarioBean.getNroRegistro());
			if (colaborador == null) {
				customMessage = false;
				throw new Exception("Usuario no existe");
			}

			String codigoDependencia = StringUtils.trimToEmpty(colaborador.getCodigoDependencia());

			registroVO.setFlagDoAction(ViaticoConstantes.VISTA_REGISTRAR);
			registroVO.setCodigoColaborador(colaborador.getCodigoEmpleado());

			// seteando niveles
			registroVO.setCodigoNivelColaborador(StringUtils.trimToEmpty(colaborador.getCodigoNivel())); // CODI_NIVE_NVL
			registroVO.setCodigoNivelViaticoColaborador(StringUtils.trimToEmpty(colaborador.getCodigoNivelViatico())); // NIVE_VIAT_NVI

			registroVO.setCodigoSedeColaborador(StringUtils.trimToEmpty(colaborador.getCodigoSede()));

			// indicadores de traslape y autorizacion de traslape
			registroVO.setIndicadorTraslape(ViaticoConstantes.INDICADOR_TRASLAPE_NO);
			registroVO.setIndicadorAutorizacion(ViaticoConstantes.INDICADOR_AUTORIZACION_SIN_AUTORIZAR);
			registroVO.setFlagResetearTraslapeAutorizacion(StringUtils.EMPTY);

			registroVO.setOrigen(ViaticoConstantes.TIPO_ORIGEN_REEMBOLSO); // solo referencial, al armar en bean para guardar siempre le pone reembolso

			Long nroRegistros = null;

			// indicador que el colaborador en session es registrador
			nroRegistros = viaticoGeneralService.determinarRegistrador(colaborador.getCodigoEmpleado());
			registroVO.setFlagRegistrador(ViaticoUtil.obtenerFlagRegistrador(nroRegistros));

			// indicador que el colaborador en session es registrador universal
			nroRegistros = viaticoGeneralService.determinarRegistradorUniversal(colaborador.getCodigoEmpleado());
			registroVO.setFlagRegistradorUniversal(ViaticoUtil.obtenerFlagRegistradorUniversal(nroRegistros));

			// determinar flags para buscar uuoo y colaborador
			String codigoTipoUUOOViatico = ViaticoUtil.obtenerFlagBuscarUUOO(registroVO.getFlagRegistradorUniversal(), registroVO.getFlagRegistrador());
			String codigoTipoUsuarioViatico = ViaticoUtil.obtenerFlagBuscarColaborador(registroVO.getFlagRegistradorUniversal(), registroVO.getFlagRegistrador());

			registroVO.setCodigoTipoUUOOViatico(codigoTipoUUOOViatico);
			registroVO.setCodigoTipoUsuarioViatico(codigoTipoUsuarioViatico);

			// el usuario en session es a la vez el registrador
			registroVO.setNumeroRegistroRegistrador(colaborador.getNumero_registro());
			registroVO.setCodigoRegistrador(colaborador.getCodigoEmpleado());

			registroVO.setCodigoEstadoColaborador(colaborador.getCodigoEstado());
			registroVO.setEstadoColaborador(colaborador.getEstado());

			registroVO.setNumeroRegistro(colaborador.getNumero_registro());
			registroVO.setNombreColaborador(colaborador.getNombre_completo());

			registroVO.setUuoo(colaborador.getUuoo());
			registroVO.setCodigoDependencia(codigoDependencia);
			registroVO.setDescripcionDependencia(colaborador.getDependencia() + ViaticoConstantes.ESPACIO + ViaticoConstantes.SIGNO_MINUS + ViaticoConstantes.ESPACIO + buscarIntendencia(colaborador.getUuoo()));

			registroVO.setCodPlanilla(StringUtils.EMPTY);
			registroVO.setCodPlanViaje(StringUtils.EMPTY);
			registroVO.setCodigoEstadoViatico(ViaticoConstantes.ESTADO_REEMBOLSO_ELABORADO);
			registroVO.setEstadoViatico(consultaSolicitudService.obtenerDescripcionSysEstado(ViaticoConstantes.ESTADO_REEMBOLSO_NOMBRE_TABLA, ViaticoConstantes.ESTADO_REEMBOLSO_ELABORADO));

			// buscar afectacion presupuesta / meta presupuestal ordenando por mayor codigo
			if (StringUtils.isNotBlank(codigoDependencia)) {

				List<MetasBean> metasList = viaticoGeneralService.obtenerMetas(codigoDependencia, FechaUtil.obtenerAnioActual(), ViaticoConstantes.BUSQ_META_ORDENA_MAYOR_CODIGO);
				if (CollectionUtils.isNotEmpty(metasList)) {

					// buscar meta por default (IND_META_UUOO = 1)
					MetasBean meta = null;
					for (int i = 0; i < metasList.size(); i++) {
						if (metasList.get(i) == null) continue;

						if (StringUtils.equals(metasList.get(i).getIndicadorMetaUUOO(), ViaticoConstantes.BUSQ_META_DEFAULT_UUOO)) {
							meta = metasList.get(i);
							break;
						}
					}

					// si no hay meta por default, coge la primera meta (en ambos casos se ordena por mayor codigo)
					if (meta == null) {
						meta = metasList.get(0);
					}

					registroVO.setMetaPresupuestal(meta.getSecuFuncSfu() + ViaticoConstantes.ESPACIO + ViaticoConstantes.SIGNO_MINUS + ViaticoConstantes.ESPACIO + meta.getCodiLargMet() + ViaticoConstantes.ESPACIO + meta.getDescLargMet());
					registroVO.setCodigoMetaPresupuestal(meta.getSecuFuncSfu());

				}

			}

			registroVO.setTipoViatico(ViaticoConstantes.VISTA_TIPO_VIATICO_NACIONAL); // nacional, internacional
			registroVO.setDuracionComision(ViaticoConstantes.VISTA_DURACION_COMISION_MAYOR4H); // may4h, men4h

			registroVO.setViaticosProgramadosNac(ViaticoConstantes.ESCALA_VIATICO_ESTA_ESC_VIAT_SI); // S: si, N:no

			registroVO.setUsarLimaComoDefault(ViaticoConstantes.NO); // al inicio carga nacional, no se considerara a lima como default en el punto de partida

			// combo lugares (lugar desplazamiento)
			registroVO.setLugaresList(viaticoGeneralService.obtenerRutasLugares());

			// combo tarifas (lugar desplazamiento)
			registroVO.setTarifasList(viaticoGeneralService.obtenerRutasTipoTarifas());

			// combo medio de transporte (lugar desplazamiento)
			registroVO.setMediosTransporteList(viaticoGeneralService.obtenerMediosTransporte());

			// combo de ampliacion de comision
			registroVO.setMotivoAmpliacion(StringUtils.EMPTY);
			registroVO.setMotivoAmpliacionList(viaticoGeneralService.obtenerMotivosAmpliacionComision());

			// combo de planillas asociadas
			String tipoDestino = ViaticoConstantes.TIPO_COMISION_NACIONAL;
			String indicadorHoras = ViaticoConstantes.INDICADOR_HORAS_DIAS;
			registroVO.setPlanillasAsociadasList(consultaReembolsoService.obtenerPlanillasAsociadas(colaborador.getCodigoEmpleado(), tipoDestino, indicadorHoras));
			registroVO.setPlanillaAsociada(StringUtils.EMPTY);

			// lista de archivos adjuntos
			registroVO.setArchivosAdjuntosList(null);

			// fecha y hora de visualizacion de asistencia
			registroVO.setConsultaAsistenciaVisualizo(ViaticoConstantes.NO);
			registroVO.setConsultaAsistenciaFecha(StringUtils.EMPTY);
			registroVO.setConsultaAsistenciaHora(StringUtils.EMPTY);

			// para el registro la fecha de registro es igual a la fecha today
			Date today = new Date();
			registroVO.setFechaToday(FechaUtil.formatDateToDateDDMMYYYY(today));
			registroVO.setFechaRegistro(FechaUtil.formatDateToDateDDMMYYYY(today));
			registroVO.setFechaRegistroMas1(FechaUtil.formatDateToDateDDMMYYYY(ViaticoUtil.addDiasToDate(today, ViaticoConstantes.UNO_INT)));
			registroVO.setTipoConfiguracion(viaticosProcesoSingleton.obtenerProceso());

			// setear listas en formato JSON
			respuesta.put("desplazamientosList", ViaticoUtil.toJSON(registroVO.getDesplazamientosList()));
			respuesta.put("lugaresList", ViaticoUtil.toJSON(registroVO.getLugaresList()));
			respuesta.put("tarifasList", ViaticoUtil.toJSON(registroVO.getTarifasList()));
			respuesta.put("mediosTransporteList", ViaticoUtil.toJSON(registroVO.getMediosTransporteList()));
			respuesta.put("archivosAdjuntosList", ViaticoUtil.toJSON(registroVO.getArchivosAdjuntosList()));

			// setear constantes que se usan en el js
			ReembolsoUtil.poblarConstantesParaRegistro(respuesta);

			respuesta.put("moneda", ViaticoConstantes.MONEDA_SOLES);
			respuesta.put("fechaToday", registroVO.getFechaToday());
			respuesta.put("fechaRegistro", registroVO.getFechaRegistro());
			respuesta.put("fechaRegistroMas1", registroVO.getFechaRegistroMas1());
			respuesta.put("tipoConfiguracion", viaticosProcesoSingleton.obtenerProceso());
			respuesta.put("tipoTarifario", viaticosTarifarioSingleton.obtenerTarifario());

			respuesta.put("registroVO", registroVO);

		} catch (Exception e) {

			log.error(e.getMessage(), e);
			errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO);

		} finally {

			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(ReembolsoConstantes.REGISTRAR_SOLICITUD_VIATICO_PAGE, respuesta);

			log.debug(getClass().getName() + " Fin del metodo mostrarRegistrarViatico");
		}

		return modelAndView;
	}

	/**
	 * Metodo que permite cargar la pagina de modificacion viatico.
	 * 
	 * @author Juan Farro
	 * @see ModelAndView
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView mostrarModificarViatico(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;

		boolean customMessage = false;
		String errorMessage = StringUtils.EMPTY;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			log.debug(getClass().getName() + " Inicio del metodo mostrarRegistrarViatico");

			String codPlanilla = StringUtils.trimToEmpty(request.getParameter("codPlanilla"));
			String dataJSON = StringUtils.trimToEmpty(request.getParameter("dataJSON"));

			// invocar al metodo que arma el view object a partir del codigo de planilla
			// view object con toda la informacion a mostrar en la pantalla de registro de una solicitud
			ReembolsoVO registroVO = armarRegistroVO(codPlanilla);

			// si hubo error en armarRegistroVO
			if (StringUtils.isNotBlank(registroVO.getErrorMessage())) {
				customMessage = registroVO.getCustomMessage();
				throw new Exception(registroVO.getErrorMessage());
			}

			// validacion, solo puede modificar si esta en proceso u observado
			if (!StringUtils.equals(registroVO.getOrigen(), ViaticoConstantes.TIPO_ORIGEN_REEMBOLSO)) {
				customMessage = true;
				throw new Exception("No puede modificar esta solicitud. No es una solicitud de reembolso");
			}

			// validar el estado en el que se puede modificar
			if (!ReembolsoUtil.puedeEnviarSolicitudReembolso(registroVO.getCodigoEstadoViatico())) {
				customMessage = true;
				throw new Exception("No puede modificar esta solicitud de reembolso.");
			}

			// parametros adicionales para la consulta: pagina que llamo al consultar, y la data de la bandeja
			respuesta.put("dataJSON", dataJSON);

			// setear listas en formato JSON
			respuesta.put("desplazamientosList", ViaticoUtil.toJSON(registroVO.getDesplazamientosList()));
			respuesta.put("lugaresList", ViaticoUtil.toJSON(registroVO.getLugaresList()));
			respuesta.put("tarifasList", ViaticoUtil.toJSON(registroVO.getTarifasList()));
			respuesta.put("mediosTransporteList", ViaticoUtil.toJSON(registroVO.getMediosTransporteList()));
			respuesta.put("archivosAdjuntosList", ViaticoUtil.toJSON(registroVO.getArchivosAdjuntosList()));

			// setear constantes que se usan en el js
			ReembolsoUtil.poblarConstantesParaRegistro(respuesta);

			respuesta.put("moneda", ViaticoConstantes.MONEDA_SOLES);
			respuesta.put("fechaToday", registroVO.getFechaToday());
			respuesta.put("fechaRegistro", registroVO.getFechaRegistro());
			respuesta.put("fechaRegistroMas1", registroVO.getFechaRegistroMas1());
			respuesta.put("tipoConfiguracion", viaticosProcesoSingleton.obtenerProceso());
			respuesta.put("tipoTarifario", viaticosTarifarioSingleton.obtenerTarifario());

			respuesta.put("registroVO", registroVO);

		} catch (Exception e) {

			log.error(e.getMessage(), e);
			errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO);

		} finally {

			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(ReembolsoConstantes.REGISTRAR_SOLICITUD_VIATICO_PAGE, respuesta);

			log.debug(getClass().getName() + " Fin del metodo mostrarRegistrarViatico");
		}

		return modelAndView;
	}

	/**
	 * Metodo que permite validar guardar viatico (ultimas validaciones lado servidor).
	 * 
	 * @author Juan Farro
	 * @see ModelAndView
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView validarGuardarViatico(HttpServletRequest request, HttpServletResponse response) {

		log.debug(getClass().getName() + " Inicio del metodo validarGuardarViatico");

		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			boolean validacionOk = true;

			if (validacionOk) {

				respuesta.put("validacionOk", ViaticoConstantes.SI);
				respuesta.put("validacionMsg", StringUtils.EMPTY);

			} else {

				respuesta.put("validacionOk", ViaticoConstantes.NO);
				respuesta.put("validacionMsg", ViaticoConstantes.OPERACION_NO_REALIZADA);

			}

			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", ViaticoConstantes.NO);
			respuesta.put("msgError", StringUtils.EMPTY);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {

			log.error(e.getMessage(), e);

			// INDICADORES QUE LA PETICION AJAX CULMINO CON ERRORES.
			// NOTA: El key msgError se usa como mensaje generico de error no manejable. 
			//       Otros keys del mapa respuesta se usan para personalizar los mensajes de negocio visibles al usuario.
			respuesta.put("error", ViaticoConstantes.SI);
			respuesta.put("msgError", ViaticoConstantes.MSG_ERROR_OPERACION_NO_EFECTUADA);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} finally {

			log.debug(getClass().getName() + " Fin del metodo validarGuardarViatico");
		}

		return modelAndView;
	}

	/**
	 * Metodo que permite validar modificar viatico (ultimas validaciones lado servidor).
	 * 
	 * @author Juan Farro
	 * @see ModelAndView
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView validarModificarViatico(HttpServletRequest request, HttpServletResponse response) {

		log.debug(getClass().getName() + " Inicio del metodo validarModificarViatico");

		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			boolean validacionOk = true;
			String validacionMsg = StringUtils.EMPTY;

			// parseo automatico: request -> a bean de vista (datos de la vista)
			ReembolsoVO viewObject = (ReembolsoVO) fillViewObjectFromRequest(request, new ReembolsoVO());

			PlanViajeBean planViaje = consultaSolicitudService.buscarPlanViajePlanilla(viewObject.getCodPlanilla());

			// validar que exista plan de viaje
			if (validacionOk && planViaje == null) {

				validacionOk = false;
				validacionMsg = "Solicitud no existe";
			}

			// validar estado de plan de viaje para modificar
			if (validacionOk) {

				if (!ReembolsoUtil.puedeModificarSolicitudReembolso(planViaje.getEstadoPlanViaje())) {
					validacionOk = false;
					validacionMsg = "No puede modificar esta solicitud de reembolso.";
				}
			}
			
			// validar que no existan comprobantes comprendidos en el rango de fechas que esta modificando
			/* NOTA: SE RETIRO VALIDACION DEL MODIFICAR
			if (validacionOk) {

				boolean esNacional = StringUtils.equals(viewObject.getTipoViatico(), ViaticoConstantes.VISTA_TIPO_VIATICO_NACIONAL);
				boolean esInternacional = StringUtils.equals(viewObject.getTipoViatico(), ViaticoConstantes.VISTA_TIPO_VIATICO_INTERNACIONAL);
				boolean esMayor4h = StringUtils.equals(viewObject.getDuracionComision(), ViaticoConstantes.VISTA_DURACION_COMISION_MAYOR4H);
				boolean esMenorIgual4h = StringUtils.equals(viewObject.getDuracionComision(), ViaticoConstantes.VISTA_DURACION_COMISION_MENOR_IGUAL4h);

				// fechas
				Date fechaDesdeEvento = null;
				Date fechaHastaEvento = null;
				Date fechaDesdeItinerario = null; // puede ser null
				Date fechaHastaItinerario = null; // puede ser null

				String planViajeID = planViaje.getCodPlanViaje();

				if (esNacional) {

					if (esMayor4h) {

						fechaDesdeEvento = FechaUtil.parseStringDateToDate(viewObject.getFechaSalidaNacMay4h(), FechaBean.FORMATO_DEFAULT);
						fechaHastaEvento = FechaUtil.parseStringDateToDate(viewObject.getFechaRetornoNacMay4h(), FechaBean.FORMATO_DEFAULT);

					} else if (esMenorIgual4h) {

						fechaDesdeEvento = FechaUtil.parseStringDateToDate(viewObject.getFechaNacMen4h(), FechaBean.FORMATO_DEFAULT);
						fechaHastaEvento = FechaUtil.parseStringDateToDate(viewObject.getFechaNacMen4h(), FechaBean.FORMATO_DEFAULT);
					}

				} else if (esInternacional) {

					fechaDesdeEvento = FechaUtil.parseStringDateToDate(viewObject.getFechaEventoInicioInter(), FechaBean.FORMATO_DEFAULT);
					fechaHastaEvento = FechaUtil.parseStringDateToDate(viewObject.getFechaEventoFinInter(), FechaBean.FORMATO_DEFAULT);

					fechaDesdeItinerario = FechaUtil.parseStringDateToDate(viewObject.getFechaItinerarioInicioInter(), FechaBean.FORMATO_DEFAULT);
					fechaHastaItinerario = FechaUtil.parseStringDateToDate(viewObject.getFechaItinerarioFinInter(), FechaBean.FORMATO_DEFAULT);
				}

				List<PlanViajeRendicionBean> planillas = consultaRendicionService.listarRendicionesFechaDocumento(planViajeID, fechaDesdeEvento, fechaHastaEvento, fechaDesdeItinerario, fechaHastaItinerario);

				if (CollectionUtils.isNotEmpty(planillas)) {

					validacionOk = false;
					validacionMsg = "Existen comprobantes de gasto que est&aacute;n comprendidos en el rango de fechas que est&aacute; modificando, favor de eliminar estos comprobantes para realizar el cambio.";
				}

			}
			*/

			if (validacionOk) {

				respuesta.put("validacionOk", ViaticoConstantes.SI);
				respuesta.put("validacionMsg", validacionMsg);

			} else {

				respuesta.put("validacionOk", ViaticoConstantes.NO);
				respuesta.put("validacionMsg", validacionMsg);
			}

			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", ViaticoConstantes.NO);
			respuesta.put("msgError", StringUtils.EMPTY);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {

			log.error(e.getMessage(), e);

			// INDICADORES QUE LA PETICION AJAX CULMINO CON ERRORES.
			// NOTA: El key msgError se usa como mensaje generico de error no manejable. 
			//       Otros keys del mapa respuesta se usan para personalizar los mensajes de negocio visibles al usuario.
			respuesta.put("error", ViaticoConstantes.SI);
			respuesta.put("msgError", ViaticoConstantes.MSG_ERROR_OPERACION_NO_EFECTUADA);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} finally {

			log.debug(getClass().getName() + " Fin del metodo validarModificarViatico");
		}

		return modelAndView;
	}

	/**
	 * Metodo que determina si puede cambiar las fechas de viatico (que no existan comprobantes con fecha de documento comprendidos en el rango de fechas del viatico)
	 * 
	 * @author Juan Farro
	 * @see ModelAndView
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView validarCambiarFechasViatico(HttpServletRequest request, HttpServletResponse response) {

		log.debug(getClass().getName() + " Inicio del metodo validarCambiarFechasViatico");

		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			String codPlanViaje = StringUtils.trimToEmpty(request.getParameter("codPlanViaje"));

			String fechaDesdeEvento = StringUtils.trimToEmpty(request.getParameter("fechaDesdeEvento")); // fecha salida
			String fechaHastaEvento = StringUtils.trimToEmpty(request.getParameter("fechaHastaEvento")); // fecha retorno
			String fechaDesdeItinerario = StringUtils.trimToEmpty(request.getParameter("fechaDesdeItinerario")); // opcional si es internacional
			String fechaHastaItinerario = StringUtils.trimToEmpty(request.getParameter("fechaHastaItinerario")); // opcional si es internacional

			Date fechaDesdeEventoDate = FechaUtil.parseStringDateToDate(fechaDesdeEvento, FechaBean.FORMATO_DEFAULT);
			Date fechaHastaEventoDate = FechaUtil.parseStringDateToDate(fechaHastaEvento, FechaBean.FORMATO_DEFAULT);
			Date fechaDesdeItinerarioDate = FechaUtil.parseStringDateToDate(fechaDesdeItinerario, FechaBean.FORMATO_DEFAULT);
			Date fechaHastaItinerarioDate = FechaUtil.parseStringDateToDate(fechaHastaItinerario, FechaBean.FORMATO_DEFAULT);

			List<PlanViajeRendicionBean> planillas = consultaRendicionService.listarRendicionesFechaDocumento(codPlanViaje, fechaDesdeEventoDate, fechaHastaEventoDate, fechaDesdeItinerarioDate, fechaHastaItinerarioDate);

			respuesta.put("puedeCambiar", ViaticoConstantes.SI);
			respuesta.put("msgPuedeCambiar", StringUtils.EMPTY);

			if (CollectionUtils.isNotEmpty(planillas)) {
				respuesta.put("puedeCambiar", ViaticoConstantes.NO);
				respuesta.put("msgPuedeCambiar", "Existen comprobantes de gasto que est&aacute;n comprendidos en el rango de fechas que est&aacute; modificando, favor de eliminar estos comprobantes para realizar el cambio.");
			}

			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", ViaticoConstantes.NO);
			respuesta.put("msgError", StringUtils.EMPTY);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {

			log.error(e.getMessage(), e);

			// INDICADORES QUE LA PETICION AJAX CULMINO CON ERRORES.
			// NOTA: El key msgError se usa como mensaje generico de error no manejable. 
			//       Otros keys del mapa respuesta se usan para personalizar los mensajes de negocio visibles al usuario.
			respuesta.put("error", ViaticoConstantes.SI);
			respuesta.put("msgError", ViaticoConstantes.MSG_ERROR_OPERACION_NO_EFECTUADA);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} finally {

			log.debug(getClass().getName() + " Fin del metodo validarCambiarFechasViatico");
		}

		return modelAndView;
	}

	/**
	 * Metodo que permite validar un desplazamiento.
	 * 
	 * @author Juan Farro
	 * @see ModelAndView
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView validarDesplazamiento(HttpServletRequest request, HttpServletResponse response) {

		log.debug(getClass().getName() + " Inicio del metodo validarDesplazamiento");

		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			boolean validacionOk = true;

			if (validacionOk) {

				respuesta.put("validacionOk", ViaticoConstantes.SI);
				respuesta.put("validacionMsg", StringUtils.EMPTY);

			} else {

				respuesta.put("validacionOk", ViaticoConstantes.NO);
				respuesta.put("validacionMsg", ViaticoConstantes.DESPLAZAMIENTO_NO_VALIDO);

			}

			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", ViaticoConstantes.NO);
			respuesta.put("msgError", StringUtils.EMPTY);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {

			log.error(e.getMessage(), e);

			// INDICADORES QUE LA PETICION AJAX CULMINO CON ERRORES.
			// NOTA: El key msgError se usa como mensaje generico de error no manejable. 
			//       Otros keys del mapa respuesta se usan para personalizar los mensajes de negocio visibles al usuario.
			respuesta.put("error", ViaticoConstantes.SI);
			respuesta.put("msgError", ViaticoConstantes.MSG_ERROR_OPERACION_NO_EFECTUADA);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} finally {

			log.debug(getClass().getName() + " Fin del metodo validarDesplazamiento");
		}

		return modelAndView;
	}

	/**
	 * Metodo que permite validar el traslape fechas.
	 * 
	 * @author Juan Farro
	 * @see ModelAndView
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView validarTraslapeFechas(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			log.debug(getClass().getName() + " Inicio del metodo validarTraslapeFechas");

			String codColaborador = StringUtils.trimToNull(request.getParameter("codColaborador"));
			String fechaSalida = StringUtils.trimToNull(request.getParameter("fechaSalida"));
			String fechaRetorno = StringUtils.trimToNull(request.getParameter("fechaRetorno"));
			String codPlanViaje = StringUtils.trimToNull(request.getParameter("codPlanViaje"));
			String esComisionNacional = StringUtils.trimToNull(request.getParameter("esComisionNacional"));

			// NOTA 01: fechaSalida y fechaRetorno siempre vienen con data.
			// si en el formulario solo ingresa una fecha [f1, ] o [ ,f2], en JS se hace el artificio de siempre
			// completar un rango de fecha [f1, f1] o [f2, f2] segun el caso y enviar estas fechas a este controller

			Date fechaSalidaDate = null;
			Date fechaRetornoDate = null;

			SimpleDateFormat sdf = new SimpleDateFormat(ViaticoConstantes.DATE_FORMAT_DDMMYYYY);

			if (fechaSalida != null && FechaBean.validaFormato(fechaSalida, FechaBean.FORMATO_DEFAULT)) {
				fechaSalidaDate = sdf.parse(fechaSalida);
			}
			if (fechaRetorno != null && FechaBean.validaFormato(fechaRetorno, FechaBean.FORMATO_DEFAULT)) {
				fechaRetornoDate = sdf.parse(fechaRetorno);
			}

			// validacion E12
			List<PlanViajeBean> traslapes = null;

			// solo si tiene seteadas las fechas
			if (fechaSalidaDate != null && fechaRetornoDate != null) {
				if (StringUtils.isNotEmpty(codPlanViaje)) {
					traslapes = consultaSolicitudService.buscarTraslapeFechas(codColaborador, fechaSalidaDate, fechaRetornoDate, codPlanViaje);
				} else {
					traslapes = consultaSolicitudService.buscarTraslapeFechas(codColaborador, fechaSalidaDate, fechaRetornoDate);
				}
			}

			if (CollectionUtils.isNotEmpty(traslapes)) {

				if (StringUtils.equals(esComisionNacional, ViaticoConstantes.SI)) {

					// SI ES NACIONAL
					// quitar de la lista de fechas traslapadas, aquellas comisiones (internacionales) cuya fecha de salida corresponda a la fecha
					// de retorno de la comision (nacional) en registro

					List<PlanViajeBean> traslapesFiltro = new ArrayList<PlanViajeBean>();

					for (PlanViajeBean traslape : traslapes) {

						if (traslape == null) continue;

						boolean agregar = true;

						// si la comision traslape es internacional
						boolean esInternacional = StringUtils.equals(traslape.getTipoDestino(), ViaticoConstantes.TIPO_COMISION_INTERNACIONAL);

						if (esInternacional) {

							String fechaRetornoInternacional = FechaUtil.formatDateToDateDDMMYYYY(traslape.getFechaHoraProgRetorno());
							String fechaSalidaNacional = FechaUtil.formatDateToDateDDMMYYYY(fechaSalidaDate);

							// en el mismo dia no es una fecha de traslape
							if (StringUtils.equals(fechaRetornoInternacional, fechaSalidaNacional)) {
								agregar = false;
							}

						}

						// NOTA: por la nota01, tal vez se necesite enviar siempre la fecha final de la comision en registro por el artificio de rango de fechas que hace.
						if (agregar) {
							traslapesFiltro.add(traslape);
						}
					}

					traslapes = traslapesFiltro;

				} else {

					// SI ES INTERNACIONAL
					// quitar de la lista de fechas traslapadas, aquellas comisiones (nacionales) cuya fecha de retorno corresponda a la fecha
					// de salida de la comision (internacional) en registro

					List<PlanViajeBean> traslapesFiltro = new ArrayList<PlanViajeBean>();

					for (PlanViajeBean traslape : traslapes) {

						if (traslape == null) continue;

						boolean agregar = true;

						// si la comision traslape es internacional
						boolean esNacional = StringUtils.equals(traslape.getTipoDestino(), ViaticoConstantes.TIPO_COMISION_NACIONAL);

						if (esNacional) {

							String fechaRetornoNacional = FechaUtil.formatDateToDateDDMMYYYY(traslape.getFechaHoraProgRetorno());
							String fechaSalidaInternacional = FechaUtil.formatDateToDateDDMMYYYY(fechaSalidaDate);

							// en el mismo dia no es una fecha de traslape
							if (StringUtils.equals(fechaRetornoNacional, fechaSalidaInternacional)) {
								agregar = false;
							}

						}

						// NOTA: por la nota01, tal vez se necesite enviar siempre la fecha final de la comision en registro por el artificio de rango de fechas que hace.
						if (agregar) {
							traslapesFiltro.add(traslape);
						}
					}

					traslapes = traslapesFiltro;
				}

			}

			boolean traslapeFechas = CollectionUtils.isNotEmpty(traslapes); // traslapeFechas = false

			if (traslapeFechas) {

				PlanViajeBean traslape = traslapes.get(0);

				respuesta.put("traslapeFechas", ViaticoConstantes.SI);
				respuesta.put("traslapeFechasNroSolicitud", StringUtils.trimToEmpty(traslape.getCodPlanilla()));
				// el rango de fechas se setea en fechas programadas
				respuesta.put("traslapeFechasInicio", sdf.format(traslape.getFechaHoraProgSalida()));
				respuesta.put("traslapeFechasFinal", traslape.getFechaHoraProgRetorno() == null ? StringUtils.EMPTY : sdf.format(traslape.getFechaHoraProgRetorno()));
			}

			boolean validacionOk = !traslapeFechas;
			respuesta.put("validacionOk", validacionOk ? ViaticoConstantes.SI : ViaticoConstantes.NO); // validacionOk = false;

			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", ViaticoConstantes.NO);
			respuesta.put("msgError", StringUtils.EMPTY);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {

			log.error(e.getMessage(), e);

			// INDICADORES QUE LA PETICION AJAX CULMINO CON ERRORES.
			// NOTA: El key msgError se usa como mensaje generico de error no manejable. 
			//       Otros keys del mapa respuesta se usan para personalizar los mensajes de negocio visibles al usuario.
			respuesta.put("error", ViaticoConstantes.SI);
			respuesta.put("msgError", ViaticoConstantes.MSG_ERROR_OPERACION_NO_EFECTUADA);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} finally {

			log.debug(getClass().getName() + " Fin del metodo validarTraslapeFechas");
		}

		return modelAndView;
	}

	/**
	 * Metodo que permite guardar una solicitud de reembolso.
	 * 
	 * @author Juan Farro
	 * @see ModelAndView
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView guardarViatico(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			log.debug(getClass().getName() + " Inicio del metodo guardarViatico");

			String desplazamientosJSON = StringUtils.trimToEmpty(request.getParameter("desplazamientosJSON"));

			List<Map<String, Object>> desplazamientos = (List<Map<String, Object>>) SojoUtil.fromJson(desplazamientosJSON);

			// parseo automatico: request -> a bean de vista
			ReembolsoVO viewObject = (ReembolsoVO) fillViewObjectFromRequest(request, new ReembolsoVO());

			boolean esNacional = StringUtils.equals(viewObject.getTipoViatico(), ViaticoConstantes.VISTA_TIPO_VIATICO_NACIONAL);
			boolean esInternacional = StringUtils.equals(viewObject.getTipoViatico(), ViaticoConstantes.VISTA_TIPO_VIATICO_INTERNACIONAL);
			boolean esMayor4h = StringUtils.equals(viewObject.getDuracionComision(), ViaticoConstantes.VISTA_DURACION_COMISION_MAYOR4H);
			boolean esMenorIgual4h = StringUtils.equals(viewObject.getDuracionComision(), ViaticoConstantes.VISTA_DURACION_COMISION_MENOR_IGUAL4h);

			String anioActual = FechaUtil.obtenerAnioActual();

			// ARMANDO PLAN DE VIAJE
			PlanViajeBean planViajeBean = armarPlanViajeBeanFromVO(viewObject);

			// ARMANDO PLAN DE VIAJE CONCEPTOS (ASIGNACION FIJA)
			List<ConceptoPlanillaViaticosBean> asignacionesFijas = null;
			PlanViajeConceptoBean planViajeConcepto = null;
			List<PlanViajeConceptoBean> planViajeConceptos = new ArrayList<PlanViajeConceptoBean>();

			if (esNacional) {
				asignacionesFijas = viaticoService.obtenerConceptosViaticoFijosNacionalAsignacion();
			} else if (esInternacional) {
				asignacionesFijas = viaticoService.obtenerConceptosViaticoFijosInternacionalAsignacion();
			}

			if (CollectionUtils.isNotEmpty(asignacionesFijas)) {

				ConceptoPlanillaViaticosBean asignacion = asignacionesFijas.get(0);

				planViajeConcepto = new PlanViajeConceptoBean();

				// planViajeConcepto.setPlanViajeID(planViajeID); // se genera en registroSolicitudService
				planViajeConcepto.setConceptoID(asignacion.getCodigoConcepto());
				planViajeConcepto.setCantidad(ViaticoConstantes.UNO_DOUBLE); // confirmado, según vicky siempre va 1
				planViajeConcepto.setMonto(planViajeBean.getMontoTotal());
				planViajeConcepto.setClasificadorGasto(asignacion.getClasificadorGasto());

				planViajeConcepto.setMontoDevuelto(null);
				planViajeConcepto.setMontoManual(null);
				planViajeConcepto.setMontoReal(planViajeBean.getMontoTotal());
				planViajeConcepto.setMontoRendido(null);
				planViajeConcepto.setMontoRic(null);

				planViajeConceptos.add(planViajeConcepto);
			}

			// ARMANDO PLAN DE VIAJE DESTINOS (DESPLAZAMIENTOS EN LA VISTA)
			List<PlanViajeDestinoBean> planViajeDestinos = new ArrayList<PlanViajeDestinoBean>();
			
			// para reembolsos, se suma los dias de traslado a la fecha de retorno de ejecucion (las fechas que se guardan por debajo)
			int diasTrasladoInternacional = 0;
			
			if (CollectionUtils.isNotEmpty(desplazamientos)) {

				PlanViajeDestinoBean planViajeDestinoBean = null;

				// calcular la fecha salida inicial
				Date fechaSalida = null;
				Date fechaSalidaViatico = null;
				Double diasHoras = null;

				if (esNacional) {

					fechaSalida = ViaticoUtil.parseStringDateToDate(esMayor4h ? viewObject.getFechaSalidaNacMay4h() : viewObject.getFechaNacMen4h());

				} else if (esInternacional) {

					fechaSalida = ViaticoUtil.parseStringDateToDate(viewObject.getFechaEventoInicioInter());
				}

				// fecha de salida viatico (valor inicial)
				fechaSalidaViatico = fechaSalida;

				// en power se le resta uno al inicio, y la sgte fecha es la suma con los dias
				if (fechaSalida != null) fechaSalida = ViaticoUtil.addDiasToDate(fechaSalida, -1);

				for (Map<String, Object> desplazamiento : desplazamientos) {

					planViajeDestinoBean = new PlanViajeDestinoBean();

					// PlanViajeID y Secuencial se generan en registroReembolsoService
					planViajeDestinoBean.setMedioTransporte(ViaticoUtil.getStringFromMap(desplazamiento, "codigoMedioTransporte"));
					planViajeDestinoBean.setSedeDestino(ViaticoUtil.getStringFromMap(desplazamiento, esNacional ? "codigoLugar" : "codigoLugarDestino"));

					// viatico nacional
					if (esNacional) {

						planViajeDestinoBean.setCodigoDepartamentoDestino(ViaticoUtil.getStringFromMap(desplazamiento, "codigoDepartamento")); // campo nuevo
						planViajeDestinoBean.setProvinciaDestino(ViaticoUtil.getStringFromMap(desplazamiento, "codigoProvincia"));
						planViajeDestinoBean.setDistritoDestino(null);

						if (esMayor4h) {

							diasHoras = ViaticoUtil.getDoubleFromMap(desplazamiento, "diasViatico");
							if (diasHoras != null && fechaSalida != null) {
								fechaSalida = ViaticoUtil.addDiasToDate(fechaSalida, diasHoras.intValue());
							}

							planViajeDestinoBean.setFechaSalida(fechaSalida);
							planViajeDestinoBean.setDias(diasHoras);
							planViajeDestinoBean.setMontoDiario(ViaticoUtil.getDoubleFromMap(desplazamiento, "importeDiario"));

							// campos que solo aplican en internacional
							planViajeDestinoBean.setDiasExtra(null);
							planViajeDestinoBean.setDiasExtraTope(null);
							planViajeDestinoBean.setMontoTraslado(null);

							planViajeDestinoBean.setCodigoTarifarioInternacional(null); // codigo tarifario solo aplica en internacional
							planViajeDestinoBean.setPorcTarifarioInternacional(null); // porcentaje tarifario solo aplica en internacional

						} else if (esMenorIgual4h) {

							diasHoras = ViaticoUtil.getDoubleFromMap(desplazamiento, "horasViatico");
							fechaSalida = fechaSalidaViatico; // en viaticos menores igual a 4 horas, la hora de salida es la misma del viatico

							planViajeDestinoBean.setFechaSalida(fechaSalida);
							planViajeDestinoBean.setDias(diasHoras); // confirmado por nery que las horas se guardan en el mismo campo
							planViajeDestinoBean.setMontoDiario(ViaticoUtil.getDoubleFromMap(desplazamiento, "importeDiario"));

							// campos que solo aplican en internacional
							planViajeDestinoBean.setDiasExtra(null);
							planViajeDestinoBean.setDiasExtraTope(null);
							planViajeDestinoBean.setMontoTraslado(null);

							planViajeDestinoBean.setCodigoTarifarioInternacional(null); // codigo tarifario solo aplica en internacional
							planViajeDestinoBean.setPorcTarifarioInternacional(null); // porcentaje tarifario solo aplica en internacional
						}

					} else if (esInternacional) {

						planViajeDestinoBean.setCodigoDepartamentoDestino(null); // solo aplica para nacional // campo nuevo
						planViajeDestinoBean.setProvinciaDestino(null); // solo aplica para nacional
						planViajeDestinoBean.setDistritoDestino(null); // solo aplica para nacional

						diasHoras = ViaticoUtil.getDoubleFromMap(desplazamiento, "diasViatico");
						if (diasHoras != null && fechaSalida != null) {
							fechaSalida = ViaticoUtil.addDiasToDate(fechaSalida, diasHoras.intValue());
						}

						planViajeDestinoBean.setFechaSalida(fechaSalida);
						planViajeDestinoBean.setDias(diasHoras); // ver si se suma con dias de traslado
						planViajeDestinoBean.setMontoDiario(ViaticoUtil.getDoubleFromMap(desplazamiento, "importeDiario"));

						planViajeDestinoBean.setDiasExtra(ViaticoUtil.getIntegerFromMap(desplazamiento, "diasTraslado"));
						planViajeDestinoBean.setDiasExtraTope(ViaticoUtil.getIntegerFromMap(desplazamiento, "diasTrasladoTope"));
						planViajeDestinoBean.setMontoTraslado(ViaticoUtil.getDoubleFromMap(desplazamiento, "viajeExtGtoTras"));

						planViajeDestinoBean.setCodigoTarifarioInternacional(ViaticoUtil.getStringFromMap(desplazamiento, "codigoTarifario"));
						planViajeDestinoBean.setPorcTarifarioInternacional(ViaticoUtil.getDoubleFromMap(desplazamiento, "porcentajeTarifario"));
						
						if ( planViajeDestinoBean.getDiasExtra() != null ) {
							diasTrasladoInternacional = diasTrasladoInternacional + planViajeDestinoBean.getDiasExtra();	
						}
						
					}

					// campos nulleables
					planViajeDestinoBean.setMontoDiarioTope(ViaticoUtil.getDoubleFromMap(desplazamiento, "importeDiarioTope"));

					planViajeDestinos.add(planViajeDestinoBean);
				}
				
				// si es internacional y hay dias de traslado, sumarlos a la fecha de retorno de ejecucion (las fechas que se guardan por debajo)
				if ( esInternacional && diasTrasladoInternacional > 0 ) {
					
					Date fechaHoraEjeRetorno = planViajeBean.getFechaHoraEjeRetorno();
					
					if ( fechaHoraEjeRetorno != null ) {
						
						// sumar los dias de traslado
						Date fechaHoraEjeRetornoConTralados = ViaticoUtil.addDiasToDate(fechaHoraEjeRetorno, diasTrasladoInternacional);
						
						planViajeBean.setFechaHoraEjeRetorno(fechaHoraEjeRetornoConTralados);
					}
				}

			}

			setAuditoriaBeanHolder(request, response);

			// REGISTRAR LA SOLICITUD
			registroReembolsoService.registrarSolicitudReembolso(anioActual, viewObject.getUuoo(), planViajeBean, planViajeDestinos, planViajeConceptos);

			// INDICADORES QUE LA OPERACION SE REALIZO CON ÉXITO
			respuesta.put("seGraboOK", ViaticoConstantes.SI);

			respuesta.put("generadoCodPlanViaje", planViajeBean.getCodPlanViaje());
			respuesta.put("generadoCodPlanilla", planViajeBean.getCodPlanilla());

			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", ViaticoConstantes.NO);
			respuesta.put("msgError", StringUtils.EMPTY);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {

			log.error(e.getMessage(), e);

			// INDICADORES QUE LA PETICION AJAX CULMINO CON ERRORES.
			// NOTA: El key msgError se usa como mensaje generico de error no manejable. 
			//       Otros keys del mapa respuesta se usan para personalizar los mensajes de negocio visibles al usuario.
			respuesta.put("error", ViaticoConstantes.SI);
			respuesta.put("msgError", ViaticoConstantes.MSG_ERROR_OPERACION_NO_EFECTUADA);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} finally {

			log.debug(getClass().getName() + " Fin del metodo guardarViatico");
		}

		return modelAndView;
	}

	/**
	 * Metodo que permite modificar una solicitud de reembolso.
	 * 
	 * @author Juan Farro
	 * @see ModelAndView
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView modificarViatico(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			log.debug(getClass().getName() + " Inicio del metodo modificarViatico");

			String desplazamientosJSON = StringUtils.trimToEmpty(request.getParameter("desplazamientosJSON"));

			List<Map<String, Object>> desplazamientos = (List<Map<String, Object>>) SojoUtil.fromJson(desplazamientosJSON);

			// parseo automatico: request -> a bean de vista
			ReembolsoVO viewObject = (ReembolsoVO) fillViewObjectFromRequest(request, new ReembolsoVO());

			boolean esNacional = StringUtils.equals(viewObject.getTipoViatico(), ViaticoConstantes.VISTA_TIPO_VIATICO_NACIONAL);
			boolean esInternacional = StringUtils.equals(viewObject.getTipoViatico(), ViaticoConstantes.VISTA_TIPO_VIATICO_INTERNACIONAL);
			boolean esMayor4h = StringUtils.equals(viewObject.getDuracionComision(), ViaticoConstantes.VISTA_DURACION_COMISION_MAYOR4H);
			boolean esMenorIgual4h = StringUtils.equals(viewObject.getDuracionComision(), ViaticoConstantes.VISTA_DURACION_COMISION_MENOR_IGUAL4h);

			// ARMANDO PLAN DE VIAJE
			PlanViajeBean planViajeBean = armarPlanViajeBeanFromVO(viewObject);

			// CAMPOS ADICIONALES QUE VIENEN EN MODIFICACION
			planViajeBean.setCodPlanViaje(StringUtils.trimToNull(viewObject.getCodPlanViaje()));
			planViajeBean.setCodPlanilla(StringUtils.trimToNull(viewObject.getCodPlanilla()));

			// ARMANDO PLAN DE VIAJE CONCEPTOS (ASIGNACION FIJA)
			List<ConceptoPlanillaViaticosBean> asignacionesFijas = null;
			PlanViajeConceptoBean planViajeConcepto = null;
			List<PlanViajeConceptoBean> planViajeConceptos = new ArrayList<PlanViajeConceptoBean>();

			if (esNacional) {
				asignacionesFijas = viaticoService.obtenerConceptosViaticoFijosNacionalAsignacion();
			} else if (esInternacional) {
				asignacionesFijas = viaticoService.obtenerConceptosViaticoFijosInternacionalAsignacion();
			}

			if (CollectionUtils.isNotEmpty(asignacionesFijas)) {

				ConceptoPlanillaViaticosBean asignacion = asignacionesFijas.get(0);

				planViajeConcepto = new PlanViajeConceptoBean();

				// planViajeConcepto.setPlanViajeID(planViajeID); // se genera en registroSolicitudService
				planViajeConcepto.setConceptoID(asignacion.getCodigoConcepto());
				planViajeConcepto.setCantidad(ViaticoConstantes.UNO_DOUBLE); // confirmado, según vicky siempre va 1
				planViajeConcepto.setMonto(planViajeBean.getMontoTotal());
				planViajeConcepto.setClasificadorGasto(asignacion.getClasificadorGasto());

				planViajeConcepto.setMontoDevuelto(null);
				planViajeConcepto.setMontoManual(null);
				planViajeConcepto.setMontoReal(planViajeBean.getMontoTotal());
				planViajeConcepto.setMontoRendido(null);
				planViajeConcepto.setMontoRic(null);

				planViajeConceptos.add(planViajeConcepto);
			}

			// MANEJO DE TRASLAPES
			// si viene el flag de reseteo -> indicando que la solicitud tuvo un traslape rechazado pero cambio las fechas
			if (StringUtils.equals(viewObject.getFlagResetearTraslapeAutorizacion(), ViaticoConstantes.UNO)) {
				// solo se actualiza el campo autorizacion, porque si tiene un traslape rechazado puede cambiar a fechas no traslapadas
				planViajeBean.setIndicadorAutorizacion(ViaticoConstantes.INDICADOR_AUTORIZACION_SIN_AUTORIZAR);
			}

			// ARMANDO PLAN DE VIAJE DESTINOS (DESPLAZAMIENTOS EN LA VISTA)
			List<PlanViajeDestinoBean> planViajeDestinos = new ArrayList<PlanViajeDestinoBean>();

			// para reembolsos, se suma los dias de traslado a la fecha de retorno de ejecucion (las fechas que se guardan por debajo)
			int diasTrasladoInternacional = 0;
			
			if (CollectionUtils.isNotEmpty(desplazamientos)) {

				PlanViajeDestinoBean planViajeDestinoBean = null;

				// calcular la fecha salida inicial
				Date fechaSalida = null;
				Date fechaSalidaViatico = null;
				Double diasHoras = null;

				if (esNacional) {

					fechaSalida = ViaticoUtil.parseStringDateToDate(esMayor4h ? viewObject.getFechaSalidaNacMay4h() : viewObject.getFechaNacMen4h());

				} else if (esInternacional) {

					fechaSalida = ViaticoUtil.parseStringDateToDate(viewObject.getFechaEventoInicioInter());
				}

				// fecha de salida viatico (valor inicial)
				fechaSalidaViatico = fechaSalida;

				// en power se le resta uno al inicio, y la sgte fecha es la suma con los dias
				if (fechaSalida != null) fechaSalida = ViaticoUtil.addDiasToDate(fechaSalida, -1);

				for (Map<String, Object> desplazamiento : desplazamientos) {

					planViajeDestinoBean = new PlanViajeDestinoBean();

					// PlanViajeID y Secuencial se generan en registroReembolsoService
					planViajeDestinoBean.setMedioTransporte(ViaticoUtil.getStringFromMap(desplazamiento, "codigoMedioTransporte"));
					planViajeDestinoBean.setSedeDestino(ViaticoUtil.getStringFromMap(desplazamiento, esNacional ? "codigoLugar" : "codigoLugarDestino"));

					// viatico nacional
					if (esNacional) {

						planViajeDestinoBean.setCodigoDepartamentoDestino(ViaticoUtil.getStringFromMap(desplazamiento, "codigoDepartamento")); // campo nuevo
						planViajeDestinoBean.setProvinciaDestino(ViaticoUtil.getStringFromMap(desplazamiento, "codigoProvincia"));
						planViajeDestinoBean.setDistritoDestino(null);

						if (esMayor4h) {

							diasHoras = ViaticoUtil.getDoubleFromMap(desplazamiento, "diasViatico");
							if (diasHoras != null && fechaSalida != null) {
								fechaSalida = ViaticoUtil.addDiasToDate(fechaSalida, diasHoras.intValue());
							}

							planViajeDestinoBean.setFechaSalida(fechaSalida);
							planViajeDestinoBean.setDias(diasHoras);
							planViajeDestinoBean.setMontoDiario(ViaticoUtil.getDoubleFromMap(desplazamiento, "importeDiario"));

							// campos que solo aplican en internacional
							planViajeDestinoBean.setDiasExtra(null);
							planViajeDestinoBean.setDiasExtraTope(null);
							planViajeDestinoBean.setMontoTraslado(null);

							planViajeDestinoBean.setCodigoTarifarioInternacional(null); // codigo tarifario solo aplica en internacional
							planViajeDestinoBean.setPorcTarifarioInternacional(null); // porcentaje tarifario solo aplica en internacional

						} else if (esMenorIgual4h) {

							diasHoras = ViaticoUtil.getDoubleFromMap(desplazamiento, "horasViatico");
							fechaSalida = fechaSalidaViatico; // en viaticos menores igual a 4 horas, la hora de salida es la misma del viatico

							planViajeDestinoBean.setFechaSalida(fechaSalida);
							planViajeDestinoBean.setDias(diasHoras); // confirmado por nery que las horas se guardan en el mismo campo
							planViajeDestinoBean.setMontoDiario(ViaticoUtil.getDoubleFromMap(desplazamiento, "importeDiario"));

							// campos que solo aplican en internacional
							planViajeDestinoBean.setDiasExtra(null);
							planViajeDestinoBean.setDiasExtraTope(null);
							planViajeDestinoBean.setMontoTraslado(null);

							planViajeDestinoBean.setCodigoTarifarioInternacional(null); // codigo tarifario solo aplica en internacional
							planViajeDestinoBean.setPorcTarifarioInternacional(null); // porcentaje tarifario solo aplica en internacional
						}

					} else if (esInternacional) {

						planViajeDestinoBean.setCodigoDepartamentoDestino(null); // solo aplica para nacional // campo nuevo
						planViajeDestinoBean.setProvinciaDestino(null); // solo aplica para nacional
						planViajeDestinoBean.setDistritoDestino(null); // solo aplica para nacional

						diasHoras = ViaticoUtil.getDoubleFromMap(desplazamiento, "diasViatico");
						if (diasHoras != null && fechaSalida != null) {
							fechaSalida = ViaticoUtil.addDiasToDate(fechaSalida, diasHoras.intValue());
						}

						planViajeDestinoBean.setFechaSalida(fechaSalida);
						planViajeDestinoBean.setDias(diasHoras); // ver si se suma con dias de traslado
						planViajeDestinoBean.setMontoDiario(ViaticoUtil.getDoubleFromMap(desplazamiento, "importeDiario"));

						planViajeDestinoBean.setDiasExtra(ViaticoUtil.getIntegerFromMap(desplazamiento, "diasTraslado"));
						planViajeDestinoBean.setDiasExtraTope(ViaticoUtil.getIntegerFromMap(desplazamiento, "diasTrasladoTope"));
						planViajeDestinoBean.setMontoTraslado(ViaticoUtil.getDoubleFromMap(desplazamiento, "viajeExtGtoTras"));

						planViajeDestinoBean.setCodigoTarifarioInternacional(ViaticoUtil.getStringFromMap(desplazamiento, "codigoTarifario"));
						planViajeDestinoBean.setPorcTarifarioInternacional(ViaticoUtil.getDoubleFromMap(desplazamiento, "porcentajeTarifario"));

						if ( planViajeDestinoBean.getDiasExtra() != null ) {
							diasTrasladoInternacional = diasTrasladoInternacional + planViajeDestinoBean.getDiasExtra();	
						}						
						
					}

					// campos nulleables
					planViajeDestinoBean.setMontoDiarioTope(ViaticoUtil.getDoubleFromMap(desplazamiento, "importeDiarioTope"));

					planViajeDestinos.add(planViajeDestinoBean);
				}
				
				// si es internacional y hay dias de traslado, sumarlos a la fecha de retorno de ejecucion (las fechas que se guardan por debajo)
				if ( esInternacional && diasTrasladoInternacional > 0 ) {
					
					Date fechaHoraEjeRetorno = planViajeBean.getFechaHoraEjeRetorno();
					
					if ( fechaHoraEjeRetorno != null ) {
						
						// sumar los dias de traslado
						Date fechaHoraEjeRetornoConTralados = ViaticoUtil.addDiasToDate(fechaHoraEjeRetorno, diasTrasladoInternacional);
						
						planViajeBean.setFechaHoraEjeRetorno(fechaHoraEjeRetornoConTralados);
					}
				}				

			}

			setAuditoriaBeanHolder(request, response);

			// ACTUALIZAR LA SOLICITUD
			registroReembolsoService.actualizarSolicitudReembolso(planViajeBean, planViajeDestinos, planViajeConceptos);

			// INDICADORES QUE LA OPERACION SE REALIZO CON ÉXITO
			respuesta.put("seGraboOK", ViaticoConstantes.SI);

			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", ViaticoConstantes.NO);
			respuesta.put("msgError", StringUtils.EMPTY);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {

			log.error(e.getMessage(), e);

			// INDICADORES QUE LA PETICION AJAX CULMINO CON ERRORES.
			// NOTA: El key msgError se usa como mensaje generico de error no manejable. 
			//       Otros keys del mapa respuesta se usan para personalizar los mensajes de negocio visibles al usuario.
			respuesta.put("error", ViaticoConstantes.SI);
			respuesta.put("msgError", ViaticoConstantes.MSG_ERROR_OPERACION_NO_EFECTUADA);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} finally {

			log.debug(getClass().getName() + " Fin del metodo modificarViatico");
		}

		return modelAndView;
	}

	/**
	 * Metodo que permite validar enviar una solicitud de reembolso (ultimas validaciones lado servidor).
	 * 
	 * @author Juan Farro
	 * @see ModelAndView
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView validarEnviarSolicitudViatico(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			log.debug(getClass().getName() + " Inicio del metodo validarEnviarSolicitudViatico");

			// flags indicadores de validaciones
			boolean validacionOk = true;
			String validacionMsg = StringUtils.EMPTY;

			// parseo automatico: request -> a bean de vista (datos de la vista)
			ReembolsoVO registroVO = (ReembolsoVO) fillViewObjectFromRequest(request, new ReembolsoVO());

			// listado de archivos adjuntos
			List<RegistroArchivosFisicoBean> listArchivosAdjuntos = null;

			// validar el estado de la solicitud para enviar
			if (validacionOk && !ReembolsoUtil.puedeEnviarSolicitudReembolso(registroVO.getCodigoEstadoViatico())) {
				validacionOk = false;
				validacionMsg = "No puede enviar esta solicitud de reembolso. Estado de vi&aacute;tico no permitido.";
			}

			// datos de la BD (se necesita el número de registro de archivo que no se maneja en la vista)
			PlanViajeBean planViaje = consultaSolicitudService.buscarPlanViaje(registroVO.getCodPlanViaje());
			if (planViaje == null) throw new Exception("Solicitud no existe");

			// VALIDAR que cuente con la autorizacion periodo superior a 15 dias
			boolean esNacional = StringUtils.equals(registroVO.getTipoViatico(), ViaticoConstantes.VISTA_TIPO_VIATICO_NACIONAL);

			String numeroDiasHabiles = StringUtils.trimToEmpty(registroVO.getDiasNacMay4hHabiles());

			if (validacionOk && esNacional && NumberUtils.isNumber(numeroDiasHabiles)) {

				// caso adicional: si es ampliacion debe considerar los dias habiles de la planilla asociada
				boolean esMotivoAmpliacion = StringUtils.equals(registroVO.getMotivoAmpliacion(), ViaticoConstantes.MOTIVO_AMPLIACION_AMPLIACION_COMISION);

				if (esMotivoAmpliacion) {

					// buscar la planilla asociada
					PlanViajeBean planViajeAsociada = consultaSolicitudService.buscarPlanViaje(registroVO.getPlanillaAsociada());

					if (planViajeAsociada != null) {

						Map<String, String> dataJSON = consultaReembolsoService.obtenerDatosPlanillaAsociada(planViajeAsociada);

						int numeroDiasHabilesAsoc = MapUtils.getIntValue(dataJSON, "numeroDiasHabiles");

						if (Integer.parseInt(numeroDiasHabiles) + numeroDiasHabilesAsoc > ViaticoConstantes.MAXIMO_NRO_DIAS_HABILES) {

							boolean cuentaConSustento15Dias = false;

							// buscar en los archivos adjuntos que tenga el sustento
							if (StringUtils.isNotBlank(planViaje.getNumeroRegistroArchivo())) {

								// buscar los archivos adjuntos (carga lazy)
								if (listArchivosAdjuntos == null) {
									Map<String, Object> paramsBuscar = new HashMap<String, Object>();
									paramsBuscar.put("num_reg", planViaje.getNumeroRegistroArchivo());
									listArchivosAdjuntos = (List<RegistroArchivosFisicoBean>) registroArchivosService.listarArchivosAdjuntos(paramsBuscar);
								}

								// buscar sustento por mayores a 15 dias
								if (CollectionUtils.isNotEmpty(listArchivosAdjuntos)) {

									for (RegistroArchivosFisicoBean archivo : listArchivosAdjuntos) {

										if (archivo == null) continue;

										// tipo de documento: JUSTIFICACION DE AMPLIACION DE DIAS DE COMISION
										if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty(archivo.getTipo_doc()), ViaticoConstantes.TIPO_ARCHIVO_JUSTIFICACION_AMPLIACION_DIAS_COMISION)) {
											cuentaConSustento15Dias = true;
											break;
										}

									}

								}

							}

							if (!cuentaConSustento15Dias) {

								validacionOk = false;
								validacionMsg = "La sumatoria de los d&iacute;as de la planilla de vi&aacute;ticos NRO_PLANILLA y los d&iacute;as de reembolso de esta planilla de reembolso superan los NRO_DIAS d&iacute;as h&aacute;biles, favor de adjuntar el sustento";

								validacionMsg = validacionMsg.replace("NRO_PLANILLA", StringUtils.trimToEmpty(planViajeAsociada.getCodPlanilla()));
								validacionMsg = validacionMsg.replace("NRO_DIAS", String.valueOf(ViaticoConstantes.MAXIMO_NRO_DIAS_HABILES));
							}

						}

					}

				} else {

					// caso normal: no es ampliacion
					if (Integer.parseInt(numeroDiasHabiles) > ViaticoConstantes.MAXIMO_NRO_DIAS_HABILES) {

						boolean cuentaConSustento15Dias = false;

						// buscar en los archivos adjuntos que tenga el sustento
						if (StringUtils.isNotBlank(planViaje.getNumeroRegistroArchivo())) {

							// buscar los archivos adjuntos (carga lazy)
							if (listArchivosAdjuntos == null) {
								Map<String, Object> paramsBuscar = new HashMap<String, Object>();
								paramsBuscar.put("num_reg", planViaje.getNumeroRegistroArchivo());
								listArchivosAdjuntos = (List<RegistroArchivosFisicoBean>) registroArchivosService.listarArchivosAdjuntos(paramsBuscar);
							}

							// buscar sustento por mayores a 15 dias
							if (CollectionUtils.isNotEmpty(listArchivosAdjuntos)) {

								for (RegistroArchivosFisicoBean archivo : listArchivosAdjuntos) {

									if (archivo == null) continue;

									// tipo de documento: JUSTIFICACION DE AMPLIACION DE DIAS DE COMISION
									if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty(archivo.getTipo_doc()), ViaticoConstantes.TIPO_ARCHIVO_JUSTIFICACION_AMPLIACION_DIAS_COMISION)) {
										cuentaConSustento15Dias = true;
										break;
									}

								}

							}

						}

						if (!cuentaConSustento15Dias) {
							validacionOk = false;
							validacionMsg = "Debe adjuntar la autorizaci&oacute;n para registrar vi&aacute;ticos por un periodo superior a los " + ViaticoConstantes.MAXIMO_NRO_DIAS_HABILES + " d&iacute;as h&aacute;biles";
						}

					}

				}

			}

			// VALIDAR que cuente el sustento de traslape de fechas: si presenta traslape (traslape=1) y
			// tiene autorizacion pendiente (ind_autorizacion=0) o ha sido rechazada (ind_autorizacion=2) no lo deja pasar.
			if (validacionOk && StringUtils.equals(registroVO.getIndicadorTraslape(), ViaticoConstantes.INDICADOR_TRASLAPE_SI)) {

				String autorizacion = registroVO.getIndicadorAutorizacion();

				// si tiene autorizacion rechazada no lo deja
				// NOTA: el ind_autorizacion=2 no deberia llegar a este punto pero se valida igual por seguridad
				if (validacionOk && StringUtils.equals(autorizacion, ViaticoConstantes.INDICADOR_AUTORIZACION_RECHAZADO)) {
					validacionOk = false;
					validacionMsg = "No puede enviar esta solicitud de reembolso. Su solicitud de traslape de fechas ha sido rechazada";
				}

				// ANTES podia enviar una solicitud con traslape y autorizacion pendiente, si adjuntaba el documento de sustento.
				// AHORA debe adjuntarla, pero ademas esperar aque el registrador universal la autorice
				if (validacionOk && StringUtils.equals(autorizacion, ViaticoConstantes.INDICADOR_AUTORIZACION_SIN_AUTORIZAR)) {
					validacionOk = false;
					validacionMsg = "No puede enviar esta solicitud de reembolso. Su solicitud de traslape de fechas est&aacute; pendiente de autorizaci&oacute;n";
				}

			}

			// VALIDAR que si es configuracion manual, debe adjuntar el formato de la solicitud
			String tipoConfiguracion = viaticosProcesoSingleton.obtenerProceso();
			boolean esConfiguracionManual = StringUtils.equals(tipoConfiguracion, ViaticoConstantes.TIPO_CONFIGURACION_MANUAL);

			if (validacionOk && esConfiguracionManual) {

				boolean cuentaConFormatoSolicitudReembolso = false;

				// buscar en los archivos adjuntos que tenga el sustento
				if (StringUtils.isNotBlank(planViaje.getNumeroRegistroArchivo())) {

					// buscar los archivos adjuntos (carga lazy)
					if (listArchivosAdjuntos == null) {
						Map<String, Object> paramsBuscar = new HashMap<String, Object>();
						paramsBuscar.put("num_reg", planViaje.getNumeroRegistroArchivo());
						listArchivosAdjuntos = (List<RegistroArchivosFisicoBean>) registroArchivosService.listarArchivosAdjuntos(paramsBuscar);
					}

					// buscar sustento por traslape de fechas
					if (CollectionUtils.isNotEmpty(listArchivosAdjuntos)) {

						for (RegistroArchivosFisicoBean archivo : listArchivosAdjuntos) {

							if (archivo == null) continue;

							// tipo de documento: TIPO ARCHIVO DE SOLICITUD DE REEMBOLSO
							if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty(archivo.getTipo_doc()), ViaticoConstantes.TIPO_ARCHIVO_SOLICITUD_REEMBOLSO)) {
								cuentaConFormatoSolicitudReembolso = true;
								break;
							}

						}

					}

				}

				if (!cuentaConFormatoSolicitudReembolso) {
					validacionOk = false;
					validacionMsg = "No es posible realizar el env&iacute;o debido a que no ha adjuntado la solicitud de reembolso firmada.";
				}

			}

			// VALIDAR QUE LA SUMATORIA DE LOS COMPROBANTES DE GASTOS REGISTRADOS (CONCEPTOS FIJOS) SEA IGUAL AL MONTO ASIGNADO
			if (validacionOk) {
				
				BigDecimal montoTotal = new BigDecimal(NumeroUtil.formatearMonedaMontoToDecimal(null, 2, planViaje.getMontoTotal()));
				BigDecimal sumaComprobantesGasto = consultaReembolsoService.obtenerMontoComprobanteGasto(planViaje.getCodPlanViaje());

				if (montoTotal != null && sumaComprobantesGasto != null) {

					boolean sonIguales = montoTotal.compareTo(sumaComprobantesGasto) == 0;

					if (!sonIguales) {

						validacionOk = false;
						validacionMsg = "El total del importe de los comprobantes de gasto por asignaci&oacute;n de viaticos NACIONAL/INTERNACIONAL es MONEDA_01 MONTO_01, favor de corregir porque este no debe pasar el MONEDA_02 MONTO_02";

						String moneda = StringUtils.trimToEmpty(planViaje.getMoneda());

						validacionMsg = validacionMsg.replace("MONEDA_01", moneda);
						validacionMsg = validacionMsg.replace("MONEDA_02", moneda);

						validacionMsg = validacionMsg.replace("MONTO_01", NumeroUtil.formatearMontoToDecimal(2, sumaComprobantesGasto));
						validacionMsg = validacionMsg.replace("MONTO_02", NumeroUtil.formatearMontoToDecimal(2, montoTotal));
					}

				}

			}
			
			respuesta.put("validacionOk", validacionOk ? ViaticoConstantes.SI : ViaticoConstantes.NO);
			respuesta.put("validacionMsg", validacionMsg);

			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", ViaticoConstantes.NO);
			respuesta.put("msgError", StringUtils.EMPTY);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {

			log.error(e.getMessage(), e);

			// INDICADORES QUE LA PETICION AJAX CULMINO CON ERRORES.
			// NOTA: El key msgError se usa como mensaje generico de error no manejable. 
			//       Otros keys del mapa respuesta se usan para personalizar los mensajes de negocio visibles al usuario.
			respuesta.put("error", ViaticoConstantes.SI);
			respuesta.put("msgError", ViaticoConstantes.MSG_ERROR_OPERACION_NO_EFECTUADA);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} finally {

			log.debug(getClass().getName() + " Fin del metodo validarEnviarSolicitudViatico");
		}

		return modelAndView;
	}

	/**
	 * Metodo que permite enviar una solicitud viatico.
	 * 
	 * @author Juan Farro
	 * @see ModelAndView
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView enviarSolicitudViatico(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			log.debug(getClass().getName() + " Inicio del metodo enviarSolicitudViatico");

			// usuario en session
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");

			// parseo automatico: request -> a bean de vista
			ReembolsoVO viewObject = (ReembolsoVO) fillViewObjectFromRequest(request, new ReembolsoVO());

			String codPlanViaje = StringUtils.trimToNull(viewObject.getCodPlanViaje());

			setAuditoriaBeanHolder(request, response);

			// datos del colaborador que esta en session (el atributo número registrador del formulario)
			MaestroPersonalBean enviador = registroPersonalService.obtenerPersonaxRegistro(usuarioBean.getNroRegistro());
			// MaestroPersonalBean enviador = registroPersonalService.obtenerPersonaxRegistro(viewObject.getNumeroRegistroRegistrador());

			if (enviador == null) throw new Exception("Colaborador no existe");

			boolean envioExito = registroReembolsoService.enviarSolicitudReembolso(codPlanViaje, enviador.getCodigoEmpleado(), viaticosProcesoSingleton.obtenerProceso());

			if (envioExito) {

				SolicitudDTO solicitudDTO = viaticoConsultaService.obtenerPlanViajeToNotificacion(codPlanViaje);

				viaticoMensajeriaService.enviarNotificacionRegistroSolicitud(solicitudDTO);
			}

			if (envioExito) {

				respuesta.put("seEnvioOK", ViaticoConstantes.SI);
				respuesta.put("envioError", StringUtils.EMPTY);

				boolean esConfiguracionManual = StringUtils.equals(viaticosProcesoSingleton.obtenerProceso(), ViaticoConstantes.TIPO_CONFIGURACION_MANUAL);

				String estadoViatico = esConfiguracionManual ? ViaticoConstantes.ESTADO_REEMBOLSO_AUTORIZADO : ViaticoConstantes.ESTADO_REEMBOLSO_POR_AUTORIZAR;

				if ( esConfiguracionManual ) {
					respuesta.put("msgEnvioOK", "Su solicitud de reembolso ha sido remitida a la gerencia financiera para la atenci&oacute;n correspondiente");	
				} else {
					respuesta.put("msgEnvioOK", "Su solicitud de reembolso ha sido remitida para la autorizaci&oacute;n correspondiente");	
				}
				
				respuesta.put("estadoViatico", estadoViatico);
				respuesta.put("estadoViaticoDescripcion", consultaSolicitudService.obtenerDescripcionSysEstado(ViaticoConstantes.ESTADO_REEMBOLSO_NOMBRE_TABLA, estadoViatico));

			} else {

				respuesta.put("seEnvioOK", ViaticoConstantes.NO);
				respuesta.put("envioError", "No se pudo realizar el env&iacute;o.");
			}

			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", ViaticoConstantes.NO);
			respuesta.put("msgError", StringUtils.EMPTY);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {

			log.error(e.getMessage(), e);

			// INDICADORES QUE LA PETICION AJAX CULMINO CON ERRORES.
			// NOTA: El key msgError se usa como mensaje generico de error no manejable. 
			//       Otros keys del mapa respuesta se usan para personalizar los mensajes de negocio visibles al usuario.
			respuesta.put("error", ViaticoConstantes.SI);
			respuesta.put("msgError", ViaticoConstantes.MSG_ERROR_OPERACION_NO_EFECTUADA);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} finally {

			log.debug(getClass().getName() + " Fin del metodo enviarSolicitudViatico");
		}

		return modelAndView;
	}

	/**
	 * Metodo que permite setear los parametros de una peticion con los atributos del bean
	 * 
	 * @author Juan Farro
	 * @see ModelAndView
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param viewObject objeto a setear atributos
	 * @return objeto con los parametros de la peticion
	 */
	private Object fillViewObjectFromRequest(HttpServletRequest request, Object viewObject) {

		// llenar en viewObject lo que viene del request
		PropertyUtilsBean pub = BeanUtilsBean.getInstance().getPropertyUtils();

		Enumeration paramNames = request.getParameterNames();
		while (paramNames.hasMoreElements()) {

			// obtener el nombre del parametro
			String nombreParametro = String.valueOf(paramNames.nextElement());

			// si el bean viewObject contiene el atributo y su setter para nombreParametro
			if (pub.isWriteable(viewObject, nombreParametro)) {
				try {
					BeanUtils.setProperty(viewObject, nombreParametro, request.getParameter(nombreParametro));
				} catch (Exception e) {
					// log.debug(e.getMessage(), e);
				} finally {
				}
			}

		}

		// retornar el object seteado con los parametros del request
		return viewObject;
	}

	/**
	 * Metodo que permite armar el objeto vista ReembolsoVO a partir del codigo de planilla.
	 * 
	 * @author Juan Farro
	 * @see ModelAndView
	 * @param codPlanilla codigo de planilla de viatico
	 * @return objeto vista ReembolsoVO
	 */
	private ReembolsoVO armarRegistroVO(String codPlanilla) {

		boolean customMessage = false;
		String errorMessage = StringUtils.EMPTY;

		ReembolsoVO registroVO = new ReembolsoVO();

		try {

			PlanViajeBean planViaje = consultaSolicitudService.buscarPlanViajePlanilla(codPlanilla);

			if (planViaje == null) {
				customMessage = true;
				throw new Exception("Solicitud no existe");
			}

			List<PlanViajeDestinoBean> planViajeDestinos = consultaSolicitudService.buscarPlanViajeDestinos(planViaje.getCodPlanViaje());

			// colaborador asociado al viatico
			MaestroPersonalBean colaborador = registroPersonalService.obtenerPersonaxCodigo(planViaje.getCodTrabajador());

			if (colaborador == null) {
				customMessage = true;
				throw new Exception("Colaborador asociado al vi&aacute;tico no existe");
			}

			SimpleDateFormat sdf = new SimpleDateFormat(ViaticoConstantes.DATE_FORMAT_DDMMYYYY);

			boolean esNacional = StringUtils.equals(planViaje.getTipoDestino(), ViaticoConstantes.TIPO_COMISION_NACIONAL);
			boolean esInternacional = StringUtils.equals(planViaje.getTipoDestino(), ViaticoConstantes.TIPO_COMISION_INTERNACIONAL);
			boolean esMenorIgual4h = StringUtils.equals(planViaje.getIndicadorHoras(), ViaticoConstantes.INDICADOR_HORAS_HORAS); // INDICADOR_HORAS_HORAS 1:horas, 0:dias
			boolean esMayor4h = !StringUtils.equals(planViaje.getIndicadorHoras(), ViaticoConstantes.INDICADOR_HORAS_HORAS); // INDICADOR_HORAS_HORAS 1:horas, 0:dias

			String codigoDependencia = StringUtils.trimToEmpty(colaborador.getCodigoDependencia());

			registroVO.setFlagDoAction(ViaticoConstantes.VISTA_MODIFICAR);

			registroVO.setCodPlanilla(planViaje.getCodPlanilla());
			registroVO.setCodPlanViaje(planViaje.getCodPlanViaje());
			registroVO.setEstadoViatico(consultaSolicitudService.obtenerDescripcionSysEstado(ViaticoConstantes.ESTADO_REEMBOLSO_NOMBRE_TABLA, planViaje.getEstadoPlanViaje()));
			registroVO.setCodigoEstadoViatico(planViaje.getEstadoPlanViaje());
			registroVO.setNumeroRegistro(colaborador.getNumero_registro());
			registroVO.setNombreColaborador(colaborador.getNombre_completo());
			registroVO.setUuoo(colaborador.getUuoo());
			registroVO.setCodigoDependencia(codigoDependencia);
			registroVO.setDescripcionDependencia(colaborador.getDependencia() + ViaticoConstantes.ESPACIO + ViaticoConstantes.SIGNO_MINUS + ViaticoConstantes.ESPACIO + buscarIntendencia(colaborador.getUuoo()));

			if (StringUtils.isNotBlank(planViaje.getPresupuestoMeta())) {

				registroVO.setCodigoMetaPresupuestal(planViaje.getPresupuestoMeta());

				MetasBean meta = viaticoGeneralService.obtenerMeta(planViaje.getPresupuestoMeta(), planViaje.getPresupuestoAnno());
				if (meta != null) {
					registroVO.setMetaPresupuestal(meta.getSecuFuncSfu() + ViaticoConstantes.ESPACIO + ViaticoConstantes.SIGNO_MINUS + ViaticoConstantes.ESPACIO + meta.getCodiLargMet() + ViaticoConstantes.ESPACIO + meta.getDescLargMet());
				}
			}

			registroVO.setCodigoColaborador(colaborador.getCodigoEmpleado());
			registroVO.setCodigoNivelColaborador(planViaje.getCodigoNivel());
			registroVO.setCodigoNivelViaticoColaborador(planViaje.getNiveViatNvi());
			registroVO.setCodigoSedeColaborador(planViaje.getSedePlanViaje());

			// indicadores de traslape y autorizacion de traslape
			registroVO.setIndicadorTraslape(planViaje.getIndicadorTraslape());
			registroVO.setIndicadorAutorizacion(planViaje.getIndicadorAutorizacion());

			registroVO.setOrigen(planViaje.getOrigen());

			// el concepto de registrador y registrador universal no aplican,
			// ya que al modificar el boton de cambiar registro se deshabilita
			registroVO.setFlagRegistrador(ViaticoConstantes.CERO);
			registroVO.setFlagRegistradorUniversal(ViaticoConstantes.CERO);
			registroVO.setCodigoTipoUUOOViatico(ViaticoConstantes.BUSCAR_COLABORADOR);
			registroVO.setCodigoTipoUsuarioViatico(ViaticoConstantes.BUSCAR_COLABORADOR);

			// y siempre guarda la informacion de su registrador inicial
			registroVO.setNumeroRegistroRegistrador(planViaje.getNumeroRegistro());
			registroVO.setCodigoRegistrador(planViaje.getCodigoRegistrador());

			registroVO.setCodigoEstadoColaborador(colaborador.getCodigoEstado());
			registroVO.setEstadoColaborador(colaborador.getEstado());

			registroVO.setMotivoComision(planViaje.getSolicitanteViaje());
			registroVO.setObservacion(planViaje.getObservacionSolicitud());
			registroVO.setCanalAtencion(consultaSolicitudService.obtenerDescripcionParametro(ViaticoConstantes.CANAL_ATENCION_CODIGO_PARAMETRO, planViaje.getIndicadorRuta()));
			registroVO.setCodigoCanalAtencion(planViaje.getIndicadorRuta());

			if (esNacional) {

				registroVO.setFechaMaximaRendicionNac(FechaUtil.formatDateToDateDDMMYYYY(planViaje.getFechaMaxRendicion()));

				registroVO.setViaticosProgramadosNac(planViaje.getPoaProgramado());

				if (esMayor4h) {

					// seccion DETALLE DE VIATICO - Nacional > 4h -> NacMay4h
					registroVO.setFechaSalidaNacMay4h(FechaUtil.formatDateToDateDDMMYYYY(planViaje.getFechaHoraProgSalida()));

					registroVO.setFechaRetornoNacMay4h(FechaUtil.formatDateToDateDDMMYYYY(planViaje.getFechaHoraProgRetorno()));

					if (planViaje.getFechaHoraProgSalida() != null && planViaje.getFechaHoraProgRetorno() != null) {

						Date fechaSalida = planViaje.getFechaHoraProgSalida();
						Date fechaRetorno = planViaje.getFechaHoraProgRetorno(); // este puede ser null

						if (fechaSalida != null && fechaRetorno != null) {

							// DIASNACMAY4H Dias
							// registroVO.setDiasNacMay4h(String.valueOf(ViaticoUtil.restarDias(fechaRetorno, fechaSalida)));
							if (planViaje.getNumeroDias() != null) {
								registroVO.setDiasNacMay4h(String.valueOf(planViaje.getNumeroDias().intValue()));
							}

							// DIASNACMAY4H Dias habiles
							registroVO.setDiasNacMay4hHabiles(String.valueOf(viaticoService.calcularDiasHabiles(fechaSalida, fechaRetorno)));
						}

					}

				} else {

					// seccion DETALLE DE VIATICO - Nacional <= 4h -> NacMen4h
					registroVO.setFechaNacMen4h(FechaUtil.formatDateToDateDDMMYYYY(planViaje.getFechaHoraProgSalida()));

					// horas y minutos de salida
					if (planViaje.getFechaHoraProgSalida() != null) {

						int horasSalida = ViaticoUtil.extraerHoras24H(planViaje.getFechaHoraProgSalida());
						int minutosSalida = ViaticoUtil.extraerMinutos(planViaje.getFechaHoraProgSalida());

						registroVO.setSalidaNacMen4h(ViaticoUtil.formatearHorasMinutos(horasSalida, minutosSalida)); // salida
					}

					// horas y minutos de retorno
					if (planViaje.getFechaHoraProgRetorno() != null) {

						int horasRetorno = ViaticoUtil.extraerHoras24H(planViaje.getFechaHoraProgRetorno());
						int minutosRetorno = ViaticoUtil.extraerMinutos(planViaje.getFechaHoraProgRetorno());

						registroVO.setRetornoNacMen4h(ViaticoUtil.formatearHorasMinutos(horasRetorno, minutosRetorno)); // retorno
					}

					// calcular la diferencia redondeado a 1 digito
					// double diferenciaMins = ((horasRetorno * 60.0 + minutosRetorno) - (horasSalida * 60.0 + minutosSalida)) / 60.0;

					// registroVO.setHorasNacMen4h(ViaticoUtil.formatearNumeros(1, new BigDecimal(diferenciaMins))); // horas
					if (planViaje.getNumeroHoras() != null) {
						registroVO.setHorasNacMen4h(ViaticoUtil.formatearNumeros(ViaticoConstantes.UNO_INT, planViaje.getNumeroHoras()));
					}

				}

			}

			// seccion DETALLE DE VIATICO - Internacional -> Int
			if (esInternacional) {

				registroVO.setFechaItinerarioInicioInter(FechaUtil.formatDateToDateDDMMYYYY(planViaje.getFechaItinerarioSalida()));

				registroVO.setFechaItinerarioFinInter(FechaUtil.formatDateToDateDDMMYYYY(planViaje.getFechaItinerarioRetorno()));

				registroVO.setFechaEventoInicioInter(FechaUtil.formatDateToDateDDMMYYYY(planViaje.getFechaHoraProgSalida()));

				registroVO.setFechaEventoFinInter(FechaUtil.formatDateToDateDDMMYYYY(planViaje.getFechaHoraProgRetorno()));

				Date fechaSalida = planViaje.getFechaHoraProgSalida();
				Date fechaRetorno = planViaje.getFechaHoraProgRetorno(); // este puede ser null

				if (fechaSalida != null && fechaRetorno != null) {

					// dias
					// registroVO.setDiasInter(String.valueOf(ViaticoUtil.restarDias(fechaRetorno, fechaSalida)));
					if (planViaje.getNumeroDias() != null) {
						registroVO.setDiasInter(String.valueOf(planViaje.getNumeroDias().intValue()));
					}

					// dias habiles
					registroVO.setDiasInterHabiles(String.valueOf(viaticoService.calcularDiasHabiles(fechaSalida, fechaRetorno)));

				}

				registroVO.setFechaMaximaRendicionInter(FechaUtil.formatDateToDateDDMMYYYY(planViaje.getFechaMaxRendicion()));

				registroVO.setFechaResolucionInter(FechaUtil.formatDateToDateDDMMYYYY(planViaje.getInternacionalFechaResolucion()));

				registroVO.setNroResolucionInter(planViaje.getInternacionalNroResolucion());

				if (planViaje.getInternacionalMontoResolucion() != null) {
					registroVO.setMontoResolucionInter(ViaticoUtil.formatearNumeros(ViaticoConstantes.NRO_DECIMALES_ROUND, planViaje.getInternacionalMontoResolucion()));
				}

			}

			TXXX8LugarUbigeoBean lugarPuntoPartida = viaticoGeneralService.obtenerLugarByCodigoLugarNacional(planViaje.getSedeOrigen());

			if (lugarPuntoPartida != null) {
				registroVO.setDepartamento(StringUtils.trimToEmpty(lugarPuntoPartida.getCodigoDepartamento()));
				registroVO.setProvincia(StringUtils.trimToEmpty(lugarPuntoPartida.getCodigoProvincia()));
				registroVO.setCodigoPuntoPartida(StringUtils.trimToEmpty(lugarPuntoPartida.getCodigoLugar()));
			}

			registroVO.setTipoViatico(esNacional ? ViaticoConstantes.VISTA_TIPO_VIATICO_NACIONAL : ViaticoConstantes.VISTA_TIPO_VIATICO_INTERNACIONAL);
			registroVO.setDuracionComision(esNacional && esMenorIgual4h ? ViaticoConstantes.VISTA_DURACION_COMISION_MENOR_IGUAL4h : ViaticoConstantes.VISTA_DURACION_COMISION_MAYOR4H);

			registroVO.setUsarLimaComoDefault(esInternacional ? ViaticoConstantes.SI : ViaticoConstantes.NO); // si es internacional, se considera a lima como default en el punto de partida

			registroVO.setDepartamentoList(registroGeneralService.obtenerDepartamentos());
			registroVO.setProvinciaList(registroGeneralService.obtenerProvincias(registroVO.getDepartamento()));

			// armando la lista de desplazamiento (plan viaje destinos)
			double totalDesplazamientos = 0.0;
			PlanViajeDestinoBean planViajeDestino = null;
			List<Map<String, Object>> desplazamientos = new ArrayList<Map<String, Object>>();

			if (CollectionUtils.isNotEmpty(planViajeDestinos)) {

				Map<String, Object> item = null;

				for (int i = 0; i < planViajeDestinos.size(); i++) {

					// item del mapa JSON respuesta vista
					item = new LinkedHashMap<String, Object>();

					// item de lista plan de viaje destinos en BD
					planViajeDestino = planViajeDestinos.get(i);

					// setear todos los campos en blanco para asegurar formato JSON
					item.put("medioTransporte", StringUtils.EMPTY); // todos
					item.put("departamento", StringUtils.EMPTY); // nacional
					item.put("provincia", StringUtils.EMPTY); // nacional
					item.put("lugarDestino", StringUtils.EMPTY); // internacional
					item.put("diasViatico", StringUtils.EMPTY); // nacional > 4 horas, e internacional
					item.put("horasViatico", StringUtils.EMPTY); // nacional <= 4horas
					item.put("importeDiario", StringUtils.EMPTY); // todos
					item.put("importeDiarioTope", StringUtils.EMPTY); // todos
					item.put("importeViatico", StringUtils.EMPTY); // todos
					item.put("diasTraslado", StringUtils.EMPTY); // internacional
					item.put("diasTrasladoTope", StringUtils.EMPTY); // internacional
					item.put("viajeExtGtoTras", StringUtils.EMPTY); // internacional
					item.put("viajeExtGtoTrasTope", StringUtils.EMPTY); // internacional
					item.put("totalOtorgado", StringUtils.EMPTY); // internacional
					item.put("codigoMedioTransporte", StringUtils.EMPTY); // todos
					item.put("codigoProvincia", StringUtils.EMPTY); // nacional hidden
					item.put("codigoDepartamento", StringUtils.EMPTY); // nacional hidden
					item.put("codigoLugar", StringUtils.EMPTY); // nacional hidden
					item.put("codigoLugarDestino", StringUtils.EMPTY); // internacional hidden
					item.put("codigoTarifario", StringUtils.EMPTY); // internacional hidden
					item.put("porcentajeTarifario", StringUtils.EMPTY); // internacional hidden

					int diasViatico = 0; // deberia ser entero
					double horasViatico = 0.0; // solo nacionales menores iguales a 4
					double importeDiario = 0.0;

					double importeViatico = 0.0;
					double totalOtorgado = 0.0;

					int diasTraslado = 0; // solo internacional
					double viajeExtGtoTras = 0.0; // solo internacional

					// setear campos según tipo de viatico y duracion de comision

					if (esNacional) {

						// CAMPOS QUE SOLO SE SETEAN EN NACIONAL

						// codigoLugar
						String codigoLugar = StringUtils.trimToEmpty(planViajeDestino.getSedeDestino());
						item.put("codigoLugar", codigoLugar);

						// obtener datos de departamento y provincia
						TXXX8LugarUbigeoBean lugarDepProv = viaticoGeneralService.obtenerLugarByCodigoLugarNacional(codigoLugar);
						if (lugarDepProv != null) {

							// otra forma: codigoDepartamento -> planViajeDestino.getCodigoDepartamentoDestino()
							item.put("codigoDepartamento", StringUtils.trimToEmpty(lugarDepProv.getCodigoDepartamento()));
							item.put("departamento", StringUtils.trimToEmpty(lugarDepProv.getDescripcionDepartamento()));

							// otra forma: codigoProvincia -> planViajeDestino.getCodigoDepartamentoDestino()
							item.put("codigoProvincia", StringUtils.trimToEmpty(lugarDepProv.getCodigoProvincia()));
							item.put("provincia", StringUtils.trimToEmpty(lugarDepProv.getDescripcionProvincia()));
						}

						if (esMayor4h) {

							if (planViajeDestino.getDias() != null) {
								diasViatico = planViajeDestino.getDias().intValue(); // deberia ser entero
								item.put("diasViatico", String.valueOf(diasViatico));
							}

						} else {

							if (planViajeDestino.getDias() != null) {
								horasViatico = ViaticoUtil.redondear(ViaticoConstantes.UNO_INT, planViajeDestino.getDias());
								item.put("horasViatico", ViaticoUtil.formatearNumeros(ViaticoConstantes.UNO_INT, planViajeDestino.getDias())); // confirmado por nery, las horas tambien se guardan en este campo
							}

						}

					} else {

						// CAMPOS QUE SOLO SE SETEAN EN INTERNACIONAL

						// codigoLugarDestino
						String codigoLugarDestino = StringUtils.trimToEmpty(planViajeDestino.getSedeDestino());
						item.put("codigoLugarDestino", codigoLugarDestino);

						// obtener descripcion de codigoLugarDestino
						TXXX8LugarUbigeoBean lugarDestino = viaticoGeneralService.obtenerLugarByCodigoLugarInternacional(codigoLugarDestino);
						if (lugarDestino != null) {
							item.put("lugarDestino", StringUtils.trimToEmpty(lugarDestino.getNombreLugar()).toUpperCase());
						}

						if (planViajeDestino.getDias() != null) {
							diasViatico = planViajeDestino.getDias().intValue(); // deberia ser entero
							item.put("diasViatico", String.valueOf(diasViatico)); // deberia ser entero
						}

						item.put("codigoTarifario", StringUtils.trimToEmpty(planViajeDestino.getCodigoTarifarioInternacional()));

						if (planViajeDestino.getPorcTarifarioInternacional() != null) {
							item.put("porcentajeTarifario", ViaticoUtil.formatearNumeros(ViaticoConstantes.NRO_DECIMALES_ROUND, planViajeDestino.getPorcTarifarioInternacional()));
						}

						if (planViajeDestino.getDiasExtra() != null) {
							diasTraslado = planViajeDestino.getDiasExtra().intValue();
							item.put("diasTraslado", String.valueOf(diasTraslado));
						}

						if (planViajeDestino.getDiasExtraTope() != null) {
							item.put("diasTrasladoTope", String.valueOf(planViajeDestino.getDiasExtraTope().intValue()));
						}

						if (planViajeDestino.getMontoTraslado() != null) {
							viajeExtGtoTras = planViajeDestino.getMontoTraslado();
							item.put("viajeExtGtoTras", ViaticoUtil.formatearNumeros(ViaticoConstantes.NRO_DECIMALES_ROUND, viajeExtGtoTras));
						}

						// viajeExtGtoTrasTope es igual al importeDiarioTope
						if (planViajeDestino.getMontoDiarioTope() != null) {
							item.put("viajeExtGtoTrasTope", ViaticoUtil.formatearNumeros(ViaticoConstantes.NRO_DECIMALES_ROUND, planViajeDestino.getMontoDiarioTope()));
						}

					}

					// PARA TODOS LOS CASOS

					// codigoMedioTransporte
					String codigoMedioTransporte = StringUtils.trimToEmpty(planViajeDestino.getMedioTransporte());
					item.put("codigoMedioTransporte", codigoMedioTransporte);

					// obtener descripcion de codigoMedioTransporte
					ClaveValorBean medioTransporte = viaticoGeneralService.obtenerMedioTransporte(codigoMedioTransporte);
					if (medioTransporte != null) {
						item.put("medioTransporte", StringUtils.trimToEmpty(medioTransporte.getDescripcion()).toUpperCase());
					}

					// obtener el importe diario tope
					if (planViajeDestino.getMontoDiarioTope() != null) {
						item.put("importeDiarioTope", ViaticoUtil.formatearNumeros(ViaticoConstantes.NRO_DECIMALES_ROUND, planViajeDestino.getMontoDiarioTope()));
					}

					// ontener el importe diario
					if (planViajeDestino.getMontoDiario() != null) {
						importeDiario = planViajeDestino.getMontoDiario();
						item.put("importeDiario", ViaticoUtil.formatearNumeros(ViaticoConstantes.NRO_DECIMALES_ROUND, importeDiario));
					}

					// calculo del importe viatico
					if (esNacional && esMenorIgual4h) {
						importeViatico = ViaticoUtil.redondear(1, importeDiario * horasViatico);//redondeo a un decimal
					} else {
						importeViatico = ViaticoUtil.redondear(1, importeDiario * diasViatico);//redondeo a un decimal
					}
					item.put("importeViatico", ViaticoUtil.formatearNumeros(1, importeViatico));//redondeo a un decimal

					// calculo de total otorgado (solo internacionales)
					if (esInternacional) {

						double viajeExtraPorDiasTraslado = ViaticoUtil.redondear(ViaticoConstantes.NRO_DECIMALES_ROUND, viajeExtGtoTras * diasTraslado);

						totalOtorgado = ViaticoUtil.redondear(ViaticoConstantes.NRO_DECIMALES_ROUND, importeViatico + viajeExtraPorDiasTraslado);

						item.put("totalOtorgado", ViaticoUtil.formatearNumeros(ViaticoConstantes.NRO_DECIMALES_ROUND, totalOtorgado)); // extranjero
					}

					// acumular total desplazamientos
					if (esNacional) {
						totalDesplazamientos = totalDesplazamientos + importeViatico;
					} else {
						totalDesplazamientos = totalDesplazamientos + totalOtorgado;
					}

					desplazamientos.add(item);
				}
			}

			// asignando lista de desplazamientos y totales
			registroVO.setDesplazamientosList(desplazamientos);
			registroVO.setTotalDesplazamientos(ViaticoUtil.formatearNumeros(ViaticoConstantes.NRO_DECIMALES_ROUND, totalDesplazamientos));

			// combo lugares (lugar desplazamiento)
			registroVO.setLugaresList(viaticoGeneralService.obtenerRutasLugares());

			// combo tarifas (lugar desplazamiento)
			registroVO.setTarifasList(viaticoGeneralService.obtenerRutasTipoTarifas());

			// combo medio de transporte (lugar desplazamiento)
			registroVO.setMediosTransporteList(viaticoGeneralService.obtenerMediosTransporte());

			// combo de ampliacion de comision
			registroVO.setMotivoAmpliacion(planViaje.getCodigoTipoMotReembolso());
			registroVO.setMotivoAmpliacionList(viaticoGeneralService.obtenerMotivosAmpliacionComision());

			// combo de planillas asociadas
			String tipoDestino = planViaje.getTipoDestino();
			String indicadorHoras = planViaje.getIndicadorHoras();
			registroVO.setPlanillasAsociadasList(consultaReembolsoService.obtenerPlanillasAsociadas(colaborador.getCodigoEmpleado(), tipoDestino, indicadorHoras));
			registroVO.setPlanillaAsociada(planViaje.getCodigoPlanillaAsc());

			// lista de archivos adjuntos
			registroVO.setArchivosAdjuntosList(null);
			if (StringUtils.isNotBlank(planViaje.getNumeroRegistroArchivo())) {

				Map<String, Object> paramsBuscar = new HashMap<String, Object>();

				paramsBuscar.put("num_reg", planViaje.getNumeroRegistroArchivo());

				List<RegistroArchivosFisicoBean> listArchivosAdjuntos = (List<RegistroArchivosFisicoBean>) registroArchivosService.listarArchivosAdjuntos(paramsBuscar);

				registroVO.setArchivosAdjuntosList(listArchivosAdjuntos);
			}

			// fecha y hora de visualizacion de asistencia
			registroVO.setConsultaAsistenciaVisualizo(ViaticoConstantes.NO);
			registroVO.setConsultaAsistenciaFecha(StringUtils.EMPTY);
			registroVO.setConsultaAsistenciaHora(StringUtils.EMPTY);

			if (planViaje.getFechaVizAsis() != null) {

				registroVO.setConsultaAsistenciaVisualizo(ViaticoConstantes.SI);

				// setear fecha
				registroVO.setConsultaAsistenciaFecha(sdf.format(planViaje.getFechaVizAsis()));

				int horasAsistencia = ViaticoUtil.extraerHoras24H(planViaje.getFechaVizAsis());
				int minutosAsistencia = ViaticoUtil.extraerMinutos(planViaje.getFechaVizAsis());

				// setear hora
				registroVO.setConsultaAsistenciaHora(ViaticoUtil.formatearHorasMinutos(horasAsistencia, minutosAsistencia));
			}

			Date today = new Date();
			registroVO.setFechaToday(FechaUtil.formatDateToDateDDMMYYYY(today));

			Date fechaRegistro = planViaje.getFechaRegistro();
			registroVO.setFechaToday(FechaUtil.obtenerFechaActual());
			registroVO.setFechaRegistro(FechaUtil.formatDateToDateDDMMYYYY(fechaRegistro));
			registroVO.setFechaRegistroMas1(FechaUtil.formatDateToDateDDMMYYYY(ViaticoUtil.addDiasToDate(fechaRegistro, ViaticoConstantes.UNO_INT)));

			registroVO.setTipoConfiguracion(viaticosProcesoSingleton.obtenerProceso());

			// tiene registros adjuntos
			registroVO.setTieneArchivoAdjunto(StringUtils.isBlank(planViaje.getNumeroRegistroArchivo()) ? ViaticoConstantes.NO : ViaticoConstantes.SI);
			
		} catch (Exception e) {

			log.error(e.getMessage(), e);
			errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO);

		} finally {

			registroVO.setErrorMessage(errorMessage);
			registroVO.setCustomMessage(customMessage);
		}

		return registroVO;
	}

	/**
	 * Metodo que permite armar plan viaje bean from viewObject.
	 * 
	 * @author Juan Farro
	 * @see ModelAndView
	 * @param viewObject objeto vista registro solicitud
	 * @return objeto plan viaje
	 * @throws Exception
	 */
	private PlanViajeBean armarPlanViajeBeanFromVO(ReembolsoVO viewObject) throws Exception {

		SimpleDateFormat sdf = new SimpleDateFormat(ViaticoConstantes.DATE_FORMAT_DDMMYYYY);

		boolean esNacional = StringUtils.equals(viewObject.getTipoViatico(), ViaticoConstantes.VISTA_TIPO_VIATICO_NACIONAL);
		boolean esInternacional = StringUtils.equals(viewObject.getTipoViatico(), ViaticoConstantes.VISTA_TIPO_VIATICO_INTERNACIONAL);
		boolean esMayor4h = StringUtils.equals(viewObject.getDuracionComision(), ViaticoConstantes.VISTA_DURACION_COMISION_MAYOR4H);
		boolean esMenorIgual4h = StringUtils.equals(viewObject.getDuracionComision(), ViaticoConstantes.VISTA_DURACION_COMISION_MENOR_IGUAL4h);

		Date fechaActual = new Date();
		String anioActual = FechaUtil.obtenerAnioActual();
		String mesActual = FechaUtil.obtenerMesActual();

		PlanViajeBean planViajeBean = new PlanViajeBean();

		// NOTA: SE DECIDIO INCLUIR EXPLICITAMENTE TODOS LOS CAMPOS DE LA TABLA PLAN_VIAJE, AUNQUE POR NEGOCIO/MODULO SOLO ALGUNOS TENGAN VALOR != NULL

		// * PLAN_VIAJE_ID (NOT NULL) (campo legado: se tomo del bean original)
		// planViajeBean.setCodPlanViaje(null); // se genera en registroReembolsoService

		// * TRABAJADOR (NOT NULL)
		planViajeBean.setCodTrabajador(StringUtils.trimToNull(viewObject.getCodigoColaborador()));

		// * FECHA_REGISTRO (NOT NULL)
		planViajeBean.setFechaRegistro(fechaActual);

		// FECHA_APROBACION
		planViajeBean.setFechaAprobacion(null);

		// * FECHA_HORA_PROG_SALIDA (NOT NULL)
		if (esNacional) {
			if (esMayor4h) {
				if (viewObject.getFechaSalidaNacMay4h() != null && FechaBean.validaFormato(viewObject.getFechaSalidaNacMay4h(), FechaBean.FORMATO_DEFAULT)) {
					planViajeBean.setFechaHoraProgSalida(sdf.parse(viewObject.getFechaSalidaNacMay4h()));
				}
			} else {
				if (viewObject.getFechaNacMen4h() != null && FechaBean.validaFormato(viewObject.getFechaNacMen4h(), FechaBean.FORMATO_DEFAULT)) {

					// toma la fecha de salida
					Date fechaNacMen4h = sdf.parse(viewObject.getFechaNacMen4h());

					// le agrega horas y minutos de la salida
					if (StringUtils.isNotBlank(viewObject.getSalidaNacMen4h())) {

						String[] horaMinutos = StringUtils.trimToEmpty(viewObject.getSalidaNacMen4h()).split(":");

						if (horaMinutos != null && horaMinutos.length > 0 && NumberUtils.isNumber(horaMinutos[0])) {
							fechaNacMen4h = ViaticoUtil.addHorasToDate(fechaNacMen4h, Integer.parseInt(horaMinutos[0]));
						}

						if (horaMinutos != null && horaMinutos.length > 1 && NumberUtils.isNumber(horaMinutos[1])) {
							fechaNacMen4h = ViaticoUtil.addMinutosToDate(fechaNacMen4h, Integer.parseInt(horaMinutos[1]));
						}
					}

					planViajeBean.setFechaHoraProgSalida(fechaNacMen4h);

				}
			}
		} else {
			if (viewObject.getFechaEventoInicioInter() != null && FechaBean.validaFormato(viewObject.getFechaEventoInicioInter(), FechaBean.FORMATO_DEFAULT)) {
				planViajeBean.setFechaHoraProgSalida(sdf.parse(viewObject.getFechaEventoInicioInter()));
			}
		}

		// FECHA_HORA_PROG_RETORNO
		if (esNacional) {

			if (esMayor4h) {

				if (viewObject.getFechaRetornoNacMay4h() != null && FechaBean.validaFormato(viewObject.getFechaRetornoNacMay4h(), FechaBean.FORMATO_DEFAULT)) {
					planViajeBean.setFechaHoraProgRetorno(sdf.parse(viewObject.getFechaRetornoNacMay4h()));
				}

			} else {

				// toma la fecha de salida
				Date fechaNacMen4h = sdf.parse(viewObject.getFechaNacMen4h());

				// agrega horas y minutos del retorno
				if (StringUtils.isNotBlank(viewObject.getRetornoNacMen4h())) {

					String[] horaMinutos = StringUtils.trimToEmpty(viewObject.getRetornoNacMen4h()).split(":");

					if (horaMinutos != null && horaMinutos.length > 0 && NumberUtils.isNumber(horaMinutos[0])) {
						fechaNacMen4h = ViaticoUtil.addHorasToDate(fechaNacMen4h, Integer.parseInt(horaMinutos[0]));
					}

					if (horaMinutos != null && horaMinutos.length > 1 && NumberUtils.isNumber(horaMinutos[1])) {
						fechaNacMen4h = ViaticoUtil.addMinutosToDate(fechaNacMen4h, Integer.parseInt(horaMinutos[1]));
					}
				}

				planViajeBean.setFechaHoraProgRetorno(fechaNacMen4h);

			}
		} else {
			if (viewObject.getFechaEventoFinInter() != null && FechaBean.validaFormato(viewObject.getFechaEventoFinInter(), FechaBean.FORMATO_DEFAULT)) {
				planViajeBean.setFechaHoraProgRetorno(sdf.parse(viewObject.getFechaEventoFinInter()));
			}
		}

		// * NUMERO_DIAS
		if (esNacional) {
			if (esMayor4h) {
				if (NumberUtils.isNumber(viewObject.getDiasNacMay4h())) {
					planViajeBean.setNumeroDias(Double.parseDouble(viewObject.getDiasNacMay4h()));
				}
			} else {
				planViajeBean.setNumeroDias(null);
			}
		} else {
			if (NumberUtils.isNumber(viewObject.getDiasInter())) {
				planViajeBean.setNumeroDias(Double.parseDouble(viewObject.getDiasInter()));
			}
		}

		// * PRESUPUESTO_ANNO (NOT NULL)
		planViajeBean.setPresupuestoAnno(anioActual);

		// * PRESUPUESTO_META (NOT NULL)
		planViajeBean.setPresupuestoMeta(StringUtils.trimToNull(viewObject.getCodigoMetaPresupuestal()));

		// * PRESUPUESTO_MES (NOT NULL)
		planViajeBean.setPresupuestoMes(mesActual);

		// * SEDE_ORIGEN
		planViajeBean.setSedeOrigen(StringUtils.trimToNull(viewObject.getCodigoPuntoPartida()));

		// * MONTO_TOTAL
		if (NumberUtils.isNumber(viewObject.getTotalDesplazamientos())) {
			planViajeBean.setMontoTotal(Double.parseDouble(viewObject.getTotalDesplazamientos()));
		}

		// * ORIGEN - siempre se setea a reembolso
		planViajeBean.setOrigen(ViaticoConstantes.TIPO_ORIGEN_REEMBOLSO);

		// * TIPO_DESTINO (NOT NULL) // 01: Nacional, 02: Internacional (tipo de viatico)
		planViajeBean.setTipoDestino(esNacional ? ViaticoConstantes.TIPO_COMISION_NACIONAL : ViaticoConstantes.TIPO_COMISION_INTERNACIONAL);

		// DESTINO_EXTERIOR
		planViajeBean.setDestinoExterior(null);

		if (esInternacional) {

			// * INTERNACIONAL_NRO_RESOLUCION
			planViajeBean.setInternacionalNroResolucion(StringUtils.trimToNull(viewObject.getNroResolucionInter()));

			// * INTERNACIONAL_FECHA_RESOLUCION
			if (viewObject.getFechaResolucionInter() != null && FechaBean.validaFormato(viewObject.getFechaResolucionInter(), FechaBean.FORMATO_DEFAULT)) {
				planViajeBean.setInternacionalFechaResolucion(sdf.parse(viewObject.getFechaResolucionInter()));
			}

			// * INTERNACIONAL_MONTO_RESOLUCION
			if (NumberUtils.isNumber(viewObject.getMontoResolucionInter())) {
				planViajeBean.setInternacionalMontoResolucion(Double.parseDouble(viewObject.getMontoResolucionInter()));
			}

		}

		// * TIPO_CAMBIO (NOT NULL)
		Double tipoCambio = null;

		if (esNacional) {

			tipoCambio = ViaticoConstantes.UNO_DOUBLE;

		} else {

			// buscar el tipo de cambio del dia de hoy (dolares a soles)
			TipoCambioBean tipoCambioBean = consultaSolicitudService.obtenerTipoCambioSimboloDolaresHoy();

			if (tipoCambioBean == null) {
				// buscar el mas reciente (dolares a soles)
				tipoCambioBean = consultaSolicitudService.obtenerTipoCambioSimboloDolaresMasReciente();
			}

			if (tipoCambioBean != null) {
				tipoCambio = tipoCambioBean.getValorSolesTipo();
			}

		}

		planViajeBean.setTipoCambio(tipoCambio);

		// * MONEDA (NOT NULL)
		planViajeBean.setMoneda(esInternacional ? ViaticoConstantes.MONEDA_DOLARES : ViaticoConstantes.MONEDA_SOLES);

		// * POA_PROGRAMADO
		if (esNacional) {
			if (StringUtils.isNotBlank(viewObject.getViaticosProgramadosNac())) {
				planViajeBean.setPoaProgramado(StringUtils.trimToNull(viewObject.getViaticosProgramadosNac()));
			}
		}

		// * SOLICITANTE_VIAJE
		planViajeBean.setSolicitanteViaje(ViaticoUtil.trimUpperCase(viewObject.getMotivoComision()));

		// * DOCUMENTOS_ANTECEDENTES
		planViajeBean.setDocumentosAntecedentes(null);

		// INSTRUCCIONES_RECIBIDAS
		planViajeBean.setInstruccionesRecibidas(null);

		// * PERSONA_AUTORIZACION_VIGENTE (autorizador del gasto) NOTA: se setea en el momento de autorizar
		planViajeBean.setPersonaAutorizacionVigente(null);

		// FORMA_PAGO
		planViajeBean.setFormaPago(null);

		// FECHA_HORA_EJE_SALIDA. NOTA: solo para reembolso, se guarda la fecha de prog salida (ya debe estar seteada en planViajeBean)
		planViajeBean.setFechaHoraEjeSalida(planViajeBean.getFechaHoraProgSalida());

		// FECHA_HORA_EJE_RETORNO. NOTA: solo para reembolso, se guarda la fecha de prog salida (ya debe estar seteada en planViajeBean)
		planViajeBean.setFechaHoraEjeRetorno(planViajeBean.getFechaHoraProgRetorno());

		if (esInternacional) {

			// FEC_ITI_SALIDA
			if (viewObject.getFechaItinerarioInicioInter() != null && FechaBean.validaFormato(viewObject.getFechaItinerarioInicioInter(), FechaBean.FORMATO_DEFAULT)) {
				planViajeBean.setFechaItinerarioSalida(sdf.parse(viewObject.getFechaItinerarioInicioInter()));
			}

			// FEC_ITI_RETORNO
			if (viewObject.getFechaItinerarioFinInter() != null && FechaBean.validaFormato(viewObject.getFechaItinerarioFinInter(), FechaBean.FORMATO_DEFAULT)) {
				planViajeBean.setFechaItinerarioRetorno(sdf.parse(viewObject.getFechaItinerarioFinInter()));
			}
		}

		// FECHA_RENDICION
		planViajeBean.setFechaRendicion(null);

		// * ESTADO_PLAN_VIAJE (NOT NULL)
		planViajeBean.setEstadoPlanViaje(ViaticoConstantes.ESTADO_REEMBOLSO_ELABORADO);

		// * ESTADO_RENDICION (NOT NULL)
		planViajeBean.setEstadoRendicion(RendicionConstantes.ESTADO_RENDICION_PENDIENTE);

		// * NUMERO_REGISTRO_ARCHIVO. NOTA: en la sentencia update de modificacion se ignora este campo
		planViajeBean.setNumeroRegistroArchivo(null);

		// * EXPEDIENTE_PLAN_VIAJE. NOTA: se setea en registroReembolsoServiceImpl
		planViajeBean.setExpedientePlanViaje(null);

		// EXPEDIENTE_RENDICION
		planViajeBean.setExpedienteRendicion(null);

		// * SEDE_PLAN_VIAJE
		planViajeBean.setSedePlanViaje(StringUtils.trimToNull(viewObject.getCodigoSedeColaborador()));

		// * MEDIO_TRANSPORTE_RETORNO
		planViajeBean.setMedioTransporteRetorno(null);

		// TRABAJADOR_ENCARGADO
		planViajeBean.setTrabajadorEncargado(null);

		// INDICADOR_RECIBO_PROVISIONAL
		planViajeBean.setIndicadorReciboProvisional(null);

		// * USO_MOVILIDAD_EMPRESA
		planViajeBean.setUsoMovilidadEmpresa(null);

		// FECHA_DEPOSITO_DEVOL
		planViajeBean.setFechaDepositoDevol(null);

		// ** MONTO_DEVOL
		planViajeBean.setMontoDevol(null);

		// * TIPO_DEVOLUCION
		planViajeBean.setTipoDevolucion(null);

		// NUMERO_PAPELETA
		planViajeBean.setNumeroPapeleta(null);

		// USER_CREA
		// planViajeBean.setUsuarioCreacion(null); // lo setea el AOP

		// FECH_CREA
		// planViajeBean.setFechaCreacion(sdf.parse(null)); // lo setea el AOP

		// USER_MODI
		// planViajeBean.setUsuarioModificacion(null); // lo setea el AOP

		// FECH_MODI
		// planViajeBean.setFechaModificacion(sdf.parse(null)); // lo setea el AOP

		// * COD_PLANILLA_VIAJE (ANIO+<UUOO>+R+<SECUENCIA>, ejemplo: 20132M0200V0134) - NOTA: se genera en registroReembolsoServiceImpl
		// planViajeBean.setCodPlanilla(null);

		// ** MTO_DEVUELTO
		planViajeBean.setMontoDevuelto(null);

		// FEC_INICIO_ACCION
		planViajeBean.setFechaInicioAccion(null);

		// CODI_BANC_BAN
		planViajeBean.setCodigoBancBan(null);

		// FEC_ANULACION
		planViajeBean.setFechaAnulacion(null);

		// FEC_AUTORIZACION
		planViajeBean.setFechaAutorizacion(null);

		// FEC_ENVIOFIN
		planViajeBean.setFechaEnviofin(null);

		// FEC_ENVIO_PRE
		planViajeBean.setFechaEnvioPre(null);

		// FEC_FIN_ACCION
		planViajeBean.setFechaFinAccion(null);

		// * FEC_MAX_RENDICION
		if (esNacional) {
			if (viewObject.getFechaMaximaRendicionNac() != null && FechaBean.validaFormato(viewObject.getFechaMaximaRendicionNac(), FechaBean.FORMATO_DEFAULT)) {
				planViajeBean.setFechaMaxRendicion(sdf.parse(viewObject.getFechaMaximaRendicionNac()));
			}
		} else {
			if (viewObject.getFechaMaximaRendicionInter() != null && FechaBean.validaFormato(viewObject.getFechaMaximaRendicionInter(), FechaBean.FORMATO_DEFAULT)) {
				planViajeBean.setFechaMaxRendicion(sdf.parse(viewObject.getFechaMaximaRendicionInter()));
			}
		}

		// FEC_NOTIFICACION
		planViajeBean.setFechaNotificacion(null);

		// FEC_OBSERVACION, NOTA: se setea cuando el autorizador observa
		planViajeBean.setFechaObservacion(null);

		// FEC_OBS_TRASLAPE
		planViajeBean.setFechaObsTraslape(null);

		// FEC_PAGO
		planViajeBean.setFechaPago(null);

		// FEC_VERIFICACION
		planViajeBean.setFechaVerificacion(null);

		// FEC_VIZ_ASIS
		if (viewObject.getConsultaAsistenciaFecha() != null && FechaBean.validaFormato(viewObject.getConsultaAsistenciaFecha(), FechaBean.FORMATO_DEFAULT)) {
			Date fechaVizAsis = sdf.parse(viewObject.getConsultaAsistenciaFecha());

			// agregar horas y minutos
			if (StringUtils.isNotBlank(viewObject.getConsultaAsistenciaHora())) {

				String[] horaMinutos = StringUtils.trimToEmpty(viewObject.getConsultaAsistenciaHora()).split(":");

				if (horaMinutos != null && horaMinutos.length > 0 && NumberUtils.isNumber(horaMinutos[0])) {
					fechaVizAsis = ViaticoUtil.addHorasToDate(fechaVizAsis, Integer.parseInt(horaMinutos[0]));
				}

				if (horaMinutos != null && horaMinutos.length > 1 && NumberUtils.isNumber(horaMinutos[1])) {
					fechaVizAsis = ViaticoUtil.addMinutosToDate(fechaVizAsis, Integer.parseInt(horaMinutos[1]));
				}
			}

			planViajeBean.setFechaVizAsis(fechaVizAsis);
		}

		// * IND_AUTORIZACION
		planViajeBean.setIndicadorAutorizacion(StringUtils.trimToNull(viewObject.getIndicadorAutorizacion()));
		if (StringUtils.isBlank(planViajeBean.getIndicadorAutorizacion())) {
			// valor por default si no viene con data
			planViajeBean.setIndicadorAutorizacion(ViaticoConstantes.INDICADOR_AUTORIZACION_SIN_AUTORIZAR);
		}

		// ** IND_EXT_DDJJ. NOTA: solo para reembolso. si es guardar nuevo siempre se guarda 0, si es modificacion se pone null para ignorarlo en el update de modificacion
		if (StringUtils.equals(viewObject.getFlagDoAction(), ViaticoConstantes.VISTA_REGISTRAR)) {
			planViajeBean.setIndicadorExtDdjj(ViaticoConstantes.INDICADOR_EXTDDJJ_NO);
		} else {
			// se pone null, porque en la modificacion se ignora este campo en el update, ya que la ventana de sustentoGasto es la que modifica este valor
			planViajeBean.setIndicadorExtDdjj(null);
		}

		// * IND_HORAS (1: horas, 0: dias) // duracion de comision
		planViajeBean.setIndicadorHoras(esNacional && esMenorIgual4h ? ViaticoConstantes.INDICADOR_HORAS_HORAS : ViaticoConstantes.INDICADOR_HORAS_DIAS);

		// IND_MEN_GAST
		planViajeBean.setIndicadorMenGast(null);

		// IND_MODO_PAGO (1:caja chica, 2:abono en cuenta, 3:cheque)
		planViajeBean.setIndicadorModoPago(null);
		if (StringUtils.equals(viewObject.getCodigoCanalAtencion(), ViaticoConstantes.CANAL_ATENCION_CAJACHICA)) {
			planViajeBean.setIndicadorModoPago(ViaticoConstantes.INDICADOR_MODO_PAGO_CAJA_CHICA);
		} else if (StringUtils.equals(viewObject.getCodigoCanalAtencion(), ViaticoConstantes.CANAL_ATENCION_REEMBOLSO)) {
			planViajeBean.setIndicadorModoPago(ViaticoConstantes.INDICADOR_MODO_PAGO_ABONO_CUENTA);
		}

		// * IND_RUTA (C: caja chica, R: reembolso)
		planViajeBean.setIndicadorRuta(StringUtils.trimToNull(viewObject.getCodigoCanalAtencion()));

		// IND_SEG_NOTIF
		planViajeBean.setIndicadorSegNotif(null);

		// * IND_TIPO_TRASLADO (1 - PERMANENTE, 2 - TEMPORAL)
		planViajeBean.setIndicadorTipoTraslado(null);

		// IND_TRASLAPE
		planViajeBean.setIndicadorTraslape(StringUtils.trimToNull(viewObject.getIndicadorTraslape()));

		if (StringUtils.isBlank(planViajeBean.getIndicadorTraslape())) {
			// valor por default si no viene con data
			planViajeBean.setIndicadorTraslape(ViaticoConstantes.INDICADOR_TRASLAPE_NO);
		}

		// OBS_ANULACION
		planViajeBean.setObservacionAnulacion(null);

		// OBS_AUTORIZACION
		planViajeBean.setObservacionAutorizacion(null);

		// OBS_AUTORIZADOR
		planViajeBean.setObservacionAutorizador(null);

		// OBS_RENDICION
		planViajeBean.setObservacionRendicion(null);

		// OBS_SOLICITUD
		planViajeBean.setObservacionSolicitud(ViaticoUtil.trimUpperCase(viewObject.getObservacion()));

		// OBS_TRASLAPE
		planViajeBean.setObservacionTraslape(null);

		// * COD_DEPENDENCIA
		planViajeBean.setCodigoDependencia(StringUtils.trimToNull(viewObject.getCodigoDependencia()));

		// COD_DEST_EXTRANJERO
		planViajeBean.setCodigoDestExtranjero(null);

		// * COD_NIVEL (NIVEL DEL PROFESIONAL TRABAJADOR, MAESTRO_PERSONAL.CODI_NIVE_NVL)
		planViajeBean.setCodigoNivel(StringUtils.trimToNull(viewObject.getCodigoNivelColaborador()));

		// COD_NIV_AUTOR (CODIGO DE CARGO DEL AUTORIZADOR) - NOTA: se setea en el momento de autorizar
		planViajeBean.setCodigoNivAutor(null);

		// COD_PLANILLA_ASC - solo para reembolsos
		planViajeBean.setCodigoPlanillaAsc(StringUtils.trimToNull(viewObject.getPlanillaAsociada()));

		// COD_PLAN_VIAJE_ID - CODIGO DE PLAN DE VIAJE PADRE
		planViajeBean.setCodigoPlanViajeID(null);

		// * COD_REGISTRADOR
		planViajeBean.setCodigoRegistrador(StringUtils.trimToNull(viewObject.getCodigoRegistrador()));

		// * COD_TIPO_TRASLADO (01: viaticos, 02: traslado)
		planViajeBean.setCodigoTipoTraslado(ViaticoConstantes.TIPO_TRASLADO_VIATICOS);

		// COD_USURENDICION
		planViajeBean.setCodigoUsurendicion(null);

		// COD_USUVERIFICACION
		planViajeBean.setCodigoUsuverificacion(null);

		// DES_JUST_REP
		planViajeBean.setDescripcionJustRep(null);

		// COD_TIP_MOT_REEM (antes era TIP_MOT_REEM) - solo para reembolsos
		planViajeBean.setCodigoTipoMotReembolso(StringUtils.trimToNull(viewObject.getMotivoAmpliacion()));

		// COD_ESTPAGO (antes era COD_ESPAGO)
		planViajeBean.setCodigoEstadoPago(null);

		// ** MTO_TOPE_VIAT_INTER
		planViajeBean.setMontoTopeViaticoInternacional(null);

		// * NRO_HORAS
		planViajeBean.setNumeroHoras(null);
		if (esNacional) {
			if (esMenorIgual4h) {
				if (NumberUtils.isNumber(viewObject.getHorasNacMen4h())) {
					planViajeBean.setNumeroHoras(Double.parseDouble(viewObject.getHorasNacMen4h()));
				}
			}
		}

		if (esInternacional) {
			// NUM_RESOL_REM - solo para reembolso
			planViajeBean.setNumeroResolRem(StringUtils.trimToNull(viewObject.getNroResolucionInter()));
		}

		// NUM_CASECID
		planViajeBean.setNumeroCasecid(null);

		// NUM_CCPSECID
		planViajeBean.setNumeroCcpsecid(null);

		// NUM_REGISTRO
		planViajeBean.setNumeroRegistro(StringUtils.trimToNull(viewObject.getNumeroRegistroRegistrador()));

		// NUM_REGI_CAB
		planViajeBean.setNumeroRegiCab(null);

		// * NIVE_VIAT_NVI (MAESTRO_PERSONAL.NIVE_VIAT_NVI, los valores en según tabla NIVELES_VIATICOS)
		planViajeBean.setNiveViatNvi(StringUtils.trimToNull(viewObject.getCodigoNivelViaticoColaborador()));

		// COD_DEP_AUTOR (nuevo campo 20160103) - NOTA: se setea en el momento de autorizar
		planViajeBean.setCodigoDepAutor(null);

		// COD_CARGO_EMP (nuevo campo 20160103)
		planViajeBean.setCodigoCargoEmpleado(null);

		return planViajeBean;
	}

	/**
	 * Metodo que permite obtener las planillas de viatico asociadas a un colaborador para reembolso
	 * 
	 * @author Juan Farro
	 * @see ModelAndView
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView obtenerPlanillasViaticoAsociadas(HttpServletRequest request, HttpServletResponse response) {

		log.debug(getClass().getName() + " Inicio del metodo obtenerPlanillasViaticoAsociadas");

		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			String codColaborador = StringUtils.trimToEmpty(request.getParameter("codColaborador"));
			String tipoViatico = StringUtils.trimToEmpty(request.getParameter("tipoViatico"));
			String duracionComision = StringUtils.trimToEmpty(request.getParameter("duracionComision"));

			// PRE: todos los parametros del request son obligatorios
			if (StringUtils.isBlank(codColaborador)) throw new Exception("codColaborador no puede estar vacio");
			if (StringUtils.isBlank(tipoViatico)) throw new Exception("tipoViatico no puede estar vacio");
			if (StringUtils.isBlank(duracionComision)) throw new Exception("duracionComision no puede estar vacio");

			boolean esNacional = StringUtils.equals(tipoViatico, ViaticoConstantes.VISTA_TIPO_VIATICO_NACIONAL);
			boolean esMenorIgual4h = StringUtils.equals(duracionComision, ViaticoConstantes.VISTA_DURACION_COMISION_MENOR_IGUAL4h);

			String tipoDestino = esNacional ? ViaticoConstantes.TIPO_COMISION_NACIONAL : ViaticoConstantes.TIPO_COMISION_INTERNACIONAL;
			String indicadorHoras = esNacional && esMenorIgual4h ? ViaticoConstantes.INDICADOR_HORAS_HORAS : ViaticoConstantes.INDICADOR_HORAS_DIAS;

			List<ClaveValorBean> planillasAsociadas = consultaReembolsoService.obtenerPlanillasAsociadas(codColaborador, tipoDestino, indicadorHoras);

			respuesta.put("planillasAsociadas", planillasAsociadas);
			respuesta.put("hayPlanillas", CollectionUtils.isEmpty(planillasAsociadas) ? ViaticoConstantes.NO : ViaticoConstantes.SI);

			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", ViaticoConstantes.NO);
			respuesta.put("msgError", StringUtils.EMPTY);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {

			log.error(e.getMessage(), e);

			// INDICADORES QUE LA PETICION AJAX CULMINO CON ERRORES.
			// NOTA: El key msgError se usa como mensaje generico de error no manejable. 
			//       Otros keys del mapa respuesta se usan para personalizar los mensajes de negocio visibles al usuario.
			respuesta.put("error", ViaticoConstantes.SI);
			respuesta.put("msgError", ViaticoConstantes.MSG_ERROR_OPERACION_NO_EFECTUADA);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} finally {

			log.debug(getClass().getName() + " Fin del metodo obtenerPlanillasViaticoAsociadas");
		}

		return modelAndView;
	}

	/**
	 * Metodo que permite cargar la pagina de visualizacion de la solicutud de reembolso.
	 * 
	 * @author Juan Farro
	 * @see ModelAndView
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView mostrarConsultarViatico(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;

		boolean customMessage = false;
		String errorMessage = StringUtils.EMPTY;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			log.debug(getClass().getName() + " Inicio del metodo mostrarConsultarViatico");

			String codPlanilla = StringUtils.trimToEmpty(request.getParameter("codPlanilla"));

			String dataJSON = StringUtils.trimToEmpty(request.getParameter("dataJSON"));
			String paginaConsultaCaller = StringUtils.trimToEmpty(request.getParameter("paginaConsultaCaller"));

			// invocar al metodo que arma el view object a partir del codigo de planilla
			// view object con toda la informacion a mostrar en la pantalla de registro de una solicitud
			ReembolsoVO registroVO = armarRegistroVO(codPlanilla);

			registroVO.setFlagDoAction(ViaticoConstantes.VISTA_CONSULTAR);

			// si hubo error en armarRegistroVO
			if (StringUtils.isNotBlank(registroVO.getErrorMessage())) {
				customMessage = registroVO.getCustomMessage();
				throw new Exception(registroVO.getErrorMessage());
			}

			// parametros adicionales para la consulta: pagina que llamo al consultar, y la data de la bandeja
			respuesta.put("dataJSON", dataJSON);
			respuesta.put("paginaConsultaCaller", paginaConsultaCaller);

			// setear listas en formato JSON
			respuesta.put("desplazamientosList", ViaticoUtil.toJSON(registroVO.getDesplazamientosList()));
			respuesta.put("archivosAdjuntosList", ViaticoUtil.toJSON(registroVO.getArchivosAdjuntosList()));

			// setear constantes que se usan en el js
			ReembolsoUtil.poblarConstantesParaRegistro(respuesta);

			respuesta.put("moneda", ViaticoConstantes.MONEDA_SOLES);
			respuesta.put("fechaToday", registroVO.getFechaToday());
			respuesta.put("fechaRegistro", registroVO.getFechaRegistro());
			respuesta.put("fechaRegistroMas1", registroVO.getFechaRegistroMas1());
			respuesta.put("tipoConfiguracion", viaticosProcesoSingleton.obtenerProceso());
			respuesta.put("tipoTarifario", viaticosTarifarioSingleton.obtenerTarifario());

			respuesta.put("registroVO", registroVO);

		} catch (Exception e) {

			log.error(e.getMessage(), e);
			errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO);

		} finally {

			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(ReembolsoConstantes.CONSULTAR_SOLICITUD_VIATICO_PAGE, respuesta);

			log.debug(getClass().getName() + " Fin del metodo mostrarConsultarViatico");
		}

		return modelAndView;
	}

	/**
	 * Metodo que permite mostrar la pagina de sustentar gasto reembolso.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView.
	 * @see ModelAndView
	 */
	public ModelAndView mostrarSustentarGastoReembolso(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView modelAndView = null;
		String errorMessage = ReembolsoConstantes.CADENA_VACIA;
		
		try {
			log.debug(RegistroReembolsoController.class.getSimpleName() + ".mostrarSustentarGastoReembolso");
			String codPlanViaje = request.getParameter("codPlanViaje");
			String dataJSON = request.getParameter("dataJSON");
			codPlanViaje = FormatoUtil.validarEmptyToNull(codPlanViaje);
			dataJSON = FormatoUtil.validarEmptyToNull(dataJSON);
			if (codPlanViaje != null) {
				UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
				String numeroRegistro = usuarioBean.getNroRegistro();
				MaestroPersonalBean maestroPersonalBean = registroPersonalService.obtenerPersonaxRegistro(numeroRegistro);
				ReembolsoVO reembolsoVO = ReembolsoUtil.obtenerReembolsoVO(usuarioBean, maestroPersonalBean);
				if (reembolsoVO != null) {
					PlanViajeBean planViajeBean = consultaReembolsoService.obtenerPlanViajeToSustentoGastoReembolso(codPlanViaje);
					reembolsoVO.setCodPlanViaje(codPlanViaje);
					reembolsoVO.setCodPlanilla(planViajeBean.getCodPlanilla());
					reembolsoVO.setNumeroRegistroColaborador(planViajeBean.getNumeroRegistroAlterno());
					reembolsoVO.setCodigoEstadoReembolso(planViajeBean.getCodEstadoSolic());
					reembolsoVO.setDescripcionEstadoReembolso(planViajeBean.getNomEstSolic());
					reembolsoVO.setIndicadorExteriorDDJJ(planViajeBean.getIndicadorExteriorDDJJ());
					reembolsoVO.setMoneda(planViajeBean.getMoneda());
					reembolsoVO.setTipoDestino(planViajeBean.getTipoDestino());
					reembolsoVO.setFlagMenorIgual4Horas(viaticoConsultaService.obtenerFlagMenorIgual4Horas(planViajeBean.getIndicadorHoras(), planViajeBean.getNumeroHoras()));
					reembolsoVO.setDataJSON(dataJSON);
				}
				respuesta.put("reembolsoVO", reembolsoVO);
			}
			log.debug(RegistroReembolsoController.class.getSimpleName() + ".mostrarSustentarGastoReembolso.fin");
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			errorMessage = ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO);
			respuesta.put("errorMessage", errorMessage);
		}
		modelAndView = new ModelAndView(ReembolsoConstantes.SUSTENTAR_GASTO_REEMBOLSO_PAGE, respuesta);
		return modelAndView;
	}

	/**
	 * Metodo que permite registrar el sustento gasto.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	public ModelAndView registrarSustentoGasto(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoOperacion = ReembolsoConstantes.ERROR_OPERACION;
		String errorMessage = ReembolsoConstantes.CADENA_VACIA;
		String successMessage = ReembolsoConstantes.CADENA_VACIA;
		
		try {
			log.debug(RegistroReembolsoController.class.getSimpleName() + ".registrarSustentoGasto");
			String codPlanViaje = request.getParameter("codPlanViaje");
			String montoDevueltoComprobanteTotalString = request.getParameter("montoDevueltoComprobanteTotal");
			String indicadorExteriorDDJJ = request.getParameter("indicadorExteriorDDJJ");
			String tipoDestino = request.getParameter("tipoDestino");
			String flagMenorIgual4Horas = request.getParameter("flagMenorIgual4Horas");
			String moneda = request.getParameter("moneda");
			Double montoDevuelto = null;
			
			codPlanViaje = FormatoUtil.validarEmptyToNull(codPlanViaje);
			tipoDestino = FormatoUtil.validarEmptyToNull(tipoDestino);
			flagMenorIgual4Horas = FormatoUtil.validarEmptyToNull(flagMenorIgual4Horas);
			moneda = FormatoUtil.validarEmptyToNull(moneda);
			montoDevueltoComprobanteTotalString = FormatoUtil.validarEmptyToNull(montoDevueltoComprobanteTotalString);
			if (montoDevueltoComprobanteTotalString != null) {
				montoDevuelto = new Double(montoDevueltoComprobanteTotalString);
			}
			
			indicadorExteriorDDJJ = FormatoUtil.validarEmptyToNull(indicadorExteriorDDJJ);
			if (indicadorExteriorDDJJ == null) {
				indicadorExteriorDDJJ = ReembolsoConstantes.INDICADOR_EXT_DDJJ_NO;
			}
			
			if (codPlanViaje != null) {
				setAuditoriaBeanHolder(request, response);
				PlanViajeBean planViajeBean = new PlanViajeBean();
				planViajeBean.setCodPlanViaje(codPlanViaje);
				planViajeBean.setMontoDevuelto(montoDevuelto);
				planViajeBean.setIndicadorExteriorDDJJ(indicadorExteriorDDJJ);
				planViajeBean.setTipoDestino(tipoDestino);
				planViajeBean.setFlagMenorIgual4Horas(flagMenorIgual4Horas);
				planViajeBean.setMoneda(moneda);
				codigoOperacion = registroReembolsoService.registrarSustentoGasto(planViajeBean);
				successMessage = ResourceBundleUtil.getMessageReembolso(ReembolsoConstantes.MENSAJE_REGISTRO_SUSTENTO_GASTO_EXITOSO);
			}
			else {
				errorMessage = ResourceBundleUtil.getMessage(ReembolsoConstantes.MENSAJE_ERROR_GENERICO);
			}
			log.debug(RegistroReembolsoController.class.getSimpleName() + ".registrarSustentoGasto.fin");

		} catch (ServiceException ex) {
			errorMessage = ex.getMessage();
			log.error(ex.getMessage(), ex);
			
		} catch (Exception ex) {
			errorMessage = ResourceBundleUtil.getMessage(ReembolsoConstantes.MENSAJE_ERROR_GENERICO);
			log.error(ex.getMessage(), ex);
		}

		respuesta.put("codigoOperacion", codigoOperacion);
		respuesta.put("errorMessage", errorMessage);
		respuesta.put("successMessage", successMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	/**
	 * Metodo que permite obtener los comprobantes asociado a un plan viaje.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	public ModelAndView obtenerComprobantesGastoPasajeConcepto(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoConsulta = ReembolsoConstantes.ERROR_CONSULTA;
		String errorMessage = ReembolsoConstantes.CADENA_VACIA;
		
		try {
			log.debug(RegistroReembolsoController.class.getSimpleName() + ".obtenerComprobantesGastoPasajeConcepto");
			String codigoPlanViaje = request.getParameter("codigoPlanViaje");
			String simboloMoneda = request.getParameter("simboloMoneda");
			codigoPlanViaje = FormatoUtil.validarEmptyToNull(codigoPlanViaje);
			simboloMoneda = FormatoUtil.validarEmptyToNull(simboloMoneda);
			if (codigoPlanViaje != null) {
				BigDecimal montoComprobanteTotal = BigDecimal.ZERO;
				BigDecimal montoAsignadoTotal = BigDecimal.ZERO;
				ArrayList<PlanViajeRendicionBean> planViajeRendicionList = viaticoConsultaService.obtenerPlanViajeRendicionToRegistroRendicion(codigoPlanViaje, simboloMoneda);
				if (planViajeRendicionList != null && !planViajeRendicionList.isEmpty()) {
					int sizeList = planViajeRendicionList.size();
					montoComprobanteTotal = new BigDecimal(planViajeRendicionList.get(sizeList - 1).getMtoReconocido());
				}
				ArrayList<PlanViajeInformeDistribBean> gastoViaticoList = viaticoConsultaService.obtenerAsignacionGastoViatico(codigoPlanViaje, null, simboloMoneda);
				ArrayList<PlanViajeInformeDistribBean> pasajeTasaEmbarqueList = viaticoConsultaService.obtenerPasajeTasaEmbarque(codigoPlanViaje, null, simboloMoneda);
				ArrayList<PlanViajeConceptoBean> planViajeConceptoList = consultaReembolsoService.obtenerPlanViajeConcepto(codigoPlanViaje, simboloMoneda);
				if (planViajeConceptoList != null && !planViajeConceptoList.isEmpty()) {
					montoAsignadoTotal = new BigDecimal(planViajeConceptoList.get(0).getMonto());
				}
				BigDecimal montoDevueltoComprobanteTotal = montoComprobanteTotal;
				
				ReembolsoVO reembolsoVO = new ReembolsoVO();
				reembolsoVO.setPlanViajeRendicionList(planViajeRendicionList);
				reembolsoVO.setGastoViaticoList(gastoViaticoList);
				reembolsoVO.setPasajeTasaEmbarqueList(pasajeTasaEmbarqueList);
				reembolsoVO.setPlanViajeConceptoList(planViajeConceptoList);
				reembolsoVO.setMontoComprobanteTotal(NumeroUtil.formatearMonedaMontoToDecimal(null, 2, montoComprobanteTotal));
				reembolsoVO.setMontoComprobanteTotalFormateado(NumeroUtil.formatearMonto(simboloMoneda, montoComprobanteTotal, 2));
				reembolsoVO.setMontoAsignadoTotal(NumeroUtil.formatearMonedaMontoToDecimal(null, 2, montoAsignadoTotal));
				reembolsoVO.setMontoDevueltoComprobanteTotal(NumeroUtil.formatearMonedaMontoToDecimal(null, 2, montoDevueltoComprobanteTotal));
				codigoConsulta = ReembolsoConstantes.EXITO_CONSULTA;
				respuesta.put("reembolsoVO", reembolsoVO);
			}
			log.debug(RevisionReembolsoController.class.getSimpleName() + ".obtenerComprobantesGastoPasajeConcepto.fin");
			
		} catch (Exception ex) {
			errorMessage = ResourceBundleUtil.getMessage(ReembolsoConstantes.MENSAJE_ERROR_GENERICO);
			log.error(ex.getMessage(), ex);
		}
		
		respuesta.put("codigoConsulta", codigoConsulta);
		respuesta.put("errorMessage", errorMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}

	private String buscarIntendencia(String num_uuoo) throws Exception {

		String intendencia = StringUtils.EMPTY;

		List<DependenciaBean> dependenciaList = (List<DependenciaBean>) registroDependenciasService.buscarIntendenciaByUnidadOrganizacional(num_uuoo);

		if (CollectionUtils.isNotEmpty(dependenciaList)) {
			intendencia = StringUtils.trimToEmpty(dependenciaList.get(0).getIntendencia());
		}

		return intendencia;
	}
}