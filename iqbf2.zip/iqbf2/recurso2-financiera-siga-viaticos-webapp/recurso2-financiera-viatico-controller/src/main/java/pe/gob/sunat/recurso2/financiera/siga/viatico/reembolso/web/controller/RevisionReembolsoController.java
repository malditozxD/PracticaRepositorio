package pe.gob.sunat.recurso2.financiera.siga.viatico.reembolso.web.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.administracion.siga.util.Anio;
import pe.gob.sunat.recurso2.administracion.siga.util.FechaUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.FormatoUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.SolicitudDTO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.reembolso.service.RevisionReembolsoService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoConsultaService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoMensajeriaService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoReporteService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ReembolsoConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ReembolsoUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ResourceBundleUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.controller.BaseController;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.view.ReembolsoVO;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

/**
 * Controller que contiene los metodos necesarios para revisar un reembolso.
 * @author Jorge Ponce.
 */
public class RevisionReembolsoController extends BaseController {
	
	protected final Log log = LogFactory.getLog(getClass());
	private RevisionReembolsoService revisionReembolsoService;
	private ViaticoConsultaService viaticoConsultaService;
	private ViaticoReporteService viaticoReporteService;
	private ViaticoMensajeriaService viaticoMensajeriaService;
	private RegistroPersonalService registroPersonalService;
	
	public RevisionReembolsoService getRevisionReembolsoService() {
		return revisionReembolsoService;
	}

	public void setRevisionReembolsoService(RevisionReembolsoService revisionReembolsoService) {
		this.revisionReembolsoService = revisionReembolsoService;
	}

	public ViaticoConsultaService getViaticoConsultaService() {
		return viaticoConsultaService;
	}

	public void setViaticoConsultaService(ViaticoConsultaService viaticoConsultaService) {
		this.viaticoConsultaService = viaticoConsultaService;
	}

	public ViaticoReporteService getViaticoReporteService() {
		return viaticoReporteService;
	}

	public void setViaticoReporteService(ViaticoReporteService viaticoReporteService) {
		this.viaticoReporteService = viaticoReporteService;
	}

	public ViaticoMensajeriaService getViaticoMensajeriaService() {
		return viaticoMensajeriaService;
	}

	public void setViaticoMensajeriaService(ViaticoMensajeriaService viaticoMensajeriaService) {
		this.viaticoMensajeriaService = viaticoMensajeriaService;
	}

	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}

	/**
	 * Metodo que permite mostrar la bandeja reembolso autorizador.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView.
	 * @see ModelAndView
	 */
	public ModelAndView mostrarBandejaReembolsoAutorizador(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView modelAndView = null;
		String errorMessage = ReembolsoConstantes.CADENA_VACIA;
		try {
			log.debug(RevisionReembolsoController.class.getSimpleName() + ".mostrarBandejaReembolsoAutorizador");
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			String numeroRegistro = usuarioBean.getNroRegistro();
			MaestroPersonalBean maestroPersonalBean = registroPersonalService.obtenerPersonaxRegistro(numeroRegistro);
			ReembolsoVO reembolsoVO = ReembolsoUtil.obtenerReembolsoVO(usuarioBean, maestroPersonalBean);
			if (reembolsoVO != null) {
				String codigoEmpleado = maestroPersonalBean.getCodigoEmpleado();
				String flagAutorizador = ViaticoUtil.obtenerFlagViatico(registroPersonalService.determinaAutorizadorGastoMovilidad(codigoEmpleado));
				if (ReembolsoConstantes.UNO.equals(flagAutorizador)) {
					ArrayList<Anio> anioList = ReembolsoUtil.obtenerAniosReembolso(Integer.parseInt(FechaUtil.obtenerAnioActual()));
					reembolsoVO.setAnioList(anioList);
					reembolsoVO.setAnioActual(FechaUtil.obtenerAnioActual());
					
					reembolsoVO.setFlagAutorizador(flagAutorizador);
					reembolsoVO.setFlagMayor1UUOOAsociada("1");
					reembolsoVO.setFlagBuscarColaborador(ViaticoConstantes.BUSCAR_AUTORIZADOR);
					reembolsoVO.setFlagBuscarUUOO(ViaticoConstantes.BUSCAR_AUTORIZADOR);
				}
				else {
					errorMessage = ResourceBundleUtil.getMessage(ReembolsoConstantes.MENSAJE_ERROR_ACCESO, ReembolsoConstantes.PERFIL_AUTORIZADOR);
				}
			}
			respuesta.put("reembolsoVO", reembolsoVO);
			log.debug(RevisionReembolsoController.class.getSimpleName() + ".mostrarBandejaReembolsoAutorizador.fin");
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			errorMessage = ResourceBundleUtil.getMessage(ReembolsoConstantes.MENSAJE_ERROR_GENERICO);
		}
		respuesta.put("errorMessage", errorMessage);
		modelAndView = new ModelAndView(ReembolsoConstantes.REVISAR_REEMBOLSO_AUTORIZADOR_PAGE, respuesta);
		return modelAndView;
	}
	
	/**
	 * Metodo que permite obtener/buscar las planillas de la bandeja reembolso autorizador.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	public ModelAndView buscarPlanillasBandejaAutorizacionReembolso(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoConsulta = ReembolsoConstantes.ERROR_CONSULTA;
		String errorMessage = ReembolsoConstantes.CADENA_VACIA;
		boolean flagExistePlanilla = true;
		
		try {
			log.debug(RevisionReembolsoController.class.getSimpleName() + ".buscarPlanillasBandejaAutorizacionReembolso");
			String codigoDependencia = request.getParameter("codigoDependencia");
			String codPlanilla = request.getParameter("codPlanilla");
			String codTrabajador = request.getParameter("codTrabajador");
			String codEstadoSolic = request.getParameter("codEstadoSolic");
			String fechaDesdeString = request.getParameter("fechaDesde");
			String fechaHastaString = request.getParameter("fechaHasta");
			String codigoAutorizador = request.getParameter("codigoAutorizador");
			Date fechaDesde = null;
			Date fechaHasta = null;
			
			codigoDependencia = FormatoUtil.validarEmptyToNull(codigoDependencia);
			codPlanilla = FormatoUtil.validarEmptyToNull(codPlanilla);
			codTrabajador = FormatoUtil.validarEmptyToNull(codTrabajador);
			codigoAutorizador = FormatoUtil.validarEmptyToNull(codigoAutorizador);
			if (ReembolsoConstantes.CADENA_VACIA.equals(codEstadoSolic) || ReembolsoConstantes.CODIGO_00.equals(codEstadoSolic)) {
				codEstadoSolic = null;
			}
			
			if (!ReembolsoConstantes.CADENA_VACIA.equals(fechaDesdeString)) {
				fechaDesde = FechaUtil.parseStringDateToDate(fechaDesdeString, ReembolsoConstantes.DATE_FORMAT_DDMMYYYY);
			}
			
			if (!ReembolsoConstantes.CADENA_VACIA.equals(fechaHastaString)) {
				fechaHasta = FechaUtil.parseStringDateToDate(fechaHastaString, ReembolsoConstantes.DATE_FORMAT_DDMMYYYY);
			}
			
			if (codPlanilla != null) {
				flagExistePlanilla = viaticoConsultaService.existePlanilla(codPlanilla);
				codigoConsulta = ReembolsoConstantes.ERROR_CONSULTA_NO_EXISTE_SOLICITUD;
				errorMessage = ResourceBundleUtil.getMessage(ReembolsoConstantes.MENSAJE_ERROR_SOLICITUD_NO_EXISTE);
			}
			
			if (flagExistePlanilla) {
				ArrayList<PlanViajeBean> planViajeList = revisionReembolsoService.obtenerPlanViajeToBandejaAutorizacionReembolso(codigoDependencia, codPlanilla, codTrabajador, codEstadoSolic, fechaDesde, fechaHasta, codigoAutorizador);
				codigoConsulta = ReembolsoConstantes.EXITO_CONSULTA;
				respuesta.put("planViajeList", planViajeList);
			}
			log.debug(RevisionReembolsoController.class.getSimpleName() + ".buscarPlanillasBandejaAutorizacionReembolso.fin");
			
		} catch (Exception e) {
			errorMessage = ResourceBundleUtil.getMessage(ReembolsoConstantes.MENSAJE_ERROR_GENERICO);
			log.error(e.getMessage(), e);
		}
		
		respuesta.put("codigoConsulta", codigoConsulta);
		respuesta.put("errorMessage", errorMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	/**
	 * Metodo que permite exportar excel de la bandeja reembolso autorizador.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (Excel).
	 * @see ModelAndView
	 */
	public ModelAndView exportarExcelBandejaAutorizacionReembolso(HttpServletRequest request, HttpServletResponse response) {
		
		ModelAndView viewPage = null;
		
		try {
			log.debug(RevisionReembolsoController.class.getSimpleName() + ".exportarExcelBandejaAutorizacionReembolso");
			String codigoDependencia = request.getParameter("codigoDependencia");
			String codPlanilla = request.getParameter("codPlanilla");
			String codTrabajador = request.getParameter("codTrabajador");
			String codEstadoSolic = request.getParameter("codEstadoSolic");
			String fechaDesdeString = request.getParameter("fechaDesde");
			String fechaHastaString = request.getParameter("fechaHasta");
			String codigoAutorizador = request.getParameter("codigoAutorizador");
			Date fechaDesde = null;
			Date fechaHasta = null;
			
			codigoDependencia = FormatoUtil.validarEmptyToNull(codigoDependencia);
			codPlanilla = FormatoUtil.validarEmptyToNull(codPlanilla);
			codTrabajador = FormatoUtil.validarEmptyToNull(codTrabajador);
			codigoAutorizador = FormatoUtil.validarEmptyToNull(codigoAutorizador);
			if (ReembolsoConstantes.CADENA_VACIA.equals(codEstadoSolic) || ReembolsoConstantes.CODIGO_00.equals(codEstadoSolic)) {
				codEstadoSolic = null;
			}
			
			if (!ReembolsoConstantes.CADENA_VACIA.equals(fechaDesdeString)) {
				fechaDesde = FechaUtil.parseStringDateToDate(fechaDesdeString, ReembolsoConstantes.DATE_FORMAT_DDMMYYYY);
			}
			
			if (!ReembolsoConstantes.CADENA_VACIA.equals(fechaHastaString)) {
				fechaHasta = FechaUtil.parseStringDateToDate(fechaHastaString, ReembolsoConstantes.DATE_FORMAT_DDMMYYYY);
			}
			
			ArrayList<PlanViajeBean> planViajeList = revisionReembolsoService.obtenerPlanViajeCompletoToBandejaAutorizacionReembolso(codigoDependencia, codPlanilla, codTrabajador, codEstadoSolic, fechaDesde, fechaHasta, codigoAutorizador);
			String nombreArchivo = ReembolsoConstantes.ARCHIVO_EXCEL_PREFIJO + FechaUtil.formatDateToDateYYYYMMDDHHMMSS(new Date()) + ReembolsoConstantes.ARCHIVO_EXCEL_EXTENSION;
			response.setContentType("application/xls");
			response.setHeader("Content-Disposition", "attachment; filename=" + nombreArchivo);
			viaticoReporteService.generarExcelBandejaAutorizacionReembolso(response.getOutputStream(), planViajeList);
			log.debug(RevisionReembolsoController.class.getSimpleName() + ".exportarExcelBandejaAutorizacionReembolso.fin");
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		
		return viewPage;
	}
	
	/**
	 * Metodo que permite autorizar un reembolso de la bandeja reembolso autorizador.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	public ModelAndView autorizarReembolsoBandejaAutorizacionReembolso(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoOperacion = ReembolsoConstantes.ERROR_OPERACION;
		String errorMessage = ReembolsoConstantes.CADENA_VACIA;
		
		try {
			log.debug(RevisionReembolsoController.class.getSimpleName() + ".autorizarReembolsoBandejaAutorizacionReembolso");
			String codPlanViaje = request.getParameter("codPlanViaje");
			String codPerAutoriza = request.getParameter("codPerAutoriza");
			String codigoSedeAutorizador = request.getParameter("codigoSedeAutorizador");
			String codigoNivelAutorizador = request.getParameter("codigoNivelAutorizador");
			String expedientePlanViaje = request.getParameter("expedientePlanViaje");
			codPlanViaje = FormatoUtil.validarEmptyToNull(codPlanViaje);
			if (codPlanViaje != null) {
				setAuditoriaBeanHolder(request, response);
				codigoOperacion = revisionReembolsoService.autorizarReembolso(codPlanViaje, codPerAutoriza, codigoSedeAutorizador, codigoNivelAutorizador, expedientePlanViaje);
				if (ReembolsoConstantes.EXITO_OPERACION.equals(codigoOperacion)) {
					/*Enviar Notificacion*/
					SolicitudDTO solicitudDTO = viaticoConsultaService.obtenerPlanViajeToNotificacion(codPlanViaje);
					viaticoMensajeriaService.enviarNotificacionAutorizacionDeSolicitudDeReembolso(solicitudDTO);
				}
			}
			log.debug(RevisionReembolsoController.class.getSimpleName() + ".autorizarReembolsoBandejaAutorizacionReembolso.fin");
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			errorMessage = ResourceBundleUtil.getMessage(ReembolsoConstantes.MENSAJE_ERROR_GENERICO);
		}

		respuesta.put("codigoOperacion", codigoOperacion);
		respuesta.put("errorMessage", errorMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
}
