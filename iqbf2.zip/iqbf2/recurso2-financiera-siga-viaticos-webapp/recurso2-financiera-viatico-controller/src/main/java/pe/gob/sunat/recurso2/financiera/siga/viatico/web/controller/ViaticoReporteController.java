package pe.gob.sunat.recurso2.financiera.siga.viatico.web.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;

import pe.gob.sunat.recurso2.administracion.siga.archivo.util.ReporteArchivoBean;
import pe.gob.sunat.recurso2.administracion.siga.archivo.util.ReporteJasperBean;
import pe.gob.sunat.recurso2.administracion.siga.archivo.util.ReporteJasperConstantes;
import pe.gob.sunat.recurso2.administracion.siga.archivo.util.ReporteJasperUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoReporteService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.service.ConsultaSolicitudService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.service.RegistroSolicitudService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ReporteConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ResourceBundleUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.singleton.ViaticosProcesoSingleton;

/**
 * La clase ViaticoReporteController realiza las exportacion de reportes.
 * 
 * @author Jhonny Quispe
 */
public class ViaticoReporteController extends BaseController{

	protected final Log log = LogFactory.getLog(getClass());
	
	/** Declaración del servicio consultaSolicitudService. */
	private ConsultaSolicitudService consultaSolicitudService;
	
	/** Declaración del servicio viaticoReporteService. */
	private ViaticoReporteService viaticoReporteService;
	
	/** Declaración del servicio registroSolicitudService. */
	private RegistroSolicitudService registroSolicitudService;
	
	/** Declaración del servicio viaticosProcesoSingleton. */
	private ViaticosProcesoSingleton viaticosProcesoSingleton;	
	
	public ConsultaSolicitudService getConsultaSolicitudService() {
		return consultaSolicitudService;
	}
	public void setConsultaSolicitudService(
			ConsultaSolicitudService consultaSolicitudService) {
		this.consultaSolicitudService = consultaSolicitudService;
	}

	public ViaticoReporteService getViaticoReporteService() {
		return viaticoReporteService;
	}
	public void setViaticoReporteService(ViaticoReporteService viaticoReporteService) {
		this.viaticoReporteService = viaticoReporteService;
	}

	public RegistroSolicitudService getRegistroSolicitudService() {
		return registroSolicitudService;
	}
	public void setRegistroSolicitudService(
			RegistroSolicitudService registroSolicitudService) {
		this.registroSolicitudService = registroSolicitudService;
	}	

	public ViaticosProcesoSingleton getViaticosProcesoSingleton() {
		return viaticosProcesoSingleton;
	}
	public void setViaticosProcesoSingleton(
			ViaticosProcesoSingleton viaticosProcesoSingleton) {
		this.viaticosProcesoSingleton = viaticosProcesoSingleton;
	}
	/**
	 * Método que permite imprimir una solicitud de viático.
	 * 
	 * @author Juan Farro
	 * @see ModelAndView
	 * @param request objeto petición de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la petición
	 */
	public ModelAndView imprimirSolicitudViatico(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = null;

		boolean customMessage = false;
		String errorMessage = StringUtils.EMPTY;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {			
			log.debug(getClass().getName() + " Inicio del método imprimirSolicitudViatico");

			String codPlanilla = StringUtils.trimToEmpty(request.getParameter("codPlanilla"));
			
			PlanViajeBean planViaje = consultaSolicitudService.buscarPlanViajePlanilla(codPlanilla);
			
			if (planViaje == null) {
				customMessage = true;
				throw new Exception("Plan de Viaje no existe");
			}			
		
			log.debug("proceso:" +viaticosProcesoSingleton.obtenerProceso());
			
			ReporteJasperBean reporteJasperBean = viaticoReporteService.generarReporteSolicitudViatico(planViaje.getCodPlanViaje(), viaticosProcesoSingleton.obtenerProceso());

			ReporteArchivoBean reporteArchivoBean = ReporteJasperUtil.generarArchivoPDF(reporteJasperBean, ReporteJasperConstantes.RUTA_JASPER_VIATICOS, ReporteJasperConstantes.RUTA_PDF_VIATICOS);
			
			if (reporteArchivoBean == null) {
				customMessage = true;
				throw new Exception("No se pudo generar el reporte");
			}

			setAuditoriaBeanHolder(request, response);

			// setear el response y escribir los bytes del pdf
			byte[] dataBytes = reporteArchivoBean.getData();

			String nombreArchivoPDF = ReporteConstantes.PLANILLA_VIATICO_NOMBRE_ARCHIVO;

			response.setContentType("application/pdf"); // response
			response.setHeader("Content-Disposition", "attachment; filename=\"" + nombreArchivoPDF + "\";");
			response.setHeader("Cache-Control", "public");
			response.setHeader("Pragma", "public");
			response.setDateHeader("Expires", 0);
			response.setContentLength(dataBytes.length);

			ServletOutputStream ouputStream = response.getOutputStream();

			ouputStream.write(dataBytes, 0, dataBytes.length);
			ouputStream.flush();
			ouputStream.close();

		} catch (Exception e) {

			log.error(e.getMessage(), e);
			errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO);

		} finally {

			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(ViaticoConstantes.REPORTE_ERROR_PAGE, respuesta);

			log.debug(getClass().getName() + " Fin del método imprimirSolicitudViatico");
		}

		return modelAndView;
	}
	
	/**
     * Método que permite imprimir una rendicion de viático.
     * 
     * @author Jhonny Quispe
     * @see ModelAndView
     * @param request objeto petición de la clase HttpServletRequest
     * @param response objeto respuesta de la clase HttpServletResponse
     * @return el objeto ModelAndView con la respuesta de la petición
     */
    public ModelAndView imprimirRendicionViatico(HttpServletRequest request, HttpServletResponse response){
        ModelAndView modelAndView = null;

        boolean customMessage = false;
        String errorMessage = StringUtils.EMPTY;
        Map<String, Object> respuesta = new HashMap<String, Object>();

        try {            
            log.debug(getClass().getName() + " Inicio del método imprimirRendicionViatico");

            String codPlanilla = StringUtils.trimToEmpty(request.getParameter("codPlanilla"));
            
            PlanViajeBean planViaje = consultaSolicitudService.buscarPlanViajePlanilla(codPlanilla);
            
            if (planViaje == null) {
                customMessage = true;
                throw new Exception("Plan de Viaje no existe");
            }            
            
            log.debug("proceso:" +viaticosProcesoSingleton.obtenerProceso());
            ReporteJasperBean reporteJasperBean = viaticoReporteService.generarReporteRendicionViatico(planViaje.getCodPlanViaje(), viaticosProcesoSingleton.obtenerProceso());

            log.debug(getClass().getName() + " Inicio del método generarReporteRendicionViatico");
    		// generando el archivo pdf
    		ReporteArchivoBean reporteArchivoBean = ReporteJasperUtil.generarArchivoPDF(reporteJasperBean, ReporteJasperConstantes.RUTA_JASPER_VIATICOS, ReporteJasperConstantes.RUTA_PDF_VIATICOS);
            
            if (reporteArchivoBean == null) {
                customMessage = true;
                throw new Exception("No se pudo generar el reporte");
            }

          //  setAuditoriaBeanHolder(request, response);
        
            // setear el response y escribir los bytes del pdf
            byte[] dataBytes = reporteArchivoBean.getData();

            String nombreArchivoPDF = ReporteConstantes.PLANILLA_RENDICION_VIATICO_NOMBRE_ARCHIVO;

            response.setContentType("application/pdf"); // response
            response.setHeader("Content-Disposition", "attachment; filename=\"" + nombreArchivoPDF + "\";");
            response.setHeader("Cache-Control", "public");
            response.setHeader("Pragma", "public");
            response.setDateHeader("Expires", 0);
            response.setContentLength(dataBytes.length);

            ServletOutputStream ouputStream = response.getOutputStream();

            ouputStream.write(dataBytes, 0, dataBytes.length);
            ouputStream.flush();
            ouputStream.close();

        } catch (Exception e) {

            log.error(e.getMessage(), e);
            errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO);

        } finally {

            respuesta.put("errorMessage", errorMessage);
            modelAndView = new ModelAndView(ViaticoConstantes.REPORTE_ERROR_PAGE, respuesta);            
            log.debug(getClass().getName() + " Fin del método imprimirRendicionViatico");
        }

        return modelAndView;        
    }
	
    
    /**
     * Método que permite imprimir una declaracion jurada.
     * 
     * @author Rocio Paz
     * @see ModelAndView
     * @param request objeto petición de la clase HttpServletRequest
     * @param response objeto respuesta de la clase HttpServletResponse
     * @return el objeto ModelAndView con la respuesta de la petición
     */
    public ModelAndView imprimirRendicionDeclaracionJurada(HttpServletRequest request, HttpServletResponse response){
        ModelAndView modelAndView = null;

        boolean customMessage = false;
        String errorMessage = StringUtils.EMPTY;
        Map<String, Object> respuesta = new HashMap<String, Object>();

        try {            
            log.debug(getClass().getName() + " Inicio del método imprimirRendicionDeclaracionJurada");

            String codPlanilla = StringUtils.trimToEmpty(request.getParameter("codPlanilla"));
            
            PlanViajeBean planViaje = consultaSolicitudService.buscarPlanViajePlanilla(codPlanilla);
            
            if (planViaje == null) {
                customMessage = true;
                throw new Exception("Plan de Viaje no existe");
            }            
            
            log.debug("proceso:" +viaticosProcesoSingleton.obtenerProceso());
            ReporteJasperBean reporteJasperBean = viaticoReporteService.generarReporteRendicionDeclaracion(planViaje.getCodPlanViaje(), viaticosProcesoSingleton.obtenerProceso());
            ReporteArchivoBean reporteArchivoBean = ReporteJasperUtil.generarArchivoPDF(reporteJasperBean, ReporteJasperConstantes.RUTA_JASPER_VIATICOS, ReporteJasperConstantes.RUTA_PDF_VIATICOS);
            
            if (reporteArchivoBean == null) {
                customMessage = true;
                throw new Exception("No se pudo generar el reporte");
            }

          //  setAuditoriaBeanHolder(request, response);
        
            // setear el response y escribir los bytes del pdf
            byte[] dataBytes = reporteArchivoBean.getData();

            String nombreArchivoPDF = ReporteConstantes.PLANILLA_RENDICION_DECLARACION_JURADA_NOMBRE_ARCHIVO;

            response.setContentType("application/pdf"); // response
            response.setHeader("Content-Disposition", "attachment; filename=\"" + nombreArchivoPDF + "\";");
            response.setHeader("Cache-Control", "public");
            response.setHeader("Pragma", "public");
            response.setDateHeader("Expires", 0);
            response.setContentLength(dataBytes.length);

            ServletOutputStream ouputStream = response.getOutputStream();

            ouputStream.write(dataBytes, 0, dataBytes.length);
            ouputStream.flush();
            ouputStream.close();

        } catch (Exception e) {

            log.error(e.getMessage(), e);
            errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO);

        } finally {

            respuesta.put("errorMessage", errorMessage);
            modelAndView = new ModelAndView(ViaticoConstantes.REPORTE_ERROR_PAGE, respuesta);            
            log.debug(getClass().getName() + " Fin del método imprimirRendicionViatico");
        }

        return modelAndView;        
    }

    /**
     * Método que permite imprimir una declaracion jurada de Permanencia.
     * 
     * @author Rocio Paz
     * @see ModelAndView
     * @param request objeto petición de la clase HttpServletRequest
     * @param response objeto respuesta de la clase HttpServletResponse
     * @return el objeto ModelAndView con la respuesta de la petición
     */
    public ModelAndView imprimirRendicionDeclaracionJuradaPermanencia(HttpServletRequest request, HttpServletResponse response){
        ModelAndView modelAndView = null;

        boolean customMessage = false;
        String errorMessage = StringUtils.EMPTY;
        Map<String, Object> respuesta = new HashMap<String, Object>();

        try {            
            log.debug(getClass().getName() + " Inicio del método imprimirRendicionDeclaracionJuradaPermanencia");

            String codPlanilla = StringUtils.trimToEmpty(request.getParameter("codPlanilla"));
            
            PlanViajeBean planViaje = consultaSolicitudService.buscarPlanViajePlanilla(codPlanilla);
            
            if (planViaje == null) {
                customMessage = true;
                throw new Exception("Plan de Viaje no existe");
            }            
            
            log.debug("proceso:" +viaticosProcesoSingleton.obtenerProceso());
            ReporteArchivoBean reporteArchivoBean = viaticoReporteService.generarReporteRendicionDeclaracionPermanencia(planViaje.getCodPlanViaje(), viaticosProcesoSingleton.obtenerProceso());

            if (reporteArchivoBean == null) {
                customMessage = true;
                throw new Exception("No se pudo generar el reporte");
            }

          //  setAuditoriaBeanHolder(request, response);
        
            // setear el response y escribir los bytes del pdf
            byte[] dataBytes = reporteArchivoBean.getData();

            String nombreArchivoPDF = ReporteConstantes.PLANILLA_RENDICION_DECLARACION_JURADA_PERMANENCIA_NOMBRE_ARCHIVO;

            response.setContentType("application/pdf"); // response
            response.setHeader("Content-Disposition", "attachment; filename=\"" + nombreArchivoPDF + "\";");
            response.setHeader("Cache-Control", "public");
            response.setHeader("Pragma", "public");
            response.setDateHeader("Expires", 0);
            response.setContentLength(dataBytes.length);

            ServletOutputStream ouputStream = response.getOutputStream();

            ouputStream.write(dataBytes, 0, dataBytes.length);
            ouputStream.flush();
            ouputStream.close();

        } catch (Exception e) {

            log.error(e.getMessage(), e);
            errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO);

        } finally {

            respuesta.put("errorMessage", errorMessage);
            modelAndView = new ModelAndView(ViaticoConstantes.REPORTE_ERROR_PAGE, respuesta);            
            log.debug(getClass().getName() + " Fin del método imprimirRendicionViatico");
        }

        return modelAndView;        
    }
    
    /**
     * Método que permite imprimir una rendicion de viático.
     * 
     * @author Samuel Dionisio
     * @see ModelAndView
     * @param request objeto petición de la clase HttpServletRequest
     * @param response objeto respuesta de la clase HttpServletResponse
     * @return el objeto ModelAndView con la respuesta de la petición
     */
    public ModelAndView imprimirReembolsoViatico(HttpServletRequest request, HttpServletResponse response){
        ModelAndView modelAndView = null;

        boolean customMessage = false;
        String errorMessage = StringUtils.EMPTY;
        Map<String, Object> respuesta = new HashMap<String, Object>();

        try {            
            log.debug(getClass().getName() + " Inicio del método imprimirReembolsoViatico");

            String codPlanilla = StringUtils.trimToEmpty(request.getParameter("codPlanilla"));
            
            PlanViajeBean planViaje = consultaSolicitudService.buscarPlanViajePlanilla(codPlanilla);
            
            if (planViaje == null) {
                customMessage = true;
                throw new Exception("Plan de Viaje no existe");
            }            
            
            log.debug("proceso:" +viaticosProcesoSingleton.obtenerProceso());
            ReporteArchivoBean reporteArchivoBean = viaticoReporteService.generarReporteReembolsoViatico(planViaje.getCodPlanViaje(), viaticosProcesoSingleton.obtenerProceso());

            if (reporteArchivoBean == null) {
                customMessage = true;
                throw new Exception("No se pudo generar el reporte");
            }

          //  setAuditoriaBeanHolder(request, response);
        
            // setear el response y escribir los bytes del pdf
            byte[] dataBytes = reporteArchivoBean.getData();

            String nombreArchivoPDF = ReporteConstantes.PLANILLA_REEMBOLSO_VIATICO_NOMBRE_ARCHIVO;

            response.setContentType("application/pdf"); // response
            response.setHeader("Content-Disposition", "attachment; filename=\"" + nombreArchivoPDF + "\";");
            response.setHeader("Cache-Control", "public");
            response.setHeader("Pragma", "public");
            response.setDateHeader("Expires", 0);
            response.setContentLength(dataBytes.length);

            ServletOutputStream ouputStream = response.getOutputStream();

            ouputStream.write(dataBytes, 0, dataBytes.length);
            ouputStream.flush();
            ouputStream.close();

        } catch (Exception e) {

            log.error("Error imprimirReembolsoViatico" + e.getMessage(), e);
            errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO);

        } finally {

            respuesta.put("errorMessage", errorMessage);
            modelAndView = new ModelAndView(ViaticoConstantes.REPORTE_ERROR_PAGE, respuesta);            
            log.debug(getClass().getName() + " Fin del método imprimirRendicionViatico");
        }

        return modelAndView;        
    }
}
