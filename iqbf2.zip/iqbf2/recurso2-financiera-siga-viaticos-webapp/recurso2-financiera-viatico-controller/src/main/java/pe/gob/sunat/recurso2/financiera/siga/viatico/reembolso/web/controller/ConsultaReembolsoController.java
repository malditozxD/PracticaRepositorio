package pe.gob.sunat.recurso2.financiera.siga.viatico.reembolso.web.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.SysEstadosBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.administracion.siga.util.FechaUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.FormatoUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.reembolso.service.ConsultaReembolsoService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.reembolso.service.RevisionReembolsoService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoConsultaService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoGeneralService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoReporteService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.service.ConsultaSolicitudService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ReembolsoConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ReembolsoUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ResourceBundleUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.SolicitudUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.controller.BaseController;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.view.ReembolsoVO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.view.SolicitudVO;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

/**
 * La clase ConsultaReembolsoController realiza las consultas y operaciones con solicitudes de reembolso
 * 
 * @author Juan Farro
 */
public class ConsultaReembolsoController extends BaseController {

	/** Declaracion del log para realizar los debug, info, error, etc. */
	protected final Log log = LogFactory.getLog(getClass());

	/** Declaracion del servicio consultaReembolsoService. */
	private ConsultaReembolsoService consultaReembolsoService;
	
	/** Declaracion del servicio registroPersonalService. */
	private RegistroPersonalService registroPersonalService;
	
	/** Declaracion del servicio viaticoGeneralService. */
	private ViaticoGeneralService viaticoGeneralService;
	
	/** Declaracion del servicio consultaSolicitudService. */
	private ConsultaSolicitudService consultaSolicitudService;
	
	/** Declaracion del servicio viaticoConsultaService. */
	private ViaticoConsultaService viaticoConsultaService;
	
	/** Declaracion del servicio viaticoReporteService. */
	private ViaticoReporteService viaticoReporteService;
	
	/** Declaracion del servicio revisionReembolsoService. */
	private RevisionReembolsoService revisionReembolsoService;
	
	public ConsultaReembolsoService getConsultaReembolsoService() {
		return consultaReembolsoService;
	}

	public void setConsultaReembolsoService(ConsultaReembolsoService consultaReembolsoService) {
		this.consultaReembolsoService = consultaReembolsoService;
	}

	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(
			RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}

	public ViaticoGeneralService getViaticoGeneralService() {
		return viaticoGeneralService;
	}

	public void setViaticoGeneralService(ViaticoGeneralService viaticoGeneralService) {
		this.viaticoGeneralService = viaticoGeneralService;
	}

	public ConsultaSolicitudService getConsultaSolicitudService() {
		return consultaSolicitudService;
	}

	public void setConsultaSolicitudService(
			ConsultaSolicitudService consultaSolicitudService) {
		this.consultaSolicitudService = consultaSolicitudService;
	}

	public ViaticoConsultaService getViaticoConsultaService() {
		return viaticoConsultaService;
	}

	public void setViaticoConsultaService(
			ViaticoConsultaService viaticoConsultaService) {
		this.viaticoConsultaService = viaticoConsultaService;
	}

	public ViaticoReporteService getViaticoReporteService() {
		return viaticoReporteService;
	}

	public void setViaticoReporteService(ViaticoReporteService viaticoReporteService) {
		this.viaticoReporteService = viaticoReporteService;
	}

	public RevisionReembolsoService getRevisionReembolsoService() {
		return revisionReembolsoService;
	}

	public void setRevisionReembolsoService(
			RevisionReembolsoService revisionReembolsoService) {
		this.revisionReembolsoService = revisionReembolsoService;
	}

	/**
	 * Metodo que permite obtener plan viaje con su detalle de la bandeja reembolso.
	 * @author Jorge Ponce.
	 * @param request: objeto de la clase HttpServletRequest.
	 * @param response: objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	public ModelAndView obtenerPlanViajeDetalleBandejaReembolso(HttpServletRequest request, HttpServletResponse response) {

		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoConsulta = ReembolsoConstantes.ERROR_CONSULTA;
		String errorMessage = ReembolsoConstantes.CADENA_VACIA;

		try {
			log.debug(ConsultaReembolsoController.class.getSimpleName() + ".obtenerPlanViajeDetalleBandejaReembolso");
			String codPlanViaje = request.getParameter("codPlanViaje");
			codPlanViaje = FormatoUtil.validarEmptyToNull(codPlanViaje);
			ArrayList<PlanViajeBean> planViajeList = consultaReembolsoService.obtenerPlanViajeDetalleToBandejaReembolso(codPlanViaje, null, null, null, null, null, null, null);
			if (planViajeList != null && !planViajeList.isEmpty()) {
				PlanViajeBean planViajeBean = planViajeList.get(0);
				codigoConsulta = ReembolsoConstantes.EXITO_CONSULTA;
				respuesta.put("planViajeBean", planViajeBean);
				
			}
			log.debug(ConsultaReembolsoController.class.getSimpleName() + ".obtenerPlanViajeDetalleBandejaReembolso.fin");

		} catch (Exception e) {
			errorMessage = ResourceBundleUtil.getMessage(ReembolsoConstantes.MENSAJE_ERROR_GENERICO);
			log.error(e.getMessage(), e);
		}

		respuesta.put("codigoConsulta", codigoConsulta);
		respuesta.put("errorMessage", errorMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	
	
	/**
	 * Metodo que permite cargar la pagina de inicio para Revisar Bandeja de Solicitudes.
	 * 
	 * @author Samuel Dionisio
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion en formato JSON
	 * @see ModelAndView
	 */
	public ModelAndView generarBandejaRevisionReembolso(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;

		boolean customMessage = false;
		String errorMessage = StringUtils.EMPTY;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			log.debug(getClass().getName() + " Inicio del metodo generarBandejaRevision");

			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");

			String dataJSON = request.getParameter("dataJSON");
			
			if(StringUtils.isNotEmpty(dataJSON)){
				respuesta.put("dataJSON", dataJSON);
			}else{
				respuesta.put("dataJSON", ViaticoConstantes.CADENA_VACIA);
			}
			
			// buscar datos del colaborador en session
			MaestroPersonalBean maestroPersonalBean = registroPersonalService.obtenerPersonaxRegistro(usuarioBean.getNroRegistro());

			if (maestroPersonalBean == null) {
				customMessage = false;
				throw new Exception("Usuario no existe");
			}

			// armar el view object para la vista
			SolicitudVO solicitudVO = SolicitudUtil.obtenerSolicitudVO(usuarioBean, maestroPersonalBean);

			// setear el número de planilla
			//solicitudVO.setCodPlanilla(codPlanilla);

			// estados de solicitud
			List<SysEstadosBean> listaEstados = consultaReembolsoService.obtenerListaEstadosReembolsoViatico();
			solicitudVO.setEstadoSolicitudList(listaEstados);

			// canales de atencion
//			List<T01ParametroBean> listaCanales = consultaSolicitudService.obtenerListaCanalesAtencionViatico();
//			solicitudVO.setCanalAtencionList(listaCanales);

			// anios - últimos 5 anios
			int anioActual = Integer.parseInt(FechaUtil.obtenerAnioActual());
			List<String> listaAnios = SolicitudUtil.obtenerListaAniosBandejasSolicitud(anioActual);
			solicitudVO.setListaAnios(listaAnios);
			solicitudVO.setAnioActual(String.valueOf(anioActual));

			// obtener flags de registrador y mayor de una UUOO asociada
			Long numeroRegistros = viaticoGeneralService.determinarRegistrador(maestroPersonalBean.getCodigoEmpleado());
			solicitudVO.setFlagRegistrador(ViaticoUtil.obtenerFlagRegistrador(numeroRegistros));
			solicitudVO.setFlagMayor1UUOOAsociada(ViaticoUtil.obtenerFlagMayor1UUOOAsociada(numeroRegistros));

			// obtener flag de registrador universal
			numeroRegistros = viaticoGeneralService.determinarRegistradorUniversal(maestroPersonalBean.getCodigoEmpleado());
			solicitudVO.setFlagRegistradorUniversal(ViaticoUtil.obtenerFlagRegistradorUniversal(numeroRegistros));

			// determinar flags para buscar uuoo y colaborador
			String codigoTipoUUOOViatico = ViaticoUtil.obtenerFlagBuscarUUOO(solicitudVO.getFlagRegistradorUniversal(), solicitudVO.getFlagRegistrador());
			String codigoTipoUsuarioViatico = ViaticoUtil.obtenerFlagBuscarColaborador(solicitudVO.getFlagRegistradorUniversal(), solicitudVO.getFlagRegistrador());

			solicitudVO.setCodigoTipoUUOOViatico(codigoTipoUUOOViatico);
			solicitudVO.setCodigoTipoUsuarioViatico(codigoTipoUsuarioViatico);

			// seteo del view object para visualizar el formulario
			respuesta.put("solicitudVO", solicitudVO);

			// seteo de estados de solicitud de viatico
			ReembolsoUtil.poblarConstantesEstadosReembolso(respuesta);

			
			
		} catch (Exception e) {

			log.error("Error generarBandejaRevisionReembolso", e);
			errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO);

		} finally {

			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(ReembolsoConstantes.REVISAR_REEMBOLSO_BANDEJA_PAGE, respuesta);

			log.debug(getClass().getName() + " Fin del metodo generarBandejaRevision");
		}

		return modelAndView;
	}

	/**
	 * Metodo que permite cargar la pagina de inicio para Consultar Bandeja de Solicitudes
	 * 
	 * @author Samuel Dionisio
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView generarBandejaConsultaReembolso(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;

		boolean customMessage = false;
		String errorMessage = StringUtils.EMPTY;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			log.debug(getClass().getName() + " Inicio del metodo generarBandejaConsulta");

			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");

			// buscar datos del colaborador en session
			MaestroPersonalBean maestroPersonalBean = registroPersonalService.obtenerPersonaxRegistro(usuarioBean.getNroRegistro());

			if (maestroPersonalBean == null) {
				customMessage = false;
				throw new Exception("Usuario no existe");
			}

			
			String dataJSON = request.getParameter("dataJSON");
			
			if(StringUtils.isNotEmpty(dataJSON)){
				respuesta.put("dataJSON", dataJSON);
			}else{
				respuesta.put("dataJSON", ViaticoConstantes.CADENA_VACIA);
			}
			
			// armar el view object para la vista
			SolicitudVO solicitudVO = SolicitudUtil.obtenerSolicitudVO(usuarioBean, maestroPersonalBean);

			// estados de solicitud
			List<SysEstadosBean> listaEstados = consultaReembolsoService.obtenerListaEstadosReembolsoViatico();
			solicitudVO.setEstadoSolicitudList(listaEstados);

			// canales de atencion
//			List<T01ParametroBean> listaCanales = consultaSolicitudService.obtenerListaCanalesAtencionViatico();
//			solicitudVO.setCanalAtencionList(listaCanales);

			// anios - últimos 5 anios
			int anioActual = Integer.parseInt(FechaUtil.obtenerAnioActual());
			List<String> listaAnios = SolicitudUtil.obtenerListaAniosBandejasSolicitud(anioActual);
			solicitudVO.setListaAnios(listaAnios);
			solicitudVO.setAnioActual(String.valueOf(anioActual));

			// obtener flags de registrador y mayor de una UUOO asociada
			Long numeroRegistros = viaticoGeneralService.determinarRegistrador(maestroPersonalBean.getCodigoEmpleado());
			solicitudVO.setFlagRegistrador(ViaticoUtil.obtenerFlagRegistrador(numeroRegistros));
			solicitudVO.setFlagMayor1UUOOAsociada(ViaticoUtil.obtenerFlagMayor1UUOOAsociada(numeroRegistros));

			// obtener flag de registrador universal
			numeroRegistros = viaticoGeneralService.determinarRegistradorUniversal(maestroPersonalBean.getCodigoEmpleado());
			solicitudVO.setFlagRegistradorUniversal(ViaticoUtil.obtenerFlagRegistradorUniversal(numeroRegistros));

			// determinar flags para buscar uuoo y colaborador
			String codigoTipoUUOOViatico = ViaticoUtil.obtenerFlagBuscarUUOO(solicitudVO.getFlagRegistradorUniversal(), solicitudVO.getFlagRegistrador());
			String codigoTipoUsuarioViatico = ViaticoUtil.obtenerFlagBuscarColaborador(solicitudVO.getFlagRegistradorUniversal(), solicitudVO.getFlagRegistrador());

			solicitudVO.setCodigoTipoUUOOViatico(codigoTipoUUOOViatico);
			solicitudVO.setCodigoTipoUsuarioViatico(codigoTipoUsuarioViatico);

			// seteo del view object para visualizar el formulario
			respuesta.put("solicitudVO", solicitudVO);

			// seteo de estados de solicitud de viatico
			ReembolsoUtil.poblarConstantesEstadosReembolso(respuesta);
			
		} catch (Exception e) {

			log.error("Error generarBandejaConsultaReembolso", e);
			errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO);

		} finally {

			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(ReembolsoConstantes.CONSULTAR_REEMBOLSO_BANDEJA_PAGE, respuesta);

			log.debug(getClass().getName() + " Fin del metodo generarBandejaConsulta");
		}

		return modelAndView;
	}

	/**
	 * Metodo que permite retornar las solicitudes de viatico en formato JSON de la bandeja de consulta 
	 * 
	 * @author Samuel Dionisio
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion en formato JSON
	 * @throws Exception
	 * @see ModelAndView
	 */
	public ModelAndView buscarReembolsosBandejaConsulta(HttpServletRequest request, HttpServletResponse response) throws Exception {

		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {
			log.debug(getClass().getName() + " Inicio del metodo buscarSolicitudesBandejaConsulta");

			String codDependencia = StringUtils.trimToNull(request.getParameter("codDependencia"));
			String codColaborador = StringUtils.trimToNull(request.getParameter("codColaborador"));
			String codEstado = StringUtils.trimToNull(request.getParameter("codEstado"));
			String codCanal = StringUtils.trimToNull(request.getParameter("codCanal"));
			String numPlanilla = StringUtils.trimToNull(request.getParameter("numPlanilla"));
			String fechaDesde = StringUtils.trimToNull(request.getParameter("fechaDesde"));
			String fechaHasta = StringUtils.trimToNull(request.getParameter("fechaHasta"));

			// INDICADORES QUE LA PETICIÓN AJAX CULMINÓ SIN ERRORES
			respuesta.put("error", ViaticoConstantes.NO);
			respuesta.put("msgError", StringUtils.EMPTY);

			// validacion, que si ingresa número de planilla, valide que esta exista
			respuesta.put("hayValidacion", ViaticoConstantes.NO);
			respuesta.put("msgValidacion", StringUtils.EMPTY);

			if (StringUtils.isNotBlank(numPlanilla)) {

				boolean existePlanilla = viaticoConsultaService.existePlanilla(numPlanilla);
				if (!existePlanilla) {

					respuesta.put("hayValidacion", ViaticoConstantes.SI);
					respuesta.put("msgValidacion", ResourceBundleUtil.getMessageReembolso(ViaticoConstantes.BANDEJA_CONSULTA_MENSAJE_ERROR_SOLICITUD_NO_EXISTE));

					modelAndView = new ModelAndView(getJsonView(), respuesta);

					return modelAndView;
				}

			}

			Date fechaDesdeDate = null;
			if (fechaDesde != null && FechaBean.validaFormato(fechaDesde, FechaBean.FORMATO_DEFAULT)) {
				fechaDesdeDate = ViaticoUtil.parseStringDateToDate(fechaDesde);
			}

			Date fechaHastaDate = null;
			if (fechaHasta != null && FechaBean.validaFormato(fechaHasta, FechaBean.FORMATO_DEFAULT)) {
				fechaHastaDate = ViaticoUtil.parseStringDateToDate(fechaHasta);
			}

			// parametros de búsqueda
			Map<String, Object> parmSearch = new HashMap<String, Object>();

			parmSearch.put("codColaborador", codColaborador);
			parmSearch.put("codDependencia", codDependencia);
			parmSearch.put("codEstado", codEstado);
			parmSearch.put("codCanal", codCanal);
			parmSearch.put("numPlanilla", numPlanilla);
			parmSearch.put("fechaDesde", fechaDesdeDate);
			parmSearch.put("fechaHasta", fechaHastaDate);
			parmSearch.put("nom_tabla", ViaticoConstantes.ESTADO_VIATICO_NOMBRE_TABLA);			

			setAuditoriaBeanHolder(request, response);

			List<PlanViajeBean> listSolicitudes = (List<PlanViajeBean>) consultaReembolsoService.obtenerReembolsosBandejaConsultaRevision(parmSearch);

			respuesta.put("listSolicitudes", listSolicitudes);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {

			log.error("Error buscarReembolsosBandejaConsulta", e);

			// INDICADORES QUE LA PETICION AJAX CULMINO CON ERRORES.
			// NOTA: El key msgError se usa como mensaje generico de error no manejable. 
			//       Otros keys del mapa respuesta se usan para personalizar los mensajes de negocio visibles al usuario.
			respuesta.put("error", ViaticoConstantes.SI);
			respuesta.put("msgError", ViaticoConstantes.MSG_ERROR_OPERACION_NO_EFECTUADA);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} finally {

			log.debug(getClass().getName() + " Fin del metodo buscarSolicitudesBandejaConsulta");

		}

		return modelAndView;
	}
	
	
	/**
	 * Metodo que permite retornar las solicitudes de viatico en formato JSON de la bandeja de consulta
	 * 
	 * @author Samuel Dionisio
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion en formato JSON
	 * @throws Exception
	 * @see ModelAndView
	 */
	public ModelAndView buscarReembolsosBandejaRevision(HttpServletRequest request, HttpServletResponse response) throws Exception {

		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			log.debug(getClass().getName() + " Inicio del metodo buscarReembolsosBandejaRevision");

			String codDependencia = StringUtils.trimToNull(request.getParameter("codDependencia"));
			String codColaborador = StringUtils.trimToNull(request.getParameter("codColaborador"));
			String codEstado = StringUtils.trimToNull(request.getParameter("codEstado"));
			String codCanal = StringUtils.trimToNull(request.getParameter("codCanal"));
			String numPlanilla = StringUtils.trimToNull(request.getParameter("numPlanilla"));
			String fechaDesde = StringUtils.trimToNull(request.getParameter("fechaDesde"));
			String fechaHasta = StringUtils.trimToNull(request.getParameter("fechaHasta"));

			// INDICADORES QUE LA PETICIÓN AJAX CULMINÓ SIN ERRORES
			respuesta.put("error", ViaticoConstantes.NO);
			respuesta.put("msgError", StringUtils.EMPTY);

			// validacion, que si ingresa número de planilla, valide que esta exista
			respuesta.put("hayValidacion", ViaticoConstantes.NO);
			respuesta.put("msgValidacion", StringUtils.EMPTY);

			if (StringUtils.isNotBlank(numPlanilla)) {

				boolean existePlanilla = viaticoConsultaService.existePlanilla(numPlanilla);
				if (!existePlanilla) {

					respuesta.put("hayValidacion", ViaticoConstantes.SI);
					respuesta.put("msgValidacion", ResourceBundleUtil.getMessageReembolso(ViaticoConstantes.BANDEJA_REVISION_MENSAJE_ERROR_SOLICITUD_NO_EXISTE));

					modelAndView = new ModelAndView(getJsonView(), respuesta);

					return modelAndView;
				}

			}

			Date fechaDesdeDate = null;
			if (fechaDesde != null && FechaBean.validaFormato(fechaDesde, FechaBean.FORMATO_DEFAULT)) {
				fechaDesdeDate = ViaticoUtil.parseStringDateToDate(fechaDesde);
			}

			Date fechaHastaDate = null;
			if (fechaHasta != null && FechaBean.validaFormato(fechaHasta, FechaBean.FORMATO_DEFAULT)) {
				fechaHastaDate = ViaticoUtil.parseStringDateToDate(fechaHasta);
			}

			// parametros de búsqueda
			Map<String, Object> parmSearch = new HashMap<String, Object>();

			parmSearch.put("codColaborador", codColaborador);
			parmSearch.put("codDependencia", codDependencia);
			parmSearch.put("codEstado", codEstado);
			parmSearch.put("codCanal", codCanal);
			parmSearch.put("numPlanilla", numPlanilla);
			parmSearch.put("fechaDesde", fechaDesdeDate);
			parmSearch.put("fechaHasta", fechaHastaDate);
			parmSearch.put("nom_tabla", ViaticoConstantes.ESTADO_VIATICO_NOMBRE_TABLA);


			setAuditoriaBeanHolder(request, response);

			List<PlanViajeBean> listSolicitudes = (List<PlanViajeBean>) consultaReembolsoService.obtenerReembolsosBandejaConsultaRevision(parmSearch);

			respuesta.put("listSolicitudes", listSolicitudes);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {

			log.error("Error buscarReembolsosBandejaRevision", e);

			// INDICADORES QUE LA PETICION AJAX CULMINO CON ERRORES.
			// NOTA: El key msgError se usa como mensaje generico de error no manejable. 
			//       Otros keys del mapa respuesta se usan para personalizar los mensajes de negocio visibles al usuario.
			respuesta.put("error", ViaticoConstantes.SI);
			respuesta.put("msgError", ViaticoConstantes.MSG_ERROR_OPERACION_NO_EFECTUADA);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} finally {

			log.debug(getClass().getName() + " Fin del metodo buscarReembolsosBandejaRevision");
		}

		return modelAndView;
	}
	
	
	/**
	 * Exporta la bandeja a un archivo en formato excel.
	 * 
	 * @author Samuel Dionisio
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 * @see ModelAndView
	 */
	public ModelAndView exportadoExcel(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;

		try {

			log.debug(getClass().getName() + " Inicio del metodo exportadoExcel");

			String codigoDependencia = request.getParameter("codDependencia");
			String codPlanilla = request.getParameter("numPlanilla");
			String codTrabajador = request.getParameter("codColaborador");
			String codEstadoSolic = request.getParameter("codEstado");
			String fechaDesdeString = request.getParameter("fechaDesde");
			String fechaHastaString = request.getParameter("fechaHasta");
			//String codigoAutorizador = request.getParameter("codigoAutorizador");
			Date fechaDesde = null;
			Date fechaHasta = null;
			
			codigoDependencia = FormatoUtil.validarEmptyToNull(codigoDependencia);
			codPlanilla = FormatoUtil.validarEmptyToNull(codPlanilla);
			codTrabajador = FormatoUtil.validarEmptyToNull(codTrabajador);
			//codigoAutorizador = FormatoUtil.validarEmptyToNull(codigoAutorizador);
			if (ReembolsoConstantes.CADENA_VACIA.equals(codEstadoSolic) || ReembolsoConstantes.CODIGO_00.equals(codEstadoSolic)) {
				codEstadoSolic = null;
			}
			
			if (!ReembolsoConstantes.CADENA_VACIA.equals(fechaDesdeString)) {
				fechaDesde = FechaUtil.parseStringDateToDate(fechaDesdeString, ReembolsoConstantes.DATE_FORMAT_DDMMYYYY);
			}
			
			if (!ReembolsoConstantes.CADENA_VACIA.equals(fechaHastaString)) {
				fechaHasta = FechaUtil.parseStringDateToDate(fechaHastaString, ReembolsoConstantes.DATE_FORMAT_DDMMYYYY);
			}
			
			ArrayList<PlanViajeBean> planViajeList = revisionReembolsoService.obtenerPlanViajeCompletoToBandejaAutorizacionReembolso(codigoDependencia, codPlanilla, codTrabajador, codEstadoSolic, fechaDesde, fechaHasta, null);
			String nombreArchivo = ReembolsoConstantes.ARCHIVO_EXCEL_PREFIJO + FechaUtil.formatDateToDateYYYYMMDDHHMMSS(new Date()) + ReembolsoConstantes.ARCHIVO_EXCEL_EXTENSION;
			response.setContentType("application/xls");
			response.setHeader("Content-Disposition", "attachment; filename=" + nombreArchivo);
			viaticoReporteService.generarExcelBandejaAutorizacionReembolso(response.getOutputStream(), planViajeList);
			
		} catch (Exception e) {

			log.error("Error exportadoExcel", e);

		} finally {

		}

		return modelAndView;
	}
	
	/**
	 * Metodo que permite mostrar la pagina de consultar gasto reembolso.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView.
	 * @see ModelAndView
	 */
	public ModelAndView mostrarConsultarGastoReembolso(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView modelAndView = null;
		String errorMessage = ReembolsoConstantes.CADENA_VACIA;
		
		try {
			log.debug(ConsultaReembolsoController.class.getSimpleName() + ".mostrarConsultarGastoReembolso");
			String codPlanViaje = request.getParameter("codPlanViaje");
			String dataJSON = request.getParameter("dataJSON");
			String paginaConsultaCaller = request.getParameter("paginaConsultaCaller");
			codPlanViaje = FormatoUtil.validarEmptyToNull(codPlanViaje);
			dataJSON = FormatoUtil.validarEmptyToNull(dataJSON);
			if (codPlanViaje != null) {
				UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
				String numeroRegistro = usuarioBean.getNroRegistro();
				MaestroPersonalBean maestroPersonalBean = registroPersonalService.obtenerPersonaxRegistro(numeroRegistro);
				ReembolsoVO reembolsoVO = ReembolsoUtil.obtenerReembolsoVO(usuarioBean, maestroPersonalBean);
				if (reembolsoVO != null) {
					PlanViajeBean planViajeBean = consultaReembolsoService.obtenerPlanViajeToSustentoGastoReembolso(codPlanViaje);
					reembolsoVO.setCodPlanViaje(codPlanViaje);
					reembolsoVO.setCodPlanilla(planViajeBean.getCodPlanilla());
					reembolsoVO.setNumeroRegistroColaborador(planViajeBean.getNumeroRegistroAlterno());
					reembolsoVO.setCodigoEstadoReembolso(planViajeBean.getCodEstadoSolic());
					reembolsoVO.setDescripcionEstadoReembolso(planViajeBean.getNomEstSolic());
					reembolsoVO.setIndicadorExteriorDDJJ(planViajeBean.getIndicadorExteriorDDJJ());
					reembolsoVO.setMoneda(planViajeBean.getMoneda());
					reembolsoVO.setTipoDestino(planViajeBean.getTipoDestino());
					reembolsoVO.setFlagMenorIgual4Horas(viaticoConsultaService.obtenerFlagMenorIgual4Horas(planViajeBean.getIndicadorHoras(), planViajeBean.getNumeroHoras()));
					reembolsoVO.setDataJSON(dataJSON);
					reembolsoVO.setPaginaConsultaCaller(paginaConsultaCaller);
				}
				respuesta.put("reembolsoVO", reembolsoVO);
			}
			log.debug(ConsultaReembolsoController.class.getSimpleName() + ".mostrarConsultarGastoReembolso.fin");
			
		} catch (Exception e) {
			log.error("Error mostrarConsultarGastoReembolso", e);
			errorMessage = ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO);
			respuesta.put("errorMessage", errorMessage);
		}
		modelAndView = new ModelAndView(ReembolsoConstantes.CONSULTAR_GASTO_REEMBOLSO_PAGE, respuesta);
		return modelAndView;
	}
	
}
