package pe.gob.sunat.recurso2.financiera.siga.viatico.web.view;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import pe.gob.sunat.recurso2.administracion.siga.util.Anio;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeConceptoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeInformeDistribBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeRendicionBean;

@SuppressWarnings("rawtypes")
public class ReembolsoVO implements Serializable {

	private static final long serialVersionUID = 610251184449315591L;

	// Registro Solicitud: seccion DATOS GENERALES
	private String codPlanilla;
	private String estadoViatico;
	private String codigoEstadoViatico;
	private String numeroRegistro;

	private String nombreColaborador;
	private String uuoo;
	private String codigoDependencia;
	private String descripcionDependencia;
	private String metaPresupuestal;
	private String codigoMetaPresupuestal;
	private String codigoEstadoColaborador;
	private String estadoColaborador;

	// Registro Solicitud: seccion DATOS GENERALES (hidden)
	private String codigoColaborador;
	private String numeroRegistroRegistrador;
	private String codigoRegistrador;
	private String flagRegistrador;
	private String flagRegistradorUniversal;
	private String flagDoAction; // registrar, modificar
	private String codigoTipoUsuarioViatico;
	private String codigoTipoUUOOViatico;
	private String codPlanViaje; // secuencia PLAN_VIAJE_ID
	private String codigoNivelColaborador;
	private String codigoNivelViaticoColaborador;
	private String codigoSedeColaborador;
	private String indicadorTraslape;
	private String indicadorAutorizacion;
	private String flagResetearTraslapeAutorizacion; // tiene uso solo para modifica un traslape rechazado
	private String origen;

	// Registro Solicitud: seccion DETALLE DE VIATICO
	private String tipoViatico;
	private String duracionComision;
	private String motivoComision;
	private String observacion;
	private String canalAtencion;
	private String codigoCanalAtencion;

	private String fechaMaximaRendicionNac;
	private String viaticosProgramadosNac;

	private List motivoAmpliacionList;
	private String motivoAmpliacion;

	private List planillasAsociadasList;
	private String planillaAsociada;

	// Registro Solicitud: seccion DETALLE DE VIATICO - Nacional > 4h -> NacMay4h
	private String fechaSalidaNacMay4h;
	private String fechaRetornoNacMay4h;
	private String diasNacMay4h;
	private String diasNacMay4hHabiles; // (hidden)

	// Registro Solicitud: seccion DETALLE DE VIATICO - Nacional <= 4h -> NacMen4h
	private String fechaNacMen4h;
	private String salidaNacMen4h;
	private String retornoNacMen4h;
	private String horasNacMen4h;

	// Registro Solicitud: seccion DETALLE DE VIATICO - Internacional -> Inter
	private String fechaItinerarioInicioInter;
	private String fechaItinerarioFinInter;
	private String fechaEventoInicioInter;
	private String fechaEventoFinInter;
	private String diasInter;
	private String diasInterHabiles; // (hidden)
	private String fechaMaximaRendicionInter;
	private String fechaResolucionInter;
	private String nroResolucionInter;
	private String montoResolucionInter;

	// Registro Solicitud: seccion INFORMACION DE DESPLAZAMIENTO - PUNTO DE PARTIDA
	private String departamento;
	private String provincia;
	private String codigoPuntoPartida; // (hidden)
	private String usarLimaComoDefault;
	private List departamentoList;
	private List provinciaList;

	// Registro Solicitud: seccion INFORMACION DE DESPLAZAMIENTO - LUGAR(ES) DESTINO
	private List desplazamientosList;
	private String totalDesplazamientos;

	// Registro Solicitud: consulta asistencia
	private String consultaAsistenciaVisualizo;
	private String consultaAsistenciaFecha;
	private String consultaAsistenciaHora;

	// Registro Solicitud: popup LUGAR DE DESPLAZAMIENTO (lugares)
	private List lugaresList;

	// Registro Solicitud: seccion LUGAR DE DESPLAZAMIENTO (tarifas)
	private List tarifasList;

	// Registro Solicitud: seccion LUGAR DE DESPLAZAMIENTO (medio de transporte)
	private List mediosTransporteList;

	// Registro Solicitud: otros
	private String fechaToday;
	private String fechaRegistro;
	private String fechaRegistroMas1;
	private List archivosAdjuntosList;
	private String tipoConfiguracion;
	private String tieneArchivoAdjunto;	

	// Registro Solicitud: datos adicionales de control
	private boolean customMessage;
	private String errorMessage;

	// Consultas - Bandejas
	private String codigoEstadoReembolso;
	private String descripcionEstadoReembolso;
	private String tipoDestino;
	private String moneda;
	private String montoComprobanteTotal;
	private String montoDevueltoComprobanteTotal;
	private String montoAsignadoTotal;
	private String montoComprobanteTotalFormateado;
	private String indicadorExteriorDDJJ;
	private String numeroRegistroColaborador;
	private String descripcionEstadoColaborador;
	private String codigoSedeRegistrador;
	private String nombreRegistrador;
	private String numeroRegistroAutorizador;
	private String codigoAutorizador;
	private String codigoDependenciaAutorizador;
	private String codigoSedeAutorizador;
	private String codigoNivelAutorizador;
	private String nombreAutorizador;
	private String flagAutorizador;
	private String flagMayor1UUOOAsociada;
	private String flagBuscarColaborador;
	private String flagBuscarUUOO;
	private String flagMenorIgual4Horas;
	private String anioActual;
	private String dataJSON;
	private String paginaConsultaCaller;
	
	private ArrayList<PlanViajeRendicionBean> planViajeRendicionList;
	private ArrayList<PlanViajeInformeDistribBean> gastoViaticoList;
	private ArrayList<PlanViajeInformeDistribBean> pasajeTasaEmbarqueList;
	private ArrayList<PlanViajeConceptoBean> planViajeConceptoList;
	private List<Anio> anioList;

	public String getCodPlanilla() {
		return codPlanilla;
	}

	public void setCodPlanilla(String codPlanilla) {
		this.codPlanilla = codPlanilla;
	}

	public String getEstadoViatico() {
		return estadoViatico;
	}

	public void setEstadoViatico(String estadoViatico) {
		this.estadoViatico = estadoViatico;
	}

	public String getCodigoEstadoViatico() {
		return codigoEstadoViatico;
	}

	public void setCodigoEstadoViatico(String codigoEstadoViatico) {
		this.codigoEstadoViatico = codigoEstadoViatico;
	}

	public String getNumeroRegistro() {
		return numeroRegistro;
	}

	public void setNumeroRegistro(String numeroRegistro) {
		this.numeroRegistro = numeroRegistro;
	}

	public String getNombreColaborador() {
		return nombreColaborador;
	}

	public void setNombreColaborador(String nombreColaborador) {
		this.nombreColaborador = nombreColaborador;
	}

	public String getUuoo() {
		return uuoo;
	}

	public void setUuoo(String uuoo) {
		this.uuoo = uuoo;
	}

	public String getCodigoDependencia() {
		return codigoDependencia;
	}

	public void setCodigoDependencia(String codigoDependencia) {
		this.codigoDependencia = codigoDependencia;
	}

	public String getDescripcionDependencia() {
		return descripcionDependencia;
	}

	public void setDescripcionDependencia(String descripcionDependencia) {
		this.descripcionDependencia = descripcionDependencia;
	}

	public String getMetaPresupuestal() {
		return metaPresupuestal;
	}

	public void setMetaPresupuestal(String metaPresupuestal) {
		this.metaPresupuestal = metaPresupuestal;
	}

	public String getCodigoMetaPresupuestal() {
		return codigoMetaPresupuestal;
	}

	public void setCodigoMetaPresupuestal(String codigoMetaPresupuestal) {
		this.codigoMetaPresupuestal = codigoMetaPresupuestal;
	}

	public String getCodigoEstadoColaborador() {
		return codigoEstadoColaborador;
	}

	public void setCodigoEstadoColaborador(String codigoEstadoColaborador) {
		this.codigoEstadoColaborador = codigoEstadoColaborador;
	}

	public String getEstadoColaborador() {
		return estadoColaborador;
	}

	public void setEstadoColaborador(String estadoColaborador) {
		this.estadoColaborador = estadoColaborador;
	}

	public String getCodigoColaborador() {
		return codigoColaborador;
	}

	public void setCodigoColaborador(String codigoColaborador) {
		this.codigoColaborador = codigoColaborador;
	}

	public String getNumeroRegistroRegistrador() {
		return numeroRegistroRegistrador;
	}

	public void setNumeroRegistroRegistrador(String numeroRegistroRegistrador) {
		this.numeroRegistroRegistrador = numeroRegistroRegistrador;
	}

	public String getCodigoRegistrador() {
		return codigoRegistrador;
	}

	public void setCodigoRegistrador(String codigoRegistrador) {
		this.codigoRegistrador = codigoRegistrador;
	}

	public String getFlagRegistrador() {
		return flagRegistrador;
	}

	public void setFlagRegistrador(String flagRegistrador) {
		this.flagRegistrador = flagRegistrador;
	}

	public String getFlagDoAction() {
		return flagDoAction;
	}

	public void setFlagDoAction(String flagDoAction) {
		this.flagDoAction = flagDoAction;
	}

	public String getTipoViatico() {
		return tipoViatico;
	}

	public void setTipoViatico(String tipoViatico) {
		this.tipoViatico = tipoViatico;
	}

	public String getDuracionComision() {
		return duracionComision;
	}

	public void setDuracionComision(String duracionComision) {
		this.duracionComision = duracionComision;
	}

	public String getMotivoComision() {
		return motivoComision;
	}

	public void setMotivoComision(String motivoComision) {
		this.motivoComision = motivoComision;
	}

	public String getObservacion() {
		return observacion;
	}

	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	public String getCanalAtencion() {
		return canalAtencion;
	}

	public void setCanalAtencion(String canalAtencion) {
		this.canalAtencion = canalAtencion;
	}

	public String getFechaMaximaRendicionNac() {
		return fechaMaximaRendicionNac;
	}

	public void setFechaMaximaRendicionNac(String fechaMaximaRendicionNac) {
		this.fechaMaximaRendicionNac = fechaMaximaRendicionNac;
	}

	public String getViaticosProgramadosNac() {
		return viaticosProgramadosNac;
	}

	public void setViaticosProgramadosNac(String viaticosProgramadosNac) {
		this.viaticosProgramadosNac = viaticosProgramadosNac;
	}

	public String getFechaRetornoNacMay4h() {
		return fechaRetornoNacMay4h;
	}

	public void setFechaRetornoNacMay4h(String fechaRetornoNacMay4h) {
		this.fechaRetornoNacMay4h = fechaRetornoNacMay4h;
	}

	public String getDiasNacMay4h() {
		return diasNacMay4h;
	}

	public void setDiasNacMay4h(String diasNacMay4h) {
		this.diasNacMay4h = diasNacMay4h;
	}

	public String getFechaNacMen4h() {
		return fechaNacMen4h;
	}

	public void setFechaNacMen4h(String fechaNacMen4h) {
		this.fechaNacMen4h = fechaNacMen4h;
	}

	public String getSalidaNacMen4h() {
		return salidaNacMen4h;
	}

	public void setSalidaNacMen4h(String salidaNacMen4h) {
		this.salidaNacMen4h = salidaNacMen4h;
	}

	public String getRetornoNacMen4h() {
		return retornoNacMen4h;
	}

	public void setRetornoNacMen4h(String retornoNacMen4h) {
		this.retornoNacMen4h = retornoNacMen4h;
	}

	public String getHorasNacMen4h() {
		return horasNacMen4h;
	}

	public void setHorasNacMen4h(String horasNacMen4h) {
		this.horasNacMen4h = horasNacMen4h;
	}

	public String getFechaItinerarioInicioInter() {
		return fechaItinerarioInicioInter;
	}

	public void setFechaItinerarioInicioInter(String fechaItinerarioInicioInter) {
		this.fechaItinerarioInicioInter = fechaItinerarioInicioInter;
	}

	public String getFechaItinerarioFinInter() {
		return fechaItinerarioFinInter;
	}

	public void setFechaItinerarioFinInter(String fechaItinerarioFinInter) {
		this.fechaItinerarioFinInter = fechaItinerarioFinInter;
	}

	public String getFechaEventoInicioInter() {
		return fechaEventoInicioInter;
	}

	public void setFechaEventoInicioInter(String fechaEventoInicioInter) {
		this.fechaEventoInicioInter = fechaEventoInicioInter;
	}

	public String getFechaEventoFinInter() {
		return fechaEventoFinInter;
	}

	public void setFechaEventoFinInter(String fechaEventoFinInter) {
		this.fechaEventoFinInter = fechaEventoFinInter;
	}

	public String getDiasInter() {
		return diasInter;
	}

	public void setDiasInter(String diasInter) {
		this.diasInter = diasInter;
	}

	public String getFechaMaximaRendicionInter() {
		return fechaMaximaRendicionInter;
	}

	public void setFechaMaximaRendicionInter(String fechaMaximaRendicionInter) {
		this.fechaMaximaRendicionInter = fechaMaximaRendicionInter;
	}

	public String getFechaResolucionInter() {
		return fechaResolucionInter;
	}

	public void setFechaResolucionInter(String fechaResolucionInter) {
		this.fechaResolucionInter = fechaResolucionInter;
	}

	public String getNroResolucionInter() {
		return nroResolucionInter;
	}

	public void setNroResolucionInter(String nroResolucionInter) {
		this.nroResolucionInter = nroResolucionInter;
	}

	public String getMontoResolucionInter() {
		return montoResolucionInter;
	}

	public void setMontoResolucionInter(String montoResolucionInter) {
		this.montoResolucionInter = montoResolucionInter;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	public String getProvincia() {
		return provincia;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

	public String getCodigoPuntoPartida() {
		return codigoPuntoPartida;
	}

	public void setCodigoPuntoPartida(String codigoPuntoPartida) {
		this.codigoPuntoPartida = codigoPuntoPartida;
	}

	public List getDepartamentoList() {
		return departamentoList;
	}

	public void setDepartamentoList(List departamentoList) {
		this.departamentoList = departamentoList;
	}

	public List getProvinciaList() {
		return provinciaList;
	}

	public void setProvinciaList(List provinciaList) {
		this.provinciaList = provinciaList;
	}

	public List getDesplazamientosList() {
		return desplazamientosList;
	}

	public void setDesplazamientosList(List desplazamientosList) {
		this.desplazamientosList = desplazamientosList;
	}

	public List getLugaresList() {
		return lugaresList;
	}

	public void setLugaresList(List lugaresList) {
		this.lugaresList = lugaresList;
	}

	public List getTarifasList() {
		return tarifasList;
	}

	public void setTarifasList(List tarifasList) {
		this.tarifasList = tarifasList;
	}

	public List getMediosTransporteList() {
		return mediosTransporteList;
	}

	public void setMediosTransporteList(List mediosTransporteList) {
		this.mediosTransporteList = mediosTransporteList;
	}

	public String getFechaSalidaNacMay4h() {
		return fechaSalidaNacMay4h;
	}

	public void setFechaSalidaNacMay4h(String fechaSalidaNacMay4h) {
		this.fechaSalidaNacMay4h = fechaSalidaNacMay4h;
	}

	public String getTotalDesplazamientos() {
		return totalDesplazamientos;
	}

	public void setTotalDesplazamientos(String totalDesplazamientos) {
		this.totalDesplazamientos = totalDesplazamientos;
	}

	public String getConsultaAsistenciaFecha() {
		return consultaAsistenciaFecha;
	}

	public void setConsultaAsistenciaFecha(String consultaAsistenciaFecha) {
		this.consultaAsistenciaFecha = consultaAsistenciaFecha;
	}

	public String getConsultaAsistenciaHora() {
		return consultaAsistenciaHora;
	}

	public void setConsultaAsistenciaHora(String consultaAsistenciaHora) {
		this.consultaAsistenciaHora = consultaAsistenciaHora;
	}

	public String getCodPlanViaje() {
		return codPlanViaje;
	}

	public void setCodPlanViaje(String codPlanViaje) {
		this.codPlanViaje = codPlanViaje;
	}

	public String getCodigoCanalAtencion() {
		return codigoCanalAtencion;
	}

	public void setCodigoCanalAtencion(String codigoCanalAtencion) {
		this.codigoCanalAtencion = codigoCanalAtencion;
	}

	public String getDiasInterHabiles() {
		return diasInterHabiles;
	}

	public void setDiasInterHabiles(String diasInterHabiles) {
		this.diasInterHabiles = diasInterHabiles;
	}

	public String getDiasNacMay4hHabiles() {
		return diasNacMay4hHabiles;
	}

	public void setDiasNacMay4hHabiles(String diasNacMay4hHabiles) {
		this.diasNacMay4hHabiles = diasNacMay4hHabiles;
	}

	public String getCodigoNivelColaborador() {
		return codigoNivelColaborador;
	}

	public void setCodigoNivelColaborador(String codigoNivelColaborador) {
		this.codigoNivelColaborador = codigoNivelColaborador;
	}

	public String getCodigoNivelViaticoColaborador() {
		return codigoNivelViaticoColaborador;
	}

	public void setCodigoNivelViaticoColaborador(String codigoNivelViaticoColaborador) {
		this.codigoNivelViaticoColaborador = codigoNivelViaticoColaborador;
	}

	public boolean getCustomMessage() {
		return customMessage;
	}

	public void setCustomMessage(boolean customMessage) {
		this.customMessage = customMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getFechaToday() {
		return fechaToday;
	}

	public void setFechaToday(String fechaToday) {
		this.fechaToday = fechaToday;
	}

	public String getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(String fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public String getFechaRegistroMas1() {
		return fechaRegistroMas1;
	}

	public void setFechaRegistroMas1(String fechaRegistroMas1) {
		this.fechaRegistroMas1 = fechaRegistroMas1;
	}

	public String getConsultaAsistenciaVisualizo() {
		return consultaAsistenciaVisualizo;
	}

	public void setConsultaAsistenciaVisualizo(String consultaAsistenciaVisualizo) {
		this.consultaAsistenciaVisualizo = consultaAsistenciaVisualizo;
	}

	public String getCodigoSedeColaborador() {
		return codigoSedeColaborador;
	}

	public void setCodigoSedeColaborador(String codigoSedeColaborador) {
		this.codigoSedeColaborador = codigoSedeColaborador;
	}

	public String getIndicadorTraslape() {
		return indicadorTraslape;
	}

	public void setIndicadorTraslape(String indicadorTraslape) {
		this.indicadorTraslape = indicadorTraslape;
	}

	public String getIndicadorAutorizacion() {
		return indicadorAutorizacion;
	}

	public void setIndicadorAutorizacion(String indicadorAutorizacion) {
		this.indicadorAutorizacion = indicadorAutorizacion;
	}

	public String getFlagResetearTraslapeAutorizacion() {
		return flagResetearTraslapeAutorizacion;
	}

	public void setFlagResetearTraslapeAutorizacion(String flagResetearTraslapeAutorizacion) {
		this.flagResetearTraslapeAutorizacion = flagResetearTraslapeAutorizacion;
	}

	public List getArchivosAdjuntosList() {
		return archivosAdjuntosList;
	}

	public void setArchivosAdjuntosList(List archivosAdjuntosList) {
		this.archivosAdjuntosList = archivosAdjuntosList;
	}

	public String getTipoConfiguracion() {
		return tipoConfiguracion;
	}

	public void setTipoConfiguracion(String tipoConfiguracion) {
		this.tipoConfiguracion = tipoConfiguracion;
	}

	public List getMotivoAmpliacionList() {
		return motivoAmpliacionList;
	}

	public void setMotivoAmpliacionList(List motivoAmpliacionList) {
		this.motivoAmpliacionList = motivoAmpliacionList;
	}

	public String getMotivoAmpliacion() {
		return motivoAmpliacion;
	}

	public void setMotivoAmpliacion(String motivoAmpliacion) {
		this.motivoAmpliacion = motivoAmpliacion;
	}

	public List getPlanillasAsociadasList() {
		return planillasAsociadasList;
	}

	public void setPlanillasAsociadasList(List planillasAsociadasList) {
		this.planillasAsociadasList = planillasAsociadasList;
	}

	public String getFlagRegistradorUniversal() {
		return flagRegistradorUniversal;
	}

	public void setFlagRegistradorUniversal(String flagRegistradorUniversal) {
		this.flagRegistradorUniversal = flagRegistradorUniversal;
	}

	public String getCodigoTipoUsuarioViatico() {
		return codigoTipoUsuarioViatico;
	}

	public void setCodigoTipoUsuarioViatico(String codigoTipoUsuarioViatico) {
		this.codigoTipoUsuarioViatico = codigoTipoUsuarioViatico;
	}

	public String getCodigoTipoUUOOViatico() {
		return codigoTipoUUOOViatico;
	}

	public void setCodigoTipoUUOOViatico(String codigoTipoUUOOViatico) {
		this.codigoTipoUUOOViatico = codigoTipoUUOOViatico;
	}

	public String getPlanillaAsociada() {
		return planillaAsociada;
	}

	public void setPlanillaAsociada(String planillaAsociada) {
		this.planillaAsociada = planillaAsociada;
	}

	public String getOrigen() {
		return origen;
	}

	public void setOrigen(String origen) {
		this.origen = origen;
	}

	public String getCodigoEstadoReembolso() {
		return codigoEstadoReembolso;
	}

	public void setCodigoEstadoReembolso(String codigoEstadoReembolso) {
		this.codigoEstadoReembolso = codigoEstadoReembolso;
	}

	public String getDescripcionEstadoReembolso() {
		return descripcionEstadoReembolso;
	}

	public void setDescripcionEstadoReembolso(String descripcionEstadoReembolso) {
		this.descripcionEstadoReembolso = descripcionEstadoReembolso;
	}

	public String getTipoDestino() {
		return tipoDestino;
	}

	public void setTipoDestino(String tipoDestino) {
		this.tipoDestino = tipoDestino;
	}

	public String getMoneda() {
		return moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public String getMontoComprobanteTotal() {
		return montoComprobanteTotal;
	}

	public void setMontoComprobanteTotal(String montoComprobanteTotal) {
		this.montoComprobanteTotal = montoComprobanteTotal;
	}

	public String getMontoDevueltoComprobanteTotal() {
		return montoDevueltoComprobanteTotal;
	}

	public void setMontoDevueltoComprobanteTotal(
			String montoDevueltoComprobanteTotal) {
		this.montoDevueltoComprobanteTotal = montoDevueltoComprobanteTotal;
	}

	public String getMontoAsignadoTotal() {
		return montoAsignadoTotal;
	}

	public void setMontoAsignadoTotal(String montoAsignadoTotal) {
		this.montoAsignadoTotal = montoAsignadoTotal;
	}

	public String getMontoComprobanteTotalFormateado() {
		return montoComprobanteTotalFormateado;
	}

	public void setMontoComprobanteTotalFormateado(
			String montoComprobanteTotalFormateado) {
		this.montoComprobanteTotalFormateado = montoComprobanteTotalFormateado;
	}

	public String getIndicadorExteriorDDJJ() {
		return indicadorExteriorDDJJ;
	}

	public void setIndicadorExteriorDDJJ(String indicadorExteriorDDJJ) {
		this.indicadorExteriorDDJJ = indicadorExteriorDDJJ;
	}

	public String getNumeroRegistroColaborador() {
		return numeroRegistroColaborador;
	}

	public void setNumeroRegistroColaborador(String numeroRegistroColaborador) {
		this.numeroRegistroColaborador = numeroRegistroColaborador;
	}

	public String getDescripcionEstadoColaborador() {
		return descripcionEstadoColaborador;
	}

	public void setDescripcionEstadoColaborador(
			String descripcionEstadoColaborador) {
		this.descripcionEstadoColaborador = descripcionEstadoColaborador;
	}

	public String getCodigoSedeRegistrador() {
		return codigoSedeRegistrador;
	}

	public void setCodigoSedeRegistrador(String codigoSedeRegistrador) {
		this.codigoSedeRegistrador = codigoSedeRegistrador;
	}

	public String getNombreRegistrador() {
		return nombreRegistrador;
	}

	public void setNombreRegistrador(String nombreRegistrador) {
		this.nombreRegistrador = nombreRegistrador;
	}

	public String getNumeroRegistroAutorizador() {
		return numeroRegistroAutorizador;
	}

	public void setNumeroRegistroAutorizador(String numeroRegistroAutorizador) {
		this.numeroRegistroAutorizador = numeroRegistroAutorizador;
	}

	public String getCodigoAutorizador() {
		return codigoAutorizador;
	}

	public void setCodigoAutorizador(String codigoAutorizador) {
		this.codigoAutorizador = codigoAutorizador;
	}

	public String getCodigoDependenciaAutorizador() {
		return codigoDependenciaAutorizador;
	}

	public void setCodigoDependenciaAutorizador(
			String codigoDependenciaAutorizador) {
		this.codigoDependenciaAutorizador = codigoDependenciaAutorizador;
	}

	public String getCodigoSedeAutorizador() {
		return codigoSedeAutorizador;
	}

	public void setCodigoSedeAutorizador(String codigoSedeAutorizador) {
		this.codigoSedeAutorizador = codigoSedeAutorizador;
	}

	public String getCodigoNivelAutorizador() {
		return codigoNivelAutorizador;
	}

	public void setCodigoNivelAutorizador(String codigoNivelAutorizador) {
		this.codigoNivelAutorizador = codigoNivelAutorizador;
	}

	public String getNombreAutorizador() {
		return nombreAutorizador;
	}

	public void setNombreAutorizador(String nombreAutorizador) {
		this.nombreAutorizador = nombreAutorizador;
	}

	public String getFlagAutorizador() {
		return flagAutorizador;
	}

	public void setFlagAutorizador(String flagAutorizador) {
		this.flagAutorizador = flagAutorizador;
	}

	public String getFlagMayor1UUOOAsociada() {
		return flagMayor1UUOOAsociada;
	}

	public void setFlagMayor1UUOOAsociada(String flagMayor1UUOOAsociada) {
		this.flagMayor1UUOOAsociada = flagMayor1UUOOAsociada;
	}

	public String getFlagBuscarColaborador() {
		return flagBuscarColaborador;
	}

	public void setFlagBuscarColaborador(String flagBuscarColaborador) {
		this.flagBuscarColaborador = flagBuscarColaborador;
	}

	public String getFlagBuscarUUOO() {
		return flagBuscarUUOO;
	}

	public void setFlagBuscarUUOO(String flagBuscarUUOO) {
		this.flagBuscarUUOO = flagBuscarUUOO;
	}

	public String getFlagMenorIgual4Horas() {
		return flagMenorIgual4Horas;
	}

	public void setFlagMenorIgual4Horas(String flagMenorIgual4Horas) {
		this.flagMenorIgual4Horas = flagMenorIgual4Horas;
	}

	public String getAnioActual() {
		return anioActual;
	}

	public void setAnioActual(String anioActual) {
		this.anioActual = anioActual;
	}

	public String getUsarLimaComoDefault() {
		return usarLimaComoDefault;
	}

	public void setUsarLimaComoDefault(String usarLimaComoDefault) {
		this.usarLimaComoDefault = usarLimaComoDefault;
	}

	public String getDataJSON() {
		return dataJSON;
	}

	public void setDataJSON(String dataJSON) {
		this.dataJSON = dataJSON;
	}
	
	public String getPaginaConsultaCaller() {
		return paginaConsultaCaller;
	}

	public void setPaginaConsultaCaller(String paginaConsultaCaller) {
		this.paginaConsultaCaller = paginaConsultaCaller;
	}

	public ArrayList<PlanViajeRendicionBean> getPlanViajeRendicionList() {
		return planViajeRendicionList;
	}

	public void setPlanViajeRendicionList(
			ArrayList<PlanViajeRendicionBean> planViajeRendicionList) {
		this.planViajeRendicionList = planViajeRendicionList;
	}

	public ArrayList<PlanViajeInformeDistribBean> getGastoViaticoList() {
		return gastoViaticoList;
	}

	public void setGastoViaticoList(
			ArrayList<PlanViajeInformeDistribBean> gastoViaticoList) {
		this.gastoViaticoList = gastoViaticoList;
	}

	public ArrayList<PlanViajeInformeDistribBean> getPasajeTasaEmbarqueList() {
		return pasajeTasaEmbarqueList;
	}

	public void setPasajeTasaEmbarqueList(
			ArrayList<PlanViajeInformeDistribBean> pasajeTasaEmbarqueList) {
		this.pasajeTasaEmbarqueList = pasajeTasaEmbarqueList;
	}

	public ArrayList<PlanViajeConceptoBean> getPlanViajeConceptoList() {
		return planViajeConceptoList;
	}

	public void setPlanViajeConceptoList(
			ArrayList<PlanViajeConceptoBean> planViajeConceptoList) {
		this.planViajeConceptoList = planViajeConceptoList;
	}

	public List<Anio> getAnioList() {
		return anioList;
	}

	public void setAnioList(List<Anio> anioList) {
		this.anioList = anioList;
	}

	public String getTieneArchivoAdjunto() {
		return tieneArchivoAdjunto;
	}

	public void setTieneArchivoAdjunto(String tieneArchivoAdjunto) {
		this.tieneArchivoAdjunto = tieneArchivoAdjunto;
	}
}
