package pe.gob.sunat.recurso2.financiera.siga.viatico.web.singleton;

/**
 * La clase ViaticosTarifarioSingletonImpl para determinar si el tipo de tarifario es regional (02) o nacional (01).
 */
public class ViaticosTarifarioSingletonImpl implements ViaticosTarifarioSingleton {

	/** Declaramos el tarifario. */
	private final String tarifario;

	@Override
	public String obtenerTarifario() {
		return this.tarifario;
	}

	/**
	 * Instancia ViaticosTarifarioSingletonImpl.
	 * 
	 * @param codigo : tipo String
	 */
	public ViaticosTarifarioSingletonImpl(String codigo) {

		this.tarifario = codigo;

	}

}
