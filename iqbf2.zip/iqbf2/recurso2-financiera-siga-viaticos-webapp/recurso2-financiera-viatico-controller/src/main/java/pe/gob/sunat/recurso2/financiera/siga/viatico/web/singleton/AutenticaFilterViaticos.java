package pe.gob.sunat.recurso2.financiera.siga.viatico.web.singleton;


import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import pe.gob.sunat.framework.core.bean.MensajeBean;
import pe.gob.sunat.framework.util.Propiedades;
import pe.gob.sunat.framework.web.filter.FilterAbstract;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

public class AutenticaFilterViaticos
  extends FilterAbstract
{
  private static final Log log = LogFactory.getLog(AutenticaFilterViaticos.class);
  private static Propiedades propiedades = new Propiedades(AutenticaFilterViaticos.class, "/autenticaTest.properties");
  private HttpSession session;
  
  public void preProcesa(ServletRequest request, ServletResponse response, FilterChain chain)
    throws IOException, ServletException
  {}
  
  public void procesa(ServletRequest request, ServletResponse response, FilterChain chain)
    throws IOException, ServletException
  {
    try
    {
      this.session = ((HttpServletRequest)request).getSession(true);
      if (this.session == null)
      {
        forwardError(request, response, "La session no se ha creado correctamente.");
        return;
      }
      if ((request instanceof HttpServletRequest))
      {
        String method = ((HttpServletRequest)request).getMethod();
        log.info("Autenticando (".concat(method).concat(") : ").concat(((HttpServletRequest)request).getRequestURI()));
        if (!method.equalsIgnoreCase("GET")) {
          return;
        }
        UsuarioBean usuarioBeanTem =(UsuarioBean)this.session.getAttribute("usuarioBean");
        if (usuarioBeanTem ==null){
        	UsuarioBean usuarioBean = new UsuarioBean();
            usuarioBean.setLogin(propiedades.leePropiedad("usuario.login"));
            usuarioBean.setCorreo(propiedades.leePropiedad("usuario.correo"));
            usuarioBean.setNombres(propiedades.leePropiedad("usuario.nombres"));
            usuarioBean.setApePaterno(propiedades.leePropiedad("usuario.apePaterno"));
            usuarioBean.setApeMaterno(propiedades.leePropiedad("usuario.apeMaterno"));
            usuarioBean.setNombreCompleto(propiedades.leePropiedad("usuario.nombreCompleto"));
            usuarioBean.setNroRegistro(propiedades.leePropiedad("usuario.nroRegistro"));
            usuarioBean.setCodUO(propiedades.leePropiedad("usuario.codUO"));
            usuarioBean.setCodCate(propiedades.leePropiedad("usuario.codCate"));
            usuarioBean.setNivelUO(new Short(propiedades.leePropiedad("usuario.nivelUO")).shortValue());
            usuarioBean.setNumRUC(propiedades.leePropiedad("usuario.numRUC"));
            usuarioBean.setUsuarioSOL(propiedades.leePropiedad("usuario.usuarioSOL"));
            usuarioBean.setCodDepend(propiedades.leePropiedad("usuario.codDepend"));
            usuarioBean.setIdCelular(propiedades.leePropiedad("usuario.idCelular"));
            usuarioBean.setCodTOpeComer(propiedades.leePropiedad("usuario.codTOpeComer"));
            setAttribute(this.session, "usuarioBean", usuarioBean);
        }else{
        	setAttribute(this.session, "usuarioBean", usuarioBeanTem);
        }
        
        
        
      }
    }
    catch (Exception e)
    {
      log.error("*** Error *** " + e.toString(), e);
      forwardError(request, response, "Ha ocurrido un error al generar los datos del usuario.");
      return;
    }
  }
  
  public void postProcesa(ServletRequest request, ServletResponse response, FilterChain chain)
    throws IOException, ServletException
  {
    try
    {
      UsuarioBean usuarioBean = (UsuarioBean)this.session.getAttribute("usuarioBean");
      if (usuarioBean == null)
      {
        forwardError(request, response, "Error al validar la informaci&oacute;n del usuario.");
        return;
      }
      chain.doFilter(request, response);
    }
    catch (Exception e)
    {
      log.error("*** Error *** " + e.toString(), e);
      forwardError(request, response, "Invocaci&oacute;n incorrecta. Por favor acceda desde el Menu SUNAT.");
      return;
    }
  }
  
  public void forwardError(ServletRequest request, ServletResponse response, Object error)
  {
    if ((error instanceof MensajeBean)) {
      setAttribute(request, "beanErr", error);
    }
    if ((error instanceof String))
    {
      MensajeBean bean = new MensajeBean();
      bean.setError(true);
      bean.setMensajeerror((String)error);
      setAttribute(request, "beanErr", bean);
    }
    forward((HttpServletRequest)request, (HttpServletResponse)response, "/PagMenuE.jsp");
  }
  
  public void setAttribute(Object scope, String key, Object obj)
  {
    if ((scope instanceof HttpServletRequest))
    {
      ((HttpServletRequest)scope).removeAttribute(key);
      ((HttpServletRequest)scope).setAttribute(key, obj);
    }
    if ((scope instanceof HttpSession))
    {
      ((HttpSession)scope).removeAttribute(key);
      ((HttpSession)scope).setAttribute(key, obj);
    }
    if ((scope instanceof ServletContext))
    {
      ((ServletContext)scope).removeAttribute(key);
      ((ServletContext)scope).setAttribute(key, obj);
    }
  }
  
  public void forward(HttpServletRequest request, HttpServletResponse response, String pagina)
  {
    try
    {
      RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(pagina);
      dispatcher.forward(request, response);
    }
    catch (ServletException e)
    {
      log.error("*** Error *** " + e.toString(), e);
    }
    catch (IOException e)
    {
      log.error("*** Error *** " + e.toString(), e);
    }
    catch (IllegalStateException localIllegalStateException) {}
  }
}

