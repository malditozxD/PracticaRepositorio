package pe.gob.sunat.recurso2.financiera.siga.viatico.web.view;

import java.io.Serializable;
import java.util.ArrayList;

import pe.gob.sunat.recurso2.administracion.siga.ubigeo.model.bean.TDepartamentosBean;
import pe.gob.sunat.recurso2.administracion.siga.ubigeo.model.bean.TDistritosBean;
import pe.gob.sunat.recurso2.administracion.siga.ubigeo.model.bean.TProvinciasBean;

public class MaestroPersonalViaticoBeanView implements Serializable {

	private static final long serialVersionUID = -1884564365562390234L;
	private String numeroRegistro;
	private String codigoEmpleado;
	private String numeroRegistroRegistrador;
	private String codigoRegistrador;
	private String nombreCompleto;
	private String codigoEstado;
	private String descripcionEstado;
	private String codigoEstadoComision;
	private String descripcionEstadoComision;
	private String numeroComision;
	private String uuoo;
	private String codigoDependencia;
	private String descripcionDependencia;
	private String secuFuncSfu;
	private String metaPresupuestal;
	private String fechaComision;
	private String horaMinima1raSalida;
	private String horaSalidaNuevaRuta;
	private String codigoTipoDesplazamiento;
	private String codigoOrigenTarifa;
	private String codigoDepartamento;
	private String codigoProvincia;
	private String codigoDistrito;
	private String codigoLugar;
	private String observacionComision;
	private String montoReembolso;
	private Long flagRegistrador;
	private String flagNotificador;
	private String flagAuditor;
	private String flagDoAction; // 1: Registrar; 0: Modificar

	private ArrayList<TDepartamentosBean> departamentoList;
	private ArrayList<TProvinciasBean> provinciaList;
	private ArrayList<TDistritosBean> distritoList;

	public String getNumeroRegistro() {
		return numeroRegistro;
	}

	public void setNumeroRegistro(String numeroRegistro) {
		this.numeroRegistro = numeroRegistro;
	}

	public String getCodigoEmpleado() {
		return codigoEmpleado;
	}

	public void setCodigoEmpleado(String codigoEmpleado) {
		this.codigoEmpleado = codigoEmpleado;
	}

	public String getNumeroRegistroRegistrador() {
		return numeroRegistroRegistrador;
	}

	public void setNumeroRegistroRegistrador(String numeroRegistroRegistrador) {
		this.numeroRegistroRegistrador = numeroRegistroRegistrador;
	}

	public String getCodigoRegistrador() {
		return codigoRegistrador;
	}

	public void setCodigoRegistrador(String codigoRegistrador) {
		this.codigoRegistrador = codigoRegistrador;
	}

	public String getNombreCompleto() {
		return nombreCompleto;
	}

	public void setNombreCompleto(String nombreCompleto) {
		this.nombreCompleto = nombreCompleto;
	}

	public String getCodigoEstado() {
		return codigoEstado;
	}

	public void setCodigoEstado(String codigoEstado) {
		this.codigoEstado = codigoEstado;
	}

	public String getDescripcionEstado() {
		return descripcionEstado;
	}

	public void setDescripcionEstado(String descripcionEstado) {
		this.descripcionEstado = descripcionEstado;
	}

	public String getCodigoEstadoComision() {
		return codigoEstadoComision;
	}

	public void setCodigoEstadoComision(String codigoEstadoComision) {
		this.codigoEstadoComision = codigoEstadoComision;
	}

	public String getDescripcionEstadoComision() {
		return descripcionEstadoComision;
	}

	public void setDescripcionEstadoComision(String descripcionEstadoComision) {
		this.descripcionEstadoComision = descripcionEstadoComision;
	}

	public String getNumeroComision() {
		return numeroComision;
	}

	public void setNumeroComision(String numeroComision) {
		this.numeroComision = numeroComision;
	}

	public String getUuoo() {
		return uuoo;
	}

	public void setUuoo(String uuoo) {
		this.uuoo = uuoo;
	}

	public String getCodigoDependencia() {
		return codigoDependencia;
	}

	public void setCodigoDependencia(String codigoDependencia) {
		this.codigoDependencia = codigoDependencia;
	}

	public String getDescripcionDependencia() {
		return descripcionDependencia;
	}

	public void setDescripcionDependencia(String descripcionDependencia) {
		this.descripcionDependencia = descripcionDependencia;
	}

	public String getSecuFuncSfu() {
		return secuFuncSfu;
	}

	public void setSecuFuncSfu(String secuFuncSfu) {
		this.secuFuncSfu = secuFuncSfu;
	}

	public String getMetaPresupuestal() {
		return metaPresupuestal;
	}

	public void setMetaPresupuestal(String metaPresupuestal) {
		this.metaPresupuestal = metaPresupuestal;
	}

	public String getFechaComision() {
		return fechaComision;
	}

	public void setFechaComision(String fechaComision) {
		this.fechaComision = fechaComision;
	}

	public String getHoraMinima1raSalida() {
		return horaMinima1raSalida;
	}

	public void setHoraMinima1raSalida(String horaMinima1raSalida) {
		this.horaMinima1raSalida = horaMinima1raSalida;
	}

	public String getHoraSalidaNuevaRuta() {
		return horaSalidaNuevaRuta;
	}

	public void setHoraSalidaNuevaRuta(String horaSalidaNuevaRuta) {
		this.horaSalidaNuevaRuta = horaSalidaNuevaRuta;
	}

	public String getCodigoTipoDesplazamiento() {
		return codigoTipoDesplazamiento;
	}

	public void setCodigoTipoDesplazamiento(String codigoTipoDesplazamiento) {
		this.codigoTipoDesplazamiento = codigoTipoDesplazamiento;
	}

	public String getCodigoOrigenTarifa() {
		return codigoOrigenTarifa;
	}

	public void setCodigoOrigenTarifa(String codigoOrigenTarifa) {
		this.codigoOrigenTarifa = codigoOrigenTarifa;
	}

	public String getCodigoDepartamento() {
		return codigoDepartamento;
	}

	public void setCodigoDepartamento(String codigoDepartamento) {
		this.codigoDepartamento = codigoDepartamento;
	}

	public String getCodigoProvincia() {
		return codigoProvincia;
	}

	public void setCodigoProvincia(String codigoProvincia) {
		this.codigoProvincia = codigoProvincia;
	}

	public String getCodigoDistrito() {
		return codigoDistrito;
	}

	public void setCodigoDistrito(String codigoDistrito) {
		this.codigoDistrito = codigoDistrito;
	}

	public String getCodigoLugar() {
		return codigoLugar;
	}

	public void setCodigoLugar(String codigoLugar) {
		this.codigoLugar = codigoLugar;
	}

	public String getObservacionComision() {
		return observacionComision;
	}

	public void setObservacionComision(String observacionComision) {
		this.observacionComision = observacionComision;
	}

	public String getMontoReembolso() {
		return montoReembolso;
	}

	public void setMontoReembolso(String montoReembolso) {
		this.montoReembolso = montoReembolso;
	}

	public Long getFlagRegistrador() {
		return flagRegistrador;
	}

	public void setFlagRegistrador(Long flagRegistrador) {
		this.flagRegistrador = flagRegistrador;
	}

	public String getFlagNotificador() {
		return flagNotificador;
	}

	public void setFlagNotificador(String flagNotificador) {
		this.flagNotificador = flagNotificador;
	}

	public String getFlagAuditor() {
		return flagAuditor;
	}

	public void setFlagAuditor(String flagAuditor) {
		this.flagAuditor = flagAuditor;
	}

	public String getFlagDoAction() {
		return flagDoAction;
	}

	public void setFlagDoAction(String flagDoAction) {
		this.flagDoAction = flagDoAction;
	}

	public ArrayList<TDepartamentosBean> getDepartamentoList() {
		return departamentoList;
	}

	public void setDepartamentoList(ArrayList<TDepartamentosBean> departamentoList) {
		this.departamentoList = departamentoList;
	}

	public ArrayList<TProvinciasBean> getProvinciaList() {
		return provinciaList;
	}

	public void setProvinciaList(ArrayList<TProvinciasBean> provinciaList) {
		this.provinciaList = provinciaList;
	}

	public ArrayList<TDistritosBean> getDistritoList() {
		return distritoList;
	}

	public void setDistritoList(ArrayList<TDistritosBean> distritoList) {
		this.distritoList = distritoList;
	}

}
