package pe.gob.sunat.recurso2.financiera.siga.viatico.web.singleton;



/**
 * La clase MovilidadProcesoSingletonImpl para ver el proceso manual, semi automatico o automatico
 */
public class ViaticosProcesoSingletonImpl implements ViaticosProcesoSingleton {

	/** Declaramos el servicio modoProcesoViaticos. */
	private final String modoProcesoViaticos;


	

	@Override
	public String obtenerProceso() {
		return this.modoProcesoViaticos;
	}


	/**
	 * Instancia ViaticosProcesoSingleton.
	 *
	 * @param codigo : tipo String
	 */
	public  ViaticosProcesoSingletonImpl(String codigo) {

		this.modoProcesoViaticos=codigo;

	}

}
