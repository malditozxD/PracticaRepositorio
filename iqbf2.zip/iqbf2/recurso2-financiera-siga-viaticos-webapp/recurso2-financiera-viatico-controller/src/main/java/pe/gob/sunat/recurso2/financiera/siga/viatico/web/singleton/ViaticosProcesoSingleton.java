package pe.gob.sunat.recurso2.financiera.siga.viatico.web.singleton;

public interface ViaticosProcesoSingleton {

	public String obtenerProceso();
}
