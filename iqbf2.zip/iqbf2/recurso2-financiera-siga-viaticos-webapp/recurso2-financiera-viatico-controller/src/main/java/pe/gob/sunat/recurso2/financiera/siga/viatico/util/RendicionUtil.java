package pe.gob.sunat.recurso2.financiera.siga.viatico.util;


import java.util.ArrayList;

import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.administracion.siga.util.Anio;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.view.MaestroPersonalViaticoBeanView;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.view.RendicionVO;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

public class RendicionUtil {

	public static MaestroPersonalViaticoBeanView obtenerMaestroPersonalBeanView(UsuarioBean usuarioBean, MaestroPersonalBean maestroPersonalBean) {
		
		MaestroPersonalViaticoBeanView maestroPersonalRendicionBeanView = new MaestroPersonalViaticoBeanView();
		maestroPersonalRendicionBeanView.setNumeroRegistro(usuarioBean.getNroRegistro());
		maestroPersonalRendicionBeanView.setCodigoEmpleado(maestroPersonalBean.getCodigoEmpleado());
		maestroPersonalRendicionBeanView.setNumeroRegistroRegistrador(usuarioBean.getNroRegistro());
		maestroPersonalRendicionBeanView.setCodigoRegistrador(maestroPersonalBean.getCodigoEmpleado());
		maestroPersonalRendicionBeanView.setNombreCompleto(maestroPersonalBean.getNombre_completo());
		maestroPersonalRendicionBeanView.setCodigoEstado(maestroPersonalBean.getCodigoEstado());
		maestroPersonalRendicionBeanView.setDescripcionEstado(maestroPersonalBean.getEstado());
		maestroPersonalRendicionBeanView.setUuoo(maestroPersonalBean.getUuoo());
		maestroPersonalRendicionBeanView.setCodigoDependencia(maestroPersonalBean.getCodigoDependencia());
		maestroPersonalRendicionBeanView.setDescripcionDependencia(maestroPersonalBean.getDependencia());
		return maestroPersonalRendicionBeanView;
	}
	
	public static RendicionVO obtenerRendicionVO(UsuarioBean usuarioBean, MaestroPersonalBean maestroPersonalBean) {
		RendicionVO rendicionVO = null;
		if (usuarioBean != null && maestroPersonalBean != null) {
			rendicionVO = new RendicionVO();
			rendicionVO.setNumeroRegistroRegistrador(usuarioBean.getNroRegistro());
			rendicionVO.setCodigoRegistrador(maestroPersonalBean.getCodigoEmpleado());
			rendicionVO.setCodigoSedeRegistrador(maestroPersonalBean.getCodigoSede());
			rendicionVO.setNombreRegistrador(maestroPersonalBean.getNombre_completo());
			
			rendicionVO.setNumeroRegistroColaborador(usuarioBean.getNroRegistro());
			rendicionVO.setCodigoColaborador(maestroPersonalBean.getCodigoEmpleado());
			rendicionVO.setNombreColaborador(maestroPersonalBean.getNombre_completo());
			rendicionVO.setCodigoEstadoColaborador(maestroPersonalBean.getCodigoEstado());
			rendicionVO.setDescripcionEstadoColaborador(maestroPersonalBean.getEstado());
			
			rendicionVO.setUuoo(maestroPersonalBean.getUuoo());
			rendicionVO.setCodigoDependencia(maestroPersonalBean.getCodigoDependencia());
			rendicionVO.setDescripcionDependencia(maestroPersonalBean.getDependencia());
		}
		return rendicionVO;
	}
	
	public static ArrayList<Anio> obtenerAniosRendicion(int anioActual) {
		
		ArrayList<Anio> anioList = new ArrayList<Anio>();
		int anioInicial = anioActual - 5;
		for (int i = anioInicial; i < anioActual + 1; i++) {
			Anio anio = new Anio();
			anio.setCodigoAnio(Integer.toString(i));
			anio.setDescripcionAnio(Integer.toString(i));
			anioList.add(anio);
		}
		return anioList;
	}
	
}
