package pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.web.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.T01ParametroBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.DependenciaBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroDependenciasService;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroGeneralService;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.administracion.siga.util.Anio;
import pe.gob.sunat.recurso2.administracion.siga.util.FechaUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.FormatoUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.SolicitudDTO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoConsultaService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoMensajeriaService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoReporteService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.service.RevisionSolicitudService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ResourceBundleUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.SolicitudConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.SolicitudUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.controller.BaseController;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.view.SolicitudVO;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

/**
 * Controller que contiene los metodos necesarios para revisar una solicitud.
 * @author Jorge Ponce.
 */
public class RevisionSolicitudController extends BaseController {
	
	protected final Log log = LogFactory.getLog(getClass());
	private RevisionSolicitudService revisionSolicitudService;
	private ViaticoConsultaService viaticoConsultaService;
	private ViaticoReporteService viaticoReporteService;
	private ViaticoMensajeriaService viaticoMensajeriaService;
	private RegistroPersonalService registroPersonalService;
	private RegistroGeneralService registroGeneralService;
	private RegistroDependenciasService registroDependenciaService;
	
	public RevisionSolicitudService getRevisionSolicitudService() {
		return revisionSolicitudService;
	}

	public void setRevisionSolicitudService(RevisionSolicitudService revisionSolicitudService) {
		this.revisionSolicitudService = revisionSolicitudService;
	}

	public ViaticoConsultaService getViaticoConsultaService() {
		return viaticoConsultaService;
	}

	public void setViaticoConsultaService(
			ViaticoConsultaService viaticoConsultaService) {
		this.viaticoConsultaService = viaticoConsultaService;
	}

	public ViaticoReporteService getViaticoReporteService() {
		return viaticoReporteService;
	}

	public void setViaticoReporteService(ViaticoReporteService viaticoReporteService) {
		this.viaticoReporteService = viaticoReporteService;
	}

	public ViaticoMensajeriaService getViaticoMensajeriaService() {
		return viaticoMensajeriaService;
	}

	public void setViaticoMensajeriaService(ViaticoMensajeriaService viaticoMensajeriaService) {
		this.viaticoMensajeriaService = viaticoMensajeriaService;
	}

	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}

	public RegistroGeneralService getRegistroGeneralService() {
		return registroGeneralService;
	}

	public void setRegistroGeneralService(RegistroGeneralService registroGeneralService) {
		this.registroGeneralService = registroGeneralService;
	}

	/**
	 * Metodo que permite mostrar la bandeja solicitud autorizador.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView.
	 * @see ModelAndView
	 */
	public ModelAndView mostrarBandejaSolicitudAutorizador(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView modelAndView = null;
		String errorMessage = SolicitudConstantes.CADENA_VACIA;
		try {
			log.debug(RevisionSolicitudController.class.getSimpleName() + ".mostrarBandejaSolicitudAutorizador");
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			String loginUsuario = usuarioBean.getLogin();
			
			String numeroRegistro = usuarioBean.getNroRegistro();
			MaestroPersonalBean maestroPersonalBean = registroPersonalService.obtenerPersonaxRegistro(numeroRegistro);
			
			Map<String,String> resultadoEvaluacionUuoo = revisionSolicitudService.reevaluarUUOOsAutorizadoras(maestroPersonalBean.getCodigoEmpleado());
			String codEjecucion = resultadoEvaluacionUuoo.get("codEjecucion");
			String msgEjecucion = resultadoEvaluacionUuoo.get("msgEjecucion");
			
			if(!"00".equals(codEjecucion)){
				errorMessage = msgEjecucion;
			}
			
			SolicitudVO solicitudVO = SolicitudUtil.obtenerSolicitudVO(usuarioBean, maestroPersonalBean);
			if (solicitudVO != null) {
				String codigoEmpleado = maestroPersonalBean.getCodigoEmpleado();
				String flagAutorizador = ViaticoUtil.obtenerFlagViatico(registroPersonalService.determinaAutorizadorGastoViatico(codigoEmpleado));
				if (SolicitudConstantes.UNO.equals(flagAutorizador)) {
					Map<String, Object> paramSearch = new HashMap<String, Object>();
					paramSearch.put("cod_par", SolicitudConstantes.PARAMETRO_CANAL_ATENCION);
					paramSearch.put("cod_tipo", SolicitudConstantes.TIPO_CANAL_ATENCION);
					ArrayList<T01ParametroBean> canalAtencionList = (ArrayList<T01ParametroBean>) registroGeneralService.recuperarParametroLista(paramSearch);
					solicitudVO.setCanalAtencionList(canalAtencionList);
					
					ArrayList<Anio> anioList = SolicitudUtil.obtenerAniosSolicitud(Integer.parseInt(FechaUtil.obtenerAnioActual()));
					solicitudVO.setAnioList(anioList);
					solicitudVO.setAnioActual(FechaUtil.obtenerAnioActual());
					
					solicitudVO.setFlagAutorizador(flagAutorizador);
					solicitudVO.setFlagMayor1UUOOAsociada("1");
					solicitudVO.setFlagBuscarColaborador(ViaticoConstantes.BUSCAR_AUTORIZADOR);
					solicitudVO.setFlagBuscarUUOO(ViaticoConstantes.BUSCAR_AUTORIZADOR);
				}
				else {
					errorMessage = ResourceBundleUtil.getMessage(SolicitudConstantes.MENSAJE_ERROR_ACCESO, SolicitudConstantes.PERFIL_AUTORIZADOR);
				}
			}
			respuesta.put("solicitudVO", solicitudVO);
			respuesta.put("loginUsuario", loginUsuario);
			log.debug(RevisionSolicitudController.class.getSimpleName() + ".mostrarBandejaSolicitudAutorizador.fin");
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			errorMessage = ResourceBundleUtil.getMessage(SolicitudConstantes.MENSAJE_ERROR_GENERICO);
		}
		respuesta.put("errorMessage", errorMessage);
		modelAndView = new ModelAndView(SolicitudConstantes.REVISAR_SOLICITUD_AUTORIZADOR_PAGE, respuesta);
		return modelAndView;
	}
	
	/**
	 * Metodo que permite obtener/buscar las planillas de la bandeja solicitud autorizador.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	public ModelAndView buscarPlanillasBandejaAutorizacionSolicitud(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoConsulta = SolicitudConstantes.ERROR_CONSULTA;
		String errorMessage = SolicitudConstantes.CADENA_VACIA;
		boolean flagExistePlanilla = true;
		
		try {
			log.debug(RevisionSolicitudController.class.getSimpleName() + ".buscarPlanillasBandejaAutorizacionSolicitud");
			String codigoDependencia = request.getParameter("codigoDependencia");
			String codPlanilla = request.getParameter("codPlanilla");
			String codTrabajador = request.getParameter("codTrabajador");
			String codEstadoSolic = request.getParameter("codEstadoSolic");
			String indicadorCanalAtencion = request.getParameter("indicadorCanalAtencion");
			String fechaDesdeString = request.getParameter("fechaDesde");
			String fechaHastaString = request.getParameter("fechaHasta");
			String codigoAutorizador = request.getParameter("codigoAutorizador");
			Date fechaDesde = null;
			Date fechaHasta = null;
			
			//JMCR-ME BANDEJA AUTORIZADOR
			List<String> listEstados = new ArrayList<String>();
			if (ViaticoConstantes.ESTADO_VIATICO_POR_AUTORIZAR.equals(codEstadoSolic)) {
				listEstados.add(ViaticoConstantes.ESTADO_VIATICO_POR_AUTORIZAR);
			}
			else if ("T".equals(codEstadoSolic)) {
				listEstados.add(ViaticoConstantes.ESTADO_VIATICO_POR_AUTORIZAR);				
				listEstados.add(ViaticoConstantes.ESTADO_VIATICO_ENVIADO_CAJACHICA);
				listEstados.add(ViaticoConstantes.ESTADO_VIATICO_ENVIADO_CPP);
				listEstados.add(ViaticoConstantes.ESTADO_VIATICO_ENVIADO_FINANCIERA);
			}
			else if (ViaticoConstantes.ESTADO_VIATICO_ENVIADO_CAJACHICA.equals(codEstadoSolic)) {
				listEstados.add(ViaticoConstantes.ESTADO_VIATICO_ENVIADO_CAJACHICA);
			}
			else if (ViaticoConstantes.ESTADO_VIATICO_ENVIADO_CPP.equals(codEstadoSolic)) {
				listEstados.add(ViaticoConstantes.ESTADO_VIATICO_ENVIADO_CPP);
			}
			else if (ViaticoConstantes.ESTADO_VIATICO_ENVIADO_FINANCIERA.equals(codEstadoSolic)) {
				listEstados.add(ViaticoConstantes.ESTADO_VIATICO_ENVIADO_FINANCIERA);
			}
			//JMCR-ME BANDEJA AUTORIZADOR
			
			codigoDependencia = FormatoUtil.validarEmptyToNull(codigoDependencia);
			codPlanilla = FormatoUtil.validarEmptyToNull(codPlanilla);
			codTrabajador = FormatoUtil.validarEmptyToNull(codTrabajador);
			codigoAutorizador = FormatoUtil.validarEmptyToNull(codigoAutorizador);
			if (SolicitudConstantes.CADENA_VACIA.equals(codEstadoSolic) || SolicitudConstantes.CODIGO_00.equals(codEstadoSolic)) {
				codEstadoSolic = null;
			}
			
			if (SolicitudConstantes.CADENA_VACIA.equals(indicadorCanalAtencion) || SolicitudConstantes.CODIGO_00.equals(indicadorCanalAtencion)) {
				indicadorCanalAtencion = null;
			}
			
			if (!SolicitudConstantes.CADENA_VACIA.equals(fechaDesdeString)) {
				fechaDesde = FechaUtil.parseStringDateToDate(fechaDesdeString, SolicitudConstantes.DATE_FORMAT_DDMMYYYY);
			}
			
			if (!SolicitudConstantes.CADENA_VACIA.equals(fechaHastaString)) {
				fechaHasta = FechaUtil.parseStringDateToDate(fechaHastaString, SolicitudConstantes.DATE_FORMAT_DDMMYYYY);
			}
			
			if (codPlanilla != null) {
				flagExistePlanilla = viaticoConsultaService.existePlanilla(codPlanilla);
				codigoConsulta = SolicitudConstantes.ERROR_CONSULTA_NO_EXISTE_PLANILLA;
				errorMessage = ResourceBundleUtil.getMessage(SolicitudConstantes.MENSAJE_ERROR_PLANILLA_NO_EXISTE);
			}
			
			if (flagExistePlanilla) {
				ArrayList<PlanViajeBean> planViajeList = revisionSolicitudService.obtenerPlanViajeToBandejaAutorizacionSolicitud(codigoDependencia, 
						codPlanilla, codTrabajador, listEstados, indicadorCanalAtencion, fechaDesde, fechaHasta, codigoAutorizador);
				codigoConsulta = SolicitudConstantes.EXITO_CONSULTA;
				respuesta.put("planViajeList", planViajeList);
			}
			log.debug(RevisionSolicitudController.class.getSimpleName() + ".buscarPlanillasBandejaAutorizacionSolicitud.fin");
			
		} catch (Exception e) {
			errorMessage = ResourceBundleUtil.getMessage(SolicitudConstantes.MENSAJE_ERROR_GENERICO);
			log.error(e.getMessage(), e);
		}
		
		respuesta.put("codigoConsulta", codigoConsulta);
		respuesta.put("errorMessage", errorMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	/**
	 * Metodo que permite exportar excel de la bandeja solicitud autorizador.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (Excel).
	 * @see ModelAndView
	 */
	public ModelAndView exportarExcelBandejaAutorizacionSolicitud(HttpServletRequest request, HttpServletResponse response) {
		
		ModelAndView viewPage = null;
		
		try {
			log.debug(RevisionSolicitudController.class.getSimpleName() + ".exportarExcelBandejaAutorizacionSolicitud");
			String codigoDependencia = request.getParameter("codigoDependencia");
			String codPlanilla = request.getParameter("codPlanilla");
			String codTrabajador = request.getParameter("codTrabajador");
			String codEstadoSolic = request.getParameter("codEstadoSolic");
			String indicadorCanalAtencion = request.getParameter("indicadorCanalAtencion");
			String fechaDesdeString = request.getParameter("fechaDesde");
			String fechaHastaString = request.getParameter("fechaHasta");
			String codigoAutorizador = request.getParameter("codigoAutorizador");
			Date fechaDesde = null;
			Date fechaHasta = null;
			
			log.debug("parametros enexportarExcelBandejaAutorizacionSolicitud: ");
			Enumeration<String> parametros = (Enumeration<String>)request.getParameterNames(); 
			while (parametros.hasMoreElements()) {
				String paramName = parametros.nextElement();
				log.debug(paramName +  ": " + request.getParameter(paramName));
			}
			
			//JMCR-ME BANDEJA AUTORIZADOR
			List<String> listEstados = new ArrayList<String>();
			if (ViaticoConstantes.ESTADO_VIATICO_POR_AUTORIZAR.equals(codEstadoSolic)) {
				listEstados.add(ViaticoConstantes.ESTADO_VIATICO_POR_AUTORIZAR);
			}
			else if ("T".equals(codEstadoSolic)) {
				listEstados.add(ViaticoConstantes.ESTADO_VIATICO_POR_AUTORIZAR);				
				listEstados.add(ViaticoConstantes.ESTADO_VIATICO_ENVIADO_CAJACHICA);
				listEstados.add(ViaticoConstantes.ESTADO_VIATICO_ENVIADO_CPP);
				listEstados.add(ViaticoConstantes.ESTADO_VIATICO_ENVIADO_FINANCIERA);
			}
			else if (ViaticoConstantes.ESTADO_VIATICO_ENVIADO_CAJACHICA.equals(codEstadoSolic)) {
				listEstados.add(ViaticoConstantes.ESTADO_VIATICO_ENVIADO_CAJACHICA);
			}
			else if (ViaticoConstantes.ESTADO_VIATICO_ENVIADO_CPP.equals(codEstadoSolic)) {
				listEstados.add(ViaticoConstantes.ESTADO_VIATICO_ENVIADO_CPP);
			}
			else if (ViaticoConstantes.ESTADO_VIATICO_ENVIADO_FINANCIERA.equals(codEstadoSolic)) {
				listEstados.add(ViaticoConstantes.ESTADO_VIATICO_ENVIADO_FINANCIERA);
			}
			//JMCR-ME BANDEJA AUTORIZADOR

			
			codigoDependencia = FormatoUtil.validarEmptyToNull(codigoDependencia);
			codPlanilla = FormatoUtil.validarEmptyToNull(codPlanilla);
			codTrabajador = FormatoUtil.validarEmptyToNull(codTrabajador);
			codigoAutorizador = FormatoUtil.validarEmptyToNull(codigoAutorizador);
			if (SolicitudConstantes.CADENA_VACIA.equals(codEstadoSolic) || SolicitudConstantes.CODIGO_00.equals(codEstadoSolic)) {
				codEstadoSolic = null;
			}
			if (SolicitudConstantes.CADENA_VACIA.equals(indicadorCanalAtencion) || SolicitudConstantes.CODIGO_00.equals(indicadorCanalAtencion)) {
				indicadorCanalAtencion = null;
			}
			
			if (!SolicitudConstantes.CADENA_VACIA.equals(fechaDesdeString)) {
				fechaDesde = FechaUtil.parseStringDateToDate(fechaDesdeString, SolicitudConstantes.DATE_FORMAT_DDMMYYYY);
			}
			
			if (!SolicitudConstantes.CADENA_VACIA.equals(fechaHastaString)) {
				fechaHasta = FechaUtil.parseStringDateToDate(fechaHastaString, SolicitudConstantes.DATE_FORMAT_DDMMYYYY);
			}
			
			ArrayList<PlanViajeBean> planViajeList = revisionSolicitudService.obtenerPlanViajeCompletoToBandejaAutorizacionSolicitud(codigoDependencia, codPlanilla, codTrabajador, listEstados, indicadorCanalAtencion, fechaDesde, fechaHasta, codigoAutorizador);
			String nombreArchivo = SolicitudConstantes.ARCHIVO_EXCEL_PREFIJO + FechaUtil.formatDateToDateYYYYMMDDHHMMSS(new Date()) + SolicitudConstantes.ARCHIVO_EXCEL_EXTENSION;
			response.setContentType("application/xls");
			response.setHeader("Content-Disposition", "attachment; filename=" + nombreArchivo);
			viaticoReporteService.generarExcelBandejaAutorizacionSolicitud(response.getOutputStream(), planViajeList);
			log.debug(RevisionSolicitudController.class.getSimpleName() + ".exportarExcelBandejaAutorizacionSolicitud.fin");
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		
		return viewPage;
	}
	
	/**
	 * Metodo que permite autorizar una solicitud de la bandeja solicitud autorizador.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	public ModelAndView autorizarSolicitudBandejaAutorizacionSolicitud(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoOperacion = SolicitudConstantes.ERROR_OPERACION;
		String errorMessage = SolicitudConstantes.CADENA_VACIA;
		
		try {
			log.debug(RevisionSolicitudController.class.getSimpleName() + ".autorizarSolicitudBandejaAutorizacionSolicitud");
			String codPlanViaje = request.getParameter("codPlanViaje");
			String codPerAutoriza = request.getParameter("codPerAutoriza");
			String codigoDependenciaAutorizador = request.getParameter("codigoDependenciaAutorizador");
			String codigoSedeAutorizador = request.getParameter("codigoSedeAutorizador");
			String codigoNivelAutorizador = request.getParameter("codigoNivelAutorizador");
			String expedientePlanViaje = request.getParameter("expedientePlanViaje");
			String indicadorCanalAtencion = request.getParameter("indicadorCanalAtencion");
			String numArchivoPdfFirmado = request.getParameter("numArchivoPdfFirmado");
			codPlanViaje = FormatoUtil.validarEmptyToNull(codPlanViaje);
			numArchivoPdfFirmado = FormatoUtil.validarEmptyToNull(numArchivoPdfFirmado);//si el parámetro está vacío retorna null, en cualquie otro caso retorna el parámetro
			if (codPlanViaje != null) {
				setAuditoriaBeanHolder(request, response);
				codigoOperacion = revisionSolicitudService.autorizarSolicitud(codPlanViaje, codPerAutoriza, codigoDependenciaAutorizador, 
						codigoSedeAutorizador, codigoNivelAutorizador, expedientePlanViaje,numArchivoPdfFirmado);
				log.debug("codigoOperacion: "+ codigoOperacion + "indicadorCanalAtencion: " +indicadorCanalAtencion+", archivo pdf firmado al autorizar:"+numArchivoPdfFirmado);
				if (SolicitudConstantes.EXITO_OPERACION.equals(codigoOperacion)) {
					if (SolicitudConstantes.CANAL_ATENCION_CAJA_CHICA.equals(indicadorCanalAtencion)) {
						SolicitudDTO solicitudDTO = viaticoConsultaService.obtenerPlanViajeToNotificacion(codPlanViaje);
						viaticoMensajeriaService.enviarNotificacionAutorizacionSolicitudCajaChica(solicitudDTO);
					}
				}
			}
			log.debug(RevisionSolicitudController.class.getSimpleName() + ".autorizarSolicitudBandejaAutorizacionSolicitud.fin");
			
		} catch (ServiceException e) {
			errorMessage = e.getMessage();
			log.error(e.getMessage(), e);
			
		} catch (Exception e) {
			errorMessage = ResourceBundleUtil.getMessage(SolicitudConstantes.MENSAJE_ERROR_GENERICO);
			log.error(e.getMessage(), e);
		}

		respuesta.put("codigoOperacion", codigoOperacion);
		respuesta.put("errorMessage", errorMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	
	public ModelAndView actualizarDependenciaPlanViaje(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoOperacion = SolicitudConstantes.ERROR_OPERACION;
		String errorMessage = SolicitudConstantes.CADENA_VACIA;
		String mensajeDerivacion = SolicitudConstantes.CADENA_VACIA;
		
		try {
			log.debug(RevisionSolicitudController.class.getSimpleName() + ".actualizarDependenciaPlanViaje");
			String codDependencia = request.getParameter("codDependencia");
			String codigoSedeAutorizador = request.getParameter("codigoSedeAutorizador");
			String codPlanViaje = request.getParameter("codPlanViaje");
			String codExpediente = request.getParameter("codExpediente");
			String indicadorCanalAtencion = request.getParameter("indicadorCanalAtencion");
			
			codPlanViaje = FormatoUtil.validarEmptyToNull(codPlanViaje);
			
			if (codPlanViaje != null) {
				setAuditoriaBeanHolder(request, response);
				UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
				MaestroPersonalBean autorizador = registroPersonalService.obtenerPersonaxRegistro(usuarioBean.getNroRegistro());
				
				DependenciaBean dependencia = registroDependenciaService.obtenerDependenciaXcod(codDependencia);
				MaestroPersonalBean responsableDependencia = registroPersonalService.obtenerPersonaxCodigo(dependencia.getCodEmpleado());
				
				//mensaje
				String nombreNuevoAutorizador = responsableDependencia.getNombre_completo();
				mensajeDerivacion = "Se realizó la derivación de la planilla al Sr(a): "+responsableDependencia.getNombre_completo()+" de la "+dependencia.getNom_largo();
				
				codigoOperacion = revisionSolicitudService.derivarSolicitud(codPlanViaje, codDependencia, codExpediente, indicadorCanalAtencion, autorizador,codigoSedeAutorizador,nombreNuevoAutorizador);
			}
			log.debug(RevisionSolicitudController.class.getSimpleName() + ".actualizarDependenciaPlanViaje.fin");
			
		} catch (ServiceException e) {
			errorMessage = e.getMessage();
			log.error(e.getMessage(), e);
			
		} catch (Exception e) {
			errorMessage = ResourceBundleUtil.getMessage(SolicitudConstantes.MENSAJE_ERROR_GENERICO);
			log.error(e.getMessage(), e);
		}

		respuesta.put("codigoOperacion", codigoOperacion);
		respuesta.put("errorMessage", errorMessage);
		respuesta.put("mensajeDerivacion", mensajeDerivacion);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}

	public RegistroDependenciasService getRegistroDependenciaService() {
		return registroDependenciaService;
	}

	public void setRegistroDependenciaService(
			RegistroDependenciasService registroDependenciaService) {
		this.registroDependenciaService = registroDependenciaService;
	}
	
}
