package pe.gob.sunat.recurso2.financiera.siga.viatico.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.web.servlet.ModelAndView;

import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.administracion.siga.util.Anio;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.view.SolicitudVO;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

/**
 * Esta clase permite realizar operaciones comunes sobre solicitudes de viatico
 * 
 * @author Juan Saccatoma
 */
public class SolicitudUtil {

	/**
	 * Metodo que permite armar un objeto de vista SolicitudVO a partir del UsuarioBean de session y el MaestroPersonalBean de base de datos.
	 * 
	 * @author Juan Saccatoma
	 * @param usuarioBean bean de session
	 * @param maestroPersonalBean bean maestro persona
	 * @return el objeto ModelAndView con la constantesMap de la peticion
	 * @see ModelAndView
	 */
	public static SolicitudVO obtenerSolicitudVO(UsuarioBean usuarioBean, MaestroPersonalBean maestroPersonalBean) {

		SolicitudVO solicitudVO = null;
		if (usuarioBean != null && maestroPersonalBean != null) {
			solicitudVO = new SolicitudVO();

			// datos del colaborador
			solicitudVO.setNumeroRegistro(usuarioBean.getNroRegistro());
			solicitudVO.setNumeroRegistroColaborador(usuarioBean.getNroRegistro());
			solicitudVO.setCodigoColaborador(maestroPersonalBean.getCodigoEmpleado());
			solicitudVO.setNombreColaborador(StringUtils.trimToEmpty(maestroPersonalBean.getNombre_completo()));
			solicitudVO.setCodigoEstadoColaborador(maestroPersonalBean.getCodigoEstado());
			solicitudVO.setEstadoColaborador(maestroPersonalBean.getEstado());
			solicitudVO.setDescripcionEstadoColaborador(maestroPersonalBean.getEstado());

			// datos del registrador
			solicitudVO.setNumeroRegistroRegistrador(usuarioBean.getNroRegistro());
			solicitudVO.setCodigoRegistrador(maestroPersonalBean.getCodigoEmpleado());
			solicitudVO.setCodigoSedeRegistrador(maestroPersonalBean.getCodigoSede());
			solicitudVO.setNombreRegistrador(StringUtils.trimToEmpty(maestroPersonalBean.getNombre_completo()));

			// datos del autorizador
			solicitudVO.setNumeroRegistroAutorizador(usuarioBean.getNroRegistro());
			solicitudVO.setCodigoAutorizador(maestroPersonalBean.getCodigoEmpleado());
			solicitudVO.setCodigoDependenciaAutorizador(maestroPersonalBean.getCodigoDependencia());
			solicitudVO.setCodigoSedeAutorizador(maestroPersonalBean.getCodigoSede());
			solicitudVO.setCodigoNivelAutorizador(maestroPersonalBean.getCodigoNivel());
			solicitudVO.setNombreAutorizador(StringUtils.trimToEmpty(maestroPersonalBean.getNombre_completo()));

			// datos de la uuoo
			solicitudVO.setUuoo(maestroPersonalBean.getUuoo());
			solicitudVO.setCodigoDependencia(maestroPersonalBean.getCodigoDependencia());
			solicitudVO.setDescripcionDependencia(maestroPersonalBean.getDependencia());
		}
		return solicitudVO;
	}

	/**
	 * Metodo que permite armar la lista de objetos Anio a visualizar en las bandejas de solicitud
	 * 
	 * @author Jorge Ponce
	 * @param anioActual a�o actual
	 * @return lista de objetos a�os
	 * @see Anio
	 */
	public static ArrayList<Anio> obtenerAniosSolicitud(int anioActual) {

		ArrayList<Anio> anioList = new ArrayList<Anio>();
		int anioInicial = anioActual - 5;
		for (int i = anioInicial; i < anioActual + 1; i++) {
			Anio anio = new Anio();
			anio.setCodigoAnio(Integer.toString(i));
			anio.setDescripcionAnio(Integer.toString(i));
			anioList.add(anio);
		}
		return anioList;
	}

	/**
	 * Metodo que permite armar la lista de anios (como cadena) a visualizar en las bandejas de solicitud.
	 * 
	 * @author Juan Farro
	 * @param anioActual anio actual
	 * @return lista de anios
	 */
	public static List<String> obtenerListaAniosBandejasSolicitud(int anioActual) {

		int anioInicial = anioActual - ViaticoConstantes.BANDEJA_NUMERO_ANIOS_RANGO;

		List<String> listaAnios = new ArrayList<String>();
		for (int anio = anioInicial; anio <= anioActual; anio++) {
			listaAnios.add(String.valueOf(anio));
		}

		return listaAnios;
	}

	/**
	 * Metodo que permite setear las constantes estados de viatico
	 * 
	 * @author Juan Farro
	 * @param constantesMap mapa con las constantes
	 */
	public static void poblarConstantesEstadosViatico(Map<String, Object> constantesMap) {

		if (constantesMap == null) return;

		constantesMap.put("ESTADO_VIATICO_ELABORADO", ViaticoConstantes.ESTADO_VIATICO_ELABORADO);
		constantesMap.put("ESTADO_VIATICO_ANULADO", ViaticoConstantes.ESTADO_VIATICO_ANULADO);
		constantesMap.put("ESTADO_VIATICO_POR_AUTORIZAR", ViaticoConstantes.ESTADO_VIATICO_POR_AUTORIZAR);
		constantesMap.put("ESTADO_VIATICO_AUTORIZADO", ViaticoConstantes.ESTADO_VIATICO_AUTORIZADO);
		constantesMap.put("ESTADO_VIATICO_OBSERVADO", ViaticoConstantes.ESTADO_VIATICO_OBSERVADO);
		constantesMap.put("ESTADO_VIATICO_OBSERVADO_CAJA_CHICA", ViaticoConstantes.ESTADO_VIATICO_OBSERVADO_CAJA_CHICA);
		constantesMap.put("ESTADO_VIATICO_OBSERVADO_FINANCIERA", ViaticoConstantes.ESTADO_VIATICO_OBSERVADO_FINANCIERA);
		constantesMap.put("ESTADO_VIATICO_ANULACION_AUTOMATICA", ViaticoConstantes.ESTADO_VIATICO_ANULACION_AUTOMATICA);
		constantesMap.put("ESTADO_VIATICO_PAGADO", ViaticoConstantes.ESTADO_VIATICO_PAGADO);
	 
	}
	
	/**
	 * Metodo que permite setear [clave-valor] las constantes usadas para el registro/modificacion de una solicitud de viatico.
	 * 
	 * @author Juan Farro
	 * @param constantesMap mapa con las constantes
	 */
	public static void poblarConstantesParaRegistro(Map<String, Object> constantesMap) {

		if (constantesMap == null) return;

		constantesMap.put("RUTA_TIPO_TARIFA_OTROS", ViaticoConstantes.RUTA_TIPO_TARIFA_OTROS);
		constantesMap.put("RUTA_TIPO_TARIFA_GENERAL", ViaticoConstantes.RUTA_TIPO_TARIFA_GENERAL);
		constantesMap.put("MEDIO_TRANSPORTE_AEREO", ViaticoConstantes.MEDIO_TRANSPORTE_AEREO);
		constantesMap.put("MEDIO_TRANSPORTE_TERRESTRE", ViaticoConstantes.MEDIO_TRANSPORTE_TERRESTRE);
		constantesMap.put("MONEDA_SOLES", ViaticoConstantes.MONEDA_SOLES);
		constantesMap.put("MONEDA_DOLARES", ViaticoConstantes.MONEDA_DOLARES);
		constantesMap.put("MAXIMO_NRO_DIAS_HABILES", ViaticoConstantes.MAXIMO_NRO_DIAS_HABILES);
		constantesMap.put("CANAL_ATENCION_CAJA_CHICA", ViaticoConstantes.CANAL_ATENCION_CAJACHICA);
		constantesMap.put("CANAL_ATENCION_CAJA_CHICA_DESCRIP", ViaticoConstantes.CANAL_ATENCION_CAJACHICA_DESCRIP);
		constantesMap.put("CANAL_ATENCION_REEMBOLSO", ViaticoConstantes.CANAL_ATENCION_REEMBOLSO);
		constantesMap.put("CANAL_ATENCION_REEMBOLSO_DESCRIP", ViaticoConstantes.CANAL_ATENCION_REEMBOLSO_DESCRIP);
		constantesMap.put("CANAL_ATENCION_NUMERO_DIAS_TOPE", ViaticoConstantes.CANAL_ATENCION_NUMERO_DIAS_TOPE);
		constantesMap.put("CONFIGURACION_MANUAL", ViaticoConstantes.TIPO_CONFIGURACION_MANUAL);
		constantesMap.put("CONFIGURACION_AUTOMATICA", ViaticoConstantes.TIPO_CONFIGURACION_AUTOMATICA);
		constantesMap.put("TARIFARIO_NACIONAL", ViaticoConstantes.TIPO_TARIFARIO_NACIONAL);
		constantesMap.put("TARIFARIO_REGIONAL", ViaticoConstantes.TIPO_TARIFARIO_REGIONAL);
		constantesMap.put("SI", ViaticoConstantes.SI);
		constantesMap.put("NO", ViaticoConstantes.NO);
	}	

	/**
	 * Metodo que permite determinar si se puede enviar una solicitud de viatico en funcion de su codigo de estado.
	 *
	 * @author Juan Farro
	 * @param estadoSolicitud estado de la solicitud de viatico
	 * @return si puede enviar o no
	 */
	public static boolean puedeEnviarSolicitudViatico(String estadoSolicitud) {

		// si esta en alguno de estos estados puede enviar
		if (StringUtils.equals(estadoSolicitud, ViaticoConstantes.ESTADO_VIATICO_ELABORADO) || 
				StringUtils.equals(estadoSolicitud, ViaticoConstantes.ESTADO_VIATICO_OBSERVADO) || 
				StringUtils.equals(estadoSolicitud, ViaticoConstantes.ESTADO_VIATICO_OBSERVADO_CAJA_CHICA) ||
				StringUtils.equals(estadoSolicitud, ViaticoConstantes.ESTADO_VIATICO_OBSERVADO_FINANCIERA)) {

			return true;
		}

		return false;
	}
	
	/**
	 * Metodo que permite determinar si se puede enviar una solicitud de viatico en funcion de su codigo de estado.
	 *
	 * @author Juan Farro
	 * @param estadoSolicitud estado de la solicitud de viatico
	 * @return si puede modificar o no
	 */
	public static boolean puedeModificarSolicitudViatico(String estadoSolicitud) {

		// si esta en alguno de estos estados puede enviar
		if (StringUtils.equals(estadoSolicitud, ViaticoConstantes.ESTADO_VIATICO_ELABORADO) || 
				StringUtils.equals(estadoSolicitud, ViaticoConstantes.ESTADO_VIATICO_OBSERVADO) || 
				StringUtils.equals(estadoSolicitud, ViaticoConstantes.ESTADO_VIATICO_OBSERVADO_CAJA_CHICA) ||
				StringUtils.equals(estadoSolicitud, ViaticoConstantes.ESTADO_VIATICO_OBSERVADO_FINANCIERA)) {

			return true;
		}

		return false;
	}	

}
