package pe.gob.sunat.recurso2.financiera.siga.viatico.web.controller;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.recurso2.administracion.siga.archivo.model.bean.RegistroArchivosFisicoBean;
import pe.gob.sunat.recurso2.administracion.siga.archivo.service.RegistroArchivosService;
import pe.gob.sunat.recurso2.administracion.siga.archivo.util.ReporteJasperBean;
import pe.gob.sunat.recurso2.administracion.siga.firma.model.bean.T5282Archbin;
import pe.gob.sunat.recurso2.administracion.siga.firma.model.bean.T7074DocumentoFirm;
import pe.gob.sunat.recurso2.administracion.siga.firma.service.ConsultaFirmaService;
import pe.gob.sunat.recurso2.administracion.siga.firma.service.ValidarFirmarService;
import pe.gob.sunat.recurso2.administracion.siga.firma.util.FirmaConstantes;
import pe.gob.sunat.recurso2.administracion.siga.ldap.service.ValidadorLdapServiceImpl;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.DependenciaBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroDependenciasService;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ColaboradorViaticoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.NivelBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeRendicionBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoConsultaService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoReporteService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.service.ConsultaSolicitudService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.service.RegistroSolicitudService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.MaestroPersonalUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.RendicionConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.singleton.ViaticosProcesoSingleton;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

public class FirmaController extends BaseController {

	protected final Log log = LogFactory.getLog(getClass());
	
	private ConsultaFirmaService consultaFirmaService;
	private ValidarFirmarService validarFirmaService;
	private ValidadorLdapServiceImpl validadorLdapServiceImpl;
	private RegistroPersonalService	registroPersonalService;
	private RegistroArchivosService registroArchivosService;
	private ViaticoReporteService viaticoReporteService;
	private ConsultaSolicitudService consultaSolicitudService;
	private ViaticosProcesoSingleton viaticosProcesoSingleton;
	private RegistroDependenciasService	registroDependenciasService;
	private ViaticoConsultaService viaticoConsultaService;
	private RegistroSolicitudService registroSolicitudService;
	

	public ConsultaFirmaService getConsultaFirmaService() {
		return consultaFirmaService;
	}

	public void setConsultaFirmaService(ConsultaFirmaService consultaFirmaService) {
		this.consultaFirmaService = consultaFirmaService;
	}
	
	
	/**
	 * Valida si el documento enviado está firmado o no
	 *
	 * @author Carlos Cacique
	 * @see ModelAndView
	 * @param request: de la clase HttpServletRequest
	 * @param response: de la clase HttpServletResponse
	 * @param tipDocumento:  Tipo de documento firmado  del request.getParameter.
	 * @param numDocumento:  Número de documento firmado  del request.getParameter.
	 * @return objeto view del la clase ModelAndView tipo json con la lista de lugares
	 */
	public ModelAndView existeDocumentoFirmado(HttpServletRequest request,
			HttpServletResponse response) {

		Map<String, Object> respuesta = new HashMap<String, Object>();
		respuesta.put("existe", false);
		ModelAndView viewPage = null;

		try {
			log.debug("Iniciando la verificación de la existencia del documento firmado.");
			String tipDocumento = request.getParameter("tipDocumento");
			String numDocumento = request.getParameter("numDocumento");

			T7074DocumentoFirm paramSearch = new T7074DocumentoFirm();
			paramSearch.setCodTipdoc(tipDocumento);
			paramSearch.setNumDocumento(numDocumento);
			paramSearch.setIndEstdoc(ViaticoConstantes.ACTIVO);
			List<T7074DocumentoFirm> documentos = consultaFirmaService.recuperarDocumentosFirmados(paramSearch);
			
			respuesta.put("existe", CollectionUtils.isNotEmpty(documentos));
			viewPage = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}

		return viewPage;
	}
	
	
	public ModelAndView usuarioLdapValido(HttpServletRequest request,
			HttpServletResponse response) {

		Map<String, Object> respuesta = new HashMap<String, Object>();
		respuesta.put("usuarioValido", false);
		ModelAndView viewPage = null;
		try {
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			String txtPasswordUsuario = request.getParameter("txtPasswordUsuario");
			respuesta.put("usuarioValido", validadorLdapServiceImpl.validarUsuario(usuarioBean.getLogin(), txtPasswordUsuario));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	
	@SuppressWarnings("unchecked")
	public ModelAndView firmaUsuarioValida(HttpServletRequest request,
			HttpServletResponse response) {

		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		respuesta.put("firmaValida", false);
		ModelAndView viewPage = null;

		String tipProceso = request.getParameter("tipProceso");
		
		try {
			log.debug("Iniciando la verificación de la validez de la firma para el usuario.");
						
			MaestroPersonalBean persona = registroPersonalService.obtenerPersonaxRegistro(usuarioBean.getNroRegistro());
			
			boolean validacionCompleta = "A".equals(tipProceso);//Si se trata de una autorización la validación es completa. 
			
			Map<String, Object> resultado = validarFirmaService.validarAutorizadoFirma(persona.getCodigoEmpleado(), persona.getCodigoDependencia(), validacionCompleta);
			
			String errorFirma = (String)resultado.get("error");
			
			respuesta.put("firmaValida", "0".equals(errorFirma));//Si no hay errores entonces la firma del usuario está activa.
			
			if(!"0".equals(errorFirma)){
				//Si hay errores saco el error
				List<Map<String, Object>> errores = (List<Map<String, Object>>)resultado.get("erroresList");
				if(!CollectionUtils.isEmpty(errores)){
					Map<String, Object> errorMap = errores.get(0);
					respuesta.put("mensajeError",errorMap.get("mensajeError"));
				}
			}
			
			respuesta.put("error",resultado);
			viewPage = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}

		return viewPage;
	}
	
	
	
	
	@SuppressWarnings("unchecked")
	private HashMap<String,String> firmarDocumento(HttpServletRequest request, String tipDocumento, String numDocumento,
			String tipProceso, String txtPasswordUsuario, UsuarioBean usuarioBean, MaestroPersonalBean persona) throws Exception{
		
		HashMap<String,String> respuesta = new HashMap<String,String>();
		
		ReporteJasperBean params = null;
		
		String nombreProceso = null;
		String nombreArchivo = null;
		
		//Si el documento está observado entonces hay que insertar la operación: LEVANTA_OBSERVACION
		//Si el documento no está observado pero ya tiene firma digital entonces hay que insertar la operación SECUENCIA
		//Si el documento no tiene firma digital la operación es NUEVO
		
		String codSecuenciaFirma = FirmaConstantes.OPERACION_NUEVO;
		
		T7074DocumentoFirm paramSearch = new T7074DocumentoFirm();
		paramSearch.setCodTipdoc(tipDocumento);
		paramSearch.setNumDocumento(numDocumento);
		paramSearch.setIndEstdoc(ViaticoConstantes.ACTIVO);
		List<T7074DocumentoFirm> documentos = consultaFirmaService.recuperarDocumentosFirmados(paramSearch);
		
		String codEstadoDeclaracion = null;
		
		int iddoc = new Integer(0);
		
		/*DdjjMovilidadLocalBean declaracion = null;*/
		 
		PlanViajeBean planViaje = null;
		if(ViaticoConstantes.TIPO_DOCUMENTO_PLANILLA.equals(tipDocumento)){
			
			planViaje = consultaSolicitudService.buscarPlanViajePlanilla(numDocumento);
			
			//Revisamos si se puede firmar en esta dependencia...
			if("R".equals(tipProceso)){
				Map<String,String> resultado = consultaSolicitudService.obtenerUUOOAutorizadora(planViaje.getCodigoDependencia(), planViaje.getCodTrabajador(), "V");
				String codEjecucion = (String)resultado.get("codEjecucion");
				log.info("Código de error uuoo autoriza:"+codEjecucion);
				log.info("Mensaje de error:"+((String)resultado.get("codDependenciaAutoriza")));
				if(!"00".equals(codEjecucion)){
					String mensajeErrorUUOOAutoriza = (String)resultado.get("codDependenciaAutoriza");
					respuesta.put("errorFirma", mensajeErrorUUOOAutoriza); 
					return respuesta;
				}	
			}
			
			params = viaticoReporteService.generarReporteSolicitudViatico(planViaje.getCodPlanViaje(), viaticosProcesoSingleton.obtenerProceso());
			
			boolean esNacional = StringUtils.equals(planViaje.getTipoDestino(), ViaticoConstantes.TIPO_COMISION_NACIONAL);
			if(esNacional)iddoc = ViaticoConstantes.ID_PLANTILLA_VIATICO_NACIONAL;
			else iddoc = ViaticoConstantes.ID_PLANTILLA_VIATICO_INTERNACIONAL;
			
			nombreProceso = "REGISTRO VIÁTICO";
			nombreArchivo = "VIA_"+numDocumento;
			
		}else if(ViaticoConstantes.TIPO_DOCUMENTO_RENDICION.equals(tipDocumento)){
			
			planViaje = consultaSolicitudService.buscarPlanViajePlanilla(numDocumento);
			
			//TODO: Validamos si la planilla pasará por la revisión previa de una OSA
			
			if(ViaticoConstantes.CANAL_ATENCION_REEMBOLSO.equals(planViaje.getIndicadorRuta())){
				//Si se trata de un abono en cuenta...
				Map<String,String> resultValidaOSA = consultaSolicitudService.validarRevisionPreviaOSA(planViaje.getCodPlanViaje());
				String codEjecucion = (String)resultValidaOSA.get("codEjecucion");
				String codOSA = (String)resultValidaOSA.get("codOSA");
				String codEstado = (String)resultValidaOSA.get("codEstado");
				log.info("Código de ejecución:"+codEjecucion);
				log.info("Código de OSA:"+codOSA);
				log.info("Código de estado:"+codEstado);
				
				if(!RendicionConstantes.CODIGO_EJECUCION_DERIVA_OSA_OK.equals(codEjecucion)){
					respuesta.put("errorFirma", codEjecucion+"-"+codOSA);//mensaje de error. 
					return respuesta;
				}	
			}
			
			params = viaticoReporteService.generarReporteRendicionViatico(planViaje.getCodPlanViaje(), viaticosProcesoSingleton.obtenerProceso());
			iddoc = ViaticoConstantes.ID_PLANTILLA_VIATICO_RENDICION;
			nombreProceso = "REGISTRO RENDICIÓN";
			nombreArchivo = "RDC_"+numDocumento;
			
		}else if(ViaticoConstantes.TIPO_DOCUMENTO_DECLARACION_RENDICION.equals(tipDocumento)){
			
			planViaje = consultaSolicitudService.buscarPlanViajePlanilla(numDocumento);
			params = viaticoReporteService.generarReporteRendicionDeclaracion(planViaje.getCodPlanViaje(), viaticosProcesoSingleton.obtenerProceso());
			iddoc = ViaticoConstantes.ID_PLANTILLA_VIATICO_DECLARACION_JURADA;
			nombreProceso = "DECLARACIÓN RENDICIÓN";
			nombreArchivo = "DCL_"+numDocumento;
		}
		
		
		
		boolean documentoObservado = false;
		
		log.info("Firmando....Procesando documento:["+tipDocumento+","+numDocumento+"] para la accion:"+tipProceso);
		
		if(!CollectionUtils.isEmpty(documentos)){
			
			//El documento firmado ya existe.
			codSecuenciaFirma = FirmaConstantes.OPERACION_SECUENCIA;
			log.info("Firmando....,El documento ya existe, aplicando la operación de secuencia:"+codSecuenciaFirma);
			if(ViaticoConstantes.TIPO_DOCUMENTO_PLANILLA.equals(tipDocumento)){
				
				log.info("Firmando....,El documento de declaración jurada ya existe, el estado de la declaración es :["+planViaje.getEstadoPlanViaje()+"]");
				
				if(ViaticoConstantes.ESTADO_VIATICO_OBSERVADO.equals(planViaje.getEstadoPlanViaje()) ||
						ViaticoConstantes.ESTADO_VIATICO_OBSERVADO_CAJA_CHICA.equals(planViaje.getEstadoPlanViaje()) ||
						ViaticoConstantes.ESTADO_VIATICO_OBSERVADO_FINANCIERA.equals(planViaje.getEstadoPlanViaje())){
					log.info("Firmando....,documento observado.");
					documentoObservado = true;
				}
				
			}
			
			
			if(documentoObservado){
				codSecuenciaFirma = FirmaConstantes.OPERACION_LEVANTA_OBSERVACION;	
				log.info("Firmando....,El documento ya existe, aplicando la operación de secuencia por observación:"+codSecuenciaFirma);
			}
			
		}
		

		//Seteamos los datos del confirmador y autorizador en el documento pdf
		//if("C".equals(tipProceso))setConfirmadorDeclaracion(request, params);
		if("A".equals(tipProceso))setAutorizadorSolicitud(request, params,planViaje);	
		if("C".equals(tipProceso))setFirmadorRendicion(request, params);
		if("R".equals(tipProceso)){
			//Si se trata de un registro no debe de mostrarse al autorizador, este caso solo aplica cuando se ha devuelto..
			Map<String, Object> parametros = params.getParametros();
			parametros.put("P_nombreAutorizador", null);
			
			//Sobreescribimos los datos de la fecha
			Date fechaHoy = new Date();
			parametros.put("P_diaFechaComisionado", ViaticoUtil.formatDateToDateDDMMYYYY(fechaHoy));
			parametros.put("P_horaFechaComisionado", ViaticoUtil.formatDateToHourHHMM(fechaHoy));
		}
		
		//TODO: reemplazar 5E2303 por MovilidadConstantes.CODIGO_DEPENDENCIA_NORMATIVA_MOVILIDAD
		log.debug("Identificador de documento jasper a utilizar:"+iddoc);
		Map<String, Object> resultado = validarFirmaService.validarLdapGenerarGrabarDocumentoFirmado(iddoc, nombreArchivo, 
				params.getParametros(), params.getListaDetalle(), usuarioBean.getLogin(), txtPasswordUsuario, codSecuenciaFirma, 
				persona.getCodigoEmpleado(),tipDocumento, numDocumento, persona.getCodigoDependencia(), ViaticoConstantes.CODIGO_DEPENDENCIA_NORMATIVA_VIATICOS, 
				"27", nombreProceso, usuarioBean.getLogin(), request.getRemoteAddr(), usuarioBean.getLogin(), request.getRemoteAddr());
		
		//Aquí recuperamos el identificador del archivo para almacenar la referencia en el SIGA.
		T7074DocumentoFirm paramSearch2 = new T7074DocumentoFirm();
		paramSearch2.setCodTipdoc(tipDocumento);
		paramSearch2.setNumDocumento(numDocumento);
		paramSearch2.setIndEstdoc(ViaticoConstantes.ACTIVO);
		List<T7074DocumentoFirm> documentos2 = consultaFirmaService.recuperarDocumentosFirmados(paramSearch2);
		
		
		
		
		if(!CollectionUtils.isEmpty(documentos2)){
			T7074DocumentoFirm documento = documentos2.get(0);
			String numArchivo = generarArchivoFisico(usuarioBean.getLogin(),nombreArchivo,tipDocumento,numDocumento,documento,planViaje.getNumeroRegistroArchivo());
			log.debug("Número de registro archivo retornado al front:"+numArchivo);
			respuesta.put("numArchivo",numArchivo);
		}
		
		
		String errorFirma = (String)resultado.get("error");
		log.info("Código de error de la firma:"+errorFirma+", tipo de documento:"+tipDocumento);
		respuesta.put("errorFirma", errorFirma); 
		return respuesta;
	}
	
	
	private String generarArchivoFisico(String codUsuario,String nombreArchivo, String tipDocumento, 
			String numDocumento, T7074DocumentoFirm documento, String numeroRegistroArchivoPV){
		
		log.debug("Número de registro archivo antes de firmar el documento:"+numeroRegistroArchivoPV);
		
		String fuente = null;
		if(ViaticoConstantes.TIPO_DOCUMENTO_PLANILLA.equals(tipDocumento)){
			fuente = "PLANILLA DE VIÁTICOS";
		}else if(ViaticoConstantes.TIPO_DOCUMENTO_RENDICION.equals(tipDocumento)){
			fuente = "RENDICIÓN DE PLANILLA";
		}else if(ViaticoConstantes.TIPO_DOCUMENTO_DECLARACION_RENDICION.equals(tipDocumento)){
			fuente = "DECLARACIÓN DE RENDICIÓN";
		}
		
		RegistroArchivosFisicoBean archivoFisico = new RegistroArchivosFisicoBean();
		archivoFisico.setDescrip_reg(fuente+"-"+numDocumento);
		archivoFisico.setFile_ext("PDF");
		archivoFisico.setFile_name(documento.getNomArchivo());
		archivoFisico.setFuente_reg(fuente);
		archivoFisico.setNom_object(documento.getNomArchivo());
		archivoFisico.setCodDocAut(documento.getCodDocaut());
		archivoFisico.setNumDocumento(numDocumento);
		archivoFisico.setNomModulo("VIÁTICOS");
		archivoFisico.setCodUsuRegis(codUsuario);
		
		return registroArchivosService.registrarArchivoFirmado(archivoFisico,numeroRegistroArchivoPV);
	}
	
	
	
	public ModelAndView validarFirmaPassword(HttpServletRequest request,
			HttpServletResponse response) {

		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		respuesta.put("firmaValidaYGrabada", false);
		ModelAndView viewPage = null;

		String numDocumento =  request.getParameter("variableImprimirSendPost");
		String txtPasswordUsuario = request.getParameter("txtPasswordUsuario");
		String tipDocumento = request.getParameter("tipDocumento");
		String tipProceso = request.getParameter("tipProceso");
		String tipoConfirmacion = request.getParameter("tipoConfirmacion");//Si el tipo de confirmacion es M:Masiva, I:Individual
		String listaDocumentos = request.getParameter("listaDocumentos");

		try {
			
			String error = null;
			MaestroPersonalBean persona = registroPersonalService.obtenerPersonaxRegistro(usuarioBean.getNroRegistro());

			List<Map<String,Object>> archivos = null;
			if(tipoConfirmacion!=null && "M".equals(tipoConfirmacion)){
				//Masiva
				String[] documentos = listaDocumentos.split(",");
				archivos = new ArrayList<Map<String,Object>>();
				for(String documento:documentos){
					HashMap<String,String> resultado = firmarDocumento(request, tipDocumento, documento,
							tipProceso, txtPasswordUsuario, usuarioBean, persona);
					
					error = resultado.get("errorFirma") ;
					if(error!=null && !"0".equals(error)){
						break;
					}
					Map<String,Object> firmaMap = new HashMap<String,Object>();
					String numArchivo = resultado.get("numArchivo") ;
					firmaMap.put("numDocumento", documento);//Mapeo numero de documento numero de archivo
					firmaMap.put("numArchivo", numArchivo);//Mapeo numero de documento numero de archivo
					archivos.add(firmaMap);
				}
				
			}else{
				
				//Individual
				HashMap<String,String> resultado = firmarDocumento(request, tipDocumento, numDocumento,
						tipProceso, txtPasswordUsuario, usuarioBean, persona);
				error = resultado.get("errorFirma") ;
				
				//si no hay error en la firma del documento de rendición entonces generamos la firma del documento de declaración
				if(error!=null && "0".equals(error)){
					//Si se trata de una rendición generamos tambien una declaracion...
					if(ViaticoConstantes.TIPO_DOCUMENTO_RENDICION.equals(tipDocumento)){
						
						//Aquí solo generamos la firma de la declaración sí y solo sí la rendición posee al menos un documento del tipo declaración jurada de viáticos...
						PlanViajeBean planViaje = consultaSolicitudService.buscarPlanViajePlanilla(numDocumento);
						List<PlanViajeRendicionBean> planes = viaticoConsultaService.obtenerListadoDocumentosPlanViaje(planViaje.getCodPlanViaje());
						boolean generarDeclaracion = false;
						for(PlanViajeRendicionBean plan:planes){
							if(ViaticoConstantes.TIPO_DOCUMENTO_DECLARACION_VIATICO.equals(plan.getTipoDocumento())){
								generarDeclaracion = true;
								break;
							}
						}
						log.info("Se debe de generar la declaración:"+generarDeclaracion);
						if(generarDeclaracion){
							log.info("Generando declaración...");
							HashMap<String,String> resultado2 = firmarDocumento(request, ViaticoConstantes.TIPO_DOCUMENTO_DECLARACION_RENDICION, numDocumento,
									tipProceso, txtPasswordUsuario, usuarioBean, persona);
							error = resultado2.get("errorFirma") ;		
						}else{
							//Verificar si ya existe una declaración previa.
							
							T7074DocumentoFirm paramSearchFirma = new T7074DocumentoFirm();
							paramSearchFirma.setCodTipdoc(ViaticoConstantes.TIPO_DOCUMENTO_DECLARACION_RENDICION);
							paramSearchFirma.setNumDocumento(numDocumento);
							paramSearchFirma.setIndEstdoc(ViaticoConstantes.ACTIVO);
							List<T7074DocumentoFirm> documentosDdjj = consultaFirmaService.recuperarDocumentosFirmados(paramSearchFirma);
							if(!CollectionUtils.isEmpty(documentosDdjj)){
								//Si existe la firma de la declaración jurada entonces hay que anularla.
								T7074DocumentoFirm documentoFirmado = documentosDdjj.get(0);
								String nomArchivo = "DCL_"+planViaje.getCodPlanilla();//Se trata de una declaración
								this.registroSolicitudService.anularFirmaDocumento(documentoFirmado.getCodDocaut().longValue(), planViaje.getNumeroRegistroArchivo(), nomArchivo);
							}
							
						}
						
					}
					
					String numArchivo = resultado.get("numArchivo") ;
					respuesta.put("numArchivo", numArchivo);//Solo para interface con presupuesto.	
				}
				
			}
			
			if(error!=null && "0".equals(error)){
				respuesta.put("firmaValidaYGrabada", true);
				respuesta.put("archivos", archivos);
			}else{
				respuesta.put("firmaValidaYGrabada", false);
			}
			
			viewPage = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}

		return viewPage;
	}
	
	
	@SuppressWarnings({ "unchecked" })
	private void setAutorizadorSolicitud(HttpServletRequest request, ReporteJasperBean params, PlanViajeBean planViaje) throws Exception{
		Map<String, Object> parametros = params.getParametros();
		
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		MaestroPersonalBean maestroAutorizador =registroPersonalService.obtenerPersonaxRegistro(usuarioBean.getNroRegistro());
		
		ColaboradorViaticoBean autorizador = MaestroPersonalUtil.parseViatico(maestroAutorizador);
		
		String UUOO = ViaticoConstantes.CADENA_VACIA;
		
		DependenciaBean dependencia = registroDependenciasService.obtenerDependenciaXcod(planViaje.getCodigoDepAutor());
		
		if (StringUtils.isNotEmpty(planViaje.getCodigoDepAutor())) {
			UUOO = dependencia.getUuoo() + " - " + dependencia.getNom_largo();
		}
		log.info("Dependencia del autorizador:"+UUOO+", código de la dependencia a buscar:"+planViaje.getCodigoDepAutor());
		
		parametros.put("P_nombreAutorizador", autorizador.getNombreCompleto());
		parametros.put("P_numeroRegistroAutorizador", autorizador.getNumeroRegistro());
		parametros.put("P_uuooAutorizador", UUOO);
		
		NivelBean nivel = viaticoReporteService.getNivel(autorizador.getCodigoNivel());
		
		parametros.put("P_cargoAutorizador","<SN>");
		if (nivel != null) {
			if (StringUtils.isNotEmpty(nivel.getDescripcionNivel())) parametros.put("P_cargoAutorizador", nivel.getDescripcionNivel());
		}
		
		Date fechaHoy = new Date();
		
		parametros.put("P_diaFechaAutorizador", ViaticoUtil.formatDateToDateDDMMYYYY(fechaHoy));
		parametros.put("P_horaFechaAutorizador", ViaticoUtil.formatDateToHourHHMM(fechaHoy));

	}
	
	
	@SuppressWarnings("unchecked")
	private void setFirmadorRendicion(HttpServletRequest request, ReporteJasperBean params) throws Exception{
		Map<String, Object> parametros = params.getParametros();
		
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		MaestroPersonalBean maestroAutorizador =registroPersonalService.obtenerPersonaxRegistro(usuarioBean.getNroRegistro());
		
		ColaboradorViaticoBean colaborador = MaestroPersonalUtil.parseViatico(maestroAutorizador);
		
		NivelBean nivel = viaticoReporteService.getNivel(colaborador.getCodigoNivel());
		
		parametros.put("cargoComisionado","<SN>");
		if (nivel != null) {
			if (StringUtils.isNotEmpty(nivel.getDescripcionNivel())) parametros.put("cargoComisionado", nivel.getDescripcionNivel());
		}
		
		Date fechaHoy = new Date();
		parametros.put("fechaComisionado", ViaticoUtil.formatDateToDateDDMMYYYYHHMM(fechaHoy));

	}
	
	
	
	public void descargarPdfFirmado(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		String tipDocumento = request.getParameter("tipDocumento");
		String numDocumento = request.getParameter("numDocumento");
		
		BufferedOutputStream bos = new BufferedOutputStream(response.getOutputStream());
		
		try {
			
			T5282Archbin binario = consultaFirmaService.recuperarDocumentoPdfFirmadoVigente(tipDocumento, numDocumento);
			
			response.setContentType("application/octet-stream");
			response.setHeader("Content-Disposition", "attachment; filename=" + binario.getDesNombreAlternativo()+".PDF");
			
			ByteArrayInputStream bais = new ByteArrayInputStream(binario.getArcDatos());
			for (int b = 0; (b = bais.read()) != -1;)
				bos.write(b);
			bais.close();
			bos.flush();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			bos.close();
		}
	}

	

	public ValidarFirmarService getValidarFirmaService() {
		return validarFirmaService;
	}

	public void setValidarFirmaService(ValidarFirmarService validarFirmaService) {
		this.validarFirmaService = validarFirmaService;
	}

	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(
			RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}

	public ValidadorLdapServiceImpl getValidadorLdapServiceImpl() {
		return validadorLdapServiceImpl;
	}

	public void setValidadorLdapServiceImpl(
			ValidadorLdapServiceImpl validadorLdapServiceImpl) {
		this.validadorLdapServiceImpl = validadorLdapServiceImpl;
	}

	public RegistroArchivosService getRegistroArchivosService() {
		return registroArchivosService;
	}

	public void setRegistroArchivosService(
			RegistroArchivosService registroArchivosService) {
		this.registroArchivosService = registroArchivosService;
	}

	public ViaticoReporteService getViaticoReporteService() {
		return viaticoReporteService;
	}

	public void setViaticoReporteService(ViaticoReporteService viaticoReporteService) {
		this.viaticoReporteService = viaticoReporteService;
	}

	public ConsultaSolicitudService getConsultaSolicitudService() {
		return consultaSolicitudService;
	}

	public void setConsultaSolicitudService(
			ConsultaSolicitudService consultaSolicitudService) {
		this.consultaSolicitudService = consultaSolicitudService;
	}

	public ViaticosProcesoSingleton getViaticosProcesoSingleton() {
		return viaticosProcesoSingleton;
	}

	public void setViaticosProcesoSingleton(
			ViaticosProcesoSingleton viaticosProcesoSingleton) {
		this.viaticosProcesoSingleton = viaticosProcesoSingleton;
	}

	public RegistroDependenciasService getRegistroDependenciasService() {
		return registroDependenciasService;
	}

	public void setRegistroDependenciasService(
			RegistroDependenciasService registroDependenciasService) {
		this.registroDependenciasService = registroDependenciasService;
	}

	public ViaticoConsultaService getViaticoConsultaService() {
		return viaticoConsultaService;
	}

	public void setViaticoConsultaService(
			ViaticoConsultaService viaticoConsultaService) {
		this.viaticoConsultaService = viaticoConsultaService;
	}

	public RegistroSolicitudService getRegistroSolicitudService() {
		return registroSolicitudService;
	}

	public void setRegistroSolicitudService(
			RegistroSolicitudService registroSolicitudService) {
		this.registroSolicitudService = registroSolicitudService;
	}

}
