package pe.gob.sunat.recurso2.financiera.siga.viatico.web.view;

import java.io.Serializable;
import java.util.ArrayList;

import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.SysEstadosBean;
import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.T01ParametroBean;
import pe.gob.sunat.recurso2.administracion.siga.util.Anio;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ComprobanteIngresoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PapeletaDepositoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeConceptoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeInformeDistribBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeRendicionBean;

public class RendicionVO implements Serializable {

	private static final long serialVersionUID = 518016712744337580L;
	private String codigoPlanViaje;
	private String codigoPlanilla;
	private String codigoEstadoRendicion;
	private String descripcionEstadoRendicion;
	private String tipoDestino;
	private String expedientePlanViaje;
	private String expedienteRendicion;
	private String fechaRegistroRendicion;
	private String fechaSalidaProgramada;
	private String fechaRetornoProgramada;
	private String fechaSalidaEjecutada;
	private String fechaRetornoEjecutada;
	
	//JMCR-ME Hora < 4 Rendicion
	private String horaSalidaProgramada;
	private String horaRetornoProgramada;
	private String horaSalidaEjecutada;
	private String horaRetornoEjecutada;
	//JMCR-ME Hora < 4 Rendicion
	
	private String indicadorExteriorDDJJ;
	private String moneda;
	private String montoRendirTotal;
	private String montoComprobanteTotal;
	private String montoDeclaracionTotal;
	private String montoDeclaracionViatico;
	private String montoDepositoTotal;
	private String montoRICTotal;
	private String montoDevolver;
	private String montoDevueltoComprobanteTotal;
	private String montoDevueltoVoucherRICTotal;
	private String montoRendirTotalFormateado;
	private String montoComprobanteTotalFormateado;
	private String montoDeclaracionTotalFormateado;
	private String montoDeclaracionViaticoFormateado;
	private String montoDepositoTotalFormateado;
	private String montoRICTotalFormateado;
	private String montoDevolverFormateado;
	private String codigoCanalAtencion;
	private String canalAtencion;
	private String fechaMaximaRendicion;
	private String numeroRegistroColaborador;
	private String codigoColaborador;
	private String nombreColaborador;
	private String codigoEstadoColaborador;
	private String descripcionEstadoColaborador;
	private String uuoo;
	private String codigoDependencia;
	private String descripcionDependencia;
	private String numeroRegistroRegistrador;
	private String codigoRegistrador;
	private String codigoSedeRegistrador;
	private String nombreRegistrador;
	private String anioPresupuesto;
	private String metaPresupuesto;
	private String indicadorMenorGasto;
	private String anioActual;
	private String flagAsociadoRIC;
	private String flagMenorIgual4Horas;
	private String flagFechaHoraSalidaValida;
	private String flagFechaHoraRetornoValida;
	private String flagRegistrador;
	private String flagRegistradorUniversal;
	private String flagMayor1UUOOAsociada;
	private String flagDeclaracion;
	private String flagHabilitarCerrarRendicion;
	private String flagCVRHabilitarCerrarRendicion;
	private String flagMostrarImprimir;
	private String flagBuscarColaborador;
	private String flagBuscarUUOO;
	private int numeroDeclaracionViatico;
	private String procesoViatico;

	private ArrayList<PlanViajeRendicionBean> planViajeRendicionList;
	private ArrayList<PlanViajeInformeDistribBean> asignacionViaticoList;
	private ArrayList<PlanViajeInformeDistribBean> pasajeTasaEmbarqueList;
	private ArrayList<PapeletaDepositoBean> papeletaDepositoList;
	private ArrayList<PlanViajeConceptoBean> planViajeConceptoList;
	private ArrayList<ComprobanteIngresoBean> comprobanteIngresoList;
	private ArrayList<SysEstadosBean> estadoRendicionList;
	private ArrayList<T01ParametroBean> canalAtencionList;
	private ArrayList<Anio> anioList;
	
	
	private boolean esRegistrador = false;

	public String getCodigoPlanViaje() {
		return codigoPlanViaje;
	}

	public void setCodigoPlanViaje(String codigoPlanViaje) {
		this.codigoPlanViaje = codigoPlanViaje;
	}

	public String getCodigoPlanilla() {
		return codigoPlanilla;
	}

	public void setCodigoPlanilla(String codigoPlanilla) {
		this.codigoPlanilla = codigoPlanilla;
	}

	public String getCodigoEstadoRendicion() {
		return codigoEstadoRendicion;
	}

	public void setCodigoEstadoRendicion(String codigoEstadoRendicion) {
		this.codigoEstadoRendicion = codigoEstadoRendicion;
	}

	public String getDescripcionEstadoRendicion() {
		return descripcionEstadoRendicion;
	}

	public void setDescripcionEstadoRendicion(String descripcionEstadoRendicion) {
		this.descripcionEstadoRendicion = descripcionEstadoRendicion;
	}

	public String getTipoDestino() {
		return tipoDestino;
	}

	public void setTipoDestino(String tipoDestino) {
		this.tipoDestino = tipoDestino;
	}

	public String getExpedientePlanViaje() {
		return expedientePlanViaje;
	}

	public void setExpedientePlanViaje(String expedientePlanViaje) {
		this.expedientePlanViaje = expedientePlanViaje;
	}

	public String getExpedienteRendicion() {
		return expedienteRendicion;
	}

	public void setExpedienteRendicion(String expedienteRendicion) {
		this.expedienteRendicion = expedienteRendicion;
	}

	public String getFechaRegistroRendicion() {
		return fechaRegistroRendicion;
	}

	public void setFechaRegistroRendicion(String fechaRegistroRendicion) {
		this.fechaRegistroRendicion = fechaRegistroRendicion;
	}

	public String getFechaSalidaProgramada() {
		return fechaSalidaProgramada;
	}

	public void setFechaSalidaProgramada(String fechaSalidaProgramada) {
		this.fechaSalidaProgramada = fechaSalidaProgramada;
	}

	public String getFechaRetornoProgramada() {
		return fechaRetornoProgramada;
	}

	public void setFechaRetornoProgramada(String fechaRetornoProgramada) {
		this.fechaRetornoProgramada = fechaRetornoProgramada;
	}

	public String getFechaSalidaEjecutada() {
		return fechaSalidaEjecutada;
	}

	public void setFechaSalidaEjecutada(String fechaSalidaEjecutada) {
		this.fechaSalidaEjecutada = fechaSalidaEjecutada;
	}

	public String getFechaRetornoEjecutada() {
		return fechaRetornoEjecutada;
	}

	public void setFechaRetornoEjecutada(String fechaRetornoEjecutada) {
		this.fechaRetornoEjecutada = fechaRetornoEjecutada;
	}

	public String getIndicadorExteriorDDJJ() {
		return indicadorExteriorDDJJ;
	}

	public void setIndicadorExteriorDDJJ(String indicadorExteriorDDJJ) {
		this.indicadorExteriorDDJJ = indicadorExteriorDDJJ;
	}

	public String getMoneda() {
		return moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public String getMontoRendirTotal() {
		return montoRendirTotal;
	}

	public void setMontoRendirTotal(String montoRendirTotal) {
		this.montoRendirTotal = montoRendirTotal;
	}

	public String getMontoComprobanteTotal() {
		return montoComprobanteTotal;
	}

	public void setMontoComprobanteTotal(String montoComprobanteTotal) {
		this.montoComprobanteTotal = montoComprobanteTotal;
	}

	public String getMontoDeclaracionTotal() {
		return montoDeclaracionTotal;
	}

	public void setMontoDeclaracionTotal(String montoDeclaracionTotal) {
		this.montoDeclaracionTotal = montoDeclaracionTotal;
	}

	public String getMontoDeclaracionViatico() {
		return montoDeclaracionViatico;
	}

	public void setMontoDeclaracionViatico(String montoDeclaracionViatico) {
		this.montoDeclaracionViatico = montoDeclaracionViatico;
	}

	public String getMontoDepositoTotal() {
		return montoDepositoTotal;
	}

	public void setMontoDepositoTotal(String montoDepositoTotal) {
		this.montoDepositoTotal = montoDepositoTotal;
	}

	public String getMontoRICTotal() {
		return montoRICTotal;
	}

	public void setMontoRICTotal(String montoRICTotal) {
		this.montoRICTotal = montoRICTotal;
	}

	public String getMontoDevolver() {
		return montoDevolver;
	}

	public void setMontoDevolver(String montoDevolver) {
		this.montoDevolver = montoDevolver;
	}

	public String getMontoDevueltoComprobanteTotal() {
		return montoDevueltoComprobanteTotal;
	}

	public void setMontoDevueltoComprobanteTotal(
			String montoDevueltoComprobanteTotal) {
		this.montoDevueltoComprobanteTotal = montoDevueltoComprobanteTotal;
	}

	public String getMontoDevueltoVoucherRICTotal() {
		return montoDevueltoVoucherRICTotal;
	}

	public void setMontoDevueltoVoucherRICTotal(
			String montoDevueltoVoucherRICTotal) {
		this.montoDevueltoVoucherRICTotal = montoDevueltoVoucherRICTotal;
	}

	public String getMontoRendirTotalFormateado() {
		return montoRendirTotalFormateado;
	}

	public void setMontoRendirTotalFormateado(String montoRendirTotalFormateado) {
		this.montoRendirTotalFormateado = montoRendirTotalFormateado;
	}

	public String getMontoComprobanteTotalFormateado() {
		return montoComprobanteTotalFormateado;
	}

	public void setMontoComprobanteTotalFormateado(
			String montoComprobanteTotalFormateado) {
		this.montoComprobanteTotalFormateado = montoComprobanteTotalFormateado;
	}

	public String getMontoDeclaracionTotalFormateado() {
		return montoDeclaracionTotalFormateado;
	}

	public void setMontoDeclaracionTotalFormateado(
			String montoDeclaracionTotalFormateado) {
		this.montoDeclaracionTotalFormateado = montoDeclaracionTotalFormateado;
	}

	public String getMontoDeclaracionViaticoFormateado() {
		return montoDeclaracionViaticoFormateado;
	}

	public void setMontoDeclaracionViaticoFormateado(
			String montoDeclaracionViaticoFormateado) {
		this.montoDeclaracionViaticoFormateado = montoDeclaracionViaticoFormateado;
	}

	public String getMontoDepositoTotalFormateado() {
		return montoDepositoTotalFormateado;
	}

	public void setMontoDepositoTotalFormateado(
			String montoDepositoTotalFormateado) {
		this.montoDepositoTotalFormateado = montoDepositoTotalFormateado;
	}

	public String getMontoRICTotalFormateado() {
		return montoRICTotalFormateado;
	}

	public void setMontoRICTotalFormateado(String montoRICTotalFormateado) {
		this.montoRICTotalFormateado = montoRICTotalFormateado;
	}

	public String getMontoDevolverFormateado() {
		return montoDevolverFormateado;
	}

	public void setMontoDevolverFormateado(String montoDevolverFormateado) {
		this.montoDevolverFormateado = montoDevolverFormateado;
	}

	public String getCodigoCanalAtencion() {
		return codigoCanalAtencion;
	}

	public void setCodigoCanalAtencion(String codigoCanalAtencion) {
		this.codigoCanalAtencion = codigoCanalAtencion;
	}

	public String getCanalAtencion() {
		return canalAtencion;
	}

	public void setCanalAtencion(String canalAtencion) {
		this.canalAtencion = canalAtencion;
	}

	public String getFechaMaximaRendicion() {
		return fechaMaximaRendicion;
	}

	public void setFechaMaximaRendicion(String fechaMaximaRendicion) {
		this.fechaMaximaRendicion = fechaMaximaRendicion;
	}

	public String getNumeroRegistroColaborador() {
		return numeroRegistroColaborador;
	}

	public void setNumeroRegistroColaborador(String numeroRegistroColaborador) {
		this.numeroRegistroColaborador = numeroRegistroColaborador;
	}

	public String getCodigoColaborador() {
		return codigoColaborador;
	}

	public void setCodigoColaborador(String codigoColaborador) {
		this.codigoColaborador = codigoColaborador;
	}

	public String getNombreColaborador() {
		return nombreColaborador;
	}

	public void setNombreColaborador(String nombreColaborador) {
		this.nombreColaborador = nombreColaborador;
	}

	public String getCodigoEstadoColaborador() {
		return codigoEstadoColaborador;
	}

	public void setCodigoEstadoColaborador(String codigoEstadoColaborador) {
		this.codigoEstadoColaborador = codigoEstadoColaborador;
	}

	public String getDescripcionEstadoColaborador() {
		return descripcionEstadoColaborador;
	}

	public void setDescripcionEstadoColaborador(
			String descripcionEstadoColaborador) {
		this.descripcionEstadoColaborador = descripcionEstadoColaborador;
	}

	public String getUuoo() {
		return uuoo;
	}

	public void setUuoo(String uuoo) {
		this.uuoo = uuoo;
	}

	public String getCodigoDependencia() {
		return codigoDependencia;
	}

	public void setCodigoDependencia(String codigoDependencia) {
		this.codigoDependencia = codigoDependencia;
	}

	public String getDescripcionDependencia() {
		return descripcionDependencia;
	}

	public void setDescripcionDependencia(String descripcionDependencia) {
		this.descripcionDependencia = descripcionDependencia;
	}

	public String getNumeroRegistroRegistrador() {
		return numeroRegistroRegistrador;
	}

	public void setNumeroRegistroRegistrador(String numeroRegistroRegistrador) {
		this.numeroRegistroRegistrador = numeroRegistroRegistrador;
	}

	public String getCodigoRegistrador() {
		return codigoRegistrador;
	}

	public void setCodigoRegistrador(String codigoRegistrador) {
		this.codigoRegistrador = codigoRegistrador;
	}

	public String getCodigoSedeRegistrador() {
		return codigoSedeRegistrador;
	}

	public void setCodigoSedeRegistrador(String codigoSedeRegistrador) {
		this.codigoSedeRegistrador = codigoSedeRegistrador;
	}

	public String getNombreRegistrador() {
		return nombreRegistrador;
	}

	public void setNombreRegistrador(String nombreRegistrador) {
		this.nombreRegistrador = nombreRegistrador;
	}

	public String getAnioPresupuesto() {
		return anioPresupuesto;
	}

	public void setAnioPresupuesto(String anioPresupuesto) {
		this.anioPresupuesto = anioPresupuesto;
	}

	public String getMetaPresupuesto() {
		return metaPresupuesto;
	}

	public void setMetaPresupuesto(String metaPresupuesto) {
		this.metaPresupuesto = metaPresupuesto;
	}

	public String getIndicadorMenorGasto() {
		return indicadorMenorGasto;
	}

	public void setIndicadorMenorGasto(String indicadorMenorGasto) {
		this.indicadorMenorGasto = indicadorMenorGasto;
	}

	public String getAnioActual() {
		return anioActual;
	}

	public void setAnioActual(String anioActual) {
		this.anioActual = anioActual;
	}

	public String getFlagAsociadoRIC() {
		return flagAsociadoRIC;
	}

	public void setFlagAsociadoRIC(String flagAsociadoRIC) {
		this.flagAsociadoRIC = flagAsociadoRIC;
	}

	public String getFlagMenorIgual4Horas() {
		return flagMenorIgual4Horas;
	}

	public void setFlagMenorIgual4Horas(String flagMenorIgual4Horas) {
		this.flagMenorIgual4Horas = flagMenorIgual4Horas;
	}

	public String getFlagFechaHoraSalidaValida() {
		return flagFechaHoraSalidaValida;
	}

	public void setFlagFechaHoraSalidaValida(String flagFechaHoraSalidaValida) {
		this.flagFechaHoraSalidaValida = flagFechaHoraSalidaValida;
	}

	public String getFlagFechaHoraRetornoValida() {
		return flagFechaHoraRetornoValida;
	}

	public void setFlagFechaHoraRetornoValida(String flagFechaHoraRetornoValida) {
		this.flagFechaHoraRetornoValida = flagFechaHoraRetornoValida;
	}

	public String getFlagRegistrador() {
		return flagRegistrador;
	}

	public void setFlagRegistrador(String flagRegistrador) {
		this.flagRegistrador = flagRegistrador;
	}

	public String getFlagRegistradorUniversal() {
		return flagRegistradorUniversal;
	}

	public void setFlagRegistradorUniversal(String flagRegistradorUniversal) {
		this.flagRegistradorUniversal = flagRegistradorUniversal;
	}

	public String getFlagMayor1UUOOAsociada() {
		return flagMayor1UUOOAsociada;
	}

	public void setFlagMayor1UUOOAsociada(String flagMayor1UUOOAsociada) {
		this.flagMayor1UUOOAsociada = flagMayor1UUOOAsociada;
	}

	public String getFlagDeclaracion() {
		return flagDeclaracion;
	}

	public void setFlagDeclaracion(String flagDeclaracion) {
		this.flagDeclaracion = flagDeclaracion;
	}

	public String getFlagHabilitarCerrarRendicion() {
		return flagHabilitarCerrarRendicion;
	}

	public void setFlagHabilitarCerrarRendicion(
			String flagHabilitarCerrarRendicion) {
		this.flagHabilitarCerrarRendicion = flagHabilitarCerrarRendicion;
	}

	public String getFlagCVRHabilitarCerrarRendicion() {
		return flagCVRHabilitarCerrarRendicion;
	}

	public void setFlagCVRHabilitarCerrarRendicion(
			String flagCVRHabilitarCerrarRendicion) {
		this.flagCVRHabilitarCerrarRendicion = flagCVRHabilitarCerrarRendicion;
	}

	public String getFlagMostrarImprimir() {
		return flagMostrarImprimir;
	}

	public void setFlagMostrarImprimir(String flagMostrarImprimir) {
		this.flagMostrarImprimir = flagMostrarImprimir;
	}

	public String getFlagBuscarColaborador() {
		return flagBuscarColaborador;
	}

	public void setFlagBuscarColaborador(String flagBuscarColaborador) {
		this.flagBuscarColaborador = flagBuscarColaborador;
	}

	public String getFlagBuscarUUOO() {
		return flagBuscarUUOO;
	}

	public void setFlagBuscarUUOO(String flagBuscarUUOO) {
		this.flagBuscarUUOO = flagBuscarUUOO;
	}

	public int getNumeroDeclaracionViatico() {
		return numeroDeclaracionViatico;
	}

	public void setNumeroDeclaracionViatico(int numeroDeclaracionViatico) {
		this.numeroDeclaracionViatico = numeroDeclaracionViatico;
	}

	public String getProcesoViatico() {
		return procesoViatico;
	}

	public void setProcesoViatico(String procesoViatico) {
		this.procesoViatico = procesoViatico;
	}

	public ArrayList<PlanViajeRendicionBean> getPlanViajeRendicionList() {
		return planViajeRendicionList;
	}

	public void setPlanViajeRendicionList(
			ArrayList<PlanViajeRendicionBean> planViajeRendicionList) {
		this.planViajeRendicionList = planViajeRendicionList;
	}

	public ArrayList<PlanViajeInformeDistribBean> getAsignacionViaticoList() {
		return asignacionViaticoList;
	}

	public void setAsignacionViaticoList(
			ArrayList<PlanViajeInformeDistribBean> asignacionViaticoList) {
		this.asignacionViaticoList = asignacionViaticoList;
	}

	public ArrayList<PlanViajeInformeDistribBean> getPasajeTasaEmbarqueList() {
		return pasajeTasaEmbarqueList;
	}

	public void setPasajeTasaEmbarqueList(
			ArrayList<PlanViajeInformeDistribBean> pasajeTasaEmbarqueList) {
		this.pasajeTasaEmbarqueList = pasajeTasaEmbarqueList;
	}

	public ArrayList<PapeletaDepositoBean> getPapeletaDepositoList() {
		return papeletaDepositoList;
	}

	public void setPapeletaDepositoList(
			ArrayList<PapeletaDepositoBean> papeletaDepositoList) {
		this.papeletaDepositoList = papeletaDepositoList;
	}

	public ArrayList<PlanViajeConceptoBean> getPlanViajeConceptoList() {
		return planViajeConceptoList;
	}

	public void setPlanViajeConceptoList(
			ArrayList<PlanViajeConceptoBean> planViajeConceptoList) {
		this.planViajeConceptoList = planViajeConceptoList;
	}

	public ArrayList<ComprobanteIngresoBean> getComprobanteIngresoList() {
		return comprobanteIngresoList;
	}

	public void setComprobanteIngresoList(
			ArrayList<ComprobanteIngresoBean> comprobanteIngresoList) {
		this.comprobanteIngresoList = comprobanteIngresoList;
	}

	public ArrayList<SysEstadosBean> getEstadoRendicionList() {
		return estadoRendicionList;
	}

	public void setEstadoRendicionList(
			ArrayList<SysEstadosBean> estadoRendicionList) {
		this.estadoRendicionList = estadoRendicionList;
	}

	public ArrayList<T01ParametroBean> getCanalAtencionList() {
		return canalAtencionList;
	}

	public void setCanalAtencionList(
			ArrayList<T01ParametroBean> canalAtencionList) {
		this.canalAtencionList = canalAtencionList;
	}

	public ArrayList<Anio> getAnioList() {
		return anioList;
	}

	public void setAnioList(ArrayList<Anio> anioList) {
		this.anioList = anioList;
	}

	public boolean isEsRegistrador() {
		return esRegistrador;
	}

	public void setEsRegistrador(boolean esRegistrador) {
		this.esRegistrador = esRegistrador;
	}

	//JMCR-ME Hora < 4 Rendicion
	public String getHoraSalidaProgramada() {
		return horaSalidaProgramada;
	}

	public void setHoraSalidaProgramada(String horaSalidaProgramada) {
		this.horaSalidaProgramada = horaSalidaProgramada;
	}

	public String getHoraRetornoProgramada() {
		return horaRetornoProgramada;
	}

	public void setHoraRetornoProgramada(String horaRetornoProgramada) {
		this.horaRetornoProgramada = horaRetornoProgramada;
	}

	public String getHoraSalidaEjecutada() {
		return horaSalidaEjecutada;
	}

	public void setHoraSalidaEjecutada(String horaSalidaEjecutada) {
		this.horaSalidaEjecutada = horaSalidaEjecutada;
	}

	public String getHoraRetornoEjecutada() {
		return horaRetornoEjecutada;
	}

	public void setHoraRetornoEjecutada(String horaRetornoEjecutada) {
		this.horaRetornoEjecutada = horaRetornoEjecutada;
	}
	//JMCR-ME Hora < 4 Rendicion
}
