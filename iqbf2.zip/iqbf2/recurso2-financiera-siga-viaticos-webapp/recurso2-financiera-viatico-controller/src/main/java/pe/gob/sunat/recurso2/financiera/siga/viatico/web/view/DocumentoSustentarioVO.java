package pe.gob.sunat.recurso2.financiera.siga.viatico.web.view;

import java.util.List;

import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.T01ParametroBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeConceptoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeInformeDistribBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeRendicionBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.TipoDocumentoBean;

public class DocumentoSustentarioVO {

	private List<PlanViajeRendicionBean> listaPlanViajeRendicion;
	private List<T01ParametroBean> listaExoneracion;
	private String moneda;
	private boolean estadoDocumentoSustentario;
	private String mensajeRepuesta;
	private PlanViajeBean planViajeBean;
	private List<PlanViajeInformeDistribBean> listaPlanViajeInformeDitrib;
	private Double igv;
	private boolean estadoDDJJ;
	private Double montoTotalRendicion;
	private List<TipoDocumentoBean> tipoDocumentoList;
	private List<PlanViajeConceptoBean> planViajeConceptoList;
	private String porcentajeDeclaracion;
	
	public List<PlanViajeRendicionBean> getListaPlanViajeRendicion() {
		return listaPlanViajeRendicion;
	}
	public void setListaPlanViajeRendicion(
			List<PlanViajeRendicionBean> listaPlanViajeRendicion) {
		this.listaPlanViajeRendicion = listaPlanViajeRendicion;
	}
	public String getMoneda() {
		return moneda;
	}
	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}
	public boolean isEstadoDocumentoSustentario() {
		return estadoDocumentoSustentario;
	}
	public void setEstadoDocumentoSustentario(boolean estadoDocumentoSustentario) {
		this.estadoDocumentoSustentario = estadoDocumentoSustentario;
	}
	public String getMensajeRepuesta() {
		return mensajeRepuesta;
	}
	public void setMensajeRepuesta(String mensajeRepuesta) {
		this.mensajeRepuesta = mensajeRepuesta;
	}
	public void setListaExoneracion(List<T01ParametroBean> listaExoneracion) {
		this.listaExoneracion = listaExoneracion;
	}
	public List<T01ParametroBean> getListaExoneracion() {
		return listaExoneracion;
	}
	public void setPlanViajeBean(PlanViajeBean planViajeBean) {
		this.planViajeBean = planViajeBean;
	}
	public PlanViajeBean getPlanViajeBean() {
		return planViajeBean;
	}
	public void setListaPlanViajeInformeDitrib(
			List<PlanViajeInformeDistribBean> listaPlanViajeInformeDitrib) {
		this.listaPlanViajeInformeDitrib = listaPlanViajeInformeDitrib;
	}
	public List<PlanViajeInformeDistribBean> getListaPlanViajeInformeDitrib() {
		return listaPlanViajeInformeDitrib;
	}
	public void setIgv(Double igv) {
		this.igv = igv;
	}
	public Double getIgv() {
		return igv;
	}
	public void setEstadoDDJJ(boolean estadoDDJJ) {
		this.estadoDDJJ = estadoDDJJ;
	}
	public boolean isEstadoDDJJ() {
		return estadoDDJJ;
	}
	public void setMontoTotalRendicion(Double montoTotalRendicion) {
		this.montoTotalRendicion = montoTotalRendicion;
	}
	public Double getMontoTotalRendicion() {
		return montoTotalRendicion;
	}
	public void setTipoDocumentoList(List<TipoDocumentoBean> tipoDocumentoList) {
		this.tipoDocumentoList = tipoDocumentoList;
	}
	public List<TipoDocumentoBean> getTipoDocumentoList() {
		return tipoDocumentoList;
	}
	public List<PlanViajeConceptoBean> getPlanViajeConceptoList() {
		return planViajeConceptoList;
	}
	public void setPlanViajeConceptoList(
			List<PlanViajeConceptoBean> planViajeConceptoList) {
		this.planViajeConceptoList = planViajeConceptoList;
	}
	/**
	 * @param porcentajeDeclaracion the porcentajeDeclaracion to set
	 */
	public void setPorcentajeDeclaracion(String porcentajeDeclaracion) {
		this.porcentajeDeclaracion = porcentajeDeclaracion;
	}
	/**
	 * @return the porcentajeDeclaracion
	 */
	public String getPorcentajeDeclaracion() {
		return porcentajeDeclaracion;
	}
	
	
}
