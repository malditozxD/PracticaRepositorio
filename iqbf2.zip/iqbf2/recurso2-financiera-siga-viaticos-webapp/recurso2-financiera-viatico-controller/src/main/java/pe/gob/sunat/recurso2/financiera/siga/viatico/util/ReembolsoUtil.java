package pe.gob.sunat.recurso2.financiera.siga.viatico.util;

import java.util.ArrayList;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.web.servlet.ModelAndView;

import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.administracion.siga.util.Anio;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.view.ReembolsoVO;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

/**
 * Esta clase permite realizar operaciones comunes sobre solicitudes de reembolso
 * 
 * @author Jorge Ponce
 */
public class ReembolsoUtil {
	
	/**
	 * Metodo que permite armar un objeto de vista ReembolsoVO a partir del UsuarioBean de session y el MaestroPersonalBean de base de datos.
	 * 
	 * @author Jorge Ponce
	 * @param usuarioBean bean de session
	 * @param maestroPersonalBean bean maestro persona
	 * @return el objeto ModelAndView con la constantesMap de la peticion
	 * @see ModelAndView
	 */
	public static ReembolsoVO obtenerReembolsoVO(UsuarioBean usuarioBean, MaestroPersonalBean maestroPersonalBean) {
		
		ReembolsoVO reembolsoVO = null;
		if (usuarioBean != null && maestroPersonalBean != null) {
			reembolsoVO = new ReembolsoVO();
			
			//Datos del colaborador
			reembolsoVO.setNumeroRegistro(usuarioBean.getNroRegistro());
			reembolsoVO.setNumeroRegistroColaborador(usuarioBean.getNroRegistro());
			reembolsoVO.setCodigoColaborador(maestroPersonalBean.getCodigoEmpleado());
			reembolsoVO.setNombreColaborador(StringUtils.trimToEmpty(maestroPersonalBean.getNombre_completo()));
			reembolsoVO.setCodigoEstadoColaborador(maestroPersonalBean.getCodigoEstado());
			reembolsoVO.setEstadoColaborador(maestroPersonalBean.getEstado());
			reembolsoVO.setDescripcionEstadoColaborador(maestroPersonalBean.getEstado());

			//Datos del registrador
			reembolsoVO.setNumeroRegistroRegistrador(usuarioBean.getNroRegistro());
			reembolsoVO.setCodigoRegistrador(maestroPersonalBean.getCodigoEmpleado());
			reembolsoVO.setCodigoSedeRegistrador(maestroPersonalBean.getCodigoSede());
			reembolsoVO.setNombreRegistrador(StringUtils.trimToEmpty(maestroPersonalBean.getNombre_completo()));

			//Datos del autorizador
			reembolsoVO.setNumeroRegistroAutorizador(usuarioBean.getNroRegistro());
			reembolsoVO.setCodigoAutorizador(maestroPersonalBean.getCodigoEmpleado());
			reembolsoVO.setCodigoDependenciaAutorizador(maestroPersonalBean.getCodigoDependencia());
			reembolsoVO.setCodigoSedeAutorizador(maestroPersonalBean.getCodigoSede());
			reembolsoVO.setCodigoNivelAutorizador(maestroPersonalBean.getCodigoNivel());
			reembolsoVO.setNombreAutorizador(StringUtils.trimToEmpty(maestroPersonalBean.getNombre_completo()));

			//Datos de la uuoo
			reembolsoVO.setUuoo(maestroPersonalBean.getUuoo());
			reembolsoVO.setCodigoDependencia(maestroPersonalBean.getCodigoDependencia());
			reembolsoVO.setDescripcionDependencia(maestroPersonalBean.getDependencia());
		}
		return reembolsoVO;
	}
	
	/**
	 * Metodo que permite armar la lista de objetos Anio a visualizar en las bandejas de reembolso
	 * 
	 * @author Jorge Ponce
	 * @param anioActual a�o actual
	 * @return lista de objetos a�os
	 * @see Anio
	 */	
	public static ArrayList<Anio> obtenerAniosReembolso(int anioActual) {

		ArrayList<Anio> anioList = new ArrayList<Anio>();
		int anioInicial = anioActual - 5;
		for (int i = anioInicial; i < anioActual + 1; i++) {
			Anio anio = new Anio();
			anio.setCodigoAnio(Integer.toString(i));
			anio.setDescripcionAnio(Integer.toString(i));
			anioList.add(anio);
		}
		return anioList;
	}
	
	/**
	 * Metodo que permite setear las constantes usadas para el registro/modificacion de una solicitud de reembolso.
	 * 
	 * @author Juan Farro
	 * @param constantesMap mapa con las constantes
	 */
	public static void poblarConstantesParaRegistro(Map<String, Object> constantesMap) {

		if (constantesMap == null) return;

		constantesMap.put("RUTA_TIPO_TARIFA_OTROS", ViaticoConstantes.RUTA_TIPO_TARIFA_OTROS);
		constantesMap.put("RUTA_TIPO_TARIFA_GENERAL", ViaticoConstantes.RUTA_TIPO_TARIFA_GENERAL);
		constantesMap.put("MEDIO_TRANSPORTE_AEREO", ViaticoConstantes.MEDIO_TRANSPORTE_AEREO);
		constantesMap.put("MEDIO_TRANSPORTE_TERRESTRE", ViaticoConstantes.MEDIO_TRANSPORTE_TERRESTRE);
		constantesMap.put("MONEDA_SOLES", ViaticoConstantes.MONEDA_SOLES);
		constantesMap.put("MONEDA_DOLARES", ViaticoConstantes.MONEDA_DOLARES);
		constantesMap.put("MAXIMO_NRO_DIAS_HABILES", ViaticoConstantes.MAXIMO_NRO_DIAS_HABILES);
		constantesMap.put("CANAL_ATENCION_CAJA_CHICA", ViaticoConstantes.CANAL_ATENCION_CAJACHICA);
		constantesMap.put("CANAL_ATENCION_CAJA_CHICA_DESCRIP", ViaticoConstantes.CANAL_ATENCION_CAJACHICA_DESCRIP);
		constantesMap.put("CANAL_ATENCION_REEMBOLSO", ViaticoConstantes.CANAL_ATENCION_REEMBOLSO);
		constantesMap.put("CANAL_ATENCION_REEMBOLSO_DESCRIP", ViaticoConstantes.CANAL_ATENCION_REEMBOLSO_DESCRIP);
		constantesMap.put("CANAL_ATENCION_NUMERO_DIAS_TOPE", ViaticoConstantes.CANAL_ATENCION_NUMERO_DIAS_TOPE);
		constantesMap.put("CONFIGURACION_MANUAL", ViaticoConstantes.TIPO_CONFIGURACION_MANUAL);
		constantesMap.put("CONFIGURACION_AUTOMATICA", ViaticoConstantes.TIPO_CONFIGURACION_AUTOMATICA);
		constantesMap.put("TARIFARIO_NACIONAL", ViaticoConstantes.TIPO_TARIFARIO_NACIONAL);
		constantesMap.put("TARIFARIO_REGIONAL", ViaticoConstantes.TIPO_TARIFARIO_REGIONAL);
		constantesMap.put("MOTIVO_AMPLIACION_AMPLIACION_COMISION", ViaticoConstantes.MOTIVO_AMPLIACION_AMPLIACION_COMISION);
		constantesMap.put("MOTIVO_AMPLIACION_VIATICO_NO_COBRADO", ViaticoConstantes.MOTIVO_AMPLIACION_VIATICO_NO_COBRADO);
		constantesMap.put("MOTIVO_AMPLIACION_OTROS", ViaticoConstantes.MOTIVO_AMPLIACION_OTROS);
		constantesMap.put("SI", ViaticoConstantes.SI);
		constantesMap.put("NO", ViaticoConstantes.NO);
	}
	
	/**
	 * Metodo que permite determinar si se puede enviar una solicitud de reembolso en función de su codigo de estado.
	 * 
	 * @author Juan Farro
	 * @param estadoSolicitud estado de la solicitud de reembolso
	 * @return si puede enviar o no
	 */
	public static boolean puedeEnviarSolicitudReembolso(String estadoSolicitud) {

		// si esta en alguno de estos estados puede enviar
		if (StringUtils.equals(estadoSolicitud, ViaticoConstantes.ESTADO_REEMBOLSO_ELABORADO) || 
				StringUtils.equals(estadoSolicitud, ViaticoConstantes.ESTADO_REEMBOLSO_OBSERVADO) || 
				StringUtils.equals(estadoSolicitud, ViaticoConstantes.ESTADO_VIATICO_OBSERVADO_FINANCIERA)) {

			return true;
		}

		return false;
	}
	
	/**
	 * Metodo que permite determinar si se puede enviar una solicitud de reembolso en función de su codigo de estado.
	 * 
	 * @author Juan Farro
	 * @param estadoSolicitud estado de la solicitud de reembolso
	 * @return si puede modificar o no
	 */
	public static boolean puedeModificarSolicitudReembolso(String estadoSolicitud) {

		// si esta en alguno de estos estados puede enviar
		if (StringUtils.equals(estadoSolicitud, ViaticoConstantes.ESTADO_REEMBOLSO_ELABORADO) || 
				StringUtils.equals(estadoSolicitud, ViaticoConstantes.ESTADO_REEMBOLSO_OBSERVADO) || 
				StringUtils.equals(estadoSolicitud, ViaticoConstantes.ESTADO_VIATICO_OBSERVADO_FINANCIERA)) {

			return true;
		}

		return false;
	}
	
	/**
	 * Metodo que permite setear las constantes estados de viatico
	 * 
	 * @author Samuel Dionisio
	 * @param constantesMap mapa con las constantes
	 */
	public static void poblarConstantesEstadosReembolso(Map<String, Object> constantesMap) {

		if (constantesMap == null) return;

		constantesMap.put("ESTADO_REEMBOLSO_ELABORADO", ViaticoConstantes.ESTADO_REEMBOLSO_ELABORADO);
		constantesMap.put("ESTADO_REEMBOLSO_ANULADO", ViaticoConstantes.ESTADO_REEMBOLSO_ANULADO);
		constantesMap.put("ESTADO_REEMBOLSO_POR_AUTORIZAR", ViaticoConstantes.ESTADO_REEMBOLSO_POR_AUTORIZAR);
		constantesMap.put("ESTADO_REEMBOLSO_AUTORIZADO", ViaticoConstantes.ESTADO_REEMBOLSO_AUTORIZADO);
		constantesMap.put("ESTADO_REEMBOLSO_OBSERVADO", ViaticoConstantes.ESTADO_REEMBOLSO_OBSERVADO);
		//constantesMap.put("ESTADO_REEMBOLSO_OBSERVADO_CAJA_CHICA", ViaticoConstantes.ESTADO_VIATICO_OBSERVADO_CAJA_CHICA);
		constantesMap.put("ESTADO_REEMBOLSO_OBSERVADO_FINANCIERA", ViaticoConstantes.ESTADO_REEMBOLSO_OBSERVADO_FINANCIERA);
		constantesMap.put("ESTADO_REEMBOLSO_ANULACION_AUTOMATICA", ViaticoConstantes.ESTADO_REEMBOLSO_ANULACION_AUTOMATICA);
		constantesMap.put("ESTADO_REEMBOLSO_PAGADO", ViaticoConstantes.ESTADO_REEMBOLSO_PAGADO);
	 
	}
	
}
