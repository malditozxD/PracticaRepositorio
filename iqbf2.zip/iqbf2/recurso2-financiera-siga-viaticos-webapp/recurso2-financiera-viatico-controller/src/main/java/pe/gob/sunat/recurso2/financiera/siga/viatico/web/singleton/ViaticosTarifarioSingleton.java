package pe.gob.sunat.recurso2.financiera.siga.viatico.web.singleton;

public interface ViaticosTarifarioSingleton {

	public String obtenerTarifario();
}
