package pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.web.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;

import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoProcesoService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ResourceBundleUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.SolicitudConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.controller.BaseController;

public class ViaticoProcesoController extends BaseController{

	
	protected final Log log = LogFactory.getLog(getClass());

	/** Declaración del servicio validacionViaticoService. */

	private ViaticoProcesoService viaticoProcesoService;


	public ViaticoProcesoService getViaticoProcesoService() {
		return viaticoProcesoService;
	}

	public void setViaticoProcesoService(ViaticoProcesoService viaticoProcesoService) {
		this.viaticoProcesoService = viaticoProcesoService;
	}
	
	public ModelAndView iniViatico(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = null;
		String errorMessage = StringUtils.EMPTY;
		Map<String, Object> respuesta = new HashMap<String, Object>();

			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(SolicitudConstantes.VALIDACION_VIATICO_PAGE, respuesta);

		return modelAndView;
	}
	
	public ModelAndView iniValidacionPendienteViatico(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = null;
		boolean customMessage = false;
		String errorMessage = StringUtils.EMPTY;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {
			viaticoProcesoService.obtenerListaEstadosSolicitudPendienteViatico();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO);
		} finally {
			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(SolicitudConstantes.VALIDACION_VIATICO_PAGE, respuesta);
		}

		return modelAndView;
	}
	
	public ModelAndView iniValidacionDiasAdicional(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = null;
		boolean customMessage = false;
		String errorMessage = StringUtils.EMPTY;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {
			viaticoProcesoService.obtenerListaViaticoDiasAdicional();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO);
		} finally {
			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(SolicitudConstantes.VALIDACION_VIATICO_PAGE, respuesta);
		}

		return modelAndView;
	}
	
	public ModelAndView iniValidacionPlazoExcedido(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = null;
		boolean customMessage = false;
		String errorMessage = StringUtils.EMPTY;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {
			viaticoProcesoService.obtenerListaViaticoPlazoExcedido();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO);
		} finally {
			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(SolicitudConstantes.VALIDACION_VIATICO_PAGE, respuesta);
		}

		return modelAndView;
	}
	
	public ModelAndView iniValidacionPlazoExcedidoGlobal(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = null;
		boolean customMessage = false;
		String errorMessage = StringUtils.EMPTY;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {
			viaticoProcesoService.obtenerListaViaticoPlazoExcedidoGlobal();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO);
		} finally {
			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(SolicitudConstantes.VALIDACION_VIATICO_PAGE, respuesta);
		}

		return modelAndView;
	}	
	
}
