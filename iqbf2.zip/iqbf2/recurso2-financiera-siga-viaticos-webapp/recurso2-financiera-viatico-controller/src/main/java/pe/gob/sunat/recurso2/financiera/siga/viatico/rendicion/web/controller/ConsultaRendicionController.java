package pe.gob.sunat.recurso2.financiera.siga.viatico.rendicion.web.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.SysEstadosBean;
import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.T01ParametroBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroGeneralService;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.administracion.siga.util.Anio;
import pe.gob.sunat.recurso2.administracion.siga.util.FechaConstantes;
import pe.gob.sunat.recurso2.administracion.siga.util.FechaUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.FormatoConstantes;
import pe.gob.sunat.recurso2.administracion.siga.util.FormatoUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.NumeroUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ComprobanteIngresoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.rendicion.service.ConsultaRendicionService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoConsultaService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoGeneralService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoReporteService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.RendicionConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.RendicionUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ResourceBundleUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.controller.BaseController;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.singleton.ViaticosProcesoSingleton;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.view.RendicionVO;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

/**
 * Controller que contiene los metodos necesarios para consultar una rendicion.
 * @author Jorge Ponce.
 */
public class ConsultaRendicionController extends BaseController {
	
	protected final Log log = LogFactory.getLog(getClass());
	private ConsultaRendicionService consultaRendicionService;
	private ViaticoGeneralService viaticoGeneralService;
	private ViaticoConsultaService viaticoConsultaService;
	private ViaticoReporteService viaticoReporteService;
	private RegistroPersonalService registroPersonalService;
	private RegistroGeneralService registroGeneralService;
	private ViaticosProcesoSingleton viaticosProcesoSingleton;
	
	public ConsultaRendicionService getConsultaRendicionService() {
		return consultaRendicionService;
	}

	public void setConsultaRendicionService(ConsultaRendicionService consultaRendicionService) {
		this.consultaRendicionService = consultaRendicionService;
	}

	public ViaticoGeneralService getViaticoGeneralService() {
		return viaticoGeneralService;
	}

	public void setViaticoGeneralService(ViaticoGeneralService viaticoGeneralService) {
		this.viaticoGeneralService = viaticoGeneralService;
	}

	public ViaticoConsultaService getViaticoConsultaService() {
		return viaticoConsultaService;
	}

	public void setViaticoConsultaService(ViaticoConsultaService viaticoConsultaService) {
		this.viaticoConsultaService = viaticoConsultaService;
	}

	public ViaticoReporteService getViaticoReporteService() {
		return viaticoReporteService;
	}

	public void setViaticoReporteService(ViaticoReporteService viaticoReporteService) {
		this.viaticoReporteService = viaticoReporteService;
	}

	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}

	public RegistroGeneralService getRegistroGeneralService() {
		return registroGeneralService;
	}

	public void setRegistroGeneralService(RegistroGeneralService registroGeneralService) {
		this.registroGeneralService = registroGeneralService;
	}

	public ViaticosProcesoSingleton getViaticosProcesoSingleton() {
		return viaticosProcesoSingleton;
	}

	public void setViaticosProcesoSingleton(ViaticosProcesoSingleton viaticosProcesoSingleton) {
		this.viaticosProcesoSingleton = viaticosProcesoSingleton;
	}

	/**
	 * Metodo que permite mostrar la pagina de consultar rendicion.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView.
	 * @see ModelAndView
	 */
	public ModelAndView mostrarConsultarRendicion(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView modelAndView = null;
		String errorMessage = RendicionConstantes.CADENA_VACIA;
		
		try {
			log.debug(RegistroRendicionController.class.getSimpleName() + ".mostrarConsultarRendicion");
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			String numeroRegistro = usuarioBean.getNroRegistro();
			MaestroPersonalBean maestroPersonalBean = registroPersonalService.obtenerPersonaxRegistro(numeroRegistro);
			RendicionVO rendicionVO = RendicionUtil.obtenerRendicionVO(usuarioBean, maestroPersonalBean);
			if (rendicionVO != null) {
				String requestValue =  request.getParameter("variableSendPost");
				String codPlanViaje = FormatoUtil.obtenerValueParameterRequest(requestValue, "codPlanViaje");
				String codigoPaginaCaller = FormatoUtil.obtenerValueParameterRequest(requestValue, "codigoPaginaCaller");
				codPlanViaje = FormatoUtil.validarEmptyToNull(codPlanViaje);
				codigoPaginaCaller = FormatoUtil.validarEmptyToNull(codigoPaginaCaller);
				if (codPlanViaje != null) {
					PlanViajeBean planViajeBean = consultaRendicionService.obtenerPlanViaje(codPlanViaje);
					if (planViajeBean != null) {
						String codigoPlanViaje = planViajeBean.getCodPlanViaje();
						rendicionVO.setCodigoPlanViaje(codigoPlanViaje);
						rendicionVO.setCodigoPlanilla(planViajeBean.getCodPlanilla());
						rendicionVO.setCodigoColaborador(planViajeBean.getCodTrabajador());
						rendicionVO.setNumeroRegistroColaborador(planViajeBean.getNumeroRegistroAlterno());
						rendicionVO.setNombreColaborador(planViajeBean.getNomColaborador());
						rendicionVO.setCodigoEstadoRendicion(planViajeBean.getCodEstadoRend());
						rendicionVO.setDescripcionEstadoRendicion(planViajeBean.getNomEstRend());
						rendicionVO.setTipoDestino(planViajeBean.getTipoDestino());
						rendicionVO.setFechaRegistroRendicion(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFechaRegistroRendicion()));
						rendicionVO.setFechaSalidaProgramada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecSalida()));
						rendicionVO.setFechaRetornoProgramada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecRetorno()));
						rendicionVO.setFechaSalidaEjecutada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecSalidaEjecutada()));
						rendicionVO.setFechaRetornoEjecutada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecRetornoEjecutada()));

						//JMCR-ME Hora < 4 Rendicion
						rendicionVO.setHoraSalidaProgramada(formatDateToHourHHMM(planViajeBean.getFecSalida()));
						rendicionVO.setHoraRetornoProgramada(formatDateToHourHHMM(planViajeBean.getFecRetorno()));
						rendicionVO.setHoraSalidaEjecutada(formatDateToHourHHMM(planViajeBean.getFecSalidaEjecutada()));
						rendicionVO.setHoraRetornoEjecutada(formatDateToHourHHMM(planViajeBean.getFecRetornoEjecutada()));
						//JMCR-ME Hora < 4 Rendicion
						
						rendicionVO.setMoneda(planViajeBean.getMoneda());
						rendicionVO.setMontoRendirTotal(planViajeBean.getMtoTotal());
						rendicionVO.setMontoRendirTotalFormateado(NumeroUtil.formatearMonedaMontoToDecimal(planViajeBean.getMoneda(), 2, planViajeBean.getMtoTotal()));
						rendicionVO.setCodigoCanalAtencion(planViajeBean.getIndicadorCanalAtencion());
						rendicionVO.setCanalAtencion(planViajeBean.getCanalAtencion());
						rendicionVO.setFechaMaximaRendicion(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecMaxRend()));
						rendicionVO.setIndicadorExteriorDDJJ(planViajeBean.getIndicadorExteriorDDJJ());
						rendicionVO.setIndicadorMenorGasto(planViajeBean.getIndicadorMenorGasto());
						rendicionVO.setFlagMenorIgual4Horas(viaticoConsultaService.obtenerFlagMenorIgual4Horas(planViajeBean.getIndicadorHoras(), planViajeBean.getNumeroHoras()));
						
						ArrayList<ComprobanteIngresoBean> comprobanteIngresoList = null;
						if (codigoPlanViaje != null && !RendicionConstantes.CADENA_VACIA.equals(codigoPlanViaje)) {
							//comprobanteIngresoList = consultaRendicionService.obtenerRecibosIngresoCaja("020201500235");
							comprobanteIngresoList = consultaRendicionService.obtenerRecibosIngresoCaja(codigoPlanViaje);
							if (comprobanteIngresoList != null && !comprobanteIngresoList.isEmpty()) {
								rendicionVO.setFlagAsociadoRIC(RendicionConstantes.UNO);
							}
							else {
								rendicionVO.setFlagAsociadoRIC(RendicionConstantes.CERO);
							}
						}
						
						if (RendicionConstantes.PAGE_CALLER_BANDEJA_RENDICION_REVISION.equals(codigoPaginaCaller) || RendicionConstantes.PAGE_CALLER_BANDEJA_RENDICION_NOTIFICACION.equals(codigoPaginaCaller)) {
							rendicionVO.setFlagMostrarImprimir(RendicionConstantes.UNO);
						}
						else if (RendicionConstantes.PAGE_CALLER_BANDEJA_RENDICION_CONSULTA.equals(codigoPaginaCaller)) {
							/*String codigoEmpleado = maestroPersonalBean.getCodigoEmpleado();
							Long numeroRegistros = viaticoGeneralService.determinarRegistradorUniversal(codigoEmpleado);
							String flagRegistradorUniversal = ViaticoUtil.obtenerFlagRegistradorUniversal(numeroRegistros);
							String procesoViatico = viaticosProcesoSingleton.obtenerProceso();
							if (RendicionConstantes.UNO.equals(flagRegistradorUniversal) && RendicionConstantes.PROCESO_AUTOMATICO.equals(procesoViatico)) {
								rendicionVO.setFlagMostrarImprimir(RendicionConstantes.UNO);
							}*/
							rendicionVO.setFlagMostrarImprimir(RendicionConstantes.UNO);
						}
					}
				}
			}
			respuesta.put("rendicionVO", rendicionVO);
			log.debug(RegistroRendicionController.class.getSimpleName() + ".mostrarConsultarRendicion.fin");
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			errorMessage = ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO);
		}
		respuesta.put("errorMessage", errorMessage);
		modelAndView = new ModelAndView(RendicionConstantes.CONSULTAR_RENDICION_VIATICO_PAGE, respuesta);
		return modelAndView;
	}

	private String formatDateToHourHHMM(Date date) {
		String formatDate = FormatoConstantes.CADENA_VACIA;
		if (date != null) {
			SimpleDateFormat sdf = new SimpleDateFormat(FechaConstantes.DATE_FORMAT_HHMM, Locale.getDefault());
			formatDate = sdf.format(date);
		}
		return formatDate;
	}
	
	/**
	 * Metodo que permite mostrar la bandeja rendicion consulta.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView.
	 * @see ModelAndView
	 */
	@SuppressWarnings("unchecked")
	public ModelAndView mostrarBandejaRendicionConsulta(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView modelAndView = null;
		String errorMessage = RendicionConstantes.CADENA_VACIA;
		
		try {
			log.debug(RegistroRendicionController.class.getSimpleName() + ".mostrarBandejaRendicionConsulta");
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			String numeroRegistro = usuarioBean.getNroRegistro();
			MaestroPersonalBean maestroPersonalBean = registroPersonalService.obtenerPersonaxRegistro(numeroRegistro);
			RendicionVO rendicionVO = RendicionUtil.obtenerRendicionVO(usuarioBean, maestroPersonalBean);
			if (rendicionVO != null) {
				String codigoEmpleado = maestroPersonalBean.getCodigoEmpleado();
				Map<String, Object> paramSearch = new HashMap<String, Object>();
				paramSearch.put("nom_tabla", RendicionConstantes.NOMTABLA_ESTADOS_RENDICION);
				ArrayList<SysEstadosBean> estadoRendicionList = (ArrayList<SysEstadosBean>) registroGeneralService.listarEstados(paramSearch);
				rendicionVO.setEstadoRendicionList(estadoRendicionList);
				paramSearch.clear();
				
				paramSearch.put("cod_par", RendicionConstantes.PARAMETRO_CANAL_ATENCION);
				paramSearch.put("cod_tipo", RendicionConstantes.TIPO_CANAL_ATENCION);
				ArrayList<T01ParametroBean> canalAtencionList = (ArrayList<T01ParametroBean>) registroGeneralService.recuperarParametroLista(paramSearch);
				rendicionVO.setCanalAtencionList(canalAtencionList);
				
				ArrayList<Anio> anioList = RendicionUtil.obtenerAniosRendicion(Integer.parseInt(FechaUtil.obtenerAnioActual()));
				rendicionVO.setAnioList(anioList);
				rendicionVO.setAnioActual(FechaUtil.obtenerAnioActual());
				
				Long numeroRegistros = viaticoGeneralService.determinarRegistrador(codigoEmpleado);
				String flagRegistrador = ViaticoUtil.obtenerFlagRegistrador(numeroRegistros);
				String flagMayor1UUOOAsociada = ViaticoUtil.obtenerFlagMayor1UUOOAsociada(numeroRegistros);
				numeroRegistros = viaticoGeneralService.determinarRegistradorUniversal(codigoEmpleado);
				String flagRegistradorUniversal = ViaticoUtil.obtenerFlagRegistradorUniversal(numeroRegistros);
				rendicionVO.setFlagRegistrador(flagRegistrador);
				rendicionVO.setFlagRegistradorUniversal(flagRegistradorUniversal);
				rendicionVO.setFlagMayor1UUOOAsociada(flagMayor1UUOOAsociada);
				rendicionVO.setFlagBuscarColaborador(ViaticoUtil.obtenerFlagBuscarColaborador(flagRegistradorUniversal, flagRegistrador));
				rendicionVO.setFlagBuscarUUOO(ViaticoUtil.obtenerFlagBuscarUUOO(flagRegistradorUniversal, flagRegistrador));
			}
			respuesta.put("rendicionVO", rendicionVO);
			log.debug(RegistroRendicionController.class.getSimpleName() + ".mostrarBandejaRendicionConsulta.fin");
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			errorMessage = ResourceBundleUtil.getMessage(RendicionConstantes.MENSAJE_ERROR_GENERICO);
		}
		respuesta.put("errorMessage", errorMessage);
		modelAndView = new ModelAndView(RendicionConstantes.CONSULTAR_RENDICION_BANDEJA_VIATICO_PAGE, respuesta);
		return modelAndView;
	}
	
	/**
	 * Metodo que permite mostrar la bandeja rendicion revision.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView.
	 * @see ModelAndView
	 */
	@SuppressWarnings("unchecked")
	public ModelAndView mostrarBandejaRendicionRevision(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView modelAndView = null;
		String errorMessage = RendicionConstantes.CADENA_VACIA;
		
		try {
			log.debug(RegistroRendicionController.class.getSimpleName() + ".mostrarBandejaRendicionRevision");
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			String numeroRegistro = usuarioBean.getNroRegistro();
			MaestroPersonalBean maestroPersonalBean = registroPersonalService.obtenerPersonaxRegistro(numeroRegistro);
			RendicionVO rendicionVO = RendicionUtil.obtenerRendicionVO(usuarioBean, maestroPersonalBean);
			if (rendicionVO != null) {
				String codigoEmpleado = maestroPersonalBean.getCodigoEmpleado();
				Map<String, Object> paramSearch = new HashMap<String, Object>();
				paramSearch.put("nom_tabla", RendicionConstantes.NOMTABLA_ESTADOS_RENDICION);
				ArrayList<SysEstadosBean> estadoRendicionList = (ArrayList<SysEstadosBean>) registroGeneralService.listarEstados(paramSearch);
				rendicionVO.setEstadoRendicionList(estadoRendicionList);
				paramSearch.clear();
				
				paramSearch.put("cod_par", RendicionConstantes.PARAMETRO_CANAL_ATENCION);
				paramSearch.put("cod_tipo", RendicionConstantes.TIPO_CANAL_ATENCION);
				ArrayList<T01ParametroBean> canalAtencionList = (ArrayList<T01ParametroBean>) registroGeneralService.recuperarParametroLista(paramSearch);
				rendicionVO.setCanalAtencionList(canalAtencionList);
				
				ArrayList<Anio> anioList = RendicionUtil.obtenerAniosRendicion(Integer.parseInt(FechaUtil.obtenerAnioActual()));
				rendicionVO.setAnioList(anioList);
				rendicionVO.setAnioActual(FechaUtil.obtenerAnioActual());
				
				Long numeroRegistros = viaticoGeneralService.determinarRegistrador(codigoEmpleado);
				String flagRegistrador = ViaticoUtil.obtenerFlagRegistrador(numeroRegistros);
				String flagMayor1UUOOAsociada = ViaticoUtil.obtenerFlagMayor1UUOOAsociada(numeroRegistros);
				numeroRegistros = viaticoGeneralService.determinarRegistradorUniversal(codigoEmpleado);
				String flagRegistradorUniversal = ViaticoUtil.obtenerFlagRegistradorUniversal(numeroRegistros);
				rendicionVO.setFlagRegistrador(flagRegistrador);
				rendicionVO.setFlagRegistradorUniversal(flagRegistradorUniversal);
				rendicionVO.setFlagMayor1UUOOAsociada(flagMayor1UUOOAsociada);
				rendicionVO.setFlagBuscarColaborador(ViaticoUtil.obtenerFlagBuscarColaborador(flagRegistradorUniversal, flagRegistrador));
				rendicionVO.setFlagBuscarUUOO(ViaticoUtil.obtenerFlagBuscarUUOO(flagRegistradorUniversal, flagRegistrador));
			}
			respuesta.put("rendicionVO", rendicionVO);
			log.debug(RegistroRendicionController.class.getSimpleName() + ".mostrarBandejaRendicionRevision.fin");
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			errorMessage = ResourceBundleUtil.getMessage(RendicionConstantes.MENSAJE_ERROR_GENERICO);
		}
		respuesta.put("errorMessage", errorMessage);
		modelAndView = new ModelAndView(RendicionConstantes.REVISAR_RENDICION_BANDEJA_VIATICO_PAGE, respuesta);
		return modelAndView;
	}
	
	/**
	 * Metodo que permite obtener/buscar las planillas.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	public ModelAndView buscarPlanillasBandeja(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoConsulta = RendicionConstantes.ERROR_CONSULTA;
		String errorMessage = RendicionConstantes.CADENA_VACIA;
		boolean flagExistePlanilla = true;
		
		try {
			log.debug(ConsultaRendicionController.class.getSimpleName() + ".buscarPlanillasBandeja");
			String codigoDependencia = request.getParameter("codigoDependencia");
			String codPlanilla = request.getParameter("codPlanilla");
			String codTrabajador = request.getParameter("codTrabajador");
			String codEstadoRend = request.getParameter("codEstadoRend");
			String indicadorCanalAtencion = request.getParameter("indicadorCanalAtencion");
			String fechaDesdeString = request.getParameter("fechaDesde");
			String fechaHastaString = request.getParameter("fechaHasta");
			Date fechaDesde = null;
			Date fechaHasta = null;
			
			codigoDependencia = FormatoUtil.validarEmptyToNull(codigoDependencia);
			codPlanilla = FormatoUtil.validarEmptyToNull(codPlanilla);
			codTrabajador = FormatoUtil.validarEmptyToNull(codTrabajador);
			if (RendicionConstantes.CADENA_VACIA.equals(codEstadoRend) || RendicionConstantes.CODIGO_00.equals(codEstadoRend)) {
				codEstadoRend = null;
			}
			
			if (RendicionConstantes.CADENA_VACIA.equals(indicadorCanalAtencion) || RendicionConstantes.CODIGO_00.equals(indicadorCanalAtencion)) {
				indicadorCanalAtencion = null;
			}
			
			if (!RendicionConstantes.CADENA_VACIA.equals(fechaDesdeString)) {
				fechaDesde = FechaUtil.parseStringDateToDate(fechaDesdeString, RendicionConstantes.DATE_FORMAT_DDMMYYYY);
			}
			
			if (!RendicionConstantes.CADENA_VACIA.equals(fechaHastaString)) {
				fechaHasta = FechaUtil.parseStringDateToDate(fechaHastaString, RendicionConstantes.DATE_FORMAT_DDMMYYYY);
			}
			
			if (codPlanilla != null) {
				flagExistePlanilla = viaticoConsultaService.existePlanilla(codPlanilla);
				codigoConsulta = RendicionConstantes.ERROR_CONSULTA_NO_EXISTE_PLANILLA;
				errorMessage = ResourceBundleUtil.getMessage(RendicionConstantes.MENSAJE_ERROR_PLANILLA_NO_EXISTE);
			}
			
			if (flagExistePlanilla) {
				ArrayList<PlanViajeBean> planViajeList = consultaRendicionService.obtenerPlanViajeToBandejaConsultaRendicion(codigoDependencia, codPlanilla, codTrabajador, codEstadoRend, indicadorCanalAtencion, fechaDesde, fechaHasta);
				codigoConsulta = RendicionConstantes.EXITO_CONSULTA;
				respuesta.put("planViajeList", planViajeList);
			}
			log.debug(ConsultaRendicionController.class.getSimpleName() + ".buscarPlanillasBandeja.fin");
			
		} catch (Exception e) {
			errorMessage = ResourceBundleUtil.getMessage(RendicionConstantes.MENSAJE_ERROR_GENERICO);
			log.error(e.getMessage(), e);
		}
		
		respuesta.put("codigoConsulta", codigoConsulta);
		respuesta.put("errorMessage", errorMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	/**
	 * Metodo que permite obtener plan viaje con su detalle.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	public ModelAndView obtenerPlanViajeDetalle(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoConsulta = RendicionConstantes.ERROR_CONSULTA;
		String errorMessage = RendicionConstantes.CADENA_VACIA;
		
		try {
			log.debug(ConsultaRendicionController.class.getSimpleName() + ".obtenerPlanViajeDetalle");
			String codPlanViaje = request.getParameter("codPlanViaje");
			codPlanViaje = FormatoUtil.validarEmptyToNull(codPlanViaje);
			ArrayList<PlanViajeBean> planViajeList = consultaRendicionService.obtenerPlanViajeDetalleToBandejaConsultaRendicion(codPlanViaje, null, null, null, null, null, null, null);
			if (planViajeList != null && !planViajeList.isEmpty()) {
				PlanViajeBean planViajeBean = planViajeList.get(0);
				codigoConsulta = RendicionConstantes.EXITO_CONSULTA;
				respuesta.put("planViajeBean", planViajeBean);
			}
			log.debug(ConsultaRendicionController.class.getSimpleName() + ".obtenerPlanViajeDetalle.fin");
			
		} catch (Exception e) {
			errorMessage = ResourceBundleUtil.getMessage(RendicionConstantes.MENSAJE_ERROR_GENERICO);
			log.error(e.getMessage(), e);
		}
		
		respuesta.put("codigoConsulta", codigoConsulta);
		respuesta.put("errorMessage", errorMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	/**
	 * Metodo que permite exportar excel de la bandeja rendicion.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (Excel).
	 * @see ModelAndView
	 */
	public ModelAndView exportarExcelBandejaRendicion(HttpServletRequest request, HttpServletResponse response) {
		
		ModelAndView viewPage = null;
		
		try {
			log.debug(ConsultaRendicionController.class.getSimpleName() + ".exportarExcelBandejaConsultaRendicion");
			String codigoDependencia = request.getParameter("codigoDependencia");
			String codPlanilla = request.getParameter("codPlanilla");
			String codTrabajador = request.getParameter("codTrabajador");
			String codEstadoRend = request.getParameter("codEstadoRend");
			String indicadorCanalAtencion = request.getParameter("indicadorCanalAtencion");
			String fechaDesdeString = request.getParameter("fechaDesde");
			String fechaHastaString = request.getParameter("fechaHasta");
			String codigoPaginaCaller = request.getParameter("codigoPaginaCaller");
			Date fechaDesde = null;
			Date fechaHasta = null;
			
			codigoDependencia = FormatoUtil.validarEmptyToNull(codigoDependencia);
			codPlanilla = FormatoUtil.validarEmptyToNull(codPlanilla);
			codTrabajador = FormatoUtil.validarEmptyToNull(codTrabajador);
			if (RendicionConstantes.CADENA_VACIA.equals(codEstadoRend) || RendicionConstantes.CODIGO_00.equals(codEstadoRend)) {
				codEstadoRend = null;
			}
			if (RendicionConstantes.CADENA_VACIA.equals(indicadorCanalAtencion) || RendicionConstantes.CODIGO_00.equals(indicadorCanalAtencion)) {
				indicadorCanalAtencion = null;
			}
			
			if (!RendicionConstantes.CADENA_VACIA.equals(fechaDesdeString)) {
				fechaDesde = FechaUtil.parseStringDateToDate(fechaDesdeString, RendicionConstantes.DATE_FORMAT_DDMMYYYY);
			}
			
			if (!RendicionConstantes.CADENA_VACIA.equals(fechaHastaString)) {
				fechaHasta = FechaUtil.parseStringDateToDate(fechaHastaString, RendicionConstantes.DATE_FORMAT_DDMMYYYY);
			}
			
			ArrayList<PlanViajeBean> planViajeList = consultaRendicionService.obtenerPlanViajeCompletoToBandejaConsultaRendicion(codigoDependencia, codPlanilla, codTrabajador, codEstadoRend, indicadorCanalAtencion, fechaDesde, fechaHasta);
			String nombreArchivo = RendicionConstantes.ARCHIVO_EXCEL_PREFIJO + FechaUtil.formatDateToDateYYYYMMDDHHMMSS(new Date()) + RendicionConstantes.ARCHIVO_EXCEL_EXTENSION;
			response.setContentType("application/xls");
			response.setHeader("Content-Disposition", "attachment; filename=" + nombreArchivo);
			viaticoReporteService.generarExcelBandejaConsultaRendicion(response.getOutputStream(), planViajeList, codigoPaginaCaller);
			log.debug(ConsultaRendicionController.class.getSimpleName() + ".exportarExcelBandejaConsultaRendicion.fin");
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		
		return viewPage;
	}
	
}
