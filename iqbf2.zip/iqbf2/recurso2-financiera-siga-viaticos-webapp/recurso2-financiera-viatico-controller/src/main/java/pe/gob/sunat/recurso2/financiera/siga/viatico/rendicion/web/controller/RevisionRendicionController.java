package pe.gob.sunat.recurso2.financiera.siga.viatico.rendicion.web.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONSerializer;
import net.sf.json.JsonConfig;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.T01ParametroBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroGeneralService;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.administracion.siga.util.FechaUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.FormatoUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.SolicitudDTO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.rendicion.service.RevisionRendicionService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoConsultaService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoGeneralService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoMensajeriaService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoReporteService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.RendicionConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.RendicionUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ResourceBundleUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.controller.BaseController;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.view.RendicionVO;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

/**
 * Controller que contiene los metodos necesarios para revisar una rendicion.
 * @author Jorge Ponce.
 */
public class RevisionRendicionController extends BaseController {
	
	protected final Log log = LogFactory.getLog(getClass());
	private RevisionRendicionService revisionRendicionService;
	private ViaticoConsultaService viaticoConsultaService;
	private ViaticoGeneralService viaticoGeneralService;
	private ViaticoReporteService viaticoReporteService;
	private ViaticoMensajeriaService viaticoMensajeriaService;
	private RegistroPersonalService registroPersonalService;
	private RegistroGeneralService registroGeneralService;
	
	public RevisionRendicionService getRevisionRendicionService() {
		return revisionRendicionService;
	}

	public void setRevisionRendicionService(RevisionRendicionService revisionRendicionService) {
		this.revisionRendicionService = revisionRendicionService;
	}

	public ViaticoConsultaService getViaticoConsultaService() {
		return viaticoConsultaService;
	}

	public void setViaticoConsultaService(ViaticoConsultaService viaticoConsultaService) {
		this.viaticoConsultaService = viaticoConsultaService;
	}

	public ViaticoGeneralService getViaticoGeneralService() {
		return viaticoGeneralService;
	}

	public void setViaticoGeneralService(ViaticoGeneralService viaticoGeneralService) {
		this.viaticoGeneralService = viaticoGeneralService;
	}

	public ViaticoReporteService getViaticoReporteService() {
		return viaticoReporteService;
	}

	public void setViaticoReporteService(ViaticoReporteService viaticoReporteService) {
		this.viaticoReporteService = viaticoReporteService;
	}

	public ViaticoMensajeriaService getViaticoMensajeriaService() {
		return viaticoMensajeriaService;
	}

	public void setViaticoMensajeriaService(ViaticoMensajeriaService viaticoMensajeriaService) {
		this.viaticoMensajeriaService = viaticoMensajeriaService;
	}

	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}

	public RegistroGeneralService getRegistroGeneralService() {
		return registroGeneralService;
	}

	public void setRegistroGeneralService(RegistroGeneralService registroGeneralService) {
		this.registroGeneralService = registroGeneralService;
	}

	/**
	 * Metodo que permite mostrar la bandeja rendicion notificacion.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView.
	 * @see ModelAndView
	 */
	public ModelAndView mostrarBandejaRendicionNotificacion(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView modelAndView = null;
		String errorMessage = RendicionConstantes.CADENA_VACIA;
		
		try {
			log.debug(RegistroRendicionController.class.getSimpleName() + ".mostrarBandejaRendicionNotificacion");
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			String numeroRegistro = usuarioBean.getNroRegistro();
			MaestroPersonalBean maestroPersonalBean = registroPersonalService.obtenerPersonaxRegistro(numeroRegistro);
			RendicionVO rendicionVO = RendicionUtil.obtenerRendicionVO(usuarioBean, maestroPersonalBean);
			if (rendicionVO != null) {
				String codigoEmpleado = maestroPersonalBean.getCodigoEmpleado();
				Long numeroRegistros = viaticoGeneralService.determinarRegistrador(codigoEmpleado);
				String flagMayor1UUOOAsociada = ViaticoUtil.obtenerFlagMayor1UUOOAsociada(numeroRegistros);
				String flagRegistrador = ViaticoUtil.obtenerFlagRegistrador(numeroRegistros);
				numeroRegistros = viaticoGeneralService.determinarRegistradorUniversal(codigoEmpleado);
				String flagRegistradorUniversal = ViaticoUtil.obtenerFlagRegistradorUniversal(numeroRegistros);
				if (RendicionConstantes.UNO.equals(flagRegistrador) || RendicionConstantes.UNO.equals(flagRegistradorUniversal)) {
					Map<String, Object> paramSearch = new HashMap<String, Object>();
					paramSearch.put("cod_par", RendicionConstantes.PARAMETRO_CANAL_ATENCION);
					paramSearch.put("cod_tipo", RendicionConstantes.TIPO_CANAL_ATENCION);
					ArrayList<T01ParametroBean> canalAtencionList = (ArrayList<T01ParametroBean>) registroGeneralService.recuperarParametroLista(paramSearch);
					rendicionVO.setCanalAtencionList(canalAtencionList);
					
					rendicionVO.setFlagRegistrador(flagRegistrador);
					rendicionVO.setFlagRegistradorUniversal(flagRegistradorUniversal);
					rendicionVO.setFlagMayor1UUOOAsociada(flagMayor1UUOOAsociada);
					rendicionVO.setFlagBuscarUUOO(ViaticoUtil.obtenerFlagBuscarUUOO(flagRegistradorUniversal, flagRegistrador));
				}
				else {
					errorMessage = ResourceBundleUtil.getMessage(RendicionConstantes.MENSAJE_ERROR_ACCESO, RendicionConstantes.PERFIL_REGISTRADOR);
				}
			}
			respuesta.put("rendicionVO", rendicionVO);
			log.debug(RegistroRendicionController.class.getSimpleName() + ".mostrarBandejaRendicionNotificacion.fin");
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			errorMessage = ResourceBundleUtil.getMessage(RendicionConstantes.MENSAJE_ERROR_GENERICO);
		}
		respuesta.put("errorMessage", errorMessage);
		modelAndView = new ModelAndView(RendicionConstantes.NOTIFICAR_RENDICION_BANDEJA_VIATICO_PAGE, respuesta);
		return modelAndView;
	}
	
	/**
	 * Metodo que permite obtener/buscar las planillas que se van a mostrar en la bandeja rendicion notificacion.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	public ModelAndView buscarPlanillasBandejaNotificacion(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoConsulta = RendicionConstantes.ERROR_CONSULTA;
		String errorMessage = RendicionConstantes.CADENA_VACIA;
		
		try {
			log.debug(RevisionRendicionController.class.getSimpleName() + ".buscarPlanillasBandejaNotificacion");
			ArrayList<PlanViajeBean> planViajeList = obtenerPlanViajeToBandejaNotificacionRendicion(request);
			codigoConsulta = RendicionConstantes.EXITO_CONSULTA;
			respuesta.put("planViajeList", planViajeList);
			log.debug(RevisionRendicionController.class.getSimpleName() + ".buscarPlanillasBandejaNotificacion.fin");
			
		} catch (Exception e) {
			errorMessage = ResourceBundleUtil.getMessage(RendicionConstantes.MENSAJE_ERROR_GENERICO);
			log.error(e.getMessage(), e);
		}
		
		respuesta.put("codigoConsulta", codigoConsulta);
		respuesta.put("errorMessage", errorMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	/**
	 * Metodo que permite exportar excel de la bandeja rendicion.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (Excel).
	 * @see ModelAndView
	 */
	public ModelAndView exportarExcelBandejaNotificacion(HttpServletRequest request, HttpServletResponse response) {
		
		ModelAndView viewPage = null;
		
		try {
			log.debug(RevisionRendicionController.class.getSimpleName() + ".exportarExcelBandejaNotificacion");
			ArrayList<PlanViajeBean> planViajeList = obtenerPlanViajeToBandejaNotificacionRendicion(request);
			String nombreArchivo = RendicionConstantes.ARCHIVO_EXCEL_PREFIJO + FechaUtil.formatDateToDateYYYYMMDDHHMMSS(new Date()) + RendicionConstantes.ARCHIVO_EXCEL_EXTENSION;
			response.setContentType("application/xls");
			response.setHeader("Content-Disposition", "attachment; filename=" + nombreArchivo);
			viaticoReporteService.generarExcelBandejaNotificacionRendicion(response.getOutputStream(), planViajeList);
			log.debug(RevisionRendicionController.class.getSimpleName() + ".exportarExcelBandejaNotificacion.fin");
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		
		return viewPage;
	}
	
	/**
	 * Metodo que permite obtener el listado de plan viaje para la bandeja notificacion rendicion.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @return Listado plan viaje.
	 * @see PlanViajeBean
	 * @throws Exception
	 */
	private ArrayList<PlanViajeBean> obtenerPlanViajeToBandejaNotificacionRendicion(HttpServletRequest request) throws Exception {
		
		String codigoDependencia = request.getParameter("codigoDependencia");
		String indicadorCanalAtencion = request.getParameter("indicadorCanalAtencion");
		String fechaHastaString = request.getParameter("fechaHasta");
		Date fechaHasta = null;
		
		codigoDependencia = FormatoUtil.validarEmptyToNull(codigoDependencia);
		if (RendicionConstantes.CADENA_VACIA.equals(indicadorCanalAtencion) || RendicionConstantes.CODIGO_00.equals(indicadorCanalAtencion)) {
			indicadorCanalAtencion = null;
		}
		
		if (!RendicionConstantes.CADENA_VACIA.equals(fechaHastaString)) {
			fechaHasta = FechaUtil.parseStringDateToDate(fechaHastaString, RendicionConstantes.DATE_FORMAT_DDMMYYYY);
		}
		
		ArrayList<PlanViajeBean> planViajeList = revisionRendicionService.obtenerPlanViajeToBandejaNotificacionRendicion(codigoDependencia, indicadorCanalAtencion, fechaHasta);
		return planViajeList;
	}
	
	/**
	 * Metodo que permite anular envio de un plan viaje.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	public ModelAndView anularEnvioPlanViaje(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoOperacion = RendicionConstantes.ERROR_OPERACION;
		String errorMessage = RendicionConstantes.CADENA_VACIA;
		
		try {
			log.debug(RevisionRendicionController.class.getSimpleName() + ".anularEnvioPlanViaje");
			String codPlanViaje = request.getParameter("codPlanViaje");
			codPlanViaje = FormatoUtil.validarEmptyToNull(codPlanViaje);
			
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			String numeroRegistro = usuarioBean.getNroRegistro();
			
			if (codPlanViaje != null) {
				setAuditoriaBeanHolder(request, response);
				codigoOperacion = revisionRendicionService.anularEnvioPlanViaje(codPlanViaje, numeroRegistro);
			}
			log.debug(RevisionRendicionController.class.getSimpleName() + ".anularEnvioPlanViaje.fin");
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			errorMessage = ResourceBundleUtil.getMessage(RendicionConstantes.MENSAJE_ERROR_GENERICO);
		}

		respuesta.put("codigoOperacion", codigoOperacion);
		respuesta.put("errorMessage", errorMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	/**
	 * Metodo que permite reprogramar fecha de rendicion de un plan viaje.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	public ModelAndView reprogramarFechaRendicion(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoOperacion = RendicionConstantes.ERROR_OPERACION;
		String errorMessage = RendicionConstantes.CADENA_VACIA;
		
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		String numeroRegistro = usuarioBean.getNroRegistro();
		
		try {
			log.debug(RevisionRendicionController.class.getSimpleName() + ".reprogramarFechaRendicion");
			String codPlanViaje = request.getParameter("codPlanViaje");
			String fecMaxRendString = request.getParameter("fecMaxRend");
			String descripcionJustRep = request.getParameter("descripcionJustRep");
			Date fecMaxRend = null;
			
			codPlanViaje = FormatoUtil.validarEmptyToNull(codPlanViaje);
			if (!RendicionConstantes.CADENA_VACIA.equals(fecMaxRendString)) {
				fecMaxRend = FechaUtil.parseStringDateToDate(fecMaxRendString, RendicionConstantes.DATE_FORMAT_DDMMYYYY);
			}
			
			if (codPlanViaje != null) {
				setAuditoriaBeanHolder(request, response);
				log.debug("reprogramarFechaRendicion en el controller" + fecMaxRend + " " + numeroRegistro);				
				codigoOperacion = revisionRendicionService.reprogramarFechaRendicion(codPlanViaje, fecMaxRend, descripcionJustRep, numeroRegistro, usuarioBean.getLogin(), new Date());
				if (RendicionConstantes.EXITO_OPERACION.equals(codigoOperacion)) {
					SolicitudDTO solicitudDTO = viaticoConsultaService.obtenerPlanViajeToNotificacion(codPlanViaje);
					viaticoMensajeriaService.enviarNotificacionReprogramacionFechaRendicion(solicitudDTO);
				}
			}
			log.debug(RevisionRendicionController.class.getSimpleName() + ".reprogramarFechaRendicion.fin");
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			errorMessage = ResourceBundleUtil.getMessage(RendicionConstantes.MENSAJE_ERROR_GENERICO);
		}
	
		respuesta.put("codigoOperacion", codigoOperacion);
		respuesta.put("errorMessage", errorMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	/**
	 * Metodo que permite enviar la segunda notificacion a la rendicion.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	@SuppressWarnings("unchecked")
	public ModelAndView enviarSegundaNotificacionRendicion(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoOperacion = RendicionConstantes.ERROR_OPERACION;
		String errorMessage = RendicionConstantes.CADENA_VACIA;
		
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		String numeroRegistro = usuarioBean.getNroRegistro();
		
		try {
			log.debug(RevisionRendicionController.class.getSimpleName() + ".enviarSegundaNotificacionRendicion");
			String planViajeListJSON = request.getParameter("planViajeList");
			setAuditoriaBeanHolder(request, response);
			JSONArray jsonArray = (JSONArray) JSONSerializer.toJSON(planViajeListJSON);
			JsonConfig jsonConfig = new JsonConfig();
			jsonConfig.setArrayMode(JsonConfig.MODE_LIST);
			jsonConfig.setRootClass(PlanViajeBean.class);
			ArrayList<PlanViajeBean> planViajeList = (ArrayList<PlanViajeBean>)JSONSerializer.toJava(jsonArray, jsonConfig);
			codigoOperacion = revisionRendicionService.enviarSegundaNotificacionRendicion(planViajeList, numeroRegistro);
			log.debug(RevisionRendicionController.class.getSimpleName() + ".enviarSegundaNotificacionRendicion.fin");
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			errorMessage = ResourceBundleUtil.getMessage(RendicionConstantes.MENSAJE_ERROR_GENERICO);
		}
	
		respuesta.put("codigoOperacion", codigoOperacion);
		respuesta.put("errorMessage", errorMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}

}
