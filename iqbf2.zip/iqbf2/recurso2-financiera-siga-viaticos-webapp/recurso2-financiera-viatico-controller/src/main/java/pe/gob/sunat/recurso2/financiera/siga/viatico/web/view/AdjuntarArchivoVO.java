package pe.gob.sunat.recurso2.financiera.siga.viatico.web.view;

public class AdjuntarArchivoVO {

	private String modulo;
	private String aplicacion;
	private String numeroRegistroColaborador;
	private String planViajeId;
	private String numeroArchivo;
	private String estadoOrigen;
	private String estadoLLamada;
	
	
	public String getModulo() {
		return modulo;
	}
	public void setModulo(String modulo) {
		this.modulo = modulo;
	}
	public String getAplicacion() {
		return aplicacion;
	}
	public void setAplicacion(String aplicacion) {
		this.aplicacion = aplicacion;
	}
	public String getNumeroRegistroColaborador() {
		return numeroRegistroColaborador;
	}
	public void setNumeroRegistroColaborador(String numeroRegistroColaborador) {
		this.numeroRegistroColaborador = numeroRegistroColaborador;
	}
	public String getPlanViajeId() {
		return planViajeId;
	}
	public void setPlanViajeId(String planViajeId) {
		this.planViajeId = planViajeId;
	}
	public String getNumeroArchivo() {
		return numeroArchivo;
	}
	public void setNumeroArchivo(String numeroArchivo) {
		this.numeroArchivo = numeroArchivo;
	}
	public String getEstadoOrigen() {
		return estadoOrigen;
	}
	public void setEstadoOrigen(String estadoOrigen) {
		this.estadoOrigen = estadoOrigen;
	}
	public String getEstadoLLamada() {
		return estadoLLamada;
	}
	public void setEstadoLLamada(String estadoLLamada) {
		this.estadoLLamada = estadoLLamada;
	}
	
}
