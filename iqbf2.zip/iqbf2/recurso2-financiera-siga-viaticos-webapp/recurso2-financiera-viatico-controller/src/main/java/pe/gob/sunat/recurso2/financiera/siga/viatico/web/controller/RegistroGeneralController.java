package pe.gob.sunat.recurso2.financiera.siga.viatico.web.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONSerializer;
import net.sf.json.JsonConfig;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.recurso2.administracion.siga.archivo.model.bean.RegistroArchivosFisicoBean;
import pe.gob.sunat.recurso2.administracion.siga.archivo.service.RegistroArchivosService;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.administracion.siga.util.FormatoUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PapeletaDepositoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeInformeDistribBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeRendicionBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dto.DocumentoSustentarioDTO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.rendicion.service.ConsultaRendicionService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.rendicion.service.RegistroRendicionService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoRegistroService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.service.ConsultaSolicitudService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.service.RegistroSolicitudService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.AuditoriaUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ResourceBundleUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

/**
 * Controller que contiene los metodos generales a usar en los diferentes CUS.
 * @author Samuel Dionisio.
 */
public class RegistroGeneralController extends BaseController {

	protected final Log log = LogFactory.getLog(getClass());
	//private ViaticoService viaticoService;
	private RegistroPersonalService registroPersonalService;
	private RegistroArchivosService registroArchivosService;
	private ConsultaSolicitudService consultaSolicitudService;
	private ConsultaRendicionService consultaRendicionService;
	private RegistroRendicionService registroRendicionService;
	private RegistroSolicitudService registroSolicitudService;
	private ViaticoRegistroService viaticoRegistroService;
	private String uploadDir;
	
	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}

	public RegistroArchivosService getRegistroArchivosService() {
		return registroArchivosService;
	}

	public void setRegistroArchivosService(RegistroArchivosService registroArchivosService) {
		this.registroArchivosService = registroArchivosService;
	}

	public ConsultaSolicitudService getConsultaSolicitudService() {
		return consultaSolicitudService;
	}

	public void setConsultaSolicitudService(ConsultaSolicitudService consultaSolicitudService) {
		this.consultaSolicitudService = consultaSolicitudService;
	}

	public ConsultaRendicionService getConsultaRendicionService() {
		return consultaRendicionService;
	}

	public void setConsultaRendicionService(ConsultaRendicionService consultaRendicionService) {
		this.consultaRendicionService = consultaRendicionService;
	}

	public RegistroRendicionService getRegistroRendicionService() {
		return registroRendicionService;
	}

	public void setRegistroRendicionService(RegistroRendicionService registroRendicionService) {
		this.registroRendicionService = registroRendicionService;
	}

	public RegistroSolicitudService getRegistroSolicitudService() {
		return registroSolicitudService;
	}

	public void setRegistroSolicitudService(RegistroSolicitudService registroSolicitudService) {
		this.registroSolicitudService = registroSolicitudService;
	}

	public ViaticoRegistroService getViaticoRegistroService() {
		return viaticoRegistroService;
	}

	public void setViaticoRegistroService(ViaticoRegistroService viaticoRegistroService) {
		this.viaticoRegistroService = viaticoRegistroService;
	}

	public String getUploadDir() {
		return uploadDir;
	}

	public void setUploadDir(String uploadDir) {
		this.uploadDir = uploadDir;
	}

	/**
	 * Metodo que permite registrar o editar el documento sustentatorio.
	 * @author Samuel Dionisio
	 * @param request: objeto de la clase HttpServletRequest.
	 * @param response: objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView)
	 * @see ModelAndView
	 */
	public ModelAndView registrarComprobantePago(HttpServletRequest request, HttpServletResponse response){
		log.debug(getClass().getName() + " Inicio del metodo registroComprobantePago.");
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView view = null;
		
		DocumentoSustentarioDTO   documentoSustentarioDTO  =  new DocumentoSustentarioDTO();
		try{
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			this.setAuditoriaBeanHolder(request, response);
			request.getSession().setAttribute("usuarioBean", usuarioBean);		
			
			String planViajeId = request.getParameter("planViajeId");
			planViajeId = FormatoUtil.validarEmptyToNull(planViajeId);
			String secuencial = request.getParameter("secuencial");
			secuencial = FormatoUtil.validarEmptyToNull(secuencial);				
			String numeroRegistroColaborador = request.getParameter("numeroRegistroColaborador");
			numeroRegistroColaborador = FormatoUtil.validarEmptyToNull(numeroRegistroColaborador);			
			String fechaDocumento  = request.getParameter("fechaDocumento");	
			fechaDocumento = FormatoUtil.validarEmptyToNull(fechaDocumento);
			String listaPlanViajeRendicion =  request.getParameter("listaPlanViajeRendicion");
			/*String indExtDDJJ =  request.getParameter("indExtDDJJ");
			indExtDDJJ = FormatoUtil.validarEmptyToNull(indExtDDJJ);
			String montoTotalTotales =  request.getParameter("montoTotalTotales");	
			montoTotalTotales = FormatoUtil.validarEmptyToNull(montoTotalTotales);*/
			
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			
			Date fechaDocumentoRegistro = formatter.parse(fechaDocumento);
			
			MaestroPersonalBean maestroPersonalColaborador = registroPersonalService.obtenerPersonaxRegistro(numeroRegistroColaborador);
			String codigoColaborador = maestroPersonalColaborador.getCodigoEmpleado();
			String codigoDependencia = maestroPersonalColaborador.getCodigoDependencia();
			
			JSONArray jsonArrayRendicion = (JSONArray) JSONSerializer.toJSON(listaPlanViajeRendicion);
			log.debug(" JSONArray jsonArrayRendicion");
				JsonConfig jsonConfigRendicion = new JsonConfig();
				jsonConfigRendicion.setArrayMode(JsonConfig.MODE_LIST);
				jsonConfigRendicion.setRootClass(PlanViajeRendicionBean.class);
				log.debug(" JsonConfig jsonConfigRendicion");
				@SuppressWarnings("unchecked")
				List<PlanViajeRendicionBean> planViajeRendicionList = (List<PlanViajeRendicionBean>)JSONSerializer.toJava(jsonArrayRendicion, jsonConfigRendicion);
				PlanViajeRendicionBean planViajeR =  planViajeRendicionList.get(0);
				planViajeR.setFechaDocumento(fechaDocumentoRegistro);
				
				planViajeRendicionList.set(0, planViajeR);
				
				String listaPlanViajeInformeDistrib =  request.getParameter("listaPlanViajeInformeDistrib");
				log.debug("lista en el controller: " + listaPlanViajeInformeDistrib);
				JSONArray jsonArrayInformeDistrib = (JSONArray) JSONSerializer.toJSON(listaPlanViajeInformeDistrib);
				log.debug("lista en el controller json: " + jsonArrayInformeDistrib.toString());
				JsonConfig jsonConfigInformeDistrib = new JsonConfig();
				jsonConfigInformeDistrib.setArrayMode(JsonConfig.MODE_LIST);
				jsonConfigInformeDistrib.setRootClass(PlanViajeInformeDistribBean.class);
				@SuppressWarnings("unchecked")
				List<PlanViajeInformeDistribBean> planViajeInformeDistribList = (List<PlanViajeInformeDistribBean>)JSONSerializer.toJava(jsonArrayInformeDistrib, jsonConfigInformeDistrib);
				
				log.debug("lista en el controller objetos: " + planViajeInformeDistribList.size());
				for(PlanViajeInformeDistribBean planViajeInformeDistribIter:planViajeInformeDistribList){
					log.debug("==========================");
					log.debug(">>fecha :" + planViajeInformeDistribIter.getFechaViaticoEntrada());
					log.debug(">>detalle de alimentacion :" + planViajeInformeDistribIter.getMontoDocumentoAlimentacion());
					log.debug(">>detalle de hospedaje :" + planViajeInformeDistribIter.getMontoDocumentoHospedaje());
					log.debug(">>detalle de movilidad :" + planViajeInformeDistribIter.getMontoDocumentoMovilidad());
					log.debug(">>detalle de traslado :" + planViajeInformeDistribIter.getMontoDocumentoTranslado());
				}
				
				log.debug("==========================");
				log.debug("lista convertida: " + planViajeInformeDistribList+", tamaño de lista"+(planViajeInformeDistribList==null?-1:planViajeInformeDistribList.size()));
				
				documentoSustentarioDTO.setPlanViajeId(planViajeId);
				documentoSustentarioDTO.setSecuencial(secuencial);
				documentoSustentarioDTO.setCodigoColaborador(codigoColaborador);
				documentoSustentarioDTO.setCodigoDependencia(codigoDependencia);
				documentoSustentarioDTO.setListaPlanViajeRendicion(planViajeRendicionList);
				documentoSustentarioDTO.setListaPlanViajeInformeDistrib(planViajeInformeDistribList);
				/*documentoSustentarioDTO.setIndExtDDJJ(indExtDDJJ);
				documentoSustentarioDTO.setMontoTotalTotales(montoTotalTotales);*/
				documentoSustentarioDTO.setListaPlanViajeInformeDistrib(planViajeInformeDistribList);	
				AuditoriaUtil.set(usuarioBean);
				documentoSustentarioDTO = viaticoRegistroService.registrarComprobantePago(documentoSustentarioDTO);		
				documentoSustentarioDTO.setMensajeOut(0);
				
		}catch (Exception e) {
			documentoSustentarioDTO.setMensajeOut(-1);
			log.error(e.getMessage(),e);
		}
		finally{
			log.debug(getClass().getName() + " Fin del metodo registroComprobantePago.");
		}	
		
		respuesta.put("documentoSustentarioDTO", documentoSustentarioDTO);
		view = new ModelAndView(getJsonView(), respuesta);
		
		return view;
	}
	
	/**
	 * Carga el Archivo al Servidor y registra en el la BD(upload)
	 * @param request : de la clase HttpServletRequest
	 * @param response : de la clase HttpServletResponse
	 * @param hidNumeroRegitroArchivo : obtenida del request.getParameter
	 * @param SelCodTipoArchivo : obtenida del request.getParameter
	 * @param txtDescripcionArchivo : obtenida del request.getParameter
	 * @param registroDescripcion : obtenida del request.getParameter
	 * @param hidNumeroDocumento : obtenida del request.getParameter
	 * @param hidApliacion : obtenida del request.getParameter
	 * @param hidModulo : obtenida del request.getParameter
	 * @return  objeto view de la clase ModelAndView tipo Json con los datos menssaje, listArchivosAdj, codigoRegArchivo
	 **/
	public ModelAndView registrarArchivo(HttpServletRequest request, HttpServletResponse response){
		if (log.isDebugEnabled()){ log.debug("Inicio -  RegistroArchivosController.cargarArchivo");}

		Map<String, Object> respuesta = new HashMap<String, Object>();
		Map<String, Object> params 	= new HashMap<String, Object>();
		ModelAndView viewPage = null;

		List<RegistroArchivosFisicoBean> listArchivosAdj=null;
		long tamanio = 1048576;
		String codigoPlanViaje = ViaticoConstantes.CADENA_VACIA;
		//String registroDescripcion=ViaticoConstantes.CADENA_VACIA;
		String tipoDocumento = ViaticoConstantes.CADENA_VACIA;
		String fileDescripcion = ViaticoConstantes.CADENA_VACIA;
		String numeroRegitroArchivo	= ViaticoConstantes.CADENA_VACIA;
		String paginaOrigen = ViaticoConstantes.CADENA_VACIA;
		String codigoBoleto = ViaticoConstantes.CADENA_VACIA;
		String numeroDocumentoOrigen =  ViaticoConstantes.CADENA_VACIA;
		String numeroArchivo =  ViaticoConstantes.CADENA_VACIA;
		try{

			File farchivo = new File(ViaticoConstantes.RUTA_ARCHIVO_DATA0);
			File fupload = new File(ViaticoConstantes.RUTA__ARCHIVO_DATA0_TEM );
			if (!farchivo.exists() ){
				farchivo.mkdir();
			}
			if (!fupload.exists() ){
				fupload.mkdir();
			}
			
			//numeroRegitroArchivo	= StringUtils.trim(request.getParameter("numeroRegitroArchivo"));
			tipoDocumento	= StringUtils.trim(request.getParameter("tipoDocumento"));
			fileDescripcion	= StringUtils.trim(request.getParameter("fileDescripcion"));
			//registroDescripcion = StringUtils.trim(request.getParameter("registroDescripcion"));
			
			codigoPlanViaje	= StringUtils.trim(request.getParameter("codigoPlanViaje"));
			paginaOrigen = StringUtils.trim(request.getParameter("paginaOrigen"));
			codigoBoleto = StringUtils.trim(request.getParameter("codigoBoleto"));
			
			
			//log.debug("numeroRegitroArchivo: " + numeroRegitroArchivo);
			log.debug("tipoDocumento: " + tipoDocumento);
			log.debug("fileDescripcion : " + fileDescripcion);
			log.debug("codigoPlanViaje: " + codigoPlanViaje);
			log.debug("paginaOrigen: " + paginaOrigen);
			log.debug("codigoBoleto: " + codigoBoleto);
			
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");


			MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
			MultipartFile multipartFile = multipartRequest.getFile("file");
			log.debug("size"+multipartFile.getSize());
			log.debug("tamanio"+tamanio);
			if(multipartFile.getSize() > 0 && multipartFile.getSize() <= tamanio ) {
				String nombre_archivo = multipartFile.getOriginalFilename();
				File file =new File(uploadDir, nombre_archivo.trim());
				FileOutputStream fileOutputStream = new FileOutputStream(file);
				fileOutputStream.close();
				multipartFile.transferTo(file);
				log.debug("file"+multipartFile);	
				
				PlanViajeBean planViaje = new PlanViajeBean();
				if(ViaticoConstantes.PAGINA_PRINCIPAL.equals(paginaOrigen)){
					planViaje  =  consultaSolicitudService.buscarPlanViaje(codigoPlanViaje);
					numeroDocumentoOrigen = StringUtils.trimToEmpty(planViaje.getCodPlanViaje());
					numeroArchivo = StringUtils.trimToEmpty(planViaje.getNumeroRegistroArchivo());
				}else if(ViaticoConstantes.PAGINA_SECUNDARIA.equals(paginaOrigen)){
					planViaje  =  consultaSolicitudService.buscarPlanViaje(codigoPlanViaje);
					PapeletaDepositoBean papeletaDeposito = consultaRendicionService.obtenerPapeletaDeposito(codigoBoleto);
					numeroDocumentoOrigen = StringUtils.trimToEmpty(papeletaDeposito.getCodigoBoletaDeposito());
					numeroArchivo = StringUtils.trimToEmpty(papeletaDeposito.getNumeroRegistroArchivo());
				}
					//planViaje  =  consultaSolicitudService.buscarPlanViaje(codigoTablaId);
				
				//planViaje.getOrigen();
				if(ViaticoConstantes.TIPO_ORIGEN_SOLICITUD_VIATICO.equals(planViaje.getOrigen()))
				{	params.put("registroDescripcion", ViaticoConstantes.DESCRIPCION_ARCHIVO_VIATICOS);}
				else if(ViaticoConstantes.TIPO_ORIGEN_REEMBOLSO.equals(planViaje.getOrigen())){
					params.put("registroDescripcion", ViaticoConstantes.DESCRIPCION_ARCHIVO_REEMBOLSOS);
				} //Archivos Adjuntos de la Declaracion Jurada
				
				
				params.put("numeroDocumentoOrigen", numeroDocumentoOrigen);//CODIGO PLAN VIAJE
				params.put("file", file);
				params.put("num_archivo", numeroArchivo);
				params.put("tipoDocumento", tipoDocumento);
				params.put("fileDescripcion", fileDescripcion);
				params.put("aplicacion", ViaticoConstantes.APLICACION_SERVICIOS);
				params.put("modulo", ViaticoConstantes.MODULO_VIATICOS);

				AuditoriaUtil.set(usuarioBean);//Seteamos el usuario que va a servir como el registrador.
				numeroRegitroArchivo=registroArchivosService.registrarArchivoGeneral(params);

				if(ViaticoConstantes.PAGINA_PRINCIPAL.equals(paginaOrigen)){					
					PlanViajeBean planViajeB =  new PlanViajeBean();
					planViajeB.setCodPlanViaje(numeroDocumentoOrigen);
					planViajeB.setNumeroRegistroArchivo(numeroRegitroArchivo);
					registroSolicitudService.actualizarNumeroArchivoPlanViaje(planViajeB);
				}else if(ViaticoConstantes.PAGINA_SECUNDARIA.equals(paginaOrigen)){
					PapeletaDepositoBean papeletaDeposito = new PapeletaDepositoBean();
					papeletaDeposito.setCodigoBoletaDeposito(numeroDocumentoOrigen);
					papeletaDeposito.setNumeroRegistroArchivo(numeroRegitroArchivo);
					registroRendicionService.actualizarNumeroArchivoPapeletaDeposito(papeletaDeposito);
				}		
				
				
				//Recuperando Archivos Adjuntos////////////////////////////////////////////////////
				if(numeroRegitroArchivo!= null){
					if (!"".equals(numeroRegitroArchivo)){
						params.put("num_reg", numeroRegitroArchivo);
						listArchivosAdj= (List<RegistroArchivosFisicoBean>)registroArchivosService.listarArchivosAdjuntos(params);

					}
				}
				respuesta.put("mensajeFinal", "OK");
				respuesta.put("listaArchivosAdjutos",listArchivosAdj);
				respuesta.put("codigoRegArchivo",numeroRegitroArchivo);

			}
			else{
				log.debug("El Archivo debe ser mayor a 0Mb y menor a 1Mb, el archivo pesa: "+multipartFile.getSize() +" y soporta hasta 1048576.");
				respuesta.put("mensajeFinal", "El Archivo debe ser mayor a 0Mb y menor a 1Mb");
			}

		}catch(Throwable e){
			respuesta.put("mensajeFinal", "A ocurrido un inconveniente por favor intentelo mas tarde.");
			log.error("error registrarArchivo", e);
		} finally {
			if (log.isDebugEnabled()) {log.debug("Fin -  RqnpArchivoController.cargarArchivo");}
		}
		viewPage = new ModelAndView(getJsonView(), respuesta);

		return viewPage;
	}
	


/**
 * Elimina Archivos Fisico.
 * @author Eduardo Marchena
 * @see ModelAndView
 * @param request : de la clase HttpServletRequest
 * @param response : de la clase HttpServletResponse
 * @param numeroRegitroArchivo : obtenida del request.getParameter
 * @param sec_reg : obtenida del request.getParameter
 * @return objeto view de la clase ModelAndView tipo Json con los datos mensaje, listArchivosAdj
 **/
public ModelAndView eliminarArchivoFisico(HttpServletRequest request, HttpServletResponse response) {
	if (log.isDebugEnabled()){ log.debug("Inicio -  RegistroArchivosController.eliminarArchivoFisico");}
	Map<String, Object> respuesta = new HashMap<String, Object>();
	Map<String, Object> params 	= new HashMap<String, Object>();
	ModelAndView viewPage = null;

	List<RegistroArchivosFisicoBean> listArchivosAdj=null;
	String numeroRegitroArchivo=ViaticoConstantes.CADENA_VACIA;
	String secuenciArchivo=ViaticoConstantes.CADENA_VACIA;
	String paginaOrigen = ViaticoConstantes.CADENA_VACIA;
	String codigoPlanViaje = ViaticoConstantes.CADENA_VACIA;
	String codigoBoleto = ViaticoConstantes.CADENA_VACIA;
	
	try {
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");

		numeroRegitroArchivo = StringUtils.trim(request.getParameter("numeroRegitroArchivo"));
		secuenciArchivo	= StringUtils.trim(request.getParameter("numeroSecuencia"));
		paginaOrigen = StringUtils.trim(request.getParameter("paginaOrigen"));
		codigoPlanViaje = StringUtils.trim(request.getParameter("codigoPlanViaje"));
		codigoBoleto = StringUtils.trim(request.getParameter("codigoBoleto"));
		
		log.debug("numeroRegitroArchivo: " +numeroRegitroArchivo);
		log.debug("secuenciArchivo: " +secuenciArchivo);
		//Eliminando Archivo Fisico
		params.put("num_reg", numeroRegitroArchivo);
		params.put("sec_arc", secuenciArchivo);
		AuditoriaUtil.set(usuarioBean);//Seteamos el usuario que va a servir como el registrador.
		registroArchivosService.eliminarArchivoFisicoGeneral(params);
		
		
		//Recuperando Archivos Adjuntos////////////////////////////////////////////////////
		if(numeroRegitroArchivo!= null){
			if (!StringUtils.isEmpty(numeroRegitroArchivo)){
				params.put("num_reg", numeroRegitroArchivo);
				listArchivosAdj = (List<RegistroArchivosFisicoBean>)registroArchivosService.listarArchivosAdjuntos(params);
				respuesta.put("mensaje","OK");
			}
		}
		
		
		if(ViaticoConstantes.PAGINA_PRINCIPAL.equals(paginaOrigen)){					
			PlanViajeBean planViajeB =  new PlanViajeBean();
			planViajeB.setCodPlanViaje(codigoPlanViaje);
			if(CollectionUtils.isEmpty(listArchivosAdj)){
				planViajeB.setNumeroRegistroArchivo(ViaticoConstantes.CADENA_VACIA);
				registroSolicitudService.actualizarNumeroArchivoPlanViaje(planViajeB);}
			else {
				planViajeB.setNumeroRegistroArchivo(numeroRegitroArchivo);
				registroSolicitudService.actualizarNumeroArchivoPlanViaje(planViajeB);
			}
			
		}else if(ViaticoConstantes.PAGINA_SECUNDARIA.equals(paginaOrigen)){
			PapeletaDepositoBean papeletaDeposito = new PapeletaDepositoBean();
			papeletaDeposito.setCodigoBoletaDeposito(codigoBoleto);
			 if(CollectionUtils.isEmpty(listArchivosAdj)){
				papeletaDeposito.setNumeroRegistroArchivo(ViaticoConstantes.CADENA_VACIA);
				registroRendicionService.actualizarNumeroArchivoPapeletaDeposito(papeletaDeposito);}
			 else{
				 papeletaDeposito.setNumeroRegistroArchivo(numeroRegitroArchivo);
				 registroRendicionService.actualizarNumeroArchivoPapeletaDeposito(papeletaDeposito);
			 }
				
		}
		
		
		
		respuesta.put("listArchivosAdj",listArchivosAdj);
		viewPage = new ModelAndView(getJsonView(), respuesta);

		return viewPage;

		}
		catch(ServiceException ex){
			log.error("Error en  RegistroArchivosController.eliminarArchivoFisico: " + ex.getMessage(), ex);
			throw new ServiceException(this, ex);
		}
		catch(Exception ex){
			log.error("Error en  RegistroArchivosController.eliminarArchivoFisico: " + ex.getMessage(), ex);
			throw new ServiceException(this, ex);
		}
		finally{
			if (log.isDebugEnabled()){ log.debug("Fin -  RegistroArchivosController.eliminarArchivoFisico");}
		}
	}
	
	/**
	 * Metodo que permite eliminar comprobante de pago.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	public ModelAndView eliminarComprobante(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoOperacion = ViaticoConstantes.ERROR_OPERACION;
		String errorMessage = ViaticoConstantes.CADENA_VACIA;
		String successMessage = ViaticoConstantes.CADENA_VACIA;
		
		try {
			log.debug(RegistroGeneralController.class.getSimpleName() + ".eliminarComprobante");
			String planViajeId = request.getParameter("planViajeId");
			String secuencialString = request.getParameter("secuencial");
			String conceptoId = request.getParameter("conceptoId");
			String mtoReconocidoString = request.getParameter("mtoReconocido");
			String codigoPaginaCaller = request.getParameter("codigoPaginaCaller");
			BigDecimal mtoReconocido = BigDecimal.ZERO;
			
			planViajeId = FormatoUtil.validarEmptyToNull(planViajeId);
			secuencialString = FormatoUtil.validarEmptyToNull(secuencialString);
			mtoReconocidoString = FormatoUtil.validarEmptyToNull(mtoReconocidoString);
			if (mtoReconocidoString != null) {
				mtoReconocido = new BigDecimal(mtoReconocidoString);
			}
			
			if (planViajeId != null && secuencialString != null) {
				setAuditoriaBeanHolder(request, response);
				Integer secuencial = new Integer(secuencialString);
				codigoOperacion = viaticoRegistroService.eliminarComprobante(planViajeId, secuencial, conceptoId, mtoReconocido, codigoPaginaCaller);
				successMessage = ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_OPERACION_EXITOSA);
			}
			log.debug(RegistroGeneralController.class.getSimpleName() + ".eliminarComprobante.fin");
	
		} catch (Exception ex) {
			errorMessage = ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO);
			log.error(ex.getMessage(), ex);
		}
	
		respuesta.put("codigoOperacion", codigoOperacion);
		respuesta.put("errorMessage", errorMessage);
		respuesta.put("successMessage", successMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
}


