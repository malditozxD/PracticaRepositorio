package pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.web.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.PrgAnnoBean;
import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.SysEstadosBean;
import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.T01ParametroBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroGeneralService;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.administracion.siga.util.FechaUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.FormatoUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ConceptoPlanillaViaticosBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.NivelBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoConsultaService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoGeneralService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoReporteService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.service.ConsultaSolicitudService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.RendicionUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ReporteConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ResourceBundleUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.SolicitudConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.SolicitudUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.controller.BaseController;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.singleton.ViaticosProcesoSingleton;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.singleton.ViaticosTarifarioSingleton;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.view.MaestroPersonalViaticoBeanView;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.view.SolicitudVO;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

/**
 * La clase ConsultaSolicitudController realiza las consultas y operaciones con solicitudes de viatico (consultas, bandejas, etc).
 * 
 * @author Juan Saccatoma
 */
@SuppressWarnings("unchecked")
public class ConsultaSolicitudController extends BaseController {

	/** Declaracion del log para realizar los debug, info, error, etc. */
	protected final Log log = LogFactory.getLog(getClass());

	/** Declaracion del servicio registroPersonalService. */
	private RegistroPersonalService registroPersonalService;

	/** Declaracion del servicio registroGeneralService. */
	private RegistroGeneralService registroGeneralService;

	/** Declaracion del servicio consultaSolicitudService. */
	private ConsultaSolicitudService consultaSolicitudService;

	/** Declaracion del servicio viaticoGeneralService. */
	private ViaticoGeneralService viaticoGeneralService;

	/** Declaracion del servicio viaticoService. */
	private ViaticoService viaticoService;

	/** Declaracion del servicio viaticoConsultaService. */
	private ViaticoConsultaService viaticoConsultaService;

	/** Declaracion del servicio viaticoReporteService. */
	private ViaticoReporteService viaticoReporteService;

	/** Declaracion del servicio viaticosProcesoSingleton. */
	private ViaticosProcesoSingleton viaticosProcesoSingleton;

	/** Declaracion del servicio viaticosTarifarioSingleton. */
	private ViaticosTarifarioSingleton viaticosTarifarioSingleton;

	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}

	public RegistroGeneralService getRegistroGeneralService() {
		return registroGeneralService;
	}

	public void setRegistroGeneralService(RegistroGeneralService registroGeneralService) {
		this.registroGeneralService = registroGeneralService;
	}

	public ConsultaSolicitudService getConsultaSolicitudService() {
		return consultaSolicitudService;
	}

	public void setConsultaSolicitudService(ConsultaSolicitudService consultaSolicitudService) {
		this.consultaSolicitudService = consultaSolicitudService;
	}

	public ViaticoGeneralService getViaticoGeneralService() {
		return viaticoGeneralService;
	}

	public void setViaticoGeneralService(ViaticoGeneralService viaticoGeneralService) {
		this.viaticoGeneralService = viaticoGeneralService;
	}

	public ViaticoService getViaticoService() {
		return viaticoService;
	}

	public void setViaticoService(ViaticoService viaticoService) {
		this.viaticoService = viaticoService;
	}

	public ViaticoConsultaService getViaticoConsultaService() {
		return viaticoConsultaService;
	}

	public void setViaticoConsultaService(ViaticoConsultaService viaticoConsultaService) {
		this.viaticoConsultaService = viaticoConsultaService;
	}

	public ViaticoReporteService getViaticoReporteService() {
		return viaticoReporteService;
	}

	public void setViaticoReporteService(ViaticoReporteService viaticoReporteService) {
		this.viaticoReporteService = viaticoReporteService;
	}

	public ViaticosProcesoSingleton getViaticosProcesoSingleton() {
		return viaticosProcesoSingleton;
	}

	public void setViaticosProcesoSingleton(ViaticosProcesoSingleton viaticosProcesoSingleton) {
		this.viaticosProcesoSingleton = viaticosProcesoSingleton;
	}

	public ViaticosTarifarioSingleton getViaticosTarifarioSingleton() {
		return viaticosTarifarioSingleton;
	}

	public void setViaticosTarifarioSingleton(ViaticosTarifarioSingleton viaticosTarifarioSingleton) {
		this.viaticosTarifarioSingleton = viaticosTarifarioSingleton;
	}

	/**
	 * Carga la pagina de inicio para Autorizar Bandeja de Solicitudes CUS12 - IU17
	 * 
	 * @author Juan Saccatoma
	 * @see ModelAndView
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView generarBandejaAutorizacion(HttpServletRequest request, HttpServletResponse response) {
		Map<String, Object> parmSearch = new HashMap<String, Object>();
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView view = null;

		try {
			log.debug("Inicio - ConsultaSolicitudController.generarBandejaAutorizacion");
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			this.setAuditoriaBeanHolder(request, response);
			MaestroPersonalBean maestroPersonalBean = registroPersonalService.obtenerPersonaxRegistro(usuarioBean.getNroRegistro());
			String codigoEmpleado = maestroPersonalBean.getCodigoEmpleado();

			MaestroPersonalViaticoBeanView maestroPersonalViaticoBeanView = RendicionUtil.obtenerMaestroPersonalBeanView(usuarioBean, maestroPersonalBean);
			maestroPersonalViaticoBeanView.setFlagRegistrador(viaticoGeneralService.determinarRegistrador(codigoEmpleado));
			respuesta.put("maestroPersonalViaticoBeanView", maestroPersonalViaticoBeanView);

			/*
			 * log.debug("maestropb_xxx getCodigoDependencia->" + maestroPersonalViaticoBeanView.getCodigoDependencia()); log.debug("maestropb_xxx getDescripcionDependencia->" + maestroPersonalViaticoBeanView.getDescripcionDependencia()); log.debug("maestropb_xxx getFlagRegistrador->" +
			 * maestroPersonalViaticoBeanView.getFlagRegistrador()); log.debug("maestropb_xxx getNumeroRegistro->" + maestroPersonalViaticoBeanView.getNumeroRegistro()); log.debug("maestropb_xxx getUuoo->" + maestroPersonalViaticoBeanView.getUuoo());
			 */

			// Estados de Solicitud
			parmSearch.put("nom_tabla", ViaticoConstantes.ESTADO_VIATICO_NOMBRE_TABLA);
			parmSearch.put("origen", ViaticoConstantes.TIPO_ORIGEN_SOLICITUD_VIATICO);
			parmSearch.put("val_estado", ViaticoConstantes.ESTADO_VIATICO_POR_AUTORIZAR);
			// log.debug("parametros->"+parmSearch);
			List<SysEstadosBean> listEstados = (List<SysEstadosBean>) registroGeneralService.listarEstados(parmSearch);
			respuesta.put("listEstados", listEstados);
			// log.debug("listEstados->"+listEstados);
			parmSearch.clear();

			// canales de atencion
			parmSearch.put("cod_par", SolicitudConstantes.PARAMETRO_CANAL_ATENCION);
			parmSearch.put("cod_tipo", SolicitudConstantes.TIPO_CANAL_ATENCION);
			List<T01ParametroBean> listCanales = (List<T01ParametroBean>) registroGeneralService.recuperarParametroLista(parmSearch);
			respuesta.put("listCanales", listCanales);

			// anios
			List<PrgAnnoBean> listAnnios = (List<PrgAnnoBean>) viaticoGeneralService.listarAnios();
			respuesta.put("listAnnios", listAnnios);
			// log.debug(listAnnios);

			view = new ModelAndView(SolicitudConstantes.AUTORIZAR_SOLICITUD_VIATICO_PAGE, respuesta);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		} finally {
			log.debug("Fin - ConsultaSolicitudController.generarBandejaAutorizacion");
		}

		return view;
	}

	/**
	 * Metodo que permite cargar la pagina de inicio para Revisar Bandeja de Solicitudes: CUS09 - IU11.
	 * 
	 * @author Juan Farro
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion en formato JSON
	 * @see ModelAndView
	 */
	public ModelAndView generarBandejaRevision(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;

		boolean customMessage = false;
		String errorMessage = StringUtils.EMPTY;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			log.debug(getClass().getName() + " Inicio del metodo generarBandejaRevision");

			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			
			String dataJSON = StringUtils.trimToEmpty(request.getParameter("dataJSON"));

			// buscar datos del colaborador en session
			MaestroPersonalBean maestroPersonalBean = registroPersonalService.obtenerPersonaxRegistro(usuarioBean.getNroRegistro());

			if (maestroPersonalBean == null) {
				customMessage = true;
				throw new Exception("Usuario no existe");
			}

			// armar el view object para la vista
			SolicitudVO solicitudVO = SolicitudUtil.obtenerSolicitudVO(usuarioBean, maestroPersonalBean);

			// estados de solicitud
			List<SysEstadosBean> listaEstados = consultaSolicitudService.obtenerListaEstadosSolicitudViatico();
			solicitudVO.setEstadoSolicitudList(listaEstados);

			// canales de atencion
			List<T01ParametroBean> listaCanales = consultaSolicitudService.obtenerListaCanalesAtencionViatico();
			solicitudVO.setCanalAtencionList(listaCanales);

			// anios - últimos 5 anios
			int anioActual = Integer.parseInt(FechaUtil.obtenerAnioActual());
			List<String> listaAnios = SolicitudUtil.obtenerListaAniosBandejasSolicitud(anioActual);
			solicitudVO.setListaAnios(listaAnios);
			solicitudVO.setAnioActual(String.valueOf(anioActual));

			// obtener flags de registrador y mayor de una UUOO asociada
			Long numeroRegistros = viaticoGeneralService.determinarRegistrador(maestroPersonalBean.getCodigoEmpleado());
			solicitudVO.setFlagRegistrador(ViaticoUtil.obtenerFlagRegistrador(numeroRegistros));
			solicitudVO.setFlagMayor1UUOOAsociada(ViaticoUtil.obtenerFlagMayor1UUOOAsociada(numeroRegistros));

			// obtener flag de registrador universal
			numeroRegistros = viaticoGeneralService.determinarRegistradorUniversal(maestroPersonalBean.getCodigoEmpleado());
			solicitudVO.setFlagRegistradorUniversal(ViaticoUtil.obtenerFlagRegistradorUniversal(numeroRegistros));

			// determinar flags para buscar uuoo y colaborador
			String codigoTipoUUOOViatico = ViaticoUtil.obtenerFlagBuscarUUOO(solicitudVO.getFlagRegistradorUniversal(), solicitudVO.getFlagRegistrador());
			String codigoTipoUsuarioViatico = ViaticoUtil.obtenerFlagBuscarColaborador(solicitudVO.getFlagRegistradorUniversal(), solicitudVO.getFlagRegistrador());

			solicitudVO.setCodigoTipoUUOOViatico(codigoTipoUUOOViatico);
			solicitudVO.setCodigoTipoUsuarioViatico(codigoTipoUsuarioViatico);

			// seteo del view object para visualizar el formulario
			respuesta.put("solicitudVO", solicitudVO);
			respuesta.put("dataJSON", dataJSON);

			// seteo de estados de solicitud de viatico
			SolicitudUtil.poblarConstantesEstadosViatico(respuesta);

		} catch (Exception e) {

			log.error(e.getMessage(), e);
			errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO);

		} finally {

			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(SolicitudConstantes.REVISAR_SOLICITUD_BANDEJA_PAGE, respuesta);

			log.debug(getClass().getName() + " Fin del metodo generarBandejaRevision");
		}

		return modelAndView;
	}

	/**
	 * Metodo que permite cargar la pagina de inicio para Consultar Bandeja de Solicitudes: CUS10 - IU16
	 * 
	 * @author Juan Farro
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView generarBandejaConsulta(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;

		boolean customMessage = false;
		String errorMessage = StringUtils.EMPTY;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			log.debug(getClass().getName() + " Inicio del metodo generarBandejaConsulta");

			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");

			// buscar datos del colaborador en session
			MaestroPersonalBean maestroPersonalBean = registroPersonalService.obtenerPersonaxRegistro(usuarioBean.getNroRegistro());

			if (maestroPersonalBean == null) {
				customMessage = true;
				throw new Exception("Usuario no existe");
			}

			// armar el view object para la vista
			SolicitudVO solicitudVO = SolicitudUtil.obtenerSolicitudVO(usuarioBean, maestroPersonalBean);

			// estados de solicitud
			List<SysEstadosBean> listaEstados = consultaSolicitudService.obtenerListaEstadosSolicitudViatico();
			solicitudVO.setEstadoSolicitudList(listaEstados);

			// canales de atencion
			List<T01ParametroBean> listaCanales = consultaSolicitudService.obtenerListaCanalesAtencionViatico();
			solicitudVO.setCanalAtencionList(listaCanales);

			// anios - últimos 5 anios
			int anioActual = Integer.parseInt(FechaUtil.obtenerAnioActual());
			List<String> listaAnios = SolicitudUtil.obtenerListaAniosBandejasSolicitud(anioActual);
			solicitudVO.setListaAnios(listaAnios);
			solicitudVO.setAnioActual(String.valueOf(anioActual));

			// obtener flags de registrador y mayor de una UUOO asociada
			Long numeroRegistros = viaticoGeneralService.determinarRegistrador(maestroPersonalBean.getCodigoEmpleado());
			solicitudVO.setFlagRegistrador(ViaticoUtil.obtenerFlagRegistrador(numeroRegistros));
			solicitudVO.setFlagMayor1UUOOAsociada(ViaticoUtil.obtenerFlagMayor1UUOOAsociada(numeroRegistros));

			// obtener flag de registrador universal
			numeroRegistros = viaticoGeneralService.determinarRegistradorUniversal(maestroPersonalBean.getCodigoEmpleado());
			solicitudVO.setFlagRegistradorUniversal(ViaticoUtil.obtenerFlagRegistradorUniversal(numeroRegistros));

			// determinar flags para buscar uuoo y colaborador
			String codigoTipoUUOOViatico = ViaticoUtil.obtenerFlagBuscarUUOO(solicitudVO.getFlagRegistradorUniversal(), solicitudVO.getFlagRegistrador());
			String codigoTipoUsuarioViatico = ViaticoUtil.obtenerFlagBuscarColaborador(solicitudVO.getFlagRegistradorUniversal(), solicitudVO.getFlagRegistrador());

			solicitudVO.setCodigoTipoUUOOViatico(codigoTipoUUOOViatico);
			solicitudVO.setCodigoTipoUsuarioViatico(codigoTipoUsuarioViatico);

			// seteo del view object para visualizar el formulario
			respuesta.put("solicitudVO", solicitudVO);

			// seteo de estados de solicitud de viatico
			SolicitudUtil.poblarConstantesEstadosViatico(respuesta);
			
		} catch (Exception e) {

			log.error(e.getMessage(), e);
			errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO);

		} finally {

			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(SolicitudConstantes.CONSULTAR_SOLICITUD_BANDEJA_PAGE, respuesta);

			log.debug(getClass().getName() + " Fin del metodo generarBandejaConsulta");
		}

		return modelAndView;
	}

	/**
	 * Metodo que permite cargar la pagina de inicio para Bandeja Otorgar Fechas Alta de Solicitudes: CUS13 - IU19
	 * 
	 * @author Juan Farro
	 * @see ModelAndView
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView generarBandejaAlta(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;

		boolean customMessage = false;
		String errorMessage = StringUtils.EMPTY;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			log.debug(getClass().getName() + " Inicio del metodo generarBandejaAlta");

			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");

			// buscar datos del colaborador en session
			MaestroPersonalBean maestroPersonalBean = registroPersonalService.obtenerPersonaxRegistro(usuarioBean.getNroRegistro());

			if (maestroPersonalBean == null) {
				customMessage = true;
				throw new Exception("Usuario no existe");
			}

			// obtener flags de registrador y mayor de una UUOO asociada
			Long numeroRegistrosUniversal = viaticoGeneralService.determinarRegistradorUniversal(maestroPersonalBean.getCodigoEmpleado());
			if (!StringUtils.equals(ViaticoUtil.obtenerFlagRegistradorUniversal(numeroRegistrosUniversal), ViaticoConstantes.UNO)) {
				customMessage = true;
				throw new Exception("No puede acceder a esta bandeja. Perfil no es de registrador universal");
			}

			// armar el view object para la vista
			SolicitudVO solicitudVO = SolicitudUtil.obtenerSolicitudVO(usuarioBean, maestroPersonalBean);

			// estados de solicitud
			List<SysEstadosBean> listaEstados = consultaSolicitudService.obtenerListaEstadosSolicitudViatico();
			solicitudVO.setEstadoSolicitudList(listaEstados);

			// canales de atencion
			List<T01ParametroBean> listaCanales = consultaSolicitudService.obtenerListaCanalesAtencionViatico();
			solicitudVO.setCanalAtencionList(listaCanales);

			// anios - últimos 5 años
			int anioActual = Integer.parseInt(FechaUtil.obtenerAnioActual());
			List<String> listaAnios = SolicitudUtil.obtenerListaAniosBandejasSolicitud(anioActual);
			solicitudVO.setListaAnios(listaAnios);
			solicitudVO.setAnioActual(String.valueOf(anioActual));

			// obtener flags de registrador y mayor de una UUOO asociada
			Long numeroRegistros = viaticoGeneralService.determinarRegistrador(maestroPersonalBean.getCodigoEmpleado());
			solicitudVO.setFlagRegistrador(ViaticoUtil.obtenerFlagRegistrador(numeroRegistros));
			solicitudVO.setFlagMayor1UUOOAsociada(ViaticoUtil.obtenerFlagMayor1UUOOAsociada(numeroRegistros));

			// obtener flag de registrador universal
			numeroRegistros = viaticoGeneralService.determinarRegistradorUniversal(maestroPersonalBean.getCodigoEmpleado());
			solicitudVO.setFlagRegistradorUniversal(ViaticoUtil.obtenerFlagRegistradorUniversal(numeroRegistros));

			// como es registrador universal, siempre deberia retornar 03 en ambos
			// determinar flags para buscar uuoo y colaborador
			String codigoTipoUUOOViatico = ViaticoUtil.obtenerFlagBuscarUUOO(solicitudVO.getFlagRegistradorUniversal(), solicitudVO.getFlagRegistrador());
			String codigoTipoUsuarioViatico = ViaticoUtil.obtenerFlagBuscarColaborador(solicitudVO.getFlagRegistradorUniversal(), solicitudVO.getFlagRegistrador());

			solicitudVO.setCodigoTipoUUOOViatico(codigoTipoUUOOViatico);
			solicitudVO.setCodigoTipoUsuarioViatico(codigoTipoUsuarioViatico);

			// obtener el anio actual
			solicitudVO.setFechaToday(FechaUtil.obtenerFechaActual());

			// seteo del view object para visualizar el formulario
			respuesta.put("solicitudVO", solicitudVO);

			// seteo de estados de solicitud de viatico
			SolicitudUtil.poblarConstantesEstadosViatico(respuesta);

		} catch (Exception e) {

			log.error(e.getMessage(), e);
			errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO);

		} finally {

			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(SolicitudConstantes.ALTA_SOLICITUD_BANDEJA_PAGE, respuesta);

			log.debug(getClass().getName() + " Fin del metodo generarBandejaAlta");
		}

		return modelAndView;
	}

	/**
	 * Retorna las solicitudes de viatico del formulario de búsqueda en formato JSON.
	 * 
	 * @author Juan Farro
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion en formato JSON
	 * @throws Exception
	 * @see ModelAndView
	 */
	public ModelAndView buscarSolicitudesBandeja(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map<String, Object> parmSearch = new HashMap<String, Object>();
		Map<String, Object> respuesta = new HashMap<String, Object>();

		ModelAndView view = null;
		try {

			log.debug("Inicio - ConsultaSolicitudController.buscarSolicitudesBandeja");
			// String codUUOO = (request.getParameter("codUUOO").isEmpty() ? null : request.getParameter("codUUOO").trim());
			// String numRegistro = (request.getParameter("numRegistro").isEmpty() ? null : request.getParameter("numRegistro").trim());
			// String nomColaborador = (request.getParameter("nomColaborador").isEmpty() ? null : request.getParameter("nomColaborador").trim());
			// String nomDependencia = (request.getParameter("nomDependencia").isEmpty() ? null : request.getParameter("nomDependencia").trim());
			String codDependencia = (request.getParameter("codDependencia").isEmpty() ? null : request.getParameter("codDependencia").trim());
			String codColaborador = (request.getParameter("codColaborador").isEmpty() ? null : request.getParameter("codColaborador").trim());
			String codEstado = (request.getParameter("codEstado").isEmpty() ? null : request.getParameter("codEstado").trim());
			String codCanal = (request.getParameter("codCanal").isEmpty() ? null : request.getParameter("codCanal").trim());

			String fechaDesde = (request.getParameter("fechaDesde").isEmpty() ? null : request.getParameter("fechaDesde").trim());
			String fechaHasta = (request.getParameter("fechaHasta").isEmpty() ? null : request.getParameter("fechaHasta").trim());
			String numPlanilla = (request.getParameter("numPlanilla").isEmpty() ? null : request.getParameter("numPlanilla").trim());
			// String indTraslape=(request.getParameter("indTraslape").isEmpty()?null:request.getParameter("indTraslape").trim());
			boolean indTraslape = false;
			if (!StringUtils.isEmpty(request.getParameter("indTraslape"))) {
				indTraslape = true;
			}

			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			this.setAuditoriaBeanHolder(request, response);
			request.getSession().setAttribute("usuarioBean", usuarioBean);
			/*
			 * log.debug(usuarioBean.getLogin() +" - "+ usuarioBean.getNroRegistro());
			 * 
			 * log.debug("buscarSolicitudes - codUUOO ->"+codUUOO); log.debug("buscarSolicitudes - numRegistro ->"+numRegistro); log.debug("buscarSolicitudes - nomColaborador ->"+nomColaborador); log.debug("buscarSolicitudes - nomDependencia ->"+nomDependencia);
			 * log.debug("buscarSolicitudes - codDependencia ->"+codDependencia); log.debug("buscarSolicitudes - codColaborador ->"+codColaborador); log.debug("buscarSolicitudes - codEstado ->"+codEstado); log.debug("buscarSolicitudes - fechaDesde ->"+ fechaDesde);
			 * log.debug("buscarSolicitudes - fechaHasta ->"+ fechaHasta); log.debug("buscarSolicitudes - numPlanilla" + numPlanilla);
			 */

			Date fechaDesde_dt = null;
			Date fechaHasta_dt = null;
			if (fechaDesde != null) {
				fechaDesde_dt = new SimpleDateFormat("dd/MM/yyyy").parse(fechaDesde);
			}
			if (fechaHasta != null) {
				fechaHasta_dt = new SimpleDateFormat("dd/MM/yyyy").parse(fechaHasta);
			}

			parmSearch.put("codColaborador", codColaborador);
			parmSearch.put("codDependencia", codDependencia);
			parmSearch.put("codEstado", codEstado);
			parmSearch.put("codCanal", codCanal);
			parmSearch.put("numPlanilla", numPlanilla);
			parmSearch.put("fechaDesde", fechaDesde_dt);
			parmSearch.put("fechaHasta", fechaHasta_dt);
			parmSearch.put("nom_tabla", ViaticoConstantes.ESTADO_VIATICO_NOMBRE_TABLA);
			parmSearch.put("origen", ViaticoConstantes.TIPO_ORIGEN_SOLICITUD_VIATICO);

			if (indTraslape) {
				parmSearch.put("indTraslape", indTraslape);
			}

			List<PlanViajeBean> listSolicitudes = (List<PlanViajeBean>) consultaSolicitudService.obtenerSolicitudesBandeja(parmSearch);
			respuesta.put("listSolicitudes", listSolicitudes);

			view = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		} finally {
			log.debug("Fin - ConsultaSolicitudController.buscarSolicitudesBandeja");
		}

		return view;
	}

	/**
	 * Metodo que permite retornar las solicitudes de viatico en formato JSON de la bandeja de consulta (CUS10)
	 * 
	 * @author Juan Farro
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion en formato JSON
	 * @throws Exception
	 * @see ModelAndView
	 */
	public ModelAndView buscarSolicitudesBandejaConsulta(HttpServletRequest request, HttpServletResponse response) throws Exception {

		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			log.debug(getClass().getName() + " Inicio del metodo buscarSolicitudesBandejaConsulta");

			String codDependencia = StringUtils.trimToNull(request.getParameter("codDependencia"));
			String codColaborador = StringUtils.trimToNull(request.getParameter("codColaborador"));
			String codEstado = StringUtils.trimToNull(request.getParameter("codEstado"));
			String codCanal = StringUtils.trimToNull(request.getParameter("codCanal"));
			String numPlanilla = StringUtils.trimToNull(request.getParameter("numPlanilla"));
			String fechaDesde = StringUtils.trimToNull(request.getParameter("fechaDesde"));
			String fechaHasta = StringUtils.trimToNull(request.getParameter("fechaHasta"));

			// INDICADORES QUE LA PETICIÓN AJAX CULMINÓ SIN ERRORES
			respuesta.put("error", ViaticoConstantes.NO);
			respuesta.put("msgError", StringUtils.EMPTY);

			// validacion, que si ingresa número de planilla, valide que esta exista
			respuesta.put("hayValidacion", ViaticoConstantes.NO);
			respuesta.put("msgValidacion", StringUtils.EMPTY);

			if (StringUtils.isNotBlank(numPlanilla)) {

				boolean existePlanilla = viaticoConsultaService.existePlanilla(numPlanilla);
				if (!existePlanilla) {

					respuesta.put("hayValidacion", ViaticoConstantes.SI);
					respuesta.put("msgValidacion", ResourceBundleUtil.getMessageSolicitud(ViaticoConstantes.BANDEJA_CONSULTA_MENSAJE_ERROR_PLANILLA_NO_EXISTE));

					modelAndView = new ModelAndView(getJsonView(), respuesta);

					return modelAndView;
				}

			}

			Date fechaDesdeDate = null;
			if (fechaDesde != null && FechaBean.validaFormato(fechaDesde, FechaBean.FORMATO_DEFAULT)) {
				fechaDesdeDate = ViaticoUtil.parseStringDateToDate(fechaDesde);
			}

			Date fechaHastaDate = null;
			if (fechaHasta != null && FechaBean.validaFormato(fechaHasta, FechaBean.FORMATO_DEFAULT)) {
				fechaHastaDate = ViaticoUtil.parseStringDateToDate(fechaHasta);
			}

			// parametros de búsqueda
			Map<String, Object> parmSearch = new HashMap<String, Object>();

			parmSearch.put("codColaborador", codColaborador);
			parmSearch.put("codDependencia", codDependencia);
			parmSearch.put("codEstado", codEstado);
			parmSearch.put("codCanal", codCanal);
			parmSearch.put("numPlanilla", numPlanilla);
			parmSearch.put("fechaDesde", fechaDesdeDate);
			parmSearch.put("fechaHasta", fechaHastaDate);
			parmSearch.put("nom_tabla", ViaticoConstantes.ESTADO_VIATICO_NOMBRE_TABLA);
			parmSearch.put("origen", ViaticoConstantes.TIPO_ORIGEN_SOLICITUD_VIATICO);

			setAuditoriaBeanHolder(request, response);

			List<PlanViajeBean> listSolicitudes = (List<PlanViajeBean>) consultaSolicitudService.obtenerSolicitudesBandejaConsultaRevisionAlta(parmSearch);

			respuesta.put("listSolicitudes", listSolicitudes);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {

			log.error(e.getMessage(), e);

			// INDICADORES QUE LA PETICION AJAX CULMINO CON ERRORES.
			// NOTA: El key msgError se usa como mensaje generico de error no manejable. 
			//       Otros keys del mapa respuesta se usan para personalizar los mensajes de negocio visibles al usuario.
			respuesta.put("error", ViaticoConstantes.SI);
			respuesta.put("msgError", ViaticoConstantes.MSG_ERROR_OPERACION_NO_EFECTUADA);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} finally {

			log.debug(getClass().getName() + " Fin del metodo buscarSolicitudesBandejaConsulta");

		}

		return modelAndView;
	}

	/**
	 * Metodo que permite retornar las solicitudes de viatico en formato JSON de la bandeja de consulta (CUS09)
	 * 
	 * @author Juan Farro
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion en formato JSON
	 * @throws Exception
	 * @see ModelAndView
	 */
	public ModelAndView buscarSolicitudesBandejaRevision(HttpServletRequest request, HttpServletResponse response) throws Exception {

		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			log.debug(getClass().getName() + " Inicio del metodo buscarSolicitudesBandejaRevision");

			String codDependencia = StringUtils.trimToNull(request.getParameter("codDependencia"));
			String codColaborador = StringUtils.trimToNull(request.getParameter("codColaborador"));
			String codEstado = StringUtils.trimToNull(request.getParameter("codEstado"));
			String codCanal = StringUtils.trimToNull(request.getParameter("codCanal"));
			String numPlanilla = StringUtils.trimToNull(request.getParameter("numPlanilla"));
			String fechaDesde = StringUtils.trimToNull(request.getParameter("fechaDesde"));
			String fechaHasta = StringUtils.trimToNull(request.getParameter("fechaHasta"));

			// INDICADORES QUE LA PETICIÓN AJAX CULMINÓ SIN ERRORES
			respuesta.put("error", ViaticoConstantes.NO);
			respuesta.put("msgError", StringUtils.EMPTY);

			// validacion, que si ingresa número de planilla, valide que esta exista
			respuesta.put("hayValidacion", ViaticoConstantes.NO);
			respuesta.put("msgValidacion", StringUtils.EMPTY);

			if (StringUtils.isNotBlank(numPlanilla)) {

				boolean existePlanilla = viaticoConsultaService.existePlanilla(numPlanilla);
				if (!existePlanilla) {

					respuesta.put("hayValidacion", ViaticoConstantes.SI);
					respuesta.put("msgValidacion", ResourceBundleUtil.getMessageSolicitud(ViaticoConstantes.BANDEJA_REVISION_MENSAJE_ERROR_PLANILLA_NO_EXISTE));

					modelAndView = new ModelAndView(getJsonView(), respuesta);

					return modelAndView;
				}

			}

			Date fechaDesdeDate = null;
			if (fechaDesde != null && FechaBean.validaFormato(fechaDesde, FechaBean.FORMATO_DEFAULT)) {
				fechaDesdeDate = ViaticoUtil.parseStringDateToDate(fechaDesde);
			}

			Date fechaHastaDate = null;
			if (fechaHasta != null && FechaBean.validaFormato(fechaHasta, FechaBean.FORMATO_DEFAULT)) {
				fechaHastaDate = ViaticoUtil.parseStringDateToDate(fechaHasta);
			}

			// parametros de búsqueda
			Map<String, Object> parmSearch = new HashMap<String, Object>();

			parmSearch.put("codColaborador", codColaborador);
			parmSearch.put("codDependencia", codDependencia);
			parmSearch.put("codEstado", codEstado);
			parmSearch.put("codCanal", codCanal);
			parmSearch.put("numPlanilla", numPlanilla);
			parmSearch.put("fechaDesde", fechaDesdeDate);
			parmSearch.put("fechaHasta", fechaHastaDate);
			parmSearch.put("nom_tabla", ViaticoConstantes.ESTADO_VIATICO_NOMBRE_TABLA);
			parmSearch.put("origen", ViaticoConstantes.TIPO_ORIGEN_SOLICITUD_VIATICO);

			setAuditoriaBeanHolder(request, response);

			List<PlanViajeBean> listSolicitudes = (List<PlanViajeBean>) consultaSolicitudService.obtenerSolicitudesBandejaConsultaRevisionAlta(parmSearch);

			respuesta.put("listSolicitudes", listSolicitudes);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {

			log.error(e.getMessage(), e);

			// INDICADORES QUE LA PETICION AJAX CULMINO CON ERRORES.
			// NOTA: El key msgError se usa como mensaje generico de error no manejable. 
			//       Otros keys del mapa respuesta se usan para personalizar los mensajes de negocio visibles al usuario.
			respuesta.put("error", ViaticoConstantes.SI);
			respuesta.put("msgError", ViaticoConstantes.MSG_ERROR_OPERACION_NO_EFECTUADA);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} finally {

			log.debug(getClass().getName() + " Fin del metodo buscarSolicitudesBandejaRevision");
		}

		return modelAndView;
	}

	/**
	 * Metodo que permite retornar las solicitudes de viatico en formato JSON de la bandeja de alta de fechas (CUS13)
	 * 
	 * @author Juan Farro
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion en formato JSON
	 * @throws Exception
	 * @see ModelAndView
	 */
	public ModelAndView buscarSolicitudesBandejaAlta(HttpServletRequest request, HttpServletResponse response) throws Exception {

		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			log.debug(getClass().getName() + " Inicio del metodo buscarSolicitudesBandejaAlta");

			String codDependencia = StringUtils.trimToNull(request.getParameter("codDependencia"));
			String codColaborador = StringUtils.trimToNull(request.getParameter("codColaborador"));
			String fechaHasta = StringUtils.trimToNull(request.getParameter("fechaHasta"));

			String selIndAutorizacion = request.getParameter("selIndAutorizacion");
			log.debug("selIndAutorizacion: " + selIndAutorizacion);
			
			Date fechaDesdeDate = ViaticoUtil.parseStringDateToDate(ViaticoConstantes.FECHA_INICIO_REFERENCIAL);

			Date fechaHastaDate = null;
			if (fechaHasta != null && FechaBean.validaFormato(fechaHasta, FechaBean.FORMATO_DEFAULT)) {
				fechaHastaDate = ViaticoUtil.parseStringDateToDate(fechaHasta);
			}

			// parametros de búsqueda
			Map<String, Object> parmSearch = new HashMap<String, Object>();

			parmSearch.put("codColaborador", codColaborador);
			parmSearch.put("codDependencia", codDependencia);
			parmSearch.put("codEstado", ViaticoConstantes.ESTADO_VIATICO_ELABORADO);
			parmSearch.put("fechaDesde", fechaDesdeDate);
			parmSearch.put("fechaHasta", fechaHastaDate);
			parmSearch.put("nom_tabla", ViaticoConstantes.ESTADO_VIATICO_NOMBRE_TABLA);
			parmSearch.put("origen", null); // que busque tanto solicitudes de viatico como de reembolso
			parmSearch.put("indTraslape", ViaticoConstantes.UNO); // aquellos que tienen traslape
			// parmSearch.put("indAutorizacion", ViaticoConstantes.INDICADOR_AUTORIZACION_SIN_AUTORIZAR); // aquellos que no han sido autorizados (1) o rechazados (2)

			setAuditoriaBeanHolder(request, response);

			/*
			TODOS T
			PENDIENTE 0
			ALTA 1
			RECHAZADO 2
			*/
			
			if ("T".equals(selIndAutorizacion)) {
				String[] listEstadosAutorizacionTraslapeInclusion = new String[3];
				listEstadosAutorizacionTraslapeInclusion[0] = ViaticoConstantes.INDICADOR_AUTORIZACION_SIN_AUTORIZAR;
				listEstadosAutorizacionTraslapeInclusion[1] = ViaticoConstantes.INDICADOR_AUTORIZACION_AUTORIZADO;
				listEstadosAutorizacionTraslapeInclusion[2] = ViaticoConstantes.INDICADOR_AUTORIZACION_RECHAZADO;
				parmSearch.put("listEstadosAutorizacionTraslapeInclusion", listEstadosAutorizacionTraslapeInclusion);
			}
			else if (ViaticoConstantes.INDICADOR_AUTORIZACION_SIN_AUTORIZAR.equals(selIndAutorizacion)) {
				parmSearch.put("indAutorizacion", ViaticoConstantes.INDICADOR_AUTORIZACION_SIN_AUTORIZAR);
				/*String[] listEstadosAutorizacionTraslapeExclusion = new String[2];
				listEstadosAutorizacionTraslapeExclusion[0] = ViaticoConstantes.INDICADOR_AUTORIZACION_AUTORIZADO;
				listEstadosAutorizacionTraslapeExclusion[1] = ViaticoConstantes.INDICADOR_AUTORIZACION_RECHAZADO;
				parmSearch.put("listEstadosAutorizacionTraslapeExclusion", listEstadosAutorizacionTraslapeExclusion);*/
			}
			else if (ViaticoConstantes.INDICADOR_AUTORIZACION_AUTORIZADO.equals(selIndAutorizacion)) {
				parmSearch.put("indAutorizacion", ViaticoConstantes.INDICADOR_AUTORIZACION_AUTORIZADO);
			}
			else if (ViaticoConstantes.INDICADOR_AUTORIZACION_RECHAZADO.equals(selIndAutorizacion)) {
				parmSearch.put("indAutorizacion", ViaticoConstantes.INDICADOR_AUTORIZACION_RECHAZADO);
			}
			
			List<PlanViajeBean> listSolicitudes = (List<PlanViajeBean>) consultaSolicitudService.obtenerSolicitudesBandejaConsultaRevisionAlta(parmSearch);

			respuesta.put("listSolicitudes", listSolicitudes);

			// INDICADORES QUE LA PETICIÓN AJAX CULMINÓ SIN ERRORES
			respuesta.put("error", ViaticoConstantes.NO);
			respuesta.put("msgError", StringUtils.EMPTY);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {

			log.error(e.getMessage(), e);

			// INDICADORES QUE LA PETICION AJAX CULMINO CON ERRORES.
			// NOTA: El key msgError se usa como mensaje generico de error no manejable. 
			//       Otros keys del mapa respuesta se usan para personalizar los mensajes de negocio visibles al usuario.
			respuesta.put("error", ViaticoConstantes.SI);
			respuesta.put("msgError", ViaticoConstantes.MSG_ERROR_OPERACION_NO_EFECTUADA);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} finally {

			log.debug(getClass().getName() + " Fin del metodo buscarSolicitudesBandejaAlta");
		}

		return modelAndView;
	}

	/**
	 * Retorna informacion adicional de la solicitud de viatico en formato JSON.
	 * 
	 * @author Juan Saccatoma
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion en formato JSON
	 * @see ModelAndView
	 */
	public ModelAndView buscarSolicitudDetalle(HttpServletRequest request, HttpServletResponse response) {
		Map<String, Object> parmSearch = new HashMap<String, Object>();
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView view = null;

		try {
			log.debug("Inicio - ConsultaSolicitudController.buscarSolicitudDetalle");
			String codPlanViaje = request.getParameter("codPlanViaje");
			parmSearch.put("codigoP", codPlanViaje);
			// log.debug("codPlanViaje xxx"+codPlanViaje);
			List<PlanViajeBean> detalle = (List<PlanViajeBean>) consultaSolicitudService.obtenerSolicitudDetalle(parmSearch);
			respuesta.put("detalleList", detalle);
			view = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		} finally {
			log.debug("Fin - ConsultaSolicitudController.buscarSolicitudDetalle");
		}

		return view;
	}

	/**
	 * Exporta la bandeja a un archivo en formato excel.
	 * 
	 * @author Juan Farro
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 * @see ModelAndView
	 */
	public ModelAndView exportadoExcel(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;

		try {

			log.debug(getClass().getName() + " Inicio del metodo exportadoExcel");

			// recogiendo parametros del request
			String codDependencia = StringUtils.trimToNull(request.getParameter("codDependencia"));
			String codColaborador = StringUtils.trimToNull(request.getParameter("codColaborador"));
			String codEstado = StringUtils.trimToNull(request.getParameter("codEstado"));
			String codCanal = StringUtils.trimToNull(request.getParameter("codCanal"));
			String numPlanilla = StringUtils.trimToNull(request.getParameter("numPlanilla"));
			String fechaDesde = StringUtils.trimToNull(request.getParameter("fechaDesde"));
			String fechaHasta = StringUtils.trimToNull(request.getParameter("fechaHasta"));
			String tipoBandeja = StringUtils.trimToNull(request.getParameter("tipoBandeja"));

			// armando parametros para la búsqueda/exportacion
			Map<String, Object> parmSearch = new HashMap<String, Object>();

			Date fechaDesdeDate = null;
			if (fechaDesde != null && FechaBean.validaFormato(fechaDesde, FechaBean.FORMATO_DEFAULT)) {
				fechaDesdeDate = ViaticoUtil.parseStringDateToDate(fechaDesde);
			}

			Date fechaHastaDate = null;
			if (fechaHasta != null && FechaBean.validaFormato(fechaHasta, FechaBean.FORMATO_DEFAULT)) {
				fechaHastaDate = ViaticoUtil.parseStringDateToDate(fechaHasta);
			}

			parmSearch.put("codColaborador", codColaborador);
			parmSearch.put("codDependencia", codDependencia);
			parmSearch.put("codEstado", codEstado);
			parmSearch.put("codCanal", codCanal);
			parmSearch.put("numPlanilla", numPlanilla);
			parmSearch.put("fechaDesde", fechaDesdeDate);
			parmSearch.put("fechaHasta", fechaHastaDate);
			parmSearch.put("nom_tabla", ViaticoConstantes.ESTADO_VIATICO_NOMBRE_TABLA);
			parmSearch.put("origen", ViaticoConstantes.TIPO_ORIGEN_SOLICITUD_VIATICO);

			// generando lista de solicitudes a exportar
			List<PlanViajeBean> listaSolicitudes = (List<PlanViajeBean>) consultaSolicitudService.obtenerSolicitudesBandejaExportar(parmSearch);

			// nombre de archivo del excel
			String nombreArchivo = ReporteConstantes.ARCHIVO_EXCEL_PREFIJO_SOLICITUDES + FechaUtil.formatDateToDateYYYYMMDDHHMMSS(new Date()) + ReporteConstantes.ARCHIVO_EXCEL_EXTENSION;

			// seteando header excel para el browser
			response.setHeader("Content-Disposition", "attachment; filename=\"" + nombreArchivo + "\"");
			response.setContentType("application/vnd.ms-excel");

			// escribiendo el archivo excel en el flujo salida de la peticion
			viaticoReporteService.generarExcelBandejaSolicitudes(response.getOutputStream(), listaSolicitudes, tipoBandeja);

		} catch (Exception e) {

			log.error(e.getMessage(), e);

		} finally {

		}

		return modelAndView;
	}

	/**
	 * Metodo que permite exportar la bandeja a un archivo en formato excel.
	 * 
	 * @author Juan Farro
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 * @see ModelAndView
	 */
	public ModelAndView exportadoExcelAlta(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;

		try {

			log.debug(getClass().getName() + " Inicio del metodo exportadoExcelAlta");

			// recogiendo parametros del request
			String codDependencia = StringUtils.trimToNull(request.getParameter("codDependencia"));
			String codColaborador = StringUtils.trimToNull(request.getParameter("codColaborador"));
			String fechaHasta = StringUtils.trimToNull(request.getParameter("fechaHasta"));

			String selIndAutorizacion = request.getParameter("selIndAutorizacion");
			log.debug("selIndAutorizacion: " + selIndAutorizacion);

			// armando parametros para la búsqueda/exportacion
			Map<String, Object> parmSearch = new HashMap<String, Object>();

			Date fechaDesdeDate = ViaticoUtil.parseStringDateToDate(ViaticoConstantes.FECHA_INICIO_REFERENCIAL);

			Date fechaHastaDate = null;
			if (fechaHasta != null && FechaBean.validaFormato(fechaHasta, FechaBean.FORMATO_DEFAULT)) {
				fechaHastaDate = ViaticoUtil.parseStringDateToDate(fechaHasta);
			}

			parmSearch.put("codColaborador", codColaborador);
			parmSearch.put("codDependencia", codDependencia);
			parmSearch.put("codEstado", ViaticoConstantes.ESTADO_VIATICO_ELABORADO);
			parmSearch.put("fechaDesde", fechaDesdeDate);
			parmSearch.put("fechaHasta", fechaHastaDate);
			parmSearch.put("nom_tabla", ViaticoConstantes.ESTADO_VIATICO_NOMBRE_TABLA);
			parmSearch.put("origen", null); // que busque tanto solicitudes de viatico como de reembolso
			parmSearch.put("indTraslape", ViaticoConstantes.UNO); // aquellos que tienen traslape
			//parmSearch.put("indAutorizacion", ViaticoConstantes.INDICADOR_AUTORIZACION_SIN_AUTORIZAR); // aquellos que no han sido autorizados

			if ("T".equals(selIndAutorizacion)) {
				String[] listEstadosAutorizacionTraslapeInclusion = new String[3];
				listEstadosAutorizacionTraslapeInclusion[0] = ViaticoConstantes.INDICADOR_AUTORIZACION_SIN_AUTORIZAR;
				listEstadosAutorizacionTraslapeInclusion[1] = ViaticoConstantes.INDICADOR_AUTORIZACION_AUTORIZADO;
				listEstadosAutorizacionTraslapeInclusion[2] = ViaticoConstantes.INDICADOR_AUTORIZACION_RECHAZADO;
				parmSearch.put("listEstadosAutorizacionTraslapeInclusion", listEstadosAutorizacionTraslapeInclusion);
			}
			else if (ViaticoConstantes.INDICADOR_AUTORIZACION_SIN_AUTORIZAR.equals(selIndAutorizacion)) {
				parmSearch.put("indAutorizacion", ViaticoConstantes.INDICADOR_AUTORIZACION_SIN_AUTORIZAR);
			}
			else if (ViaticoConstantes.INDICADOR_AUTORIZACION_AUTORIZADO.equals(selIndAutorizacion)) {
				parmSearch.put("indAutorizacion", ViaticoConstantes.INDICADOR_AUTORIZACION_AUTORIZADO);
			}
			else if (ViaticoConstantes.INDICADOR_AUTORIZACION_RECHAZADO.equals(selIndAutorizacion)) {
				parmSearch.put("indAutorizacion", ViaticoConstantes.INDICADOR_AUTORIZACION_RECHAZADO);
			}
			
			// generando lista de solicitudes a exportar
			List<PlanViajeBean> listaSolicitudes = (List<PlanViajeBean>) consultaSolicitudService.obtenerSolicitudesBandejaExportar(parmSearch);

			// nombre de archivo del excel
			String nombreArchivo = ReporteConstantes.ARCHIVO_EXCEL_PREFIJO_SOLICITUDES + FechaUtil.formatDateToDateYYYYMMDDHHMMSS(new Date()) + ReporteConstantes.ARCHIVO_EXCEL_EXTENSION;

			// seteando header excel para el browser
			response.setHeader("Content-Disposition", "attachment; filename=\"" + nombreArchivo + "\"");
			response.setContentType("application/vnd.ms-excel");

			// escribiendo el archivo excel en el flujo salida de la peticion
			viaticoReporteService.generarExcelBandejaSolicitudes(response.getOutputStream(), listaSolicitudes, ReporteConstantes.TIPO_BANDEJA_ALTA_FECHA_SOLICITUD);

		} catch (Exception e) {

			log.error(e.getMessage(), e);

		} finally {

		}

		return modelAndView;
	}

	/**
	 * Calcula el número dias habiles entre dos fechas y lo retorna al cliente en formato JSON.
	 * 
	 * @author Juan Farro
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 * @see ModelAndView
	 */
	public ModelAndView calcularNroDiasHabiles(HttpServletRequest request, HttpServletResponse response) {

		log.debug(getClass().getName() + " Inicio del metodo calcularNroDiasHabiles");

		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			String fechaInicial = StringUtils.trimToEmpty(request.getParameter("fechaInicial"));
			String fechaFinal = StringUtils.trimToEmpty(request.getParameter("fechaFinal"));

			respuesta.put("nroDias", StringUtils.EMPTY);
			respuesta.put("nroDiasHabiles", StringUtils.EMPTY);

			if (FechaBean.validaFormato(fechaInicial, FechaBean.FORMATO_DEFAULT) && FechaBean.validaFormato(fechaFinal, FechaBean.FORMATO_DEFAULT)) {

				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

				Date fechaInicialDate = sdf.parse(fechaInicial);
				Date fechaFinalDate = sdf.parse(fechaFinal);

				// obtener el número de dias y número de dias habiles
				respuesta.put("nroDias", ViaticoUtil.restarDias(fechaFinalDate, fechaInicialDate) + 1);
				respuesta.put("nroDiasHabiles", viaticoService.calcularDiasHabiles(fechaInicialDate, fechaFinalDate));

			}

			respuesta.put("error", "no");
			respuesta.put("msgError", StringUtils.EMPTY);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {

			log.error(e.getMessage(), e);

			// INDICADORES QUE LA PETICION AJAX CULMINO CON ERRORES.
			// NOTA: El key msgError se usa como mensaje generico de error no manejable. 
			//       Otros keys del mapa respuesta se usan para personalizar los mensajes de negocio visibles al usuario.
			respuesta.put("error", "si");
			respuesta.put("msgError", ViaticoConstantes.MSG_ERROR_OPERACION_NO_EFECTUADA);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} finally {

			log.debug(getClass().getName() + " Fin del metodo calcularNroDiasHabiles");
		}

		return modelAndView;
	}

	/**
	 * Calcula la fecha maxima rendicion y lo retorna al cliente en formato JSON.
	 * 
	 * @author Juan Farro
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion en formato JSON
	 * @see ModelAndView
	 */
	public ModelAndView calcularFechaMaximaRendicion(HttpServletRequest request, HttpServletResponse response) {

		log.debug(getClass().getName() + " Inicio del metodo calcularFechaMaximaRendicion");

		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			String tipoViatico = StringUtils.trimToEmpty(request.getParameter("tipoViatico"));
			String duracionComision = StringUtils.trimToEmpty(request.getParameter("duracionComision"));
			String canalAtencion = StringUtils.trimToEmpty(request.getParameter("canalAtencion"));
			String fechaFinal = StringUtils.trimToEmpty(request.getParameter("fechaFinal"));

			boolean esNacional = StringUtils.equals(tipoViatico, ViaticoConstantes.VISTA_TIPO_VIATICO_NACIONAL);
			boolean esInternacional = StringUtils.equals(tipoViatico, ViaticoConstantes.VISTA_TIPO_VIATICO_INTERNACIONAL);
			boolean esMayor4h = StringUtils.equals(duracionComision, ViaticoConstantes.VISTA_DURACION_COMISION_MAYOR4H);
			boolean esMenorIgual4h = StringUtils.equals(duracionComision, ViaticoConstantes.VISTA_DURACION_COMISION_MENOR_IGUAL4h);

			Date fechaMaximaRendicion = null;
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

			if (FechaBean.validaFormato(fechaFinal, FechaBean.FORMATO_DEFAULT)) {

				Date fechaFinalDate = sdf.parse(fechaFinal);

				if (esNacional) {

					if (esMayor4h) {

						if (StringUtils.equals(canalAtencion, ViaticoConstantes.CANAL_ATENCION_CAJACHICA)) {

							fechaMaximaRendicion = viaticoService.sumarDiasHabiles(fechaFinalDate, ViaticoConstantes.FECHA_MAXIMA_DIAS_NACIONAL_CAJACHICA);

						} else if (StringUtils.equals(canalAtencion, ViaticoConstantes.CANAL_ATENCION_REEMBOLSO)) {

							fechaMaximaRendicion = viaticoService.sumarDiasHabiles(fechaFinalDate, ViaticoConstantes.FECHA_MAXIMA_DIAS_NACIONAL_ABONOCUENTA);
						}

					} else if (esMenorIgual4h) {

						fechaMaximaRendicion = viaticoService.sumarDiasHabiles(fechaFinalDate, ViaticoConstantes.FECHA_MAXIMA_DIAS_NACIONAL_CAJACHICA);
					}

				} else if (esInternacional) {

					Date fechaFinalMas15 = ViaticoUtil.addDiasToDate(fechaFinalDate, ViaticoConstantes.FECHA_MAXIMA_DIAS_INTERNACIONAL_CALENDARIO);
					fechaMaximaRendicion = viaticoService.sumarDiasHabiles(fechaFinalMas15, ViaticoConstantes.FECHA_MAXIMA_DIAS_INTERNACIONAL);
				}

			}

			respuesta.put("fechaMaximaRendicion", fechaMaximaRendicion == null ? StringUtils.EMPTY : sdf.format(fechaMaximaRendicion));

			respuesta.put("error", "no");
			respuesta.put("msgError", StringUtils.EMPTY);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {

			log.error(e.getMessage(), e);

			// INDICADORES QUE LA PETICION AJAX CULMINO CON ERRORES.
			// NOTA: El key msgError se usa como mensaje generico de error no manejable. 
			//       Otros keys del mapa respuesta se usan para personalizar los mensajes de negocio visibles al usuario.
			respuesta.put("error", "si");
			respuesta.put("msgError", ViaticoConstantes.MSG_ERROR_OPERACION_NO_EFECTUADA);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} finally {

			log.debug(getClass().getName() + " Fin del metodo calcularFechaMaximaRendicion");
		}

		return modelAndView;
	}

	/**
	 * Metodo que permite obtener plan viaje con su detalle de la bandeja solicitud.
	 * 
	 * @author Jorge Ponce.
	 * @param request: objeto de la clase HttpServletRequest.
	 * @param response: objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	public ModelAndView obtenerPlanViajeDetalleBandejaSolicitud(HttpServletRequest request, HttpServletResponse response) {

		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoConsulta = SolicitudConstantes.ERROR_CONSULTA;
		String errorMessage = SolicitudConstantes.CADENA_VACIA;

		try {
			log.debug(ConsultaSolicitudController.class.getSimpleName() + ".obtenerPlanViajeDetalleBandejaSolicitud");
			String codPlanViaje = request.getParameter("codPlanViaje");
			codPlanViaje = FormatoUtil.validarEmptyToNull(codPlanViaje);
			ArrayList<PlanViajeBean> planViajeList = consultaSolicitudService.obtenerPlanViajeDetalleToBandejaSolicitud(codPlanViaje, null, null, null, null, null, null, null, null);
			if (planViajeList != null && !planViajeList.isEmpty()) {
				PlanViajeBean planViajeBean = planViajeList.get(0);
				codigoConsulta = SolicitudConstantes.EXITO_CONSULTA;
				respuesta.put("planViajeBean", planViajeBean);
			}
			log.debug(ConsultaSolicitudController.class.getSimpleName() + ".obtenerPlanViajeDetalleBandejaSolicitud.fin");

		} catch (Exception e) {
			errorMessage = ResourceBundleUtil.getMessage(SolicitudConstantes.MENSAJE_ERROR_GENERICO);
			log.error(e.getMessage(), e);
		}

		respuesta.put("codigoConsulta", codigoConsulta);
		respuesta.put("errorMessage", errorMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}

	/**
	 * Metodo que permite obtener importe diario.
	 * 
	 * @author Juan Farro
	 * @see ModelAndView
	 * @param request objeto peticion de la clase HttpServletRequest
	 * @param response objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion en formato JSON
	 */
	public ModelAndView obtenerImporteDiario(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();

		try {

			log.debug(getClass().getName() + " Inicio del metodo obtenerImporteDiario");

			String tipoViatico = StringUtils.trimToEmpty(request.getParameter("tipoViatico"));
			String codigoDepartamento = StringUtils.trimToEmpty(request.getParameter("codigoDepartamento"));
			String codigoProvincia = StringUtils.trimToEmpty(request.getParameter("codigoProvincia"));
			String codigoUbigeo = StringUtils.trimToEmpty(request.getParameter("codigoUbigeo"));
			String codColaborador = StringUtils.trimToEmpty(request.getParameter("codColaborador"));

//			String provinciaPuntoPartida = StringUtils.trimToEmpty(request.getParameter("provinciaPuntoPartida"));
			String departamentoPuntoPartida = StringUtils.trimToEmpty(request.getParameter("departamentoPuntoPartida"));

			boolean esTarifarioRegional = StringUtils.equals(viaticosTarifarioSingleton.obtenerTarifario(), ViaticoConstantes.TIPO_TARIFARIO_REGIONAL);

			String anioActual = FechaUtil.obtenerAnioActual();
			String nivelViatico = buscarNivelViatico(codColaborador);

			ConceptoPlanillaViaticosBean conceptoPlanillaViatico = null;

			if (StringUtils.equals(tipoViatico, ViaticoConstantes.BUSCAR_CONCEPTO_VIATICO_FILTRO_NACIONAL)) {

				if (esTarifarioRegional) {
					
					// tarifario regional
					if( StringUtils.equals(departamentoPuntoPartida, codigoDepartamento)) {
						
						// si se traslada (siempre considerando el punto de origen) en el mismo departamento, considera la provincia
						conceptoPlanillaViatico = viaticoService.obtenerImporteDiarioNacional(anioActual, codigoDepartamento, codigoProvincia, nivelViatico);
						
						// por acta reunion: toma tarifa nacional si no hay tarifa regional
						if ( conceptoPlanillaViatico == null ) {
							conceptoPlanillaViatico = viaticoService.obtenerImporteDiarioNacional(anioActual, ViaticoConstantes.CODIGO_00, ViaticoConstantes.CODIGO_00, nivelViatico);	
						}
						
					} else {
						
						// si se traslada (siempre considerando el punto de origen) a otro departamento, se toma la tarifa nacional
						conceptoPlanillaViatico = viaticoService.obtenerImporteDiarioNacional(anioActual, ViaticoConstantes.CODIGO_00, ViaticoConstantes.CODIGO_00, nivelViatico);
					}

				} else {
					
					// tarifario nacional
					conceptoPlanillaViatico = viaticoService.obtenerImporteDiarioNacional(anioActual, ViaticoConstantes.CODIGO_00, ViaticoConstantes.CODIGO_00, nivelViatico);
				}

			} else if (StringUtils.equals(tipoViatico, ViaticoConstantes.BUSCAR_CONCEPTO_VIATICO_FILTRO_INTERNACIONAL)) {

				conceptoPlanillaViatico = viaticoService.obtenerImporteDiarioInternacional(anioActual, codigoUbigeo, nivelViatico);
			}

			respuesta.put("hayImporte", ViaticoConstantes.NO);

			if (conceptoPlanillaViatico != null) {

				respuesta.put("hayImporte", ViaticoConstantes.SI);

				respuesta.put("codigoConcepto", conceptoPlanillaViatico.getCodigoConcepto());
				respuesta.put("descripcionConcepto", conceptoPlanillaViatico.getDescripcionConcepto());
				respuesta.put("clasificadorGasto", conceptoPlanillaViatico.getClasificadorGasto());
				respuesta.put("montoDiario", conceptoPlanillaViatico.getImporteDiario());
				respuesta.put("cantidadPVI", StringUtils.EMPTY);

			}

			// INDICADORES QUE LA PETICIÓN AJAX CULMINÓ OK SIN ERRORES
			respuesta.put("error", ViaticoConstantes.NO);
			respuesta.put("msgError", StringUtils.EMPTY);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} catch (Exception e) {

			log.error(e.getMessage(), e);

			// INDICADORES QUE LA PETICION AJAX CULMINO CON ERRORES.
			// NOTA: El key msgError se usa como mensaje generico de error no manejable. 
			//       Otros keys del mapa respuesta se usan para personalizar los mensajes de negocio visibles al usuario.
			respuesta.put("error", ViaticoConstantes.SI);
			respuesta.put("msgError", ViaticoConstantes.MSG_ERROR_OPERACION_NO_EFECTUADA);

			modelAndView = new ModelAndView(getJsonView(), respuesta);

		} finally {

			log.debug(getClass().getName() + " Fin del metodo obtenerImporteDiario");
		}

		return modelAndView;
	}

	/**
	 * Metodo que permite obtener el nivel de viatico de un colaborador
	 * 
	 * @author Juan Farro
	 * @param codColaborador codigo del colaborador
	 * @return nivel de viatico del colaborador
	 * @throws Exception
	 */
	private String buscarNivelViatico(String codColaborador) throws Exception {

		// por default el nivel es 003 - otros (no intendente)
		String nivelViatico = ViaticoConstantes.NIVEL_VIATICO_OTROS;

		// traer informacion adicional del colaborador (ademas de datos de su dependencia)
		MaestroPersonalBean colaborador = registroPersonalService.obtenerPersonaxCodigo(codColaborador);

		// retorna el nivel de viatico default
		if (colaborador == null) return nivelViatico;

		String nivelColaborador = colaborador.getCodigoNivel();

		// buscamos el nivel en la tabla niveles usando el nivel del colaborador
		NivelBean nivel = consultaSolicitudService.buscarNivelViatico(nivelColaborador);

		if (nivel != null) {

			// si en niveles existe nivel de viatico, lo asigna
			if (StringUtils.isNotBlank(nivel.getNivelViatico())) {

				nivelViatico = StringUtils.trimToEmpty(nivel.getNivelViatico());

			} else {

				// extrae el codigo del jefe de la dependencia (TDEPENDENCIA.CODI_EMPL_PER)
				String empleadoDependencia = StringUtils.trimToEmpty(colaborador.getCodigoJefeUuoo());

				// si el colaborador del viatico es el jefe de la dependencia, busca la categoria de dependencia
				if (StringUtils.equals(codColaborador, empleadoDependencia)) {

					// categria viatico de la dependencia (TDEPENDENCIA.COD_CATEG_VIATICO)
					String categoriaDependencia = colaborador.getCategoriaViatico();

					if (StringUtils.isNotBlank(categoriaDependencia)) {
						nivelViatico = StringUtils.trimToEmpty(categoriaDependencia);
					}

				}
			}

		}

		return nivelViatico;
	}

}
