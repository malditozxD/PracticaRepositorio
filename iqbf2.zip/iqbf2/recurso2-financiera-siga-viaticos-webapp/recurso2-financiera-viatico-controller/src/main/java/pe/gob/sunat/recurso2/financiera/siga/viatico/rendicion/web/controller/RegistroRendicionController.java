package pe.gob.sunat.recurso2.financiera.siga.viatico.rendicion.web.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.administracion.siga.util.FechaConstantes;
import pe.gob.sunat.recurso2.administracion.siga.util.FechaUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.FormatoConstantes;
import pe.gob.sunat.recurso2.administracion.siga.util.FormatoUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.NumeroUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ComprobanteIngresoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PapeletaDepositoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeConceptoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeInformeDistribBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeRendicionBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.rendicion.service.ConsultaRendicionService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.rendicion.service.RegistroRendicionService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoConsultaService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.service.ConsultaSolicitudService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.RendicionConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.RendicionUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ResourceBundleUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.controller.BaseController;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.singleton.ViaticosProcesoSingleton;
import pe.gob.sunat.recurso2.financiera.siga.viatico.web.view.RendicionVO;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

/**
 * Controller que contiene los metodos necesarios para registrar una rendicion.
 * @author Jorge Ponce.
 */
public class RegistroRendicionController extends BaseController {
	
	protected final Log log = LogFactory.getLog(getClass());
	private RegistroRendicionService registroRendicionService;
	private ConsultaRendicionService consultaRendicionService;
	private ViaticoConsultaService viaticoConsultaService;
	private RegistroPersonalService registroPersonalService;
	private ViaticosProcesoSingleton viaticosProcesoSingleton;
	private ConsultaSolicitudService consultaSolicitudService;
	
	public RegistroRendicionService getRegistroRendicionService() {
		return registroRendicionService;
	}

	public void setRegistroRendicionService(RegistroRendicionService registroRendicionService) {
		this.registroRendicionService = registroRendicionService;
	}

	public ConsultaRendicionService getConsultaRendicionService() {
		return consultaRendicionService;
	}

	public void setConsultaRendicionService(ConsultaRendicionService consultaRendicionService) {
		this.consultaRendicionService = consultaRendicionService;
	}

	public ViaticoConsultaService getViaticoConsultaService() {
		return viaticoConsultaService;
	}

	public void setViaticoConsultaService(ViaticoConsultaService viaticoConsultaService) {
		this.viaticoConsultaService = viaticoConsultaService;
	}

	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}

	public ViaticosProcesoSingleton getViaticosProcesoSingleton() {
		return viaticosProcesoSingleton;
	}

	public void setViaticosProcesoSingleton(ViaticosProcesoSingleton viaticosProcesoSingleton) {
		this.viaticosProcesoSingleton = viaticosProcesoSingleton;
	}

	/**
	 * Metodo que permite mostrar la pagina de registrar/modificar rendicion.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView.
	 * @see ModelAndView
	 */
	public ModelAndView mostrarRegistrarRendicion(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView modelAndView = null;
		String errorMessage = RendicionConstantes.CADENA_VACIA;
		
		try {
			log.debug(RegistroRendicionController.class.getSimpleName() + ".mostrarRegistrarRendicion");
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			String loginUsuario = usuarioBean.getLogin();
			String numeroRegistro = usuarioBean.getNroRegistro();
			MaestroPersonalBean maestroPersonalBean = registroPersonalService.obtenerPersonaxRegistro(numeroRegistro);
			RendicionVO rendicionVO = RendicionUtil.obtenerRendicionVO(usuarioBean, maestroPersonalBean);
			if (rendicionVO != null) {
				String requestValue =  request.getParameter("variableSendPost");
				String codPlanViaje = FormatoUtil.obtenerValueParameterRequest(requestValue, "codPlanViaje");
				//String codPlanViaje = request.getParameter("codPlanViaje");
				codPlanViaje = FormatoUtil.validarEmptyToNull(codPlanViaje);
				if (codPlanViaje != null) {
					PlanViajeBean planViajeBean = consultaRendicionService.obtenerPlanViaje(codPlanViaje);
					if (planViajeBean != null) {
						boolean esNacional = StringUtils.equals(planViajeBean.getTipoDestino(), ViaticoConstantes.TIPO_COMISION_NACIONAL);
						boolean esInternacional = StringUtils.equals(planViajeBean.getTipoDestino(), ViaticoConstantes.TIPO_COMISION_INTERNACIONAL);
						log.debug("es nacional o internacional: " +esNacional + " " + esInternacional);
						
						String codigoPlanViaje = planViajeBean.getCodPlanViaje();
						rendicionVO.setCodigoPlanViaje(codigoPlanViaje);
						rendicionVO.setCodigoPlanilla(planViajeBean.getCodPlanilla());
						rendicionVO.setExpedientePlanViaje(planViajeBean.getExpedientePlanViaje());
						rendicionVO.setExpedienteRendicion(planViajeBean.getExpedienteRendicion());
						rendicionVO.setCodigoColaborador(planViajeBean.getCodTrabajador());
						rendicionVO.setNumeroRegistroColaborador(planViajeBean.getNumeroRegistroAlterno());
						rendicionVO.setNombreColaborador(planViajeBean.getNomColaborador());
						rendicionVO.setCodigoEstadoRendicion(planViajeBean.getCodEstadoRend());
						rendicionVO.setDescripcionEstadoRendicion(planViajeBean.getNomEstRend());
						rendicionVO.setTipoDestino(planViajeBean.getTipoDestino());
						rendicionVO.setFechaRegistroRendicion(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFechaRegistroRendicion()));
						
						//JMCR-ME Hora < 4 Rendicion
						rendicionVO.setFechaSalidaProgramada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecSalida()));
						rendicionVO.setFechaRetornoProgramada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecRetorno()));
						
						rendicionVO.setHoraSalidaProgramada(formatDateToHourHHMM(planViajeBean.getFecSalida()));
						rendicionVO.setHoraRetornoProgramada(formatDateToHourHHMM(planViajeBean.getFecRetorno()));
						
						if(ViaticoConstantes.UNO.equals(planViajeBean.getIndicadorHoras())){
						}
						
						if (planViajeBean.getFecSalidaEjecutada() != null && planViajeBean.getFecRetornoEjecutada() != null) {							
							// cuando el viatico es menor a cuatro horas siempre se fuerza a que sea las fechas programadas
							if(ViaticoConstantes.UNO.equals(planViajeBean.getIndicadorHoras())){
								rendicionVO.setFechaSalidaEjecutada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecSalida()));
								rendicionVO.setFechaRetornoEjecutada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecRetorno()));
							}
							
							rendicionVO.setFechaSalidaEjecutada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecSalidaEjecutada()));
							rendicionVO.setFechaRetornoEjecutada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecRetornoEjecutada()));

							rendicionVO.setHoraSalidaEjecutada(formatDateToHourHHMM(planViajeBean.getFecSalidaEjecutada()));
							rendicionVO.setHoraRetornoEjecutada(formatDateToHourHHMM(planViajeBean.getFecRetornoEjecutada()));

							rendicionVO.setFlagFechaHoraSalidaValida(RendicionConstantes.UNO);
							rendicionVO.setFlagFechaHoraRetornoValida(RendicionConstantes.UNO);
						}
						else {
							rendicionVO.setFlagFechaHoraSalidaValida(RendicionConstantes.CERO);
							rendicionVO.setFlagFechaHoraRetornoValida(RendicionConstantes.CERO);

							//JMCR-ME fecha default
							
							if (esNacional) {
								rendicionVO.setFlagFechaHoraSalidaValida(RendicionConstantes.UNO);
								rendicionVO.setFlagFechaHoraRetornoValida(RendicionConstantes.UNO);
	
								rendicionVO.setFechaSalidaEjecutada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecSalida()));
								rendicionVO.setFechaRetornoEjecutada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecRetorno()));

								rendicionVO.setHoraSalidaEjecutada(formatDateToHourHHMM(planViajeBean.getFecSalida()));
								rendicionVO.setHoraRetornoEjecutada(formatDateToHourHHMM(planViajeBean.getFecRetorno()));
								
								if(ViaticoConstantes.UNO.equals(planViajeBean.getIndicadorHoras())){
								}								
							}
							else if (esInternacional){
								log.debug("fechas: " + planViajeBean.getFechaItinerarioSalida() + " " + planViajeBean.getFechaItinerarioRetorno());
								rendicionVO.setFlagFechaHoraSalidaValida(RendicionConstantes.UNO);
								rendicionVO.setFlagFechaHoraRetornoValida(RendicionConstantes.UNO);

								rendicionVO.setFechaSalidaEjecutada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFechaItinerarioSalida()));
								rendicionVO.setFechaRetornoEjecutada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFechaItinerarioRetorno()));

								rendicionVO.setHoraSalidaEjecutada(formatDateToHourHHMM(planViajeBean.getFechaItinerarioSalida()));
								rendicionVO.setHoraRetornoEjecutada(formatDateToHourHHMM(planViajeBean.getFechaItinerarioRetorno()));
							}
							
							//JMCR-ME fecha default
							//JMCR-ME Hora < 4 Rendicion
						}
						rendicionVO.setMoneda(planViajeBean.getMoneda());
						rendicionVO.setMontoRendirTotal(planViajeBean.getMtoTotal());
						rendicionVO.setMontoRendirTotalFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getMtoTotal(), 2));
						rendicionVO.setCodigoCanalAtencion(planViajeBean.getIndicadorCanalAtencion());
						rendicionVO.setCanalAtencion(planViajeBean.getCanalAtencion());
						rendicionVO.setFechaMaximaRendicion(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecMaxRend()));
						rendicionVO.setIndicadorExteriorDDJJ(planViajeBean.getIndicadorExteriorDDJJ());
						rendicionVO.setIndicadorMenorGasto(planViajeBean.getIndicadorMenorGasto());
						
						ArrayList<ComprobanteIngresoBean> comprobanteIngresoList = null;
						if (codigoPlanViaje != null && !RendicionConstantes.CADENA_VACIA.equals(codigoPlanViaje)) {
							//comprobanteIngresoList = consultaRendicionService.obtenerRecibosIngresoCaja("020201500235");
							comprobanteIngresoList = consultaRendicionService.obtenerRecibosIngresoCaja(codigoPlanViaje);
							if (comprobanteIngresoList != null && !comprobanteIngresoList.isEmpty()) {
								rendicionVO.setFlagAsociadoRIC(RendicionConstantes.UNO);
							}
							else {
								rendicionVO.setFlagAsociadoRIC(RendicionConstantes.CERO);
							}
						}
						String flagHabilitar = consultaRendicionService.obtenerFlagHabilitarCerrarRendicion(planViajeBean.getMtoTotal(), planViajeBean.getMontoDevuelto(), planViajeBean.getMontoDevol(), planViajeBean.getIndicadorMenorGasto());
						log.info("2. setting --> flagHabilitar:"+flagHabilitar);
						rendicionVO.setFlagHabilitarCerrarRendicion(flagHabilitar);
						log.info("3. getting --> flagHabilitar:"+rendicionVO.getFlagHabilitarCerrarRendicion());
						rendicionVO.setFlagMenorIgual4Horas(viaticoConsultaService.obtenerFlagMenorIgual4Horas(planViajeBean.getIndicadorHoras(), planViajeBean.getNumeroHoras()));
						String procesoViatico = viaticosProcesoSingleton.obtenerProceso();
						rendicionVO.setProcesoViatico(procesoViatico);
						if (RendicionConstantes.PROCESO_MANUAL.equals(procesoViatico)) {
							rendicionVO.setFlagMostrarImprimir(RendicionConstantes.UNO);
						}
						
						if(!planViajeBean.getCodTrabajador().equals(maestroPersonalBean.getCodigoEmpleado())){
							rendicionVO.setEsRegistrador(true);
					}
				}
			}
			}
			respuesta.put("rendicionVO", rendicionVO);
			respuesta.put("loginUsuario", loginUsuario);
			log.debug(RegistroRendicionController.class.getSimpleName() + ".mostrarRegistrarRendicion.fin");
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			errorMessage = ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO);
			respuesta.put("errorMessage", errorMessage);
		}
		modelAndView = new ModelAndView(RendicionConstantes.REGISTRAR_MODIFICAR_RENDICION_VIATICO_PAGE, respuesta);
		return modelAndView;
	}
	
	private Integer[] valueHHMMToInteger(String hourString) {
		
		Integer[] resultado = new Integer[2];
		resultado[0] = 0;
		resultado[1] = 0;
		
		try{
			if (hourString != null && hourString.contains(FormatoConstantes.DOS_PUNTOS)) {
				String[] arrayHour = hourString.split(FormatoConstantes.DOS_PUNTOS);
				if (arrayHour.length >= 2) {
					resultado[0] = Integer.parseInt(arrayHour[0]);
					resultado[1] = Integer.parseInt(arrayHour[1]);
				}
			}			
		}
		catch (Exception e) {
			log.debug("Error en la conversion de la hora ", e);
		}
		
		return resultado;
	}
	
	private String formatDateToHourHHMM(Date date) {
		String formatDate = FormatoConstantes.CADENA_VACIA;
		if (date != null) {
			SimpleDateFormat sdf = new SimpleDateFormat(FechaConstantes.DATE_FORMAT_HHMM, Locale.getDefault());
			formatDate = sdf.format(date);
		}
		return formatDate;
	}
	
	/**
	 * Metodo que permite registrar la rendicion.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	public ModelAndView registrarRendicion(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoOperacion = RendicionConstantes.ERROR_OPERACION;
		String flagHabilitarCerrarRendicion = RendicionConstantes.CERO;
		String errorMessage = RendicionConstantes.CADENA_VACIA;
		String successMessage = RendicionConstantes.CADENA_VACIA;
		
		try {
			log.debug(RegistroRendicionController.class.getSimpleName() + ".registrarRendicion");
			String codPlanViaje = request.getParameter("codPlanViaje");
			String fechaRegistroRendicionString = request.getParameter("fechaRegistroRendicion");
			String fecSalidaEjecutadaString = request.getParameter("fecSalidaEjecutada");
			String fecRetornoEjecutadaString = request.getParameter("fecRetornoEjecutada");

			//JMCR-ME Hora < 4 Rendicion			fecSalidaEjecutadaString = FormatoUtil.validarEmptyToNull(fecSalidaEjecutadaString);
			String horaSalidaEjecutadaString = request.getParameter("horaSalidaEjecutada");
			String horaRetornoEjecutadaString = request.getParameter("horaRetornoEjecutada");
			//JMCR-ME Hora < 4 Rendicion			fecSalidaEjecutadaString = FormatoUtil.validarEmptyToNull(fecSalidaEjecutadaString);

			String montoDevueltoComprobanteTotalString = request.getParameter("montoDevueltoComprobanteTotal");
			String montoDevueltoVoucherRICTotalString = request.getParameter("montoDevueltoVoucherRICTotal");
			String indicadorExteriorDDJJ = request.getParameter("indicadorExteriorDDJJ");
			String indicadorMenorGasto = request.getParameter("indicadorMenorGasto");
			String tipoDestino = request.getParameter("tipoDestino");
			String flagMenorIgual4Horas = request.getParameter("flagMenorIgual4Horas");
			String flagDeclaracion = request.getParameter("flagDeclaracion");
			String numeroDeclaracionViaticoString = request.getParameter("numeroDeclaracionViatico");
			String montoDeclaracionTotalString = request.getParameter("montoDeclaracionTotal");
			String montoDeclaracionViaticoString = request.getParameter("montoDeclaracionViatico");
			String montoAsignadoTotalString = request.getParameter("montoAsignadoTotal");
			String montoAsignacionViaticoString = request.getParameter("montoAsignacionViatico");
			String simboloMoneda = request.getParameter("simboloMoneda");
			String codigoRegistrador = request.getParameter("codigoRegistrador");
			String codigoSedeRegistrador = request.getParameter("codigoSedeRegistrador");
			
			Date fechaRegistroRendicion = null;
			Date fecSalidaEjecutada = null;
			Date fecRetornoEjecutada = null;
			
			//JMCR-ME Hora < 4 Rendicion			fecSalidaEjecutadaString = FormatoUtil.validarEmptyToNull(fecSalidaEjecutadaString);
			Integer[] horaSalidaEjecutadaArray = null;
			Integer[] horaRetornoEjecutadaArray = null;
			//JMCR-ME Hora < 4 Rendicion			fecSalidaEjecutadaString = FormatoUtil.validarEmptyToNull(fecSalidaEjecutadaString);
			
			Double montoDevuelto = null;
			Double montoDevol = null;
			int numeroDeclaracionViatico = 0;
			BigDecimal montoDeclaracionTotal = BigDecimal.ZERO;
			BigDecimal montoDeclaracionViatico = BigDecimal.ZERO;
			BigDecimal montoAsignadoTotal = BigDecimal.ZERO;
			BigDecimal montoAsignacionViatico = BigDecimal.ZERO;
			
			codPlanViaje = FormatoUtil.validarEmptyToNull(codPlanViaje);
			tipoDestino = FormatoUtil.validarEmptyToNull(tipoDestino);
			flagMenorIgual4Horas = FormatoUtil.validarEmptyToNull(flagMenorIgual4Horas);
			flagDeclaracion = FormatoUtil.validarEmptyToNull(flagDeclaracion);
			fechaRegistroRendicionString = FormatoUtil.validarEmptyToNull(fechaRegistroRendicionString);
			if (fechaRegistroRendicionString == null) {
				fechaRegistroRendicion =  FechaUtil.parseStringDateToDate(FechaUtil.obtenerFechaActual(), RendicionConstantes.DATE_FORMAT_DDMMYYYY);
			}
			
			
			fecSalidaEjecutadaString = FormatoUtil.validarEmptyToNull(fecSalidaEjecutadaString);
			if (fecSalidaEjecutadaString != null) {
				fecSalidaEjecutada = FechaUtil.parseStringDateToDate(fecSalidaEjecutadaString, RendicionConstantes.DATE_FORMAT_DDMMYYYY);
			}
			
			fecRetornoEjecutadaString = FormatoUtil.validarEmptyToNull(fecRetornoEjecutadaString);
			if (fecRetornoEjecutadaString != null) {
				fecRetornoEjecutada = FechaUtil.parseStringDateToDate(fecRetornoEjecutadaString, RendicionConstantes.DATE_FORMAT_DDMMYYYY);
			}
			
			//JMCR-ME Hora < 4 Rendicion	
			horaSalidaEjecutadaString = FormatoUtil.validarEmptyToNull(horaSalidaEjecutadaString);
			if (horaSalidaEjecutadaString != null) {			
				try {
					horaSalidaEjecutadaArray = valueHHMMToInteger(horaSalidaEjecutadaString);
					
					Calendar calSalidaEjecutada = Calendar.getInstance();
					calSalidaEjecutada.setTime(fecSalidaEjecutada);
					calSalidaEjecutada.add(Calendar.HOUR_OF_DAY, horaSalidaEjecutadaArray[0]);
					calSalidaEjecutada.add(Calendar.MINUTE, horaSalidaEjecutadaArray[1]);
					
					fecSalidaEjecutada = calSalidaEjecutada.getTime();					
				}
				catch (Exception e) {
					log.debug("Error en conversion de fecha: ", e);
				}
			}

			horaRetornoEjecutadaString = FormatoUtil.validarEmptyToNull(horaRetornoEjecutadaString);
			if (horaRetornoEjecutadaString != null) {
				try {
					horaRetornoEjecutadaArray = valueHHMMToInteger(horaRetornoEjecutadaString);
					
					Calendar calRetornoEjecutada = Calendar.getInstance();
					calRetornoEjecutada.setTime(fecRetornoEjecutada);
					calRetornoEjecutada.add(Calendar.HOUR_OF_DAY, horaRetornoEjecutadaArray[0]);
					calRetornoEjecutada.add(Calendar.MINUTE, horaRetornoEjecutadaArray[1]);
					
					fecRetornoEjecutada = calRetornoEjecutada.getTime();					
				}
				catch (Exception e) {
					log.debug("Error en conversion defecha: ", e);
				}
			}
			//JMCR-ME Hora < 4 Rendicion			
			
			montoDevueltoComprobanteTotalString = FormatoUtil.validarEmptyToNull(montoDevueltoComprobanteTotalString);
			if (montoDevueltoComprobanteTotalString != null) {
				montoDevuelto = new Double(montoDevueltoComprobanteTotalString);
			}
			
			montoDevueltoVoucherRICTotalString = FormatoUtil.validarEmptyToNull(montoDevueltoVoucherRICTotalString);
			if (montoDevueltoVoucherRICTotalString != null) {
				montoDevol = new Double(montoDevueltoVoucherRICTotalString);
			}
			
			indicadorExteriorDDJJ = FormatoUtil.validarEmptyToNull(indicadorExteriorDDJJ);
			if (indicadorExteriorDDJJ == null) {
				indicadorExteriorDDJJ = RendicionConstantes.INDICADOR_EXT_DDJJ_NO;
			}
			
			indicadorMenorGasto = FormatoUtil.validarEmptyToNull(indicadorMenorGasto);
			if (indicadorMenorGasto == null) {
				indicadorMenorGasto = RendicionConstantes.INDICADOR_MEN_GAST_NO;
			}
			
			numeroDeclaracionViaticoString = FormatoUtil.validarEmptyToNull(numeroDeclaracionViaticoString);
			if (numeroDeclaracionViaticoString != null) {
				numeroDeclaracionViatico = Integer.parseInt(numeroDeclaracionViaticoString);
			}
			
			montoDeclaracionTotalString = FormatoUtil.validarEmptyToNull(montoDeclaracionTotalString);
			if (montoDeclaracionTotalString != null) {
				montoDeclaracionTotal = new BigDecimal(montoDeclaracionTotalString);
			}
			
			montoDeclaracionViaticoString = FormatoUtil.validarEmptyToNull(montoDeclaracionViaticoString);
			if (montoDeclaracionViaticoString != null) {
				montoDeclaracionViatico = new BigDecimal(montoDeclaracionViaticoString);
			}
			
			montoAsignadoTotalString = FormatoUtil.validarEmptyToNull(montoAsignadoTotalString);
			if (montoAsignadoTotalString != null) {
				montoAsignadoTotal = new BigDecimal(montoAsignadoTotalString);
			}
			
			montoAsignacionViaticoString = FormatoUtil.validarEmptyToNull(montoAsignacionViaticoString);
			if (montoAsignacionViaticoString != null) {
				montoAsignacionViatico = new BigDecimal(montoAsignacionViaticoString);
			}
			
			if (codPlanViaje != null) {
				setAuditoriaBeanHolder(request, response);
				PlanViajeBean planViajeBean = new PlanViajeBean();
				planViajeBean.setCodPlanViaje(codPlanViaje);
				planViajeBean.setFechaRegistroRendicion(fechaRegistroRendicion);
				planViajeBean.setFecSalidaEjecutada(fecSalidaEjecutada);
				planViajeBean.setFecRetornoEjecutada(fecRetornoEjecutada);
				planViajeBean.setMontoDevuelto(montoDevuelto);
				planViajeBean.setMontoDevol(montoDevol);
				planViajeBean.setIndicadorExteriorDDJJ(indicadorExteriorDDJJ);
				planViajeBean.setIndicadorMenorGasto(indicadorMenorGasto);
				planViajeBean.setTipoDestino(tipoDestino);
				planViajeBean.setFlagMenorIgual4Horas(flagMenorIgual4Horas);
				planViajeBean.setFlagDeclaracion(flagDeclaracion);
				planViajeBean.setNumeroDeclaracionViatico(numeroDeclaracionViatico);
				planViajeBean.setMontoDeclaracionTotal(montoDeclaracionTotal);
				planViajeBean.setMontoDeclaracionViatico(montoDeclaracionViatico);
				planViajeBean.setMontoAsignadoTotal(montoAsignadoTotal);
				planViajeBean.setMontoAsignacionViatico(montoAsignacionViatico);
				planViajeBean.setMoneda(simboloMoneda);
				codigoOperacion = registroRendicionService.registrarRendicion(planViajeBean, codigoRegistrador, codigoSedeRegistrador);
				flagHabilitarCerrarRendicion = consultaRendicionService.obtenerFlagHabilitarCerrarRendicion(montoAsignadoTotalString, montoDevuelto, montoDevol, indicadorMenorGasto);
				successMessage = ResourceBundleUtil.getMessageRendicion(RendicionConstantes.MENSAJE_REGISTRO_RENDICION_EXITOSO);
			}
			else {
				errorMessage = ResourceBundleUtil.getMessage(RendicionConstantes.MENSAJE_ERROR_GENERICO);
			}
			log.debug(RegistroRendicionController.class.getSimpleName() + ".registrarRendicion.fin");

		} catch (ServiceException ex) {
			errorMessage = ex.getMessage();
			log.error(ex.getMessage(), ex);
			
		} catch (Exception ex) {
			errorMessage = ResourceBundleUtil.getMessage(RendicionConstantes.MENSAJE_ERROR_GENERICO);
			log.error(ex.getMessage(), ex);
		}

		respuesta.put("codigoOperacion", codigoOperacion);
		respuesta.put("flagHabilitarCerrarRendicion", flagHabilitarCerrarRendicion);
		respuesta.put("errorMessage", errorMessage);
		respuesta.put("successMessage", successMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	/**
	 * Metodo que permite cerrar la rendicion.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	public ModelAndView cerrarRendicion(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoOperacion = RendicionConstantes.ERROR_OPERACION;
		String errorMessage = RendicionConstantes.CADENA_VACIA;
		String successMessage = RendicionConstantes.CADENA_VACIA;
		
		try {
			log.debug(RegistroRendicionController.class.getSimpleName() + ".cerrarRendicion");
			String codPlanViaje = request.getParameter("codPlanViaje");
			String flagHabilitarCerrarRendicion = request.getParameter("flagHabilitarCerrarRendicion");
			String flagCVRHabilitarCerrarRendicion = request.getParameter("flagCVRHabilitarCerrarRendicion");
			String flagRegistroComprobante = request.getParameter("flagRegistroComprobante");
			String flagRegistroVoucher = request.getParameter("flagRegistroVoucher");
			String flagRegistroRIC = request.getParameter("flagRegistroRIC");
			String montoDevueltoComprobanteTotalString = request.getParameter("montoDevueltoComprobanteTotal");
			String montoDevueltoVoucherRICTotalString = request.getParameter("montoDevueltoVoucherRICTotal");
			String codigoRegistrador = request.getParameter("codigoRegistrador");
			String codigoSedeRegistrador = request.getParameter("codigoSedeRegistrador");
			
			BigDecimal montoDevueltoComprobanteTotal = BigDecimal.ZERO;
			BigDecimal montoDevueltoVoucherRICTotal = BigDecimal.ZERO;
			
			codPlanViaje = FormatoUtil.validarEmptyToNull(codPlanViaje);
			flagHabilitarCerrarRendicion = FormatoUtil.validarEmptyToNull(flagHabilitarCerrarRendicion);
			flagCVRHabilitarCerrarRendicion = FormatoUtil.validarEmptyToNull(flagCVRHabilitarCerrarRendicion);
			flagRegistroComprobante = FormatoUtil.validarEmptyToNull(flagRegistroComprobante);
			flagRegistroVoucher = FormatoUtil.validarEmptyToNull(flagRegistroVoucher);
			flagRegistroRIC = FormatoUtil.validarEmptyToNull(flagRegistroRIC);
			
			montoDevueltoComprobanteTotalString = FormatoUtil.validarEmptyToNull(montoDevueltoComprobanteTotalString);
			if (montoDevueltoComprobanteTotalString != null) {
				montoDevueltoComprobanteTotal = new BigDecimal(montoDevueltoComprobanteTotalString);
			}
			
			montoDevueltoVoucherRICTotalString = FormatoUtil.validarEmptyToNull(montoDevueltoVoucherRICTotalString);
			if (montoDevueltoVoucherRICTotalString != null) {
				montoDevueltoVoucherRICTotal = new BigDecimal(montoDevueltoVoucherRICTotalString);
			}
			
			if (codPlanViaje != null) {
				setAuditoriaBeanHolder(request, response);
				String procesoViatico = viaticosProcesoSingleton.obtenerProceso();
				
				PlanViajeBean planViajeTmp = registroRendicionService.obtenerPlanViajeToRendicion(codPlanViaje);
				
				String codDerivacionRendicion = null;
				String codOSA = null;
				if(ViaticoConstantes.CANAL_ATENCION_REEMBOLSO.equals(planViajeTmp.getIndicadorCanalAtencion())){
					Map<String,String> resultValidaOSA = consultaSolicitudService.validarRevisionPreviaOSA(planViajeTmp.getCodPlanViaje());
					String codEjecucion = (String)resultValidaOSA.get("codEjecucion");
					codOSA = (String)resultValidaOSA.get("codOSA");
					String codEstado = (String)resultValidaOSA.get("codEstado");
					log.info("OSA-controller-C�digo de ejecuci�n:"+codEjecucion);
					log.info("OSA-controller-C�digo de OSA:"+codOSA);
					log.info("OSA-controller-C�digo de estado:"+codEstado);
					
					if(RendicionConstantes.CODIGO_EJECUCION_DERIVA_OSA_OK.equals(codEjecucion)){
						//Si llega hasta aqu� es por que no hay error.
						/*if(RendicionConstantes.CODIGO_ESTADO_DERIVA_OSA.equals(codEstado)){
							codDerivacionRendicion = RendicionConstantes.ESTADO_RENDICION_ENVIADO_OSA;
						}else if(RendicionConstantes.CODIGO_ESTADO_DERIVA_PRESUPUESTO.equals(codEstado)){
							codDerivacionRendicion = RendicionConstantes.ESTADO_RENDICION_ENVIADO_FINANCIERA;
						}*/
						codDerivacionRendicion=codEstado;//Se coloca como estado el estado devuelto por el store procedure.
					}	
				}
				
				log.info("Controller-Codigo de derivaci�n:"+codDerivacionRendicion+", codOsa:"+codOSA);
				codigoOperacion = registroRendicionService.cerrarRendicion(codPlanViaje, flagHabilitarCerrarRendicion, flagCVRHabilitarCerrarRendicion, 
						flagRegistroComprobante, flagRegistroVoucher, flagRegistroRIC, montoDevueltoComprobanteTotal, montoDevueltoVoucherRICTotal, codigoRegistrador, 
						codigoSedeRegistrador, procesoViatico,codDerivacionRendicion,codOSA);
				String descripcionEstadoRendicion = RendicionConstantes.DESCRIPCION_ESTADO_RENDICION_CERRADO;
				
				if(ViaticoConstantes.CANAL_ATENCION_CAJACHICA.equals(planViajeTmp.getIndicadorCanalAtencion())){
					successMessage = ResourceBundleUtil.getMessageRendicion(RendicionConstantes.MENSAJE_CIERRE_RENDICION_EXITOSO_CAJA);
				}else{
					successMessage = ResourceBundleUtil.getMessageRendicion(RendicionConstantes.MENSAJE_CIERRE_RENDICION_EXITOSO_FINANZAS);
				}
				
				//volvemos a buscar al rendición y mostramos el estado actualizado en bd
				PlanViajeBean planViajeBD = registroRendicionService.obtenerPlanViajeToRendicion(codPlanViaje);
				respuesta.put("descripcionEstadoRendicion", planViajeBD.getNomEstRend());
			}
			else {
				errorMessage = ResourceBundleUtil.getMessage(RendicionConstantes.MENSAJE_ERROR_GENERICO);
			}
			log.debug(RegistroRendicionController.class.getSimpleName() + ".cerrarRendicion.fin");

		} catch (ServiceException ex) {
			errorMessage = ex.getMessage();
			log.error(ex.getMessage(), ex);
			
		} catch (Exception ex) {
			errorMessage = ResourceBundleUtil.getMessage(RendicionConstantes.MENSAJE_ERROR_GENERICO);
			log.error(ex.getMessage(), ex);
		}

		respuesta.put("codigoOperacion", codigoOperacion);
		respuesta.put("errorMessage", errorMessage);
		respuesta.put("successMessage", successMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	/**
	 * Metodo que permite registrar una papeleta deposito.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	public ModelAndView registrarPapeletaDeposito(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoOperacion = RendicionConstantes.ERROR_OPERACION;
		String errorMessage = RendicionConstantes.CADENA_VACIA;
		String successMessage = RendicionConstantes.CADENA_VACIA;
		
		try {
			log.debug(RegistroRendicionController.class.getSimpleName() + ".registrarPapeletaDeposito");
			String codigoPlanViaje = request.getParameter("codigoPlanViaje");
			String codigoBanco = request.getParameter("codigoBanco");
			String codigoCuentaBanco = request.getParameter("codigoCuentaBanco");
			String numeroOperacion = request.getParameter("numeroOperacion");
			String fechaVoucherString = request.getParameter("fechaVoucher");
			String simboloMoneda = request.getParameter("simboloMoneda");
			String montoUtilizadoString = request.getParameter("montoUtilizado");
			String valorTipoCambioString = request.getParameter("valorTipoCambio");
			String montoDepositoString = request.getParameter("montoDeposito");
			String codigoPersona = request.getParameter("codigoPersona");
			String tipoDestino = request.getParameter("tipoDestino");
			Date fechaVoucher = null;
			BigDecimal montoUtilizado = null;
			BigDecimal valorTipoCambio = null;
			BigDecimal montoDeposito = null;
			
			codigoPlanViaje = FormatoUtil.validarEmptyToNull(codigoPlanViaje);
			codigoBanco = FormatoUtil.validarEmptyToNull(codigoBanco);
			codigoCuentaBanco = FormatoUtil.validarEmptyToNull(codigoCuentaBanco);
			numeroOperacion = FormatoUtil.validarEmptyToNull(numeroOperacion);
			simboloMoneda = FormatoUtil.validarEmptyToNull(simboloMoneda);
			codigoPersona = FormatoUtil.validarEmptyToNull(codigoPersona);
			tipoDestino = FormatoUtil.validarEmptyToNull(tipoDestino);
			
			fechaVoucherString = FormatoUtil.validarEmptyToNull(fechaVoucherString);
			if (fechaVoucherString != null) {
				fechaVoucher = FechaUtil.parseStringDateToDate(fechaVoucherString, RendicionConstantes.DATE_FORMAT_DDMMYYYY);
			}
			
			montoUtilizadoString = FormatoUtil.validarEmptyToNull(montoUtilizadoString);
			if (montoUtilizadoString != null) {
				montoUtilizado = new BigDecimal(montoUtilizadoString);
			}
			
			valorTipoCambioString = FormatoUtil.validarEmptyToNull(valorTipoCambioString);
			if (valorTipoCambioString != null) {
				valorTipoCambio = new BigDecimal(valorTipoCambioString);
			}
			
			montoDepositoString = FormatoUtil.validarEmptyToNull(montoDepositoString);
			if (montoDepositoString != null) {
				montoDeposito = new BigDecimal(montoDepositoString);
			}
			
			boolean flagDatosCorrectos = codigoPlanViaje != null && codigoBanco != null && codigoCuentaBanco != null && numeroOperacion != null && simboloMoneda != null && codigoPersona != null && fechaVoucher != null && montoDeposito != null;
			if (flagDatosCorrectos) {
				setAuditoriaBeanHolder(request, response);
				PapeletaDepositoBean papeletaDeposito = new PapeletaDepositoBean();
				papeletaDeposito.setCodigoPlanViaje(codigoPlanViaje);
				papeletaDeposito.setCodigoBanco(codigoBanco);
				papeletaDeposito.setCodigoCuentaBanco(codigoCuentaBanco);
				papeletaDeposito.setNumeroOperacion(numeroOperacion);
				papeletaDeposito.setFechaVoucher(fechaVoucher);
				papeletaDeposito.setSimboloMoneda(simboloMoneda);
				papeletaDeposito.setMontoUtilizado(montoUtilizado);
				papeletaDeposito.setValorTipoCambio(valorTipoCambio);
				papeletaDeposito.setMontoDeposito(montoDeposito);
				papeletaDeposito.setCodigoPersona(codigoPersona);
				
				//Verificar que no exista una tupla duplicada
				PlanViajeBean planViajeBD = consultaSolicitudService.buscarPlanViaje(codigoPlanViaje);
				papeletaDeposito.setCodigoSede(planViajeBD.getSedeOrigen());
				papeletaDeposito.setNumeroOperacionWithoutZerosLeft(numeroOperacion.replaceFirst("^0+(?!$)", ""));
				if(!registroRendicionService.operacionExiste(papeletaDeposito)){
					String codigoBoletaDeposito = registroRendicionService.registrarPapeletaDeposito(papeletaDeposito, tipoDestino);
					codigoOperacion = RendicionConstantes.EXITO_OPERACION;
					successMessage = ResourceBundleUtil.getMessageRendicion(RendicionConstantes.MENSAJE_BOLETA_DEPOSITO_REGISTRO_EXITOSO);
					respuesta.put("codigoBoletaDeposito", codigoBoletaDeposito);
				}else{
					errorMessage = ResourceBundleUtil.getMessageRendicion(RendicionConstantes.MENSAJE_BOLETA_DEPOSITO_OPERACION_DUPLICADA);	
				}
				
			}
			else {
				errorMessage = ResourceBundleUtil.getMessageRendicion(RendicionConstantes.MENSAJE_BOLETA_DEPOSITO_COMPLETAR_CAMPOS);
			}
			log.debug(RegistroRendicionController.class.getSimpleName() + ".registrarPapeletaDeposito.fin");

		} catch (Exception ex) {
			errorMessage = ResourceBundleUtil.getMessage(RendicionConstantes.MENSAJE_ERROR_GENERICO);
			log.error(ex.getMessage(), ex);
		}

		respuesta.put("codigoOperacion", codigoOperacion);
		respuesta.put("errorMessage", errorMessage);
		respuesta.put("successMessage", successMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	/**
	 * Metodo que permite validar si una papeleta deposito tiene voucher adjuntado.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	public ModelAndView validarPapeletaDepositoAdjuntado(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoConsulta = RendicionConstantes.ERROR_CONSULTA;
		String flagPapeletaDepositoAdjuntado = RendicionConstantes.CERO;
		String errorMessage = RendicionConstantes.CADENA_VACIA;
		
		try {
			log.debug(RegistroRendicionController.class.getSimpleName() + ".validarPapeletaDepositoAdjuntado");
			String codigoPapeletaDeposito = request.getParameter("codigoPapeletaDeposito");
			flagPapeletaDepositoAdjuntado = consultaRendicionService.obtenerFlagPapeletaDepositoAdjuntado(codigoPapeletaDeposito);
			if (RendicionConstantes.CERO.equals(flagPapeletaDepositoAdjuntado)) {
				errorMessage = ResourceBundleUtil.getMessageRendicion(RendicionConstantes.MENSAJE_ADJUNTAR_VOUCHER);
			}
			codigoConsulta = RendicionConstantes.EXITO_CONSULTA;
			log.debug(RegistroRendicionController.class.getSimpleName() + ".validarPapeletaDepositoAdjuntado.fin");

		} catch (Exception ex) {
			errorMessage = ResourceBundleUtil.getMessage(RendicionConstantes.MENSAJE_ERROR_GENERICO);
			log.error(ex.getMessage(), ex);
		}
		
		respuesta.put("codigoConsulta", codigoConsulta);
		respuesta.put("flagPapeletaDepositoAdjuntado", flagPapeletaDepositoAdjuntado);
		respuesta.put("errorMessage", errorMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	/**
	 * Metodo que permite desasociar una papeleta deposito de un plan viaje.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	public ModelAndView desasociarPapeletaDeposito(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoOperacion = RendicionConstantes.ERROR_OPERACION;
		String errorMessage = RendicionConstantes.CADENA_VACIA;
		String successMessage = RendicionConstantes.CADENA_VACIA;
		
		try {
			log.debug(RegistroRendicionController.class.getSimpleName() + ".desasociarPapeletaDeposito");
			String codigoBoletaDeposito = request.getParameter("codigoBoletaDeposito");
			String codigoPlanViaje = request.getParameter("codigoPlanViaje");
			String montoDepositoString = request.getParameter("montoDeposito");
			String tipoDestino = request.getParameter("tipoDestino");
			BigDecimal montoDeposito = BigDecimal.ZERO;
			
			codigoBoletaDeposito = FormatoUtil.validarEmptyToNull(codigoBoletaDeposito);
			codigoPlanViaje = FormatoUtil.validarEmptyToNull(codigoPlanViaje);
			tipoDestino = FormatoUtil.validarEmptyToNull(tipoDestino);
			montoDepositoString = FormatoUtil.validarEmptyToNull(montoDepositoString);
			if (montoDepositoString != null) {
				montoDeposito = new BigDecimal(montoDepositoString);
			}
			
			if (codigoBoletaDeposito != null && codigoPlanViaje != null) {
				setAuditoriaBeanHolder(request, response);
				codigoOperacion = registroRendicionService.desasociarPapeletaDeposito(codigoBoletaDeposito, codigoPlanViaje, montoDeposito, tipoDestino);
				successMessage = ResourceBundleUtil.getMessageRendicion(RendicionConstantes.MENSAJE_OPERACION_EXITOSA);
			}
			log.debug(RegistroRendicionController.class.getSimpleName() + ".desasociarPapeletaDeposito.fin");

		} catch (Exception ex) {
			errorMessage = ResourceBundleUtil.getMessage(RendicionConstantes.MENSAJE_ERROR_GENERICO);
			log.error(ex.getMessage(), ex);
		}

		respuesta.put("codigoOperacion", codigoOperacion);
		respuesta.put("errorMessage", errorMessage);
		respuesta.put("successMessage", successMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	/**
	 * Metodo que permite obtener los comprobantes, papeletas deposito, registros interno de caja asociado a un plan viaje.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	public ModelAndView obtenerComprobantesAsignacionesPapeletasRics(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoConsulta = RendicionConstantes.ERROR_CONSULTA;
		String errorMessage = RendicionConstantes.CADENA_VACIA;
		
		try {
			log.debug(RegistroRendicionController.class.getSimpleName() + ".obtenerComprobantesAsignacionesPapeletasRics");
			String codigoPlanViaje = request.getParameter("codigoPlanViaje");
			String montoRendirTotal = request.getParameter("montoRendirTotal");
			String simboloMoneda = request.getParameter("simboloMoneda");
			String indicadorMenorGasto = request.getParameter("indicadorMenorGasto");
			codigoPlanViaje = FormatoUtil.validarEmptyToNull(codigoPlanViaje);
			montoRendirTotal = FormatoUtil.validarEmptyToNull(montoRendirTotal);
			simboloMoneda = FormatoUtil.validarEmptyToNull(simboloMoneda);
			indicadorMenorGasto = FormatoUtil.validarEmptyToNull(indicadorMenorGasto);
			
			if (codigoPlanViaje != null && montoRendirTotal != null) {
				
				BigDecimal montoComprobanteTotal = BigDecimal.ZERO;
				BigDecimal montoDeclaracionTotal = BigDecimal.ZERO;
				BigDecimal montoDeclaracionViatico = BigDecimal.ZERO;
				BigDecimal montoDepositoTotal = BigDecimal.ZERO;
				BigDecimal montoRICTotal = BigDecimal.ZERO;
				int numeroDeclaracionViatico = 0;
				String flagDeclaracion = RendicionConstantes.CERO;
				ArrayList<PlanViajeRendicionBean> planViajeRendicionList = viaticoConsultaService.obtenerPlanViajeRendicionToRegistroRendicion(codigoPlanViaje, simboloMoneda);
				if (planViajeRendicionList != null && !planViajeRendicionList.isEmpty()) {
					int sizeList = planViajeRendicionList.size();
					montoComprobanteTotal = new BigDecimal(planViajeRendicionList.get(sizeList - 1).getMtoReconocido());
					montoDeclaracionTotal = new BigDecimal(planViajeRendicionList.get(sizeList - 1).getMontoDeclaracion());
					montoDeclaracionViatico = new BigDecimal(planViajeRendicionList.get(sizeList - 1).getMontoDeclaracionViatico());
					numeroDeclaracionViatico = planViajeRendicionList.get(sizeList - 1).getNumeroDeclaracionViatico();
					flagDeclaracion = planViajeRendicionList.get(sizeList - 1).getFlagDeclaracion();
				}
				
				ArrayList<PlanViajeConceptoBean> planViajeConceptoList = consultaRendicionService.obtenerPlanViajeConcepto(codigoPlanViaje, simboloMoneda);
				
				ArrayList<PapeletaDepositoBean> papeletaDepositoList = consultaRendicionService.obtenerPapeletasDeposito(codigoPlanViaje);
				if (papeletaDepositoList != null && !papeletaDepositoList.isEmpty()) {
					int sizeList = papeletaDepositoList.size();
					montoDepositoTotal = papeletaDepositoList.get(sizeList - 1).getMontoDeposito();
				}
				
				//ArrayList<ComprobanteIngresoBean> comprobanteIngresoList = consultaRendicionService.obtenerRecibosIngresoCaja("020201500235");
				ArrayList<ComprobanteIngresoBean> comprobanteIngresoList = consultaRendicionService.obtenerRecibosIngresoCaja(codigoPlanViaje);
				if (comprobanteIngresoList != null && !comprobanteIngresoList.isEmpty()) {
					int sizeList = comprobanteIngresoList.size();
					montoRICTotal = comprobanteIngresoList.get(sizeList - 1).getMonto();
				}
				
				BigDecimal montoDevolver = consultaRendicionService.obtenerMontoDevolver(new BigDecimal(montoRendirTotal), montoComprobanteTotal, montoDepositoTotal, montoRICTotal);
				log.info("Monto declaración:"+montoDeclaracionTotal);
				log.info("Monto declaración viático:"+montoDeclaracionViatico);
				log.info("Monto a devolver:"+montoDevolver+", montoTotal:"+montoRendirTotal+", montoComprobante:"+montoComprobanteTotal+", montoDeposito:"+montoDepositoTotal+", montoRic:"+montoRICTotal);
				
				BigDecimal montoDevueltoComprobanteTotal = montoComprobanteTotal;
				BigDecimal montoDevueltoVoucherRICTotal = montoDepositoTotal.add(montoRICTotal);
				String flagCVRHabilitarCerrarRendicion = consultaRendicionService.obtenerFlagHabilitarCerrarRendicion(new BigDecimal(montoRendirTotal), montoDevueltoComprobanteTotal, montoDevueltoVoucherRICTotal, indicadorMenorGasto);
				RendicionVO rendicionVO = new RendicionVO();
				rendicionVO.setPlanViajeRendicionList(planViajeRendicionList);
				rendicionVO.setPlanViajeConceptoList(planViajeConceptoList);
				rendicionVO.setPapeletaDepositoList(papeletaDepositoList);
				rendicionVO.setComprobanteIngresoList(comprobanteIngresoList);
				rendicionVO.setMontoComprobanteTotal(NumeroUtil.formatearMonedaMontoToDecimal(null, 2, montoComprobanteTotal));
				rendicionVO.setMontoComprobanteTotalFormateado(NumeroUtil.formatearMonto(simboloMoneda, montoComprobanteTotal, 2));
				rendicionVO.setMontoDeclaracionTotal(NumeroUtil.formatearMonedaMontoToDecimal(null, 2, montoDeclaracionTotal));
				rendicionVO.setMontoDeclaracionTotalFormateado(NumeroUtil.formatearMonto(simboloMoneda, montoDeclaracionTotal, 2));
				rendicionVO.setMontoDeclaracionViatico(NumeroUtil.formatearMonedaMontoToDecimal(null, 2, montoDeclaracionViatico));
				rendicionVO.setMontoDeclaracionViaticoFormateado(NumeroUtil.formatearMonto(simboloMoneda, montoDeclaracionViatico, 2));
				rendicionVO.setMontoDepositoTotal(NumeroUtil.formatearMonedaMontoToDecimal(null, 2, montoDepositoTotal));
				rendicionVO.setMontoDepositoTotalFormateado(NumeroUtil.formatearMonto(simboloMoneda, montoDepositoTotal, 2));
				rendicionVO.setMontoRICTotal(NumeroUtil.formatearMonedaMontoToDecimal(null, 2, montoRICTotal));
				rendicionVO.setMontoRICTotalFormateado(NumeroUtil.formatearMonto(simboloMoneda, montoRICTotal, 2));
				rendicionVO.setMontoDevolver(NumeroUtil.formatearMonedaMontoToDecimal(null, 2, montoDevolver));
				rendicionVO.setMontoDevolverFormateado(NumeroUtil.formatearMonto(simboloMoneda, montoDevolver, 2));
				rendicionVO.setMontoDevueltoComprobanteTotal(NumeroUtil.formatearMonedaMontoToDecimal(null, 2, montoDevueltoComprobanteTotal));
				rendicionVO.setMontoDevueltoVoucherRICTotal(NumeroUtil.formatearMonedaMontoToDecimal(null, 2, montoDevueltoVoucherRICTotal));
				rendicionVO.setFlagDeclaracion(flagDeclaracion);
				rendicionVO.setFlagCVRHabilitarCerrarRendicion(flagCVRHabilitarCerrarRendicion);
				rendicionVO.setNumeroDeclaracionViatico(numeroDeclaracionViatico);
				codigoConsulta = RendicionConstantes.EXITO_CONSULTA;
				respuesta.put("rendicionVO", rendicionVO);
			}
			log.debug(RegistroRendicionController.class.getSimpleName() + ".obtenerComprobantesAsignacionesPapeletasRics.fin");
			
		} catch (Exception ex) {
			errorMessage = ResourceBundleUtil.getMessage(RendicionConstantes.MENSAJE_ERROR_GENERICO);
			log.error(ex.getMessage(), ex);
		}
		
		respuesta.put("codigoConsulta", codigoConsulta);
		respuesta.put("errorMessage", errorMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	/**
	 * Metodo que permite obtener los gastos con el detalle de los comprobantes.
	 * @author Jorge Ponce.
	 * @param request :objeto de la clase HttpServletRequest.
	 * @param response :objeto de la clase HttpServletResponse.
	 * @return Objeto ModelAndView (JsonView).
	 * @see ModelAndView
	 */
	public ModelAndView obtenerGastoDetallePorConcepto(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String codigoConsulta = RendicionConstantes.ERROR_CONSULTA;
		String errorMessage = RendicionConstantes.CADENA_VACIA;
		
		try {
			log.debug(RegistroRendicionController.class.getSimpleName() + ".obtenerGastoDetallePorConcepto");
			String planViajeId = request.getParameter("planViajeId");
			String secuencialString = request.getParameter("secuencial");
			String simboloMoneda = request.getParameter("simboloMoneda");
			Integer secuencial = null;
			planViajeId = FormatoUtil.validarEmptyToNull(planViajeId);
			secuencialString = FormatoUtil.validarEmptyToNull(secuencialString);
			if (secuencialString != null) {
				secuencial = new Integer(secuencialString);
			}
			if (planViajeId != null) {
				setAuditoriaBeanHolder(request, response);
				ArrayList<PlanViajeInformeDistribBean> asignacionViaticoList = viaticoConsultaService.obtenerAsignacionGastoViatico(planViajeId, secuencial, simboloMoneda);
				ArrayList<PlanViajeInformeDistribBean> pasajeTasaEmbarqueList = viaticoConsultaService.obtenerPasajeTasaEmbarque(planViajeId, secuencial, simboloMoneda);
				codigoConsulta = RendicionConstantes.EXITO_CONSULTA;
				RendicionVO rendicionVO = new RendicionVO();
				rendicionVO.setAsignacionViaticoList(asignacionViaticoList);
				rendicionVO.setPasajeTasaEmbarqueList(pasajeTasaEmbarqueList);
				respuesta.put("rendicionVO", rendicionVO);
			}
			log.debug(RegistroRendicionController.class.getSimpleName() + ".obtenerGastoDetallePorConcepto.fin");
			
		} catch (Exception ex) {
			errorMessage = ResourceBundleUtil.getMessage(RendicionConstantes.MENSAJE_ERROR_GENERICO);
			log.error(ex.getMessage(), ex);
		}
		
		respuesta.put("codigoConsulta", codigoConsulta);
		respuesta.put("errorMessage", errorMessage);
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}

	public ConsultaSolicitudService getConsultaSolicitudService() {
		return consultaSolicitudService;
	}

	public void setConsultaSolicitudService(
			ConsultaSolicitudService consultaSolicitudService) {
		this.consultaSolicitudService = consultaSolicitudService;
	}
	
}
