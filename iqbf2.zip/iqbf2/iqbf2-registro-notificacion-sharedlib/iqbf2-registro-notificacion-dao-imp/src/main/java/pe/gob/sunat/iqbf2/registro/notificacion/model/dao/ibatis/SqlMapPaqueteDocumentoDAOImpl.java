package pe.gob.sunat.iqbf2.registro.notificacion.model.dao.ibatis;

import java.util.Collection;
import java.util.Map;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.PaqueteDocumentoBean;
import pe.gob.sunat.iqbf2.registro.notificacion.model.dao.PaqueteDocumentoDAO;

public class SqlMapPaqueteDocumentoDAOImpl  extends SqlMapClientDaoSupport implements  PaqueteDocumentoDAO{

	@Override
	public PaqueteDocumentoBean getPaqueteDocumento(String codPaquete,
			String codDocumento) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<PaqueteDocumentoBean> buscarPaqueteDocumento(
			Map<String, Object> parm) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insertPaqueteDocumento(PaqueteDocumentoBean paqueteDocumentoBean) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updatePaqueteDocumento(PaqueteDocumentoBean paqueteDocumentoBean) {
		// TODO Auto-generated method stub
		
	}

}
