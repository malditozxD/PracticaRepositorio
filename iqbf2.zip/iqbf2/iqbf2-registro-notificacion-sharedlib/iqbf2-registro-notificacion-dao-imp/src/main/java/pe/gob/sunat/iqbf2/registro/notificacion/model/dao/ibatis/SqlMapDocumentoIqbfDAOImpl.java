package pe.gob.sunat.iqbf2.registro.notificacion.model.dao.ibatis;

import java.util.Collection;
import java.util.Map;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.DocumentoIqbfBean;
import pe.gob.sunat.iqbf2.registro.notificacion.model.dao.DocumentoIqbfDAO;

public class SqlMapDocumentoIqbfDAOImpl extends SqlMapClientDaoSupport implements DocumentoIqbfDAO{

	@Override
	public DocumentoIqbfBean getDocumento(String codDocumento) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<DocumentoIqbfBean> buscarDocumento(
			Map<String, Object> parm) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insertDocumento(DocumentoIqbfBean documentoIqbfBean) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateDocumento(DocumentoIqbfBean documentoIqbfBean) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateDocumentoEstado(DocumentoIqbfBean documentoIqbfBean) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateDocumentoObserva(DocumentoIqbfBean documentoIqbfBean) {
		// TODO Auto-generated method stub
		
	}

}
