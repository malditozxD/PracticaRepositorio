package pe.gob.sunat.iqbf2.registro.notificacion.model.dao.ibatis;

import java.util.Collection;
import java.util.Map;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.TipoProcedimientoBean;
import pe.gob.sunat.iqbf2.registro.notificacion.model.dao.TipoProcedimientoDAO;

public class SqlTipoProcedimientoDAOImpl extends SqlMapClientDaoSupport implements TipoProcedimientoDAO {

	@Override
	public TipoProcedimientoBean getTipoProcedimiento(String codTipoDoc) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<TipoProcedimientoBean> buscarTipoProcedimiento(
			Map<String, Object> parm) {
		// TODO Auto-generated method stub
		return null;
	}

}
