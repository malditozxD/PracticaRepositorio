package pe.gob.sunat.iqbf2.registro.notificacion.model.dao.ibatis;



import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.RegistroAfiliacionBean;
import pe.gob.sunat.iqbf2.registro.notificacion.model.dao.RegistroAfiliacionDAO;


/**
 * Clase RegistroAfiliacionDAO.
 * 
 * @author emarchena
 */
public class SqlMapRegistroAfiliacionDAOImpl extends SqlMapClientDaoSupport implements RegistroAfiliacionDAO {

	
	/**
	 * Metodo que permite obtener si un ruc esta afiliado.
	 * 
	 * @author emarchena.
	 * @param codRuc :Ruc de afiliado.
	 * @return Registro de Afiliacion.
	 * @see String
	 * @throws DataAccessException
	 */
	@Override
	public RegistroAfiliacionBean obtenerAfliado(String codRuc)
			throws DataAccessException {
		RegistroAfiliacionBean registroAfiliacionBean= new  RegistroAfiliacionBean();
		registroAfiliacionBean.setCodigoRuc(codRuc);
	
		RegistroAfiliacionBean tem = (RegistroAfiliacionBean) getSqlMapClientTemplate()
				.queryForObject("registroAfiliacion.buscarAfiliacion", registroAfiliacionBean);
		return tem;
	}

	/**
	 * Metodo que permite grabar la afiliacion.
	 * 
	 * @author emarchena.
	 * @param RegistroAfiliacionBean 
	 * @return void.
	 * @see String
	 * @throws DataAccessException
	 */
	
	@Override
	public void insertAfiliacion(RegistroAfiliacionBean registroAfiliacionBean)
			throws DataAccessException {
		getSqlMapClientTemplate().insert("registroAfiliacion.registrarAfiliacion", registroAfiliacionBean);
		
	}

}
