package pe.gob.sunat.iqbf2.registro.notificacion.model.dao.ibatis;

import java.util.Collection;
import java.util.Map;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.TipoDocumentoBean;
import pe.gob.sunat.iqbf2.registro.notificacion.model.dao.TipoDocumentoDAO;

public class SqlMapTipoDocumentoDAOImpl extends SqlMapClientDaoSupport  implements TipoDocumentoDAO{

	@Override
	public TipoDocumentoBean getTipoDocumento(String codTipoDoc) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<TipoDocumentoBean> buscarTipoDocumento(
			Map<String, Object> parm) {
		// TODO Auto-generated method stub
		return null;
	}

}
