package pe.gob.sunat.iqbf2.registro.notificacion.model.dao.ibatis;

import java.util.Collection;
import java.util.Map;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.PaqueteBean;
import pe.gob.sunat.iqbf2.registro.notificacion.model.dao.PaqueteDAO;



public class SqlMapPaqueteDAOImpl extends SqlMapClientDaoSupport implements PaqueteDAO {

	@Override
	public PaqueteBean getPaquete(String codPaquete) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<PaqueteBean> buscarPaquete(Map<String, Object> parm) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insertPaquete(PaqueteBean paqueteBean) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updatePaquete(PaqueteBean paqueteBean) {
		// TODO Auto-generated method stub
		
	}
	
	

}
