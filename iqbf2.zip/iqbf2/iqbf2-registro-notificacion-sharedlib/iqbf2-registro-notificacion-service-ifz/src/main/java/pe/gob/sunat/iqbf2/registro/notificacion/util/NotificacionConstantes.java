package pe.gob.sunat.iqbf2.registro.notificacion.util;

public class NotificacionConstantes {

	
	
	public static final String DO_ACTION_REGISTRO = "R";	
	public static final String DO_ACTION_MODIFICAR = "M";
	public static final String DO_ACTION_CONSULTAR = "C";
	public static final String DO_ACTION_PROYECTAR = "P";
	
	
	
	
	
	
	//eejmplo
	// GENERALES BUNDLE///////////////////////////////////////////////////////
	public static final String RESOURCE_BUNDLE_VIATICO = "iasiga-viatico-viatico";
	public static final String RESOURCE_BUNDLE_VIATICO_CORREO = "iasiga-viatico-correo";
	
	// GENERALES MENSAJE///////////////////////////////////////////////////////
	public static final String MENSAJE_ERROR_GENERICO = "error.mensaje.generico";
	public static final String MENSAJE_OPERACION_EXITOSA = "success.message.operacionExitosa";
	public static final String MENSAJE_ERROR_SIN_CCP_CAS = "error.mensaje.sinCcpCas";
	public static final String OPERACION_NO_REALIZADA = "Operación no realizada";
	public static final String DESPLAZAMIENTO_NO_VALIDO = "Desplazamiento no válido";

	// GENERALES FOMATO FECHA///////////////////////////////////////////////////////
	public static final String DATE_FORMAT_DDMMYYYYHHMM = "dd/MM/yyyy HH:mm";
	public static final String DATE_FORMAT_DDMMYYYYHHMM_AMPM = "dd/MM/yyyy HH:mm a";
	public static final String DATE_FORMAT_DDMMYYYY = "dd/MM/yyyy";
	public static final String DATE_FORMAT_YYYY = "yyyy";
	public static final String DATE_FORMAT_MM = "MM";
	public static final String DATE_FORMAT_DD = "dd";
	public static final String DATE_FORMAT_HHMM = "HH:mm";
	public static final String FECHA_INICIO_REFERENCIAL = "01/01/1800";
	
	//GENERALES FOMATO MONEDA///////////////////////////////////////////////////////
	public static final String MONEDA_SOLES = "S/.";
	public static final String MONEDA_DOLARES = "US$";
	public static final String CERO = "0";
	public static final String UNO = "1";
	public static final String CODIGO_0 = "0";
	public static final String CODIGO_00 = "00";
	public static final String CODIGO_0000 = "0000";
	// NRO DECIMALES ROUND
	public static final int NRO_DECIMALES_ROUND = 2;
	
	
		
	//GENERALES FOMATO SIGNOS///////////////////////////////////////////////////////
	public static final String SIGNO_MINUS = "-";
	public static final String REQUEST_AND = "&";
	public static final String IGUAL = "=";
	public static final String DOS_PUNTOS = ":";
	public static final String ESPACIO = " ";
	public static final String CADENA_VACIA = "";
	//GENERALES FOMATO BUSQUEDA///////////////////////////////////////////////////////
	public static final String SELECCIONE = "-- Seleccione --";
	
	public static final String SI = "si";
	public static final String NO = "no";
	public static final String OK = "ok";

	//GENERALES FOMATO HTML///////////////////////////////////////////////////////
	public static final String BR = "<br>";
	public static final String UL_INICIO = "<ul>";
	public static final String UL_FIN = "</ul>";
	public static final String LI_INICIO = "<li>";
	public static final String LI_FIN = "</li>";
	public static final String TEXTO_PLANILLA = "Planilla ";
	public static final String COMA = ",";
	public static final String TOTAL = "TOTAL";
	


	// TIPOS DE PAGINA
	public static final String TIPO_PAGINA_GENERAL = "01";
	public static final String TIPO_PAGINA_ESPECIFICO = "02";
	public static final String PORCENTAJE = "%";

	



	// MENSAJE GENÉRICO PETICIÓN AJAX - LOS MENSAJES DE NEGOCIO PERSONALIZADOS SON OTROS 
	public static final String MSG_ERROR_OPERACION_NO_EFECTUADA = "Error de aplicación - Comuníquese con el Administrador del Sistema";


	// ESTADOS VIATICO SOLICITUD (codigos)
	public static final String ESTADO_DOCUMENTO_ELABORADO = "01";
	public static final String ESTADO_VIATICO_ENVIADO_CAJACHICA = "02";
	public static final String ESTADO_VIATICO_ANULADO = "03";
	public static final String ESTADO_VIATICO_POR_AUTORIZAR = "04";
	public static final String ESTADO_VIATICO_AUTORIZADO = "05";
	public static final String ESTADO_VIATICO_ENVIADO_CPP = "05";
	public static final String ESTADO_VIATICO_OBSERVADO = "06";
	public static final String ESTADO_VIATICO_OBSERVADO_CAJA_CHICA = "07";
	public static final String ESTADO_VIATICO_OBSERVADO_FINANCIERA = "08";
	public static final String ESTADO_VIATICO_ANULACION_AUTOMATICA = "09";
	public static final String ESTADO_VIATICO_PAGADO = "10";
	public static final String ESTADO_VIATICO_ENVIADO_FINANCIERA = "11";

	
	//http://api.sunat.peru/v1/contribuyente/registro/e/contribuyentes/20100238234/comprobantes
	//http://insi.sunat.gob.pe/cl-ti-iaconsultaruc-ws/contribuyentes/
	// URL RESTFULL
	public static final String URL_DESARROLLO_CONTRIBUYENTE = "http://api.sunat.peru/v1/contribuyente/registro/e/contribuyentes/";
	public static final String URL_DESARROLLO_COMPROBANTE = "http://api.sunat.peru/v1/contribuyente/registro/e/comprobantes?numRuc=";
	public static final String URL_PRODUCCION = "";

	public static final String RUTA_ARCHIVO_DATA0 = "/data0";
	public static final String RUTA__ARCHIVO_DATA0_TEM = "/data0/tempo";
	public static final String APLICACION_SERVICIOS = "VIATICOS WEB";
	

	
	// TIPOS DE ARCHIVOS ADJUNTOS
	public static final String TIPO_ARCHIVO_SOLICITUD_VIATICO = "SOLICITUD DE VIATICO";
	public static final String TIPO_ARCHIVO_SOLICITUD_REEMBOLSO = "SOLICITUD DE REEMBOLSO";
	public static final String TIPO_ARCHIVO_AUTORIZACION_COMISION = "AUTORIZACION DE COMISION";
	public static final String TIPO_ARCHIVO_JUSTIFICACION_TRASLAPE_COMISION= "JUSTIFICACION TRASLAPE COMISION";
	
	public static final String DESC_TIPO_ARCHIVO_SOLICITUD_VIATICO = "SOLICITUD DE VIATICO";
	public static final String DESC_TIPO_ARCHIVO_SOLICITUD_REEMBOLSO = "SOLICITUD DE REEMBOLSO";
	
	public static final String PAGINA_PRINCIPAL = "PRINCIPAL";
	public static final String PAGINA_SECUNDARIA = "SECUNDARIA";
	
	//CODIGO DE CONSULTA - EXITO - ERROR
	public static final String EXITO_CONSULTA = "00";
	public static final String ERROR_CONSULTA = "01";
	public static final String ERROR_CONSULTA_SIN_SEGUIMIENTO = "02";
	public static final String ERROR_CONSULTA_NO_EXISTE_PLANILLA = "02";

	//CODIGO DE OPERACION - EXITO - ERROR
	public static final String EXITO_OPERACION = "00";
	public static final String ERROR_OPERACION_NO_EXISTE_ARCHIVO_ADJUNTO = "01";
	public static final String ERROR_OPERACION = "02";
	

		
	//PAGES
	public static final String REPORTE_ERROR_PAGE = "general/errorReportePage";

	//menu
	public static final String MENU = "general/menu";
	
}









