package pe.gob.sunat.iqbf2.registro.notificacion.tool;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;









public class JasperTool {
	static Log log = LogFactory.getLog(JasperTool.class);
	
	
	
	public static ArchivoBean GenerarArchivoPDF(JasperBean params){
		ArchivoBean reportBean = new ArchivoBean();
		
		//ReporteArchivoBean fbean = new ReporteArchivoBean();
		
		String path_jasper= JasperConstantes.RUTA_JASPER + params.getJasperName();
		String path_pdf= JasperConstantes.RUTA_PDF + params.getFileName();
		
		InputStream is = null;
		byte[] fileBytes ;
		try {
			log.debug(path_jasper);
			is = new FileInputStream(path_jasper);
			JasperReport reporte;
			log.debug("avialble: " + is.available() );
			reporte = (JasperReport) JRLoader.loadObject(is);
			log.debug("name JAsper: " + reporte.getName());
			 
	        JRDataSource dsLista = new JRBeanCollectionDataSource(params.getListaDetalle());
	        
	        JasperPrint jasperPrint=new JasperPrint() ;
	        jasperPrint = JasperFillManager.fillReport( reporte,params.getParametros(), dsLista );
	       
	        
	        log.debug("pages: "+ jasperPrint.getPageWidth());
	      
	        fileBytes=JasperExportManager.exportReportToPdf(jasperPrint);
	        
	        
	        log.debug("Tamanio bye: "+fileBytes.length);
	        if(fileBytes.length > 0){
	        	FileOutputStream file = new FileOutputStream(path_pdf + ".pdf");
	        	file.write(fileBytes);
	        	reportBean.setData(fileBytes);
	        	reportBean.setFieldExtension("pdf");
	        	reportBean.setFieldName(path_pdf+".pdf");
	        	
	        }else{
	        	log.error("No se Genero El  Jasper y por lo tanto no el PDF");
	        }
	        //reportBean.setData(fileBytes);
	        //reportBean.setFieldName(fieldName);
	        
	        is.close();
		} catch (FileNotFoundException ex) {
			log.error("FileNotFoundException en ReporteJasperUtil.GenerarArchivoPDF: " + ex.getMessage(), ex);
			ex.printStackTrace();
		}catch (JRException ex) {
			log.error("JRException en ReporteJasperUtil.GenerarArchivoPDF: " + ex.getMessage(), ex);
			ex.printStackTrace();
		} catch (IOException ex) {
			log.error("IOException en ReporteJasperUtil.GenerarArchivoPDF: " + ex.getMessage(), ex);
			ex.printStackTrace();
		}
		return reportBean;
	}

	public static ArchivoBean generarArchivoPDF(JasperBean params, String rutaJasper, String rutaPdf){
		
		ArchivoBean reportBean = new ArchivoBean();

			
		String path_jasper= rutaJasper + params.getJasperName();
		String path_pdf= rutaPdf + params.getFileName();
		
		InputStream is = null;
		byte[] fileBytes ;
		try {
			log.debug(path_jasper);
			is = new FileInputStream(path_jasper);
			JasperReport reporte;
			log.debug("avialble: " + is.available() );
			reporte = (JasperReport) JRLoader.loadObject(is);
			log.debug("name JAsper: " + reporte.getName());
			 
	        JRDataSource dsLista = new JRBeanCollectionDataSource(params.getListaDetalle());
	        
	        JasperPrint jasperPrint=new JasperPrint() ;
	        jasperPrint = JasperFillManager.fillReport( reporte,params.getParametros(), dsLista );
	       
	        
	        log.debug("pages: "+ jasperPrint.getPageWidth());
	      
	        fileBytes=JasperExportManager.exportReportToPdf(jasperPrint);
	        
	        
	        log.debug("Tamanio bye: "+fileBytes.length);
	        if(fileBytes.length > 0){
	        	FileOutputStream file = new FileOutputStream(path_pdf + ".pdf");
	        	file.write(fileBytes);
	        	reportBean.setData(fileBytes);
	        	reportBean.setFieldExtension("pdf");
	        	reportBean.setFieldName(path_pdf+".pdf");
	        	
	        }else{
	        	log.error("No se Genero El  Jasper y por lo tanto no el PDF");
	        }
	        //reportBean.setData(fileBytes);
	        //reportBean.setFieldName(fieldName);
	        
	        is.close();
		} catch (FileNotFoundException ex) {
			log.error("FileNotFoundException en ReporteJasperUtil.GenerarArchivoPDF: " + ex.getMessage(), ex);
			ex.printStackTrace();
		}catch (JRException ex) {
			log.error("JRException en ReporteJasperUtil.GenerarArchivoPDF: " + ex.getMessage(), ex);
			ex.printStackTrace();
		} catch (IOException ex) {
			log.error("IOException en ReporteJasperUtil.GenerarArchivoPDF: " + ex.getMessage(), ex);
			ex.printStackTrace();
		}
		return reportBean;
	}
}
