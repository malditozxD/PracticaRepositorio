package pe.gob.sunat.iqbf2.registro.notificacion.service;

import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.RegistroAfiliacionBean;
import pe.gob.sunat.iqbf2.registro.notificacion.tool.JasperBean;



public interface NotificacionJasperService {
	public JasperBean generarConstanciaAfiliacionPDF(RegistroAfiliacionBean registroAfiliacionBean) throws Exception ;
}
