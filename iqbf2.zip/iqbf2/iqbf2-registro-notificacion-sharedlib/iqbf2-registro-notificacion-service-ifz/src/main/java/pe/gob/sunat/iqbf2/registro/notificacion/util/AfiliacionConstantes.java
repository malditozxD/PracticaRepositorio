package pe.gob.sunat.iqbf2.registro.notificacion.util;

public class AfiliacionConstantes {
	
	//PAGES
	public static final String REGISTRAR_AFILIACION_PAGE = "afiliacion/registrarAfiliacion";
	



	
	//PROPERTIES
	public static final String MENSAJE_ERROR_GENERICO = "error.mensaje.generico";
	public static final String MENSAJE_ERROR_ACCESO = "error.mensaje.acceso";
	public static final String MENSAJE_ERROR_PLANILLA_NO_EXISTE = "error.mensaje.nroPlanillaNoExiste";
	public static final String MENSAJE_REGISTRO_RENDICION_EXITOSO = "registrarModificarRendicion.message.grabacionExitosa";
	public static final String MENSAJE_CIERRE_RENDICION_EXITOSO = "registrarModificarRendicion.message.cierreExitoso";
	public static final String MENSAJE_CIERRE_RENDICION_EXITOSO_CAJA = "registrarModificarRendicion.message.cierreExitosoCajaChica";
	public static final String MENSAJE_CIERRE_RENDICION_EXITOSO_FINANZAS = "registrarModificarRendicion.message.cierreExitosoFinanciera";
	
	public static final String MENSAJE_OPERACION_EXITOSA = "registrarModificarRendicion.message.operacionExitosa";
	public static final String MENSAJE_BOLETA_DEPOSITO_REGISTRO_EXITOSO = "registrarBoletaDeposito.message.registroVoucherExitoso";
	public static final String MENSAJE_BOLETA_DEPOSITO_COMPLETAR_CAMPOS = "registrarBoletaDeposito.messageError.completarCampos";
	public static final String MENSAJE_BOLETA_DEPOSITO_OPERACION_DUPLICADA = "registrarBoletaDeposito.messageError.operacionDuplicada";
	public static final String MENSAJE_ADJUNTAR_DOCUMENTO = "registrarModificarRendicion.messageError.adjuntarDocumentoRendicion";
	public static final String MENSAJE_ADJUNTAR_VOUCHER = "registrarModificarRendicion.messageError.adjuntarVoucherDeposito";


}