package pe.gob.sunat.iqbf2.registro.notificacion.documento.service;

import java.util.Collection;
import java.util.Map;



import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.DocumentoIqbfBean;
import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.PaqueteDocumentoBean;



public interface DocumentoIndividualService {
	
	public DocumentoIqbfBean obtenerDocumento(String codDocumento);
	public Collection<DocumentoIqbfBean> listarDocumentos(Map< String, Object> parm);
	public String registrarDocumento(DocumentoIqbfBean documentoIqbfBean);
	public String registrarDocumentoPaquete(PaqueteDocumentoBean paqueteDocumentoBean);
	public String proyectarDocumento(DocumentoIqbfBean documentoIqbfBean );
	public String darBajaDocumento(DocumentoIqbfBean documentoIqbfBean);
	
	
	public Collection<DocumentoIqbfBean> consultarDocumentosEnviados(Map< String, Object> parm);
	
	//metodos de revision 
	public String iniciarDocumento(DocumentoIqbfBean documentoIqbfBean );
	public String devolverDocumento(DocumentoIqbfBean documentoIqbfBean );
	
	public String enviarDocumento(DocumentoIqbfBean documentoIqbfBean );
	public String rechazarDocumento(DocumentoIqbfBean documentoIqbfBean );
}
