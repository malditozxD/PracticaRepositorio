package pe.gob.sunat.iqbf2.registro.notificacion.service;

import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.DocumentoIqbfBean;
import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.PaqueteBean;

public interface NotificacionMensajeriaService {
	
	
	void enviarCorreoAprobarIndividual(DocumentoIqbfBean documentoIqbfBean);
	void enviarCorreoAprobarMasivo(PaqueteBean paqueteBean);
	
	void enviarCorreoDevolverIndividual(DocumentoIqbfBean documentoIqbfBean);
	void enviarCorreoDevolverMasivo(PaqueteBean paqueteBean);
	
	void enviarCorreoEnviarNotificarIndividual(DocumentoIqbfBean documentoIqbfBean);
	void enviarCorreoEnviarNotificarMasivo(PaqueteBean paqueteBean);
	
	void enviarCorreoRechazarIndividual(DocumentoIqbfBean documentoIqbfBean);
	void enviarCorreoRechazarMasivo(PaqueteBean paqueteBean);

}
