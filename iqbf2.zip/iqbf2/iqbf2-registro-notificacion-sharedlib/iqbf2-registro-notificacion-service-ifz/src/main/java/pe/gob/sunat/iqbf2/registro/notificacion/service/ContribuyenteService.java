package pe.gob.sunat.iqbf2.registro.notificacion.service;

import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.ContribuyenteBean;

public interface ContribuyenteService {
	public ContribuyenteBean obtenerContribuyente(String Ruc);
	public String validarContribuyente(String ruc);
	

}
