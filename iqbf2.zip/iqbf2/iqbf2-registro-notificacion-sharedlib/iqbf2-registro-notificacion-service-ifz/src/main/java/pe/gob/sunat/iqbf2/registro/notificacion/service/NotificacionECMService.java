package pe.gob.sunat.iqbf2.registro.notificacion.service;

import pe.gob.sunat.iqbf2.registro.notificacion.tool.ArchivoBean;

public interface NotificacionECMService {
	public String createDocumento(ArchivoBean archivoBean);
	public ArchivoBean obtenerDocumento(String idEcm);
	

}
