package pe.gob.sunat.iqbf2.registro.notificacion.util;

import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

public class AuditoriaUtil {

	private static ThreadLocal<UsuarioBean> tLocal = new ThreadLocal<UsuarioBean>();

	public static void set(UsuarioBean envioBean) {
		tLocal.set(envioBean);
	}

	public static UsuarioBean get() {
		return (UsuarioBean) tLocal.get();
	}

}
