package pe.gob.sunat.iqbf2.registro.notificacion.util;

public class DocumentoIndividualConstantes {
	
	//PAGES
	public static final String REGISTRAR_DOCUMENTO_INDIVIDUAL_PAGE = "individual/registrarDocumentoIndividual";
	public static final String BANDEJA_DOCUMENTO_INDIVIDUAL_PAGE = "individual/bandejaDocumentoIndividual";
	public static final String CONSULTA_DOCUMENTO_INDIVIDUAL_PAGE = "individual/consultarDocumentoIndividual";
	

	
	
	
	//ejemplo

	
	//CODIGO DE OPERACION - EXITO - ERROR
	public static final String EXITO_OPERACION = "00";
	public static final String ERROR_OPERACION = "01";
	
	//CODIGO DE OPERACION - EXITO - ERROR
	public static final String EXITO_CONSULTA = "00";
	public static final String ERROR_CONSULTA = "01";
	
	
	
	//PAGE - CALLER
	public static final String PAGE_CALLER_BANDEJA_RENDICION_REVISION = "01";
	public static final String PAGE_CALLER_BANDEJA_RENDICION_CONSULTA = "02";
	public static final String PAGE_CALLER_BANDEJA_RENDICION_NOTIFICACION = "03";
	
		
	//PROPERTIES
	public static final String MENSAJE_ERROR_GENERICO = "error.mensaje.generico";
	public static final String MENSAJE_ERROR_ACCESO = "error.mensaje.acceso";
	public static final String MENSAJE_ERROR_PLANILLA_NO_EXISTE = "error.mensaje.nroPlanillaNoExiste";
	public static final String MENSAJE_REGISTRO_RENDICION_EXITOSO = "registrarModificarRendicion.message.grabacionExitosa";
	public static final String MENSAJE_CIERRE_RENDICION_EXITOSO = "registrarModificarRendicion.message.cierreExitoso";
	public static final String MENSAJE_CIERRE_RENDICION_EXITOSO_CAJA = "registrarModificarRendicion.message.cierreExitosoCajaChica";
	public static final String MENSAJE_CIERRE_RENDICION_EXITOSO_FINANZAS = "registrarModificarRendicion.message.cierreExitosoFinanciera";
	
	
	

	// BANDEJA DE CONSULTAS - CUS10
	public static final Integer BANDEJA_NUMERO_ANIOS_RANGO = 5;
	public static final String BANDEJA_CONSULTA_MENSAJE_ERROR_PLANILLA_NO_EXISTE = "consultarSolicitudBandeja.messageError.numeroPlanillaNoExiste";
	public static final String BANDEJA_REVISION_MENSAJE_ERROR_PLANILLA_NO_EXISTE = "revisarSolicitudBandeja.messageError.numeroPlanillaNoExiste";
	public static final String BANDEJA_ALTA_MENSAJE_ERROR_PLANILLA_NO_EXISTE = "altaSolicitudBandeja.messageError.numeroPlanillaNoExiste";
	public static final String BANDEJA_REVISION_MENSAJE_ERROR_SOLICITUD_NO_EXISTE = "revisarReembolsoBandeja.messageError.numeroPlanillaNoExiste";
	public static final String BANDEJA_CONSULTA_MENSAJE_ERROR_SOLICITUD_NO_EXISTE = "consultarReembolsoBandeja.messageError.numeroPlanillaNoExiste";
	
	
}