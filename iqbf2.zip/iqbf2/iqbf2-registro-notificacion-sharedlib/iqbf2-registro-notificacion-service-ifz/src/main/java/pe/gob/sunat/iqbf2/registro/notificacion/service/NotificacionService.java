package pe.gob.sunat.iqbf2.registro.notificacion.service;

import java.util.Collection;

import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.TipoDocumentoBean;
import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.TipoProcedimientoBean;

public interface NotificacionService {
	 
		
	Collection<TipoDocumentoBean>listarTipoDocumentos();
	Collection<TipoProcedimientoBean>listarTipoProcedimiento(String tipoDocumento);
	 

}
