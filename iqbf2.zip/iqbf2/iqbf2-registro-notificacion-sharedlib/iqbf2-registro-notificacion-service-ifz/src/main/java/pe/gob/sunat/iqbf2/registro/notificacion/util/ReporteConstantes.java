package pe.gob.sunat.iqbf2.registro.notificacion.util;

public class ReporteConstantes {
	
	// GENERALES
	public static final String CADENA_VACIA = "";
	public static final String ESPACIO = " ";
	public static final String SIN_REGISTROS = "No se encontraron registros.";
	public static final String CAMPO_VACIO = "---";
	public static final String RUTA_ARCHIVO_DATA0 = "/data0";
	public static final String RUTA__ARCHIVO_DATA0_TEM = "/data0/tempo";
	// BANDEJA
	public static final String BANDEJA_SOLICITUD = "Solicitud";
	public static final String BANDEJA_AUTORIZACION_SOLICITUD = "Solicitud";
	public static final String BANDEJA_CONSULTA_RENDICION = "Rendicion";
	public static final String BANDEJA_NOTIFICACION_RENDICION = "Rendicion";
	public static final String BANDEJA_AUTORIZACION_REEMBOLSO = "Reembolso";

	// TIPOS DE BANDEJA
	public static final String TIPO_BANDEJA_REVISION_SOLICITUD = "01";
	public static final String TIPO_BANDEJA_CONSULTA_SOLICITUD = "02";
	public static final String TIPO_BANDEJA_ALTA_FECHA_SOLICITUD = "03";
	public static final String TIPO_BANDEJA_AUTORIZAR = "04";
	public static final String TIPO_BANDEJA_REVISION_REEMBOLSO = "05";
	public static final String TIPO_BANDEJA_CONSULTA_REEMBOLSO = "06";
	
	// NOMBRE DE ARCHIVO PDF
	public static final String PLANILLA_VIATICO_NOMBRE_ARCHIVO = "planilla_viatico.pdf"; 
	public static final String PLANILLA_RENDICION_VIATICO_NOMBRE_ARCHIVO = "planilla_rendicion_viatico.pdf";
	public static final String PLANILLA_REEMBOLSO_VIATICO_NOMBRE_ARCHIVO = "planilla_reembolso_viatico.pdf"; 
	public static final String PLANILLA_RENDICION_DECLARACION_JURADA_NOMBRE_ARCHIVO = "planilla_rendicion_declaracion_jurada.pdf";
	public static final String PLANILLA_RENDICION_DECLARACION_JURADA_PERMANENCIA_NOMBRE_ARCHIVO = "planilla_rendicion_declaracion_jurada_permanencia.pdf";
	
	// ARCHIVOS JASPERS
	public static final String PLANILLA_VIATICO_NACIONAL = "planilla_viatico_nacional.jasper";
	public static final String PLANILLA_VIATICO_INTERNACIONAL = "planilla_viatico_internacional.jasper";
	public static final String PLANILLA_RENDICION_VIATICO = "planilla_rendicion_viatico.jasper";
	public static final String PLANILLA_RENDICION_DECLARACION_JURADA = "planilla_declaracion_jurada.jasper";
	public static final String PLANILLA_RENDICION_DECLARACION_JURADA_PERMANENCIA = "planilla_declaracion_jurada_permanencia.jasper";
	public static final String PLANILLA_REEMBOLSO_VIATICO = "planilla_reembolso_viatico.jasper";
	
	
	public static final String CUERPO_IMPRESION_DECLARACION_PERMANENCIA = "Yo p_nombreColaborador, con Registro N° p_numeroRegistro Identificada(a) con DNI N° p_numeroDNI colaborador (a) de la p_unidadOrganizacional, declaro bajo juramento que la comisón de servicio llevada a cabo en la ciudad(es) de p_ciudad, por motivo de p_motivo, tuvo una duración de p_horas horas, tiempo estimado desde la salida de mi lugar de origen hasta el retorno, habiéndose iniciado a las p_fechaInicio horas y concluido a las horas  de p_fechaFin horas del día del mes de p_mes del p_anio.";
	public static final String CUERPO_IMPRESION_DECLARACION = "Yo p_nombreColaborador, con Registro N° p_numeroRegistro identificado (a) con DNI N° p_numeroDNI colaborador(a) de la p_unidadOrganizacional, declaro bajo juramento haber efectuado los gastos que detallo en cuadro adjunto, en la comisión de de servicios a la ciudad(es) p_ciudad por el período comprendido del p_fechaInicio al p_fechaFin, con motivo de: p_motivo.";
}
