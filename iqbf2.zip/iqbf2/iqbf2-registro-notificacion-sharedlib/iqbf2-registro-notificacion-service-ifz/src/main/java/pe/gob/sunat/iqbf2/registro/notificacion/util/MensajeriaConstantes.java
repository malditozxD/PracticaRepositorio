package pe.gob.sunat.iqbf2.registro.notificacion.util;

import java.text.MessageFormat;

public class MensajeriaConstantes {
	
	//TIPO VIATICOS
	public static final String TIPO_MENSAJE_PARA = "PARA";
	public static final String TIPO_MENSAJE_CC = "CC";
	public static final String TIPO_MENSAJE_OCC = "BCC";
	
	//CODIGO MENSAJE
	public static final String CODIGO_REGISTRO_SOLICITUD = "VIAW00001";
	public static final String CODIGO_NOTIFICACION_ANULACION_SOLICITUD_REGISTRADOR_COLABORADOR = "VIAW00002";
	public static final String CODIGO_NOTIFICACION_AUTORIZACION_SOLICITUD_CAJA_CHICA = "VIAW00003";
	public static final String CODIGO_NOTIFICACION_ANULACION_SOLICITUD = "VIAW00004";
	public static final String CODIGO_NOTIFICACION_OBSERVACION_SOLICITUD = "VIAW00005";
	public static final String CODIGO_NOTIFICACION_REPROGRAMACION_FECHA_RENDICION = "VIAW00016";


	//ASUNTO MENSAJE
	public static final String ASUNTO_REGISTRO_SOLICITUD = "NOTIFICACIÓN DE REGISTRO DE SOLICITUD DE VIATICOS";
	public static final String ASUNTO_NOTIFICACION_AUTORIZACION_SOLICITUD_CAJA_CHICA = "NOTIFICACIÓN DE AUTORIZACION DE PLANILLA DE VIATICOS - PAGO POR CAJA CHICA";
	
	
  
	
	//CODIGO DE OPERACION - EXITO - ERROR
	public static final String EXITO_OPERACION = "00";
	public static final String ERROR_OPERACION = "01";
	
	//PROPERTIES CORREO
	public static final String NOTIFICACION_CUERPO_1 = "notificacion.cuerpo1";
	public static final String NOTIFICACION_CUERPO_2 = "notificacion.cuerpo2";
	public static final String NOTIFICACION_AUTORIZACION_TITULO = "notificacionAutorizacion.titulo";
	public static final String NOTIFICACION_AUTORIZACION_CUERPO = "notificacionAutorizacion.cuerpo";

	
	public static void main(String[] aaa){
		int fileCount = 1273;
		 String diskName = "MyDisk";
		 Object[] testArgs = {new Long(fileCount), diskName,"argumento3","argumento4"};

		 MessageFormat form = new MessageFormat("The disk \"{2}\" contains {3} file(s).");
		 System.out.println(form.format(testArgs));
	}
}
