package pe.gob.sunat.iqbf2.registro.notificacion.afiliacion.service;

import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.RegistroAfiliacionBean;

/**
 * Interfaz RegistroAfiliacionService.
 * 
 * @author emarchena
 */
public interface RegistroAfiliacionService {
	
	
	
	/**
	 * Metodo que permite validar si un usuario esta Afiliado.
	 * 
	 * @author emarchena.
	 * @param codRuc :Ruc de Usuario.
	 * @return true/false
	 * @throws Exception
	 */
	public boolean validarAfiliacion(String codRuc)throws Exception;
	
	
	/**
	 * Metodo que permite registrar una Afiliación de Usuario
	 * 
	 * @author emarchena
	 * @param RegistroAfiliacionBean Datos a registrar
	 * @return RegistroAfiliacionBean Datos Registrados
	 * @throws Exception
	 */
	RegistroAfiliacionBean registrarAfiliacion( RegistroAfiliacionBean registroAfiliacionBean ) throws Exception;

	/**
	 * Metodo que permite registrar una Afiliación de Usuario
	 * 
	 * @author emarchena
	 * @param RegistroAfiliacionBean Datos a registrar
	 * @return RegistroAfiliacionBean Datos Registrados
	 * @throws Exception
	 */
	RegistroAfiliacionBean obtenerAfiliacion(String ruc ) throws Exception;

}
