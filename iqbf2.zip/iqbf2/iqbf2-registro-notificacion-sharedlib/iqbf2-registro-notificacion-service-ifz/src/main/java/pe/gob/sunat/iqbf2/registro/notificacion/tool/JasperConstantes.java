package pe.gob.sunat.iqbf2.registro.notificacion.tool;

public class JasperConstantes {

	public static final String RUTA_JASPER = "/data0/generador/jasper/plantillas/notificacion/";
	public static final String RUTA_PDF = "/data0/generador/jasper/plantillas/notificacion/";
	public static final String RUTA_JASPER_VIATICOS = "/data0/generador/jasper/plantillas/notificacion/";
	public static final String RUTA_PDF_VIATICOS = "/data0/generador/jasper/plantillas/notificacion/";

}
