package pe.gob.sunat.iqbf2.registro.notificacion.documento.service;


import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.PaqueteBean;

public interface DocumentoMasivoService {
	
	public PaqueteBean obtenerPaquete(String codPaquete);
	public String generarDocumentosMasivo(PaqueteBean paqueteBean);
	public String proyectarDocumentosMasivo(PaqueteBean paqueteBean);
	

	
	//metodos de revision 
	public String iniciarPaquete(PaqueteBean paqueteBean );
	public String devolverPaquete(PaqueteBean paqueteBean );
	
	public String enviarPaquete(PaqueteBean paqueteBean );
	public String rechazarPaquete(PaqueteBean paqueteBean );
	
}
