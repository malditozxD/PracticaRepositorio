package pe.gob.sunat.iqbf2.registro.notificacion.model.bean;

public class ContribuyenteBean {
	private String ruc;
	private String razonSocial;
	
	
	
	
	public String getRuc() {
		return ruc;
	}
	public void setRuc(String ruc) {
		this.ruc = ruc;
	}
	public String getRazonSocial() {
		return razonSocial;
	}
	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}
	
	
	
}
