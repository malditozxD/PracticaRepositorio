package pe.gob.sunat.iqbf2.registro.notificacion.model.bean;

import java.io.Serializable;
import java.util.List;

public class PaqueteBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String 	codPaquete ;
	private Integer numRegistro  ;
	private Integer codTipoFormato ;
	
	private List<DocumentoIqbfBean> listaDocumentos;
	
	
	
	
	
	public List<DocumentoIqbfBean> getListaDocumentos() {
		return listaDocumentos;
	}
	public void setListaDocumentos(List<DocumentoIqbfBean> listaDocumentos) {
		this.listaDocumentos = listaDocumentos;
	}
	public String getCodPaquete() {
		return codPaquete;
	}
	public void setCodPaquete(String codPaquete) {
		this.codPaquete = codPaquete;
	}
	public Integer getNumRegistro() {
		return numRegistro;
	}
	public void setNumRegistro(Integer numRegistro) {
		this.numRegistro = numRegistro;
	}
	public Integer getCodTipoFormato() {
		return codTipoFormato;
	}
	public void setCodTipoFormato(Integer codTipoFormato) {
		this.codTipoFormato = codTipoFormato;
	}
	
	 

}
