package pe.gob.sunat.iqbf2.registro.notificacion.model.bean;

import java.io.Serializable;

public class TipoDocumentoBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String 	codTipoDoc ;
	private String 	desTipoDoc;
	private String  indOrigen;
	private String  indEstado;
	
	
	
	public String getCodTipoDoc() {
		return codTipoDoc;
	}
	public void setCodTipoDoc(String codTipoDoc) {
		this.codTipoDoc = codTipoDoc;
	}
	public String getDesTipoDoc() {
		return desTipoDoc;
	}
	public void setDesTipoDoc(String desTipoDoc) {
		this.desTipoDoc = desTipoDoc;
	}
	public String getIndOrigen() {
		return indOrigen;
	}
	public void setIndOrigen(String indOrigen) {
		this.indOrigen = indOrigen;
	}
	public String getIndEstado() {
		return indEstado;
	}
	public void setIndEstado(String indEstado) {
		this.indEstado = indEstado;
	}

	
	

}
