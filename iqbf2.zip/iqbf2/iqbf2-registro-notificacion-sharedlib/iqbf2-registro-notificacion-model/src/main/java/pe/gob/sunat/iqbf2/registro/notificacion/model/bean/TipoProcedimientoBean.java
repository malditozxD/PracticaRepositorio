package pe.gob.sunat.iqbf2.registro.notificacion.model.bean;

import java.io.Serializable;

public class TipoProcedimientoBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String codTipoProc ;
	private String desTipoProc ; 
	private String indEstado ;
	private String nomTipoProc ;
	private String codTipoDoc ;
	
	
	public String getCodTipoProc() {
		return codTipoProc;
	}
	public void setCodTipoProc(String codTipoProc) {
		this.codTipoProc = codTipoProc;
	}
	public String getDesTipoProc() {
		return desTipoProc;
	}
	public void setDesTipoProc(String desTipoProc) {
		this.desTipoProc = desTipoProc;
	}
	public String getIndEstado() {
		return indEstado;
	}
	public void setIndEstado(String indEstado) {
		this.indEstado = indEstado;
	}
	public String getNomTipoProc() {
		return nomTipoProc;
	}
	public void setNomTipoProc(String nomTipoProc) {
		this.nomTipoProc = nomTipoProc;
	}
	public String getCodTipoDoc() {
		return codTipoDoc;
	}
	public void setCodTipoDoc(String codTipoDoc) {
		this.codTipoDoc = codTipoDoc;
	}
	
	
	
	
	
	
	
}
