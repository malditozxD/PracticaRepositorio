package pe.gob.sunat.iqbf2.registro.notificacion.model.bean;

import java.io.Serializable;

public class PaqueteDocumentoBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String 	codPaquete ;
	private String 	codDocumento;
	
	
	public String getCodPaquete() {
		return codPaquete;
	}
	public void setCodPaquete(String codPaquete) {
		this.codPaquete = codPaquete;
	}
	public String getCodDocumento() {
		return codDocumento;
	}
	public void setCodDocumento(String codDocumento) {
		this.codDocumento = codDocumento;
	}
	
	
	

}
