package pe.gob.sunat.iqbf2.registro.notificacion.model.bean;

import java.io.Serializable;
import java.util.Date;

public class RegistroAfiliacionBean implements Serializable{
	
	private static final long serialVersionUID = 7281404914136497098L;
	private String 	codigoRuc;
	private Date 	fechaAfiliacion;
	private Date 	fechaAlta;
	private String 	codigoEstado;
	private Date 	codigoArchivo;
	
	
	
	
	
	public String getCodigoRuc() {
		return codigoRuc;
	}
	public void setCodigoRuc(String codigoRuc) {
		this.codigoRuc = codigoRuc;
	}
	public Date getFechaAfiliacion() {
		return fechaAfiliacion;
	}
	public void setFechaAfiliacion(Date fechaAfiliacion) {
		this.fechaAfiliacion = fechaAfiliacion;
	}
	public Date getFechaAlta() {
		return fechaAlta;
	}
	public void setFechaAlta(Date fechaAlta) {
		this.fechaAlta = fechaAlta;
	}
	public String getCodigoEstado() {
		return codigoEstado;
	}
	public void setCodigoEstado(String codigoEstado) {
		this.codigoEstado = codigoEstado;
	}
	public Date getCodigoArchivo() {
		return codigoArchivo;
	}
	public void setCodigoArchivo(Date codigoArchivo) {
		this.codigoArchivo = codigoArchivo;
	}
	
	
	
	

}
