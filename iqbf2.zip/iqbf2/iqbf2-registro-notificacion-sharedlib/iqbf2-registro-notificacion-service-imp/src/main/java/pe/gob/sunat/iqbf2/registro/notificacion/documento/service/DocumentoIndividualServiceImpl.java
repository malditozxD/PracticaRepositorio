package pe.gob.sunat.iqbf2.registro.notificacion.documento.service;

import java.util.Collection;
import java.util.Map;

import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.DocumentoIqbfBean;
import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.PaqueteDocumentoBean;
import pe.gob.sunat.iqbf2.registro.notificacion.model.dao.DocumentoIqbfDAO;
import pe.gob.sunat.iqbf2.registro.notificacion.model.dao.PaqueteDocumentoDAO;
import pe.gob.sunat.iqbf2.registro.notificacion.service.NotificacionMensajeriaService;

public class DocumentoIndividualServiceImpl implements DocumentoIndividualService {
	DocumentoIqbfDAO documentoIqbfDAO;
	PaqueteDocumentoDAO paqueteDocumentoDAO;
	NotificacionMensajeriaService  notificacionMensajeriaService;
	
	
	
	
	

	public DocumentoIqbfDAO getDocumentoIqbfDAO() {
		return documentoIqbfDAO;
	}

	public void setDocumentoIqbfDAO(DocumentoIqbfDAO documentoIqbfDAO) {
		this.documentoIqbfDAO = documentoIqbfDAO;
	}

	public PaqueteDocumentoDAO getPaqueteDocumentoDAO() {
		return paqueteDocumentoDAO;
	}

	public void setPaqueteDocumentoDAO(PaqueteDocumentoDAO paqueteDocumentoDAO) {
		this.paqueteDocumentoDAO = paqueteDocumentoDAO;
	}

	public NotificacionMensajeriaService getNotificacionMensajeriaService() {
		return notificacionMensajeriaService;
	}

	public void setNotificacionMensajeriaService(
			NotificacionMensajeriaService notificacionMensajeriaService) {
		this.notificacionMensajeriaService = notificacionMensajeriaService;
	}
	
	

	@Override
	public DocumentoIqbfBean obtenerDocumento(String codDocumento) {
		// TODO Auto-generated method stub
		documentoIqbfDAO.getDocumento(codDocumento);
		return null;
	}

	@Override
	public Collection<DocumentoIqbfBean> listarDocumentos(
			Map<String, Object> parm) {
		// TODO Auto-generated method stub
		return  documentoIqbfDAO.buscarDocumento(parm);
	}

	@Override
	public String registrarDocumento(DocumentoIqbfBean documentoIqbfBean) {
		// TODO Auto-generated method stub
		documentoIqbfDAO.insertDocumento(documentoIqbfBean);
		return null;
	}

	@Override
	public String proyectarDocumento(DocumentoIqbfBean documentoIqbfBean) {
		// TODO Auto-generated method stub
		documentoIqbfDAO.updateDocumento(documentoIqbfBean);
		notificacionMensajeriaService.enviarCorreoAprobarIndividual(documentoIqbfBean);
		
		return null;
	}

	@Override
	public String registrarDocumentoPaquete(
			PaqueteDocumentoBean paqueteDocumentoBean) {
		// TODO Auto-generated method stub
		paqueteDocumentoDAO.insertPaqueteDocumento(paqueteDocumentoBean);
		return null;
	}

	@Override
	public String darBajaDocumento(DocumentoIqbfBean documentoIqbfBean) {
		// TODO Auto-generated method stub
		documentoIqbfDAO.updateDocumento(documentoIqbfBean);
		
		return null;
	}

	@Override
	public String iniciarDocumento(DocumentoIqbfBean documentoIqbfBean) {
		documentoIqbfDAO.updateDocumentoEstado(documentoIqbfBean);
		notificacionMensajeriaService.enviarCorreoEnviarNotificarIndividual(documentoIqbfBean);
		return null;
	}

	@Override
	public String devolverDocumento(DocumentoIqbfBean documentoIqbfBean) {
		documentoIqbfDAO.updateDocumentoObserva(documentoIqbfBean);
		notificacionMensajeriaService.enviarCorreoDevolverIndividual(documentoIqbfBean);
		return null;
	}

	@Override
	public String enviarDocumento(DocumentoIqbfBean documentoIqbfBean) {
		// TODO Auto-generated method stub
		documentoIqbfDAO.updateDocumentoEstado(documentoIqbfBean);
		return null;
	}

	@Override
	public String rechazarDocumento(DocumentoIqbfBean documentoIqbfBean) {
		// TODO Auto-generated method stub
		documentoIqbfDAO.updateDocumentoObserva(documentoIqbfBean);
		notificacionMensajeriaService.enviarCorreoRechazarIndividual(documentoIqbfBean);
		return null;
	}

	@Override
	public Collection<DocumentoIqbfBean> consultarDocumentosEnviados(
			Map<String, Object> parm) {
		// TODO Auto-generated method stub
		return null;
	}

}
