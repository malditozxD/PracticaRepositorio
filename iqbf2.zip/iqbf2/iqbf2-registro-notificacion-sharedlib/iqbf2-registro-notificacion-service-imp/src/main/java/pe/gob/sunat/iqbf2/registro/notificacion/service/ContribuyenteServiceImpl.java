package pe.gob.sunat.iqbf2.registro.notificacion.service;

import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.ContribuyenteBean;

public class ContribuyenteServiceImpl implements ContribuyenteService {

	@Override
	public ContribuyenteBean obtenerContribuyente(String Ruc) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String validarContribuyente(String ruc) {
		// TODO Auto-generated method stub
		return null;
	}

}
