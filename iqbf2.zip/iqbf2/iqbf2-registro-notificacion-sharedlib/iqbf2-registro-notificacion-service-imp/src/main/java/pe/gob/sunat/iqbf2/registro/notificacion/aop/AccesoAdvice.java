package pe.gob.sunat.iqbf2.registro.notificacion.aop;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.AfterReturningAdvice;
import org.springframework.aop.MethodBeforeAdvice;
import org.springframework.aop.ThrowsAdvice;

import pe.gob.sunat.iqbf2.registro.notificacion.util.AuditoriaUtil;

import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

public class AccesoAdvice implements MethodBeforeAdvice, AfterReturningAdvice, ThrowsAdvice {

	protected final Log log = LogFactory.getLog(getClass());



	/**
	 * Aspecto ejecutado antes de la ejecucion del servicio de grabacion
	 * */
	public void before(Method metodoEjecutado, Object[] argumentos, Object instancia) throws Throwable {
		// TODO Auto-generated method stub
		UsuarioBean usuarioBean = AuditoriaUtil.get();
		log.info("Iniciando metodo AccesoAdvice.before(...) con usuario:" + usuarioBean.getLogin());

		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("codVariable", "USER");
		parametros.put("valVariable", usuarioBean.getLogin().toUpperCase());
		log.info("datos a enviar para setear entorno:" + parametros);
		
		log.info("metodo AccesoAdvice.before(...) terminado.");
	}

	/**
	 * Aspecto ejecutado luego de la ejecucion del servicio de grabacion
	 * */
	public void afterReturning(Object retorno, Method metodo, Object[] argumentos, Object instancia) throws Throwable {
		log.info("Iniciando metodo AccesoAdvice.afterReturning(...) para limpiar la variable de sesion");
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("codVariable", "USER");
		
		log.info("metodo AccesoAdvice.afterReturning(...) terminado.");
	}

	/**
	 * Aspecto ejecutado si el servicio de grabacion a retornado un
	 * */
	public void afterThrowing(Method metodo, Object[] argumentos, Object instancia, Exception exception) {
		log.info("Iniciando metodo AccesoAdvice.afterThrowing(...) para limpiar la variable de sesion");
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("codVariable", "USER");
		
		log.info("metodo AccesoAdvice.afterThrowing(...) terminado.");
	}

}
