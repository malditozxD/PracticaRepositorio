package pe.gob.sunat.iqbf2.registro.notificacion.service;

import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.RegistroAfiliacionBean;
import pe.gob.sunat.iqbf2.registro.notificacion.tool.JasperBean;

public class NotificacionJasperServiceImpl implements NotificacionJasperService {

	@Override
	public JasperBean generarConstanciaAfiliacionPDF(
			RegistroAfiliacionBean registroAfiliacionBean) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	

	

}
