package pe.gob.sunat.iqbf2.registro.notificacion.afiliacion.service;


import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.RegistroAfiliacionBean;
import pe.gob.sunat.iqbf2.registro.notificacion.model.dao.RegistroAfiliacionDAO;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


public class RegistroAfiliacionServiceImpl implements RegistroAfiliacionService {
	protected final Log log = LogFactory.getLog(getClass());
	private RegistroAfiliacionDAO registroAfiliacionDAO;
	
	
	
	public RegistroAfiliacionDAO getRegistroAfiliacionDAO() {
		return registroAfiliacionDAO;
	}

	public void setRegistroAfiliacionDAO(RegistroAfiliacionDAO registroAfiliacionDAO) {
		this.registroAfiliacionDAO = registroAfiliacionDAO;
	}

	
	@Override
	public boolean validarAfiliacion(String codRuc) throws Exception {
		// TODO Auto-generated method stub
		registroAfiliacionDAO.obtenerAfliado(codRuc);
		return false;
	}

	@Override
	public RegistroAfiliacionBean registrarAfiliacion(
			RegistroAfiliacionBean registroAfiliacionBean) throws Exception {
		if (log.isDebugEnabled()){ log.debug("debug Inicio - RegistroAfiliacionServiceImpl.registrarSolicitudViatico");}
		try{
			registroAfiliacionDAO.insertAfiliacion(registroAfiliacionBean);
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			
		}
		finally{
			log.debug("Fin RegistroAfiliacionServiceImpl -- registrarSolicitudViatico");
		}
		return registroAfiliacionBean;
	}

	@Override
	public RegistroAfiliacionBean obtenerAfiliacion(String ruc)
			throws Exception {
		registroAfiliacionDAO.obtenerAfliado(ruc);
		return null;
	}

}
