package pe.gob.sunat.iqbf2.registro.notificacion.service;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.TipoDocumentoBean;
import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.TipoProcedimientoBean;
import pe.gob.sunat.iqbf2.registro.notificacion.model.dao.TipoDocumentoDAO;
import pe.gob.sunat.iqbf2.registro.notificacion.model.dao.TipoProcedimientoDAO;

public class NotificacionServiceImpl implements NotificacionService{
	TipoDocumentoDAO tipoDocumentoDAO;
	TipoProcedimientoDAO tipoProcedimientoDAO;
	

	public TipoDocumentoDAO getTipoDocumentoDAO() {
		return tipoDocumentoDAO;
	}

	public void setTipoDocumentoDAO(TipoDocumentoDAO tipoDocumentoDAO) {
		this.tipoDocumentoDAO = tipoDocumentoDAO;
	}

	public TipoProcedimientoDAO getTipoProcedimientoDAO() {
		return tipoProcedimientoDAO;
	}

	public void setTipoProcedimientoDAO(TipoProcedimientoDAO tipoProcedimientoDAO) {
		this.tipoProcedimientoDAO = tipoProcedimientoDAO;
	}
	

	@Override
	public Collection<TipoDocumentoBean> listarTipoDocumentos() {
		// TODO Auto-generated method stub
		Map<String, Object> parm = new HashMap<String, Object>();
		tipoDocumentoDAO.buscarTipoDocumento(parm);
		return null;
	}

	@Override
	public Collection<TipoProcedimientoBean> listarTipoProcedimiento(
			String tipoDocumento) {
		Map<String, Object> parm = new HashMap<String, Object>();
		tipoProcedimientoDAO.buscarTipoProcedimiento(parm);
		return null;
	}

}
