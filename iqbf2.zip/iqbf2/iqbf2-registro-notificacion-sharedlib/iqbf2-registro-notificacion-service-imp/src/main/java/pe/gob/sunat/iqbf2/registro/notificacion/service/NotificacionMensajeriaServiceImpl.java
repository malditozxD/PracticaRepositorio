package pe.gob.sunat.iqbf2.registro.notificacion.service;

import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.DocumentoIqbfBean;
import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.PaqueteBean;




public class NotificacionMensajeriaServiceImpl  implements NotificacionMensajeriaService {

	@Override
	public void enviarCorreoAprobarIndividual(
			DocumentoIqbfBean documentoIqbfBean) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void enviarCorreoAprobarMasivo(PaqueteBean paqueteBean) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void enviarCorreoDevolverIndividual(
			DocumentoIqbfBean documentoIqbfBean) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void enviarCorreoDevolverMasivo(PaqueteBean paqueteBean) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void enviarCorreoEnviarNotificarIndividual(
			DocumentoIqbfBean documentoIqbfBean) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void enviarCorreoEnviarNotificarMasivo(PaqueteBean paqueteBean) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void enviarCorreoRechazarIndividual(
			DocumentoIqbfBean documentoIqbfBean) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void enviarCorreoRechazarMasivo(PaqueteBean paqueteBean) {
		// TODO Auto-generated method stub
		
	}
	


}
