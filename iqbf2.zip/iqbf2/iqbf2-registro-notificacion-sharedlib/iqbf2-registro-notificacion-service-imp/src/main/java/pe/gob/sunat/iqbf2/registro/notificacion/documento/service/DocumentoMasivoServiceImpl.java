package pe.gob.sunat.iqbf2.registro.notificacion.documento.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.DocumentoIqbfBean;
import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.PaqueteBean;

import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.PaqueteDocumentoBean;
import pe.gob.sunat.iqbf2.registro.notificacion.model.dao.PaqueteDAO;
import pe.gob.sunat.iqbf2.registro.notificacion.model.dao.PaqueteDocumentoDAO;
import pe.gob.sunat.iqbf2.registro.notificacion.service.ContribuyenteService;
import pe.gob.sunat.iqbf2.registro.notificacion.service.NotificacionMensajeriaService;

public class DocumentoMasivoServiceImpl  implements DocumentoMasivoService{
	ContribuyenteService contribuyenteService;
	DocumentoIndividualService  documentoIndividualService;
	PaqueteDAO paqueteDAO;
	PaqueteDocumentoDAO paqueteDocumentoDAO;
	NotificacionMensajeriaService  notificacionMensajeriaService;
	
	@Override
	public PaqueteBean obtenerPaquete(String codPaquete) {
			Map<String, Object> parm = new HashMap<String, Object>();
			parm.put("codPaquete",codPaquete);
			PaqueteBean  paqueteBean = paqueteDAO.getPaquete(codPaquete);
			List<PaqueteDocumentoBean> listaTem=(List<PaqueteDocumentoBean>) paqueteDocumentoDAO.buscarPaqueteDocumento(parm);
			List<DocumentoIqbfBean> listaDocumentos= new ArrayList<DocumentoIqbfBean>();
			for (PaqueteDocumentoBean obj : listaTem) {
				DocumentoIqbfBean documento= documentoIndividualService.obtenerDocumento(obj.getCodDocumento());
				listaDocumentos.add(documento);
			}
			paqueteBean.setListaDocumentos(listaDocumentos);
		return paqueteBean;
	}

	@Override
	public String generarDocumentosMasivo(PaqueteBean paqueteBean) {
		// TODO Auto-generated method stub
		String ruc = StringUtils.EMPTY;
		List<DocumentoIqbfBean> listaTem = paqueteBean.getListaDocumentos();
		PaqueteBean paquete= new PaqueteBean();
		paqueteDAO.insertPaquete(paquete);
		for( DocumentoIqbfBean obj : listaTem ){
			
			DocumentoIqbfBean documento = new DocumentoIqbfBean();
			PaqueteDocumentoBean paqueteDocumentoBean= new PaqueteDocumentoBean();
			contribuyenteService.validarContribuyente(obj.getRuc() );
			
			documentoIndividualService.registrarDocumento(documento);
			documentoIndividualService.registrarDocumentoPaquete(paqueteDocumentoBean );
			
			
		}
		
		
		return null;
	}

	@Override
	public String proyectarDocumentosMasivo(PaqueteBean paqueteBean) {
		// TODO Auto-generated method stub
		for (DocumentoIqbfBean obj : paqueteBean.getListaDocumentos()) {
			documentoIndividualService.proyectarDocumento(obj);
		}
		notificacionMensajeriaService.enviarCorreoAprobarMasivo(paqueteBean);
		return null;
	}

	@Override
	public String iniciarPaquete(PaqueteBean paqueteBean) {

		for (DocumentoIqbfBean obj : paqueteBean.getListaDocumentos()) {
			documentoIndividualService.iniciarDocumento(obj);
		}
		notificacionMensajeriaService.enviarCorreoEnviarNotificarMasivo(paqueteBean);
		return null;
	}

	@Override
	public String devolverPaquete(PaqueteBean paqueteBean) {
		// TODO Auto-generated method stub
		for (DocumentoIqbfBean obj : paqueteBean.getListaDocumentos()) {
			documentoIndividualService.devolverDocumento(obj);
		}
		notificacionMensajeriaService.enviarCorreoDevolverMasivo(paqueteBean);
		return null;
	}

	@Override
	public String enviarPaquete(PaqueteBean paqueteBean) {
		for (DocumentoIqbfBean obj : paqueteBean.getListaDocumentos()) {
			documentoIndividualService.enviarDocumento(obj);
		}
		
		return null;
	}

	@Override
	public String rechazarPaquete(PaqueteBean paqueteBean) {
		for (DocumentoIqbfBean obj : paqueteBean.getListaDocumentos()) {
			documentoIndividualService.rechazarDocumento(obj);
		}
		notificacionMensajeriaService.enviarCorreoRechazarMasivo(paqueteBean);
		return null;
	}

}
