package pe.gob.sunat.iqbf2.registro.notificacion.service;

import pe.gob.sunat.iqbf2.registro.notificacion.tool.ArchivoBean;

public class NotificacionECMServiceImpl implements NotificacionECMService{

	@Override
	public String createDocumento(ArchivoBean archivoBean) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArchivoBean obtenerDocumento(String idEcm) {
		// TODO Auto-generated method stub
		return null;
	}

}
