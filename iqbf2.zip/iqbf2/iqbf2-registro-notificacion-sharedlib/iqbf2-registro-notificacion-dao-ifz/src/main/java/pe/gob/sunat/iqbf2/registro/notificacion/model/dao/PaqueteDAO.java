package pe.gob.sunat.iqbf2.registro.notificacion.model.dao;

import java.util.Collection;
import java.util.Map;


import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.PaqueteBean;

public interface PaqueteDAO {
	public PaqueteBean getPaquete(String codPaquete );
	public Collection<PaqueteBean> buscarPaquete( Map<String, Object> parm); 
	public void insertPaquete(PaqueteBean paqueteBean );
	public void updatePaquete(PaqueteBean paqueteBean );
	
}
