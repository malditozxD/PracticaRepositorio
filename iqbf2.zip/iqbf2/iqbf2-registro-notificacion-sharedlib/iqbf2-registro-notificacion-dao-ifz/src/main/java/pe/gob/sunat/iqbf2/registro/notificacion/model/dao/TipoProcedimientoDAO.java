package pe.gob.sunat.iqbf2.registro.notificacion.model.dao;

import java.util.Collection;
import java.util.Map;


import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.TipoProcedimientoBean;

public interface TipoProcedimientoDAO {

	public TipoProcedimientoBean getTipoProcedimiento(String codTipoDoc );
	public Collection<TipoProcedimientoBean> buscarTipoProcedimiento( Map<String, Object> parm); 
}
