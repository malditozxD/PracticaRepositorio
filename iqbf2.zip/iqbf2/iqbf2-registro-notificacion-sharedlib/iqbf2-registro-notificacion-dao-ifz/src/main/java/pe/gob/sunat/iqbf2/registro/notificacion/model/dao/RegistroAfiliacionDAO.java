package pe.gob.sunat.iqbf2.registro.notificacion.model.dao;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.RegistroAfiliacionBean;

/**
 * Interfaz RegistroAfiliacionDAO.
 * 
 * @author emarchena
 */
public interface RegistroAfiliacionDAO {
	
	/**
	 * Metodo que permite obtener si un ruc esta afiliado.
	 * 
	 * @author emarchena.
	 * @param codRuc :Ruc de afiliado.
	 * @return Registro de Afiliacion.
	 * @see String
	 * @throws DataAccessException
	 */
	RegistroAfiliacionBean obtenerAfliado(String  codRuc) throws DataAccessException;
	
	
	/**
	 * Metodo que permite grabar la afiliacion.
	 * 
	 * @author emarchena.
	 * @param RegistroAfiliacionBean 
	 * @return void.
	 * @see String
	 * @throws DataAccessException
	 */
	
	void insertAfiliacion (RegistroAfiliacionBean registroAfiliacionBean) throws DataAccessException;
	
}
