package pe.gob.sunat.iqbf2.registro.notificacion.model.dao;

import java.util.Collection;
import java.util.Map;

import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.DocumentoIqbfBean;

public interface DocumentoIqbfDAO {
	
	public DocumentoIqbfBean getDocumento(String codDocumento );
	public Collection<DocumentoIqbfBean> buscarDocumento( Map<String, Object> parm); 
	public void insertDocumento(DocumentoIqbfBean documentoIqbfBean );
	public void updateDocumento(DocumentoIqbfBean documentoIqbfBean );
	public void updateDocumentoEstado(DocumentoIqbfBean documentoIqbfBean );
	public void updateDocumentoObserva(DocumentoIqbfBean documentoIqbfBean );
	
	
}
