package pe.gob.sunat.iqbf2.registro.notificacion.model.dao;

import java.util.Collection;
import java.util.Map;


import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.TipoDocumentoBean;

public interface TipoDocumentoDAO {
	
	public TipoDocumentoBean getTipoDocumento(String codTipoDoc );
	public Collection<TipoDocumentoBean> buscarTipoDocumento( Map<String, Object> parm); 

}
