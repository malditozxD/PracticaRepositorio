package pe.gob.sunat.iqbf2.registro.notificacion.model.dao;

import java.util.Collection;
import java.util.Map;

import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.PaqueteDocumentoBean;

public interface PaqueteDocumentoDAO {
	public PaqueteDocumentoBean getPaqueteDocumento(String codPaquete, String codDocumento );
	public Collection<PaqueteDocumentoBean> buscarPaqueteDocumento( Map<String, Object> parm); 
	public void insertPaqueteDocumento(PaqueteDocumentoBean paqueteDocumentoBean );
	public void updatePaqueteDocumento(PaqueteDocumentoBean paqueteDocumentoBean );
}
