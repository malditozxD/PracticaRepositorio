/*
 * 
 */
package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.TipoCambioBean;

/**
 * Interfaz TipoCambioDAO.
 * 
 * @author Juan Farro
 */
public interface TipoCambioDAO {

	/**
	 * Metodo que permite obtener el tipo de cambio (moneda dolares a soles) con la fecha actual
	 * 
	 * @author Juan Farro
	 * @return tipo de cambio
	 * @throws DataAccessException the data access exception
	 * @see TipoCambioBean
	 */
	TipoCambioBean obtenerTipoCambioSimboloDolaresHoy() throws DataAccessException;

	/**
	 * Metodo que permite obtener el tipo de cambio (moneda dolares a soles) con fecha mas reciente
	 * 
	 * @author Juan Farro
	 * @return tipo de cambio
	 * @throws DataAccessException the data access exception
	 * @see TipoCambioBean
	 */
	TipoCambioBean obtenerTipoCambioSimboloDolaresMasReciente() throws DataAccessException;

}
