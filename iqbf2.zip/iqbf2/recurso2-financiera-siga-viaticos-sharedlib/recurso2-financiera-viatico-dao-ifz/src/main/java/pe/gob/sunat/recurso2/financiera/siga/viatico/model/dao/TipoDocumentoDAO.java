package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao;

import java.util.ArrayList;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.TipoDocumentoBean;

public interface TipoDocumentoDAO {
	
	public ArrayList<TipoDocumentoBean> obtenerTipoDocumentoToComprobante(String abreviaturaTipoDocumento) throws DataAccessException;
}
