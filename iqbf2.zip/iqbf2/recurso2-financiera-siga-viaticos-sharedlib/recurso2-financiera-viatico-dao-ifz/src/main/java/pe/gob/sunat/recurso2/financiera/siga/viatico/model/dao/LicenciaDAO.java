package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.LicenciaBean;

/**
 * Interfaz LicenciaDAO.
 * 
 * @author Juan Farro 
 */
public interface LicenciaDAO {

	/**
	 * Metodo que permite obtener las licencias de un colaborador en un rango de fechas.
	 * 
	 * @author Juan Farro
	 * @see LicenciaBean
	 * @param params parametros de busqueda
	 * @return lista de licencias
	 * @throws DataAccessException
	 */
	List<LicenciaBean> listarLicencias(Map<String, Object> params) throws DataAccessException;

	/**
	 * Metodo que permite obtener las compensaciones de un colaborador en un rango de fechas.
	 * 
	 * @author Juan Farro
	 * @see LicenciaBean
	 * @param params parametros de busqueda
	 * @return lista de compensaciones
	 * @throws DataAccessException
	 */
	List<LicenciaBean> listarCompensacion(Map<String, Object> params) throws DataAccessException;

}
