package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.MetasBean;

/**
 * Interfaz MetasDAO.
 * 
 * @author Juan Saccatoma
 */
public interface MetasDAO {

	/**
	 * Metodo que permite obtener metas. 
	 * 
	 * @author Juan Saccatoma
	 * @see MetasBean
	 * @param secuFuncSfu secuFuncSfu
	 * @param codigoDependencia codigo de dependencia
	 * @param anioEjecucion anio de ejecucion
	 * @param ordenarPor campo por el cual ordenar
	 * @return lista de metas
	 * @throws DataAccessException
	 */
	List<MetasBean> obtenerMetas(String secuFuncSfu, String codigoDependencia, String anioEjecucion, String ordenarPor) throws DataAccessException;
}
