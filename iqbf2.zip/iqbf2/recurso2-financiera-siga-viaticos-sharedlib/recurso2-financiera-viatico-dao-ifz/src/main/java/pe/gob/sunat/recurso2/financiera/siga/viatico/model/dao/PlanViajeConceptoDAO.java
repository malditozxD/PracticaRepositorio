package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeConceptoBean;

/**
 * Interfaz PlanViajeConceptoDAO.
 * 
 * @author Juan Farro
 */
public interface PlanViajeConceptoDAO {

	/**
	 * Metodo que permite registrar plan viaje concepto.
	 * 
	 * @author Juan Farro
	 * @see PlanViajeConceptoBean
	 * @param planViajeConcepto plan viaje concepto
	 * @throws DataAccessException
	 */
	void registrarPlanViajeConcepto(PlanViajeConceptoBean planViajeConcepto) throws DataAccessException;

	/**
	 * Metodo que permite actualizar un plan viaje concepto.
	 * 
	 * @author Juan Farro
	 * @see PlanViajeConceptoBean
	 * @param planViajeConcepto plan viaje concepto
	 * @throws DataAccessException
	 */
	void actualizarPlanViajeConcepto(PlanViajeConceptoBean planViajeConcepto) throws DataAccessException;

	/**
	 * Metodo que permite buscar los plan viaje concepto asociados a una solicitud de viatico.
	 * 
	 * @author Juan Farro
	 * @see PlanViajeConceptoBean
	 * @param codPlanViaje codigo de solicitud de viatico
	 * @return lista de plan de viaje conceptos
	 * @throws DataAccessException
	 */
	List<PlanViajeConceptoBean> buscarPlanViajeConceptos(String codPlanViaje) throws DataAccessException;
	
	/**
	 * Metodo que permite obtener el listado de plan viaje concepto asociados a una solicitud.
	 * @author Jorge Ponce.
	 * @param  planViajeID :codigo plan viaje.
	 * @return Listado de plan de viaje concepto.
	 * @see    PlanViajeBean
	 * @throws DataAccessException
	 */
	ArrayList<PlanViajeConceptoBean> obtenerPlanViajeConceptoToRendicion(String planViajeID) throws DataAccessException;
	
	/**
	 * Metodo que permite actualizar el monto devuelto por voucher en el plan viaje concepto.
	 * @author Jorge Ponce.
	 * @param  planViajeConceptoBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	void actualizarMontoDevueltoVoucher(PlanViajeConceptoBean planViajeConceptoBean) throws DataAccessException;
	
	/**
	 * Metodo que permite actualizar el monto rendido por comprobante en el plan viaje concepto.
	 * @author Jorge Ponce.
	 * @param  planViajeConceptoBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	void actualizarMontoRendidoComprobante(PlanViajeConceptoBean planViajeConceptoBean) throws DataAccessException;
	
	/**
	 * Metodo que permite obtener los montos de plan viaje concepto asociados a una solicitud.
	 * @author Jorge Ponce.
	 * @param  planViajeID :codigo plan viaje.
	 * @param  conceptoID :codigo concepto.
	 * @return Plan de viaje concepto.
	 * @see    PlanViajeBean
	 * @throws DataAccessException
	 */
	PlanViajeConceptoBean obtenerPlanViajeConceptoMonto(String planViajeID, String conceptoID) throws DataAccessException;

	/**
	 * Metodo que permite eliminar los plan viaje concepto asociados a una solicitud de viatico.
	 * 
	 * @author Juan Farro
	 * @param codPlanViaje codigo de solicitud de viatico
	 * @throws DataAccessException
	 */
	void eliminarPlanViajeConceptos(String codPlanViaje) throws DataAccessException;
	
	/**
	 * Metodo que permite eliminar los plan viaje concepto asociados a una solicitud de viatico.
	 * 
	 * @author Samuel Dionisio
	 * @param codPlanViaje : String codigo de solicitud de viatico
	 * @param conceptoId : String id de concepto
	 * @throws DataAccessException
	 */
	void eliminarPlanViajeConceptos(String codPlanViaje, String conceptoId) throws DataAccessException;

}
