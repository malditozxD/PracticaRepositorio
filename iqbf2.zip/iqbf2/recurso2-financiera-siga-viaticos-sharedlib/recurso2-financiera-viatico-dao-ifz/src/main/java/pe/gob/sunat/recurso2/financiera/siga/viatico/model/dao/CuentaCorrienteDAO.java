package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao;

import java.util.ArrayList;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.CuentaCorrienteBean;

/**
 * Interface CuentaCorrienteDAO, contiene los metodos para la consulta y transaccion de la tabla CUENTA_CORRIENTE.
 * @author Jorge Ponce.
 */
public interface CuentaCorrienteDAO {
	
	/**
	 * Metodo que permite obtener el listado de cuentas corriente.
	 * @author Jorge Ponce.
	 * @param  simboloMoneda :simbolo de la moneda.
	 * @return Listado de cuentas corriente.
	 * @see    CuentaCorrienteBean
	 * @throws DataAccessException
	 */
	ArrayList<CuentaCorrienteBean> obtenerCuentasCorriente(String simboloMoneda) throws DataAccessException;
	
}
