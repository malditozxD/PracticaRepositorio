package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao;

import java.math.BigDecimal;
import java.util.ArrayList;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PapeletaDepositoBean;

/**
 * Interface PapeletaDepositoDAO, contiene los metodos para la consulta y transaccion de la tabla PAPELETAS_DEPOSITOS.
 * @author Jorge Ponce.
 */
public interface PapeletaDepositoDAO {
	
	/**
	 * Metodo que permite obtener el listado de papeletas de deposito asociados a un plan viaje.
	 * @author Jorge Ponce.
	 * @param  codigoPlanViaje :codigo plan viaje.
	 * @return Listado de papeletas deposito.
	 * @see    PapeletaDepositoBean
	 * @throws DataAccessException
	 */
	ArrayList<PapeletaDepositoBean> obtenerPapeletasDeposito(String codigoPlanViaje) throws DataAccessException;
	
	/**
	 * Metodo que permite obtener el secuencial (codigoBoletaDeposito) para la papeleta deposito a registrar.
	 * @author Jorge Ponce.
	 * @return Secuencial del codigo de boleta deposito.
	 * @see    String
	 * @throws DataAccessException
	 */
	String obtenerSecuencialCodigoBoletaDeposito() throws DataAccessException;
	
	/**
	 * Metodo que permite obtener el monto total que se deposito.
	 * @author Jorge Ponce.
	 * @param  codigoPlanViaje :codigo plan viaje.
	 * @return Monto total depositado.
	 * @see    PapeletaDepositoBean
	 * @throws DataAccessException
	 */
	BigDecimal obtenerMontoDepositado(String codigoPlanViaje) throws DataAccessException;
	
	/**
	 * Metodo que permite obtener el numero de registro archivo de la papeleta deposito.
	 * @author Jorge Ponce.
	 * @param codigoPapeletaDeposito :codigo papeleta deposito.
	 * @return Numero de registro archivo.
	 * @see String
	 * @throws DataAccessException
	 */
	String obtenerNumeroRegistroArchivo(String codigoPapeletaDeposito) throws DataAccessException;
	
	/**
	 * Metodo que permite registrar una papeleta deposito y asociarlo a un plan viaje.
	 * @author Jorge Ponce.
	 * @param  papeletaDeposito :objeto que tiene los datos para registrar.
	 * @return Codigo de boleta deposito.
	 * @see    String
	 * @throws Exception
	 */
	void insertarPapeletaDeposito(PapeletaDepositoBean papeletaDeposito) throws DataAccessException;
	
	/**
	 * Metodo que permite desasociar una papeleta deposito a un plan viaje.
	 * @author Jorge Ponce.
	 * @param  codigoPlanViaje :codigo plan viaje al cual se debe actualizar.
	 * @param  codigoBoletaDeposito :codigo boleta deposito.
	 * @param  codigoPlanViaje :codigo plan viaje.
	 * @return Secuencial del codigo de boleta deposito.
	 * @see    String
	 * @throws Exception
	 */
	void actualizarCodigoPlanViaje(String codigoPlanViajeAux, String codigoBoletaDeposito, String codigoPlanViaje) throws DataAccessException;
	
	/**
	 * Metodo que permite obtener papeleta de deposito.
	 * @author Samuel Dionisio.
	 * @param  papeletaDepositoBean : PapeletaDepositoBean.
	 * @return Papeleta deposito.
	 * @see    PapeletaDepositoBean
	 * @throws DataAccessException
	 */
	PapeletaDepositoBean obtenerPapeletaDeposito(String codigoBoletaDeposito) throws DataAccessException;
	
	/**
	 * Metodo que permite desasociar una papeleta deposito a un plan viaje.
	 * @author Jorge Ponce.
	 * @param  codigoPlanViaje :codigo plan viaje al cual se debe actualizar.
	 * @param  codigoBoletaDeposito :codigo boleta deposito.
	 * @param  codigoPlanViaje :codigo plan viaje.
	 * @return Secuencial del codigo de boleta deposito.
	 * @see    String
	 * @throws Exception
	 */
	void actualizarNumeroArchivo(PapeletaDepositoBean papeletaDepositoBean) throws DataAccessException;
	
	
	Integer countPapeletaDeposito(PapeletaDepositoBean papeletaDepositoBean) throws DataAccessException;
	
	void eliminarPapeletaDeposito(String codigoBoletaDeposito, String codigoPlanViaje) throws DataAccessException;
	
}
