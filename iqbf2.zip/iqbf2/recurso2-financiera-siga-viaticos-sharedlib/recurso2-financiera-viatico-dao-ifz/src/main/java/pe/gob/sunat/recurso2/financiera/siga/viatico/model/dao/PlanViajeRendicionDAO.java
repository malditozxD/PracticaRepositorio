package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PapeletaDepositoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeRendicionBean;

public interface PlanViajeRendicionDAO {

	/**
	 * Metodo que permite obtener el documento sustentatorio.
	 * @author Samuel Dionisio.
	 * @param  planViajeId : String.
	 * @param  secuencia : String.
	 * @return Listado de documento sustentatorio.
	 * @see    PlanViajeRendicionBean
	 * @throws DataAccessException
	 */
	List<PlanViajeRendicionBean> obtenerDocumentoSustentario(String planViajeId, String secuencia) throws DataAccessException;
	/**
	 * Metodo que permite obtener el listado de plan de viaje de Rendicion.
	 * @author Samuel Dionisio.
	 * @param  vacio : vacio.
	 * @return Listado de tipo de comprobante de pago.
	 * @see    PlanViajeRendicionBean
	 * @throws DataAccessException
	 */
	List<PlanViajeRendicionBean> obtenerListaPlanViajeRendicion(String planViajeId) throws DataAccessException;
	/**
	 * Metodo que permite obtener la secuencia maxima.
	 * @author Samuel Dionisio.
	 * @param  vacio : vacio.
	 * @return la secuencia maxima.
	 * @see    Integer
	 * @throws DataAccessException
	 */
	Integer secuencialMax (String planViajeId) throws DataAccessException;
	/**
	 * Metodo que permite registrar el plan de rendicion.
	 * @author Samuel Dionisio.
	 * @param  planViajeRendicion : PlanViajeRendicionBean.
	 * @return vacio.
	 * @see    void
	 * @throws DataAccessException
	 */
	void registrarPlanViajeRendicion(PlanViajeRendicionBean planViajeRendicion) throws DataAccessException;
	/**
	 * Metodo que permite modificar el plan de rendicion.
	 * @author Samuel Dionisio.
	 * @param  planViajeRendicion : PlanViajeRendicionBean.
	 * @return vacio.
	 * @see    void
	 * @throws DataAccessException
	 */
	void actualizarPlanViajeRendicion(PlanViajeRendicionBean planViajeRendicion) throws DataAccessException;
	
	/**
	 * Metodo que permite obtener todo el plan viaje.
	 * @author Samuel Dionisio.
	 * @param  planViajeRendicion : PlanViajeRendicionBean.
	 * @return lista PlanViajeRendicionBean.
	 * @see    void
	 * @throws DataAccessException
	 */
	List<PlanViajeRendicionBean> obtenerAllListaPlanViajeRendicion(PlanViajeRendicionBean planViajeRendicion) throws DataAccessException;
	
	/**
	 * Metodo que permite obtener el listado de plan viaje rendicion que se muestran en el registro de rendicion de la solicitud y reembolso.
	 * @author Jorge Ponce.
	 * @param  planViajeId :codigo plan viaje.
	 * @return Listado de plan viaje rendicion.
	 * @see    PlanViajeRendicionBean
	 * @throws DataAccessException
	 */
	ArrayList<PlanViajeRendicionBean> obtenerPlanViajeRendicionToRegistroRendicion(String planViajeId) throws DataAccessException;
	
	/**
	 * Metodo que permite eliminar plan viaje rendicion.
	 * @author Jorge Ponce.
	 * @param  planViajeRendicionBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	void eliminarPlanViajeRendicion(PlanViajeRendicionBean planViajeRendicionBean) throws DataAccessException;
	
	/**
	 * Metodo que permite obtener el monto total de comprobantes de gasto.
	 * @author Jorge Ponce.
	 * @param  planViajeId :codigo plan viaje.
	 * @return Monto total depositado.
	 * @see    PapeletaDepositoBean
	 * @throws DataAccessException
	 */
	BigDecimal obtenerMontoComprobanteGasto(String planViajeId) throws DataAccessException;
	
	/**
	 * Metodo que permite obtener las rendiciones en rango de fechas.
	 *
	 * @author Juan Farro.
	 * @param planViajeID codigo de plan de viaje
	 * @param fechaDesdeEvento fecha de inicio de evento
	 * @param fechaHastaEvento fecha de fin de evento
	 * @param fechaDesdeItinerario fecha de inicio de itinerario
	 * @param fechaHastaItinerario fecha de fin de itinerario
	 * @return Listado de rendiciones
	 * @throws DataAccessException
	 * @see    PlanViajeRendicionBean
	 */
	List<PlanViajeRendicionBean> listarRendicionesFechaDocumento( String planViajeID, Date fechaDesdeEvento, Date fechaHastaEvento, Date fechaDesdeItinerario, Date fechaHastaItinerario) throws DataAccessException;
	/**
	 * Metodo que permite obtener el listado de plan de viaje de Rendicion con distintos conceptos.
	 * @author Samuel Dionisio.
	 * @param  planViajeId : String.
	 * @return Listado de tipo de comprobante de pago.
	 * @see    PlanViajeRendicionBean
	 * @throws DataAccessException
	 */
	List<PlanViajeRendicionBean> obtenerListDistinctConceptoRendicion(String planViajeId) throws DataAccessException;
	
	Integer countPlanViajeRendicion(PlanViajeRendicionBean planViajeRendicionBean) throws DataAccessException; 
}