/*
 * 
 */
package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.NivelBean;

/**
 * Interfaz NivelDAO.
 * 
 * @author Juan Farro
 */
public interface NivelDAO {

	/**
	 * Buscar un nivel de viatico por su codigo.
	 * 
	 * @author Juan Farro
	 * @param codigoNivel codigo nivel
	 * @return nivel
	 * @throws DataAccessException
	 * @see NivelBean
	 */
	NivelBean buscarNivelViatico(String codigoNivel) throws DataAccessException;

}
