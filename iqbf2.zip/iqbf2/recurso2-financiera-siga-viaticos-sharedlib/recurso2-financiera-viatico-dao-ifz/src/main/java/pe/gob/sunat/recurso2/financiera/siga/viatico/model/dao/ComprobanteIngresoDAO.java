package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao;

import java.util.ArrayList;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ComprobanteIngresoBean;

/**
 * Interface ComprobanteIngresoDAO, contiene los metodos para la consulta y transaccion de la tabla COMPROBANTES_INGRESO.
 * @author Jorge Ponce.
 */
public interface ComprobanteIngresoDAO {
	
	/**
	 * Metodo que permite obtener el listado de recibos de ingreso caja (RICs) asociados a un plan viaje.
	 * @author Jorge Ponce.
	 * @param  numeroRendicion :numero de rendicion/codigo plan viaje.
	 * @return Listado de recibos de ingreso caja.
	 * @see    ComprobanteIngresoBean
	 * @throws DataAccessException
	 */
	ArrayList<ComprobanteIngresoBean> obtenerRecibosIngresoCaja(String numeroRendicion) throws DataAccessException;
	
}
