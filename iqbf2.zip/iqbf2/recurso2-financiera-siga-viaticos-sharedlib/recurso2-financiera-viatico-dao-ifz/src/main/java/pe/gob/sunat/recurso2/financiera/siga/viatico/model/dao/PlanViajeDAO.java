package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;

/**
 * Interfaz PlanViajeDAO.
 * 
 * @author Juan Saccatoma
 */
public interface PlanViajeDAO {

	/**
	 * Metodo que permite obtener la lista de solicitud de viaticos para la bandeja de rendiciones.
	 * 
	 * @author Juan Saccatoma
	 * @param parmSearch parametros de busqueda de la bandeja
	 * @return lista de solicitudes
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	List<PlanViajeBean> getRendicionesBandeja(Map<String, Object> parmSearch) throws DataAccessException;

	/**
	 * Metodo que permite obtener el detalle de viaticos para la bandeja de rendiciones.
	 * 
	 * @author Juan Saccatoma
	 * @param parmSearch parametros de busqueda de la bandeja
	 * @return lista de solicitudes
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	List<PlanViajeBean> getRendicionDetalle(Map<String, Object> parmSearch) throws DataAccessException;

	/**
	 * Metodo que permite obtener la lista de solicitud de viaticos para la opcion de exportar en la bandeja de rendiciones.
	 * 
	 * @author Juan Saccatoma
	 * @param parmSearch parametros de busqueda de la bandeja
	 * @return lista de solicitudes
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	List<PlanViajeBean> getRendicionesBandejaExportar(Map<String, Object> parmSearch) throws DataAccessException;

	/**
	 * Metodo que permite obtener una solicitud de viatico.
	 * 
	 * @author Juan Saccatoma
	 * @param parmSearch parametros de busqueda
	 * @return solicitud de viatico
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	PlanViajeBean getSolicitud(Map<String, Object> parmSearch) throws DataAccessException;

	/**
	 * Metodo que permite obtener solicitudes de viatico para la bandeja.
	 * 
	 * @author Juan Saccatoma
	 * @param parmSearch parametros de busqueda de la bandeja
	 * @return lista de solicitudes
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	List<PlanViajeBean> getSolicitudesBandeja(Map<String, Object> parmSearch) throws DataAccessException;

	/**
	 * Metodo que permite obtener solicitudes de viatico para la bandeja consulta, revision y alta (CUS10, CUS09 y CUS13).
	 * 
	 * @author Juan Saccatoma
	 * @param parmSearch parametros de busqueda de la bandeja
	 * @return lista de solicitudes
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	List<PlanViajeBean> getSolicitudesBandejaConsultaRevisionAlta(Map<String, Object> parmSearch);

	/**
	 * Metodo que permite obtener el detalle de una solicitud de viatico para la bandeja.
	 * 
	 * @author Juan Saccatoma
	 * @param parmSearch parametros de busqueda
	 * @return lista de solicitudes
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	List<PlanViajeBean> getSolicitudDetalle(Map<String, Object> parmSearch) throws DataAccessException;

	/**
	 * Metodo que permite obtener la lista de solicitud de viaticos para la opcion de exportar en la bandeja.
	 * 
	 * @author Juan Saccatoma
	 * @param parmSearch parametros de busqueda de la bandeja
	 * @return lista de solicitudes
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	List<PlanViajeBean> getSolicitudesBandejaExportar(Map<String, Object> parmSearch) throws DataAccessException;

	/**
	 * Metodo que permite anular una solicitud de viatico.
	 * 
	 * @author Juan Farro
	 * @param planViajeBean solicitud de viatico
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	void actualizaAnulacion(PlanViajeBean planViajeBean) throws DataAccessException;

	/**
	 * Metodo que permite observar una solicitud de viatico.
	 * 
	 * @author Juan Farro
	 * @param planViajeBean solicitud de viatico
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	void actualizaObservacion(PlanViajeBean planViajeBean) throws DataAccessException;

	/**
	 * Metodo que permite autorizar una solicitud de viatico.
	 * 
	 * @author Juan Farro
	 * @param planViajeBean solicitud de viatico
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	void actualizaAutorizacion(PlanViajeBean planViajeBean) throws DataAccessException;

	/**
	 * Metodo que permite obtener el listado de plan de viaje que se van a mostrar en la bandeja de autorizacion de solicitud.
	 * 
	 * @author Jorge Ponce.
	 * @param codigoDependencia :codigo de dependencia.
	 * @param codPlanilla :codigo de planilla.
	 * @param codTrabajador :codigo del colaborador.
	 * @param codEstadoSolic :codigo de estado de la solicitud.
	 * @param indicadorCanalAtencion :indicador canal de atencion.
	 * @param fechaDesde :fecha desde.
	 * @param fechaHasta :fecha hasta.
	 * @param codigoAutorizador :codigo del autorizador.
	 * @return Listado de plan de viaje.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	ArrayList<PlanViajeBean> obtenerPlanViajeToBandejaAutorizacionSolicitud(String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoSolic, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws DataAccessException;

	//JMCR-ME BANDEJA AUTORIZADOR se cambia el estado de la solicitud por una lista de estados  a enviar con "IN"
	ArrayList<PlanViajeBean> obtenerPlanViajeToBandejaAutorizacionSolicitudMultiplesEstados(String codigoDependencia, String codPlanilla, String codTrabajador, List <String> listCodEstadoSolic, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws DataAccessException;
	
	/**
	 * Metodo que permite obtener el listado de detalle de los plan de viaje que se muestran la bandeja de solicitud.
	 * 
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @param codigoDependencia :codigo de dependencia.
	 * @param codPlanilla :codigo de planilla.
	 * @param codTrabajador :codigo del colaborador.
	 * @param codEstadoSolic :codigo de estado de la solicitud.
	 * @param indicadorCanalAtencion :indicador canal de atencion.
	 * @param fechaDesde :fecha desde.
	 * @param fechaHasta :fecha hasta.
	 * @param codigoAutorizador :codigo del autorizador.
	 * @return Listado de plan de viaje.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	ArrayList<PlanViajeBean> obtenerPlanViajeDetalleToBandejaSolicitud(String codPlanViaje, String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoSolic, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws DataAccessException;

	//JMCR-ME BANDEJA AUTORIZADOR se cambia el estado de la solicitud por una lista de estados  a enviar con "IN"
	ArrayList<PlanViajeBean> obtenerPlanViajeDetalleToBandejaSolicitudMultiplesEstados(String codPlanViaje, String codigoDependencia, String codPlanilla, String codTrabajador, List<String> listCodEstadoSolic, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws DataAccessException;
	
	/**
	 * Metodo que permite obtener los datos de plan viaje para el envio de notificacion.
	 * 
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @return Objeto PlanViajeBean.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	PlanViajeBean obtenerPlanViajeToNotificacion(String codPlanViaje) throws DataAccessException;

	/**
	 * Metodo que permite autorizar una solicitud por un autorizador.
	 * 
	 * @author Jorge Ponce.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	void autorizarSolicitudByAutorizador(PlanViajeBean planViajeBean) throws DataAccessException;

	/**
	 * Metodo que permite observar una solicitud por un autorizador.
	 * 
	 * @author Jorge Ponce.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	void observarSolicitudByAutorizador(PlanViajeBean planViajeBean) throws DataAccessException;

	/**
	 * Metodo que permite anular una solicitud por un autorizador.
	 * 
	 * @author Jorge Ponce.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	void anularSolicitudByAutorizador(PlanViajeBean planViajeBean) throws DataAccessException;

	/**
	 * Metodo que permite obtener el listado de plan de viaje que se van a mostrar en la bandeja de consulta de rendicion.
	 * 
	 * @author Jorge Ponce.
	 * @param codigoDependencia :codigo de dependencia.
	 * @param codPlanilla :codigo de planilla.
	 * @param codTrabajador :codigo del colaborador.
	 * @param codEstadoSolic :codigo de estado de la solicitud.
	 * @param codEstadoRend :codigo de estado de la rendicion.
	 * @param indicadorCanalAtencion :indicador canal de atencion.
	 * @param fechaDesde :fecha desde.
	 * @param fechaHasta :fecha hasta.
	 * @return Listado de plan de viaje.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	ArrayList<PlanViajeBean> obtenerPlanViajeToBandejaConsultaRendicion(String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoSolic, String codEstadoRend, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta) throws DataAccessException;

	/**
	 * Metodo que permite obtener el listado de detalle de los plan de viaje que se muestran la bandeja de consulta de rendicion.
	 * 
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @param codigoDependencia :codigo de dependencia.
	 * @param codPlanilla :codigo de planilla.
	 * @param codTrabajador :codigo del colaborador.
	 * @param codEstadoSolic :codigo de estado de la solicitud.
	 * @param codEstadoRend :codigo de estado de la rendicion.
	 * @param indicadorCanalAtencion :indicador canal de atencion.
	 * @param fechaDesde :fecha desde.
	 * @param fechaHasta :fecha hasta.
	 * @return Listado de plan de viaje.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	ArrayList<PlanViajeBean> obtenerPlanViajeDetalleToBandejaConsultaRendicion(String codPlanViaje, String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoSolic, String codEstadoRend, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta) throws DataAccessException;
	
	/**
	 * Metodo que permite obtener los datos para realizar una rendicion del plan viaje.
	 * 
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @return Objeto PlanViajeBean.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	PlanViajeBean obtenerPlanViajeToRendicion(String codPlanViaje) throws DataAccessException;

	/**
	 * Metodo que permite obtener los numeros de expedientes del plan viaje.
	 * 
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @return Objeto PlanViajeBean.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	PlanViajeBean obtenerNumeroExpediente(String codPlanViaje) throws DataAccessException;

	/**
	 * Metodo que permite obtener el numero de registro archivo del plan viaje.
	 * 
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @return Numero de registro archivo.
	 * @see String
	 * @throws DataAccessException
	 */
	String obtenerNumeroRegistroArchivo(String codPlanViaje) throws DataAccessException;

	/**
	 * Metodo que permite obtener los monstos devueltos de una rendicion del plan viaje.
	 * 
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @return Objeto PlanViajeBean.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	PlanViajeBean obtenerMontoDevueltoToRegistroRendicion(String codPlanViaje) throws DataAccessException;

	/**
	 * Metodo que permite actualizar plan viaje cuando se registra la rendicion.
	 * 
	 * @author Jorge Ponce.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	void actualizarPlanViajeToRegistroRendicion(PlanViajeBean planViajeBean) throws DataAccessException;

	/**
	 * Metodo que permite actualizar plan viaje cuando se cierra la rendicion.
	 * 
	 * @author Jorge Ponce.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	void actualizarPlanViajeToCerrarRendicion(PlanViajeBean planViajeBean) throws DataAccessException;

	/**
	 * Metodo que permite actualizar el numero de expediente para el registro de rendicion.
	 * 
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @param expedienteRendicion :numero de expediente.
	 * @throws DataAccessException
	 */
	void actualizarNumeroExpedienteToRegistroRendicion(String codPlanViaje, String expedienteRendicion) throws DataAccessException;

	/**
	 * Metodo que permite anular el envio de una solicitud.
	 * 
	 * @author Jorge Ponce.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	void anularEnvioPlanViaje(PlanViajeBean planViajeBean) throws DataAccessException;

	/**
	 * Metodo que permite reprogramar la fecha de rendicion.
	 * 
	 * @author Jorge Ponce.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	void reprogramarFechaRendicion(PlanViajeBean planViajeBean) throws DataAccessException;

	/**
	 * Metodo que permite obtener el listado de plan de viaje que se van a mostrar en la bandeja de notificacion de rendicion.
	 * 
	 * @author Jorge Ponce.
	 * @param codigoDependencia :codigo de dependencia.
	 * @param indicadorCanalAtencion :indicador canal de atencion.
	 * @param fechaHasta :fecha hasta.
	 * @return Listado de plan de viaje.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	ArrayList<PlanViajeBean> obtenerPlanViajeToBandejaNotificacionRendicion(String codigoDependencia, String indicadorCanalAtencion, 
			Date fechaHasta, Integer diasHabilesSegundaNotificacion) throws DataAccessException;

	/**
	 * Metodo que permite enviar la segunda notificacion a una rendicion.
	 * 
	 * @author Jorge Ponce.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	void enviarSegundaNotificacionRendicion(PlanViajeBean planViajeBean) throws DataAccessException;

	/**
	 * Metodo que permite obtener los datos para realizar el sustento de gasto del plan viaje.
	 * 
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @return Objeto PlanViajeBean.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	PlanViajeBean obtenerPlanViajeToSustentoGastoReembolso(String codPlanViaje) throws DataAccessException;

	/**
	 * Metodo que permite actualizar plan viaje cuando se registra el sustento gasto de reembolso.
	 * 
	 * @author Jorge Ponce.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	void actualizarPlanViajeToSustentoGastoReembolso(PlanViajeBean planViajeBean) throws DataAccessException;

	/**
	 * Metodo que permite obtener el listado de plan de viaje que se van a mostrar en la bandeja de autorizacion de reembolso.
	 * 
	 * @author Jorge Ponce.
	 * @param codigoDependencia :codigo de dependencia.
	 * @param codPlanilla :codigo de planilla.
	 * @param codTrabajador :codigo del colaborador.
	 * @param codEstadoSolic :codigo de estado de la solicitud.
	 * @param fechaDesde :fecha desde.
	 * @param fechaHasta :fecha hasta.
	 * @param codigoAutorizador :codigo del autorizador.
	 * @return Listado de plan de viaje.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	ArrayList<PlanViajeBean> obtenerPlanViajeToBandejaAutorizacionReembolso(String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoSolic, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws DataAccessException;

	/**
	 * Metodo que permite autorizar un reembolso por un autorizador.
	 * 
	 * @author Jorge Ponce.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	void autorizarReembolsoByAutorizador(PlanViajeBean planViajeBean) throws DataAccessException;

	/**
	 * Metodo que permite observar un reembolso por un autorizador.
	 * 
	 * @author Jorge Ponce.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	void observarReembolsoByAutorizador(PlanViajeBean planViajeBean) throws DataAccessException;

	/**
	 * Metodo que permite anular un reembolso por un autorizador.
	 * 
	 * @author Jorge Ponce.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	void anularReembolsoByAutorizador(PlanViajeBean planViajeBean) throws DataAccessException;

	/**
	 * Metodo que permite obtener el listado de detalle de los plan de viaje que se muestran la bandeja de reembolso.
	 * 
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @param codigoDependencia :codigo de dependencia.
	 * @param codPlanilla :codigo de planilla.
	 * @param codTrabajador :codigo del colaborador.
	 * @param codEstadoSolic :codigo de estado de la solicitud.
	 * @param fechaDesde :fecha desde.
	 * @param fechaHasta :fecha hasta.
	 * @param codigoAutorizador :codigo del autorizador.
	 * @return Listado de plan de viaje.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	ArrayList<PlanViajeBean> obtenerPlanViajeDetalleToBandejaReembolso(String codPlanViaje, String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoSolic, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws DataAccessException;

	/**
	 * Metodo que permite obtener los datos de plan de viaje para el seguimiento.
	 * 
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @return Plan de viaje.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	PlanViajeBean obtenerPlanViajeToSeguimiento(String codPlanViaje) throws DataAccessException;

	/**
	 * Metodo que permite registrar plan de viaje.
	 * 
	 * @author Juan Farro
	 * @param planViajeBean solicitud de viatico
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	void registrarPlanViaje(PlanViajeBean planViajeBean) throws DataAccessException;

	/**
	 * Metodo que permite actualizar plan de viaje.
	 * 
	 * @author Juan Farro
	 * @param planViajeBean solicitud de viatico
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	void actualizarPlanViaje(PlanViajeBean planViajeBean) throws DataAccessException;

	/**
	 * Metodo que permite actualizar plan de viaje (para la modificacion de solicitud de viatico).
	 * 
	 * @author Juan Farro
	 * @param planViajeBean solicitud de viatico
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	void actualizarPlanViajeToModificar(PlanViajeBean planViajeBean) throws DataAccessException;

	/**
	 * Metodo que permite actualizar plan de viaje (para la modificacion de solicitud de viatico).
	 * 
	 * @author Juan Farro
	 * @param planViajeBean solicitud de viatico/reembolso
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	void actualizarPlanViajeToModificarReembolso(PlanViajeBean planViajeBean) throws DataAccessException;

	/**
	 * Metodo que permite calcular el siguiente dia habil a partir de una fecha y un numero de dias que se suma a esta.
	 * 
	 * @author Juan Farro
	 * @param fecha fecha inicial
	 * @param dias numero de dias a sumar a la fecha inicial
	 * @return siguiente dia habil despues de realizar la suma de dias a la fecha inicial
	 * @throws DataAccessException
	 */
	Date fechaDiasHabiles(Date fecha, int dias) throws DataAccessException;

	/**
	 * Metodo que permite buscar los datos de un plan de viaje a partir de su identificador.
	 * 
	 * @author Juan Farro
	 * @param codPlanViaje codigo de solicitud de viatico
	 * @return solicitud de viatico
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	PlanViajeBean buscarPlanViaje(String codPlanViaje) throws DataAccessException;

	/**
	 * Metodo que permite generar la secuencia para el identificador de un plan de viaje.
	 * 
	 * @author Juan Farro
	 * @param sede sede
	 * @param anio anio
	 * @return secuencia generada
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	String getSecuenciaPlanViajeID(String sede, String anio) throws DataAccessException;

	/**
	 * Metodo que permite generar la secuencia para el codigo de planilla de un plan de viaje.
	 * 
	 * @author Juan Farro
	 * @param anio anio
	 * @param uuoo UUOO
	 * @param tipoViaticoReembolso tipo viatico (V) o reembolso (R)
	 * @return secuencia generada
	 * @throws DataAccessException
	 */
	String getSecuenciaCodPlanillaViaje(String anio, String uuoo, String tipoViaticoReembolso) throws DataAccessException;

	/**
	 * Metodo que permite buscar los datos de un plan de viaje a partir de su codigo de planilla.
	 * 
	 * @author Juan Farro
	 * @param codPlanilla codigo de planilla
	 * @return solicitud de viatico
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	PlanViajeBean buscarPlanViajePlanilla(String codPlanilla) throws DataAccessException;

	/**
	 * Metodo que permite buscar solicitudes de viaticos para un colaborador que se traslapen con las fechas especificadas en los parametros.
	 * 
	 * @author Juan Farro
	 * @param codColaborador codigo de colaborador
	 * @param fechaSalida fecha inicio para busqueda de traslape de fechas
	 * @param fechaRetorno fecha fin para la busqueda de traslape de fechas
	 * @return lista de solicitudes que tienen fechas traslapadas
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	List<PlanViajeBean> buscarTraslapeFechas(String codColaborador, Date fechaSalida, Date fechaRetorno) throws DataAccessException;

	/**
	 * Metodo que permite buscar solicitudes de viaticos (diferente a la especificado en el parametro) para un colaborador que se traslapen con las fechas especificadas.
	 * 
	 * @author Juan Farro
	 * @param codColaborador codigo de colaborador
	 * @param fechaSalida fecha de inicio para la busqueda de traslape de fechas
	 * @param fechaRetorno fecha fin para la busqueda de traslape de fechas
	 * @param codPlanViaje codigo de plan de viaje a excluir en la busqueda
	 * @return lista de solicitudes que tienen fechas traslapadas
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	List<PlanViajeBean> buscarTraslapeFechas(String codColaborador, Date fechaSalida, Date fechaRetorno, String codPlanViaje) throws DataAccessException;

	/**
	 * Metodo que permite determinar si existe en BD un codigo de planilla.
	 * 
	 * @author Juan Farro
	 * @param codPlanilla codigo de planilla
	 * @return true si codigo de planilla existe en BD
	 * @throws DataAccessException
	 */
	boolean existePlanilla(String codPlanilla) throws DataAccessException;

	/**
	 * Buscar codigo empleado del autorizador de gasto
	 * 
	 * @author Juan Farro
	 * @param codColaborador codigo del colaborador
	 * @return codigo empleado del autorizador de gasto
	 * @throws DataAccessException
	 */
	String obtenerCodigoEmpleadoAutorizador(String codColaborador) throws DataAccessException;

	/**
	 * Buscar datos adicionales colaborador.
	 * 
	 * @author Samuel Dionisio
	 * @param planViajeId : codigo plan viaje
	 * @return plan viaje
	 * @throws DataAccessException
	 */
	public PlanViajeBean obtenerPlanViajeToSolicitud(String planViajeId) throws DataAccessException;

	/**
	 * Busca plan viaje para el reporte de reembolso
	 * 
	 * @author Juan Farro
	 * @param planViajeId : codigo plan viaje
	 * @return plan viaje
	 * @throws DataAccessException
	 */
	public PlanViajeBean obtenerPlanViajeToReembolso(String planViajeId) throws DataAccessException;

	/**
	 * Metodo que permite buscar las planillas de viatico asociadas a un colaborador para reembolso.
	 * 
	 * @author Juan Farro
	 * @param codColaborador codigo del colaborador
	 * @param tipoDestino tipo destino (nacional, internacional)
	 * @param indicadorHoras indicador de horas (mayor a 4 horas, menor o igual a 4 horas)
	 * @return lista de planillas asociadas para reembolso
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	public List<PlanViajeBean> obtenerPlanillasAsociadasParaReembolso(String codColaborador, String tipoDestino, String indicadorHoras) throws DataAccessException;
	
	/**
	 * Metodo que permite obtener solicitudes de reembolsos para la bandeja consulta, revision
	 * 
	 * @author Juan Saccatoma
	 * @param parmSearch parametros de busqueda de la bandeja
	 * @return lista de solicitudes
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	public List<PlanViajeBean> getReembolsosBandejaConsultaRevision(Map<String, Object> parmSearch)throws DataAccessException;
		
	/**
	 * Metodo que permite buscar las planillas de viatico pendientes
	 * 
	 * @author Yoney Ayala
	 * @return lista de planillas pendientes
	 * @throws DataAccessException
	 */
	public List<PlanViajeBean> obtenerListaEstadosSolicitudPendienteViatico() throws DataAccessException;
	
	/**
	 * Metodo que permite buscar las planillas de viatico asociadas vencidos dos dias
	 * 
	 * @author Yoney Ayala
	 * @return lista de planillas pendientes vencidos dos dias
	 * @throws DataAccessException
	 */
	public List<PlanViajeBean> obtenerListaViaticoDiasAdicional() throws DataAccessException;

	/**
	 * Metodo que permite buscar las planillas de viatico asociadas vencidos trienta dias
	 * 
	 * @author Yoney Ayala
	 * @return lista de planillas pendientes vencidos a trienta dias
	 * @throws DataAccessException
	 */
	public List<PlanViajeBean> obtenerListaViaticoPlazoExcedido() throws DataAccessException;

	/**
	 * Metodo que permite buscar las planillas de viatico asociadas vencidos trienta dias y vencidos dos dias
	 * 
	 * @author Yoney Ayala
	 * @return lista de planillas pendientes vencidos a trienta dias y dos dias vencidos
	 * @throws DataAccessException
	 */
	public List<PlanViajeBean> obtenerListaViaticoPlazoExcedidoGlobal()throws DataAccessException;
	
	/**
	 * Metodo que permite obtener el CCP - CAS.
	 *
	 * @author Juan Farro
	 * @param tipoReq tipo de requerimiento
	 * @param codigoReq codigo de req
	 * @return codigo CCP
	 * @throws DataAccessException
	 */
	public String obtenerCodigoCCP(String tipoReq, String codigoReq) throws DataAccessException;	

	/**
	 * Metodo que permite actualizar plan viaje aquellas planillas vencidos
	 * 
	 * @author Yoney Ayala.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */	
	void actualizarPlanViajeToCerrarAnulacion(PlanViajeBean planViajeBean) throws DataAccessException;

	/**
	 * Metodo que permite actualizar Fecha de Primera Notificacion
	 * 
	 * @author emarchena.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	public void actualizarPlanViajeToFechaNotificacion(PlanViajeBean planViajeBean) throws DataAccessException ;
	
	
	/**
	 * Metodo que permite actualizar plan viaje aquellas planillas vencidos
	 * 
	 * @author Yoney Ayala.
	 * @param planViajeBean :objeto que tiene los parametros a actualizar
	 * @throws DataAccessException
	 */	
	public List<PlanViajeBean> obtenerListaViaticoConcecutivo(PlanViajeBean planViajeBean)throws DataAccessException;
	
	public Map<String,String> obtenerUUOOAutorizadora(String codDependencia, String codEmpleado, String indProceso)throws DataAccessException;
	
	public Map<String,String> reevaluarUUOOsAutorizadoras(String codEmpleado)throws DataAccessException;
	
	void derivarSolicitudByAutorizador(PlanViajeBean planViajeBean) throws DataAccessException;

	public String obtenerExistenciaPlanillasConsecutivas(String codiEmplPer,
			Date fecInicio, Date fecFin, String origen)
			throws DataAccessException;
	
	public Map<String, String> validarRevisionPreviaOSA(String idPlanilla) throws DataAccessException;
	
	void autorizarSolicitudByAutorizadorSoloFirma(PlanViajeBean planViajeBean) throws DataAccessException;

}



