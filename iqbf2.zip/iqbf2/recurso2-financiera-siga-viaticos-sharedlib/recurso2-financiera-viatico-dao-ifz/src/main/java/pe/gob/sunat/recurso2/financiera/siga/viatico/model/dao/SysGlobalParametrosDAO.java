package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.SysGlobalParametrosBean;


/**
 * Interfaz SysGlobalParametrosDAO.
 * 
 * @author Samuel Dionisio
 */
public interface SysGlobalParametrosDAO {
	/**
	 * Metodo que permite obtener el IGV actual.
	 * 
	 * @author Samuel Dionisio
	 * @see SysGlobalParametrosBean
	 * @return obtiene el IGV actual.
	 * @throws DataAccessException
	 */
	SysGlobalParametrosBean obtenerIgv() throws DataAccessException;
}
