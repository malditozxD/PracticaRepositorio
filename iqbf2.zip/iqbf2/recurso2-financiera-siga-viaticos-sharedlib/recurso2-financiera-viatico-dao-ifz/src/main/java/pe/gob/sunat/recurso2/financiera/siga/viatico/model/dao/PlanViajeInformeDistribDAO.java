package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeInformeDistribBean;

public interface PlanViajeInformeDistribDAO {

	
	/**
	 * Metodo que permite obtener el documento sustentatorio.
	 * @author Samuel Dionisio.
	 * @param  planViajeId : String.
	 * @param  secuencial : String.
	 * @return Listado de plan viaje de informe distribucion.
	 * @see    PlanViajeInformeDistribBean
	 * @throws DataAccessException
	 */
	List<PlanViajeInformeDistribBean> obtenerListaPlanViajeInformeDistrib(String planViajeId, String secuencial) throws DataAccessException; 
	
	
	/**
	 * Metodo que permite obtener el documento sustentatorio por concepto.
	 * @author Samuel Dionisio.
	 * @param  planViajeId : String.
	 * @param  secuencial : String.
	 * @return Listado de plan viaje de informe distribucion.
	 * @see    PlanViajeInformeDistribBean
	 * @throws DataAccessException
	 */
	List<PlanViajeInformeDistribBean> obtenerListaPlanViajeInformeDistribToConcepto(String planViajeId, String codConceptoOri) throws DataAccessException; 
	
	/**
	 * Metodo que permite el registro de un nuevo plan viaje de informe distribucion.
	 * @author Samuel Dionisio.
	 * @param  planViajeInformeDistrib : PlanViajeInformeDistribBean.
	 * @return vacio
	 * @see    void
	 * @throws DataAccessException
	 */
	void registrarPlanViajeInformeDistrib(PlanViajeInformeDistribBean planViajeInformeDistrib)	throws DataAccessException;
	/**
	 * Metodo que permite modifica el plan viaje de informe distribucion.
	 * @author Samuel Dionisio.
	 * @param  planViajeInformeDistrib : PlanViajeInformeDistribBean.
	 * @return vacio
	 * @see    void
	 * @throws DataAccessException
	 */
	void actualizarPlanViajeInformeDistrib(PlanViajeInformeDistribBean planViajeInformeDistrib)	throws DataAccessException;
	
	/**
	 * Metodo que permite eliminar el plan viaje de informe distribucion.
	 * @author Samuel Dionisio.
	 * @param  planViajeInformeDistrib : PlanViajeInformeDistribBean.
	 * @return vacio
	 * @see    void
	 * @throws DataAccessException
	 */
	void eliminarPlanViajeInformeDistrib(PlanViajeInformeDistribBean planViajeInformeDistrib)	throws DataAccessException;
	
	/**
	 * Metodo que permite obtener el listado de asignacion/gasto viatico.
	 * @author Jorge Ponce.
	 * @param  planViajeId :codigo plan viaje.
	 * @param  secuencial :secuencial del comprobante de pago.
	 * @return Listado de asignacion de viatico.
	 * @see    PlanViajeInformeDistribBean
	 * @throws DataAccessException
	 */
	ArrayList<PlanViajeInformeDistribBean> obtenerAsignacionGastoViatico(String planViajeId, Integer secuencial) throws DataAccessException;
	
	/**
	 * Metodo que permite obtener el listado de pasaje y tasa embarque.
	 * @author Jorge Ponce.
	 * @param  planViajeId :codigo plan viaje.
	 * @param  secuencial :secuencial del comprobante de pago.
	 * @return Listado de pasaje y tasa embarque.
	 * @see    PlanViajeInformeDistribBean
	 * @throws DataAccessException
	 */
	ArrayList<PlanViajeInformeDistribBean> obtenerPasajeTasaEmbarque(String planViajeId, Integer secuencial) throws DataAccessException;
	
	/**
	 * Metodo que permite obtener el listado de monto rendido diario.
	 * @author Jorge Ponce.
	 * @param  planViajeId :codigo plan viaje.
	 * @return Listado de monto rendido diario.
	 * @see    PlanViajeInformeDistribBean
	 * @throws DataAccessException
	 */
	ArrayList<PlanViajeInformeDistribBean> obtenerMontoRendidoDiario(String planViajeId) throws DataAccessException;
	
		/**
	 * Metodo que permite obtener el detalle de gasto.
	 * @author Samuel Dionisio.
	 * @param  planViajeId : codigo plan viaje.
	 * @return Listado de detalle de gasto.
	 * @see    PlanViajeInformeDistribBean
	 * @throws DataAccessException
	 */
	ArrayList<PlanViajeInformeDistribBean> obtenerDetalleGastoReporte(String planViajeId, String tipoDocumento) throws DataAccessException;

	/**
	 * Metodo que permite obtener la suma del monto rendido por fecha.
	 * @author Samuel Dionisio.
	 * @param  planViajeId : codigo plan viaje.
	 * @param  codConceptoGastoOrigen : codigo concepto gasto origen.
	 * @return Listado de la suma del monto rendido por fecha.
	 * @see    PlanViajeInformeDistribBean
	 * @throws DataAccessException
	 */
	ArrayList<PlanViajeInformeDistribBean> obtenerSumaMontoRendido(String planViajeId, String codConceptoGastoOrigen) throws DataAccessException;
}
