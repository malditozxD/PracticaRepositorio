package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ConceptoPlanillaViaticosBean;

/**
 * Interfaz ConceptoPlanillaViaticosDAO.
 * 
 * @author Juan Saccatoma
 */
public interface ConceptoPlanillaViaticosDAO {

	/**
	 * Metodo que permite obtener concepto planilla viaticos para comprobante.
	 * 
	 * @author Jorge Ponce
	 * @see ConceptoPlanillaViaticosBean
	 * @param idPlanViaje codigo de solicitud
	 * @return lista de conceptos
	 * @throws DataAccessException
	 */
	public ArrayList<ConceptoPlanillaViaticosBean> obtenerConceptoPlanillaViaticosToComprobante(String idPlanViaje) throws DataAccessException;

	/**
	 * Metodo que permite obtener conceptos viatico.
	 * 
	 * @author Juan Saccatoma
	 * @see ConceptoPlanillaViaticosBean
	 * @param codigo codigo del concepto de viatico
	 * @param descripcion descripcion del concepto de viatico
	 * @return lista de conceptos
	 * @throws DataAccessException
	 */
	public List<ConceptoPlanillaViaticosBean> obtenerConceptosViatico(String codigo, String descripcion) throws DataAccessException;

	/**
	 * Metodo que permite obtener conceptos viatico a partir de su codigo y descripcion
	 * 
	 * @author Juan Farro
	 * @see ConceptoPlanillaViaticosBean
	 * @param params parametros de busqueda
	 * @return lista de conceptos
	 * @throws DataAccessException
	 */
	public List<ConceptoPlanillaViaticosBean> obtenerConceptosViatico(Map<String, Object> params) throws DataAccessException;

	/**
	 * Metodo que permite obtener el importe diario.
	 * 
	 * @author Juan Farro
	 * @see ConceptoPlanillaViaticosBean
	 * @param params parametros de busqueda
	 * @return lista de conceptos
	 * @throws DataAccessException
	 */
	public List<ConceptoPlanillaViaticosBean> obtenerImporteDiario(Map<String, Object> params) throws DataAccessException;

	/**
	 * Metodo que permite obtener un concepto de viatico por su codigo
	 * 
	 * @author Juan Farro
	 * @param codigo codigo del concepto de viatico
	 * @return concepto de viatico
	 * @throws DataAccessException
	 * @see ConceptoPlanillaViaticosBean
	 */
	public ConceptoPlanillaViaticosBean obtenerConceptoViatico(String codigo) throws DataAccessException;

	/**
	 * Metodo que permite obtener un concepto de viatico por su indicador de itinerario
	 * 
	 * @author Samuel Dionisio
	 * @param codigo codigo del concepto de viatico
	 * @return concepto de viatico
	 * @throws DataAccessException
	 * @see ConceptoPlanillaViaticosBean
	 */
	public ConceptoPlanillaViaticosBean obtenerConceptoViaticoIndItinerario(String indItinerario,String tipoDestino) throws DataAccessException;
}
