package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.VacacionBean;

/**
 * Interfaz VacacionDAO.
 * 
 * @author Juan Farro
 */
public interface VacacionDAO {

	/**
	 * Metodo que permite obtener las vacaciones de un colaborador en un rango de fechas.
	 * 
	 * @author Juan Farro
	 * @see VacacionBean
	 * @param params parametros de busqueda
	 * @return lista de vacaciones
	 * @throws DataAccessException 
	 * 
	 */
	List<VacacionBean> listarVacaciones(Map<String, Object> params) throws DataAccessException;

}
