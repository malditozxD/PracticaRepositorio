package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao;

import org.springframework.dao.DataAccessException;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.CabeceraMovBean;

/**
 * Interfaz CabeceraMovDAO.
 * 
 * @author Samuel Dionisio
 */
public interface CabeceraMovDAO {
	/**
	 * Metodo que permite obtener el expediente siaf y nota de compromiso.
	 * 
	 * @author Samuel Dionisio
	 * @see CabeceraMovBean
	 * @param numeroRegistroCab : String
	 * @return expediente siaf y nota de compromiso
	 * @throws DataAccessException
	 */
	CabeceraMovBean obtenerCabeceraMov(String numeroRegistroCab);
}
