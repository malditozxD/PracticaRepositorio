package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.TXXX8LugarUbigeoBean;

/**
 * Interfaz TXXX8LugarUbigeoDAO.
 * 
 * @author Juan Saccatoma
 */
public interface TXXX8LugarUbigeoDAO {

	/**
	 * Metodo que permite obtener lugares a partir de los codigo de departamento y provincia.
	 * 
	 * @author Juan Saccatoma
	 * @see TXXX8LugarUbigeoBean
	 * @param codigoDepartamento codigo de departamento
	 * @param codigoProvincia codigo de provincia
	 * @return lista de lugares
	 * @throws DataAccessException
	 */
	List<TXXX8LugarUbigeoBean> obtenerLugaresByCodigo(String codigoDepartamento, String codigoProvincia) throws DataAccessException;

	/**
	 * Metodo que permite obtener lugares a partir de las descripciones de departamento, provincia y lugar.
	 * 
	 * @author Juan Farro
	 * @see TXXX8LugarUbigeoBean
	 * @param descripcionDepartamento descripcion departamento
	 * @param descripcionProvincia descripcion provincia
	 * @param descripcionLugar descripcion lugar
	 * @return lista de lugares
	 * @throws DataAccessException
	 */
	List<TXXX8LugarUbigeoBean> obtenerLugaresByDescripcion(String descripcionDepartamento, String descripcionProvincia, String descripcionLugar) throws DataAccessException;

	/**
	 * Metodo que permite obtener rutas lugares.
	 * 
	 * @author Juan Farro
	 * @see TXXX8LugarUbigeoBean
	 * @param params parametros de busqueda
	 * @return lista de lugares
	 * @throws DataAccessException
	 */
	List<TXXX8LugarUbigeoBean> obtenerRutasLugares(Map<String, Object> params) throws DataAccessException;

	/**
	 * Metodo que permite obtener un lugar nacional a partir de su codigo.
	 * 
	 * @author Juan Farro
	 * @see TXXX8LugarUbigeoBean
	 * @param codigoLugar codigo de lugar
	 * @return lugar
	 * @throws DataAccessException
	 */
	TXXX8LugarUbigeoBean obtenerLugarNacional(String codigoLugar) throws DataAccessException;

	/**
	 * Metodo que permite obtener un lugar internacional a partir de su codigo.
	 * 
	 * @author Juan Farro
	 * @see TXXX8LugarUbigeoBean
	 * @param codigoLugar codigo de lugar
	 * @return lugar
	 * @throws DataAccessException
	 */
	TXXX8LugarUbigeoBean obtenerLugarInternacional(String codigoLugar) throws DataAccessException;
}
