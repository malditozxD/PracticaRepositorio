package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao;

import org.springframework.dao.DataAccessException;

/**
 * Clase que permite realizar operaciones sobre la tabla REGISTRADOR_MOVILIDAD
 * 
 * @author Juan Saccatoma
 */
public interface RegistradorViaticoDAO {

	/**
	 * Metodo que determinar si un colaborador es registrador
	 * 
	 * @author Juan Saccatoma
	 * @param codEmp codigo de empleado
	 * @return numero de uuoo en las que puede registrar
	 * @throws DataAccessException
	 */
	Long determinaRegistrador(String codEmp) throws DataAccessException;

	/**
	 * Metodo que determinar si un colaborador es registrador universal
	 * 
	 * @author Juan Saccatoma
	 * @param codEmp codigo de empleado
	 * @return numero de uuoo en la que es registrador universal
	 * @throws DataAccessException
	 */
	Long determinaRegistradorUniversal(String codEmp) throws DataAccessException;

}
