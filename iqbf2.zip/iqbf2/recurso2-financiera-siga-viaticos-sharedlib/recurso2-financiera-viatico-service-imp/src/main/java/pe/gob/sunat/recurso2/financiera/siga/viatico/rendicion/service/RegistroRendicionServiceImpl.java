package pe.gob.sunat.recurso2.financiera.siga.viatico.rendicion.service;

import java.math.BigDecimal;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.recurso2.administracion.siga.archivo.service.RegistroArchivosService;
import pe.gob.sunat.recurso2.administracion.siga.expediente.util.ExpedienteConstantes;
import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.T01ParametroBean;
import pe.gob.sunat.recurso2.administracion.siga.util.FechaUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.NumeroUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PapeletaDepositoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PapeletaDepositoDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dto.ViaticoValidate;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoConsultaService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoExpedienteService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoGeneralService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoRegistroService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.RendicionConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ResourceBundleUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;

/**
 * Implementacion de la interface RegistroRendicionService, contiene los metodos para el registro de rendicion.
 * @author Jorge Ponce.
 */
public class RegistroRendicionServiceImpl implements RegistroRendicionService { 
	
	protected final Log log = LogFactory.getLog(getClass());
	private ViaticoGeneralService viaticoGeneralService;
	private ViaticoConsultaService viaticoConsultaService;
	private ViaticoRegistroService viaticoRegistroService;
	private ViaticoExpedienteService viaticoExpedienteService;
	private RegistroArchivosService registroArchivosService;
	private PlanViajeDAO planViajeDAO;
	private PapeletaDepositoDAO papeletaDepositoDAO;
	
	public ViaticoGeneralService getViaticoGeneralService() {
		return viaticoGeneralService;
	}

	public void setViaticoGeneralService(ViaticoGeneralService viaticoGeneralService) {
		this.viaticoGeneralService = viaticoGeneralService;
	}

	public ViaticoConsultaService getViaticoConsultaService() {
		return viaticoConsultaService;
	}

	public void setViaticoConsultaService(ViaticoConsultaService viaticoConsultaService) {
		this.viaticoConsultaService = viaticoConsultaService;
	}

	public ViaticoRegistroService getViaticoRegistroService() {
		return viaticoRegistroService;
	}

	public void setViaticoRegistroService(ViaticoRegistroService viaticoRegistroService) {
		this.viaticoRegistroService = viaticoRegistroService;
	}

	public ViaticoExpedienteService getViaticoExpedienteService() {
		return viaticoExpedienteService;
	}

	public void setViaticoExpedienteService(ViaticoExpedienteService viaticoExpedienteService) {
		this.viaticoExpedienteService = viaticoExpedienteService;
	}

	public RegistroArchivosService getRegistroArchivosService() {
		return registroArchivosService;
	}

	public void setRegistroArchivosService(RegistroArchivosService registroArchivosService) {
		this.registroArchivosService = registroArchivosService;
	}

	public PlanViajeDAO getPlanViajeDAO() {
		return planViajeDAO;
	}

	public void setPlanViajeDAO(PlanViajeDAO planViajeDAO) {
		this.planViajeDAO = planViajeDAO;
	}

	public PapeletaDepositoDAO getPapeletaDepositoDAO() {
		return papeletaDepositoDAO;
	}

	public void setPapeletaDepositoDAO(PapeletaDepositoDAO papeletaDepositoDAO) {
		this.papeletaDepositoDAO = papeletaDepositoDAO;
	}

	/**
	 * Metodo que permite registrar la rendicion.
	 * @author Jorge Ponce.
	 * @param  planViajeBean :objeto que tiene los datos para registrar.
	 * @param  codigoRegistrador :codigo del registrador.
	 * @param  codigoSedeRegistrador :codigo sede del registrador.
	 * @return Codigo de operacion: Exito(00), Error(02).
	 * @see    String
	 * @throws ServiceException, Exception
	 */
	public String registrarRendicion(PlanViajeBean planViajeBean, String codigoRegistrador, String codigoSedeRegistrador) throws ServiceException, Exception {
		
		String codigoOperacion = RendicionConstantes.ERROR_OPERACION;
		boolean flagRendicionCorrecta = true;
		String errorMessage = RendicionConstantes.CADENA_VACIA;
		if (flagRendicionCorrecta && RendicionConstantes.UNO.equals(planViajeBean.getFlagDeclaracion())) {
			if (planViajeBean.getNumeroDeclaracionViatico() > 1) {
				flagRendicionCorrecta = false;
				errorMessage = ResourceBundleUtil.getMessageRendicion(RendicionConstantes.MENSAJE_DDJJ_VIATICO_UNICA);
			}
			else {
				BigDecimal porcentaje = BigDecimal.ZERO;
				if (RendicionConstantes.TIPO_DESTINO_NACIONAL.equals(planViajeBean.getTipoDestino())) {
					if (RendicionConstantes.UNO.equals(planViajeBean.getFlagMenorIgual4Horas())) {
						T01ParametroBean parametroPorcentaje = viaticoGeneralService.obtenerParametroViatico(ViaticoConstantes.CODIGO_PARAMETRO_PORCENTAJE_DDJJ, ViaticoConstantes.CODIGO_ARGUMENTO_NACIONAL_MENOR_4);
						porcentaje = new BigDecimal(parametroPorcentaje.getDesc_abrv());
					}
					else {
						T01ParametroBean parametroPorcentaje = viaticoGeneralService.obtenerParametroViatico(ViaticoConstantes.CODIGO_PARAMETRO_PORCENTAJE_DDJJ, ViaticoConstantes.CODIGO_ARGUMENTO_NACIONAL_MAYOR_4);
						porcentaje = new BigDecimal(parametroPorcentaje.getDesc_abrv());
					}
				}
				else {
					if (RendicionConstantes.INDICADOR_EXT_DDJJ_SI.equals(planViajeBean.getIndicadorExteriorDDJJ())) {
						T01ParametroBean parametroPorcentaje = viaticoGeneralService.obtenerParametroViatico(ViaticoConstantes.CODIGO_PARAMETRO_CONFIGURACION_GN, ViaticoConstantes.CODIGO_ARGUMENTO_DDJJ_SIT_EMERGENCIA);
						porcentaje = new BigDecimal(parametroPorcentaje.getDesc_abrv());
					}
					else {
						T01ParametroBean parametroPorcentaje = viaticoGeneralService.obtenerParametroViatico(ViaticoConstantes.CODIGO_PARAMETRO_PORCENTAJE_DDJJ, ViaticoConstantes.CODIGO_ARGUMENTO_INTERNACIONAL);
						porcentaje = new BigDecimal(parametroPorcentaje.getDesc_abrv());
					}
				}
				
				int resultado = planViajeBean.getMontoDeclaracionViatico().compareTo(porcentaje.multiply(planViajeBean.getMontoAsignacionViatico()));
				if (resultado == 1) {
					flagRendicionCorrecta = false;
					errorMessage = ResourceBundleUtil.getMessageRendicion(RendicionConstantes.MENSAJE_DDJJ_SUPERA_PORCENTAJE, NumeroUtil.formatearNumeros(0, porcentaje.multiply(new BigDecimal(100))));
				}
			}
		}
		
		if (flagRendicionCorrecta) {
			//validar solo para el tipo de concepto 01, asignación nacional.
			ViaticoValidate viaticoValidate = viaticoConsultaService.validarMontoRendidoDiario(planViajeBean.getCodPlanViaje(), planViajeBean.getTipoDestino(), planViajeBean.getFlagMenorIgual4Horas(), planViajeBean.getMoneda());
			flagRendicionCorrecta = viaticoValidate.isFlagValidacion();
			if (!flagRendicionCorrecta) {
				errorMessage = viaticoValidate.getErrorMessage();
			}
		}
		
		if (flagRendicionCorrecta) {
			planViajeBean.setCodEstadoRend(RendicionConstantes.ESTADO_RENDICION_PENDIENTE);
			planViajeDAO.actualizarPlanViajeToRegistroRendicion(planViajeBean);
			codigoOperacion = RendicionConstantes.EXITO_OPERACION;
			String codPlanViaje = planViajeBean.getCodPlanViaje();
			PlanViajeBean planViajeAuxBean = planViajeDAO.obtenerNumeroExpediente(codPlanViaje);
			String expedienteRendicion = planViajeAuxBean.getExpedienteRendicion();
			if (expedienteRendicion == null || (RendicionConstantes.CADENA_VACIA.equals(expedienteRendicion))) {
				/*Seguimiento*/
				expedienteRendicion = viaticoExpedienteService.crearExpediente(ExpedienteConstantes.CODIGO_PROCESO_VIATICO_RENDICION, codPlanViaje, codigoRegistrador, codigoSedeRegistrador);
				String observacion = ViaticoConstantes.EXPEDIENTE_REGISTRO_RENDICION_MENSAJE;
				viaticoExpedienteService.crearAccion(ExpedienteConstantes.CODIGO_PROCESO_VIATICO_RENDICION, expedienteRendicion, ExpedienteConstantes.ESTADO_ACCION_001_CONFORME, ExpedienteConstantes.ACCION_VIATICO_RENDICION_REGISTRADA, codigoRegistrador, observacion, codigoSedeRegistrador);
				planViajeDAO.actualizarNumeroExpedienteToRegistroRendicion(codPlanViaje, expedienteRendicion);
			}
		}
		else {
			throw new ServiceException(this, errorMessage);
		}
		return codigoOperacion;
	}
	
	/**
	 * Metodo que permite cerrar la rendicion.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @param  flagHabilitarCerrarRendicion :flag habilitar cerrar rendicion.
	 * @param  flagCVRHabilitarCerrarRendicion :flag cvr habilitar cerrar rendicion.
	 * @param  flagRegistroComprobante :flag registro de comprobante.
	 * @param  flagRegistroVoucher :flag registro de voucher.
	 * @param  flagRegistroRIC :flag registro de RIC.
	 * @param  montoDevueltoComprobanteTotal :monto total devuelto por comprobante.
	 * @param  montoDevueltoVoucherRICTotal :monto total devuelto por voucher y ric.
	 * @param  codigoRegistrador :codigo del registrador.
	 * @param  codigoSedeRegistrador :codigo sede del registrador.
	 * @param  procesoViatico :proceso viatico - manual 01 - automatico 02.
	 * @return Codigo de operacion: Exito(00), Error(02).
	 * @see    String
	 * @throws ServiceException, Exception
	 */
	public String cerrarRendicion(String codPlanViaje, String flagHabilitarCerrarRendicion, String flagCVRHabilitarCerrarRendicion, String flagRegistroComprobante, 
			String flagRegistroVoucher, String flagRegistroRIC, BigDecimal montoDevueltoComprobanteTotal, BigDecimal montoDevueltoVoucherRICTotal, String codigoRegistrador, 
			String codigoSedeRegistrador, String procesoViatico, String codDerivacionRendicion, String codOsa) throws ServiceException, Exception {
		
		String codigoOperacion = RendicionConstantes.ERROR_OPERACION;
		boolean flagRendicionCorrecta = true;
		String errorMessage = RendicionConstantes.CADENA_VACIA;
		
		if (RendicionConstantes.PROCESO_MANUAL.equals(procesoViatico)) {
			String numeroRegistroArchivo = planViajeDAO.obtenerNumeroRegistroArchivo(codPlanViaje);
			if (!RendicionConstantes.CADENA_VACIA.equals(numeroRegistroArchivo)) {
				boolean flagArchivoRegistrado = registroArchivosService.validarArchivoRegistrado(ViaticoConstantes.APLICACION_SERVICIOS, ViaticoConstantes.MODULO_VIATICOS, ViaticoConstantes.TIPO_ARCHIVO_AUTORIZACION_COMISION, numeroRegistroArchivo);
				if (!flagArchivoRegistrado) {
					flagRendicionCorrecta = false;
					errorMessage = ResourceBundleUtil.getMessageRendicion(RendicionConstantes.MENSAJE_ADJUNTAR_DOCUMENTO);
				}
			}
			else {
				flagRendicionCorrecta = false;
				errorMessage = ResourceBundleUtil.getMessageRendicion(RendicionConstantes.MENSAJE_ADJUNTAR_DOCUMENTO);
			}
		}
		
		if (flagRendicionCorrecta && (RendicionConstantes.CERO.equals(flagHabilitarCerrarRendicion) || RendicionConstantes.CERO.equals(flagCVRHabilitarCerrarRendicion))) {
			flagRendicionCorrecta = false;
			errorMessage = ResourceBundleUtil.getMessageRendicion(RendicionConstantes.MENSAJE_RENDICION_INCOMPLETA);
		}
		
		if (flagRendicionCorrecta && RendicionConstantes.CERO.equals(flagRegistroComprobante) && RendicionConstantes.CERO.equals(flagRegistroVoucher) && RendicionConstantes.CERO.equals(flagRegistroRIC)) {
			flagRendicionCorrecta = false;
			errorMessage = ResourceBundleUtil.getMessageRendicion(RendicionConstantes.MENSAJE_REGISTRAR_DOCUMENTOS);
		}
		
		if (flagRendicionCorrecta) {
			PlanViajeBean planViajeBean = planViajeDAO.obtenerMontoDevueltoToRegistroRendicion(codPlanViaje);
			BigDecimal montoDevueltoComprobanteRegistrado = BigDecimal.ZERO;
			BigDecimal montoDevueltoVoucherRICRegistrado = BigDecimal.ZERO;
			int resultado;
			
			if (planViajeBean.getMontoDevuelto() != null) {
				montoDevueltoComprobanteRegistrado = montoDevueltoComprobanteRegistrado.add(new BigDecimal(NumeroUtil.formatearMonedaMontoToDecimal(null, 2, planViajeBean.getMontoDevuelto())));
			}
			if (planViajeBean.getMontoDevol() != null) {
				montoDevueltoVoucherRICRegistrado = montoDevueltoVoucherRICRegistrado.add(new BigDecimal(NumeroUtil.formatearMonedaMontoToDecimal(null, 2, planViajeBean.getMontoDevol())));
			}
			
			resultado = montoDevueltoComprobanteRegistrado.compareTo(montoDevueltoComprobanteTotal);
			if (resultado != 0) {
				flagRendicionCorrecta = false;
				errorMessage = ResourceBundleUtil.getMessageRendicion(RendicionConstantes.MENSAJE_MONTO_DIFERENTE);
			}
			else {
				resultado = montoDevueltoVoucherRICRegistrado.compareTo(montoDevueltoVoucherRICTotal);
				if (resultado != 0) {
					flagRendicionCorrecta = false;
					errorMessage = ResourceBundleUtil.getMessageRendicion(RendicionConstantes.MENSAJE_MONTO_DIFERENTE);
				}
			}
		}
		
		if (flagRendicionCorrecta) {
			
			PlanViajeBean planViajeTmp = planViajeDAO.obtenerPlanViajeToRendicion(codPlanViaje);
			
			PlanViajeBean planViajeBean = new PlanViajeBean();
			planViajeBean.setCodPlanViaje(codPlanViaje);
			planViajeBean.setFechaRendicion(FechaUtil.parseStringDateToDate(FechaUtil.obtenerFechaActual(), RendicionConstantes.DATE_FORMAT_DDMMYYYY));
			if(ViaticoConstantes.CANAL_ATENCION_CAJACHICA.equals(planViajeTmp.getIndicadorCanalAtencion())){
				planViajeBean.setCodEstadoRend(RendicionConstantes.ESTADO_RENDICION_ENVIADO_CAJACHICA);	
			}else{
				
				/*if(RendicionConstantes.ESTADO_RENDICION_ENVIADO_OSA.equals(codDerivacionRendicion)){
					planViajeBean.setCodEstadoRend(RendicionConstantes.ESTADO_RENDICION_ENVIADO_OSA);
					planViajeBean.setCodOsa(codOsa);
				}else{
					planViajeBean.setCodEstadoRend(RendicionConstantes.ESTADO_RENDICION_ENVIADO_FINANCIERA);	
				}*/
				
				planViajeBean.setCodEstadoRend(codDerivacionRendicion);//el estado devuelto por el store procedure.
				if(!StringUtils.isBlank(codOsa)){
					planViajeBean.setCodOsa(codOsa);
				}
			}
			
			log.info("Codigo de derivación:"+codDerivacionRendicion+", codOsa:"+codOsa+", codigo de estado:"+planViajeBean.getCodEstadoRend());
			planViajeDAO.actualizarPlanViajeToCerrarRendicion(planViajeBean);
			
			/*Seguimiento*/
			PlanViajeBean planViajeAuxBean = planViajeDAO.obtenerNumeroExpediente(codPlanViaje);
			String expedienteRendicion = planViajeAuxBean.getExpedienteRendicion();
			String observacion = ViaticoConstantes.EXPEDIENTE_CIERRE_RENDICION_MENSAJE;
			viaticoExpedienteService.crearAccion(ExpedienteConstantes.CODIGO_PROCESO_VIATICO_RENDICION, expedienteRendicion, ExpedienteConstantes.ESTADO_ACCION_001_CONFORME, ExpedienteConstantes.ACCION_VIATICO_RENDICION_CERRADA, codigoRegistrador, observacion, codigoSedeRegistrador);
			codigoOperacion = RendicionConstantes.EXITO_OPERACION;
		}
		else {
			throw new ServiceException(this, errorMessage);
		}
		return codigoOperacion;
	}
	
	/**
	 * Metodo que permite registrar una papeleta deposito y asociarlo a un plan viaje.
	 * @author Jorge Ponce.
	 * @param  papeletaDeposito :objeto que tiene los datos para registrar.
	 * @param  tipoDestino :tipo destino.
	 * @return Codigo de boleta deposito.
	 * @see    String
	 * @throws Exception
	 */
	public String registrarPapeletaDeposito(PapeletaDepositoBean papeletaDeposito, String tipoDestino) throws Exception {
		
		String codigoPlanViaje = papeletaDeposito.getCodigoPlanViaje();
		BigDecimal montoDepositado =  papeletaDepositoDAO.obtenerMontoDepositado(codigoPlanViaje);
		/*Registramos papeleta deposito*/
		String codigoBoletaDeposito = obtenerSecuencialCodigoBoletaDeposito();
		papeletaDeposito.setCodigoBoletaDeposito(codigoBoletaDeposito);
		papeletaDeposito.setFlagBoletaDeposito(RendicionConstantes.FLAG_BOLETA_DEPOSITO_VIATICOS);
		papeletaDepositoDAO.insertarPapeletaDeposito(papeletaDeposito);
		/*Actualizando el monto devuelto por voucher*/
		montoDepositado = montoDepositado.add(papeletaDeposito.getMontoDeposito());
		viaticoRegistroService.actualizarMontoDevueltoVoucher(codigoPlanViaje, montoDepositado);
		/*
		ArrayList<PlanViajeConceptoBean> planViajeConceptoList = distribuirMontoDepositado(codigoPlanViaje, montoDepositado);
		if (planViajeConceptoList != null && !planViajeConceptoList.isEmpty()) {
			for (PlanViajeConceptoBean planViajeConceptoBean : planViajeConceptoList) {
				planViajeConceptoDAO.actualizarMontoDevueltoVoucher(planViajeConceptoBean);
			}
		}
		*/
		/*Actualizando el monto devuelto por voucher*/
		/*
		BigDecimal montoDevuelto = BigDecimal.ZERO;
		String planViajeID = papeletaDeposito.getCodigoPlanViaje();
		String conceptoID = RendicionConstantes.CODIGO_ASIGNACION_VIATICO_NACIONAL;
		if (RendicionConstantes.TIPO_DESTINO_INTERNACIONAL.equals(tipoDestino)) {
			conceptoID = RendicionConstantes.CODIGO_ASIGNACION_VIATICO_INTERNACIONAL;
		}
		PlanViajeConceptoBean planViajeConceptoAuxBean = planViajeConceptoDAO.obtenerPlanViajeConceptoMonto(planViajeID, conceptoID);
		if (planViajeConceptoAuxBean != null && planViajeConceptoAuxBean.getMontoDevuelto() != null) {
			montoDevuelto = new BigDecimal(planViajeConceptoAuxBean.getMontoDevuelto());
		}
		montoDevuelto = montoDevuelto.add(papeletaDeposito.getMontoDeposito());
		String montoDevueltoFormateado = NumeroUtil.formatearMonedaMontoToDecimal(null, 2, montoDevuelto);
		PlanViajeConceptoBean planViajeConceptoBean = new PlanViajeConceptoBean();
		planViajeConceptoBean.setPlanViajeID(planViajeID);
		planViajeConceptoBean.setConceptoID(conceptoID);
		planViajeConceptoBean.setMontoDevuelto(new Double(montoDevueltoFormateado));
		planViajeConceptoDAO.actualizarMontoDevueltoVoucher(planViajeConceptoBean);
		*/
		return codigoBoletaDeposito;
	}
	
	/**
	 * Metodo que permite obtener el secuencial (codigoBoletaDeposito) para la papeleta deposito a registrar.
	 * @author Jorge Ponce.
	 * @return Secuencial del codigo de boleta deposito.
	 * @see    String
	 * @throws Exception
	 */
	private String obtenerSecuencialCodigoBoletaDeposito() throws Exception {
		return papeletaDepositoDAO.obtenerSecuencialCodigoBoletaDeposito();
	}
	
	/**
	 * Metodo que permite desasociar una papeleta deposito a un plan viaje.
	 * @author Jorge Ponce.
	 * @param  codigoBoletaDeposito :codigo boleta deposito.
	 * @param  codigoPlanViaje :codigo plan viaje.
	 * @param  montoDeposito :monto del deposito.
	 * @param  tipoDestino :tipo destino.
	 * @return Codigo de operacion: Exito(00), Error(02).
	 * @see    String
	 * @throws Exception
	 */
	public String desasociarPapeletaDeposito(String codigoBoletaDeposito, String codigoPlanViaje, BigDecimal montoDeposito, String tipoDestino) throws Exception {
		
		String codigoOperacion = RendicionConstantes.ERROR_OPERACION;
		BigDecimal montoDepositado =  papeletaDepositoDAO.obtenerMontoDepositado(codigoPlanViaje);
		/*Desasociamos papeleta deposito*/
		//papeletaDepositoDAO.actualizarCodigoPlanViaje(RendicionConstantes.CADENA_VACIA, codigoBoletaDeposito, codigoPlanViaje);
		papeletaDepositoDAO.eliminarPapeletaDeposito(codigoBoletaDeposito, codigoPlanViaje);
		/*Actualizando el monto devuelto por voucher*/
		montoDepositado = montoDepositado.subtract(montoDeposito);
		viaticoRegistroService.actualizarMontoDevueltoVoucher(codigoPlanViaje, montoDepositado);
		/*
		ArrayList<PlanViajeConceptoBean> planViajeConceptoList = distribuirMontoDepositado(codigoPlanViaje, montoDepositado);
		if (planViajeConceptoList != null && !planViajeConceptoList.isEmpty()) {
			for (PlanViajeConceptoBean planViajeConceptoBean : planViajeConceptoList) {
				planViajeConceptoDAO.actualizarMontoDevueltoVoucher(planViajeConceptoBean);
			}
		}
		*/
		/*Actualizando el monto devuelto por voucher*/
		/*
		BigDecimal montoDevuelto = BigDecimal.ZERO;
		String conceptoID = RendicionConstantes.CODIGO_ASIGNACION_VIATICO_NACIONAL;
		if (RendicionConstantes.TIPO_DESTINO_INTERNACIONAL.equals(tipoDestino)) {
			conceptoID = RendicionConstantes.CODIGO_ASIGNACION_VIATICO_INTERNACIONAL;
		}
		PlanViajeConceptoBean planViajeConceptoAuxBean = planViajeConceptoDAO.obtenerPlanViajeConceptoMonto(codigoPlanViaje, conceptoID);
		if (planViajeConceptoAuxBean != null && planViajeConceptoAuxBean.getMontoDevuelto() != null) {
			montoDevuelto = new BigDecimal(planViajeConceptoAuxBean.getMontoDevuelto());
		}
		montoDevuelto = montoDevuelto.subtract(montoDeposito);
		String montoDevueltoFormateado = NumeroUtil.formatearMonedaMontoToDecimal(null, 2, montoDevuelto);
		PlanViajeConceptoBean planViajeConceptoBean = new PlanViajeConceptoBean();
		planViajeConceptoBean.setPlanViajeID(codigoPlanViaje);
		planViajeConceptoBean.setConceptoID(conceptoID);
		planViajeConceptoBean.setMontoDevuelto(new Double(montoDevueltoFormateado));
		planViajeConceptoDAO.actualizarMontoDevueltoVoucher(planViajeConceptoBean);
		*/
		codigoOperacion = RendicionConstantes.EXITO_OPERACION;
		return codigoOperacion;
	}

	/**
	 * Metodo que permite actualizar el numero archivo de la papeleta deposito.
	 * @author Samuel Dionisio.
	 * @param  papeletaDeposito : PapeletaDepositoBean.
	 * @return Codigo de boleta deposito.
	 * @see    String
	 * @throws Exception
	 */
	@Override
	public String actualizarNumeroArchivoPapeletaDeposito(PapeletaDepositoBean papeletaDeposito) throws Exception {
		String codigoOperacion = RendicionConstantes.ERROR_OPERACION;
		papeletaDepositoDAO.actualizarNumeroArchivo(papeletaDeposito);
		codigoOperacion = RendicionConstantes.EXITO_OPERACION;
		return codigoOperacion;
	}

	@Override
	public PlanViajeBean obtenerPlanViajeToRendicion(String codPlanViaje) {
		return planViajeDAO.obtenerPlanViajeToRendicion(codPlanViaje);
	}

	@Override
	public boolean operacionExiste(PapeletaDepositoBean papeletaDeposito) {
		// TODO Auto-generated method stub
		Integer result = papeletaDepositoDAO.countPapeletaDeposito(papeletaDeposito);
		if(result.intValue()==0)return false;
		return true;
	}
	
}
