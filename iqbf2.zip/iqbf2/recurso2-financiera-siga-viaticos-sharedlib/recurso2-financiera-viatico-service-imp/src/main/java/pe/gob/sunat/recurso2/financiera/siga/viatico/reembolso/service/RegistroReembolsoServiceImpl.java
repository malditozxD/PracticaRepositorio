package pe.gob.sunat.recurso2.financiera.siga.viatico.reembolso.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.recurso2.administracion.siga.expediente.util.ExpedienteConstantes;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.administracion.siga.util.NumeroUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeConceptoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeDestinoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.NivelDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeConceptoDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeDestinoDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeRendicionDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.TipoCambioDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dto.ViaticoValidate;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoConsultaService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoExpedienteService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoGeneralService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoMensajeriaService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ReembolsoConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ResourceBundleUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.SolicitudConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;

/**
 * Clase RegistroReembolsoServiceImpl.
 * 
 * @author Juan Farro
 */
public class RegistroReembolsoServiceImpl implements RegistroReembolsoService {

	/** Declaracion del log para realizar los debug, info, error, etc. */
	protected final Log log = LogFactory.getLog(getClass());

	/** Declaracion del DAO planViajeDAO. */
	private PlanViajeDAO planViajeDAO;
	
	/** Declaracion del DAO PlanViajeRendicionDAO. */
	private PlanViajeRendicionDAO planViajeRendicionDAO;

	/** Declaracion del DAO planViajeDestinoDAO. */
	private PlanViajeDestinoDAO planViajeDestinoDAO;

	/** Declaracion del DAO planViajeConceptoDAO. */
	private PlanViajeConceptoDAO planViajeConceptoDAO;

	/** Declaracion del DAO tipoCambioDAO. */
	private TipoCambioDAO tipoCambioDAO;

	/** Declaracion del DAO nivelDAO. */
	private NivelDAO nivelDAO;

	/** Declaracion del servicio registroPersonalService. */
	private RegistroPersonalService registroPersonalService;

	/** Declaracion del servicio viaticoExpedienteService. */
	private ViaticoExpedienteService viaticoExpedienteService;

	/** Declaracion del servicio viaticoMensajeriaService. */
	private ViaticoMensajeriaService viaticoMensajeriaService;

	/** Declaracion del servicio viaticoGeneralService. */
	private ViaticoGeneralService viaticoGeneralService;
	
	/** Declaracion del servicio viaticoConsultaService. */
	private ViaticoConsultaService viaticoConsultaService;
	
	/** Declaracion del servicio consultaReembolsoService. */
	private ConsultaReembolsoService consultaReembolsoService;
	
	public PlanViajeDAO getPlanViajeDAO() {
		return planViajeDAO;
	}

	public void setPlanViajeDAO(PlanViajeDAO planViajeDAO) {
		this.planViajeDAO = planViajeDAO;
	}

	public PlanViajeRendicionDAO getPlanViajeRendicionDAO() {
		return planViajeRendicionDAO;
	}

	public void setPlanViajeRendicionDAO(PlanViajeRendicionDAO planViajeRendicionDAO) {
		this.planViajeRendicionDAO = planViajeRendicionDAO;
	}

	public PlanViajeDestinoDAO getPlanViajeDestinoDAO() {
		return planViajeDestinoDAO;
	}

	public void setPlanViajeDestinoDAO(PlanViajeDestinoDAO planViajeDestinoDAO) {
		this.planViajeDestinoDAO = planViajeDestinoDAO;
	}

	public PlanViajeConceptoDAO getPlanViajeConceptoDAO() {
		return planViajeConceptoDAO;
	}

	public void setPlanViajeConceptoDAO(PlanViajeConceptoDAO planViajeConceptoDAO) {
		this.planViajeConceptoDAO = planViajeConceptoDAO;
	}

	public TipoCambioDAO getTipoCambioDAO() {
		return tipoCambioDAO;
	}

	public void setTipoCambioDAO(TipoCambioDAO tipoCambioDAO) {
		this.tipoCambioDAO = tipoCambioDAO;
	}

	public NivelDAO getNivelDAO() {
		return nivelDAO;
	}

	public void setNivelDAO(NivelDAO nivelDAO) {
		this.nivelDAO = nivelDAO;
	}

	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}

	public ViaticoExpedienteService getViaticoExpedienteService() {
		return viaticoExpedienteService;
	}

	public void setViaticoExpedienteService(ViaticoExpedienteService viaticoExpedienteService) {
		this.viaticoExpedienteService = viaticoExpedienteService;
	}

	public ViaticoMensajeriaService getViaticoMensajeriaService() {
		return viaticoMensajeriaService;
	}

	public void setViaticoMensajeriaService(ViaticoMensajeriaService viaticoMensajeriaService) {
		this.viaticoMensajeriaService = viaticoMensajeriaService;
	}

	public ViaticoGeneralService getViaticoGeneralService() {
		return viaticoGeneralService;
	}

	public void setViaticoGeneralService(ViaticoGeneralService viaticoGeneralService) {
		this.viaticoGeneralService = viaticoGeneralService;
	}

	public ViaticoConsultaService getViaticoConsultaService() {
		return viaticoConsultaService;
	}

	public void setViaticoConsultaService(ViaticoConsultaService viaticoConsultaService) {
		this.viaticoConsultaService = viaticoConsultaService;
	}

	public ConsultaReembolsoService getConsultaReembolsoService() {
		return consultaReembolsoService;
	}

	public void setConsultaReembolsoService(ConsultaReembolsoService consultaReembolsoService) {
		this.consultaReembolsoService = consultaReembolsoService;
	}

	/**
	 * Metodo que permite registrar una solicitud viatico/reembolso.
	 * 
	 * @author Juan Farro
	 * @param anioActual anio actual
	 * @param uuoo uuoo
	 * @param planViajeBean solicitud de viatico/reembolso
	 * @param planViajeDestinos plan viaje destinos
	 * @param planViajeConceptos plan viaje conceptos
	 * @throws Exception
	 */
	@Override
	public void registrarSolicitudReembolso(String anioActual, String uuoo, PlanViajeBean planViajeBean, List<PlanViajeDestinoBean> planViajeDestinos, List<PlanViajeConceptoBean> planViajeConceptos) throws Exception {

		if (StringUtils.isBlank(anioActual)) throw new IllegalArgumentException("anio no puede estar vacio");
		if (StringUtils.isBlank(uuoo)) throw new IllegalArgumentException("uuoo no puede estar vacia");
		if (StringUtils.isBlank(planViajeBean.getSedePlanViaje())) throw new IllegalArgumentException("sede no puede estar vacia");

		// generar el secuencial PLAN_VIAJE_ID (primary key)
		planViajeBean.setCodPlanViaje(planViajeDAO.getSecuenciaPlanViajeID(planViajeBean.getSedePlanViaje(), anioActual));

		// generar el secuencial COD_PLANILLA_VIAJE ANIO VIGENTE + UUOO + "R" + CORRELATIVO 4 CARACTERES
		planViajeBean.setCodPlanilla(planViajeDAO.getSecuenciaCodPlanillaViaje(anioActual, uuoo, "R"));

		// registrar plan de viaje
		planViajeDAO.registrarPlanViaje(planViajeBean);

		if (CollectionUtils.isNotEmpty(planViajeDestinos)) {

			int secuencial = 1;
			for (PlanViajeDestinoBean destino : planViajeDestinos) {

				destino.setPlanViajeID(planViajeBean.getCodPlanViaje());
				destino.setSecuencial(secuencial++);

				// registrar destinos de plan de viaje
				planViajeDestinoDAO.registrarPlanViajeDestino(destino);
			}

		}
		
		if (CollectionUtils.isNotEmpty(planViajeConceptos)) {

			for (PlanViajeConceptoBean concepto : planViajeConceptos) {

				concepto.setPlanViajeID(planViajeBean.getCodPlanViaje());

				// registrar conceptos de plan de viaje
				planViajeConceptoDAO.registrarPlanViajeConcepto(concepto);
			}

		}		

		// codigo del colaborador y registrador
		String codigoColaborador = planViajeBean.getCodTrabajador();
		String codigoRegistrador = planViajeBean.getCodigoRegistrador();

		// buscar la sede del registrador
		String sedeRegistrador = StringUtils.EMPTY;
		if (StringUtils.isNotBlank(planViajeBean.getCodigoRegistrador())) {
			MaestroPersonalBean registrador = registroPersonalService.obtenerPersonaxCodigo(planViajeBean.getCodigoRegistrador());
			if (registrador != null) {
				sedeRegistrador = registrador.getCodigoSede();
			}
		}

		// crear expediente
		String numeroExpediente = viaticoExpedienteService.crearExpediente(ExpedienteConstantes.CODIGO_PROCESO_VIATICO_REEMBOLSO, planViajeBean.getCodPlanilla(), codigoColaborador, sedeRegistrador);

		// actualizar el numero de expediente
		if (StringUtils.isNotBlank(numeroExpediente)) {

			// preferible se crea un nuevo bean que solo actualice el campo que falta
			PlanViajeBean planViajeUpdate = new PlanViajeBean();

			planViajeUpdate.setCodPlanViaje(planViajeBean.getCodPlanViaje());
			planViajeUpdate.setExpedientePlanViaje(StringUtils.trimToNull(numeroExpediente));

			planViajeDAO.actualizarPlanViaje(planViajeUpdate);

		} else {
			log.debug("no se pudo generar numero de expediente");
		}

		// crear accion (proceso: 417, accion: 001, estado: 001)
		String codigoProceso = ExpedienteConstantes.CODIGO_PROCESO_VIATICO_REEMBOLSO;
		String codigoAccion = ExpedienteConstantes.ACCION_VIATICO_REEMB_GENERAR_SOLICITUD;
		String codigoEstado = ExpedienteConstantes.ACCION_VIATICO_REEMB_GENERAR_SOLICITUD_ESTADO_GENERADO;

		viaticoExpedienteService.crearAccion(codigoProceso, numeroExpediente, codigoAccion, codigoEstado, codigoRegistrador, ViaticoConstantes.EXPEDIENTE_REEMBOLSO_SOLICITUD_MENSAJE, sedeRegistrador);
		
		
		// crear accion (proceso: 417, accion: 003, estado: 001) -> si hay traslape
		if (StringUtils.equals(planViajeBean.getIndicadorTraslape(), ViaticoConstantes.INDICADOR_TRASLAPE_SI)) {

			codigoProceso = ExpedienteConstantes.CODIGO_PROCESO_VIATICO_REEMBOLSO;
			codigoAccion = ExpedienteConstantes.ACCION_VIATICO_REEMB_OTORGAR_ALTA;
			codigoEstado = ExpedienteConstantes.ACCION_VIATICO_REEMB_OTORGAR_ALTA_ESTADO_EN_ESPERA;

			viaticoExpedienteService.crearAccion(codigoProceso, numeroExpediente, codigoAccion, codigoEstado, codigoRegistrador, ViaticoConstantes.EXPEDIENTE_TRASLAPE_SOLICITUD_MENSAJE, sedeRegistrador);
		}		
	}

	/**
	 * Metodo que permite modificar una solicitud viatico/reembolso.
	 * 
	 * @author Juan Farro
	 * @param planViajeBean solicitud de viatico/reembolso
	 * @param planViajeDestinos plan viaje destinos
	 * @param planViajeConceptos plan viaje conceptos
	 * @throws Exception
	 */
	@Override
	public void actualizarSolicitudReembolso(PlanViajeBean planViajeBean, List<PlanViajeDestinoBean> planViajeDestinos, List<PlanViajeConceptoBean> planViajeConceptos) throws Exception {

		if (planViajeBean == null) throw new IllegalArgumentException("objeto plan de viaje no puede ser null");
		if (StringUtils.isBlank(planViajeBean.getCodPlanViaje())) throw new IllegalArgumentException("codigo de plan de viaje no puede estar vacio");

		// NOTA: el actualizarPlanViajeToModificar no modificar el ESTADO_PLAN_VIAJE (por el tema del boton imprimir que cambia de estado)

		// actualizar campos de plan de viaje
		planViajeDAO.actualizarPlanViajeToModificarReembolso(planViajeBean);

		// eliminar todos los plan de viaje destino asociados al viatico
		planViajeDestinoDAO.eliminarPlanViajeDestinos(planViajeBean.getCodPlanViaje());

		if (CollectionUtils.isNotEmpty(planViajeDestinos)) {

			int secuencial = 1;
			for (PlanViajeDestinoBean destino : planViajeDestinos) {

				destino.setPlanViajeID(planViajeBean.getCodPlanViaje());
				destino.setSecuencial(secuencial++);

				planViajeDestinoDAO.registrarPlanViajeDestino(destino);
			}

		}
		
		// eliminar todos los plan de viaje concepto asociados al viatico
		planViajeConceptoDAO.eliminarPlanViajeConceptos(planViajeBean.getCodPlanViaje());		
		
		if (CollectionUtils.isNotEmpty(planViajeConceptos)) {

			for (PlanViajeConceptoBean concepto : planViajeConceptos) {

				concepto.setPlanViajeID(planViajeBean.getCodPlanViaje());

				// registrar conceptos de plan de viaje
				planViajeConceptoDAO.registrarPlanViajeConcepto(concepto);
			}

		}		
	}

	/**
	 * Metodo que permite enviar una solicitud viatico/reembolso.
	 *
	 * @author Juan Farro
	 * @param codPlanViaje codigo de plan de viaje a enviar
	 * @param codigoEnviador codigo de empleado que realiza el envio
	 * @param tipoConfiguracion tipo de configuracion
	 * @return true, si tiene exito
	 * @throws Exception
	 */
	@Override
	public boolean enviarSolicitudReembolso(String codPlanViaje, String codigoEnviador, String tipoConfiguracion) throws Exception {

		// buscar plan de viaje
		if (StringUtils.isBlank(codPlanViaje)) throw new IllegalArgumentException("codPlanViaje no puede estar vacio");

		// trae todos los datos de plan de viaje
		PlanViajeBean planViaje = planViajeDAO.buscarPlanViaje(codPlanViaje);

		if (planViaje == null) throw new IllegalArgumentException("codPlanViaje no existe");

		// creacion del bean de modificacion
		PlanViajeBean planViajeUpdate = new PlanViajeBean();

		// seteando primary key del update
		planViajeUpdate.setCodPlanViaje(planViaje.getCodPlanViaje());

		boolean envioValido = false;
		boolean esNacional = StringUtils.equals(planViaje.getTipoDestino(), ViaticoConstantes.TIPO_COMISION_NACIONAL);
		boolean esConfiguracionManual = StringUtils.equals(tipoConfiguracion, ViaticoConstantes.TIPO_CONFIGURACION_MANUAL);

		if (esConfiguracionManual) {

			// setear estado a autorizado
			planViajeUpdate.setEstadoPlanViaje(ViaticoConstantes.ESTADO_VIATICO_AUTORIZADO);

			if ( esNacional ) {
				
				// si es nacional valida el CCP
				String codigoCCP = planViajeDAO.obtenerCodigoCCP(ViaticoConstantes.CCP_SISTEMA_VIATICOS, planViaje.getCodPlanViaje());

				codigoCCP = StringUtils.trimToEmpty(codigoCCP);
				
				// CCP VALIDO
				envioValido = StringUtils.equals(codigoCCP, ViaticoConstantes.CCP_SISTEMA_VIATICOS_OK);
				
			} else {
				
				// en internacional no se valida el CCP
				envioValido = true;
			}
			
			if (envioValido) {
				
				// actualizar plan de viaje
				planViajeDAO.actualizarPlanViaje(planViajeUpdate);
			}

		} else {

			// setear estado a por autorizar
			planViajeUpdate.setEstadoPlanViaje(ViaticoConstantes.ESTADO_REEMBOLSO_POR_AUTORIZAR);

			// actualizar plan de viaje
			planViajeDAO.actualizarPlanViaje(planViajeUpdate);

			// obtener datos del enviador (para crear la accion)
			MaestroPersonalBean enviador = registroPersonalService.obtenerPersonaxCodigo(codigoEnviador);

			// crear accion (proceso: 417, accion: 001, estado: 004)
			String codigoProceso = ExpedienteConstantes.CODIGO_PROCESO_VIATICO_REEMBOLSO;
			String codigoAccion = ExpedienteConstantes.ACCION_VIATICO_REEMB_GENERAR_SOLICITUD;
			String codigoEstado = ExpedienteConstantes.ACCION_VIATICO_REEMB_GENERAR_SOLICITUD_ESTADO_EN_LEVANTAMIENTO_OBSERVACION;

			if (StringUtils.isBlank(planViaje.getExpedientePlanViaje())) throw new Exception("Solicitud no tiene expediente");

			viaticoExpedienteService.crearAccion(codigoProceso, planViaje.getExpedientePlanViaje(), codigoAccion, codigoEstado, codigoEnviador, ViaticoConstantes.EXPEDIENTE_ENVIO_SOLICITUD_MENSAJE, StringUtils.trimToNull(enviador.getCodigoSede()));

			envioValido = true;
		}

		return envioValido;
	}
	
	/**
	 * Metodo que permite registrar el sustento gasto.
	 * @author Jorge Ponce.
	 * @param  planViajeBean :objeto que tiene los datos para registrar.
	 * @return Codigo de operacion: Exito(00), Error(01).
	 * @see    String
	 * @throws Exception
	 */
	public String registrarSustentoGasto(PlanViajeBean planViajeBean) throws ServiceException, Exception {
		
		String codigoOperacion = ReembolsoConstantes.ERROR_OPERACION;
		boolean flagSustentoCorrecto = true;
		String errorMessage = ReembolsoConstantes.CADENA_VACIA;
		
		if (flagSustentoCorrecto) {
			ViaticoValidate viaticoValidate = viaticoConsultaService.validarMontoRendidoDiario(planViajeBean.getCodPlanViaje(), planViajeBean.getTipoDestino(), planViajeBean.getFlagMenorIgual4Horas(), planViajeBean.getMoneda());
			flagSustentoCorrecto = viaticoValidate.isFlagValidacion();
			if (!flagSustentoCorrecto) {
				errorMessage = viaticoValidate.getErrorMessage();
			}
		}
		
		if (flagSustentoCorrecto) {
			BigDecimal montoComprobanteGasto = planViajeRendicionDAO.obtenerMontoComprobanteGasto(planViajeBean.getCodPlanViaje());
			BigDecimal montoAsignadoTotal = BigDecimal.ZERO;
			String moneda = planViajeBean.getMoneda();
			ArrayList<PlanViajeConceptoBean> planViajeConceptoList = consultaReembolsoService.obtenerPlanViajeConcepto(planViajeBean.getCodPlanViaje(), moneda);
			if (planViajeConceptoList != null && !planViajeConceptoList.isEmpty()) {
				int sizeList = planViajeConceptoList.size();
				montoAsignadoTotal = new BigDecimal(NumeroUtil.formatearMonedaMontoToDecimal(null, 2, planViajeConceptoList.get(sizeList - 1).getMonto()));
			}
			
			int resultado = montoComprobanteGasto.compareTo(montoAsignadoTotal);
			if (resultado == 1) {
				flagSustentoCorrecto = false;
				String descripcionTipoDestino = ReembolsoConstantes.CADENA_VACIA;
				if (ViaticoConstantes.TIPO_COMISION_NACIONAL.equals(planViajeBean.getTipoDestino())) {
					descripcionTipoDestino = ViaticoConstantes.TIPO_COMISION_NACIONAL_DESCRIP.toLowerCase();
				}
				else {
					descripcionTipoDestino = ViaticoConstantes.TIPO_COMISION_INTERNACIONAL_DESCRIP.toLowerCase();
				}
				String montoComprobanteGastoFormateado =  NumeroUtil.formatearMonedaMontoToDecimal(moneda, 2, montoComprobanteGasto);
				String montoAsignadoTotalFormateado =  NumeroUtil.formatearMonedaMontoToDecimal(moneda, 2, montoAsignadoTotal);
				errorMessage = ResourceBundleUtil.getMessageReembolso(ReembolsoConstantes.MENSAJE_MONTO_COMPROBANTE_GASTO_MAYOR_ASIGNADO, descripcionTipoDestino, montoComprobanteGastoFormateado, montoAsignadoTotalFormateado);
			}
		}
		
		if (flagSustentoCorrecto) {
			planViajeDAO.actualizarPlanViajeToSustentoGastoReembolso(planViajeBean);
			codigoOperacion = ReembolsoConstantes.EXITO_OPERACION;
		}
		else {
			throw new ServiceException(this, errorMessage);
		}
		
		return codigoOperacion;
	}
	
	/**
	 * Metodo que permite anular una solicitud de viatico.
	 *
	 * @author Samuel Dionisio
	 * @param codPlanViaje codigo de solicitud de reembolso
	 * @param motivoAnulacion motivo de anulacion
	 * @param expedientePlanViaje expediente plan de viaje
	 * @param codigoAnulador codigo de empleado de la que realiza la anulacion
	 * @return codigo resultado de operacion
	 * @throws Exception
	 */
	@Override
	public String anularReembolsoRevision(String codPlanViaje, String motivoAnulacion, String expedientePlanViaje, String codigoAnulador) throws Exception {

		if (StringUtils.isBlank(codPlanViaje)) throw new IllegalArgumentException("Codigo de planilla no puede estar vacia");
		if (StringUtils.isBlank(expedientePlanViaje)) throw new IllegalArgumentException("Solicitud tiene asociado ningun expediente");

		// creacion del plan viaje a actualizar
		PlanViajeBean planViajeUpdate = new PlanViajeBean();

		planViajeUpdate.setCodPlanViaje(codPlanViaje); // PLAN_VIAJE_ID
		planViajeUpdate.setObservacionAnulacion(StringUtils.trimToNull(motivoAnulacion)); // OBS_ANULACION
		planViajeUpdate.setFechaAnulacion(new Date()); // FEC_ANULACION
		planViajeUpdate.setEstadoPlanViaje(ViaticoConstantes.ESTADO_REEMBOLSO_ANULADO); // ESTADO_PLAN_VIAJE

		// actualizar plan viaje
		planViajeDAO.actualizarPlanViaje(planViajeUpdate);

		// datos del anulador / usuario en session que realiza esta accion
		MaestroPersonalBean anulador = registroPersonalService.obtenerPersonaxCodigo(codigoAnulador);

		// crear accion (proceso: 417, accion: 003, estado: 004)
		String codigoProceso = ExpedienteConstantes.CODIGO_PROCESO_VIATICO_REEMBOLSO;
		String codigoAccion = ExpedienteConstantes.ESTADO_ACCION_002_ANULADO;
		String codigoEstado = ExpedienteConstantes.ESTADO_ACCION_003_ANULADO_V;

		viaticoExpedienteService.crearAccion(codigoProceso, expedientePlanViaje, codigoAccion, codigoEstado, codigoAnulador, ViaticoConstantes.EXPEDIENTE_ANULACION_SOLICITUD_MENSAJE, StringUtils.trimToNull(anulador.getCodigoSede()));
		
		return SolicitudConstantes.EXITO_OPERACION;
	}
	

}