package pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.recurso2.administracion.siga.archivo.model.bean.RegistroArchivosFisicoBean;
import pe.gob.sunat.recurso2.administracion.siga.archivo.service.RegistroArchivosService;
import pe.gob.sunat.recurso2.administracion.siga.expediente.util.ExpedienteConstantes;
import pe.gob.sunat.recurso2.administracion.siga.firma.service.GrabarDocumentoFirmaService;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.DependenciaBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroDependenciasService;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ColaboradorViaticoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeConceptoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeDestinoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.SolicitudDTO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeConceptoDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeDestinoDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoExpedienteService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoGeneralService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoMensajeriaService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.MaestroPersonalUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ResourceBundleUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.SolicitudConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;

/**
 * Clase RegistroSolicitudServiceImpl permite realizar operaciones de registro con las solicitudes de viatico.
 * 
 * @author Juan Saccatoma 
 */
public class RegistroSolicitudServiceImpl implements RegistroSolicitudService {

	/** Declaracion del log para realizar los debug, info, error, etc. */
	protected final Log log = LogFactory.getLog(getClass());

	/** Declaracion del DAO planViajeDAO. */
	private PlanViajeDAO planViajeDAO;

	/** Declaracion del DAO planViajeDestinoDAO. */
	private PlanViajeDestinoDAO planViajeDestinoDAO;

	/** Declaracion del DAO planViajeConceptoDAO. */
	private PlanViajeConceptoDAO planViajeConceptoDAO;

	/** Declaracion del servicio registroPersonalService. */
	private RegistroPersonalService registroPersonalService;

	/** Declaracion del servicio viaticoExpedienteService. */
	private ViaticoExpedienteService viaticoExpedienteService;

	/** Declaracion del servicio viaticoMensajeriaService. */
	private ViaticoMensajeriaService viaticoMensajeriaService;

	/** Declaracion del servicio viaticoGeneralService. */
	private ViaticoGeneralService viaticoGeneralService;
	
	
	/** Declaracion del servicio registroPersonalService. */
	private RegistroDependenciasService registroDependenciaService;
	
	private RegistroArchivosService registroArchivosService;
	private GrabarDocumentoFirmaService grabarDocumentoFirmaService;

	public PlanViajeDAO getPlanViajeDAO() {
		return planViajeDAO;
	}

	public void setPlanViajeDAO(PlanViajeDAO planViajeDAO) {
		this.planViajeDAO = planViajeDAO;
	}

	public PlanViajeDestinoDAO getPlanViajeDestinoDAO() {
		return planViajeDestinoDAO;
	}

	public void setPlanViajeDestinoDAO(PlanViajeDestinoDAO planViajeDestinoDAO) {
		this.planViajeDestinoDAO = planViajeDestinoDAO;
	}

	public PlanViajeConceptoDAO getPlanViajeConceptoDAO() {
		return planViajeConceptoDAO;
	}

	public void setPlanViajeConceptoDAO(PlanViajeConceptoDAO planViajeConceptoDAO) {
		this.planViajeConceptoDAO = planViajeConceptoDAO;
	}

	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}

	public ViaticoExpedienteService getViaticoExpedienteService() {
		return viaticoExpedienteService;
	}

	public void setViaticoExpedienteService(ViaticoExpedienteService viaticoExpedienteService) {
		this.viaticoExpedienteService = viaticoExpedienteService;
	}

	public ViaticoMensajeriaService getViaticoMensajeriaService() {
		return viaticoMensajeriaService;
	}

	public void setViaticoMensajeriaService(ViaticoMensajeriaService viaticoMensajeriaService) {
		this.viaticoMensajeriaService = viaticoMensajeriaService;
	}

	public ViaticoGeneralService getViaticoGeneralService() {
		return viaticoGeneralService;
	}

	public void setViaticoGeneralService(ViaticoGeneralService viaticoGeneralService) {
		this.viaticoGeneralService = viaticoGeneralService;
	}

	/**
	 * Metodo que permite anular una solicitud de viatico.
	 * 
	 * @author Juan Farro
	 * @param codPlanViaje codigo de solicitud de viatico
	 * @param motivoAnulacion motivo de anulacion
	 * @param expedientePlanViaje expediente plan de viaje
	 * @param codigoAnulador codigo de empleado de la que realiza la anulacion
	 * @return codigo resultado de operacion
	 * @throws Exception
	 */
	@Override
	public String anularSolicitud(String codPlanViaje, String motivoAnulacion, String expedientePlanViaje, String codigoAnulador) throws Exception {

		if (StringUtils.isBlank(codPlanViaje)) throw new IllegalArgumentException("Codigo de planilla no puede estar vacia");
		if (StringUtils.isBlank(expedientePlanViaje)) throw new IllegalArgumentException("Solicitud tiene asociado ningun expediente");

		// creacion del plan viaje a actualizar
		PlanViajeBean planViajeUpdate = new PlanViajeBean();

		planViajeUpdate.setCodPlanViaje(codPlanViaje); // PLAN_VIAJE_ID
		planViajeUpdate.setObservacionAnulacion(StringUtils.trimToNull(motivoAnulacion)); // OBS_ANULACION
		planViajeUpdate.setFechaAnulacion(new Date()); // FEC_ANULACION
		planViajeUpdate.setEstadoPlanViaje(ViaticoConstantes.ESTADO_VIATICO_ANULADO); // ESTADO_PLAN_VIAJE

		// actualizar plan viaje
		planViajeDAO.actualizarPlanViaje(planViajeUpdate);

		// datos del anulador / usuario en session que realiza esta accion
		MaestroPersonalBean anulador = registroPersonalService.obtenerPersonaxCodigo(codigoAnulador);

		// crear accion (proceso: 416, accion: 001, estado: 002)
		String codigoProceso = ExpedienteConstantes.CODIGO_PROCESO_VIATICO_SOLICITUD;
		String codigoAccion = ExpedienteConstantes.ACCION_VIATICO_SOLIC_GENERAR_SOLICITUD;
		String codigoEstado = ExpedienteConstantes.ACCION_VIATICO_SOLIC_GENERAR_ESTADO_ANULADO;

		String observacion = ViaticoConstantes.EXPEDIENTE_ANULACION_SOLICITUD_MENSAJE;
		int tamanioSubstring = 0;
		if (motivoAnulacion != null) {
			tamanioSubstring = motivoAnulacion.length();
			if (tamanioSubstring > (200 - (observacion.length() + 20))) {
				tamanioSubstring = 200 - (observacion.length() + 20);
			}
			observacion = observacion.trim() + " : " + motivoAnulacion.substring(0, tamanioSubstring); 
		}

		//viaticoExpedienteService.crearAccion(codigoProceso, expedientePlanViaje, codigoAccion, codigoEstado, codigoAnulador, ViaticoConstantes.EXPEDIENTE_ANULACION_SOLICITUD_MENSAJE, StringUtils.trimToNull(anulador.getCodigoSede()));
		viaticoExpedienteService.crearAccion(codigoProceso, expedientePlanViaje, codigoAccion, codigoEstado, codigoAnulador, observacion, StringUtils.trimToNull(anulador.getCodigoSede()));

		return SolicitudConstantes.EXITO_OPERACION;
	}

	/**
	 * Metodo que permite rechazar una solicitud de traslape.
	 * 
	 * @author Juan Farro
	 * @param codPlanilla codigo planilla
	 * @param motivoRechazo motivo
	 * @param codigoRechazador codigo de empleado de la que realiza el rechazo
	 * @throws Exception
	 */
	@Override
	public void rechazarSolicitud(String codPlanilla, String motivoRechazo, String codigoRechazador) throws Exception {

		// validar codigo de planilla (not blank y que exista)
		if (StringUtils.isBlank(codPlanilla)) throw new IllegalArgumentException("Codigo de planilla no puede estar vacio");

		PlanViajeBean planViaje = planViajeDAO.buscarPlanViajePlanilla(codPlanilla);

		if (planViaje == null) throw new IllegalArgumentException("Codigo de planilla no existe");

		// creacion del plan viaje a actualizar
		PlanViajeBean planViajeUpdate = new PlanViajeBean();

		planViajeUpdate.setCodPlanViaje(planViaje.getCodPlanViaje()); // PLAN_VIAJE_ID
//		planViajeUpdate.setObservacionTraslape(StringUtils.trimToNull(motivoRechazo)); // OBS_TRASLAPE
		planViajeUpdate.setFechaObsTraslape(new Date()); // FEC_OBS_TRASLAPE
		planViajeUpdate.setIndicadorAutorizacion(ViaticoConstantes.INDICADOR_AUTORIZACION_RECHAZADO); // IND_AUTORIZACION

		// actualizar plan viaje
		planViajeDAO.actualizarPlanViaje(planViajeUpdate);

		if (StringUtils.isBlank(planViaje.getExpedientePlanViaje())) throw new IllegalArgumentException("Solicitud no tiene asociado ningun expediente");

		// datos del anulador / usuario en session que realiza esta accion
		MaestroPersonalBean anulador = registroPersonalService.obtenerPersonaxCodigo(codigoRechazador);

		if (StringUtils.equals(planViaje.getOrigen(), ViaticoConstantes.TIPO_ORIGEN_SOLICITUD_VIATICO)) {

			// crear accion (proceso: 416, accion: 002, estado: 004)
			String codigoProceso = ExpedienteConstantes.CODIGO_PROCESO_VIATICO_SOLICITUD;
			String codigoAccion = ExpedienteConstantes.ACCION_VIATICO_SOLIC_OTORGAR_ALTA;
			String codigoEstado = ExpedienteConstantes.ACCION_VIATICO_SOLIC_OTORGAR_ALTA_ESTADO_RECHAZADO;

			String observacion = ViaticoConstantes.EXPEDIENTE_RECHAZO_SOLICITUD_MENSAJE;
			int tamanioSubstring = 0;
			if (motivoRechazo != null) {
				tamanioSubstring = motivoRechazo.length();
				if (tamanioSubstring > (200 - (observacion.length() + 20))) {
					tamanioSubstring = 200 - (observacion.length() + 20);
				}
				observacion = observacion.trim() + " : " + motivoRechazo.substring(0, tamanioSubstring); 
			}

			//viaticoExpedienteService.crearAccion(codigoProceso, planViaje.getExpedientePlanViaje(), codigoAccion, codigoEstado, codigoRechazador, ViaticoConstantes.EXPEDIENTE_RECHAZO_SOLICITUD_MENSAJE, StringUtils.trimToNull(anulador.getCodigoSede()));
			viaticoExpedienteService.crearAccion(codigoProceso, planViaje.getExpedientePlanViaje(), codigoAccion, codigoEstado, codigoRechazador, observacion, StringUtils.trimToNull(anulador.getCodigoSede()));
		} else if (StringUtils.equals(planViaje.getOrigen(), ViaticoConstantes.TIPO_ORIGEN_REEMBOLSO)) {

			// crear accion (proceso: 417, accion: 003, estado: 003)
			String codigoProceso = ExpedienteConstantes.CODIGO_PROCESO_VIATICO_REEMBOLSO;
			String codigoAccion = ExpedienteConstantes.ACCION_VIATICO_REEMB_OTORGAR_ALTA;
			String codigoEstado = ExpedienteConstantes.ACCION_VIATICO_REEMB_OTORGAR_ALTA_ESTADO_RECHAZADO;

			String observacion = ViaticoConstantes.EXPEDIENTE_RECHAZO_SOLICITUD_MENSAJE;
			int tamanioSubstring = 0;
			if (motivoRechazo != null) {
				tamanioSubstring = motivoRechazo.length();
				if (tamanioSubstring > (200 - (observacion.length() + 20))) {
					tamanioSubstring = 200 - (observacion.length() + 20);
				}
				observacion = observacion.trim() + " : " + motivoRechazo.substring(0, tamanioSubstring); 
			}
			
			//viaticoExpedienteService.crearAccion(codigoProceso, planViaje.getExpedientePlanViaje(), codigoAccion, codigoEstado, codigoRechazador, ViaticoConstantes.EXPEDIENTE_RECHAZO_SOLICITUD_MENSAJE, StringUtils.trimToNull(anulador.getCodigoSede()));
			viaticoExpedienteService.crearAccion(codigoProceso, planViaje.getExpedientePlanViaje(), codigoAccion, codigoEstado, codigoRechazador, observacion, StringUtils.trimToNull(anulador.getCodigoSede()));
		}

	}

	/**
	 * Metodo que permite dar de alta una solicitud de traslape.
	 * 
	 * @author Juan Farro
	 * @param codPlanilla codigo planilla
	 * @param codigoRegistrador codigo de empleado de la que realiza el alta
	 * @throws Exception
	 */
	@Override
	public void darAltaSolicitud(String codPlanilla, String codigoRegistrador) throws Exception {

		// validar codigo de planilla (not blank y que exista)
		if (StringUtils.isBlank(codPlanilla)) throw new IllegalArgumentException("Codigo de planilla no puede estar vacio");

		PlanViajeBean planViaje = planViajeDAO.buscarPlanViajePlanilla(codPlanilla);

		if (planViaje == null) throw new IllegalArgumentException("Codigo de planilla no existe");

		// creacion del plan viaje a actualizar
		PlanViajeBean planViajeUpdate = new PlanViajeBean();

		planViajeUpdate.setCodPlanViaje(planViaje.getCodPlanViaje()); // PLAN_VIAJE_ID
		planViajeUpdate.setFechaAutorizacion(new Date()); // FEC_AUTORIZACION
		planViajeUpdate.setIndicadorAutorizacion(ViaticoConstantes.INDICADOR_AUTORIZACION_AUTORIZADO); // IND_AUTORIZACION

		// actualizar plan viaje
		planViajeDAO.actualizarPlanViaje(planViajeUpdate);

		if (StringUtils.isBlank(planViaje.getExpedientePlanViaje())) throw new IllegalArgumentException("Solicitud no tiene asociado ningun expediente");

		// datos del anulador / usuario en session que realiza esta accion
		MaestroPersonalBean empleadoRegistradorAlta = registroPersonalService.obtenerPersonaxCodigo(codigoRegistrador);

		if (StringUtils.equals(planViaje.getOrigen(), ViaticoConstantes.TIPO_ORIGEN_SOLICITUD_VIATICO)) {

			// crear accion (proceso: 416, accion: 002, estado: 003).
			String codigoProceso = ExpedienteConstantes.CODIGO_PROCESO_VIATICO_SOLICITUD;
			String codigoAccion = ExpedienteConstantes.ACCION_VIATICO_SOLIC_OTORGAR_ALTA;
			String codigoEstado = ExpedienteConstantes.ACCION_VIATICO_SOLIC_OTORGAR_ALTA_ESTADO_APROBADO;

			viaticoExpedienteService.crearAccion(codigoProceso, planViaje.getExpedientePlanViaje(), codigoAccion, codigoEstado, codigoRegistrador, ViaticoConstantes.EXPEDIENTE_OTORGAR_ALTA_SOLICITUD_MENSAJE, StringUtils.trimToNull(empleadoRegistradorAlta.getCodigoSede()));

		} else if (StringUtils.equals(planViaje.getOrigen(), ViaticoConstantes.TIPO_ORIGEN_REEMBOLSO)) {

			// crear accion (proceso: 417, accion: 003, estado: 002)
			String codigoProceso = ExpedienteConstantes.CODIGO_PROCESO_VIATICO_REEMBOLSO;
			String codigoAccion = ExpedienteConstantes.ACCION_VIATICO_REEMB_OTORGAR_ALTA;
			String codigoEstado = ExpedienteConstantes.ACCION_VIATICO_REEMB_OTORGAR_ALTA_ESTADO_APROBADO;

			viaticoExpedienteService.crearAccion(codigoProceso, planViaje.getExpedientePlanViaje(), codigoAccion, codigoEstado, codigoRegistrador, ViaticoConstantes.EXPEDIENTE_OTORGAR_ALTA_SOLICITUD_MENSAJE, StringUtils.trimToNull(empleadoRegistradorAlta.getCodigoSede()));
		}

	}

	/**
	 * Metodo que permite autorizar una solicitud de viatico.
	 * 
	 * @author Juan Saccatoma
	 * @param parmSearch parametos de autorizacion
	 * @return true, si operacion fue exitosa
	 * @throws ServiceException
	 */
	@Override
	public boolean autorizarSolicitud(Map<String, Object> parmSearch) throws Exception {
		log.debug("Inicio - ViaticoSolicitudServiceImpl.autorizarSolicitud");
		PlanViajeBean planViajeBean = new PlanViajeBean();
		boolean flag = false;
		try {
			planViajeBean = planViajeDAO.getSolicitud(parmSearch);
			planViajeBean.setCodPerAutoriza((String) parmSearch.get("codRegistrador"));
			planViajeBean.setCodEstadoSolic((String) parmSearch.get("codEstadoSolic"));

			MaestroPersonalBean colaborador = registroPersonalService.obtenerPersonaxRegistro((String) parmSearch.get("numRegistrador"));
			ColaboradorViaticoBean colaboradorDTO = MaestroPersonalUtil.parseViatico(colaborador);

			planViajeDAO.actualizaAutorizacion(planViajeBean);
			flag = true;

			SolicitudDTO solicitudDTO = new SolicitudDTO();
			solicitudDTO.setPlanViajeBean(planViajeBean);
			solicitudDTO.setRegistrador(colaboradorDTO);
			// crearAccionAutorizar(solicitudDTO);
		} catch (DataAccessException e) {
			flag = false;
			throw new ServiceException(this, ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO));

		} catch (Exception e) {
			flag = false;
			throw new ServiceException(this, ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO));
		} finally {

		}

		return flag;
	}

	/**
	 * Metodo que permite registrar una solicitud viatico.
	 * 
	 * @author Juan Farro
	 * @param anioActual anio actual
	 * @param uuoo uuoo
	 * @param planViajeBean solicitud de viatico
	 * @param planViajeDestinos plan viaje destinos
	 * @param planViajeConceptos plan viaje conceptos
	 * @throws Exception
	 */
	@Override
	public PlanViajeBean registrarSolicitudViatico(String anioActual, String uuoo, PlanViajeBean planViajeBean, List<PlanViajeDestinoBean> planViajeDestinos, List<PlanViajeConceptoBean> planViajeConceptos) throws Exception {

		if (StringUtils.isBlank(anioActual)) throw new IllegalArgumentException("anio no puede estar vacia");
		if (StringUtils.isBlank(uuoo)) throw new IllegalArgumentException("uuoo no puede estar vacia");
		if (StringUtils.isBlank(planViajeBean.getSedePlanViaje())) throw new IllegalArgumentException("sede no puede estar vacia");

		// generar el secuencial PLAN_VIAJE_ID (primary key)
		planViajeBean.setCodPlanViaje(planViajeDAO.getSecuenciaPlanViajeID(planViajeBean.getSedePlanViaje(), anioActual));

		// generar el secuencial COD_PLANILLA_VIAJE ANIO VIGENTE + UUOO + "V" + CORRELATIVO 4 CARACTERES
		planViajeBean.setCodPlanilla(planViajeDAO.getSecuenciaCodPlanillaViaje(anioActual, uuoo, "V"));

		// registrar plan de viaje
		planViajeDAO.registrarPlanViaje(planViajeBean);

		if (CollectionUtils.isNotEmpty(planViajeDestinos)) {

			int secuencial = 1;
			for (PlanViajeDestinoBean destino : planViajeDestinos) {

				destino.setPlanViajeID(planViajeBean.getCodPlanViaje());
				destino.setSecuencial(secuencial++);

				// registrar destinos de plan de viaje
				planViajeDestinoDAO.registrarPlanViajeDestino(destino);
			}

		}

		if (CollectionUtils.isNotEmpty(planViajeConceptos)) {

			for (PlanViajeConceptoBean concepto : planViajeConceptos) {

				concepto.setPlanViajeID(planViajeBean.getCodPlanViaje());

				// registrar conceptos de plan de viaje
				planViajeConceptoDAO.registrarPlanViajeConcepto(concepto);
			}

		}

		// codigo del colaborador y registrador
		String codigoColaborador = planViajeBean.getCodTrabajador();
		String codigoRegistrador = planViajeBean.getCodigoRegistrador();

		// buscar la sede del registrador
		String sedeRegistrador = StringUtils.EMPTY;
		if (StringUtils.isNotBlank(planViajeBean.getCodigoRegistrador())) {
			MaestroPersonalBean registrador = registroPersonalService.obtenerPersonaxCodigo(planViajeBean.getCodigoRegistrador());
			if (registrador != null) {
				sedeRegistrador = registrador.getCodigoSede();
			}
		}

		// crear expediente
		String numeroExpediente = viaticoExpedienteService.crearExpediente(ExpedienteConstantes.CODIGO_PROCESO_VIATICO_SOLICITUD, planViajeBean.getCodPlanilla(), codigoColaborador, sedeRegistrador);

		// actualizar el numero de expediente
		if (StringUtils.isNotBlank(numeroExpediente)) {

			// preferible se crea un nuevo bean que solo actualice el campo que falta
			PlanViajeBean planViajeUpdate = new PlanViajeBean();

			planViajeUpdate.setCodPlanViaje(planViajeBean.getCodPlanViaje());
			planViajeUpdate.setExpedientePlanViaje(StringUtils.trimToNull(numeroExpediente));

			planViajeDAO.actualizarPlanViaje(planViajeUpdate);

		} else {
			log.debug("no se pudo generar numero de expediente");
		}

		// crear accion (proceso: 416, accion: 001, estado: 001)
		String codigoProceso = ExpedienteConstantes.CODIGO_PROCESO_VIATICO_SOLICITUD;
		String codigoAccion = ExpedienteConstantes.ACCION_VIATICO_SOLIC_GENERAR_SOLICITUD;
		String codigoEstado = ExpedienteConstantes.ACCION_VIATICO_SOLIC_GENERAR_ESTADO_GENERADO;

		viaticoExpedienteService.crearAccion(codigoProceso, numeroExpediente, codigoAccion, codigoEstado, codigoRegistrador, ViaticoConstantes.EXPEDIENTE_CREACION_SOLICITUD_MENSAJE, sedeRegistrador);

		// crear accion (proceso: 416, accion: 002, estado: 002) -> si hay traslape
		if (StringUtils.equals(planViajeBean.getIndicadorTraslape(), ViaticoConstantes.INDICADOR_TRASLAPE_SI)) {

			codigoProceso = ExpedienteConstantes.CODIGO_PROCESO_VIATICO_SOLICITUD;
			codigoAccion = ExpedienteConstantes.ACCION_VIATICO_SOLIC_OTORGAR_ALTA;
			codigoEstado = ExpedienteConstantes.ACCION_VIATICO_SOLIC_OTORGAR_ALTA_ESTADO_EN_ESPERA;

			viaticoExpedienteService.crearAccion(codigoProceso, numeroExpediente, codigoAccion, codigoEstado, codigoRegistrador, ViaticoConstantes.EXPEDIENTE_TRASLAPE_SOLICITUD_MENSAJE, sedeRegistrador);
		}
		return planViajeBean;

	}

	/**
	 * Metodo que permite modificar una solicitud viatico.
	 * 
	 * @author Juan Farro
	 * @param planViajeBean solicitud de viatico
	 * @param planViajeDestinos plan viaje destinos
	 * @param planViajeConceptos plan viaje conceptos
	 * @throws Exception
	 */
	@Override
	public void actualizarSolicitudViatico(PlanViajeBean planViajeBean, List<PlanViajeDestinoBean> planViajeDestinos, List<PlanViajeConceptoBean> planViajeConceptos) throws Exception {

		if (planViajeBean == null) throw new IllegalArgumentException("objeto plan de viaje no puede ser null");
		if (StringUtils.isBlank(planViajeBean.getCodPlanViaje())) throw new IllegalArgumentException("codigo de plan de viaje no puede estar vacio");

		// NOTA: el actualizarPlanViajeToModificar no modificar el ESTADO_PLAN_VIAJE (por el tema del boton imprimir que cambia de estado)

		// actualizar campos de plan de viaje
		planViajeDAO.actualizarPlanViajeToModificar(planViajeBean);

		// eliminar todos los plan de viaje destino asociados al viatico
		planViajeDestinoDAO.eliminarPlanViajeDestinos(planViajeBean.getCodPlanViaje());

		if (CollectionUtils.isNotEmpty(planViajeDestinos)) {

			int secuencial = 1;
			for (PlanViajeDestinoBean destino : planViajeDestinos) {

				destino.setPlanViajeID(planViajeBean.getCodPlanViaje());
				destino.setSecuencial(secuencial++);

				planViajeDestinoDAO.registrarPlanViajeDestino(destino);
			}

		}

		// eliminar todos los plan de viaje concepto asociados al viatico
		planViajeConceptoDAO.eliminarPlanViajeConceptos(planViajeBean.getCodPlanViaje());

		if (CollectionUtils.isNotEmpty(planViajeConceptos)) {

			for (PlanViajeConceptoBean concepto : planViajeConceptos) {

				concepto.setPlanViajeID(planViajeBean.getCodPlanViaje());

				// registrar conceptos de plan de viaje
				planViajeConceptoDAO.registrarPlanViajeConcepto(concepto);
			}

		}

	}

	/**
	 * Metodo que permite enviar una solicitud viatico (estado por autorizar).
	 * 
	 * @author Juan Farro
	 * @param codPlanViaje codigo de plan de viaje a enviar
	 * @param codigoEnviador codigo de empleado que realiza el envio
	 * @param tipoConfiguracion tipo de configuracion
	 * @return true, si tiene exito
	 * @throws Exception
	 */
	@Override
	public boolean enviarSolicitudViatico(String codPlanViaje, String codigoEnviador, String tipoConfiguracion, String numeroRegistroArchivo) throws Exception {

		// buscar plan de viaje
		if (StringUtils.isBlank(codPlanViaje)) throw new IllegalArgumentException("codPlanViaje no puede estar vacio");

		// trae todos los datos de plan de viaje
		PlanViajeBean planViaje = planViajeDAO.buscarPlanViaje(codPlanViaje);

		if (planViaje == null) throw new IllegalArgumentException("codPlanViaje no existe");

		// creacion del bean de modificacion
		PlanViajeBean planViajeUpdate = new PlanViajeBean();

		// seteando primary key del update
		planViajeUpdate.setCodPlanViaje(planViaje.getCodPlanViaje());

		boolean envioValido = false;
		boolean esNacional = StringUtils.equals(planViaje.getTipoDestino(), ViaticoConstantes.TIPO_COMISION_NACIONAL);
		boolean esConfiguracionManual = StringUtils.equals(tipoConfiguracion, ViaticoConstantes.TIPO_CONFIGURACION_MANUAL);

		if (esConfiguracionManual) {

			// setear estado a autorizado
			planViajeUpdate.setEstadoPlanViaje(ViaticoConstantes.ESTADO_VIATICO_AUTORIZADO);

			if (esNacional) {

				// si es nacional valida el CCP
				String codigoCCP = planViajeDAO.obtenerCodigoCCP(ViaticoConstantes.CCP_SISTEMA_VIATICOS, planViaje.getCodPlanViaje());

				codigoCCP = StringUtils.trimToEmpty(codigoCCP);

				// CCP VALIDO
				envioValido = StringUtils.equals(codigoCCP, ViaticoConstantes.CCP_SISTEMA_VIATICOS_OK);

			} else {

				// en internacional no se valida el CCP
				envioValido = true;
			}

			if (envioValido) {

				// actualizar plan de viaje
				planViajeDAO.actualizarPlanViaje(planViajeUpdate);
			}

		} else {
			
			//Invocamos al procedimiento SIGA01.PAFIRMAELECTRONICA.SP_UUOOAUTORIZA() para obtener el código de dependencia de autorización
			Map<String,String> resultado = planViajeDAO.obtenerUUOOAutorizadora(planViaje.getCodigoDependencia(), planViaje.getCodTrabajador(), "V");
			String codEjecucion = (String)resultado.get("codEjecucion");
			if("00".equals(codEjecucion)){
				
				String codDependenciaAutoriza = (String)resultado.get("codDependenciaAutoriza");
				
				//Ahora hay que buscar al responsable de esa acción
				DependenciaBean dependenciaAutoriza = registroDependenciaService.obtenerDependenciaXcod(codDependenciaAutoriza);
				
				// setear estado a por autorizar
				planViajeUpdate.setEstadoPlanViaje(ViaticoConstantes.ESTADO_VIATICO_POR_AUTORIZAR);
				planViajeUpdate.setCodigoDepAutor(codDependenciaAutoriza);
				planViajeUpdate.setPersonaAutorizacionVigente(dependenciaAutoriza.getCodEmpleado());
				planViajeUpdate.setNumeroRegistroArchivo(numeroRegistroArchivo);

				// actualizar plan de viaje
				planViajeDAO.actualizarPlanViaje(planViajeUpdate);

				// obtener datos del enviador (para crear la accion)
				MaestroPersonalBean enviador = registroPersonalService.obtenerPersonaxCodigo(codigoEnviador);

				// crear accion (proceso: 416, accion: 001, estado: 005)
				String codigoProceso = ExpedienteConstantes.CODIGO_PROCESO_VIATICO_SOLICITUD;
				String codigoAccion = ExpedienteConstantes.ACCION_VIATICO_SOLIC_ENVIAR_AUTORIZADOR;
				String codigoEstado = ExpedienteConstantes.ACCION_VIATICO_SOLIC_GENERAR_ESTADO_EN_LEVANTAMIENTO_OBSERVACION;

				if (StringUtils.isBlank(planViaje.getExpedientePlanViaje())) throw new Exception("Solicitud no tiene expediente");

				viaticoExpedienteService.crearAccion(codigoProceso, planViaje.getExpedientePlanViaje(), codigoAccion, "005", codigoEnviador, ViaticoConstantes.EXPEDIENTE_ENVIO_SOLICITUD_MENSAJE, StringUtils.trimToNull(enviador.getCodigoSede()));
				
				envioValido = true;
			}
			
		}

		return envioValido;
	}

	/**
	 * Buscar un nivel de viatico por su codigo.
	 * 
	 * @author Juan Farro
	 * @param codPlanViaje codigo de solicitud de viatico
	 * @param nuevoEstado nuevo estado
	 * @throws Exception
	 */
	@Override
	public void actualizarEstadoViatico(String codPlanViaje, String nuevoEstado) throws Exception {

		if (StringUtils.isBlank(codPlanViaje)) throw new IllegalArgumentException("Codigo de plan de viaje no puede estar vacio");

		// cambiar el estado a por autorizar
		PlanViajeBean planViajeUpdate = new PlanViajeBean();

		planViajeUpdate.setCodPlanViaje(codPlanViaje);
		planViajeUpdate.setEstadoPlanViaje(nuevoEstado);

		planViajeDAO.actualizarPlanViaje(planViajeUpdate);

	}

	@Override
	public void actualizarNumeroArchivoPlanViaje(PlanViajeBean planViaje) throws Exception {
		planViajeDAO.actualizarPlanViaje(planViaje);
	}

	public RegistroDependenciasService getRegistroDependenciaService() {
		return registroDependenciaService;
	}

	public void setRegistroDependenciaService(
			RegistroDependenciasService registroDependenciaService) {
		this.registroDependenciaService = registroDependenciaService;
	}

	@Override
	public void anularFirmaDocumento(Long codDocaut, String numArchivo,
			String nomArchivo) throws Exception {
		grabarDocumentoFirmaService.anularDocumento(codDocaut);
		List<RegistroArchivosFisicoBean> archivos = registroArchivosService.listarArchivosFirmados(numArchivo, nomArchivo);
		if(!CollectionUtils.isEmpty(archivos)){
			for(RegistroArchivosFisicoBean bean:archivos){
				Map<String,Object> paramUpdate = new HashMap<String,Object>();
				paramUpdate.put("sec_arc", bean.getSec_reg().toString());
				registroArchivosService.eliminarArchivoFisicoGeneral(paramUpdate);	
			}
		}
		
	}

	public RegistroArchivosService getRegistroArchivosService() {
		return registroArchivosService;
	}

	public void setRegistroArchivosService(
			RegistroArchivosService registroArchivosService) {
		this.registroArchivosService = registroArchivosService;
	}

	public GrabarDocumentoFirmaService getGrabarDocumentoFirmaService() {
		return grabarDocumentoFirmaService;
	}

	public void setGrabarDocumentoFirmaService(
			GrabarDocumentoFirmaService grabarDocumentoFirmaService) {
		this.grabarDocumentoFirmaService = grabarDocumentoFirmaService;
	}

}