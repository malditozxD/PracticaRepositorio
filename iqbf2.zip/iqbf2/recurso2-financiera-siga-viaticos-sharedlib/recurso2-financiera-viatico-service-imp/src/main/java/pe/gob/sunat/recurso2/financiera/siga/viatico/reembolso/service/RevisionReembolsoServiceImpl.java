package pe.gob.sunat.recurso2.financiera.siga.viatico.reembolso.service;

import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.recurso2.administracion.siga.expediente.util.ExpedienteConstantes;
import pe.gob.sunat.recurso2.administracion.siga.util.FechaUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.FormatoUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.NumeroUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoExpedienteService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ReembolsoConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;

/**
 * Implementacion de la interface RevisionReembolsoService, contiene los metodos para la revision del reembolso.
 * @author Jorge Ponce.
 */
public class RevisionReembolsoServiceImpl implements RevisionReembolsoService {
	
	protected final Log log = LogFactory.getLog(getClass());
	private ConsultaReembolsoService consultaReembolsoService;
	private ViaticoExpedienteService viaticoExpedienteService;
	private PlanViajeDAO planViajeDAO;
	
	public ConsultaReembolsoService getConsultaReembolsoService() {
		return consultaReembolsoService;
	}

	public void setConsultaReembolsoService(ConsultaReembolsoService consultaReembolsoService) {
		this.consultaReembolsoService = consultaReembolsoService;
	}

	public ViaticoExpedienteService getViaticoExpedienteService() {
		return viaticoExpedienteService;
	}

	public void setViaticoExpedienteService(ViaticoExpedienteService viaticoExpedienteService) {
		this.viaticoExpedienteService = viaticoExpedienteService;
	}

	public PlanViajeDAO getPlanViajeDAO() {
		return planViajeDAO;
	}

	public void setPlanViajeDAO(PlanViajeDAO planViajeDAO) {
		this.planViajeDAO = planViajeDAO;
	}

	/**
	 * Metodo que permite obtener el listado de planes de viaje que se van a mostrar en la bandeja de autorizacion de reembolso.
	 * @author Jorge Ponce.
	 * @param  codigoDependencia :codigo de dependencia.
	 * @param  codPlanilla :codigo de planilla.
	 * @param  codTrabajador :codigo del colaborador.
	 * @param  codEstadoSolic :codigo de estado de la solicitud.
	 * @param  fechaDesde :fecha desde.
	 * @param  fechaHasta :fecha hasta.
	 * @param  codigoAutorizador :codigo del autorizador.
	 * @return Objeto PlanViajeBean.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	public ArrayList<PlanViajeBean> obtenerPlanViajeCompletoToBandejaAutorizacionReembolso(String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoSolic, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws Exception {
		
		ArrayList<PlanViajeBean> planViajeList = obtenerPlanViajeToBandejaAutorizacionReembolso(codigoDependencia, codPlanilla, codTrabajador, codEstadoSolic, fechaDesde, fechaHasta, codigoAutorizador);
		ArrayList<PlanViajeBean> planViajeDetalleList = consultaReembolsoService.obtenerPlanViajeDetalleToBandejaReembolso(null, codigoDependencia, codPlanilla, codTrabajador, codEstadoSolic, fechaDesde, fechaHasta, codigoAutorizador);
		ArrayList<PlanViajeBean> planViajeCompletoList = null;
		if (planViajeList != null && !planViajeList.isEmpty() && planViajeDetalleList != null && !planViajeDetalleList.isEmpty()) {
			int sizePlanViajeList = planViajeList.size();
			int sizePlanViajeDetalleList = planViajeDetalleList.size();
			if (sizePlanViajeList == sizePlanViajeDetalleList) {
				planViajeCompletoList = new ArrayList<PlanViajeBean>();
				for (int i = 0; i < sizePlanViajeList; i++) {
					PlanViajeBean planViaje = planViajeList.get(i);
					PlanViajeBean planViajeDetalle = planViajeDetalleList.get(i);
					planViaje.setCodigoPlanillaAsc(planViajeDetalle.getCodigoPlanillaAsc());
					planViaje.setNomUuOoCom(planViajeDetalle.getNomUuOoCom());
					planViaje.setItinerario(planViajeDetalle.getItinerario());
					planViaje.setFecSalidaFormateada(planViajeDetalle.getFecSalidaFormateada());
					planViaje.setFecRetornoFormateada(planViajeDetalle.getFecRetornoFormateada());
					planViaje.setMotivoComis(planViajeDetalle.getMotivoComis());
					planViaje.setObservacionAnulacion(planViajeDetalle.getObservacionAnulacion());
					planViaje.setNomRegistrador(planViajeDetalle.getNomRegistrador());
					planViaje.setInternacionalNroResolucion(planViajeDetalle.getInternacionalNroResolucion());
					planViaje.setImpGastoAlojFormateado(planViajeDetalle.getImpGastoAlojFormateado());
					planViaje.setImpGastoAlimFormateado(planViajeDetalle.getImpGastoAlimFormateado());
					planViaje.setImpGastoMovLocalFormateado(planViajeDetalle.getImpGastoMovLocalFormateado());
					planViaje.setImpGastoTrasladoFormateado(planViajeDetalle.getImpGastoTrasladoFormateado());
					planViaje.setImpAsigPasajesFormateado(planViajeDetalle.getImpAsigPasajesFormateado());
					planViaje.setMedioPago(planViajeDetalle.getMedioPago());
					planViajeCompletoList.add(planViaje);
				}
			}
		}
		return planViajeCompletoList;
	}
	
	/**
	 * Metodo que permite obtener el listado de plan de viaje que se van a mostrar en la bandeja de autorizacion de reembolso.
	 * @author Jorge Ponce.
	 * @param  codigoDependencia :codigo de dependencia.
	 * @param  codPlanilla :codigo de planilla.
	 * @param  codTrabajador :codigo del colaborador.
	 * @param  codEstadoSolic :codigo de estado de la solicitud.
	 * @param  fechaDesde :fecha desde.
	 * @param  fechaHasta :fecha hasta.
	 * @param  codigoAutorizador :codigo del autorizador.
	 * @return Listado de plan de viaje.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	public ArrayList<PlanViajeBean> obtenerPlanViajeToBandejaAutorizacionReembolso(String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoSolic, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws Exception {
		
		ArrayList<PlanViajeBean> planViajeList = planViajeDAO.obtenerPlanViajeToBandejaAutorizacionReembolso(codigoDependencia, codPlanilla, codTrabajador, codEstadoSolic, fechaDesde, fechaHasta, codigoAutorizador);
		ArrayList<PlanViajeBean> planViajeListAux = null;
		if (planViajeList != null && !planViajeList.isEmpty()) {
			planViajeListAux = new ArrayList<PlanViajeBean>();
			for (PlanViajeBean planViajeBean : planViajeList) {
				planViajeBean.setFechaRegistroFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFechaRegistro()));
				planViajeBean.setMtoTotalFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getMtoTotal(), 2));
				planViajeBean.setNomEstSolic(FormatoUtil.getUppperCaseText(planViajeBean.getNomEstSolic()));
				planViajeBean.setNomUuOoCom(FormatoUtil.getUppperCaseText(planViajeBean.getNomUuOoCom()));
				planViajeListAux.add(planViajeBean);
			}
		}
		return planViajeListAux;
	}
	
	/**
	 * Metodo que permite autorizar un reembolso.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @param  codPerAutoriza :codigo del autorizador.
	 * @param  codigoSedeAutorizador :codigo de sede del autorizador.
	 * @param  codigoNivelAutorizador :codigo nivel del autorizador.
	 * @param  expedientePlanViaje :expediente plan de viaje.
	 * @return Codigo de operacion: Exito(00) - Error(01).
	 * @see    String
	 * @throws Exception
	 */
	public String autorizarReembolso(String codPlanViaje, String codPerAutoriza, String codigoSedeAutorizador, String codigoNivelAutorizador, String expedientePlanViaje) throws Exception {
		
		String codigoOperacion = ReembolsoConstantes.ERROR_OPERACION;
		PlanViajeBean planViajeBean = new PlanViajeBean();
		planViajeBean.setCodPlanViaje(codPlanViaje);
		planViajeBean.setCodEstadoSolic(ViaticoConstantes.ESTADO_REEMBOLSO_AUTORIZADO);
		planViajeBean.setCodPerAutoriza(codPerAutoriza);
		planViajeBean.setCodigoNivAutor(codigoNivelAutorizador);
		planViajeDAO.autorizarReembolsoByAutorizador(planViajeBean);
		/*Seguimiento*/
		String observacion = ViaticoConstantes.EXPEDIENTE_AUTORIZACION_REEMBOLSO_MENSAJE;
		viaticoExpedienteService.crearAccion(ExpedienteConstantes.CODIGO_PROCESO_VIATICO_REEMBOLSO, expedientePlanViaje, ExpedienteConstantes.ESTADO_ACCION_002_CONFORME, ExpedienteConstantes.ACCION_VIATICO_REEMBOLSO_AUTORIZADA_AUTORIZADOR, codPerAutoriza, observacion, codigoSedeAutorizador);
		codigoOperacion = ReembolsoConstantes.EXITO_OPERACION;
		return codigoOperacion;
	}
	
	/**
	 * Metodo que permite observar un reembolso.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @param  observacionAutorizador :motivo de observacion.
	 * @param  codPerAutoriza :codigo del autorizador.
	 * @param  codigoSedeAutorizador :codigo de sede del autorizador.
	 * @param  expedientePlanViaje :expediente plan de viaje.
	 * @return Codigo de operacion: Exito(00) - Error(01).
	 * @see    String
	 * @throws Exception
	 */
	public String observarReembolso(String codPlanViaje, String observacionAutorizador, String codPerAutoriza, String codigoSedeAutorizador, String expedientePlanViaje) throws Exception {
		
		String codigoOperacion = ReembolsoConstantes.ERROR_OPERACION;
		PlanViajeBean planViajeBean = new PlanViajeBean();
		planViajeBean.setCodPlanViaje(codPlanViaje);
		planViajeBean.setCodEstadoSolic(ViaticoConstantes.ESTADO_REEMBOLSO_OBSERVADO);
		planViajeBean.setObservacionAutorizador(observacionAutorizador);
		planViajeDAO.observarReembolsoByAutorizador(planViajeBean);
		/*Seguimiento*/
		String observacion = ViaticoConstantes.EXPEDIENTE_OBSERVACION_REEMBOLSO_MENSAJE;
		viaticoExpedienteService.crearAccion(ExpedienteConstantes.CODIGO_PROCESO_VIATICO_REEMBOLSO, expedientePlanViaje, ExpedienteConstantes.ESTADO_ACCION_002_CONFORME, ExpedienteConstantes.ACCION_VIATICO_REEMBOLSO_OBSERVADA_AUTORIZADOR, codPerAutoriza, observacion, codigoSedeAutorizador);
		codigoOperacion = ReembolsoConstantes.EXITO_OPERACION;
		return codigoOperacion;
	}
	
	/**
	 * Metodo que permite anular un reembolso.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @param  observacionAnulacion :motivo de anulacion.
	 * @param  codPerAutoriza :codigo del autorizador.
	 * @param  codigoSedeAutorizador :codigo de sede del autorizador.
	 * @param  expedientePlanViaje :expediente plan de viaje.
	 * @return Codigo de operacion: Exito(00) - Error(01).
	 * @see    String
	 * @throws Exception
	 */
	public String anularReembolso(String codPlanViaje, String observacionAnulacion, String codPerAutoriza, String codigoSedeAutorizador, String expedientePlanViaje) throws Exception {
		
		String codigoOperacion = ReembolsoConstantes.ERROR_OPERACION;
		PlanViajeBean planViajeBean = new PlanViajeBean();
		planViajeBean.setCodPlanViaje(codPlanViaje);
		planViajeBean.setCodEstadoSolic(ViaticoConstantes.ESTADO_REEMBOLSO_ANULADO);
		planViajeBean.setObservacionAnulacion(observacionAnulacion);
		planViajeDAO.anularReembolsoByAutorizador(planViajeBean);
		/*Seguimiento*/
		String observacion = ViaticoConstantes.EXPEDIENTE_ANULACION_REEMBOLSO_MENSAJE;
		viaticoExpedienteService.crearAccion(ExpedienteConstantes.CODIGO_PROCESO_VIATICO_REEMBOLSO, expedientePlanViaje, ExpedienteConstantes.ESTADO_ACCION_002_CONFORME, ExpedienteConstantes.ACCION_VIATICO_REEMBOLSO_ANULADA_AUTORIZADOR, codPerAutoriza, observacion, codigoSedeAutorizador);
		codigoOperacion = ReembolsoConstantes.EXITO_OPERACION;
		return codigoOperacion;
	}
	
}
