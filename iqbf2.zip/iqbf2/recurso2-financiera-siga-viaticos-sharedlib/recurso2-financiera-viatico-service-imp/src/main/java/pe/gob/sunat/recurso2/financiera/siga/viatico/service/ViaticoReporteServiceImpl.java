package pe.gob.sunat.recurso2.financiera.siga.viatico.service;

import java.io.OutputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.WordUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;

import pe.gob.sunat.recurso2.administracion.siga.archivo.util.ReporteArchivoBean;
import pe.gob.sunat.recurso2.administracion.siga.archivo.util.ReporteJasperBean;
import pe.gob.sunat.recurso2.administracion.siga.archivo.util.ReporteJasperConstantes;
import pe.gob.sunat.recurso2.administracion.siga.archivo.util.ReporteJasperUtil;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroDependenciasService;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.administracion.siga.util.FechaConstantes;
import pe.gob.sunat.recurso2.administracion.siga.util.NumeroUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ColaboradorViaticoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.NivelBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PapeletaDepositoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeInformeDistribBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeRendicionBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ReembolsoDTO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.RendicionDTO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.SolicitudDTO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.CuentaCorrienteDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.NivelDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeConceptoDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeDestinoDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.reembolso.service.ConsultaReembolsoService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.rendicion.service.ConsultaRendicionService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.service.ConsultaSolicitudService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ExcelUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.RendicionConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ReporteConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoUtil;

public class ViaticoReporteServiceImpl implements ViaticoReporteService {

	protected final Log log = LogFactory.getLog(getClass());

	private ViaticoService viaticoService;
	private RegistroPersonalService registroPersonalService;
	private ConsultaSolicitudService consultaSolicitudService;
	private ConsultaReembolsoService consultaReembolsoService;
	private RegistroDependenciasService registroDependenciasService;
	private ViaticoConsultaService viaticoConsultaService;
	private ConsultaRendicionService consultaRendicionService;
	private PlanViajeDAO planViajeDAO;
	private CuentaCorrienteDAO cuentaCorrienteDAO;
	private PlanViajeConceptoDAO planViajeConceptoDAO;
	private PlanViajeDestinoDAO planViajeDestinoDAO;
	private NivelDAO nivelDAO;
	

	public ViaticoService getViaticoService() {
		return viaticoService;
	}

	public void setViaticoService(ViaticoService viaticoService) {
		this.viaticoService = viaticoService;
	}

	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}

	public ConsultaSolicitudService getConsultaSolicitudService() {
		return consultaSolicitudService;
	}

	public void setConsultaSolicitudService(ConsultaSolicitudService consultaSolicitudService) {
		this.consultaSolicitudService = consultaSolicitudService;
	}

	public PlanViajeDAO getPlanViajeDAO() {
		return planViajeDAO;
	}

	public void setPlanViajeDAO(PlanViajeDAO planViajeDAO) {
		this.planViajeDAO = planViajeDAO;
	}

	public CuentaCorrienteDAO getCuentaCorrienteDAO() {
		return cuentaCorrienteDAO;
	}

	public void setCuentaCorrienteDAO(CuentaCorrienteDAO cuentaCorrienteDAO) {
		this.cuentaCorrienteDAO = cuentaCorrienteDAO;
	}

	public PlanViajeConceptoDAO getPlanViajeConceptoDAO() {
		return planViajeConceptoDAO;
	}

	public void setPlanViajeConceptoDAO(PlanViajeConceptoDAO planViajeConceptoDAO) {
		this.planViajeConceptoDAO = planViajeConceptoDAO;
	}

	public PlanViajeDestinoDAO getPlanViajeDestinoDAO() {
		return planViajeDestinoDAO;
	}

	public void setPlanViajeDestinoDAO(PlanViajeDestinoDAO planViajeDestinoDAO) {
		this.planViajeDestinoDAO = planViajeDestinoDAO;
	}

	public NivelDAO getNivelDAO() {
		return nivelDAO;
	}

	public void setNivelDAO(NivelDAO nivelDAO) {
		this.nivelDAO = nivelDAO;
	}

	public RegistroDependenciasService getRegistroDependenciasService() {
		return registroDependenciasService;
	}

	public void setRegistroDependenciasService(RegistroDependenciasService registroDependenciasService) {
		this.registroDependenciasService = registroDependenciasService;
	}

	public ViaticoConsultaService getViaticoConsultaService() {
		return viaticoConsultaService;
	}

	public void setViaticoConsultaService(ViaticoConsultaService viaticoConsultaService) {
		this.viaticoConsultaService = viaticoConsultaService;
	}

	public ConsultaRendicionService getConsultaRendicionService() {
		return consultaRendicionService;
	}

	public void setConsultaRendicionService(ConsultaRendicionService consultaRendicionService) {
		this.consultaRendicionService = consultaRendicionService;
	}

	public ConsultaReembolsoService getConsultaReembolsoService() {
		return consultaReembolsoService;
	}

	public void setConsultaReembolsoService(
			ConsultaReembolsoService consultaReembolsoService) {
		this.consultaReembolsoService = consultaReembolsoService;
	}
	
	/**
	 * Metodo que permite generar el excel para la bandeja de solicitud de viaticos.
	 * @author Juan Farro.
	 * @param  outputStream :objeto donde se escribe los datos del excel.
	 * @param  planViajeList :listado de plan viaje.
	 * @param  tipoReporte :tipo de reporte
	 * @throws Exception
	 */
	@Override
	public void generarExcelBandejaSolicitudes(OutputStream outputStream, List<PlanViajeBean> listaSolicitudes, String tipoReporte) throws Exception {

		ExcelUtil excel = new ExcelUtil();

		// cabecera
		List<String> cabeceraList = new ArrayList<String>();

		cabeceraList.add("N\u00B0 Planilla");
		cabeceraList.add("Fecha de registro");
		cabeceraList.add("Nombre Colaborador");
		cabeceraList.add("Tipo de Vi\u00E1ticos");
		
		if (StringUtils.equals(tipoReporte, ReporteConstantes.TIPO_BANDEJA_CONSULTA_SOLICITUD)) {
			
			cabeceraList.add("Importe Total Otorgado");
		} else {
			cabeceraList.add("Total Otorgado");
		}
		
		cabeceraList.add("Canal de Atenci\u00F3n");
		cabeceraList.add("Plazo para Rendir");
		cabeceraList.add("Estado Planilla");
		cabeceraList.add("UUOO");
		cabeceraList.add("Itinerario");
		cabeceraList.add("Fecha de Salida/Fecha Ini. Evento");
		cabeceraList.add("Fecha de Retorno/Fecha Ter. Evento");
		cabeceraList.add("Total D\u00EDas/Horas de la Comisi\u00F3n");
		cabeceraList.add("Motivo de la Comisi\u00F3n");
		cabeceraList.add("Autorizador de Gasto");
		cabeceraList.add("Nombre del Registrador");
		cabeceraList.add("Asignaci\u00F3n de Vi\u00E1ticos");
		cabeceraList.add("Pasajes");
		cabeceraList.add("Otros");
		cabeceraList.add("Total Otorgado");
		cabeceraList.add("Medio de Pago");
		cabeceraList.add("N\u00B0 Recibo Provisional");
		cabeceraList.add("Fecha Pago Caja Ch.");

		excel.xlsInitLibro(ReporteConstantes.BANDEJA_SOLICITUD);
		
		// estilos personalizados
		HSSFCellStyle _styleCenter = excel.getStyleNormalCenter();
		HSSFCellStyle _styleRight = excel.getStyleNormalDerecha();
		HSSFCellStyle _styleBloque = excel.getStyleBloque();

		// por si desean las celdas con bordes
		// HSSFCellStyle _styleCenter = excel.xlsMakeStyleNormalCenter(true, true, true, true);
		// HSSFCellStyle _styleRight = excel.xlsMakeStyleNormalDerecha(true, true, true, true);
		// HSSFCellStyle _styleBloque = excel.xlsMakeStyleBloque(true, true, true, true);
		// HSSFCellStyle _styleFecha = excel.xlsMakeStyleDate(true, true, true, true);
		// HSSFCellStyle _styleLeft = excel.xlsMakeStyleNormal(true, true, true, true);
		// HSSFCellStyle _styleCabecera = excel.xlsMakeStyleCabecera(true, true, true, true);

		// por si desean las celdas con bordes
		// excel.setStyleCabecera(_styleCabecera);

		excel.xlsBloque(cabeceraList, null, 4);

		// número de columna
		int k = 0;

		if (CollectionUtils.isNotEmpty(listaSolicitudes)) {

			for (PlanViajeBean solicitud : listaSolicitudes) {

				// crear nueva fila
				excel.xlsRow();

				// crear celdas en la columna k
				k = 1;

				// Nro Planilla
				excel.xlsCell(k++, solicitud.getCodPlanilla(), _styleCenter);

				// Fecha de Registro
				excel.xlsCell(k++, solicitud.getFecRegistro());

				// Nombre Colaborador
				excel.xlsCell(k++, StringUtils.trimToEmpty(solicitud.getNomColaborador()));

				// Tipo de Viáticos
				excel.xlsCell(k++, StringUtils.trimToEmpty(solicitud.getNomTipoViatico()), _styleCenter);

				// Total Otorgado
				excel.xlsCell(k++, solicitud.getMtoTotal(), _styleRight);

				// Canal de Atención
				excel.xlsCell(k++, StringUtils.trimToEmpty(solicitud.getCanalAtencion()), _styleCenter);

				// Plazo para Rendir
				excel.xlsCell(k++, solicitud.getFecMaxRend());

				// Estado Planilla
				excel.xlsCell(k++, ViaticoUtil.trimUpperCase(solicitud.getNomEstSolic()), _styleCenter);

				// UUOO
				excel.xlsCell(k++, StringUtils.trimToEmpty(solicitud.getNomUuOoCom()));

				// Itinerario
				excel.xlsCell(k++, StringUtils.trimToEmpty(solicitud.getItinerario()));

				// Fecha de Salida
				excel.xlsCell(k++, solicitud.getFecSalida());

				// Fecha de Retorno
				excel.xlsCell(k++, solicitud.getFecRetorno());

				// Total días Comisión
				excel.xlsCell(k++, solicitud.getNumDias()!=null?solicitud.getNumDias():solicitud.getNumeroHoras(), _styleCenter);

				// Motivo de la Comisión
				excel.xlsCell(k++, StringUtils.trimToEmpty(solicitud.getMotivoComis()));

				// Autorizador de Gasto
				excel.xlsCell(k++, StringUtils.trimToEmpty(solicitud.getNomAutorizador()));

				// Nombre del Registrador
				excel.xlsCell(k++, StringUtils.trimToEmpty(solicitud.getNomRegistrador()));

				// Asignación de Viáticos
				excel.xlsCell(k++, solicitud.getImpAsigViatico(), _styleRight);

				// Pasajes
				excel.xlsCell(k++, solicitud.getImpPasaje(), _styleRight);

				// Otros
				excel.xlsCell(k++, solicitud.getImpOtros(), _styleRight);

				// Total Otorgado
				excel.xlsCell(k++, solicitud.getImpTotalOtorgado(), _styleRight);

				// Medio de Pago
				excel.xlsCell(k++, StringUtils.trimToEmpty(solicitud.getMedioPago()), _styleCenter);

				// Nro Recibo Provisional
				excel.xlsCell(k++, StringUtils.trimToEmpty(solicitud.getNumReciboProv()));

				// Fecha Pago Caja Ch.
				excel.xlsCell(k++, solicitud.getFecPagoCajaCh());

			}

		} else {

			excel.xlsRow();
			k = 1;

			excel.xlsCell(k++, ReporteConstantes.SIN_REGISTROS, _styleBloque);
			excel.xlsRow();
			excel.xlsRow();
			excel.xlsRow();
		}

		excel.xlsGetWbLibro().write(outputStream);
	}



	/**
	 * Metodo que permite generar el excel para la bandeja de solicitud de viaticos.
	 * @author Samuel Dionisio.
	 * @param  outputStream :objeto donde se escribe los datos del excel.
	 * @param  planViajeList :listado de plan viaje.
	 * @param  tipoReporte :tipo de reporte
	 * @throws Exception
	 */
	@Override
	public void generarExcelBandejaReembolsos(OutputStream outputStream, List<PlanViajeBean> listaReembolsos, String tipoReporte) throws Exception {

		ExcelUtil excel = new ExcelUtil();

		// cabecera
		List<String> cabeceraList = new ArrayList<String>();

		cabeceraList.add("N\u00B0 Solicitud");
		cabeceraList.add("Fec. de registro de Solicitud");
		cabeceraList.add("Nombre Colaborador");
		//cabeceraList.add("Tipo de Vi\u00E1ticos");
		/*if (StringUtils.equals(tipoReporte, ReporteConstantes.TIPO_BANDEJA_CONSULTA_SOLICITUD)) {
			
			cabeceraList.add("Importe Total Otorgado");
		} else {
			cabeceraList.add("Total Otorgado");
		}*/
		
		//cabeceraList.add("Canal de Atenci\u00F3n");
		//cabeceraList.add("Plazo para Rendir");
		cabeceraList.add("Total D\u00EDas de la Comisi\u00F3n");
		cabeceraList.add("Total Gasto");
		cabeceraList.add("Estado Solicitud");
		cabeceraList.add("Nombre de Autorizador");
		cabeceraList.add("Planilla Asociada");
		cabeceraList.add("UUOO");
		cabeceraList.add("Itinerario");
		cabeceraList.add("Fecha de Salida");
		cabeceraList.add("Fecha de Retorno");
		cabeceraList.add("Motivo de la Comisi\u00F3n");
		cabeceraList.add("Motivo por el cual no se otorge el Vi\u00E1tico");
		cabeceraList.add("Nombre del Registrador");
		cabeceraList.add("N\u00B0 de la Resoluci\u00F3n Administrativa");
		cabeceraList.add("Alojamiento");
		cabeceraList.add("Alimentaci\u00F3n");
		cabeceraList.add("Movilidad Local");
		cabeceraList.add("Traslado al/del");
		cabeceraList.add("Pasajes");
		cabeceraList.add("Medio de Pago");
		//cabeceraList.add("Motivo de la Comisi\u00F3n");
		//cabeceraList.add("Autorizador de Gasto");
		//cabeceraList.add("Nombre del Registrador");
		//cabeceraList.add("Asignaci\u00F3n de Vi\u00E1ticos");
		//cabeceraList.add("Pasajes");
		//cabeceraList.add("Otros");
		//cabeceraList.add("Total Otorgado");
		//cabeceraList.add("Medio de Pago");
		//cabeceraList.add("N\u00B0 Recibo Provisional");
		//cabeceraList.add("Fecha Pago Caja Ch.");

		excel.xlsInitLibro(ReporteConstantes.BANDEJA_SOLICITUD);
		
		// estilos personalizados
		HSSFCellStyle _styleCenter = excel.getStyleNormalCenter();
		HSSFCellStyle _styleRight = excel.getStyleNormalDerecha();
		HSSFCellStyle _styleBloque = excel.getStyleBloque();

		// por si desean las celdas con bordes
		// HSSFCellStyle _styleCenter = excel.xlsMakeStyleNormalCenter(true, true, true, true);
		// HSSFCellStyle _styleRight = excel.xlsMakeStyleNormalDerecha(true, true, true, true);
		// HSSFCellStyle _styleBloque = excel.xlsMakeStyleBloque(true, true, true, true);
		// HSSFCellStyle _styleFecha = excel.xlsMakeStyleDate(true, true, true, true);
		// HSSFCellStyle _styleLeft = excel.xlsMakeStyleNormal(true, true, true, true);
		// HSSFCellStyle _styleCabecera = excel.xlsMakeStyleCabecera(true, true, true, true);

		// por si desean las celdas con bordes
		// excel.setStyleCabecera(_styleCabecera);

		excel.xlsBloque(cabeceraList, null, 4);

		// número de columna
		int k = 0;

		if (CollectionUtils.isNotEmpty(listaReembolsos)) {

			for (PlanViajeBean solicitud : listaReembolsos) {

				// crear nueva fila
				excel.xlsRow();

				// crear celdas en la columna k
				k = 1;

				// Nro Planilla
				excel.xlsCell(k++, solicitud.getCodPlanilla(), _styleCenter);

				// Fecha de Registro
				excel.xlsCell(k++, solicitud.getFecRegistro());

				// Nombre Colaborador
				excel.xlsCell(k++, StringUtils.trimToEmpty(solicitud.getNomColaborador()));

				// Tipo de Viáticos
				//excel.xlsCell(k++, StringUtils.trimToEmpty(solicitud.getNomTipoViatico()), _styleCenter);				

				// Total días Comisión
				excel.xlsCell(k++, solicitud.getNumDias(), _styleCenter);

				// Total Gasto
				excel.xlsCell(k++, solicitud.getMtoTotal(), _styleRight);
				
				// Estado Planilla
				excel.xlsCell(k++, ViaticoUtil.trimUpperCase(solicitud.getNomEstSolic()), _styleCenter);				
				
				// Nombre Autorizador de Gasto
				excel.xlsCell(k++, StringUtils.trimToEmpty(solicitud.getNomAutorizador()));
				
				// UUOO
			//	excel.xlsCell(k++, StringUtils.trimToEmpty(solicitud.getNomUuOoCom()));

				// Itinerario
				//excel.xlsCell(k++, StringUtils.trimToEmpty(solicitud.getItinerario()));

				// Fecha de Salida
			//	excel.xlsCell(k++, solicitud.getFecSalida());

				// Fecha de Retorno
				//excel.xlsCell(k++, solicitud.getFecRetorno());


				

				// Motivo de la Comisión
				//excel.xlsCell(k++, StringUtils.trimToEmpty(solicitud.getMotivoComis()));

				

				// Nombre del Registrador
				//excel.xlsCell(k++, StringUtils.trimToEmpty(solicitud.getNomRegistrador()));

				// Asignación de Viáticos
				//excel.xlsCell(k++, solicitud.getImpAsigViatico(), _styleRight);

				// Pasajes
				//excel.xlsCell(k++, solicitud.getImpPasaje(), _styleRight);


				// Total Otorgado
				//excel.xlsCell(k++, solicitud.getImpTotalOtorgado(), _styleRight);

				// Medio de Pago
			//	excel.xlsCell(k++, StringUtils.trimToEmpty(solicitud.getMedioPago()), _styleCenter);

	

			}

		} else {

			excel.xlsRow();
			k = 1;

			excel.xlsCell(k++, ReporteConstantes.SIN_REGISTROS, _styleBloque);
			excel.xlsRow();
			excel.xlsRow();
			excel.xlsRow();
		}

		excel.xlsGetWbLibro().write(outputStream);
	}
	
	
	/**
	 * Metodo que permite generar el excel para la bandeja autorizacion solicitud.
	 * 
	 * @author Jorge Ponce.
	 * @param outputStream :objeto donde se escribe los datos del excel.
	 * @param planViajeList :listado de plan viaje.
	 * @throws Exception
	 */
	public void generarExcelBandejaAutorizacionSolicitud(OutputStream outputStream, ArrayList<PlanViajeBean> planViajeList) throws Exception {

		ExcelUtil excel = new ExcelUtil();

		// Cabecera
		ArrayList<String> cabeceraList = new ArrayList<String>();
		cabeceraList.add("Nro. Planilla");
		cabeceraList.add("Fec. Registro Solicitud");
		cabeceraList.add("Nombre Colaborador");
		cabeceraList.add("Tipo de Vi\u00e1ticos");
		cabeceraList.add("Importe Total Otorgado");
		cabeceraList.add("Canal de Atenci\u00F3n");
		cabeceraList.add("Plazo para Rendir");
		cabeceraList.add("Estado Planilla");

		cabeceraList.add("UUOO Comisionado");
		cabeceraList.add("Itinerario");
		cabeceraList.add("Fecha de Salida/Fecha Ini. Evento");
		cabeceraList.add("Fecha de Retorno/Fecha Ter. Evento");
		cabeceraList.add("Total D\u00edas/Horas de la Comisi\u00F3n");
		cabeceraList.add("Motivo de la Comisi\u00F3n");
		cabeceraList.add("Autorizador de Gasto");
		cabeceraList.add("Nombre del Registrador");

		cabeceraList.add("Asignaci\u00F3n de Vi\u00e1ticos");
		cabeceraList.add("Pasajes");
		cabeceraList.add("Otros");
		cabeceraList.add("Total Otorgado");
		cabeceraList.add("Medio de Pago");
		cabeceraList.add("Nro. Recibo Provisional");
		cabeceraList.add("Fecha Pago Caja Ch.");

		// Nombre del Libro
		excel.xlsInitLibro(ReporteConstantes.BANDEJA_AUTORIZACION_SOLICITUD);
		excel.xlsBloque(cabeceraList, null, 4);

		// Estilos
		HSSFCellStyle _styleCenter = excel.getStyleNormalCenter();
		HSSFCellStyle _styleBloque = excel.getStyleBloque();
		HSSFCellStyle _styleDerecha = excel.getStyleNormalDerecha();

		int contador = 0;
		if (planViajeList != null && !planViajeList.isEmpty()) {
			for (PlanViajeBean planViajeBean : planViajeList) {
				excel.xlsRow();
				contador = 1;
				excel.xlsCell(contador++, planViajeBean.getCodPlanilla(), _styleCenter);
				excel.xlsCell(contador++, planViajeBean.getFechaRegistroFormateada(), _styleCenter);
				excel.xlsCell(contador++, planViajeBean.getNomColaborador());
				excel.xlsCell(contador++, planViajeBean.getNomTipoViatico());
				excel.xlsCell(contador++, planViajeBean.getMtoTotalFormateado(), _styleDerecha);
				excel.xlsCell(contador++, planViajeBean.getCanalAtencion());
				excel.xlsCell(contador++, planViajeBean.getFecMaxRendFormateada(), _styleCenter);
				excel.xlsCell(contador++, planViajeBean.getNomEstSolic());

				excel.xlsCell(contador++, planViajeBean.getNomUuOoCom());
				excel.xlsCell(contador++, planViajeBean.getItinerario());
				excel.xlsCell(contador++, planViajeBean.getFecSalidaFormateada(), _styleCenter);
				excel.xlsCell(contador++, planViajeBean.getFecRetornoFormateada(), _styleCenter);
				if (planViajeBean.getNumDias() != null) {
					excel.xlsCell(contador++, planViajeBean.getNumDias(), _styleCenter);
				}else if (planViajeBean.getNumeroHoras() != null) { 
					excel.xlsCell(contador++, planViajeBean.getNumeroHoras(), _styleCenter);
				}else {
					excel.xlsCell(contador++, ReporteConstantes.CADENA_VACIA);
				}
				
				excel.xlsCell(contador++, planViajeBean.getMotivoComis());
				excel.xlsCell(contador++, planViajeBean.getNomAutorizador());
				excel.xlsCell(contador++, planViajeBean.getNomRegistrador());

				excel.xlsCell(contador++, planViajeBean.getImpAsigViaticoFormateado(), _styleDerecha);
				excel.xlsCell(contador++, planViajeBean.getImpAsigPasajesFormateado(), _styleDerecha);
				excel.xlsCell(contador++, planViajeBean.getImpOtrosFormateado(), _styleDerecha);
				excel.xlsCell(contador++, planViajeBean.getImpTotalOtorgadoFormateado(), _styleDerecha);
				excel.xlsCell(contador++, planViajeBean.getMedioPago());
				excel.xlsCell(contador++, planViajeBean.getNumReciboProv());
				excel.xlsCell(contador++, planViajeBean.getFecPagoCajaChFormateado(), _styleCenter);
			}
		} else {
			excel.xlsRow();
			contador = 1;
			excel.xlsCell(contador++, ReporteConstantes.SIN_REGISTROS, _styleBloque);
			excel.xlsRow();
			excel.xlsRow();
			excel.xlsRow();
		}

		excel.xlsGetWbLibro().write(outputStream);
	}

	/**
	 * Metodo que permite generar el excel para la bandeja rendicion.
	 * @author Jorge Ponce.
	 * @param outputStream :objeto donde se escribe los datos del excel.
	 * @param planViajeList :listado de plan viaje.
	 * @param  codigoPaginaCaller :codigo de pagina que llama al reporte.
	 * @throws Exception
	 */
	public void generarExcelBandejaConsultaRendicion(OutputStream outputStream, ArrayList<PlanViajeBean> planViajeList, String codigoPaginaCaller) throws Exception {

		ExcelUtil excel = new ExcelUtil();

		// Cabecera
		ArrayList<String> cabeceraList = new ArrayList<String>();
		cabeceraList.add("Nro. Planilla");
		cabeceraList.add("Fec. Registro de la Rendici\u00F3n");
		cabeceraList.add("Nombre Colaborador");
		cabeceraList.add("Tipo de Vi\u00e1ticos");
		if (RendicionConstantes.PAGE_CALLER_BANDEJA_RENDICION_REVISION.equals(codigoPaginaCaller)) {
			cabeceraList.add("Total Otorgado");
		}
		else {
			cabeceraList.add("Importe Total Otorgado");
		}
		cabeceraList.add("Fecha para Rendir Cuenta");
		cabeceraList.add("Fecha Reprogramada");
		cabeceraList.add("D\u00edas Vcto. Plazo");
		cabeceraList.add("Estado Rendici\u00F3n");
		cabeceraList.add("Estado Reprogramaci\u00F3n");

		cabeceraList.add("UUOO Comisionado");
		cabeceraList.add("Fecha de Salida/Fecha Ini. Evento");
		cabeceraList.add("Fecha de Retorno/Fecha Ter. Evento");
		cabeceraList.add("Itinerario");
		cabeceraList.add("Canal de Atenci\u00F3n");
		cabeceraList.add("Total D\u00edas/Horas de la Comisi\u00F3n");
		cabeceraList.add("Motivo de la Comisi\u00F3n");
		cabeceraList.add("Asignaci\u00F3n de Pasajes");
		cabeceraList.add("Otros");
		cabeceraList.add("Importe Total Otorgado");
		cabeceraList.add("Nombre del Registrador");

		cabeceraList.add("Alojamiento");
		cabeceraList.add("Alimentaci\u00F3n");
		cabeceraList.add("Movilidad Local");
		cabeceraList.add("Traslado al del");
		cabeceraList.add("Pasajes");
		cabeceraList.add("Importe Gastado");
		cabeceraList.add("Importe Devuelto");
		cabeceraList.add("Devoluci\u00F3n de Menor Gasto");
		cabeceraList.add("Nro. Recibo Provisional");
		cabeceraList.add("Fecha Pago Caja Ch.");

		// Nombre del Libro
		excel.xlsInitLibro(ReporteConstantes.BANDEJA_CONSULTA_RENDICION);
		excel.xlsBloque(cabeceraList, null, 4);

		// Estilos
		HSSFCellStyle _styleCenter = excel.getStyleNormalCenter();
		HSSFCellStyle _styleBloque = excel.getStyleBloque();
		HSSFCellStyle _styleDerecha = excel.getStyleNormalDerecha();

		int contador = 0;
		if (planViajeList != null && !planViajeList.isEmpty()) {
			for (PlanViajeBean planViajeBean : planViajeList) {
				excel.xlsRow();
				contador = 1;
				excel.xlsCell(contador++, planViajeBean.getCodPlanilla(), _styleCenter);
				excel.xlsCell(contador++, planViajeBean.getFechaRegistroRendicionFormateda(), _styleCenter);
				excel.xlsCell(contador++, planViajeBean.getNomColaborador());
				excel.xlsCell(contador++, planViajeBean.getNomTipoViatico());
				excel.xlsCell(contador++, planViajeBean.getMtoTotalFormateado(), _styleDerecha);
				excel.xlsCell(contador++, planViajeBean.getFecMaxRendFormateada());
				excel.xlsCell(contador++, planViajeBean.getFecReprogFormateada());
				if (planViajeBean.getCantDiasRend() != null) {
					excel.xlsCell(contador++, planViajeBean.getCantDiasRend(), _styleCenter);
				} else {
					excel.xlsCell(contador++, ReporteConstantes.CADENA_VACIA);
				}
				excel.xlsCell(contador++, planViajeBean.getNomEstRend());
				excel.xlsCell(contador++, ReporteConstantes.CADENA_VACIA);//TODO: q debe de mostrarse?

				excel.xlsCell(contador++, planViajeBean.getNomUuOoCom());
				excel.xlsCell(contador++, planViajeBean.getFecSalidaFormateada(), _styleCenter);
				excel.xlsCell(contador++, planViajeBean.getFecRetornoFormateada(), _styleCenter);
				excel.xlsCell(contador++, planViajeBean.getItinerario());
				excel.xlsCell(contador++, planViajeBean.getCanalAtencion());
				if (planViajeBean.getNumDias() != null) {
					excel.xlsCell(contador++, planViajeBean.getNumDias(), _styleCenter);
				} else if (planViajeBean.getNumeroHoras() != null) {
					excel.xlsCell(contador++, planViajeBean.getNumeroHoras(), _styleCenter);
				} else {
					excel.xlsCell(contador++, ReporteConstantes.CADENA_VACIA);
				}
				excel.xlsCell(contador++, planViajeBean.getMotivoComis());
				excel.xlsCell(contador++, planViajeBean.getImpAsigPasajesFormateado(), _styleDerecha);
				excel.xlsCell(contador++, planViajeBean.getImpOtrosFormateado(), _styleDerecha);
				excel.xlsCell(contador++, planViajeBean.getImpTotalOtorgadoFormateado(), _styleDerecha);
				excel.xlsCell(contador++, planViajeBean.getNomRegistrador());

				excel.xlsCell(contador++, planViajeBean.getImpGastoAlojFormateado(), _styleDerecha);
				excel.xlsCell(contador++, planViajeBean.getImpGastoAlimFormateado(), _styleDerecha);
				excel.xlsCell(contador++, planViajeBean.getImpGastoMovLocalFormateado(), _styleDerecha);
				excel.xlsCell(contador++, planViajeBean.getImpGastoTrasladoFormateado(), _styleDerecha);
				excel.xlsCell(contador++, planViajeBean.getImpGastoPasajesFormateado(), _styleDerecha);
				excel.xlsCell(contador++, planViajeBean.getImpGastoFormateado(), _styleDerecha);
				excel.xlsCell(contador++, planViajeBean.getImpDevueltoFormateado(), _styleDerecha);
				excel.xlsCell(contador++, planViajeBean.getImpDevolMenorFormateado(), _styleDerecha);
				excel.xlsCell(contador++, planViajeBean.getNumReciboProv());
				excel.xlsCell(contador++, planViajeBean.getFecPagoCajaChFormateado(), _styleCenter);
			}
		} else {
			excel.xlsRow();
			contador = 1;
			excel.xlsCell(contador++, ReporteConstantes.SIN_REGISTROS, _styleBloque);
			excel.xlsRow();
			excel.xlsRow();
			excel.xlsRow();
		}

		excel.xlsGetWbLibro().write(outputStream);
	}

	/**
	 * Metodo que permite generar el excel para la bandeja notificacion rendicion.
	 * 
	 * @author Jorge Ponce.
	 * @param outputStream :objeto donde se escribe los datos del excel.
	 * @param planViajeList :listado de plan viaje.
	 * @throws Exception
	 */
	public void generarExcelBandejaNotificacionRendicion(OutputStream outputStream, ArrayList<PlanViajeBean> planViajeList) throws Exception {

		ExcelUtil excel = new ExcelUtil();

		// Cabecera
		ArrayList<String> cabeceraList = new ArrayList<String>();
		cabeceraList.add("Nro. Planilla");
		cabeceraList.add("Comisionado");
		cabeceraList.add("Plazo de Rendici\u00F3n");
		cabeceraList.add("Fecha de 1ra. Notificaci\u00F3n");
		cabeceraList.add("Canal");
		cabeceraList.add("Importe Otorgado");
		cabeceraList.add("Importe Rendido");
		cabeceraList.add("Importe Devoluci\u00F3n Menor Gasto");
		cabeceraList.add("Observado");

		// Nombre del Libro
		excel.xlsInitLibro(ReporteConstantes.BANDEJA_NOTIFICACION_RENDICION);
		excel.xlsBloque(cabeceraList, null, 4);

		// Estilos
		HSSFCellStyle _styleCenter = excel.getStyleNormalCenter();
		HSSFCellStyle _styleBloque = excel.getStyleBloque();
		HSSFCellStyle _styleDerecha = excel.getStyleNormalDerecha();

		int contador = 0;
		if (planViajeList != null && !planViajeList.isEmpty()) {
			for (PlanViajeBean planViajeBean : planViajeList) {
				excel.xlsRow();
				contador = 1;
				excel.xlsCell(contador++, planViajeBean.getCodPlanilla(), _styleCenter);
				excel.xlsCell(contador++, planViajeBean.getNomColaborador());
				excel.xlsCell(contador++, planViajeBean.getFecMaxRendFormateada(), _styleCenter);
				excel.xlsCell(contador++, planViajeBean.getFechaNotificacionFormateada(), _styleCenter);
				excel.xlsCell(contador++, planViajeBean.getCanalAtencion());
				excel.xlsCell(contador++, planViajeBean.getMtoTotalFormateado(), _styleDerecha);
				excel.xlsCell(contador++, planViajeBean.getMontoDevueltoFormateado(), _styleDerecha);
				excel.xlsCell(contador++, planViajeBean.getMontoMenorGastoFormateado(), _styleDerecha);
				excel.xlsCell(contador++, planViajeBean.getObservacionDCP(), _styleCenter);
			}
		} else {
			excel.xlsRow();
			contador = 1;
			excel.xlsCell(contador++, ReporteConstantes.SIN_REGISTROS, _styleBloque);
			excel.xlsRow();
			excel.xlsRow();
			excel.xlsRow();
		}

		excel.xlsGetWbLibro().write(outputStream);
	}
	
	/**
	 * Metodo que permite generar el excel para la bandeja autorizacion solicitud.
	 * @author Jorge Ponce.
	 * @param  outputStream :objeto donde se escribe los datos del excel.
	 * @param  planViajeList :listado de plan viaje.
	 * @throws Exception
	 */
	public void generarExcelBandejaAutorizacionReembolso(OutputStream outputStream, ArrayList<PlanViajeBean> planViajeList) throws Exception {
		
		ExcelUtil excel = new ExcelUtil();

		// Cabecera
		ArrayList<String> cabeceraList = new ArrayList<String>();
		cabeceraList.add("Nro. Solicitud");
		cabeceraList.add("Fec. Registro Solicitud");
		cabeceraList.add("Nombre Colaborador");
		cabeceraList.add("Total D\u00edas de la Comisi\u00F3n");
		cabeceraList.add("Total Gasto");
		cabeceraList.add("Estado Solicitud");
		cabeceraList.add("Nombre del Autorizador");
		
		cabeceraList.add("Planilla Asociada");
		cabeceraList.add("UUOO");
		cabeceraList.add("Itinerario");
		cabeceraList.add("Fecha de Salida");
		cabeceraList.add("Fecha de Retorno");
		cabeceraList.add("Motivo de la comisi\u00F3n");
		cabeceraList.add("Motivo por el cual no se otorg\u00F3 Vi\u00e1ticos");
		cabeceraList.add("Nombre del Registrador");
		cabeceraList.add("N\u00B0 de Resoluci\u00F3n Administrativa");
		
		cabeceraList.add("Alojamiento");
		cabeceraList.add("Alimentaci\u00F3n");
		cabeceraList.add("Movilidad Local");
		cabeceraList.add("Traslado al/del");
		cabeceraList.add("Pasajes");
		cabeceraList.add("Medio Pago");

		// Nombre del Libro
		excel.xlsInitLibro(ReporteConstantes.BANDEJA_AUTORIZACION_REEMBOLSO);
		excel.xlsBloque(cabeceraList, null, 4);

		// Estilos
		HSSFCellStyle _styleCenter = excel.getStyleNormalCenter();
		HSSFCellStyle _styleBloque = excel.getStyleBloque();
		HSSFCellStyle _styleDerecha = excel.getStyleNormalDerecha();

		int contador = 0;
		if (planViajeList != null && !planViajeList.isEmpty()) {
			for (PlanViajeBean planViajeBean : planViajeList) {
				excel.xlsRow();
				contador = 1;
				excel.xlsCell(contador++, planViajeBean.getCodPlanilla(), _styleCenter);
				excel.xlsCell(contador++, planViajeBean.getFechaRegistroFormateada(), _styleCenter);
				excel.xlsCell(contador++, planViajeBean.getNomColaborador());
				excel.xlsCell(contador++, planViajeBean.getNumDias(), _styleCenter);
				excel.xlsCell(contador++, planViajeBean.getMtoTotalFormateado(), _styleDerecha);
				excel.xlsCell(contador++, planViajeBean.getNomEstSolic());
				excel.xlsCell(contador++, planViajeBean.getNomAutorizador());
				
				excel.xlsCell(contador++, planViajeBean.getCodigoPlanillaAsc(), _styleCenter);
				excel.xlsCell(contador++, planViajeBean.getNomUuOoCom());
				excel.xlsCell(contador++, planViajeBean.getItinerario());
				excel.xlsCell(contador++, planViajeBean.getFecSalidaFormateada(), _styleCenter);
				excel.xlsCell(contador++, planViajeBean.getFecRetornoFormateada(), _styleCenter);
				excel.xlsCell(contador++, planViajeBean.getMotivoComis());
				excel.xlsCell(contador++, planViajeBean.getObservacionAnulacion());
				excel.xlsCell(contador++, planViajeBean.getNomRegistrador());
				excel.xlsCell(contador++, planViajeBean.getInternacionalNroResolucion());
				
				excel.xlsCell(contador++, planViajeBean.getImpGastoAlojFormateado(), _styleCenter);
				excel.xlsCell(contador++, planViajeBean.getImpGastoAlimFormateado(), _styleCenter);
				excel.xlsCell(contador++, planViajeBean.getImpGastoMovLocalFormateado(), _styleCenter);
				excel.xlsCell(contador++, planViajeBean.getImpGastoTrasladoFormateado(), _styleCenter);
				excel.xlsCell(contador++, planViajeBean.getImpAsigPasajesFormateado(), _styleCenter);
				excel.xlsCell(contador++, planViajeBean.getMedioPago());
			}
		} else {
			excel.xlsRow();
			contador = 1;
			excel.xlsCell(contador++, ReporteConstantes.SIN_REGISTROS, _styleBloque);
			excel.xlsRow();
			excel.xlsRow();
			excel.xlsRow();
		}

		excel.xlsGetWbLibro().write(outputStream);
	}

	/**
	 * genera el reporte de solicitud de viaticos.
	 * @param codPlanViaje : String con el codigo de plan viaje
	 * @param modoProceso : String codigo de proceso 01 o 02
	 * @see ReporteArchivoBean
	 * @return lista de mapas para el cuerpo del reporte solicitud
	 * */
	@Override
	@SuppressWarnings("unused")
	public ReporteJasperBean generarReporteSolicitudViatico(String codPlanViaje, String modoProceso) throws Exception {

		SolicitudDTO solicitudDTO = consultaSolicitudService.obtenerDatosReporteSolicitud(codPlanViaje);
		
		PlanViajeBean planViaje = solicitudDTO.getPlanViajeBean();

		if (planViaje == null) throw new Exception("Solicitud no existe");

		boolean esNacional = StringUtils.equals(planViaje.getTipoDestino(), ViaticoConstantes.TIPO_COMISION_NACIONAL);
		boolean esInternacional = StringUtils.equals(planViaje.getTipoDestino(), ViaticoConstantes.TIPO_COMISION_INTERNACIONAL);
		boolean esMenorIgual4h = StringUtils.equals(planViaje.getIndicadorHoras(), ViaticoConstantes.INDICADOR_HORAS_HORAS); // INDICADOR_HORAS_HORAS 1:horas, 0:dias
		boolean esMayor4h = !StringUtils.equals(planViaje.getIndicadorHoras(), ViaticoConstantes.INDICADOR_HORAS_HORAS); // INDICADOR_HORAS_HORAS 1:horas, 0:dias
		boolean esTipoConfiguracionManual = StringUtils.equals(modoProceso, ViaticoConstantes.TIPO_CONFIGURACION_MANUAL);

		Map<String, Object> parametrosJasper = new HashMap<String, Object>();

		parametrosJasper.put("P_nombreColaborador", solicitudDTO.getColaborador().getNombreCompleto());
		parametrosJasper.put("P_numeroRegistro", solicitudDTO.getColaborador().getNumeroRegistro());
		parametrosJasper.put("P_unidadOrganizacional", solicitudDTO.getColaborador().getUuoo() + " - " + solicitudDTO.getColaborador().getNombreDependencia());
		Double mtoTotal = Double.valueOf(planViaje.getMtoTotal());
		parametrosJasper.put("P_importeOtorgado", planViaje.getMoneda() + ViaticoConstantes.CADENA_VACIA + NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(mtoTotal), 2));
		parametrosJasper.put("P_destinos", planViaje.getItinerario());
		parametrosJasper.put("P_motivo", planViaje.getMotivoComis());
		parametrosJasper.put("P_observaciones", planViaje.getObservacionSolicitud());
		parametrosJasper.put("P_fechaRegistro", ViaticoUtil.formatDateToDateDDMMYYYY(planViaje.getFechaRegistro()));
		parametrosJasper.put("P_numeroPlanilla", planViaje.getCodPlanilla());
		parametrosJasper.put("P_fechaMaxRendicion", planViaje.getFecMaxRend());
		
		String fechaRendicion = ViaticoUtil.formatDateToDateDDMMYYYY(planViaje.getFecMaxRend());
		
		parametrosJasper.put("P_diaMaxRendicion", fechaRendicion.substring(0, 2));
		parametrosJasper.put("P_mesMaxRendicion", fechaRendicion.substring(3, 5));
		parametrosJasper.put("P_anioMaxRendicion", fechaRendicion.substring(6));
		parametrosJasper.put("SUBREPORT_DIR", ReporteJasperConstantes.RUTA_JASPER_VIATICOS);
		parametrosJasper.put("P_nombreComisionado", solicitudDTO.getColaborador().getNombreCompleto());
		parametrosJasper.put("P_dniComisionado", solicitudDTO.getColaborador().getDni());
		parametrosJasper.put("P_uuooComisionado", solicitudDTO.getColaborador().getUuoo() + " - " + solicitudDTO.getColaborador().getNombreDependencia());
		parametrosJasper.put("P_cargoComisionado", solicitudDTO.getNivelColaborador().getDescripcionNivel());
		parametrosJasper.put("P_diaFechaComisionado", ViaticoUtil.formatDateToDateDDMMYYYY(planViaje.getFechaRegistro()));
		parametrosJasper.put("P_horaFechaComisionado", ViaticoUtil.formatDateToHourHHMM(planViaje.getFechaRegistro()));
		
		String UUOO = ViaticoConstantes.CADENA_VACIA;
		if (StringUtils.isNotEmpty((solicitudDTO.getAutorizador().getUuoo()))) {
			UUOO = solicitudDTO.getAutorizador().getUuoo() + " - " + solicitudDTO.getAutorizador().getNombreDependencia();
		}

		parametrosJasper.put("P_nombreAutorizador", solicitudDTO.getAutorizador().getNombreCompleto());
		parametrosJasper.put("P_numeroRegistroAutorizador", solicitudDTO.getAutorizador().getNumeroRegistro());
		parametrosJasper.put("P_dniAutorizador", solicitudDTO.getAutorizador().getDni());
		parametrosJasper.put("P_uuooAutorizador", UUOO);

		if (solicitudDTO.getNivelAutorizador() != null) {
			if (StringUtils.isNotEmpty(solicitudDTO.getNivelAutorizador().getDescripcionNivel())) parametrosJasper.put("P_cargoAutorizador", solicitudDTO.getNivelAutorizador().getDescripcionNivel());
		}

		if (planViaje.getFechaEnviofin() != null) {
			parametrosJasper.put("P_diaFechaAutorizador", ViaticoUtil.formatDateToDateDDMMYYYY(planViaje.getFechaEnviofin()));
			parametrosJasper.put("P_horaFechaAutorizador", ViaticoUtil.formatDateToHourHHMM(planViaje.getFechaEnviofin()));
		}

		parametrosJasper.put("P_numeroRegistroRegistrador", solicitudDTO.getRegistrador().getNumeroRegistro());
		parametrosJasper.put("P_nombreRegistrador", solicitudDTO.getRegistrador().getNombreCompleto());
		
		String nombreArchivoJasper = null;
		
		if (esNacional) {
			nombreArchivoJasper = ReporteConstantes.PLANILLA_VIATICO_NACIONAL;
			parametrosJasper.put("P_fechaInicio", ViaticoUtil.formatDateToDateDDMMYYYY(planViaje.getFecSalida()));
			parametrosJasper.put("P_fechaFin", ViaticoUtil.formatDateToDateDDMMYYYY(planViaje.getFecRetorno()));
			parametrosJasper.put("P_esMayor4Horas", esMayor4h);
		} else {
			nombreArchivoJasper = ReporteConstantes.PLANILLA_VIATICO_INTERNACIONAL;
			parametrosJasper.put("P_fechaInicio", ViaticoUtil.formatDateToDateDDMMYYYY(planViaje.getFecSalida()));
			parametrosJasper.put("P_fechaFin", ViaticoUtil.formatDateToDateDDMMYYYY(planViaje.getFecRetorno()));
		}
		parametrosJasper.put("P_montoImporteTotal", solicitudDTO.getMontoTotalConcepto());
		parametrosJasper.put("P_esTipoConfManual", esTipoConfiguracionManual);
		parametrosJasper.put("P_esTipoComisionNacional", esNacional);
		
		if(solicitudDTO.getCuenta() != null){
			parametrosJasper.put("P_numeroCuenta", solicitudDTO.getCuenta().getNumeroCuenta());
		}
		
		
		//Datos registrador
		StringBuilder datosRegistrador = new StringBuilder();
		ColaboradorViaticoBean registrador = solicitudDTO.getRegistrador();
		datosRegistrador.append(StringUtils.trimToEmpty(registrador.getNumeroRegistro()));
		datosRegistrador.append(" - ");
		datosRegistrador.append(StringUtils.trimToEmpty(registrador.getNombreCompleto()));
		datosRegistrador.append(", UUOO: ");
		datosRegistrador.append(StringUtils.trimToEmpty(registrador.getUuoo()) + " - " + StringUtils.trimToEmpty(registrador.getNombreDependencia()));
		datosRegistrador.append(", CARGO: ");
		datosRegistrador.append(solicitudDTO.getNivelRegistrador().getDescripcionNivel());
		parametrosJasper.put("P_datosRegistrador", datosRegistrador.toString());
		
		List<Map<String, Object>> listaDataJasper = solicitudDTO.getConceptoList();

		ReporteJasperBean reporteJasperBean = new ReporteJasperBean();

		reporteJasperBean.setParametros(parametrosJasper);
		reporteJasperBean.setListaDetalle(listaDataJasper);
		reporteJasperBean.setFileName("nombreArchivo");
		reporteJasperBean.setJasperName(nombreArchivoJasper);

		//ReporteArchivoBean reporteArchivoBean = ReporteJasperUtil.generarArchivoPDF(reporteJasperBean, ReporteJasperConstantes.RUTA_JASPER_VIATICOS, ReporteJasperConstantes.RUTA_PDF_VIATICOS);

		return reporteJasperBean;
	}

	/**
	 * genera el reporte de rendicion.
	 * @author Rocio Paz
	 * @param codPlanViaje : String con el codigo de plan viaje
	 * @param modoProceso : String codigo de proceso 01 o 02
	 * @see ReporteArchivoBean
	 * @return lista de mapas para el cuerpo del reporte rendicion
	 * */
	@Override
	@SuppressWarnings("unused")
	public ReporteJasperBean generarReporteRendicionViatico(String codPlanViaje, String modoProceso) throws Exception {
		
		log.debug(getClass().getName() + " Inicio del método generarReporteRendicionViatico");
		
		if (StringUtils.isBlank(codPlanViaje)) throw new IllegalArgumentException("Código de rendicion de viático no puede estar vacío");

		RendicionDTO rendicionDTO = consultaRendicionService.obtenerDatosReporteRendicion(codPlanViaje);
		PlanViajeBean planViaje = rendicionDTO.getPlanViaje();

		if (planViaje == null) throw new Exception("Rendicion de viático no existe");

		boolean esNacional = StringUtils.equals(planViaje.getTipoDestino(), ViaticoConstantes.TIPO_COMISION_NACIONAL);
		boolean esMenorIgual4h = StringUtils.equals(planViaje.getIndicadorHoras(), ViaticoConstantes.INDICADOR_HORAS_HORAS); // INDICADOR_HORAS_HORAS 1:horas, 0:dias
		boolean esTipoConfiguracionManual = StringUtils.equals(modoProceso, ViaticoConstantes.TIPO_CONFIGURACION_MANUAL);

		String nombreArchivoJasper = null;
		String EMPTY = StringUtils.EMPTY;

		// parámetros finales a enviar al jasper
		Map<String, Object> parametrosJasper = new HashMap<String, Object>();
		nombreArchivoJasper = ReporteConstantes.PLANILLA_RENDICION_VIATICO;
		Date fechaRegistroPlanilla = new Date();

		parametrosJasper.put("P_fechaRegistro", ViaticoUtil.formatDateToDateDDMMYYYY(rendicionDTO.getPlanViaje().getFechaRegistro()));
		parametrosJasper.put("P_numeroPlanilla", rendicionDTO.getPlanViaje().getCodPlanilla());
		parametrosJasper.put("P_numeroRegistroRegistrador", rendicionDTO.getRegistrador().getNumeroRegistro());
		parametrosJasper.put("P_numeroRegistro", rendicionDTO.getColaborador().getNumeroRegistro());
		parametrosJasper.put("P_nombreRegistrador", rendicionDTO.getRegistrador().getNombreCompleto());
		parametrosJasper.put("P_esTipoConfManual", esTipoConfiguracionManual);
		parametrosJasper.put("P_esTipoComisionNacional", esNacional);
		parametrosJasper.put("P_esComisionMenorIgual4Horas", esMenorIgual4h);
		parametrosJasper.put("SUBREPORT_DIR", ReporteJasperConstantes.RUTA_JASPER_VIATICOS);

		ArrayList<Map<String, Object>> listaPiePagina = new ArrayList<Map<String, Object>>();
		if (!esTipoConfiguracionManual) {
			listaPiePagina = agregarParametroComisionadoRendicion(rendicionDTO);
		}

		//parametrosJasper.put("P_listaPiePagina", new JRBeanCollectionDataSource(listaPiePagina));
		parametrosJasper.put("P_listaPiePagina", listaPiePagina);
		// Agrega la lista de detalle al reporte

		List<Map<String, Object>> listaDataJasper = obtenerCampoCabeceraReporteRendicionViatico(rendicionDTO);
		
		//Aquí solo hay un registro.
		Map<String,Object> datos = listaDataJasper.get(0);
		parametrosJasper.putAll(datos);//Lo agregamos como parámetros
		
		ArrayList<Map<String, Object>> listaDocumentoRendidoJasper = new ArrayList<Map<String, Object>>();
		Double totalizador = 0D;
		
		if (CollectionUtils.isNotEmpty(rendicionDTO.getPlanViajeRendicionList())) {
			for (PlanViajeRendicionBean comprobante : rendicionDTO.getPlanViajeRendicionList()) {
				Map<String, Object> comprobanteMap = new HashMap<String, Object>();
				comprobanteMap.put("fecha", comprobante.getFechaDocumentoFormateada());
				comprobanteMap.put("tipoComprobantePago", comprobante.getDescripcionTipoDocumento());
				comprobanteMap.put("numeroComprobantePago", comprobante.getSerie()+"-"+comprobante.getNumeroDocumento());

				if (StringUtils.isNotEmpty(comprobante.getRuc())) {
					comprobanteMap.put("ruc", StringUtils.trimToEmpty(comprobante.getRuc()));
					comprobanteMap.put("proveedor", comprobante.getNombreRazonSocial());
				} else {
					comprobanteMap.put("ruc", rendicionDTO.getColaborador().getNumeroRegistro());
					comprobanteMap.put("proveedor", rendicionDTO.getColaborador().getNombreCompleto());
				}
				totalizador =  totalizador + comprobante.getMontoTotal();
				comprobanteMap.put("conceptoGasto", comprobante.getNombreConceptoGasto());
				comprobanteMap.put("total", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, BigDecimal.valueOf(comprobante.getMontoTotal()), 2));
				listaDocumentoRendidoJasper.add(comprobanteMap);
			}
			
		}

		parametrosJasper.put("P_totalRendido",  NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, BigDecimal.valueOf(totalizador), 2));
		//parametrosJasper.put("P_listaDocumentoRendido", new JRBeanCollectionDataSource(listaDocumentoRendidoJasper));
		parametrosJasper.put("P_listaDocumentoRendido", listaDocumentoRendidoJasper);

		ArrayList<Map<String, Object>> listaDocumentoDevolucionJasper = new ArrayList<Map<String, Object>>();

		if (CollectionUtils.isNotEmpty(rendicionDTO.getPapeletaDepositoList())) {
			for (PapeletaDepositoBean papeleta : rendicionDTO.getPapeletaDepositoList()) {
				Map<String, Object> papeletaMap = new HashMap<String, Object>();
				papeletaMap.put("fecha", papeleta.getFechaVoucherFormateada());
				papeletaMap.put("tipo", "VOUCHER");
				papeletaMap.put("numero", papeleta.getNumeroOperacion());
				papeletaMap.put("banco", papeleta.getNombreBanco());
				papeletaMap.put("importe", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, papeleta.getMontoDeposito(), 2));

				listaDocumentoDevolucionJasper.add(papeletaMap);
			}
		}

		parametrosJasper.put("P_totalImporte", rendicionDTO.getMontoDepositoTotal());
		//parametrosJasper.put("P_listaDocumentoDevolucion", new JRBeanCollectionDataSource(listaDocumentoDevolucionJasper));
		parametrosJasper.put("P_listaDocumentoDevolucion", listaDocumentoDevolucionJasper);

		// Parametro lista Resumen
		parametrosJasper.put("P_otorgado", rendicionDTO.getMontoRendirTotal());
		parametrosJasper.put("P_rendido", rendicionDTO.getMontoComprobanteTotal());
		parametrosJasper.put("P_noUtilizado", rendicionDTO.getMontoNoUtilizadoTotal());
		parametrosJasper.put("P_devuelto", rendicionDTO.getMontoDevueltoTotal());
		parametrosJasper.put("P_diferencia", rendicionDTO.getMontoDiferenciaTotal());
		
		//Datos registrador
		StringBuilder datosRegistrador = new StringBuilder();
		ColaboradorViaticoBean registrador = rendicionDTO.getRegistrador();
		datosRegistrador.append(StringUtils.trimToEmpty(registrador.getNumeroRegistro()));
		datosRegistrador.append(" - ");
		datosRegistrador.append(StringUtils.trimToEmpty(registrador.getNombreCompleto()));
		datosRegistrador.append(", UUOO: ");
		datosRegistrador.append(StringUtils.trimToEmpty(registrador.getUuoo()) + " - " + StringUtils.trimToEmpty(registrador.getNombreDependencia()));
		datosRegistrador.append(", CARGO: ");
		datosRegistrador.append(rendicionDTO.getNivelRegistrador().getDescripcionNivel());
		parametrosJasper.put("P_datosRegistrador", datosRegistrador.toString());

		// parámetros jasper
		ReporteJasperBean reporteJasperBean = new ReporteJasperBean();

		reporteJasperBean.setParametros(parametrosJasper);
		reporteJasperBean.setListaDetalle(listaDocumentoRendidoJasper);
		reporteJasperBean.setFileName("nombreArchivo");
		reporteJasperBean.setJasperName(nombreArchivoJasper);
		

		return reporteJasperBean;
	}

	/**
	 * agrega data al reporte para el cuerpo del reporte.
	 * 
	 * @param rendicionDTO : DTO para los reportes de rendicion
	 * @see List<Map<String, Object>>
	 * @return lista de mapas para el cuerpo del reporte declaracaion Permanencia
	 * */
	private ArrayList<Map<String, Object>> obtenerCampoCabeceraReporteRendicionViatico(RendicionDTO rendicionDTO) {

		ArrayList<Map<String, Object>> listaCampoCabecera = new ArrayList<Map<String, Object>>();
		Map<String, Object> campoCabecera = new HashMap<String, Object>();

		campoCabecera.put("nombreColaborador", rendicionDTO.getColaborador().getNombreCompleto());
		campoCabecera.put("unidadOrganizacional", rendicionDTO.getColaborador().getUuoo() + " - " + rendicionDTO.getColaborador().getNombreDependencia());
		campoCabecera.put("destinos", rendicionDTO.getPlanViaje().getItinerario());
		campoCabecera.put("fechaProgramadaInicio", ViaticoUtil.formatDateToDateDDMMYYYY(rendicionDTO.getPlanViaje().getFecSalida()));
		campoCabecera.put("fechaProgramadaFin", ViaticoUtil.formatDateToDateDDMMYYYY(rendicionDTO.getPlanViaje().getFecRetorno()));
		campoCabecera.put("fechaEjecutadaInicio", ViaticoUtil.formatDateToDateDDMMYYYY(rendicionDTO.getPlanViaje().getFecSalidaEjecutada()));
		campoCabecera.put("fechaEjecutadaFin", ViaticoUtil.formatDateToDateDDMMYYYY(rendicionDTO.getPlanViaje().getFecRetornoEjecutada()));

		if (ViaticoConstantes.INDICADOR_HORAS_HORAS.equals(rendicionDTO.getPlanViaje().getIndicadorHoras())) {
			campoCabecera.put("numeroDia", String.valueOf(rendicionDTO.getPlanViaje().getNumeroHoras()));
		} else if (ViaticoConstantes.INDICADOR_HORAS_DIAS.equals(rendicionDTO.getPlanViaje().getIndicadorHoras())) {
			campoCabecera.put("numeroDia", String.valueOf(rendicionDTO.getPlanViaje().getNumDias()));
		}

		if (rendicionDTO.getCabeceraMov() != null) {
			if (StringUtils.isNotEmpty(rendicionDTO.getCabeceraMov().getNumeroSiafCab())) {
				campoCabecera.put("expSiaf", rendicionDTO.getCabeceraMov().getNumeroSiafCab());
			} else {
				campoCabecera.put("expSiaf", ViaticoConstantes.CADENA_VACIA);
			}

			if (StringUtils.isNotEmpty(rendicionDTO.getCabeceraMov().getNumeroNotaCab())) {
				campoCabecera.put("notaCompromiso", rendicionDTO.getCabeceraMov().getNumeroNotaCab());
			} else {
				campoCabecera.put("notaCompromiso", ViaticoConstantes.CADENA_VACIA);
			}
		} else {
			campoCabecera.put("expSiaf", ViaticoConstantes.CADENA_VACIA);
			campoCabecera.put("notaCompromiso", ViaticoConstantes.CADENA_VACIA);
		}
		listaCampoCabecera.add(campoCabecera);
		return listaCampoCabecera;
	}

	/**
	 * agrega data al reporte para el cuerpo del reporte.
	 * 
	 * @param rendicionDTO : DTO para los reportes de rendicion
	 * @see List<Map<String, Object>>
	 * @return lista de mapas para el cuerpo del reporte rendicion
	 * */
	private ArrayList<Map<String, Object>> agregarParametroComisionadoRendicion(RendicionDTO rendicionDTO) {
		ArrayList<Map<String, Object>> resultadoListaMap = new ArrayList<Map<String, Object>>();
		Map<String, Object> parametrosJasper = new HashMap<String, Object>();
		parametrosJasper.put("nombreComisionado", rendicionDTO.getColaborador().getNombreCompleto());
		parametrosJasper.put("dniComisionado", rendicionDTO.getColaborador().getDni());
		parametrosJasper.put("uuooComisionado", rendicionDTO.getColaborador().getNombreDependencia() + " - " + rendicionDTO.getColaborador().getUuoo());
		parametrosJasper.put("cargoComisionado", rendicionDTO.getNivel().getDescripcionNivel());// obtenerCargoEmpleado(comisionado.getCodigoEmpleado())
		parametrosJasper.put("diaFechaComisionado", rendicionDTO.getFechaActual());
		parametrosJasper.put("horaFechaComisionado", rendicionDTO.getHoraActual());
		resultadoListaMap.add(parametrosJasper);
		return resultadoListaMap;
	}
	

	/**
	 * genera el reporte de declaracion.
	 * 
	 * @param codPlanViaje : String con el codigo de plan viaje
	 * @param modoProceso : String codigo de proceso 01 o 02
	 * @see ReporteArchivoBean
	 * @return lista de mapas para el cuerpo del reporte declaracaion
	 * */

	@Override
	public ReporteJasperBean generarReporteRendicionDeclaracion(String codPlanViaje, String modoProceso) throws Exception {

		RendicionDTO rendicionDTO = consultaRendicionService.obtenerDatosReporteRendicion(codPlanViaje);
		PlanViajeBean planViaje = rendicionDTO.getPlanViaje();

		if (planViaje == null) throw new Exception("Rendicion de viático no existe");

		boolean esNacional = StringUtils.equals(planViaje.getTipoDestino(), ViaticoConstantes.TIPO_COMISION_NACIONAL);
		boolean esTipoConfiguracionManual = StringUtils.equals(modoProceso, ViaticoConstantes.TIPO_CONFIGURACION_MANUAL);
		String nombreArchivoJasper = null;

		// parámetros finales a enviar al jasper
		Map<String, Object> parametrosJasper = new HashMap<String, Object>();
		nombreArchivoJasper = ReporteConstantes.PLANILLA_RENDICION_DECLARACION_JURADA;
		parametrosJasper.put("P_numeroPlanilla", rendicionDTO.getPlanViaje().getCodPlanilla());
		parametrosJasper.put("P_esTipoComisionNacional", esNacional);
		parametrosJasper.put("P_total", rendicionDTO.getMontoDetalleComprobanteTotal());
		parametrosJasper.put("P_esTipoConfManual", esTipoConfiguracionManual);
		parametrosJasper.put("P_fecha", rendicionDTO.getFechaActual());

		// Map<String, Object> parametrosJasperTable = new HashMap<String, Object>();
		String cuerpo = ReporteConstantes.CUERPO_IMPRESION_DECLARACION;
		cuerpo = cuerpo.replace("p_nombreColaborador", rendicionDTO.getColaborador().getNombreCompleto().trim()).replace("p_numeroRegistro", rendicionDTO.getColaborador().getNumeroRegistro()).replace("p_numeroDNI", rendicionDTO.getColaborador().getDni())
				.replace("p_unidadOrganizacional", rendicionDTO.getColaborador().getNombreDependencia()).replace("p_ciudad", rendicionDTO.getPlanViaje().getItinerario()).replace("p_motivo", rendicionDTO.getPlanViaje().getSolicitanteViaje());
		//Siempre se muestra la fecha ejecutada...
		/*if (esNacional) {
			cuerpo = cuerpo.replace("p_fechaInicio", ViaticoUtil.formatDateToDateDDMMYYYY(rendicionDTO.getPlanViaje().getFecSalidaEjecutada())).replace("p_fechaFin", ViaticoUtil.formatDateToDateDDMMYYYY(rendicionDTO.getPlanViaje().getFecRetornoEjecutada()));
		} else {
			cuerpo = cuerpo.replace("p_fechaInicio", ViaticoUtil.formatDateToDateDDMMYYYY(rendicionDTO.getPlanViaje().getFechaItinerarioSalida())).replace("p_fechaFin", ViaticoUtil.formatDateToDateDDMMYYYY(rendicionDTO.getPlanViaje().getFechaItinerarioRetorno()));
		}*/
		cuerpo = cuerpo.replace("p_fechaInicio", ViaticoUtil.formatDateToDateDDMMYYYY(rendicionDTO.getPlanViaje().getFecSalidaEjecutada())).replace("p_fechaFin", ViaticoUtil.formatDateToDateDDMMYYYY(rendicionDTO.getPlanViaje().getFecRetornoEjecutada()));
		parametrosJasper.put("P_cuerpoImpresion", cuerpo);
		
		
		//Datos registrador
		StringBuilder datosRegistrador = new StringBuilder();
		ColaboradorViaticoBean registrador = rendicionDTO.getRegistrador();
		datosRegistrador.append(StringUtils.trimToEmpty(registrador.getNumeroRegistro()));
		datosRegistrador.append(" - ");
		datosRegistrador.append(StringUtils.trimToEmpty(registrador.getNombreCompleto()));
		datosRegistrador.append(", UUOO: ");
		datosRegistrador.append(StringUtils.trimToEmpty(registrador.getUuoo()) + " - " + StringUtils.trimToEmpty(registrador.getNombreDependencia()));
		datosRegistrador.append(", CARGO: ");
		datosRegistrador.append(rendicionDTO.getNivelRegistrador().getDescripcionNivel());
		parametrosJasper.put("P_datosRegistrador", datosRegistrador.toString());
		parametrosJasper.put("P_nombreColaborador", rendicionDTO.getColaborador().getNombreCompleto().trim());
		parametrosJasper.put("P_numeroRegistro", rendicionDTO.getColaborador().getNumeroRegistro());
		parametrosJasper.put("P_unidadOrganizacional", rendicionDTO.getColaborador().getNombreDependencia());
		
		List<Map<String, Object>> listaDataJasper = agregarParametroComisionadoRendicionDeclaracion(rendicionDTO, esNacional);// agregarParametroComisionadoRendicionDeclaracion(rendicionDTO);
		// parametrosJasper.put("P_listaDetalle", new JRBeanCollectionDataSource(agregarParametroComisionadoRendicionDeclaracion(rendicionDTO)));
		// parámetros jasper
		ReporteJasperBean reporteJasperBean = new ReporteJasperBean();

		reporteJasperBean.setParametros(parametrosJasper);
		reporteJasperBean.setListaDetalle(listaDataJasper);
		reporteJasperBean.setFileName("nombreArchivo");
		reporteJasperBean.setJasperName(nombreArchivoJasper);
		log.debug(getClass().getName() + " Inicio del método generarReporteRendicionViatico");
		// generando el archivo pdf
		//ReporteArchivoBean reporteArchivoBean = ReporteJasperUtil.generarArchivoPDF(reporteJasperBean, ReporteJasperConstantes.RUTA_JASPER_VIATICOS, ReporteJasperConstantes.RUTA_PDF_VIATICOS);

		return reporteJasperBean;

	}

	/**
	 * agrega data al reporte para el cuerpo del reporte.
	 * 
	 * @param rendicionDTO : DTO para los reportes de rendicion
	 * @see List<Map<String, Object>>
	 * @return lista de mapas para el cuerpo del reporte declaracaion
	 * */
	private List<Map<String, Object>> agregarParametroComisionadoRendicionDeclaracion(RendicionDTO rendicionDTO, boolean esNacional) {
		List<Map<String, Object>> resultadoListaMap = new ArrayList<Map<String, Object>>();
		int decimal = 2;
		for (PlanViajeInformeDistribBean planViajeInformeDistrib : rendicionDTO.getPlanViajeInformeList()) {
			Map<String, Object> parametrosJasper = new HashMap<String, Object>();
			parametrosJasper.put("fecha", ViaticoUtil.formatDateToDateDDMMYYYY(planViajeInformeDistrib.getFecViatico()));
			parametrosJasper.put("detalleGasto", planViajeInformeDistrib.getDetalleGasto());
			parametrosJasper.put("importe", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, BigDecimal.valueOf(planViajeInformeDistrib.getMtoDocumento()), decimal));
			parametrosJasper.put("moneda", planViajeInformeDistrib.getMoneda());
			resultadoListaMap.add(parametrosJasper);
		}

		// resultadoListaMap.add(parametrosJasperTable);
		return resultadoListaMap;
	}

	/**
	 * genera el reporte de declaracion de permanencia.
	 * 
	 * @param codPlanViaje : String con el codigo de plan viaje
	 * @param modoProceso : String codigo de proceso 01 o 02
	 * @see ReporteArchivoBean
	 * @return lista de mapas para el cuerpo del reporte declaracaion Permanencia
	 * */
	@Override
	public ReporteArchivoBean generarReporteRendicionDeclaracionPermanencia(String codPlanViaje, String modoProceso) throws Exception {

		RendicionDTO rendicionDTO = consultaRendicionService.obtenerDatosReporteRendicion(codPlanViaje);
		PlanViajeBean planViaje = rendicionDTO.getPlanViaje();

		if (planViaje == null) throw new Exception("Rendicion de viático no existe");

		String nombreArchivoJasper = null;

		// parámetros finales a enviar al jasper
		Map<String, Object> parametrosJasper = new HashMap<String, Object>();
		nombreArchivoJasper = ReporteConstantes.PLANILLA_RENDICION_DECLARACION_JURADA_PERMANENCIA;

		List<Map<String, Object>> listaDataJasper = agregarParametroComisionadoRendicionDeclaracionPermanencia(rendicionDTO);

		parametrosJasper.put("P_fechaActual", rendicionDTO.getFechaActual());

		ReporteJasperBean reporteJasperBean = new ReporteJasperBean();

		reporteJasperBean.setParametros(parametrosJasper);
		reporteJasperBean.setListaDetalle(listaDataJasper);
		reporteJasperBean.setFileName("nombreArchivo");
		reporteJasperBean.setJasperName(nombreArchivoJasper);
		log.debug(getClass().getName() + " Inicio del método generarReporteRendicionViatico");
		// generando el archivo pdf
		ReporteArchivoBean reporteArchivoBean = ReporteJasperUtil.generarArchivoPDF(reporteJasperBean, ReporteJasperConstantes.RUTA_JASPER_VIATICOS, ReporteJasperConstantes.RUTA_PDF_VIATICOS);

		return reporteArchivoBean;

	}

	/**
	 * agrega data al reporte para el cuerpo del reporte.
	 * 
	 * @param rendicionDTO : DTO para los reportes de rendicion
	 * @see List<Map<String, Object>>
	 * @return lista de mapas para el cuerpo del reporte declaracaion Permanencia
	 * */

	private List<Map<String, Object>> agregarParametroComisionadoRendicionDeclaracionPermanencia(RendicionDTO rendicionDTO) {
		
		String fecha = ViaticoUtil.formatDateToDateDDMMYYYY(rendicionDTO.getPlanViaje().getFecSalida());
		String dia = String.valueOf(fecha.charAt(0)) + String.valueOf(fecha.charAt(1));
		List<Map<String, Object>> resultadoListaMap = new ArrayList<Map<String, Object>>();
		SimpleDateFormat mesSimpleDateFormat = new SimpleDateFormat(FechaConstantes.DATE_FORMAT_MMMM, new Locale("ES"));
		SimpleDateFormat anioSimpleDateFormat = new SimpleDateFormat(FechaConstantes.DATE_FORMAT_YYYY, new Locale("ES"));
		Map<String, Object> parametrosJasper = new HashMap<String, Object>();
		String cuerpo = ReporteConstantes.CUERPO_IMPRESION_DECLARACION_PERMANENCIA;
		cuerpo = cuerpo.replace("p_nombreColaborador", rendicionDTO.getColaborador().getNombreCompleto().trim()).replace("p_numeroRegistro", rendicionDTO.getColaborador().getNumeroRegistro()).replace("p_numeroDNI", rendicionDTO.getColaborador().getDni())
				.replace("p_unidadOrganizacional", rendicionDTO.getColaborador().getNombreDependencia().trim()).replace("p_ciudad", rendicionDTO.getPlanViaje().getItinerario()).replace("p_motivo", rendicionDTO.getPlanViaje().getSolicitanteViaje())
				.replace("p_horas", rendicionDTO.getPlanViaje().getNumeroHoras().toString()).replace("p_fechaInicio", ViaticoUtil.formatDateToHourHHMM(rendicionDTO.getPlanViaje().getFecSalida())).replace("p_fechaFin", ViaticoUtil.formatDateToHourHHMM(rendicionDTO.getPlanViaje().getFecRetorno()))
				.replace("p_dia", dia).replace("p_mes", WordUtils.capitalizeFully(mesSimpleDateFormat.format(rendicionDTO.getPlanViaje().getFecSalida())).toUpperCase()).replace("p_anio", WordUtils.capitalizeFully(anioSimpleDateFormat.format(rendicionDTO.getPlanViaje().getFecSalida())));
		log.debug("cuerpo impresion" + cuerpo);
		parametrosJasper.put("cuerpoImpresion", cuerpo);
		resultadoListaMap.add(parametrosJasper);
		return resultadoListaMap;
	}
	
	
	/**
	 * genera el reporte de rendicion.
	 * @author Rocio Paz
	 * @param codPlanViaje : String con el codigo de plan viaje
	 * @param modoProceso : String codigo de proceso 01 o 02
	 * @see ReporteArchivoBean
	 * @return lista de mapas para el cuerpo del reporte rendicion
	 * */
	@Override
	@SuppressWarnings("unused")
	public ReporteArchivoBean generarReporteReembolsoViatico(String codPlanViaje, String modoProceso) throws Exception {
		
		log.debug(getClass().getName() + " Inicio del método generarReporteReembolsoViatico");
		
		if (StringUtils.isBlank(codPlanViaje)) throw new IllegalArgumentException("Código de reembolso de viático no puede estar vacío");

		//RendicionDTO rendicionDTO = consultaRendicionService.obtenerDatosReporteRendicion(codPlanViaje);
		ReembolsoDTO reembolsoDTO = consultaReembolsoService.obtenerDatosReporteReembolso(codPlanViaje);
		PlanViajeBean planViaje = reembolsoDTO.getPlanViajeBean();

		if (planViaje == null) throw new Exception("Reembolso de viático no existe");

		boolean esNacional = StringUtils.equals(planViaje.getTipoDestino(), ViaticoConstantes.TIPO_COMISION_NACIONAL);
		boolean esMenorIgual4h = StringUtils.equals(planViaje.getIndicadorHoras(), ViaticoConstantes.INDICADOR_HORAS_HORAS); // INDICADOR_HORAS_HORAS 1:horas, 0:dias
		boolean esTipoConfiguracionManual = StringUtils.equals(modoProceso, ViaticoConstantes.TIPO_CONFIGURACION_MANUAL);

		String nombreArchivoJasper = null;
		String EMPTY = StringUtils.EMPTY;

		// parámetros finales a enviar al jasper
		Map<String, Object> parametrosJasper = new HashMap<String, Object>();
		nombreArchivoJasper = ReporteConstantes.PLANILLA_REEMBOLSO_VIATICO;
		Date fechaRegistroPlanilla = new Date();

		parametrosJasper.put("P_fechaRegistro", ViaticoUtil.formatDateToDateDDMMYYYY(reembolsoDTO.getPlanViajeBean().getFechaRegistro()));
		parametrosJasper.put("P_numeroPlanilla", reembolsoDTO.getPlanViajeBean().getCodPlanilla());
		parametrosJasper.put("P_numeroRegistroRegistrador", reembolsoDTO.getRegistrador().getNumeroRegistro());
		parametrosJasper.put("P_numeroRegistro", reembolsoDTO.getColaborador().getNumeroRegistro());
		parametrosJasper.put("P_nombreRegistrador", reembolsoDTO.getRegistrador().getNombreCompleto());
		parametrosJasper.put("P_esTipoConfManual", esTipoConfiguracionManual);
		parametrosJasper.put("P_esTipoComisionNacional", esNacional);
		parametrosJasper.put("P_esComisionMenorIgual4Horas", esMenorIgual4h);
		parametrosJasper.put("SUBREPORT_DIR", ReporteJasperConstantes.RUTA_JASPER_VIATICOS);

		List<Map<String, Object>> listaPiePagina = new ArrayList<Map<String, Object>>();
		if (!esTipoConfiguracionManual) {
			listaPiePagina = agregarParametroComisionadoReembolso(reembolsoDTO);
		}

		parametrosJasper.put("P_listaPiePagina", new JRBeanCollectionDataSource(listaPiePagina));
		// Agrega la lista de detalle al reporte

		List<Map<String, Object>> listaDataJasper = obtenerCampoCabeceraReporteReembolsoViatico(reembolsoDTO);
		List<Map<String, Object>> listaDocumentoReembolsoJasper = new ArrayList<Map<String, Object>>();
		Double totalizador = 0D;

		if (CollectionUtils.isNotEmpty(reembolsoDTO.getPlanViajeRendicionList())) {
			for (PlanViajeRendicionBean comprobante : reembolsoDTO.getPlanViajeRendicionList()) {
				Map<String, Object> comprobanteMap = new HashMap<String, Object>();
				comprobanteMap.put("fecha", comprobante.getFechaDocumentoFormateada());
				comprobanteMap.put("tipoComprobantePago", comprobante.getDescripcionTipoDocumento());
				comprobanteMap.put("numeroComprobantePago", comprobante.getNumeroDocumento());
				comprobanteMap.put("ruc", StringUtils.trimToEmpty(comprobante.getRuc()));

				if (StringUtils.isNotEmpty(comprobante.getRuc())) {
					comprobanteMap.put("proveedor", comprobante.getNombreRazonSocial());
				} else {
					comprobanteMap.put("proveedor", ViaticoConstantes.CADENA_VACIA);
				}
				comprobanteMap.put("conceptoGasto", comprobante.getNombreConceptoGasto());
				comprobanteMap.put("total", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, BigDecimal.valueOf(comprobante.getMontoTotal()), 2));
				listaDocumentoReembolsoJasper.add(comprobanteMap);
			}
			parametrosJasper.put("P_totalReembolso", reembolsoDTO.getImporteComprobanteTotal());
			parametrosJasper.put("P_listaDocumentoReembolso", new JRBeanCollectionDataSource(listaDocumentoReembolsoJasper));
			
		}

		parametrosJasper.put("P_alimentacion", reembolsoDTO.getImporteAlimentacionTotal());
		parametrosJasper.put("P_alojamiento", reembolsoDTO.getImporteAlojamientoTotal());
		parametrosJasper.put("P_transladoTerminal", reembolsoDTO.getImporteTrasladoTotal());
		parametrosJasper.put("P_movilidadLocal", reembolsoDTO.getImporteMovilidadTotal());
		parametrosJasper.put("P_totalViatico", reembolsoDTO.getImporteTotalViatico());		
		parametrosJasper.put("P_pasaje", reembolsoDTO.getImportePasajeTotal());
		parametrosJasper.put("P_tasaEmbarque", reembolsoDTO.getImporteTasaEmbarqueTotal());
		parametrosJasper.put("P_totalOtAsignaciones", reembolsoDTO.getImporteOtrasAsignacionesTotal());
		parametrosJasper.put("P_totalGasto", reembolsoDTO.getImporteMontoTotalGasto());

		/*
		List<Map<String, Object>> listaDocumentoDevolucionJasper = new ArrayList<Map<String, Object>>();

		if (CollectionUtils.isNotEmpty(rendicionDTO.getPapeletaDepositoList())) {
			for (PapeletaDepositoBean papeleta : rendicionDTO.getPapeletaDepositoList()) {
				Map<String, Object> papeletaMap = new HashMap<String, Object>();
				papeletaMap.put("fecha", papeleta.getFechaVoucherFormateada());
				papeletaMap.put("tipo", "VAUCHER");
				papeletaMap.put("numero", papeleta.getNumeroOperacion());
				papeletaMap.put("banco", papeleta.getNombreBanco());
				papeletaMap.put("importe", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, papeleta.getMontoDeposito(), 2));

				listaDocumentoDevolucionJasper.add(papeletaMap);
			}
		}

		parametrosJasper.put("P_totalImporte", rendicionDTO.getMontoDepositoTotal());
		parametrosJasper.put("P_listaDocumentoDevolucion", new JRBeanCollectionDataSource(listaDocumentoDevolucionJasper));

		// Parametro lista Resumen
		parametrosJasper.put("P_otorgado", rendicionDTO.getMontoRendirTotal());
		parametrosJasper.put("P_rendido", rendicionDTO.getMontoComprobanteTotal());
		parametrosJasper.put("P_noUtilizado", rendicionDTO.getMontoNoUtilizadoTotal());
		parametrosJasper.put("P_devuelto", rendicionDTO.getMontoDevueltoTotal());
		parametrosJasper.put("P_diferencia", rendicionDTO.getMontoDiferenciaTotal());
*/
		// parámetros jasper
		ReporteJasperBean reporteJasperBean = new ReporteJasperBean();

		reporteJasperBean.setParametros(parametrosJasper);
		reporteJasperBean.setListaDetalle(listaDataJasper);
		reporteJasperBean.setFileName("nombreArchivo");
		reporteJasperBean.setJasperName(nombreArchivoJasper);
		log.debug(getClass().getName() + " Fin del método generarReporteReembolsoViatico");
		// generando el archivo pdf
		ReporteArchivoBean reporteArchivoBean = ReporteJasperUtil.generarArchivoPDF(reporteJasperBean, ReporteJasperConstantes.RUTA_JASPER_VIATICOS, ReporteJasperConstantes.RUTA_PDF_VIATICOS);

		return reporteArchivoBean;
	}

	
	/**
	 * agrega data al reporte para el cuerpo del reporte.
	 * 
	 * @param rendicionDTO : DTO para los reportes de rendicion
	 * @see List<Map<String, Object>>
	 * @return lista de mapas para el cuerpo del reporte rendicion
	 * */
	private List<Map<String, Object>> agregarParametroComisionadoReembolso(ReembolsoDTO reembolsoDTO) {
		List<Map<String, Object>> resultadoListaMap = new ArrayList<Map<String, Object>>();
		Map<String, Object> parametrosJasper = new HashMap<String, Object>();
		parametrosJasper.put("nombreComisionado", reembolsoDTO.getColaborador().getNombreCompleto());
		parametrosJasper.put("dniComisionado", reembolsoDTO.getColaborador().getDni());
		parametrosJasper.put("uuooComisionado",reembolsoDTO.getColaborador().getUuoo()  + " - " +reembolsoDTO.getColaborador().getNombreDependencia() );
		parametrosJasper.put("cargoComisionado", reembolsoDTO.getNivelColaborador().getDescripcionNivel());// obtenerCargoEmpleado(comisionado.getCodigoEmpleado())
		parametrosJasper.put("diaFechaComisionado", reembolsoDTO.getFechaActual());
		parametrosJasper.put("horaFechaComisionado", reembolsoDTO.getHoraActual());
		resultadoListaMap.add(parametrosJasper);
		return resultadoListaMap;
	}
	
	
	/**
	 * agrega data al reporte para el cuerpo del reporte.
	 * @author Samuel Dionisio
	 * @param rendicionDTO : DTO para los reportes de rendicion
	 * @see List<Map<String, Object>>
	 * @return lista de mapas para el cuerpo del reporte declaracaion Permanencia
	 * */
	private List<Map<String, Object>> obtenerCampoCabeceraReporteReembolsoViatico(ReembolsoDTO reembolsoDTO) {

		List<Map<String, Object>> listaCampoCabecera = new ArrayList<Map<String, Object>>();
		Map<String, Object> campoCabecera = new HashMap<String, Object>();

		campoCabecera.put("nombreColaborador", reembolsoDTO.getColaborador().getNombreCompleto());
		campoCabecera.put("unidadOrganizacional", reembolsoDTO.getColaborador().getUuoo() + " - " + reembolsoDTO.getColaborador().getNombreDependencia());
		campoCabecera.put("destinos", reembolsoDTO.getPlanViajeBean().getItinerario());
		campoCabecera.put("fechaProgramadaInicio", ViaticoUtil.formatDateToDateDDMMYYYY(reembolsoDTO.getPlanViajeBean().getFecSalida()));
		campoCabecera.put("fechaProgramadaFin", ViaticoUtil.formatDateToDateDDMMYYYY(reembolsoDTO.getPlanViajeBean().getFecRetorno()));
		campoCabecera.put("fechaEjecutadaInicio", ViaticoUtil.formatDateToDateDDMMYYYY(reembolsoDTO.getPlanViajeBean().getFecSalidaEjecutada()));
		campoCabecera.put("fechaEjecutadaFin", ViaticoUtil.formatDateToDateDDMMYYYY(reembolsoDTO.getPlanViajeBean().getFecRetornoEjecutada()));
		campoCabecera.put("totalReembolsar", NumeroUtil.formatearMonto(reembolsoDTO.getPlanViajeBean().getMoneda(), BigDecimal.valueOf(reembolsoDTO.getPlanViajeBean().getMontoTotal()), 2));
		if (ViaticoConstantes.INDICADOR_HORAS_HORAS.equals(reembolsoDTO.getPlanViajeBean().getIndicadorHoras())) {
			campoCabecera.put("totalDias", reembolsoDTO.getPlanViajeBean().getNumeroHoras());
		} else if (ViaticoConstantes.INDICADOR_HORAS_DIAS.equals(reembolsoDTO.getPlanViajeBean().getIndicadorHoras())) {
			campoCabecera.put("totalDias", reembolsoDTO.getPlanViajeBean().getNumDias());
		}

		/*if (reembolsoDTO.getCabeceraMov() != null) {
			if (StringUtils.isNotEmpty(reembolsoDTO.getCabeceraMov().getNumeroSiafCab())) {
				campoCabecera.put("expSiaf", reembolsoDTO.getCabeceraMov().getNumeroSiafCab());
			} else {
				campoCabecera.put("expSiaf", ViaticoConstantes.CADENA_VACIA);
			}

			if (StringUtils.isNotEmpty(reembolsoDTO.getCabeceraMov().getNumeroNotaCab())) {
				campoCabecera.put("notaCompromiso", reembolsoDTO.getCabeceraMov().getNumeroNotaCab());
			} else {
				campoCabecera.put("notaCompromiso", ViaticoConstantes.CADENA_VACIA);
			}
		} else {
			campoCabecera.put("expSiaf", ViaticoConstantes.CADENA_VACIA);
			campoCabecera.put("notaCompromiso", ViaticoConstantes.CADENA_VACIA);
		}*/
		listaCampoCabecera.add(campoCabecera);
		return listaCampoCabecera;
	}

	@Override
	public NivelBean getNivel(String codNivel) {
		return nivelDAO.buscarNivelViatico(codNivel);
	}
	
	
}
