package pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.SysEstadosBean;
import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.T01ParametroBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroGeneralService;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.administracion.siga.util.FechaUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.FormatoUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.NumeroUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ConceptoPlanillaViaticosBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.CuentaCorrienteBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.NivelBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeConceptoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeDestinoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.SolicitudDTO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.TipoCambioBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.CuentaCorrienteDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.NivelDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeConceptoDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeDestinoDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.TXXX8LugarUbigeoDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.TipoCambioDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.MaestroPersonalUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ReporteConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;

/**
 * La clase ConsultaSolicitudServiceImpl permite realizar consultas de solicitudes de viatico y sus tablas relacionadas.
 * 
 * @author Juan Saccatoma
 */
@SuppressWarnings("unchecked")
public class ConsultaSolicitudServiceImpl implements ConsultaSolicitudService {

	/** Declaracion del log para realizar los debug, info, error, etc. */
	protected final Log log = LogFactory.getLog(getClass());

	/** Declaracion del DAO planViajeDAO. */
	private PlanViajeDAO planViajeDAO;

	/** Declaracion del DAO planViajeDestinoDAO. */
	private PlanViajeDestinoDAO planViajeDestinoDAO;

	/** Declaracion del DAO planViajeConceptoDAO. */
	private PlanViajeConceptoDAO planViajeConceptoDAO;

	/** Declaracion del DAO tXXX8LugarUbigeoDAO. */
	private TXXX8LugarUbigeoDAO tXXX8LugarUbigeoDAO;

	/** Declaracion del DAO nivelDAO. */
	private NivelDAO nivelDAO;

	/** Declaracion del DAO tipoCambioDAO. */
	private TipoCambioDAO tipoCambioDAO;

	/** Declaracion del servicio registroGeneralService. */
	private RegistroGeneralService registroGeneralService;

	private RegistroPersonalService registroPersonalService;

	private ViaticoService viaticoService;

	private CuentaCorrienteDAO cuentaCorrienteDAO;

	public TipoCambioDAO getTipoCambioDAO() {
		return tipoCambioDAO;
	}

	public void setTipoCambioDAO(TipoCambioDAO tipoCambioDAO) {
		this.tipoCambioDAO = tipoCambioDAO;
	}

	public PlanViajeDAO getPlanViajeDAO() {
		return planViajeDAO;
	}

	public void setPlanViajeDAO(PlanViajeDAO planViajeDAO) {
		this.planViajeDAO = planViajeDAO;
	}

	public PlanViajeDestinoDAO getPlanViajeDestinoDAO() {
		return planViajeDestinoDAO;
	}

	public void setPlanViajeDestinoDAO(PlanViajeDestinoDAO planViajeDestinoDAO) {
		this.planViajeDestinoDAO = planViajeDestinoDAO;
	}

	public PlanViajeConceptoDAO getPlanViajeConceptoDAO() {
		return planViajeConceptoDAO;
	}

	public void setPlanViajeConceptoDAO(PlanViajeConceptoDAO planViajeConceptoDAO) {
		this.planViajeConceptoDAO = planViajeConceptoDAO;
	}

	public RegistroGeneralService getRegistroGeneralService() {
		return registroGeneralService;
	}

	public void setRegistroGeneralService(RegistroGeneralService registroGeneralService) {
		this.registroGeneralService = registroGeneralService;
	}

	public TXXX8LugarUbigeoDAO gettXXX8LugarUbigeoDAO() {
		return tXXX8LugarUbigeoDAO;
	}

	public void settXXX8LugarUbigeoDAO(TXXX8LugarUbigeoDAO tXXX8LugarUbigeoDAO) {
		this.tXXX8LugarUbigeoDAO = tXXX8LugarUbigeoDAO;
	}

	public NivelDAO getNivelDAO() {
		return nivelDAO;
	}

	public void setNivelDAO(NivelDAO nivelDAO) {
		this.nivelDAO = nivelDAO;
	}

	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}

	public ViaticoService getViaticoService() {
		return viaticoService;
	}

	public void setViaticoService(ViaticoService viaticoService) {
		this.viaticoService = viaticoService;
	}

	public CuentaCorrienteDAO getCuentaCorrienteDAO() {
		return cuentaCorrienteDAO;
	}

	public void setCuentaCorrienteDAO(CuentaCorrienteDAO cuentaCorrienteDAO) {
		this.cuentaCorrienteDAO = cuentaCorrienteDAO;
	}

	/**
	 * Metodo que permite obtener una solicitud de viatico.
	 * 
	 * @author Juan Farro
	 * @param parmSearch parametros de busqueda
	 * @return solicitud de viatico
	 * @throws Exception
	 * @see PlanViajeBean
	 */
	@Override
	public PlanViajeBean obtenerSolicitud(Map<String, Object> parmSearch) throws Exception {
		return planViajeDAO.getSolicitud(parmSearch);
	}

	/**
	 * Metodo que permite obtener solicitudes de viatico para la bandeja.
	 * 
	 * @author Juan Farro
	 * @param parmSearch parametros de busqueda
	 * @return lista de solicitudes
	 * @throws Exception
	 * @see PlanViajeBean
	 */
	@Override
	public List<PlanViajeBean> obtenerSolicitudesBandeja(Map<String, Object> parmSearch) throws Exception {
		return (List<PlanViajeBean>) planViajeDAO.getSolicitudesBandeja(parmSearch);
	}

	/**
	 * Metodo que permite obtener solicitudes de viatico para la bandeja de consulta, revision y alta (CUS10, CUS09 y CUS13).
	 * 
	 * @author Juan Farro
	 * @param parmSearch parametros de busqueda
	 * @return lista de solicitudes
	 * @throws Exception
	 * @see PlanViajeBean
	 */
	@Override
	public List<PlanViajeBean> obtenerSolicitudesBandejaConsultaRevisionAlta(Map<String, Object> parmSearch) throws Exception {

		List<PlanViajeBean> listaSolicitudes = (List<PlanViajeBean>) planViajeDAO.getSolicitudesBandejaConsultaRevisionAlta(parmSearch);

		return listaSolicitudes;
	}

	/**
	 * Metodo que permite obtener el detalle solicitudes de viatico.
	 * 
	 * @author Juan Farro
	 * @param parmSearch parametros de busqueda
	 * @return lista de solicitudes
	 * @throws Exception
	 * @see PlanViajeBean
	 */
	@Override
	public List<PlanViajeBean> obtenerSolicitudDetalle(Map<String, Object> parmSearch) throws Exception {
		return (List<PlanViajeBean>) planViajeDAO.getSolicitudDetalle(parmSearch);
	}

	/**
	 * Metodo que permite obtener las solicitudes de viatico para exportar en la bandeja.
	 * 
	 * @author Juan Farro
	 * @param parmSearch parametros de busqueda
	 * @return lista de solicitudes
	 * @throws Exception
	 * @see PlanViajeBean
	 */
	@Override
	public List<PlanViajeBean> obtenerSolicitudesBandejaExportar(Map<String, Object> parmSearch) throws Exception {
		return (List<PlanViajeBean>) planViajeDAO.getSolicitudesBandejaExportar(parmSearch);
	}

	
	/**
	 * Metodo que permite obtener un solicitud de viatico a partir de su codigo de solicitud.
	 * 
	 * @author Juan Farro
	 * @param codPlanViaje codigo plan de viaje
	 * @return solicitud de viatico
	 * @throws Exception
	 * @see PlanViajeBean
	 */
	@Override
	public PlanViajeBean buscarPlanViaje(String codPlanViaje) throws Exception {

		if (StringUtils.isBlank(codPlanViaje)) return null;

		return planViajeDAO.buscarPlanViaje(codPlanViaje);
	}

	/**
	 * Metodo que permite buscar los datos de un plan de viaje a partir de su codigo de planilla.
	 * 
	 * @author Juan Farro
	 * @param codPlanilla codigo de planilla de viatico
	 * @return solicitud de viatico
	 * @throws Exception
	 * @see PlanViajeBean
	 */
	@Override
	public PlanViajeBean buscarPlanViajePlanilla(String codPlanilla) throws Exception {

		if (StringUtils.isBlank(codPlanilla)) return null;

		return planViajeDAO.buscarPlanViajePlanilla(codPlanilla);
	}

	/**
	 * Metodo que permite obtener los plan de viaje destino asociados al codigo de solicitud de viatico.
	 * 
	 * @author Juan Farro
	 * @param codPlanViaje codigo de solicitud de viatico
	 * @return lista de plan de viaje destino
	 * @throws Exception
	 * @see PlanViajeDestinoBean
	 */
	@Override
	public List<PlanViajeDestinoBean> buscarPlanViajeDestinos(String codPlanViaje) throws Exception {
		return planViajeDestinoDAO.buscarPlanViajeDestinos(codPlanViaje);
	}

	/**
	 * Metodo que permite buscar plan viaje conceptos asociados a una solicitud de viatico.
	 * 
	 * @author Juan Farro
	 * @param codPlanViaje codigo de solicitud de viatico
	 * @return lista de plan de viaje conceptos
	 * @throws Exception
	 * @see PlanViajeConceptoBean
	 */
	@Override
	public List<PlanViajeConceptoBean> buscarPlanViajeConceptos(String codPlanViaje) throws Exception {
		return planViajeConceptoDAO.buscarPlanViajeConceptos(codPlanViaje);
	}

	/**
	 * Metodo que permite buscar solicitudes de viaticos para un colaborador que se traslapen con las fechas especificadas en los parametros.
	 * 
	 * @author Juan Farro
	 * @param codColaborador codigo de colaborador
	 * @param fechaSalida fecha inicio para busqueda de traslape de fechas
	 * @param fechaRetorno fecha fin para la busqueda de traslape de fechas
	 * @return lista de solicitudes del colaborador que tienen fechas traslapadas
	 * @throws Exception
	 * @see PlanViajeBean
	 */
	@Override
	public List<PlanViajeBean> buscarTraslapeFechas(String codColaborador, Date fechaSalida, Date fechaRetorno) throws Exception {

		return planViajeDAO.buscarTraslapeFechas(codColaborador, fechaSalida, fechaRetorno);
	}

	/**
	 * Metodo que permite buscar solicitudes de viaticos (diferente a la especificado en el parametro) para un colaborador que se traslapen con las fechas especificadas.
	 * 
	 * @author Juan Farro
	 * @param codColaborador codigo de colaborador
	 * @param fechaSalida fecha de inicio para la busqueda de traslape de fechas
	 * @param fechaRetorno fecha fin para la busqueda de traslape de fechas
	 * @param codPlanViaje codigo de plan de viaje a excluir en la busqueda
	 * @return lista de solicitudes del colaborador que tienen fechas traslapadas
	 * @throws Exception
	 * @see PlanViajeBean
	 */
	@Override
	public List<PlanViajeBean> buscarTraslapeFechas(String codColaborador, Date fechaSalida, Date fechaRetorno, String codPlanViaje) throws Exception {

		return planViajeDAO.buscarTraslapeFechas(codColaborador, fechaSalida, fechaRetorno, codPlanViaje);
	}

	/**
	 * Metodo que permite buscar la descripcion de un parametro (t01parametro).
	 * 
	 * @author Juan Farro
	 * @param codigoParametro codigo de parametro
	 * @param codigoArgumento codigo de argumento
	 * @return descripcion del parametro
	 * @throws Exception
	 */
	@Override
	public String obtenerDescripcionParametro(String codigoParametro, String codigoArgumento) throws Exception {

		// Wrapper del servicio registroGeneralService, para recuperar parametros de la tabla t01parametro
		if (StringUtils.isBlank(codigoParametro) || StringUtils.isBlank(codigoArgumento)) return StringUtils.EMPTY;

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("cod_par", codigoParametro);
		params.put("cod_tipo", ViaticoConstantes.DETALLE);
		params.put("cod_arg", codigoArgumento);

		List<T01ParametroBean> listaCanales = (List<T01ParametroBean>) registroGeneralService.recuperarParametroLista(params);

		if (CollectionUtils.isNotEmpty(listaCanales)) {
			return StringUtils.trimToEmpty(listaCanales.get(0).getDesc_abrv());
		}

		return StringUtils.EMPTY;
	}

	/**
	 * Metodo que permite buscar la descripcion de un estado (sys_estados).
	 * 
	 * @author Juan Farro
	 * @param nombreTabla nombre de tabla
	 * @param valorEstado valor estado
	 * @return descripcion del estado
	 * @throws Exception
	 */
	@Override
	public String obtenerDescripcionSysEstado(String nombreTabla, String valorEstado) throws Exception {

		// Wrapper del servicio registroGeneralService, para recuperar parametros de la tabla sys_estados
		if (StringUtils.isBlank(nombreTabla) || StringUtils.isBlank(valorEstado)) return StringUtils.EMPTY;

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("nom_tabla", nombreTabla);

		// el servicio trae todos los estados, no tiene un filtro por un codigo de estado
		List<SysEstadosBean> listaEstados = (List<SysEstadosBean>) registroGeneralService.listarEstados(params);

		if (CollectionUtils.isNotEmpty(listaEstados)) {

			String valorEstadoTrim = StringUtils.trimToEmpty(valorEstado);

			for (SysEstadosBean itemEstado : listaEstados) {

				if (itemEstado == null) continue;

				if (valorEstadoTrim.equals(StringUtils.trimToEmpty(itemEstado.getVal_estado()))) {

					return StringUtils.trimToEmpty(itemEstado.getDesc_estado());
				}

			}

		}

		return StringUtils.EMPTY;
	}

	/**
	 * Metodo que permite buscar los estados de una solicitud de viatico (t01parametro).
	 * 
	 * @author Juan Farro
	 * @return lista de estados de solicitud de viatico
	 * @throws Exception
	 */
	@Override
	public List<SysEstadosBean> obtenerListaEstadosSolicitudViatico() throws Exception {

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("nom_tabla", ViaticoConstantes.ESTADO_VIATICO_NOMBRE_TABLA);

		List<SysEstadosBean> listaEstados = (List<SysEstadosBean>) registroGeneralService.listarEstados(params);

		return listaEstados;
	}

	/**
	 * Metodo que permite buscar los canales de atencion de una solicitud de viatico (t01parametro).
	 * 
	 * @author Juan Farro
	 * @return canales de atencion
	 * @throws Exception
	 */
	@Override
	public List<T01ParametroBean> obtenerListaCanalesAtencionViatico() throws Exception {

		// catalogo canal de atencion
		Map<String, Object> params = new HashMap<String, Object>();

		params.put("cod_par", ViaticoConstantes.CANAL_ATENCION_CODIGO_PARAMETRO);
		params.put("cod_tipo", ViaticoConstantes.DETALLE);

		ArrayList<T01ParametroBean> listaCanalAtencion = (ArrayList<T01ParametroBean>) registroGeneralService.recuperarParametroLista(params);

		return listaCanalAtencion;
	}

	/**
	 * Metodo que permite buscar los tipos de comision de un viatico
	 * 
	 * @author Juan Farro
	 * @return tipos de comision de viatico
	 * @throws Exception
	 */
	@Override
	public List<T01ParametroBean> obtenerListaTiposComisionViatico() throws Exception {

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("cod_par", ViaticoConstantes.TIPO_COMISION_CODIGO_PARAMETRO);
		params.put("cod_tipo", ViaticoConstantes.DETALLE);

		ArrayList<T01ParametroBean> listaTipoViatico = (ArrayList<T01ParametroBean>) registroGeneralService.recuperarParametroLista(params);

		return listaTipoViatico;
	}

	/**
	 * Metodo que permite obtener el listado de detalle de los planes de viaje que se muestran la bandeja de solicitud.
	 * 
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @param codigoDependencia :codigo de dependencia.
	 * @param codPlanilla :codigo de planilla.
	 * @param codTrabajador :codigo del colaborador.
	 * @param codEstadoSolic :codigo de estado de la solicitud.
	 * @param indicadorCanalAtencion :indicador canal de atencion.
	 * @param fechaDesde :fecha desde.
	 * @param fechaHasta :fecha hasta.
	 * @param codigoAutorizador :codigo del autorizador.
	 * @return Objeto PlanViajeBean.
	 * @see PlanViajeBean
	 * @throws Exception
	 */
	public ArrayList<PlanViajeBean> obtenerPlanViajeDetalleToBandejaSolicitud(String codPlanViaje, String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoSolic, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws Exception {

		ArrayList<PlanViajeBean> planViajeList = planViajeDAO.obtenerPlanViajeDetalleToBandejaSolicitud(codPlanViaje, codigoDependencia, codPlanilla, codTrabajador, codEstadoSolic, indicadorCanalAtencion, fechaDesde, fechaHasta, codigoAutorizador);
		ArrayList<PlanViajeBean> planViajeListAux = null;
		if (planViajeList != null && !planViajeList.isEmpty()) {
			planViajeListAux = new ArrayList<PlanViajeBean>();
			for (PlanViajeBean planViajeBean : planViajeList) {
				BigDecimal montoAsignadoViaticos = BigDecimal.ZERO;
				BigDecimal montoAsignadoPasajes = BigDecimal.ZERO;
				BigDecimal montoOtros = BigDecimal.ZERO;
				BigDecimal montoOtorgadoTotal = BigDecimal.ZERO;
				PlanViajeBean planViajeBeanAux = new PlanViajeBean();
				planViajeBeanAux.setCodPlanViaje(planViajeBean.getCodPlanViaje());
				planViajeBeanAux.setCodPlanilla(planViajeBean.getCodPlanilla());
				planViajeBeanAux.setNomColaborador(FormatoUtil.getUppperCaseText(planViajeBean.getNomColaborador()));
				planViajeBeanAux.setNomUuOoCom(FormatoUtil.getUppperCaseText(planViajeBean.getNomUuOoCom()));
				planViajeBeanAux.setItinerario(planViajeBean.getItinerario());
				planViajeBeanAux.setFecSalidaFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecSalida()));
				planViajeBeanAux.setFecRetornoFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecRetorno()));
				planViajeBeanAux.setNumDias(planViajeBean.getNumDias());
				planViajeBeanAux.setNumeroHoras(planViajeBean.getNumeroHoras());
				planViajeBeanAux.setMotivoComis(FormatoUtil.getUppperCaseText(planViajeBean.getMotivoComis()));
				planViajeBeanAux.setNomAutorizador(FormatoUtil.getUppperCaseText(planViajeBean.getNomAutorizador()));
				planViajeBeanAux.setNomRegistrador(FormatoUtil.getUppperCaseText(planViajeBean.getNomRegistrador()));
				planViajeBeanAux.setImpAsigViaticoFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getImpAsigViatico(), 2));
				planViajeBeanAux.setImpAsigPasajesFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getImpAsigPasajes(), 2));
				planViajeBeanAux.setImpTotalOtorgadoFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getImpTotalOtorgado(), 2));
				if (planViajeBean.getImpAsigViatico() != null) {
					montoAsignadoViaticos = new BigDecimal(planViajeBean.getImpAsigViatico());
				}
				if (planViajeBean.getImpAsigPasajes() != null) {
					montoAsignadoPasajes = new BigDecimal(planViajeBean.getImpAsigPasajes());
				}
				if (planViajeBean.getImpTotalOtorgado() != null) {
					montoOtorgadoTotal = new BigDecimal(planViajeBean.getImpTotalOtorgado());
				}
				montoOtros = montoOtorgadoTotal.subtract(montoAsignadoViaticos).subtract(montoAsignadoPasajes);
				planViajeBeanAux.setImpOtrosFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), montoOtros, 2));
				planViajeBeanAux.setMedioPago(FormatoUtil.getUppperCaseText(planViajeBean.getMedioPago()));
				planViajeBeanAux.setNumReciboProv(FormatoUtil.getUppperCaseText(planViajeBean.getNumReciboProv()));
				planViajeBeanAux.setFecPagoCajaChFormateado(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecPagoCajaCh()));
				planViajeListAux.add(planViajeBeanAux);
			}
		}
		return planViajeListAux;
	}

	//JMCR-ME BANDEJA AUTORIZADOR se cambia el estado de la solicitud por una lista de estados  a enviar con "IN"
	public ArrayList<PlanViajeBean> obtenerPlanViajeDetalleToBandejaSolicitudMiltiplesEstados(String codPlanViaje, String codigoDependencia, String codPlanilla, String codTrabajador, List<String> listCodEstadoSolic, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws Exception {

		log.debug("CODIGO DE AUTORIZADOR EN obtenerPlanViajeDetalleToBandejaSolicitudMiltiplesEstados del service: " + codigoAutorizador);
		
		ArrayList<PlanViajeBean> planViajeList = planViajeDAO.obtenerPlanViajeDetalleToBandejaSolicitudMultiplesEstados(codPlanViaje, codigoDependencia, codPlanilla, codTrabajador, listCodEstadoSolic, indicadorCanalAtencion, fechaDesde, fechaHasta, codigoAutorizador);
		ArrayList<PlanViajeBean> planViajeListAux = null;
		if (planViajeList != null && !planViajeList.isEmpty()) {
			planViajeListAux = new ArrayList<PlanViajeBean>();
			for (PlanViajeBean planViajeBean : planViajeList) {
				BigDecimal montoAsignadoViaticos = BigDecimal.ZERO;
				BigDecimal montoAsignadoPasajes = BigDecimal.ZERO;
				BigDecimal montoOtros = BigDecimal.ZERO;
				BigDecimal montoOtorgadoTotal = BigDecimal.ZERO;
				PlanViajeBean planViajeBeanAux = new PlanViajeBean();
				planViajeBeanAux.setCodPlanViaje(planViajeBean.getCodPlanViaje());
				planViajeBeanAux.setCodPlanilla(planViajeBean.getCodPlanilla());
				planViajeBeanAux.setNomColaborador(FormatoUtil.getUppperCaseText(planViajeBean.getNomColaborador()));
				planViajeBeanAux.setNomUuOoCom(FormatoUtil.getUppperCaseText(planViajeBean.getNomUuOoCom()));
				planViajeBeanAux.setItinerario(planViajeBean.getItinerario());
				planViajeBeanAux.setFecSalidaFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecSalida()));
				planViajeBeanAux.setFecRetornoFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecRetorno()));
				planViajeBeanAux.setNumDias(planViajeBean.getNumDias());
				planViajeBeanAux.setNumeroHoras(planViajeBean.getNumeroHoras());
				planViajeBeanAux.setMotivoComis(FormatoUtil.getUppperCaseText(planViajeBean.getMotivoComis()));
				planViajeBeanAux.setNomAutorizador(FormatoUtil.getUppperCaseText(planViajeBean.getNomAutorizador()));
				planViajeBeanAux.setNomRegistrador(FormatoUtil.getUppperCaseText(planViajeBean.getNomRegistrador()));
				planViajeBeanAux.setImpAsigViaticoFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getImpAsigViatico(), 2));
				planViajeBeanAux.setImpAsigPasajesFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getImpAsigPasajes(), 2));
				planViajeBeanAux.setImpTotalOtorgadoFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getImpTotalOtorgado(), 2));
				if (planViajeBean.getImpAsigViatico() != null) {
					montoAsignadoViaticos = new BigDecimal(planViajeBean.getImpAsigViatico());
				}
				if (planViajeBean.getImpAsigPasajes() != null) {
					montoAsignadoPasajes = new BigDecimal(planViajeBean.getImpAsigPasajes());
				}
				if (planViajeBean.getImpTotalOtorgado() != null) {
					montoOtorgadoTotal = new BigDecimal(planViajeBean.getImpTotalOtorgado());
				}
				montoOtros = montoOtorgadoTotal.subtract(montoAsignadoViaticos).subtract(montoAsignadoPasajes);
				planViajeBeanAux.setImpOtrosFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), montoOtros, 2));
				planViajeBeanAux.setMedioPago(FormatoUtil.getUppperCaseText(planViajeBean.getMedioPago()));
				planViajeBeanAux.setNumReciboProv(FormatoUtil.getUppperCaseText(planViajeBean.getNumReciboProv()));
				planViajeBeanAux.setFecPagoCajaChFormateado(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecPagoCajaCh()));
				planViajeListAux.add(planViajeBeanAux);
			}
		}
		return planViajeListAux;
	}
	//JMCR-ME BANDEJA AUTORIZADOR se cambia el estado de la solicitud por una lista de estados  a enviar con "IN"

	/**
	 * Buscar un nivel de viatico por su codigo.
	 * 
	 * @author Juan Farro
	 * @param codigoNivel codigo nivel
	 * @return nivel
	 * @throws Exception
	 * @see NivelBean
	 */
	@Override
	public NivelBean buscarNivelViatico(String codigoNivel) throws Exception {

		if (StringUtils.isBlank(codigoNivel)) return null;

		NivelBean nivel = nivelDAO.buscarNivelViatico(codigoNivel);

		return nivel;
	}

	/**
	 * Metodo que permite obtener el tipo de cambio (moneda dolares a soles) con la fecha actual.
	 * 
	 * @author Juan Farro
	 * @return tipo de cambio
	 * @throws Exception
	 * @see TipoCambioBean
	 */
	@Override
	public TipoCambioBean obtenerTipoCambioSimboloDolaresHoy() throws Exception {

		TipoCambioBean tipoCambio = tipoCambioDAO.obtenerTipoCambioSimboloDolaresHoy();

		return tipoCambio;
	}

	/**
	 * Metodo que permite obtener el tipo de cambio (moneda dolares a soles) con fecha mas reciente.
	 * 
	 * @author Juan Farro
	 * @return tipo de cambio
	 * @throws Exception
	 * @see TipoCambioBean
	 */
	@Override
	public TipoCambioBean obtenerTipoCambioSimboloDolaresMasReciente() throws Exception {

		TipoCambioBean tipoCambio = tipoCambioDAO.obtenerTipoCambioSimboloDolaresMasReciente();

		return tipoCambio;
	}

	@Override
	public SolicitudDTO obtenerDatosReporteSolicitud(String codPlanViaje) throws Exception {

		SolicitudDTO solicitudDTO = new SolicitudDTO();

		if (StringUtils.isNotEmpty(codPlanViaje)) {

			PlanViajeBean planViaje = planViajeDAO.obtenerPlanViajeToSolicitud(codPlanViaje);

			if (planViaje != null) {

				solicitudDTO.setPlanViajeBean(planViaje);

				String codigoColaborador = planViaje.getCodTrabajador();
				if (StringUtils.isNotBlank(codigoColaborador)) {
					MaestroPersonalBean colaborador = registroPersonalService.obtenerPersonaxCodigo(codigoColaborador);
					solicitudDTO.setColaborador(MaestroPersonalUtil.parseViatico(colaborador));
				}

				String codigoRegistrador = planViaje.getCodigoRegistrador();
				if (StringUtils.isNotBlank(codigoRegistrador)) {
					MaestroPersonalBean registrador = registroPersonalService.obtenerPersonaxCodigo(codigoRegistrador);
					solicitudDTO.setRegistrador(MaestroPersonalUtil.parseViatico(registrador));
				}

				String codigoAutorizador = planViaje.getCodPerAutoriza();
				if (StringUtils.isNotBlank(codigoRegistrador)) {
					MaestroPersonalBean autorizador = registroPersonalService.obtenerPersonaxCodigo(codigoAutorizador);
					solicitudDTO.setAutorizador(MaestroPersonalUtil.parseViatico(autorizador));
				}

				String codigoNivelColaborador = solicitudDTO.getColaborador().getCodigoNivel();
				if (StringUtils.isNotBlank(codigoNivelColaborador)) {
					NivelBean nivel = nivelDAO.buscarNivelViatico(codigoNivelColaborador);
					solicitudDTO.setNivelColaborador(nivel);
				}

				String codigoNivelAutorizador = solicitudDTO.getAutorizador().getCodigoNivel();
				if (!StringUtils.isEmpty(codigoNivelAutorizador)) {
					NivelBean nivel = nivelDAO.buscarNivelViatico(codigoNivelAutorizador);
					solicitudDTO.setNivelAutorizador(nivel);
				}
				
				String codigoNivelRegistrador = solicitudDTO.getRegistrador().getCodigoNivel();
				if (StringUtils.isNotBlank(codigoNivelRegistrador)) {
					NivelBean nivel = nivelDAO.buscarNivelViatico(codigoNivelRegistrador);
					solicitudDTO.setNivelRegistrador(nivel);
				}

				Map<String, Object> conceptoMap = new HashMap<String, Object>();
				List<Map<String, Object>> conceptoList = new ArrayList<Map<String, Object>>();

				List<PlanViajeConceptoBean> listaPlanViajeConcepto = planViajeConceptoDAO.buscarPlanViajeConceptos(codPlanViaje);
				Double montoTotalConcepto = 0D;

				if (CollectionUtils.isNotEmpty(listaPlanViajeConcepto)) {

					if (ViaticoConstantes.TIPO_COMISION_NACIONAL.equals(planViaje.getTipoDestino())) {

						
						List<PlanViajeDestinoBean> listaPlanViajeDestino = planViajeDestinoDAO.buscarPlanViajeDestinos(codPlanViaje);
						
						List<CuentaCorrienteBean> cuentas = cuentaCorrienteDAO.obtenerCuentasCorriente(ViaticoConstantes.MONEDA_SOLES);
						
						if (CollectionUtils.isNotEmpty(cuentas)) {
							solicitudDTO.setCuenta(cuentas.get(0));
						}

						if (CollectionUtils.isNotEmpty(listaPlanViajeDestino)) {

							// viaticos
							Double diaViatico = 0D;
							Double montoViaticoTotal = 0D;
							Double diaViaticoTotal = 0D;

							for (PlanViajeDestinoBean planViajeDestino : listaPlanViajeDestino) {
								diaViatico = planViajeDestino.getDias();
								montoViaticoTotal += planViajeDestino.getMontoDiario() * diaViatico;
								diaViaticoTotal += diaViatico;
							}
							
							conceptoMap = new HashMap<String, Object>();
							conceptoMap.put("concepto", ViaticoConstantes.MODULO_VIATICOS);
							conceptoMap.put("numDia", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(diaViaticoTotal), 0));
							conceptoMap.put("asignacionDiaria", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(montoViaticoTotal / diaViaticoTotal), 2));
							conceptoMap.put("mtoImporte", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(montoViaticoTotal), 2));
							conceptoList.add(conceptoMap);

							montoTotalConcepto = montoTotalConcepto + montoViaticoTotal;

						}
						
						Double sumaPasaje = 0D;
						Double sumaTUUA = 0D;
						for (PlanViajeConceptoBean planViajeConcepto : listaPlanViajeConcepto) {
							ConceptoPlanillaViaticosBean conceptoPlanillaViatico = viaticoService.obtenerConceptoViatico(StringUtils.trimToEmpty(planViajeConcepto.getConceptoID()));
													
							if(conceptoPlanillaViatico != null){
								if(StringUtils.isNotEmpty(conceptoPlanillaViatico.getIndTipo()) && StringUtils.isNotEmpty(conceptoPlanillaViatico.getTipoFijoPVI())) {
									boolean igualTipoPVIVariable = ViaticoConstantes.CONCEPTO_VIATICO_TIPO_FIJ_PVI_VARIABLE.equals(conceptoPlanillaViatico.getTipoFijoPVI());
									Double asignacionDiaria = planViajeConcepto.getMonto();
									
									boolean igualIndTipoPasaje = ViaticoConstantes.CONCEPTO_INDICADOR_PASAJE.equals(conceptoPlanillaViatico.getIndTipo());
										if(igualTipoPVIVariable && igualIndTipoPasaje){
											Double numeroDia = planViajeConcepto.getCantidad();
											double montoImporte = asignacionDiaria * numeroDia;
											sumaPasaje = sumaPasaje + montoImporte;
										}
										
									boolean igualIndTipoTUUA = ViaticoConstantes.CONCEPTO_INDICADOR_TUUA.equals(conceptoPlanillaViatico.getIndTipo());
										if(igualTipoPVIVariable && igualIndTipoTUUA){
											Double numeroDia = planViajeConcepto.getCantidad();
											double montoImporte = asignacionDiaria * numeroDia;
											sumaTUUA = sumaTUUA + montoImporte;
										}
								}
							}
						}
						
						montoTotalConcepto += sumaTUUA + sumaPasaje;
						
						String campoNumeroDia = ReporteConstantes.CAMPO_VACIO;
						
						if(sumaPasaje>0){
							conceptoMap = new HashMap<String, Object>();
							conceptoMap.put("concepto", "PASAJE");
							conceptoMap.put("numDia", campoNumeroDia);
							conceptoMap.put("asignacionDiaria",campoNumeroDia);
							conceptoMap.put("mtoImporte", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(sumaPasaje), 2));
							conceptoList.add(conceptoMap);	
						}
						
						if(sumaTUUA>0){
							conceptoMap = new HashMap<String, Object>();
							conceptoMap.put("concepto", "TUUA");
							conceptoMap.put("numDia", campoNumeroDia);
							conceptoMap.put("asignacionDiaria", campoNumeroDia);
							conceptoMap.put("mtoImporte", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(sumaTUUA), 2));	
							conceptoList.add(conceptoMap);	
						}

					} else if (ViaticoConstantes.TIPO_COMISION_INTERNACIONAL.equals(planViaje.getTipoDestino())) {

						List<PlanViajeDestinoBean> listaPlanViajeDestino = planViajeDestinoDAO.buscarPlanViajeDestinos(codPlanViaje);
						
						List<CuentaCorrienteBean> cuentas = cuentaCorrienteDAO.obtenerCuentasCorriente(ViaticoConstantes.MONEDA_DOLARES);
						
						if (CollectionUtils.isNotEmpty(cuentas)) {
							solicitudDTO.setCuenta(cuentas.get(0));
						}

						if (CollectionUtils.isNotEmpty(listaPlanViajeDestino)) {

							// viaticos
							Double diaViatico = 0D;
							Double montoViaticoTotal = 0D;
							Double diaViaticoTotal = 0D;

							for (PlanViajeDestinoBean planViajeDestino : listaPlanViajeDestino) {
								diaViatico = planViajeDestino.getDias();
								montoViaticoTotal += planViajeDestino.getMontoDiario() * diaViatico;
								diaViaticoTotal += diaViatico;
							}
							
							conceptoMap = new HashMap<String, Object>();
							conceptoMap.put("concepto", ViaticoConstantes.MODULO_VIATICOS);
							conceptoMap.put("numDia", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(diaViaticoTotal), 0));
							
							conceptoMap.put("asignacionDiaria", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(montoViaticoTotal / diaViaticoTotal), 2));
							conceptoMap.put("mtoImporte", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(montoViaticoTotal), 2));
							conceptoList.add(conceptoMap);

							montoTotalConcepto = montoTotalConcepto + montoViaticoTotal;
							
							// gasto instalacion
							Integer diaTraslado = 0;
							Double montoTrasladoTotal = 0D;
							Double diaTrasladoTotal = 0D;
							
							for (PlanViajeDestinoBean planViajeDestino : listaPlanViajeDestino) {
								diaTraslado = planViajeDestino.getDiasExtra();
								montoTrasladoTotal += planViajeDestino.getMontoTraslado() * diaTraslado;
								diaTrasladoTotal += diaTraslado;
							}
							
							conceptoMap = new HashMap<String, Object>();
							conceptoMap.put("concepto", ViaticoConstantes.GASTO_INSTACION_TRASLADO);
							conceptoMap.put("numDia", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(diaTrasladoTotal), 0));
							Double monto = 0D;
							if(diaTrasladoTotal != 0D)
								monto = montoTrasladoTotal / diaTrasladoTotal;
							
							
							conceptoMap.put("asignacionDiaria", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(monto), 2));							
							conceptoMap.put("mtoImporte", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(montoTrasladoTotal), 2));
							
							
							montoTotalConcepto = montoTotalConcepto + montoTrasladoTotal;
							conceptoList.add(conceptoMap);
						}
						
						Double sumaPasaje = 0D;
						Double sumaTUUA = 0D;
						for (PlanViajeConceptoBean planViajeConcepto : listaPlanViajeConcepto) {
							ConceptoPlanillaViaticosBean conceptoPlanillaViatico = viaticoService.obtenerConceptoViatico(StringUtils.trimToEmpty(planViajeConcepto.getConceptoID()));
													
							if(conceptoPlanillaViatico != null){
								if(StringUtils.isNotEmpty(conceptoPlanillaViatico.getIndTipo()) && StringUtils.isNotEmpty(conceptoPlanillaViatico.getTipoFijoPVI())) {
									boolean igualTipoPVIVariable = ViaticoConstantes.CONCEPTO_VIATICO_TIPO_FIJ_PVI_VARIABLE.equals(conceptoPlanillaViatico.getTipoFijoPVI());
									Double asignacionDiaria = planViajeConcepto.getMonto();
									
									boolean igualIndTipoPasaje = ViaticoConstantes.CONCEPTO_INDICADOR_PASAJE.equals(conceptoPlanillaViatico.getIndTipo());
										if(igualTipoPVIVariable && igualIndTipoPasaje){
											Double numeroDia = planViajeConcepto.getCantidad();
											double montoImporte = asignacionDiaria * numeroDia;
											sumaPasaje = sumaPasaje + montoImporte;
										}
										
									boolean igualIndTipoTUUA = ViaticoConstantes.CONCEPTO_INDICADOR_TUUA.equals(conceptoPlanillaViatico.getIndTipo());
										if(igualTipoPVIVariable && igualIndTipoTUUA){
											Double numeroDia = planViajeConcepto.getCantidad();
											double montoImporte = asignacionDiaria * numeroDia;
											sumaTUUA = sumaTUUA + montoImporte;
										}
								}
							}
						}
						
						montoTotalConcepto += sumaTUUA + sumaPasaje;
						
						String campoNumeroDia = ReporteConstantes.CAMPO_VACIO;
						if(sumaPasaje>0){
							conceptoMap = new HashMap<String, Object>();
							conceptoMap.put("concepto", "PASAJE");
							conceptoMap.put("numDia", campoNumeroDia);
							conceptoMap.put("asignacionDiaria",campoNumeroDia);
							conceptoMap.put("mtoImporte", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(sumaPasaje), 2));
							conceptoList.add(conceptoMap);	
						}
						
						if(sumaTUUA>0){
							conceptoMap = new HashMap<String, Object>();
							conceptoMap.put("concepto", "TUUA");
							conceptoMap.put("numDia", campoNumeroDia);
							conceptoMap.put("asignacionDiaria", campoNumeroDia);
							conceptoMap.put("mtoImporte", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(sumaTUUA), 2));	
							conceptoList.add(conceptoMap);	
						}
						
					}
				}

				solicitudDTO.setMontoTotalConcepto(NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(montoTotalConcepto), 2));
				solicitudDTO.setConceptoList(conceptoList);
			}

		}

		return solicitudDTO;
	}

	@Override
	public Map<String, String> obtenerUUOOAutorizadora(String codDependencia,
			String codEmpleado, String indProceso) throws Exception {
		return planViajeDAO.obtenerUUOOAutorizadora(codDependencia, codEmpleado, indProceso);
	}

	@Override
	public Map<String, String> validarRevisionPreviaOSA(String idPlanilla)
			throws Exception {
		// TODO Auto-generated method stub
		return planViajeDAO.validarRevisionPreviaOSA(idPlanilla);
	}
	
}