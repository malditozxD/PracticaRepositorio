package pe.gob.sunat.recurso2.financiera.siga.viatico.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.PrgAnnoBean;
import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.T01ParametroBean;
import pe.gob.sunat.recurso2.administracion.siga.parametro.model.dao.PrgAnnoDAO;
import pe.gob.sunat.recurso2.administracion.siga.parametro.model.dao.T01ParametroDAO;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroContratistasBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.administracion.siga.util.FormatoConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.CuentaCorrienteBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.LicenciaBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ClaveValorBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.MetasBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeRendicionBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.RutaTipoTarifaBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.TXXX8LugarUbigeoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.TipoDocumentoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.VacacionBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.CuentaCorrienteDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.LicenciaDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.MetasDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeRendicionDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.RegistradorViaticoDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.TXXX8LugarUbigeoDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.TipoDocumentoDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.VacacionDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;

@SuppressWarnings("unchecked")
public class ViaticoGeneralServiceImpl implements ViaticoGeneralService {

	protected final Log log = LogFactory.getLog(getClass());
	private RegistradorViaticoDAO registradorViaticoDAO;
	private PrgAnnoDAO prgAnnoDao;
	private TXXX8LugarUbigeoDAO tXXX8LugarUbigeoDAO;
	private MetasDAO metasDAO;
	private LicenciaDAO licenciaDAO;
	private VacacionDAO vacacionDAO;
	private T01ParametroDAO t01ParametroDAO;
	private CuentaCorrienteDAO cuentaCorrienteDAO;
	private TipoDocumentoDAO tipoDocumentoDAO;
	private PlanViajeRendicionDAO planViajeRendicionDAO;
	private RegistroPersonalService registroPersonalService;

	public RegistradorViaticoDAO getRegistradorViaticoDAO() {
		return registradorViaticoDAO;
	}

	public void setRegistradorViaticoDAO(RegistradorViaticoDAO registradorViaticoDAO) {
		this.registradorViaticoDAO = registradorViaticoDAO;
	}

	public PrgAnnoDAO getPrgAnnoDao() {
		return prgAnnoDao;
	}

	public void setPrgAnnoDao(PrgAnnoDAO prgAnnoDao) {
		this.prgAnnoDao = prgAnnoDao;
	}

	public TXXX8LugarUbigeoDAO gettXXX8LugarUbigeoDAO() {
		return tXXX8LugarUbigeoDAO;
	}

	public void settXXX8LugarUbigeoDAO(TXXX8LugarUbigeoDAO tXXX8LugarUbigeoDAO) {
		this.tXXX8LugarUbigeoDAO = tXXX8LugarUbigeoDAO;
	}

	public MetasDAO getMetasDAO() {
		return metasDAO;
	}

	public void setMetasDAO(MetasDAO metasDAO) {
		this.metasDAO = metasDAO;
	}

	public LicenciaDAO getLicenciaDAO() {
		return licenciaDAO;
	}

	public void setLicenciaDAO(LicenciaDAO licenciaDAO) {
		this.licenciaDAO = licenciaDAO;
	}

	public VacacionDAO getVacacionDAO() {
		return vacacionDAO;
	}

	public void setVacacionDAO(VacacionDAO vacacionDAO) {
		this.vacacionDAO = vacacionDAO;
	}

	public T01ParametroDAO getT01ParametroDAO() {
		return t01ParametroDAO;
	}

	public void setT01ParametroDAO(T01ParametroDAO t01ParametroDAO) {
		this.t01ParametroDAO = t01ParametroDAO;
	}

	public CuentaCorrienteDAO getCuentaCorrienteDAO() {
		return cuentaCorrienteDAO;
	}

	public void setCuentaCorrienteDAO(CuentaCorrienteDAO cuentaCorrienteDAO) {
		this.cuentaCorrienteDAO = cuentaCorrienteDAO;
	}	

	public Long determinarRegistrador(String codEmp) throws Exception {
		return registradorViaticoDAO.determinaRegistrador(codEmp);
	}
	
	public Long determinarRegistradorUniversal(String codEmp) throws Exception {
		return registradorViaticoDAO.determinaRegistradorUniversal(codEmp);
	}

	public PlanViajeRendicionDAO getPlanViajeRendicionDAO() {
		return planViajeRendicionDAO;
	}

	public void setPlanViajeRendicionDAO(PlanViajeRendicionDAO planViajeRendicionDAO) {
		this.planViajeRendicionDAO = planViajeRendicionDAO;
	}

	public TipoDocumentoDAO getTipoDocumentoDAO() {
		return tipoDocumentoDAO;
	}

	public void setTipoDocumentoDAO(TipoDocumentoDAO tipoDocumentoDAO) {
		this.tipoDocumentoDAO = tipoDocumentoDAO;
	}



	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}


	
	@Override
	public List<PrgAnnoBean> listarAnios() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		Calendar fecha = Calendar.getInstance();
		String ls_anio = String.valueOf(fecha.get(Calendar.YEAR));
		map.put("anio_act", ls_anio);
		List<PrgAnnoBean> lista = (List<PrgAnnoBean>) prgAnnoDao.listarAnnos(map);
		return lista;
	}

	/**
	 * Metodo que permite buscar un lugares a partir del codigo de departamento y codigo de provincia
	 * 
	 * @author Juan Farro
	 * @param codigoDepartamento codigo departamento
	 * @param codigoProvincia codigo provincia
	 * @return lista de lugares
	 * @throws Exception
	 * @see TXXX8LugarUbigeoBean
	 */
	@Override
	public List<TXXX8LugarUbigeoBean> obtenerLugaresByCodigo(String codigoDepartamento, String codigoProvincia) throws Exception {
		return tXXX8LugarUbigeoDAO.obtenerLugaresByCodigo(codigoDepartamento, codigoProvincia);
	}

	/**
	 * Metodo que permite buscar un lugar a partir de su codigo.
	 * 
	 * @author Juan Farro
	 * @param descripcionDepartamento descripcion departamento
	 * @param descripcionProvincia descripcion provincia
	 * @param descripcionLugar descripcion lugar
	 * @return lista de lugares
	 * @throws Exception
	 * @see TXXX8LugarUbigeoBean
	 */
	@Override
	public List<TXXX8LugarUbigeoBean> obtenerLugaresByDescripcion(String descripcionDepartamento, String descripcionProvincia, String descripcionLugar) throws Exception {
		return tXXX8LugarUbigeoDAO.obtenerLugaresByDescripcion(descripcionDepartamento, descripcionProvincia, descripcionLugar);
	}

	/**
	 * Metodo que permite listar las vacaciones de un colaborador.
	 * 
	 * @author Juan Farro
	 * @param codigoDependencia codigo de dependencia
	 * @param anioEjecucion anio de ejecucion
	 * @param ordenarPor indicador de ordenacion
	 * @return lista de metas
	 * @throws Exception
	 * @see MetasBean
	 */
	@Override
	public List<MetasBean> obtenerMetas(String codigoDependencia, String anioEjecucion, String ordenarPor) throws Exception {
		return metasDAO.obtenerMetas(null, codigoDependencia, anioEjecucion, ordenarPor);
	}

	@Override
	public MetasBean obtenerMeta(String secuFuncSfu, String anioEjecucion) throws Exception {

		// Primary Key ANNO_EJEC_EJE y SECU_FUNC_SFU
		List<MetasBean> listaMetas = metasDAO.obtenerMetas(secuFuncSfu, null, anioEjecucion, null);

		if (CollectionUtils.isNotEmpty(listaMetas)) {
			return listaMetas.get(0);
		}

		return null;
	}

	/**
	 * Metodo que permite listar las vacaciones de un colaborador.
	 * 
	 * @author Juan Farro
	 * @param parametros de busqueda
	 * @return lista de vacaciones
	 * @throws Exception
	 * @see VacacionBean
	 */
	@Override
	public List<VacacionBean> listarVacaciones(Map<String, Object> params) throws Exception {

		return vacacionDAO.listarVacaciones(params);
	}

	/**
	 * Metodo que permite listar las licencias de un colaborador.
	 * 
	 * @author Juan Farro
	 * @param parametros de busqueda
	 * @return lista de licencias
	 * @throws Exception
	 * @see LicenciaBean
	 */
	@Override
	public List<LicenciaBean> listarLicencias(Map<String, Object> params) throws Exception {

		return licenciaDAO.listarLicencias(params);
	}

	/**
	 * Metodo que permite listar las compensaciones de un colaborador.
	 * 
	 * @author Juan Farro
	 * @param parametros de busqueda
	 * @return lista de compensaciones
	 * @throws Exception
	 * @see LicenciaBean
	 */
	@Override
	public List<LicenciaBean> listarCompensacion(Map<String, Object> params) throws Exception {

		return licenciaDAO.listarCompensacion(params);
	}

	/**
	 * Metodo que permite obtener los tarifas (tarifario, porcentaje).
	 * 
	 * @author Juan Farro
	 * @return lista de tarifas
	 * @throws Exception
	 * @see RutaTipoTarifaBean
	 */
	@Override
	public List<RutaTipoTarifaBean> obtenerRutasTipoTarifas() throws Exception {

		List<RutaTipoTarifaBean> listaRutas = null;

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("cod_par", ViaticoConstantes.LUGAR_DESPLAZ_TARIFAS_PARAM);
		params.put("cod_tipo", ViaticoConstantes.DETALLE);

		// NOTA: se espera que nunca cambien el T01ParametroBean del DAO compartido en el sharedlib
		Collection<T01ParametroBean> paramList = t01ParametroDAO.recuperarParametroLista(params);

		if (CollectionUtils.isNotEmpty(paramList)) {
			listaRutas = new ArrayList<RutaTipoTarifaBean>(paramList.size());

			String des_abr = null;
			RutaTipoTarifaBean item = null;

			for (T01ParametroBean paramItem : paramList) {
				if (paramItem == null) continue;

				item = new RutaTipoTarifaBean();

				// COD_ARGUMENTO
				item.setCodigo(StringUtils.trimToEmpty(paramItem.getCod_argumento()));

				// DESC_LARGA
				item.setDescripcion(StringUtils.trimToEmpty(paramItem.getNom_largo()).toUpperCase());

				// campo DESC_ABREVIATURA que lo usan para guardar el %
				des_abr = StringUtils.trimToEmpty(paramItem.getDesc_abrv());

				item.setPorcentaje(NumberUtils.isNumber(des_abr) ? Double.parseDouble(des_abr) * 100.00 : 0.0);

				listaRutas.add(item);
			}

		}

		return listaRutas;
	}

	/**
	 * Metodo que permite obtener los lugares (lugar, dias de traslado, codigo de ubigo).
	 * 
	 * @author Juan Farro
	 * @return lista de lugares
	 * @throws Exception
	 * @see TXXX8LugarUbigeoBean
	 */
	@Override
	public List<TXXX8LugarUbigeoBean> obtenerRutasLugares() throws Exception {

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("COD_PARAMETRO", ViaticoConstantes.LUGAR_DESPLAZ_LUGARES_PARAM);
		params.put("COD_TIPO", ViaticoConstantes.DETALLE);
		params.put("COD_ESTADO", ViaticoConstantes.ACTIVO);

		List<TXXX8LugarUbigeoBean> listaLugares = tXXX8LugarUbigeoDAO.obtenerRutasLugares(params);

		return listaLugares;
	}

	/**
	 * Metodo que permite obtener los medios de transporte
	 * 
	 * @author Juan Farro
	 * @return lista de medios de transporte
	 * @throws Exception
	 * @see ClaveValorBean
	 */
	@Override
	public List<ClaveValorBean> obtenerMediosTransporte() throws Exception {

		List<ClaveValorBean> listaMedioTransporte = null;

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("cod_par", ViaticoConstantes.LUGAR_DESPLAZ_MEDIO_TRANSPORTE_PARAM);
		params.put("cod_tipo", ViaticoConstantes.DETALLE);

		Collection<T01ParametroBean> paramList = t01ParametroDAO.recuperarParametroLista(params);

		if (CollectionUtils.isNotEmpty(paramList)) {
			listaMedioTransporte = new ArrayList<ClaveValorBean>(paramList.size());

			ClaveValorBean item = null;

			for (T01ParametroBean paramItem : paramList) {
				if (paramItem == null) continue;

				item = new ClaveValorBean();

				// COD_ARGUMENTO
				item.setCodigo(StringUtils.trimToEmpty(paramItem.getCod_argumento()));

				// DESC_LARGA
				item.setDescripcion(StringUtils.trimToEmpty(paramItem.getNom_largo()));

				listaMedioTransporte.add(item);
			}

		}

		return listaMedioTransporte;
	}

	/**
	 * Metodo que permite obtener los motivos de ampliacion de comision
	 * 
	 * @author Juan Farro
	 * @return lista de motivos ampliacion comision
	 * @throws Exception
	 * @see ClaveValorBean
	 */
	@Override
	public List<ClaveValorBean> obtenerMotivosAmpliacionComision() throws Exception {

		List<ClaveValorBean> listaMotivosAmpliacion = null;

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("cod_par", ViaticoConstantes.MOTIVO_AMPLIACION_CODIGO_PARAMETRO);
		params.put("cod_tipo", ViaticoConstantes.DETALLE);

		Collection<T01ParametroBean> paramList = t01ParametroDAO.recuperarParametroLista(params);

		if (CollectionUtils.isNotEmpty(paramList)) {
			listaMotivosAmpliacion = new ArrayList<ClaveValorBean>(paramList.size());

			ClaveValorBean item = null;

			for (T01ParametroBean paramItem : paramList) {
				if (paramItem == null) continue;

				item = new ClaveValorBean();

				// COD_ARGUMENTO
				item.setCodigo(StringUtils.trimToEmpty(paramItem.getCod_argumento()));

				// DESC_LARGA
				item.setDescripcion(StringUtils.trimToEmpty(paramItem.getNom_largo()));

				listaMotivosAmpliacion.add(item);
			}

		}

		return listaMotivosAmpliacion;
	}	
	
	/**
	 * Metodo que permite obtener un medio de transporte.
	 * 
	 * @author Juan Farro
	 * @param codMedioTransporte codigo medio de transporte
	 * @return medio de transporte
	 * @throws Exception
	 * @see ClaveValorBean
	 */
	@Override
	public ClaveValorBean obtenerMedioTransporte(String codMedioTransporte) throws Exception {

		if (StringUtils.isBlank(codMedioTransporte)) return null;

		ClaveValorBean medioTransporte = null;

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("cod_par", ViaticoConstantes.LUGAR_DESPLAZ_MEDIO_TRANSPORTE_PARAM);
		params.put("cod_tipo", ViaticoConstantes.DETALLE);
		params.put("cod_arg", codMedioTransporte);

		// NOTA: se espera que nunca cambien el T01ParametroBean del DAO compartido en el sharedlib
		Collection<T01ParametroBean> listaParametros = t01ParametroDAO.recuperarParametroLista(params);

		if (CollectionUtils.isNotEmpty(listaParametros)) {

			// la interfaz collection no tiene un metodo get(posicion) por lo que se esta usando un for
			for (T01ParametroBean parametro : listaParametros) {

				if (parametro == null) continue;

				medioTransporte = new ClaveValorBean();

				// COD_ARGUMENTO
				medioTransporte.setCodigo(StringUtils.trimToEmpty(parametro.getCod_argumento()));

				// DESC_LARGA
				medioTransporte.setDescripcion(StringUtils.trimToEmpty(parametro.getNom_largo()));

				// la interfaz collection no tiene un metodo get(posicion) por lo que se esta usando un for
				break;
			}

		}

		return medioTransporte;
	}

	/**
	 * Metodo que permite obtener el listado de cuentas corriente.
	 * 
	 * @author Jorge Ponce.
	 * @param tipoDestino :tipo destino.
	 * @return Listado de cuentas corriente.
	 * @see CuentaCorrienteBean
	 * @throws Exception
	 */
	@Override
	public ArrayList<CuentaCorrienteBean> obtenerCuentasCorriente(String tipoDestino) throws Exception {

		String simboloMoneda = ViaticoConstantes.CADENA_VACIA;
		ArrayList<CuentaCorrienteBean> cuentaCorrienteList = null;

		if (ViaticoConstantes.TIPO_COMISION_NACIONAL.equals(tipoDestino)) {
			simboloMoneda = ViaticoConstantes.MONEDA_SOLES;
		} else {
			simboloMoneda = ViaticoConstantes.MONEDA_DOLARES;
		}

		if (!ViaticoConstantes.CADENA_VACIA.equals(simboloMoneda)) {
			cuentaCorrienteList = cuentaCorrienteDAO.obtenerCuentasCorriente(null);
		}

		return cuentaCorrienteList;
	}

	@Override
	public ArrayList<TipoDocumentoBean> obtenerTipoDocumentoToComprobante() throws Exception {
		return tipoDocumentoDAO.obtenerTipoDocumentoToComprobante(null);
	}
	
	/**
	 * Metodo que permite obtener el listado de tipo documento declaracion.
	 * @author Jorge Ponce.
	 * @param  abreviaturaTipoDocumento :abreviatura tipo documento.
	 * @return Listado de tipo documento.
	 * @see    TipoDocumentoBean
	 * @throws Exception
	 */
	public ArrayList<TipoDocumentoBean> obtenerTipoDocumentoDeclaracion() throws Exception {
		return tipoDocumentoDAO.obtenerTipoDocumentoToComprobante(ViaticoConstantes.ABREVIATURA_TIPO_DOCUMENTO_DECLARACION);
	}

	/**
	 * Metodo que permite buscar un lugar nacional a partir de su codigo.
	 * 
	 * @author Juan Farro
	 * @param codigoLugar codigo de lugar
	 * @return lugar
	 * @throws Exception
	 * @see TXXX8LugarUbigeoBean
	 */
	@Override
	public TXXX8LugarUbigeoBean obtenerLugarByCodigoLugarNacional(String codigoLugar) throws Exception {

		if (StringUtils.isBlank(codigoLugar)) return null;
		
		return tXXX8LugarUbigeoDAO.obtenerLugarNacional(codigoLugar);
	}
	
	/**
	 * Metodo que permite buscar un lugar internacional a partir de su codigo.
	 * 
	 * @author Juan Farro
	 * @param codigoLugar codigo de lugar
	 * @return lugar
	 * @throws Exception
	 * @see TXXX8LugarUbigeoBean
	 */
	@Override
	public TXXX8LugarUbigeoBean obtenerLugarByCodigoLugarInternacional(String codigoLugar) throws Exception {

		if (StringUtils.isBlank(codigoLugar)) return null;

		return tXXX8LugarUbigeoDAO.obtenerLugarInternacional(codigoLugar);
	}

	/**
	 * Metodo que permite obtener verdadero / falso si se repite el tipo documento, serie y numero documento
	 * 
	 * @author Samuel Donisio.
	 * @param planViajeRendicion : PlanViajeRendicionBean para el envio de data.
	 * @return boolean.
	 * @see Boolean
	 * @throws Exception
	 */
	@Override
	public Boolean validarNumeroDocumento(PlanViajeRendicionBean planViajeRendicion) throws Exception {
		boolean estadoNumeroDocumento =  false;
		if(planViajeRendicion.getSerie()!=null)planViajeRendicion.setSerie(planViajeRendicion.getSerie().replaceFirst("^0+(?!$)", ""));
		if(planViajeRendicion.getNumeroDocumento()!=null)planViajeRendicion.setNumeroDocumento(planViajeRendicion.getNumeroDocumento().replaceFirst("^0+(?!$)", ""));
		Integer rendiciones = planViajeRendicionDAO.countPlanViajeRendicion(planViajeRendicion);
		if(rendiciones.intValue()==0){
			estadoNumeroDocumento =  true;
		}
		return estadoNumeroDocumento;
	}	
	
	/**
	 * Recuperar Contratista .Padron
	 * 
	 * @author emarchena.
	 * @param String : RUC de proveedor
	 * @return String.
	 * @see String
	 * @throws Exception
	 */
	public String validarPadronRUC(String ruc) throws Exception{
			String ls_rpta=FormatoConstantes.CADENA_VACIA;
			Map<String,Object> parm = new HashMap<String,Object>();
			parm.put("num_ruc",ruc);
			MaestroContratistasBean contratista= registroPersonalService.recuperarContratistaPadronNew(parm);
			
			contratista.getRaz_social();
			contratista.getNum_ruc();
			
			
		
		return ls_rpta;
	}
	
	/**
	 * Metodo que permite obtener un parametro de viaticos.
	 * @author Jorge Ponce.
	 * @param  codParametro :codigo parametro.
	 * @param  codArgumento :codigo argumento.
	 * @return Parametro de viaticos.
	 * @see    T01ParametroBean
	 * @throws Exception
	 */
	public T01ParametroBean obtenerParametroViatico(String codParametro, String codArgumento) throws Exception {
		
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("cod_mod", ViaticoConstantes.CODIGO_MODULO);
		paramSearch.put("cod_tipo", ViaticoConstantes.CODIGO_TIPO);
		paramSearch.put("cod_par", codParametro);
		paramSearch.put("cod_arg", codArgumento);
		return t01ParametroDAO.recuperarParametro(paramSearch);
	}

	@Override
	public Boolean existeRendicion(PlanViajeRendicionBean planViajeRendicion)
			throws Exception {
		boolean existe = false;
		List<PlanViajeRendicionBean> lista = planViajeRendicionDAO.obtenerAllListaPlanViajeRendicion(planViajeRendicion);
		if(!CollectionUtils.isEmpty(lista))existe = true;
		return existe;
	}
	
}
