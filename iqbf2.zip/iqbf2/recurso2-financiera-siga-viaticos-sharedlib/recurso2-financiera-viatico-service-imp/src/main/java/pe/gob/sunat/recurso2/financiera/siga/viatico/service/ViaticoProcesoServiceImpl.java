package pe.gob.sunat.recurso2.financiera.siga.viatico.service;

import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.recurso2.administracion.siga.util.FechaUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.SolicitudDTO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoUtil;



/**
 * Implementacion de la interface ViaticoProcesoService
 * @author Yoney Ayala.
 */
public class ViaticoProcesoServiceImpl implements ViaticoProcesoService {
	
	protected final Log log = LogFactory.getLog(getClass());
	
	
	/** Declaracion del servicio ViaticoConsultaService. */
	private ViaticoConsultaService viaticoConsultaService;

	/** Declaracion del servicio viaticoMensajeriaService. */
	private ViaticoMensajeriaService viaticoMensajeriaService;
	
	private PlanViajeDAO planViajeDAO;
	

	
	public ViaticoConsultaService getViaticoConsultaService() {
		return viaticoConsultaService;
	}

	public void setViaticoConsultaService(
			ViaticoConsultaService viaticoConsultaService) {
		this.viaticoConsultaService = viaticoConsultaService;
	}
	
	public ViaticoMensajeriaService getViaticoMensajeriaService() {
		return viaticoMensajeriaService;
	}

	public void setViaticoMensajeriaService(
			ViaticoMensajeriaService viaticoMensajeriaService) {
		this.viaticoMensajeriaService = viaticoMensajeriaService;
	}

	public PlanViajeDAO getPlanViajeDAO() {
		return planViajeDAO;
	}

	public void setPlanViajeDAO(PlanViajeDAO planViajeDAO) {
		this.planViajeDAO = planViajeDAO;
	}

	/**
	 * Metodo que permite enviar notificacion electronica a comisionado, registrador y registrador Universal 
	 * @author Yoney Ayala.
	 * @throws Exception
	 */
	@Override
	public void obtenerListaEstadosSolicitudPendienteViatico() {
		try {
		    log.debug("obtenerListaEstadosSolicitudPendienteViatico - INICIO");
		    List<PlanViajeBean> listaViaticos = planViajeDAO.obtenerListaEstadosSolicitudPendienteViatico();
	
		     if(listaViaticos != null){
	
		            int j = listaViaticos.size();
		            log.debug("1 NUMERO DE ELEMENTOS - "+j);
		         
		          for(int i = 0; i < listaViaticos.size(); i++){
		        	  PlanViajeBean planViaje =listaViaticos.get(i);
		        	  planViaje.setFechaHoraProgRetornoSiguiente( FechaUtil.sumarRestarDiasFecha( planViaje.getFechaHoraProgRetorno(), 1));
		        	  log.debug("Plan Viaje"+ planViaje.getCodPlanViaje()+" Fecha REtrono dia siguiente" + planViaje.getFechaHoraProgRetornoSiguiente());
		        	  try{
		                List<PlanViajeBean> listaViaticoConcecutivo = planViajeDAO.obtenerListaViaticoConcecutivo(planViaje);
		                log.debug("2  listaViaticoConcecutivo - ");
		                if(listaViaticoConcecutivo != null  && !listaViaticoConcecutivo.isEmpty() ){
		                    log.debug("3  listaViaticoConcecutivo - UNIVERSAL");
		                    notificacionRegistradorUniversal(listaViaticos, i);
		                }else{
		                    log.debug("4  listaViaticoConcecutivo - NORMAL");
		                    notificacion(listaViaticos.get(i).getCodPlanViaje());
		                    log.debug("5  actualizarPlanViajeToFechaNotificacion - NORMAL");
		                    planViajeDAO.actualizarPlanViajeToFechaNotificacion( listaViaticos.get(i));
		                }
		        	  }catch(Exception e){
		        		  log.error("Error obtenerListaViaticoConcecutivo", e); // recordar arreglar el manejo del log de errores
		        	  }
		            }
		      }
		     log.debug("obtenerListaEstadosSolicitudPendienteViatico - FIN");
		
		}catch(Exception e){
			log.error(" Error obtenerListaEstadosSolicitudPendienteViatico", e);
		}
    }
	/**
	 * Metodo que permite enviar notificacion al registrador Universal 
	 * @author Yoney Ayala.
	 */
	    public void notificacionRegistradorUniversal(List<PlanViajeBean> lista,int i){
	        log.debug("3.1 notificacionRegistradorUniversal");
	        SolicitudDTO solicitudDTO = new SolicitudDTO();
	        solicitudDTO = viaticoConsultaService.obtenerPlanViajeToNotificacion(lista.get(i).getCodPlanViaje(), lista);
	        log.debug("3.2 obtenerPlanViajeToNotificacion-fin");
	        viaticoMensajeriaService.enviarNotificacionAnulacionSolcitudReembolsoAutorizador(solicitudDTO); 
	        log.debug("3.3 enviarNotificacionAnulacionSolcitudReembolsoAutorizador-fin");
	    }
	    
		/**
		 * Metodo que permite enviar notificacion al  comisionado, registrador
		 * @author Yoney Ayala.
		 */
	    public void notificacion(String codPlanViaje){
	        log.debug("4.1 notificacion");
	        SolicitudDTO solicitudDTO = new SolicitudDTO();
	        solicitudDTO = viaticoConsultaService.obtenerPlanViajeToNotificacion(codPlanViaje);
	        log.debug("4.2 obtenerPlanViajeToNotificacion Fin");
	        viaticoMensajeriaService.enviarNotificacionRendicion(solicitudDTO);
	        
	        log.debug("4.3 enviarNotificacionRendicion Fin");
	    }
		
		/**
		 * Metodo que envia notificacion electronica a comisionados que no cumplan con presentar la rendición de Planillas de viaticos en el plazo establecido adicional 
		 * 
		 * @author Yoney Ayala
		 * @throws Exception
		 */	
	@Override
	public void obtenerListaViaticoDiasAdicional()  {
		try{
			List<PlanViajeBean> listaViaticosPlazoDosDias = planViajeDAO.obtenerListaViaticoDiasAdicional();
			 Date fechaActual = new Date();
			if(listaViaticosPlazoDosDias != null){	
				long j=listaViaticosPlazoDosDias.size();
				log.debug("1 Numeor de REgistros" + j);
				for(int i= 0; i < listaViaticosPlazoDosDias.size(); i++){
					log.debug("2 fechaActual" + fechaActual + "Fecha Notifiacion " + listaViaticosPlazoDosDias.get(i).getFechaNotificacion() );
					//if(ViaticoUtil.restarDias( fechaActual,listaViaticosPlazoDosDias.get(i).getFechaNotificacion()) == 0 ){
					 try{
						SolicitudDTO solicitudDTO = new SolicitudDTO();
						log.debug("3 obtenerPlanViajeToNotificacion");
						solicitudDTO = viaticoConsultaService.obtenerPlanViajeToNotificacion(listaViaticosPlazoDosDias.get(i).getCodPlanViaje());
						log.debug("4 obtenerPlanViajeToNotificacion");
						viaticoMensajeriaService.enviarNotificacioAlRegistrador(solicitudDTO);
						 log.debug("5  actualizarPlanViajeToFechaNotificacion ");
		                  planViajeDAO.actualizarPlanViajeToFechaNotificacion( listaViaticosPlazoDosDias.get(i));
					//}
					 }catch(Exception e){
		        		  log.error("Error obtenerListaViaticoDiasAdicional", e); // recordar arreglar el manejo del log de errores
		        	 }
				}
			}	
		}catch(Exception e){
			log.error("Error obtenerListaViaticoDiasAdicional", e);
		}
	}
	
	/**
	 * Metodo que envia notificacion electronica a al comisionado, registrador 
	 * cuando las planillas de viaticos que no han sido remitidas para la gestion del pago en 30 dias calendarios
	 * @author Yoney Ayala
	 * @throws Exception
	 */	
	@Override
	public void obtenerListaViaticoPlazoExcedido()  {	
		try{
			 
			List<PlanViajeBean> listaViaticosPlazoExcedido = planViajeDAO.obtenerListaViaticoPlazoExcedido();
			//String codTrabajador= ViaticoConstantes.CADENA_VACIA;
		
			if(CollectionUtils.isNotEmpty(listaViaticosPlazoExcedido)){
				long j = listaViaticosPlazoExcedido.size();
				log.debug("1 nuemro de registros " + j);
				List<SolicitudDTO> listaDTO = viaticoConsultaService.obtenerPlanViajeToNotificacionList( listaViaticosPlazoExcedido);
				 if(CollectionUtils.isNotEmpty(listaDTO)){
					log.debug("2 obtenerPlanViajeToNotificacion numero de registros " + listaDTO.size());
					viaticoMensajeriaService.enviarnotificacionPlanillaVaiticosNoRemitidas(listaDTO);
					log.debug("3 enviarnotificacionPlanillaVaiticosNoRemitidas ok");	
				} 
							
			}		
		}catch(Exception e){
			log.error("Error obtenerListaViaticoPlazoExcedido", e);
		}
		
	}
	
	/**
	 * Metodo que actualiza e envia notificaciones electronica al comisionado y registrado
	 * 
	 * @author Yoney Ayala
	 * @throws Exception
	 */		
	@Override
	public void obtenerListaViaticoPlazoExcedidoGlobal()  {
		try{
			 Date fechaActual = new Date();
			List<PlanViajeBean> listaViaticosPlazoExcedidoGlobal = planViajeDAO.obtenerListaViaticoPlazoExcedidoGlobal();
	
			if(listaViaticosPlazoExcedidoGlobal != null){
				long j = listaViaticosPlazoExcedidoGlobal.size();
				log.debug("1 numero de registro :" + j);
				for(int i= 0; i < listaViaticosPlazoExcedidoGlobal.size(); i++){
					try{
					
						PlanViajeBean planViajeBean = listaViaticosPlazoExcedidoGlobal.get(i);
					
						planViajeBean.setEstadoPlanViaje(ViaticoConstantes.ESTADO_VIATICO_ANULACION_AUTOMATICA);			
					
						planViajeDAO.actualizarPlanViajeToCerrarAnulacion(planViajeBean);
						log.debug("2 actualizarPlanViajeToCerrarAnulacion ok");
						SolicitudDTO solicitudDTO = new SolicitudDTO();
						solicitudDTO = viaticoConsultaService.obtenerPlanViajeToNotificacion(planViajeBean.getCodPlanViaje());
						log.debug("3 obtenerPlanViajeToNotificacion ok");
						viaticoMensajeriaService.enviarNotificacionDeAnulacionDePlanilla(solicitudDTO);	
						log.debug("4 enviarNotificacionDeAnulacionDePlanilla ok");
					 }catch(Exception e){
		        		  log.error("Error obtenerListaViaticoPlazoExcedidoGlobal", e); // recordar arreglar el manejo del log de errores
		        	 }
						
				}
			}	
		}catch(Exception e){
			log.error("Error obtenerListaViaticoPlazoExcedidoGlobal", e);
		}
	}

}
