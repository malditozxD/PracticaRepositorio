package pe.gob.sunat.recurso2.financiera.siga.viatico.service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.PersonaBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.administracion.siga.util.NumeroUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ConceptoPlanillaViaticosBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeConceptoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeInformeDistribBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeRendicionBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.ConceptoPlanillaViaticosDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PapeletaDepositoDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeConceptoDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeInformeDistribDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeRendicionDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dto.DocumentoSustentarioDTO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.service.ConsultaSolicitudService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;

public class ViaticoRegistroServiceImpl implements ViaticoRegistroService{

	protected final Log log = LogFactory.getLog(getClass());
	
	private RegistroPersonalService registroPersonalService;
	private ConsultaSolicitudService consultaSolicitudService;
	private PlanViajeInformeDistribDAO planViajeInformeDistribDAO;
	private ConceptoPlanillaViaticosDAO conceptoPlanillaViaticosDAO;
	private PlanViajeRendicionDAO planViajeRendicionDAO;
	private PapeletaDepositoDAO papeletaDepositoDAO;
	private PlanViajeConceptoDAO planViajeConceptoDAO;
	
	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}

	public ConsultaSolicitudService getConsultaSolicitudService() {
		return consultaSolicitudService;
	}

	public void setConsultaSolicitudService(ConsultaSolicitudService consultaSolicitudService) {
		this.consultaSolicitudService = consultaSolicitudService;
	}

	public PlanViajeInformeDistribDAO getPlanViajeInformeDistribDAO() {
		return planViajeInformeDistribDAO;
	}

	public void setPlanViajeInformeDistribDAO(PlanViajeInformeDistribDAO planViajeInformeDistribDAO) {
		this.planViajeInformeDistribDAO = planViajeInformeDistribDAO;
	}

	public ConceptoPlanillaViaticosDAO getConceptoPlanillaViaticosDAO() {
		return conceptoPlanillaViaticosDAO;
	}

	public void setConceptoPlanillaViaticosDAO(ConceptoPlanillaViaticosDAO conceptoPlanillaViaticosDAO) {
		this.conceptoPlanillaViaticosDAO = conceptoPlanillaViaticosDAO;
	}

	public PlanViajeRendicionDAO getPlanViajeRendicionDAO() {
		return planViajeRendicionDAO;
	}

	public void setPlanViajeRendicionDAO(PlanViajeRendicionDAO planViajeRendicionDAO) {
		this.planViajeRendicionDAO = planViajeRendicionDAO;
	}

	public PapeletaDepositoDAO getPapeletaDepositoDAO() {
		return papeletaDepositoDAO;
	}

	public void setPapeletaDepositoDAO(PapeletaDepositoDAO papeletaDepositoDAO) {
		this.papeletaDepositoDAO = papeletaDepositoDAO;
	}

	public PlanViajeConceptoDAO getPlanViajeConceptoDAO() {
		return planViajeConceptoDAO;
	}

	public void setPlanViajeConceptoDAO(PlanViajeConceptoDAO planViajeConceptoDAO) {
		this.planViajeConceptoDAO = planViajeConceptoDAO;
	}

	/**
	 * Metodo que permite registrar o editar documento sustentario.
	 * 
	 * @author Samuel Donisio.
	 * @param documentoSustentarioDTO :DTO para transaccion.
	 * @return mensaje de error o exito.
	 * @see DocumentoSustentarioDTO
	 * @throws Exception
	 */

	@Override
	public DocumentoSustentarioDTO registrarComprobantePago(DocumentoSustentarioDTO documentoSustentarioDTO) {
		log.debug(getClass().getName() + " Inicio del metodo registrarComprobantePago");
		DocumentoSustentarioDTO registroDocumentoSustentarioDTO = new DocumentoSustentarioDTO();
			String planViajeId = documentoSustentarioDTO.getPlanViajeId();
			Integer secuencial = planViajeRendicionDAO.secuencialMax(planViajeId);
			Calendar fecha = Calendar.getInstance();
	        String anio =  String.valueOf(fecha.get(Calendar.YEAR));
	        log.debug("documentoSustentarioDTO secuencial: " + documentoSustentarioDTO.getSecuencial() + " secuencial: " + secuencial);
			if(secuencial != null){
				
				if(StringUtils.isEmpty(documentoSustentarioDTO.getSecuencial()) ){
					log.debug("nuevo registro");					
					String numeroDocumento = ViaticoConstantes.CADENA_VACIA;
						try{		
								PlanViajeBean planViaje = consultaSolicitudService.buscarPlanViaje(planViajeId);
								PlanViajeRendicionBean planViajeRendicion = new PlanViajeRendicionBean();					
								planViajeRendicion = documentoSustentarioDTO.getListaPlanViajeRendicion().get(0);
								planViajeRendicion.setSerie(planViajeRendicion.getSerie().toUpperCase());
								planViajeRendicion.setPlanViajeId(planViajeId);
								planViajeRendicion.setSecuencial(secuencial);
								
								if(documentoSustentarioDTO.getListaPlanViajeRendicion().get(ViaticoConstantes.CERO_INT).getTipoDocumento().equals(ViaticoConstantes.TIPO_DOCUMENTO_DECLARACION_COMPROBANTE_PAGO) || 
											documentoSustentarioDTO.getListaPlanViajeRendicion().get(ViaticoConstantes.CERO_INT).getTipoDocumento().equals(ViaticoConstantes.TIPO_DOCUMENTO_DECLARACION_VIATICO)){
									
									String anioDocumentos = documentoSustentarioDTO.getListaPlanViajeRendicion().get(ViaticoConstantes.CERO_INT).getAnio();
									log.debug("anioDocumentos: " + anioDocumentos);
									numeroDocumento =  anioDocumentos + documentoSustentarioDTO.getCodigoDependencia() + "W" + NumeroUtil.formatearCerosIzquierda(secuencial, ViaticoConstantes.CUATRO);
									
									planViajeRendicion.setNumeroDocumento(numeroDocumento);
								
								}else if(documentoSustentarioDTO.getListaPlanViajeRendicion().get(ViaticoConstantes.CERO_INT).getTipoDocumento().equals(ViaticoConstantes.TIPO_DOCUMENTO_COMPROBANTE_EXTERIOR)) {
									String anioDocumentos = documentoSustentarioDTO.getListaPlanViajeRendicion().get(ViaticoConstantes.CERO_INT).getAnio();		
									log.debug("anioDocumentos: " + anioDocumentos);
									 numeroDocumento = anioDocumentos + documentoSustentarioDTO.getCodigoDependencia() + "X" + NumeroUtil.formatearCerosIzquierda(secuencial, ViaticoConstantes.CUATRO);
									planViajeRendicion.setNumeroDocumento(numeroDocumento);		
								}
								else{ if(StringUtils.isEmpty(documentoSustentarioDTO.getListaPlanViajeRendicion().get(ViaticoConstantes.CERO_INT).getNumeroDocumento())){
										numeroDocumento = ViaticoConstantes.CADENA_VACIA;
										planViajeRendicion.setNumeroDocumento(numeroDocumento);		
									}else {
										numeroDocumento = documentoSustentarioDTO.getListaPlanViajeRendicion().get(ViaticoConstantes.CERO_INT).getNumeroDocumento();
										planViajeRendicion.setNumeroDocumento(numeroDocumento);		
									} 								
								}
															
									 if(!StringUtils.isEmpty(planViajeRendicion.getRuc())){
										 log.debug("Si ingresa RUC");
											 Map<String, Object> param =  new HashMap<String, Object>();
											 param.put("num_ruc", planViajeRendicion.getRuc());
											 PersonaBean persona = registroPersonalService.recuperarPersona(param);
											 if(persona != null){
												 log.debug("Tiene codigo Persona");
											 	planViajeRendicion.setPersonaId(persona.getCodigo_persona());
											 	planViajeRendicion.setTrabajador(documentoSustentarioDTO.getCodigoColaborador());
											 }else{
												 log.debug("No tiene codigo Persona");
											 }										 							 
									 }else{
										 log.debug("No ingresa RUC");
										 planViajeRendicion.setPersonaId(documentoSustentarioDTO.getCodigoColaborador());
										 planViajeRendicion.setTrabajador(documentoSustentarioDTO.getCodigoColaborador());
										 planViajeRendicion.setDependencia(documentoSustentarioDTO.getCodigoDependencia());
									 }
											
										planViajeRendicion.setPresupuestoAnno(anio);
									
										planViajeRendicion.setPresupuestoMeta(planViaje.getPresupuestoMeta());
					
									log.debug("Registrando plan viaje rendición...");
									planViajeRendicionDAO.registrarPlanViajeRendicion(planViajeRendicion);
									log.debug("Plan viaje rendición registrado.");
									
									if(!documentoSustentarioDTO.getListaPlanViajeInformeDistrib().isEmpty()){
										log.debug("La lista ListaPlanViajeInformeDistrib() no está vacía.");
										//Crea una lista de cada tipo de distribucion, aquí no debería de registrar...
										List<PlanViajeInformeDistribBean> listaPlanViajeInformeDistrib = formatoPlanViajeInformeDistrib(documentoSustentarioDTO.getListaPlanViajeInformeDistrib(), 
												planViajeId, secuencial,planViajeRendicion,planViaje.getTipoDestino());			
										for (PlanViajeInformeDistribBean planViajeInformeDistrib : listaPlanViajeInformeDistrib){
											planViajeInformeDistribDAO.registrarPlanViajeInformeDistrib(planViajeInformeDistrib);
											log.debug("Registrando plan viaje informe distrib....");
										}
									}								
									
									log.debug("Inicio del cálculo del monto del documento...");
									
									Double montoDocumento = 0D;								
									
									log.debug("Obteniendo lista del plan viaje informe de distribución...");
									List<PlanViajeInformeDistribBean> planViajeInformeDistribConcepto = planViajeInformeDistribDAO.obtenerListaPlanViajeInformeDistribToConcepto(planViajeId, planViajeRendicion.getConceptoId());						
									for(PlanViajeInformeDistribBean planViajeInformeDistribB : planViajeInformeDistribConcepto){
										montoDocumento = montoDocumento + planViajeInformeDistribB.getMtoDocumento();
									}
									log.debug("montoDocumento 1: " + montoDocumento);
									PlanViajeConceptoBean planViajeConcepto = new PlanViajeConceptoBean(); 
									
									
									//**Para reembolso genera nuevo concepto****/
									log.debug("tipo de origen:"+ planViaje.getOrigen()+".");
									log.debug("tipo de traslado:"+ planViaje.getCodigoTipoTraslado()+".");
									log.debug("tipo de concepto a evaluar:"+ planViajeRendicion.getConceptoId()+".");
									
									if(ViaticoConstantes.TIPO_ORIGEN_REEMBOLSO.equals(planViaje.getOrigen()) &&
											ViaticoConstantes.TIPO_TRASLADO_VIATICOS.equals(planViaje.getCodigoTipoTraslado()) &&
											!(ViaticoConstantes.CONCEPTO_VIATICO_CODI_CONC_PVI_FIJO_NACIONAL.equals(planViajeRendicion.getConceptoId())) &&
											!(ViaticoConstantes.CONCEPTO_VIATICO_CODI_CONC_PVI_FIJO_INTERNACIONAL.equals(planViajeRendicion.getConceptoId()))
									){
										
										log.debug("Listando conceptos para actualizar...");
										List<PlanViajeConceptoBean> planViajeConceptoConsultaList = planViajeConceptoDAO.buscarPlanViajeConceptos(planViajeRendicion.getPlanViajeId());
									
										if(CollectionUtils.isNotEmpty(planViajeConceptoConsultaList)){
											boolean estadoInsert = true;
											for(PlanViajeConceptoBean planViajeConceptoLoop : planViajeConceptoConsultaList){
												log.debug("Iterando sobre el concepto:"+planViajeConceptoLoop.getConceptoID()+", concepto a comparar:"+planViajeRendicion.getConceptoId());
												if(planViajeConceptoLoop.getConceptoID().equals(planViajeRendicion.getConceptoId())){
													estadoInsert = false; break;
												}
											}
											log.debug("Estado de insercion/actualizacion :"+estadoInsert);
											if(estadoInsert){
												PlanViajeConceptoBean planViajeConceptoNew = new PlanViajeConceptoBean();
												planViajeConceptoNew.setPlanViajeID(planViajeRendicion.getPlanViajeId());
												planViajeConceptoNew.setConceptoID(planViajeRendicion.getConceptoId());
												planViajeConceptoNew.setCantidad(ViaticoConstantes.UNO_DOUBLE);
												// confirmado, según vicky siempre va 1
												if(ViaticoConstantes.TIPO_DOCUMENTO_BOLETO_VIAJE.equals(planViajeRendicion.getTipoDocumento()) || 
													ViaticoConstantes.TIPO_DOCUMENTO_BOLETO_VIAJE.equals(planViajeRendicion.getTipoDocumento())){
													planViajeConceptoNew.setMonto(planViajeRendicion.getMontoDocumento());
													planViajeConceptoNew.setMontoReal(planViajeRendicion.getMontoDocumento());														
												}
												else{
													planViajeConceptoNew.setMonto(planViajeRendicion.getMontoRendicion());
													planViajeConceptoNew.setMontoReal(planViajeRendicion.getMontoDocumento());														
												}
												planViajeConceptoNew.setClasificadorGasto(planViajeRendicion.getClasificadorGasto());
												planViajeConceptoNew.setMontoDevuelto(null);
												planViajeConceptoNew.setMontoManual(null);				                    
												planViajeConceptoNew.setMontoRendido(null);
												planViajeConceptoNew.setMontoRic(null);           
												planViajeConceptoDAO.registrarPlanViajeConcepto(planViajeConceptoNew);
											}else{													 
												PlanViajeConceptoBean planViajeConceptoNew = new PlanViajeConceptoBean();
												planViajeConceptoNew.setPlanViajeID(planViajeRendicion.getPlanViajeId());
												planViajeConceptoNew.setConceptoID(planViajeRendicion.getConceptoId());
												planViajeConceptoNew.setMonto(montoDocumento);
												planViajeConceptoNew.setMontoReal(montoDocumento);
												planViajeConceptoDAO.actualizarPlanViajeConcepto(planViajeConceptoNew);
											}
										}
									}
									///**********************************//
											
									planViajeConcepto.setMontoRendido(montoDocumento);
									planViajeConcepto.setPlanViajeID(planViajeId);
									planViajeConcepto.setConceptoID(planViajeRendicion.getConceptoId());
									planViajeConceptoDAO.actualizarMontoRendidoComprobante(planViajeConcepto);
									log.debug("PLan viaje concepto actualizado...");														
				
									
									/*Actualizando el monto devuelto por voucher*/
									BigDecimal montoDepositado =  papeletaDepositoDAO.obtenerMontoDepositado(planViajeId);
									log.debug("Monto depositado :"+montoDepositado);
									actualizarMontoDevueltoVoucher(planViajeId, montoDepositado);
									log.debug("Monto devuelto actualizado...");
									PlanViajeRendicionBean planViajeRendicionB = new PlanViajeRendicionBean();
									planViajeRendicionB.setSecuencial(secuencial);
									planViajeRendicionB.setNumeroDocumento(numeroDocumento);
									registroDocumentoSustentarioDTO.setPlanViajeRendicionBean(planViajeRendicionB);
									registroDocumentoSustentarioDTO.setMensajeOut(0);			            

							}catch (Exception e) {
									registroDocumentoSustentarioDTO.setMensajeOut(-1);
									log.error("Error registrar registrarComprobantePago" + e.getMessage(), e);
								}
					
									
				}else if(!StringUtils.isEmpty(documentoSustentarioDTO.getSecuencial())){
					log.debug("editar registro");
					log.debug("documentoSustentarioDTO secuencial: " + documentoSustentarioDTO.getSecuencial() + " secuencial: " + secuencial);
					try{
					
						PlanViajeBean planViaje = consultaSolicitudService.buscarPlanViaje(planViajeId);
						PlanViajeRendicionBean planViajeRendicion = new PlanViajeRendicionBean();					
						planViajeRendicion = documentoSustentarioDTO.getListaPlanViajeRendicion().get(0);
						planViajeRendicion.setSerie(planViajeRendicion.getSerie().toUpperCase());
						planViajeRendicion.setPlanViajeId(planViajeId);
						planViajeRendicion.setSecuencial(Integer.parseInt(documentoSustentarioDTO.getSecuencial()));
					
							 if(!StringUtils.isEmpty(planViajeRendicion.getRuc())){
								 
									 Map<String, Object> param =  new HashMap<String, Object>();
									 param.put("num_ruc",planViajeRendicion.getRuc());
									 PersonaBean persona = registroPersonalService.recuperarPersona(param);
									 if(persona != null){
									 	planViajeRendicion.setPersonaId(persona.getCodigo_persona());
									 	planViajeRendicion.setTrabajador(documentoSustentarioDTO.getCodigoColaborador());
									 }
								 							 
							 }else{
								 planViajeRendicion.setPersonaId(documentoSustentarioDTO.getCodigoColaborador());
								 planViajeRendicion.setTrabajador(documentoSustentarioDTO.getCodigoColaborador());
								 planViajeRendicion.setDependencia(documentoSustentarioDTO.getCodigoDependencia());
							 }
									
							planViajeRendicion.setPresupuestoAnno(anio);
							planViajeRendicion.setPresupuestoMeta(planViaje.getPresupuestoMeta());
			
							planViajeRendicionDAO.actualizarPlanViajeRendicion(planViajeRendicion);
							
							if(!documentoSustentarioDTO.getListaPlanViajeInformeDistrib().isEmpty()){
								log.debug(">>> Lista de distribucion no esta vacia....");
								PlanViajeInformeDistribBean planViajeInformeDistribucion =  new PlanViajeInformeDistribBean();
								planViajeInformeDistribucion.setPlanViajeId(planViajeId);
								planViajeInformeDistribucion.setSecuencial(Integer.parseInt(documentoSustentarioDTO.getSecuencial()));							
								planViajeInformeDistribDAO.eliminarPlanViajeInformeDistrib(planViajeInformeDistribucion);
								log.debug(">>> Informe de distribucion eliminado...");
								List<PlanViajeInformeDistribBean> listaPlanViajeInformeDistrib = formatoPlanViajeInformeDistrib(documentoSustentarioDTO.getListaPlanViajeInformeDistrib(), 
										planViajeId,Integer.parseInt(documentoSustentarioDTO.getSecuencial()),planViajeRendicion,planViaje.getTipoDestino());			
								for (PlanViajeInformeDistribBean planViajeInformeDistrib : listaPlanViajeInformeDistrib){
									planViajeInformeDistribDAO.registrarPlanViajeInformeDistrib(planViajeInformeDistrib);
									log.debug(">>> Informe de distribucion registrado.");
								}
							}				
							
							Double montoDocumento = 0D;							
						
							/****Para reembolso genera edicion concepto****/
							
							if(ViaticoConstantes.TIPO_ORIGEN_REEMBOLSO.equals(planViaje.getOrigen()) && 
									ViaticoConstantes.TIPO_TRASLADO_VIATICOS.equals(planViaje.getCodigoTipoTraslado()) &&
									!(ViaticoConstantes.CONCEPTO_VIATICO_CODI_CONC_PVI_FIJO_NACIONAL.equals(planViajeRendicion.getConceptoId())) &&
									!(ViaticoConstantes.CONCEPTO_VIATICO_CODI_CONC_PVI_FIJO_INTERNACIONAL.equals(planViajeRendicion.getConceptoId()))
							){
							PlanViajeRendicionBean planViajeRendicionBeanR = new PlanViajeRendicionBean();
							planViajeRendicionBeanR.setPlanViajeId(planViajeId);
							
							List<PlanViajeRendicionBean> listaPlanViajeRendicion = planViajeRendicionDAO.obtenerListDistinctConceptoRendicion(planViajeRendicionBeanR.getPlanViajeId());
							List<PlanViajeConceptoBean> planViajeConceptoConsultaList = planViajeConceptoDAO.buscarPlanViajeConceptos(planViajeRendicion.getPlanViajeId());
							
							planViajeConceptoDAO.eliminarPlanViajeConceptos(planViajeRendicion.getPlanViajeId());
							
							if(CollectionUtils.isNotEmpty(planViajeConceptoConsultaList)){
								Map <String, PlanViajeConceptoBean> planViajeConceptoMap = new HashMap<String, PlanViajeConceptoBean>();
								for(PlanViajeConceptoBean planViajeConceptoLoop : planViajeConceptoConsultaList){
									planViajeConceptoMap.put(planViajeConceptoLoop.getConceptoID(), planViajeConceptoLoop);
								}
								
								if(ViaticoConstantes.TIPO_COMISION_NACIONAL.equals(planViaje.getTipoDestino())){
									PlanViajeConceptoBean planViajeConceptoNacional = planViajeConceptoMap.get(ViaticoConstantes.CONCEPTO_VIATICO_CODI_CONC_PVI_FIJO_NACIONAL);
									planViajeConceptoDAO.registrarPlanViajeConcepto(planViajeConceptoNacional);
								}else{
									PlanViajeConceptoBean planViajeConceptoInterNacional =planViajeConceptoMap.get(ViaticoConstantes.CONCEPTO_VIATICO_CODI_CONC_PVI_FIJO_INTERNACIONAL);
									planViajeConceptoDAO.registrarPlanViajeConcepto(planViajeConceptoInterNacional);}
								
									for(PlanViajeRendicionBean planViajeRendicionConsulta : listaPlanViajeRendicion ){											
										if(!ViaticoConstantes.CONCEPTO_VIATICO_CODI_CONC_PVI_FIJO_NACIONAL.equals(planViajeRendicionConsulta.getConceptoId())
											&& !ViaticoConstantes.CONCEPTO_VIATICO_CODI_CONC_PVI_FIJO_INTERNACIONAL.equals(planViajeRendicionConsulta.getConceptoId())){
											PlanViajeConceptoBean planViajeConceptoFijoOld = new PlanViajeConceptoBean();
											PlanViajeConceptoBean planViajeConceptofijo = planViajeConceptoMap.get(planViajeRendicionConsulta.getConceptoId());
											montoDocumento = sumaMontoDocumentoxConcepto(planViajeRendicionConsulta.getPlanViajeId(), planViajeRendicionConsulta);	
											planViajeConceptoFijoOld = planViajeConceptofijo;
											planViajeConceptoFijoOld.setMonto(montoDocumento);
											planViajeConceptoFijoOld.setMontoReal(montoDocumento);
											planViajeConceptoFijoOld.setMontoRendido(montoDocumento);
											planViajeConceptoDAO.registrarPlanViajeConcepto(planViajeConceptoFijoOld);
										}
									}
						
								
							}
						}
						///**********************************//
							
						PlanViajeConceptoBean planViajeConcepto = new PlanViajeConceptoBean(); 	
						montoDocumento = sumaMontoDocumentoxConcepto(planViajeId, planViajeRendicion);
						log.debug("montoDocumento: " + montoDocumento);
						planViajeConcepto.setMontoRendido(montoDocumento);
						planViajeConcepto.setPlanViajeID(planViajeId);
						planViajeConcepto.setConceptoID(planViajeRendicion.getConceptoId());
						planViajeConceptoDAO.actualizarMontoRendidoComprobante(planViajeConcepto);														
	
						/*Actualizando el monto devuelto por voucher*/
						BigDecimal montoDepositado =  papeletaDepositoDAO.obtenerMontoDepositado(planViajeId);
						actualizarMontoDevueltoVoucher(planViajeId, montoDepositado);
						
						
						PlanViajeRendicionBean planViajeRendicionBeanR = new PlanViajeRendicionBean();
						planViajeRendicionBeanR.setPlanViajeId(planViajeId);
						planViajeRendicionBeanR.setSecuencial(Integer.parseInt(documentoSustentarioDTO.getSecuencial()));
						List<PlanViajeRendicionBean> listaPlanViajeRendicion = planViajeRendicionDAO.obtenerAllListaPlanViajeRendicion(planViajeRendicionBeanR);
						
						registroDocumentoSustentarioDTO.setPlanViajeRendicionBean(listaPlanViajeRendicion.get(0));
							
						registroDocumentoSustentarioDTO.setMensajeOut(0); 
					}catch (Exception e) {
						registroDocumentoSustentarioDTO.setMensajeOut(-1);
						log.error("Error editar registrarComprobantePago" + e.getMessage(), e);
					}				
								
					
				}
			
			}
			log.debug(getClass().getName() + " Fin del metodo registrarComprobantePago");
		return registroDocumentoSustentarioDTO;
	}
	
	private Double sumaMontoDocumentoxConcepto(String planViajeId, PlanViajeRendicionBean planViajeRendicion){
		Double montoDocumento = 0D;
		List<PlanViajeInformeDistribBean> planViajeInformeDistribConcepto = planViajeInformeDistribDAO.obtenerListaPlanViajeInformeDistribToConcepto(planViajeId, planViajeRendicion.getConceptoId());						
		for(PlanViajeInformeDistribBean planViajeInformeDistribB : planViajeInformeDistribConcepto){
			log.debug(">>>>montoDocumento detalle: " + planViajeInformeDistribB.getMtoDocumento());
			montoDocumento = montoDocumento + planViajeInformeDistribB.getMtoDocumento();
		}
		log.debug("montoDocumento: " + montoDocumento);
		
		log.debug("Fin del nuevo cálculo de monto...");
		return montoDocumento;
	}
	
	/**
	 * Metodo que permite obtener lista de planViajeDistribucion formateado con los conceptos de alimentacion, hospedaje, traslado, movilidad.
	 * @author Samuel Dionisio
	 * @param  planViajeInformeDistribList : List<PlanViajeInformeDistribBean>.
	 * @param  secuencial : secuencial del comprobante de pago.
	 * @param  conceptoId : codigo del concepto
	 * @return List PlanViajeInformeDistribBean on los conceptos de alimentacion, hospedaje, traslado, movilidad.
	 * @see    List PlanViajeInformeDistribBean
	 * @throws Exception
	 */
	private List<PlanViajeInformeDistribBean> formatoPlanViajeInformeDistrib (List<PlanViajeInformeDistribBean> planViajeInformeDistribList,
			String planViajeId, Integer secuencial, PlanViajeRendicionBean planViajeRendicion,String tipoDestino) {
		log.debug(getClass().getName() + " Inicio del metodo formatoPlanViajeInformeDistrib");
		List<PlanViajeInformeDistribBean> listaPlanViajeInformeDistrib =  new ArrayList<PlanViajeInformeDistribBean>();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		
		try{
			for(PlanViajeInformeDistribBean  planViajeInformeDistribIter :  planViajeInformeDistribList){				
				
				log.debug("inicio :" + planViajeInformeDistribIter.getFechaViaticoEntrada());
				log.debug(">>detalle de alimentacion :" + planViajeInformeDistribIter.getMontoDocumentoAlimentacion());
				log.debug(">>detalle de hospedaje :" + planViajeInformeDistribIter.getMontoDocumentoHospedaje());
				log.debug(">>detalle de movilidad :" + planViajeInformeDistribIter.getMontoDocumentoMovilidad());
				log.debug(">>detalle de traslado :" + planViajeInformeDistribIter.getMontoDocumentoTranslado());
				if(planViajeInformeDistribIter.getMontoDocumentoAlimentacion() > ViaticoConstantes.CERO_INT){
					log.debug(">>Agregando detalle por alimentacion...");
					PlanViajeInformeDistribBean  planViajeInformeDistrib =  new  PlanViajeInformeDistribBean();				
					ConceptoPlanillaViaticosBean conceptoPlanillaViaticos = new ConceptoPlanillaViaticosBean();
					planViajeInformeDistrib.setPlanViajeId(planViajeId);
					planViajeInformeDistrib.setSecuencial(secuencial);				
					Date fechaViatico = formatter.parse(planViajeInformeDistribIter.getFechaViaticoEntrada());
					planViajeInformeDistrib.setFecViatico(fechaViatico);
					planViajeInformeDistrib.setMtoDocumento(planViajeInformeDistribIter.getMontoDocumentoAlimentacion());
					planViajeInformeDistrib.setIndItinerario(ViaticoConstantes.CONCEPTOS_VIATICOS_ALIMENTACION);
					conceptoPlanillaViaticos = conceptoPlanillaViaticosDAO.obtenerConceptoViaticoIndItinerario(ViaticoConstantes.CONCEPTOS_VIATICOS_ALIMENTACION,tipoDestino);
					planViajeInformeDistrib.setCodConcepto(conceptoPlanillaViaticos.getCodigoConcepto());
					planViajeInformeDistrib.setClasGastGas(conceptoPlanillaViaticos.getClasificadorGasto());
					planViajeInformeDistrib.setCodConceptoOri(planViajeInformeDistribIter.getCodConceptoOri());
					listaPlanViajeInformeDistrib.add(planViajeInformeDistrib);
				}
				if(planViajeInformeDistribIter.getMontoDocumentoHospedaje() > ViaticoConstantes.CERO_INT){
					log.debug(">>Agregando detalle por hospedaje...");
					PlanViajeInformeDistribBean  planViajeInformeDistrib =  new  PlanViajeInformeDistribBean();				
					ConceptoPlanillaViaticosBean conceptoPlanillaViaticos = new ConceptoPlanillaViaticosBean();
					planViajeInformeDistrib.setPlanViajeId(planViajeId);
					planViajeInformeDistrib.setSecuencial(secuencial);				
					Date fechaViatico = formatter.parse(planViajeInformeDistribIter.getFechaViaticoEntrada());
					planViajeInformeDistrib.setFecViatico(fechaViatico);
					planViajeInformeDistrib.setMtoDocumento(planViajeInformeDistribIter.getMontoDocumentoHospedaje());
					planViajeInformeDistrib.setIndItinerario(ViaticoConstantes.CONCEPTOS_VIATICOS_HOSPEDAJE);
					conceptoPlanillaViaticos = conceptoPlanillaViaticosDAO.obtenerConceptoViaticoIndItinerario(ViaticoConstantes.CONCEPTOS_VIATICOS_HOSPEDAJE,tipoDestino);
					planViajeInformeDistrib.setCodConcepto(conceptoPlanillaViaticos.getCodigoConcepto());
					planViajeInformeDistrib.setClasGastGas(conceptoPlanillaViaticos.getClasificadorGasto());
					planViajeInformeDistrib.setCodConceptoOri(planViajeInformeDistribIter.getCodConceptoOri());
					listaPlanViajeInformeDistrib.add(planViajeInformeDistrib);	
				}
				if(planViajeInformeDistribIter.getMontoDocumentoMovilidad() > ViaticoConstantes.CERO_INT){
					log.debug(">>Agregando detalle por movilidad...");
					PlanViajeInformeDistribBean  planViajeInformeDistrib =  new  PlanViajeInformeDistribBean();				
					ConceptoPlanillaViaticosBean conceptoPlanillaViaticos = new ConceptoPlanillaViaticosBean();
					planViajeInformeDistrib.setPlanViajeId(planViajeId);
					planViajeInformeDistrib.setSecuencial(secuencial);				
					Date fechaViatico = formatter.parse(planViajeInformeDistribIter.getFechaViaticoEntrada());
					planViajeInformeDistrib.setFecViatico(fechaViatico);
					planViajeInformeDistrib.setMtoDocumento(planViajeInformeDistribIter.getMontoDocumentoMovilidad());
					planViajeInformeDistrib.setIndItinerario(ViaticoConstantes.CONCEPTOS_VIATICOS_MOVILIDAD_LOCAL);
					conceptoPlanillaViaticos = conceptoPlanillaViaticosDAO.obtenerConceptoViaticoIndItinerario(ViaticoConstantes.CONCEPTOS_VIATICOS_MOVILIDAD_LOCAL,tipoDestino);
					planViajeInformeDistrib.setCodConcepto(conceptoPlanillaViaticos.getCodigoConcepto());
					planViajeInformeDistrib.setClasGastGas(conceptoPlanillaViaticos.getClasificadorGasto());
					planViajeInformeDistrib.setCodConceptoOri(planViajeInformeDistribIter.getCodConceptoOri());
					listaPlanViajeInformeDistrib.add(planViajeInformeDistrib);}
				if(planViajeInformeDistribIter.getMontoDocumentoTranslado() > ViaticoConstantes.CERO_INT){
					log.debug(">>Agregando detalle por traslado...");
					PlanViajeInformeDistribBean  planViajeInformeDistrib =  new  PlanViajeInformeDistribBean();				
					ConceptoPlanillaViaticosBean conceptoPlanillaViaticos = new ConceptoPlanillaViaticosBean();
					planViajeInformeDistrib.setPlanViajeId(planViajeId);
					planViajeInformeDistrib.setSecuencial(secuencial);				
					Date fechaViatico = formatter.parse(planViajeInformeDistribIter.getFechaViaticoEntrada());
					planViajeInformeDistrib.setFecViatico(fechaViatico);
					planViajeInformeDistrib.setMtoDocumento(planViajeInformeDistribIter.getMontoDocumentoTranslado());
					planViajeInformeDistrib.setIndItinerario(ViaticoConstantes.CONCEPTOS_VIATICOS_TRASLADOS_AL_DEL);
					conceptoPlanillaViaticos = conceptoPlanillaViaticosDAO.obtenerConceptoViaticoIndItinerario(ViaticoConstantes.CONCEPTOS_VIATICOS_TRASLADOS_AL_DEL,tipoDestino);
					planViajeInformeDistrib.setCodConcepto(conceptoPlanillaViaticos.getCodigoConcepto());
					planViajeInformeDistrib.setClasGastGas(conceptoPlanillaViaticos.getClasificadorGasto());
					planViajeInformeDistrib.setCodConceptoOri(planViajeInformeDistribIter.getCodConceptoOri());
					listaPlanViajeInformeDistrib.add(planViajeInformeDistrib);
				}
						
			}
			
			log.debug("Tamaño de lista del plan viaje distribuido:"+listaPlanViajeInformeDistrib.size());
			
			//La lista que envía el usuario al registrar un comprobante está vacía por que el concepto no es ni 01 ni 12, aquí hay que registrar una plan viaje por default
			if(CollectionUtils.isEmpty(listaPlanViajeInformeDistrib)){
			
				if(!(ViaticoConstantes.CONCEPTO_VIATICO_CODI_CONC_PVI_FIJO_NACIONAL.equals(planViajeRendicion.getConceptoId())) &&
						!(ViaticoConstantes.CONCEPTO_VIATICO_CODI_CONC_PVI_FIJO_INTERNACIONAL.equals(planViajeRendicion.getConceptoId()))){
					
					PlanViajeInformeDistribBean  planViajeInformeDistrib =  new  PlanViajeInformeDistribBean();				
					ConceptoPlanillaViaticosBean conceptoPlanillaViaticos = new ConceptoPlanillaViaticosBean();
					planViajeInformeDistrib.setPlanViajeId(planViajeId);
					planViajeInformeDistrib.setSecuencial(secuencial);				
					
					//Date fechaViatico = formatter.parse(planViajeInformeDistribIter.getFechaViaticoEntrada());
					planViajeInformeDistrib.setFecViatico(planViajeRendicion.getFechaDocumento());
					planViajeInformeDistrib.setMtoDocumento(planViajeRendicion.getMontoDocumento());
					
					conceptoPlanillaViaticos = conceptoPlanillaViaticosDAO.obtenerConceptoViatico(planViajeRendicion.getConceptoId());
					planViajeInformeDistrib.setCodConcepto(conceptoPlanillaViaticos.getCodigoConcepto());//igual al origen
					planViajeInformeDistrib.setClasGastGas(conceptoPlanillaViaticos.getClasificadorGasto());
					planViajeInformeDistrib.setCodConceptoOri(planViajeRendicion.getConceptoId());//origen
					planViajeInformeDistrib.setIndItinerario(conceptoPlanillaViaticos.getIndItinerario());//tiene indicador de itinerario el concepto?
					listaPlanViajeInformeDistrib.add(planViajeInformeDistrib);
					
				}
			}
			
		}catch (Exception e) {
			log.error("Error registrar formatoPlanViajeInformeDistrib" + e.getMessage(), e);
		}
					
		log.debug(getClass().getName() + " Fin del metodo formatoPlanViajeInformeDistrib");
		return listaPlanViajeInformeDistrib;
	}
	
	/**
	 * Metodo que permite eliminar comprobante de pago.
	 * @author Jorge Ponce.
	 * @param  planViajeId :codigo plan viaje.
	 * @param  secuencial :secuencial del comprobante de pago.
	 * @param  conceptoId :codigo del concepto.
	 * @param  mtoReconocido :monto reconocido/rendido.
	 * @param  codigoPaginaCaller :codigo de pagina que llama al metodo.
	 * @return Codigo de operacion: Exito(00), Error(01).
	 * @see    String
	 * @throws Exception
	 */
	public String eliminarComprobante(String planViajeId, Integer secuencial, String conceptoId, BigDecimal mtoReconocido, String codigoPaginaCaller) throws Exception {
		
		String codigoOperacion = ViaticoConstantes.ERROR_OPERACION;
		PlanViajeInformeDistribBean planViajeInformeDistrib = new PlanViajeInformeDistribBean();
		planViajeInformeDistrib.setPlanViajeId(planViajeId);
		planViajeInformeDistrib.setSecuencial(secuencial);
		planViajeInformeDistribDAO.eliminarPlanViajeInformeDistrib(planViajeInformeDistrib);
		PlanViajeRendicionBean planViajeRendicionBean = new PlanViajeRendicionBean();
		planViajeRendicionBean.setPlanViajeId(planViajeId);
		planViajeRendicionBean.setSecuencial(secuencial);
		planViajeRendicionDAO.eliminarPlanViajeRendicion(planViajeRendicionBean);
		/*Actualizando el monto rendido por comprobante*/
		BigDecimal montoRendido = BigDecimal.ZERO;
		PlanViajeConceptoBean planViajeConceptoAuxBean = planViajeConceptoDAO.obtenerPlanViajeConceptoMonto(planViajeId, conceptoId);
		if (planViajeConceptoAuxBean != null && planViajeConceptoAuxBean.getMontoRendido() != null) {
			montoRendido = new BigDecimal(NumeroUtil.formatearMonedaMontoToDecimal(null, 2, planViajeConceptoAuxBean.getMontoRendido()));
		}
		montoRendido = montoRendido.subtract(mtoReconocido);
		String montoRendidoFormateado = NumeroUtil.formatearMonedaMontoToDecimal(null, 2, montoRendido);
		
		if (ViaticoConstantes.PAGE_CALLER_REGISTRAR_RENDICION.equals(codigoPaginaCaller)) {
			/*Actualizando el monto rendido por comprobante*/
			PlanViajeConceptoBean planViajeConceptoBean = new PlanViajeConceptoBean();
			planViajeConceptoBean.setPlanViajeID(planViajeId);
			planViajeConceptoBean.setConceptoID(conceptoId);
			planViajeConceptoBean.setMontoRendido(new Double(montoRendidoFormateado));
			planViajeConceptoDAO.actualizarMontoRendidoComprobante(planViajeConceptoBean);
			/*Actualizando el monto devuelto por voucher*/
			BigDecimal montoDepositado =  papeletaDepositoDAO.obtenerMontoDepositado(planViajeId);
			actualizarMontoDevueltoVoucher(planViajeId, montoDepositado);
		}
		else if (ViaticoConstantes.PAGE_CALLER_SUSTENTAR_GASTO.equals(codigoPaginaCaller)) {
			if (conceptoId != null && !ViaticoConstantes.CONCEPTO_VIATICO_CODI_CONC_PVI_FIJO_NACIONAL.equals(conceptoId) && !ViaticoConstantes.CONCEPTO_VIATICO_CODI_CONC_PVI_FIJO_INTERNACIONAL.equals(conceptoId)) {
				int resultado = montoRendido.compareTo(BigDecimal.ZERO);
				if (resultado == 0) {
					/*Eliminamos el concepto, ya que el monto rendido por comprobante es cero*/
					planViajeConceptoDAO.eliminarPlanViajeConceptos(planViajeId, conceptoId);
				}
				else {
					/*Actualizando el monto, monto rendido por comprobante*/
					PlanViajeConceptoBean planViajeConceptoBean = new PlanViajeConceptoBean();
					planViajeConceptoBean.setPlanViajeID(planViajeId);
					planViajeConceptoBean.setConceptoID(conceptoId);
					planViajeConceptoBean.setMonto(new Double(montoRendidoFormateado));
					planViajeConceptoBean.setMontoRendido(new Double(montoRendidoFormateado));
					planViajeConceptoDAO.actualizarPlanViajeConcepto(planViajeConceptoBean);
				}
			}
			else {
				/*Actualizando el monto rendido por comprobante*/
				PlanViajeConceptoBean planViajeConceptoBean = new PlanViajeConceptoBean();
				planViajeConceptoBean.setPlanViajeID(planViajeId);
				planViajeConceptoBean.setConceptoID(conceptoId);
				planViajeConceptoBean.setMontoRendido(new Double(montoRendidoFormateado));
				planViajeConceptoDAO.actualizarMontoRendidoComprobante(planViajeConceptoBean);
			}
		}
		codigoOperacion = ViaticoConstantes.EXITO_OPERACION;
		return codigoOperacion;
	}
	
	/**
	 * Metodo que permite actualizar el monto devuelto por voucher una vez distribuido.
	 * @author Jorge Ponce.
	 * @param  codigoPlanViaje :codigo plan viaje.
	 * @param  montoDepositado :monto depositado.
	 * @return Listado plan viaje concepto.
	 * @see    PlanViajeConceptoBean
	 * @throws Exception
	 */
	public void actualizarMontoDevueltoVoucher(String codigoPlanViaje, BigDecimal montoDepositado) throws Exception {
		ArrayList<PlanViajeConceptoBean> planViajeConceptoList = distribuirMontoDepositado(codigoPlanViaje, montoDepositado);
		if (planViajeConceptoList != null && !planViajeConceptoList.isEmpty()) {
			log.debug("Cantidad de conceptos a actualizar :"+planViajeConceptoList.size());
			for (PlanViajeConceptoBean planViajeConceptoBean : planViajeConceptoList) {
				planViajeConceptoDAO.actualizarMontoDevueltoVoucher(planViajeConceptoBean);
			}
		}
	}
	
	/**
	 * Metodo que permite distribuir el monto depositado en plan viaje concepto.
	 * @author Jorge Ponce.
	 * @param  codigoPlanViaje :codigo plan viaje.
	 * @param  montoDepositado :monto depositado.
	 * @return Listado plan viaje concepto.
	 * @see    PlanViajeConceptoBean
	 * @throws Exception
	 */
	private ArrayList<PlanViajeConceptoBean> distribuirMontoDepositado(String codigoPlanViaje, BigDecimal montoDepositado) throws Exception {
		log.debug("Inicio de distribución de conceptos...");
		ArrayList<PlanViajeConceptoBean> planViajeConceptoList = planViajeConceptoDAO.obtenerPlanViajeConceptoToRendicion(codigoPlanViaje);
		ArrayList<PlanViajeConceptoBean> planViajeConceptoAuxList = null;
		if (planViajeConceptoList != null && !planViajeConceptoList.isEmpty()) {
			planViajeConceptoAuxList = new ArrayList<PlanViajeConceptoBean>();
			BigDecimal montoDistribuir = montoDepositado;
			for (PlanViajeConceptoBean planViajeConceptoBean : planViajeConceptoList) {
				BigDecimal montoEntregado = BigDecimal.ZERO;
				BigDecimal montoRendido = BigDecimal.ZERO;
				BigDecimal montoDevueltoRIC = BigDecimal.ZERO;
				BigDecimal montoDevuelto = BigDecimal.ZERO;
				String montoDevueltoFormateado;
				int resultado;
				if (planViajeConceptoBean.getMonto() != null) {
					montoEntregado = montoEntregado.add(new BigDecimal(planViajeConceptoBean.getMonto()));
				}
				
				if (planViajeConceptoBean.getMontoRendido() != null) {
					montoRendido = montoRendido.add(new BigDecimal(planViajeConceptoBean.getMontoRendido()));
				}
				
				if (planViajeConceptoBean.getMontoRic() != null) {
					montoDevueltoRIC = montoDevueltoRIC.add(new BigDecimal(planViajeConceptoBean.getMontoRic()));
				}
				
				resultado = montoDistribuir.compareTo(montoEntregado.subtract(montoRendido).subtract(montoDevueltoRIC));
				if (resultado == -1 || resultado == 0) {
					montoDevuelto = montoDistribuir;
					montoDistribuir = BigDecimal.ZERO;
				}
				else {
					montoDevuelto = montoEntregado.subtract(montoRendido).subtract(montoDevueltoRIC);
					montoDistribuir = montoDistribuir.subtract(montoEntregado.subtract(montoRendido).subtract(montoDevueltoRIC));
				}
				montoDevueltoFormateado = NumeroUtil.formatearMonedaMontoToDecimal(null, 2, montoDevuelto);
				planViajeConceptoBean.setMontoDevuelto(new Double(montoDevueltoFormateado));
				planViajeConceptoAuxList.add(planViajeConceptoBean);
			}
		}
		return planViajeConceptoAuxList;
	}
	
}
