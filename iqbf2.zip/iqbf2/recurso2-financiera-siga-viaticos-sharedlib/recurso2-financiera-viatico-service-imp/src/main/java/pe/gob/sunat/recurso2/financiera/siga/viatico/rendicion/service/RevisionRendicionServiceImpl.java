package pe.gob.sunat.recurso2.financiera.siga.viatico.rendicion.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;

import pe.gob.sunat.recurso2.administracion.siga.expediente.util.ExpedienteConstantes;
import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.T01ParametroBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.administracion.siga.util.FechaUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.FormatoUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.NumeroUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.SolicitudDTO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoConsultaService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoExpedienteService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoGeneralService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoMensajeriaService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.RendicionConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;

/**
 * Implementacion de la interface RevisionRendicionService, contiene los metodos para la revision de una rendicion.
 * @author Jorge Ponce.
 */
public class RevisionRendicionServiceImpl implements RevisionRendicionService {
	
	protected final Log log = LogFactory.getLog(getClass());
	private ViaticoConsultaService viaticoConsultaService;
	private ViaticoMensajeriaService viaticoMensajeriaService;
	private PlanViajeDAO planViajeDAO;
	
	private ViaticoExpedienteService viaticoExpedienteService;
	private RegistroPersonalService registroPersonalService;
	private ViaticoGeneralService viaticoGeneralService;
	
	public ViaticoConsultaService getViaticoConsultaService() {
		return viaticoConsultaService;
	}

	public void setViaticoConsultaService(ViaticoConsultaService viaticoConsultaService) {
		this.viaticoConsultaService = viaticoConsultaService;
	}

	public ViaticoMensajeriaService getViaticoMensajeriaService() {
		return viaticoMensajeriaService;
	}

	public void setViaticoMensajeriaService(ViaticoMensajeriaService viaticoMensajeriaService) {
		this.viaticoMensajeriaService = viaticoMensajeriaService;
	}

	public PlanViajeDAO getPlanViajeDAO() {
		return planViajeDAO;
	}

	public void setPlanViajeDAO(PlanViajeDAO planViajeDAO) {
		this.planViajeDAO = planViajeDAO;
	}

	/**
	 * Metodo que permite anular el envio de una solicitud.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @return Codigo de operacion: Exito(00) - Error(01).
	 * @see    String
	 * @throws Exception
	 */
	public String anularEnvioPlanViaje(String codPlanViaje, String nroRegistro) throws Exception {
		
		String codigoOperacion = RendicionConstantes.ERROR_OPERACION;
		PlanViajeBean planViajeBean = new PlanViajeBean();
		planViajeBean.setCodPlanViaje(codPlanViaje);
		planViajeBean.setCodEstadoRend(RendicionConstantes.ESTADO_RENDICION_PENDIENTE);
		planViajeDAO.anularEnvioPlanViaje(planViajeBean);
		codigoOperacion = RendicionConstantes.EXITO_OPERACION;
		
		//JMCR-ME-ACCION_ANULAR
		
		/*String codigoProceso, 
		String numeroExpediente, 
		String codigoAccion, 
		String codigoEstado,
		String codigoColaborador, 
		String observacion, 
		String codigoSede*/
		
		PlanViajeBean planViajeAuxBean = planViajeDAO.obtenerNumeroExpediente(codPlanViaje);
		String expedienteRendicion = planViajeAuxBean.getExpedienteRendicion();
		String observacion = ViaticoConstantes.EXPEDIENTE_ANULACION_RENDICION_MENSAJE;
		
		//PlanViajeBean planViaje = planViajeDAO.obtenerPlanViajeToRendicion(codPlanViaje);
		MaestroPersonalBean mp = registroPersonalService.obtenerPersonaxRegistro(nroRegistro);//MaestroPersonalBean mp = registroPersonalService.obtenerPersonaxCodigo(planViaje.getCodTrabajador());
		
		viaticoExpedienteService.crearAccion(
				ExpedienteConstantes.CODIGO_PROCESO_VIATICO_RENDICION, 
				expedienteRendicion, 
				"001", //accion anulado 
				"003", // estado anulado 
				mp.getCodigoEmpleado(), 
				observacion,
				mp.getCodigoSede());

		//JMCR-ME-ACCION_ANULAR
		
		return codigoOperacion;
	}
	
	/**
	 * Metodo que permite reprogramar la fecha de rendicion.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @param  fecMaxRend :fecha maxima de rendicion.
	 * @param  descripcionJustRep :justtificacion de la reprogramacion.
	 * @return Codigo de operacion: Exito(00) - Error(01).
	 * @see    String
	 * @throws Exception
	 */
	public String reprogramarFechaRendicion(String codPlanViaje, Date fecReprog, String descripcionJustRep, String codEmpReprog, String userModi, Date fechModi) throws Exception {
		
		log.debug("reprogramarFechaRendicion en el service");
		
		String codigoOperacion = RendicionConstantes.ERROR_OPERACION;
		PlanViajeBean planViajeBean = new PlanViajeBean();
		planViajeBean.setCodPlanViaje(codPlanViaje);
		//planViajeBean.setFecMaxRend(fecMaxRend);
		planViajeBean.setDescripcionJustRep(descripcionJustRep);
		//JMCR-ME Fecha Reprogramacion
		planViajeBean.setFecReprog(fecReprog);
		planViajeBean.setCodEmpReprog(codEmpReprog);
		planViajeBean.setUserModi(userModi);
		planViajeBean.setFechModi(fechModi);
		//JMCR-ME Fecha Reprogramacion
		planViajeDAO.reprogramarFechaRendicion(planViajeBean);
		codigoOperacion = RendicionConstantes.EXITO_OPERACION;

				
		//JMCR-ME Fecha Reprogramacion
		
		/*String codigoProceso, 
		String numeroExpediente, 
		String codigoAccion, 
		String codigoEstado,
		String codigoColaborador, 
		String observacion, 
		String codigoSede*/
		
		PlanViajeBean planViajeAuxBean = planViajeDAO.obtenerNumeroExpediente(codPlanViaje);
		String expedienteRendicion = planViajeAuxBean.getExpedienteRendicion();
		String observacion = ViaticoConstantes.EXPEDIENTE_REPROGRAMACION_RENDICION_MENSAJE;
		String observacionCreacion = ViaticoConstantes.EXPEDIENTE_REGISTRO_RENDICION_MENSAJE;
		
		//PlanViajeBean planViaje = planViajeDAO.obtenerPlanViajeToRendicion(codPlanViaje);
		MaestroPersonalBean mp = registroPersonalService.obtenerPersonaxRegistro(codEmpReprog);
		//MaestroPersonalBean mp = registroPersonalService.obtenerPersonaxCodigo(planViaje.getCodTrabajador());
		
		//SIGA.PA_EXPEDIENTES.sp_crear_acc(<Nro_expediente> ,'418','002’, sSede, sUsuario, '004', sNomPersona_Accion )	
		
		if (expedienteRendicion == null || (RendicionConstantes.CADENA_VACIA.equals(expedienteRendicion))) {
			expedienteRendicion = viaticoExpedienteService.crearExpediente(ExpedienteConstantes.CODIGO_PROCESO_VIATICO_RENDICION, codPlanViaje, mp.getCodigoEmpleado(), mp.getCodigoSede());
			viaticoExpedienteService.crearAccion(ExpedienteConstantes.CODIGO_PROCESO_VIATICO_RENDICION, expedienteRendicion, ExpedienteConstantes.ESTADO_ACCION_001_CONFORME, ExpedienteConstantes.ACCION_VIATICO_RENDICION_REGISTRADA, mp.getCodigoEmpleado(), observacionCreacion, mp.getCodigoSede());
			planViajeDAO.actualizarNumeroExpedienteToRegistroRendicion(codPlanViaje, expedienteRendicion);
		}
		
		viaticoExpedienteService.crearAccion(
				ExpedienteConstantes.CODIGO_PROCESO_VIATICO_RENDICION, 
				expedienteRendicion, 
				ExpedienteConstantes.ACCION_VIATICO_RENDICION_REGISTRADA, //accion anulado 
				ExpedienteConstantes. ESTADO_ACCION_004_CONFORME, // estado anulado 
				mp.getCodigoEmpleado(), 
				observacion,
				mp.getCodigoSede());

		//JMCR-ME Fecha Reprogramacion		
		
		return codigoOperacion;
		
	}
	
	/**
	 * Metodo que permite obtener el listado de plan de viaje que se van a mostrar en la bandeja de notificacion de rendicion.
	 * @author Jorge Ponce.
	 * @param  codigoDependencia :codigo de dependencia.
	 * @param  indicadorCanalAtencion :indicador canal de atencion.
	 * @param  fechaHasta :fecha hasta.
	 * @return Listado de plan de viaje.
	 * @see    PlanViajeBean
	 * @throws DataAccessException
	 */
	public ArrayList<PlanViajeBean> obtenerPlanViajeToBandejaNotificacionRendicion(String codigoDependencia, String indicadorCanalAtencion, Date fechaHasta) throws Exception {
		
		//Obtener los días habíles desde el parámetro
		T01ParametroBean parametro = viaticoGeneralService.obtenerParametroViatico(ViaticoConstantes.DIAS_SEGUNDA_NOTIFICACION_CODIGO_PARAMETRO, ViaticoConstantes.DIAS_SEGUNDA_NOTIFICACION);
		
		Integer dias = new Integer(parametro.getDesc_abrv())+1;//el parámetro es un valor entero
		
		ArrayList<PlanViajeBean> planViajeList = planViajeDAO.obtenerPlanViajeToBandejaNotificacionRendicion(codigoDependencia, indicadorCanalAtencion, fechaHasta,dias);
		ArrayList<PlanViajeBean> planViajeListAux = null;
		if (planViajeList != null && !planViajeList.isEmpty()) {
			planViajeListAux = new ArrayList<PlanViajeBean>();
			for (PlanViajeBean planViajeBean : planViajeList) {
				BigDecimal montoMenorGasto = BigDecimal.ZERO;
				planViajeBean.setFecMaxRendFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecMaxRend()));
				planViajeBean.setFechaNotificacionFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFechaNotificacion()));
				planViajeBean.setCanalAtencion(FormatoUtil.getUppperCaseText(planViajeBean.getCanalAtencion()));
				planViajeBean.setMtoTotalFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getMtoTotal(), 2));
				planViajeBean.setMontoDevueltoFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getMontoDevuelto(), 2));
				planViajeBean.setMontoDevolFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getMontoDevol(), 2));
				if (RendicionConstantes.INDICADOR_MEN_GAST_SI.equals(planViajeBean.getIndicadorMenorGasto())) {
					if (planViajeBean.getMtoTotal() != null) {
						montoMenorGasto = montoMenorGasto.add(new BigDecimal(planViajeBean.getMtoTotal()));
					}
					if (planViajeBean.getMontoDevuelto() != null) {
						montoMenorGasto = montoMenorGasto.subtract(new BigDecimal(planViajeBean.getMontoDevuelto()));
					}
					planViajeBean.setMontoMenorGastoFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), montoMenorGasto, 2));
				}
				else {
					planViajeBean.setMontoMenorGastoFormateado(RendicionConstantes.CADENA_VACIA);
				}
				planViajeListAux.add(planViajeBean);
			}
		}
		return planViajeListAux;
	}
	
	/**
	 * Metodo que permite enviar la segunda notificacion a un listado de rendiciones.
	 * @author Jorge Ponce.
	 * @param  planViajeList :Listado de plan viaje a ser notificadas.
	 * @return Codigo de operacion: Exito(00) - Error(01).
	 * @see    String
	 * @throws Exception
	 */
	public String enviarSegundaNotificacionRendicion(ArrayList<PlanViajeBean> planViajeList,  String codEmpNotif) throws Exception {
		
		try {
		
		String codigoOperacion = RendicionConstantes.ERROR_OPERACION;
		if (planViajeList != null && !planViajeList.isEmpty()) {
			for (PlanViajeBean planViajeBean : planViajeList) {
				planViajeDAO.enviarSegundaNotificacionRendicion(planViajeBean);
					
					//JMCR-ME Fecha accion 2da notificacion
									
					PlanViajeBean planViajeAuxBean = planViajeDAO.obtenerNumeroExpediente(planViajeBean.getCodPlanViaje());
					String expedienteRendicion = planViajeAuxBean.getExpedienteRendicion();
					String observacion = ViaticoConstantes.EXPEDIENTE_SEGUNDA_NOTIFICACION_RENDICION;
					String observacionCreacion = ViaticoConstantes.EXPEDIENTE_REGISTRO_RENDICION_MENSAJE;
					
					MaestroPersonalBean mp = registroPersonalService.obtenerPersonaxRegistro(codEmpNotif);
					
					//SIGA.PA_EXPEDIENTES.sp_crear_acc(<Nro_expediente> ,'418','002’, sSede, sUsuario, '004', sNomPersona_Accion )	
					if (expedienteRendicion == null || (RendicionConstantes.CADENA_VACIA.equals(expedienteRendicion))) {
						expedienteRendicion = viaticoExpedienteService.crearExpediente(ExpedienteConstantes.CODIGO_PROCESO_VIATICO_RENDICION, planViajeBean.getCodPlanViaje(), mp.getCodigoEmpleado(), mp.getCodigoSede());
						viaticoExpedienteService.crearAccion(ExpedienteConstantes.CODIGO_PROCESO_VIATICO_RENDICION, expedienteRendicion, ExpedienteConstantes.ESTADO_ACCION_001_CONFORME, ExpedienteConstantes.ACCION_VIATICO_RENDICION_REGISTRADA, mp.getCodigoEmpleado(), observacionCreacion, mp.getCodigoSede());
						planViajeDAO.actualizarNumeroExpedienteToRegistroRendicion(planViajeBean.getCodPlanViaje(), expedienteRendicion);
					}
					
					//SIGA.PA_EXPEDIENTES.sp_crear_acc(<Nro_expediente> ,‘418’,’001’, sSede, sUsuario, ‘005’, sNomPersona_Accion )
					viaticoExpedienteService.crearAccion(
							ExpedienteConstantes.CODIGO_PROCESO_VIATICO_RENDICION, 
							expedienteRendicion, 
							ExpedienteConstantes.ACCION_VIATICO_RENDICION_REGISTRADA, //accion anulado 
							ExpedienteConstantes.ESTADO_ACCION_005_ANULADO, // estado 2da notificacion 
							mp.getCodigoEmpleado(), 
							observacion,
							mp.getCodigoSede());
	
					//JMCR-ME Fecha accion 2da notificacion
					
				/*Enviar Notificacion*/
				SolicitudDTO solicitudDTO = viaticoConsultaService.obtenerPlanViajeToNotificacion(planViajeBean.getCodPlanViaje());
				viaticoMensajeriaService.enviarNotificacioSegundaNotificacion(solicitudDTO);
			}
			codigoOperacion = RendicionConstantes.EXITO_OPERACION;
		}
		return codigoOperacion;
		}
		catch (Exception e) {
			log.error("error", e);
			throw e;
		}
	}

	public ViaticoExpedienteService getViaticoExpedienteService() {
		return viaticoExpedienteService;
	}

	public void setViaticoExpedienteService(
			ViaticoExpedienteService viaticoExpedienteService) {
		this.viaticoExpedienteService = viaticoExpedienteService;
	}

	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(
			RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}

	public ViaticoGeneralService getViaticoGeneralService() {
		return viaticoGeneralService;
	}

	public void setViaticoGeneralService(ViaticoGeneralService viaticoGeneralService) {
		this.viaticoGeneralService = viaticoGeneralService;
	}
	
}
