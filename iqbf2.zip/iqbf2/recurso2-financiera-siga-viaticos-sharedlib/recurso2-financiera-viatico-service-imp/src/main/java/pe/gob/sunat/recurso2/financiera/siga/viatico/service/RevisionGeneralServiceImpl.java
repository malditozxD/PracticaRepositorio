package pe.gob.sunat.recurso2.financiera.siga.viatico.service;

// TODO/FIXME: esta clase esta vacia, eliminar si corresponde.
public class RevisionGeneralServiceImpl implements RevisionGeneralService {

}
