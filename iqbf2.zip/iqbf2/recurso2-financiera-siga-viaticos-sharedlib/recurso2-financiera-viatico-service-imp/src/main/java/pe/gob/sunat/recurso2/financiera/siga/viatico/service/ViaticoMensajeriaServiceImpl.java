package pe.gob.sunat.recurso2.financiera.siga.viatico.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.recurso2.administracion.siga.mensajeria.model.bean.SysMensajeriaBean;
import pe.gob.sunat.recurso2.administracion.siga.mensajeria.model.bean.SysMensajeriaDestinosBean;
import pe.gob.sunat.recurso2.administracion.siga.mensajeria.service.RegistroMensajeriaService;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroDependenciasService;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.administracion.siga.util.FechaUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.FormatoUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.SolicitudDTO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.service.ConsultaSolicitudService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.MensajeriaConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ResourceBundleUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;

public class ViaticoMensajeriaServiceImpl implements ViaticoMensajeriaService {

	protected final Log log = LogFactory.getLog(getClass());

	private RegistroPersonalService registroPersonalService;
	private RegistroMensajeriaService registroMensajeriaService;
	private RegistroDependenciasService registroDependenciasService;
	private ConsultaSolicitudService consultaSolicitudService;
	private ViaticoConsultaService viaticoConsultaService;

	public RegistroMensajeriaService getRegistroMensajeriaService() {
		return registroMensajeriaService;
	}

	public void setRegistroMensajeriaService(RegistroMensajeriaService registroMensajeriaService) {
		this.registroMensajeriaService = registroMensajeriaService;
	}

	public RegistroDependenciasService getRegistroDependenciasService() {
		return registroDependenciasService;
	}

	public void setRegistroDependenciasService(RegistroDependenciasService registroDependenciasService) {
		this.registroDependenciasService = registroDependenciasService;
	}

	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}

 
	/**
	 * Metodo que permite enviar correo: notificacion envio solicitud para registro de solicitud (ANEXO 01)
	 * 
	 * @author Rocio Paz
	 * @param  solicitudDTO : solicitudDTO datos de la solicitud de viatico
	 * @throws Exception
	 */
	
	public void enviarNotificacionRegistroSolicitud(SolicitudDTO solicitudDTO){
		 try {
             if (solicitudDTO != null && solicitudDTO.getPlanViajeBean() != null &&  solicitudDTO.getColaborador() != null && solicitudDTO.getRegistrador() != null) {
                             
            	 			 String codPlanilla = solicitudDTO.getPlanViajeBean().getCodPlanilla();
                             String fechaSalida = solicitudDTO.getPlanViajeBean().getFecSalidaFormateada();
                             String fechaRetorno = solicitudDTO.getPlanViajeBean().getFecRetornoFormateada();
                             String nombreColaborador = FormatoUtil.getUppperCaseText(solicitudDTO.getColaborador().getNombreCompleto());
                             String emailColaborador = StringUtils.trimToEmpty(solicitudDTO.getColaborador().getCorreoElectronico());                                                      
                             
                             if(!(solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado()))){
                            	 String bodyMessage = obtenerMensajeNotificacionRegistroSolicitud(codPlanilla, fechaSalida, fechaRetorno, nombreColaborador);
                                 Long numberMessage = createMessage(MensajeriaConstantes.CODIGO_REGISTRO_SOLICITUD, MensajeriaConstantes.ASUNTO_NOTIFICACION_REGISTRO_SOLICITUD, bodyMessage);
	                        	  if(StringUtils.isNotEmpty(emailColaborador) && StringUtils.isNotEmpty(nombreColaborador)){
                                 	addAddresSee(numberMessage, emailColaborador, nombreColaborador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
                                 	sendMessage(numberMessage);}
	                         }                             
                             
             } 

			} catch (Exception e) {
			             log.error(e.getMessage(), e);
			}
			
}

	/**
	 * Metodo que permite obtener el mensaje cuando se envia notificacion   (ANEXO 01)
	
	 * @author Rocio Paz
	 * @param codPlanilla :codigo de la planilla.
	 * @param fechaSalida : fecha salida.
	 * @param fechaRetorno : fecha retorno.
	 * @param nombreColaborador : nombre colaborador.
	 * @see String
	 */
	
	
	
	private String obtenerMensajeNotificacionRegistroSolicitud(String codPlanilla, String fechaSalida, String fechaRetorno, String nombreColaborador) {
		  
		    String tituloMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_REGISTRO_SOLICITUD_TITULO);
			String cuerpoMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_REGISTRO_SOLICITUD_CUERPO, nombreColaborador, codPlanilla, fechaSalida, fechaRetorno);
			StringBuilder mensaje = new StringBuilder();
			mensaje.append(ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_CUERPO_1, tituloMensaje, cuerpoMensaje));
			//mensaje.append(ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_CUERPO_2, MensajeriaConstantes.ASUNTO_NOTIFICACION_REGISTRO_SOLICITUD));
			return mensaje.toString();
}
	
	
	/**
	 * Metodo que permite enviar correo de notificacion al Anulacion de la solicitud(ANEXO 02)
	 * 
	 * @author Rocio Paz
	 * @param solicitudDTO datos para anulacion de la solicitud de viatico
     * @throws Exception	 
	 */	
	
	
	
	public void enviarAnulacionSolicitud(SolicitudDTO solicitudDTO){
		
		 try {
            if (solicitudDTO != null && solicitudDTO.getPlanViajeBean() != null &&  solicitudDTO.getColaborador() != null) {
                            String codPlanilla = solicitudDTO.getPlanViajeBean().getCodPlanilla();
                            String observacionAnulacion = solicitudDTO.getPlanViajeBean().getObservacionAnulacion();                            
                            String nombreColaborador = FormatoUtil.getUppperCaseText(solicitudDTO.getColaborador().getNombreCompleto());
                            String nombreRegistrador = FormatoUtil.getUppperCaseText(solicitudDTO.getRegistrador().getNombreCompleto());
                            String nombreAutorizador = ViaticoConstantes.CADENA_VACIA;
                            if(solicitudDTO.getAutorizador() != null){
                            	if(StringUtils.isNotEmpty(solicitudDTO.getAutorizador().getNombreCompleto()))
                            		nombreAutorizador = "CC: "+FormatoUtil.getUppperCaseText(solicitudDTO.getAutorizador().getNombreCompleto());	
                            }                            
                            String emailColaborador = StringUtils.trimToEmpty(solicitudDTO.getColaborador().getCorreoElectronico());
                            String emailAutorizador = ViaticoConstantes.CADENA_VACIA;
                            if(solicitudDTO.getAutorizador() != null){
                            	if(StringUtils.isNotEmpty(solicitudDTO.getAutorizador().getCorreoElectronico()))
                            		emailAutorizador = StringUtils.trimToEmpty(solicitudDTO.getAutorizador().getCorreoElectronico());
                            }
                            
                            String emailRegistrador = StringUtils.trimToEmpty(solicitudDTO.getRegistrador().getCorreoElectronico());
                                                      
                            //Si la solicitud no está autorizada
                            
                            
                            String bodyMessage =  obtenerAnulacionSolicitud(codPlanilla,nombreColaborador, observacionAnulacion, nombreAutorizador);
                            Long numberMessage = createMessage(MensajeriaConstantes.CODIGO_NOTIFICACION_ANULACION_SOLICITUD_REGISTRADOR_COLABORADOR, MensajeriaConstantes.ASUNTO_NOTIFICACION_ANULACION_SOLICITUD_REGISTRADOR_COLABORADOR, bodyMessage);
                            
                            boolean estado = false;
                            if(solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
	                             if(StringUtils.isNotEmpty(emailColaborador) && StringUtils.isNotEmpty(nombreColaborador) )
                            		addAddresSee(numberMessage, emailColaborador, nombreColaborador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
	                             estado = true;
	                         }else if(!solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
	                        	 if(StringUtils.isNotEmpty(emailRegistrador) && StringUtils.isNotEmpty(nombreRegistrador) )
	                        	  addAddresSee(numberMessage, emailRegistrador, nombreRegistrador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
	                        	 estado = true;
	                        }                          
                            
                            if(solicitudDTO.getAutorizador() != null){
	                            if(StringUtils.isNotEmpty(emailAutorizador)){
	                            	addAddresSee(numberMessage, emailAutorizador, nombreAutorizador, MensajeriaConstantes.TIPO_MENSAJE_CC);
	                            	estado = true;
	                            }
                            }
                            if(estado)
                            	sendMessage(numberMessage);
                            
            }

			} catch (Exception e) {
			             log.error(e.getMessage(), e);
			}
			
}


	
	/**
	 * Metodo que permite enviar correo de la Anulacion de la solicitud(ANEXO 02)
	 * 
	 * @author Rocio Paz
	 * @param solicitudDTO datos de la solicitud de viatico.
     * @param codPlanilla :codigo de la planilla.
     * @param nombreColaborador : nombre colaborador.
	 * @param observacionAnulacion : observacion de la anulacion.
	 * @param nombreAutorizador : nombre autorizador.	
	 * @see String
	 */
	
	private String obtenerAnulacionSolicitud(String codPlanilla,  String nombreColaborador, String observacionAnulacion,String nombreAutorizador) {		  
		  	String tituloMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_ANULACION_SOLICITUD_REGISTRADOR_COLABORADOR_TITULO);
			String cuerpoMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_ANULACION_SOLICITUD_REGISTRADOR_COLABORADOR_CUERPO, nombreColaborador, codPlanilla,observacionAnulacion, nombreAutorizador);
			StringBuilder mensaje = new StringBuilder();
			mensaje.append(ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_CUERPO_1, tituloMensaje, cuerpoMensaje));
			
			return mensaje.toString();
}
	/**
	 * Metodo que permite enviar notificacion cuando se autoriza una solicitud de caja chica.(ANEXO 03)
	 * @author Jorge Ponce.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo.
	 */
	public void enviarNotificacionAutorizacionSolicitudCajaChica(SolicitudDTO solicitudDTO) {

		try {
			if (solicitudDTO != null && solicitudDTO.getPlanViajeBean() != null && solicitudDTO.getColaborador() != null) {
				String codPlanilla = solicitudDTO.getPlanViajeBean().getCodPlanilla();
				String fechaSalida = solicitudDTO.getPlanViajeBean().getFecSalidaFormateada();
				String fechaRetorno = solicitudDTO.getPlanViajeBean().getFecRetornoFormateada();
				String nombreColaborador = FormatoUtil.getUppperCaseText(solicitudDTO.getColaborador().getNombreCompleto());
				String nombreAutorizador = ViaticoConstantes.CADENA_VACIA;
				String emailAutorizador = ViaticoConstantes.CADENA_VACIA;
				if(solicitudDTO.getAutorizador() != null){
					nombreAutorizador = FormatoUtil.getUppperCaseText(solicitudDTO.getAutorizador().getNombreCompleto());
					emailAutorizador = StringUtils.trimToEmpty(solicitudDTO.getAutorizador().getCorreoElectronico());
				}
				
				String emailColaborador = StringUtils.trimToEmpty(solicitudDTO.getColaborador().getCorreoElectronico());
				
				String bodyMessage = obtenerMensajeNotificacionAutorizacionSolicitudCajaChica(codPlanilla, fechaSalida, fechaRetorno, nombreColaborador, nombreAutorizador);
				Long numberMessage = createMessage(MensajeriaConstantes.CODIGO_NOTIFICACION_AUTORIZACION_SOLICITUD_CAJA_CHICA, MensajeriaConstantes.ASUNTO_NOTIFICACION_AUTORIZACION_SOLICITUD_CAJA_CHICA, bodyMessage);
				
				boolean validaDestino = false;
					if(StringUtils.isNotEmpty(emailColaborador) && StringUtils.isNotEmpty(nombreColaborador)){
						addAddresSee(numberMessage, emailColaborador, nombreColaborador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
						validaDestino = true;}
					
					if(StringUtils.isNotEmpty(emailAutorizador) && StringUtils.isNotEmpty(nombreAutorizador)){	
						addAddresSee(numberMessage, emailAutorizador, nombreAutorizador, MensajeriaConstantes.TIPO_MENSAJE_CC);
						validaDestino = true;}
					
					if(validaDestino)
						sendMessage(numberMessage);
				
			}

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	} 

	/**
	 * Metodo que permite obtener el mensaje de la notificacion, cuando se autoriza una solicitud de caja chica(ANEXO 03).
	 * @author Jorge Ponce.
	 * @param  codPlanilla :codigo de planilla.
	 * @param  fechaSalida :fecha salida.
	 * @param  fechaRetorno :fecha retorno.
	 * @param  nombreColaborador :nombre del colaborador.
	 * @param  nombreAutorizador :nombre del autorizador.
	 * @return Mensaje de la notificacion.
	 * @see    String
	 */
	private String obtenerMensajeNotificacionAutorizacionSolicitudCajaChica(String codPlanilla, String fechaSalida, String fechaRetorno, String nombreColaborador, String nombreAutorizador) {

		String tituloMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_AUTORIZACION_TITULO);
		String cuerpoMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_AUTORIZACION_CUERPO, nombreColaborador, codPlanilla, fechaSalida, fechaRetorno, nombreAutorizador);
		StringBuilder mensaje = new StringBuilder();
		mensaje.append(ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_CUERPO_1, tituloMensaje, cuerpoMensaje));
		
		return mensaje.toString();
	}
	/**
	 * Metodo que permite enviar notificacion al confirmar anulacion de solicitud.(ANEXO 04)
	 * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo.
	 * @throws Exception	 
	 */
	public void enviarNotificacionAnulacionSolicitud(SolicitudDTO solicitudDTO) {

		try {
			if (solicitudDTO != null && solicitudDTO.getPlanViajeBean() != null && solicitudDTO.getColaborador() != null && solicitudDTO.getRegistrador() != null) {
				String codPlanilla = solicitudDTO.getPlanViajeBean().getCodPlanilla();
				String fechaSalida = solicitudDTO.getPlanViajeBean().getFecSalidaFormateada();
				String fechaRetorno = solicitudDTO.getPlanViajeBean().getFecRetornoFormateada();
				String nombreColaborador = FormatoUtil.getUppperCaseText(solicitudDTO.getColaborador().getNombreCompleto());
				String nombreRegistrador = FormatoUtil.getUppperCaseText(solicitudDTO.getRegistrador().getNombreCompleto());
				String nombreAutorizador = ViaticoConstantes.CADENA_VACIA;
				if(solicitudDTO.getAutorizador() != null){
                	if(StringUtils.isNotEmpty(solicitudDTO.getAutorizador().getNombreCompleto()))
                		nombreAutorizador = FormatoUtil.getUppperCaseText(solicitudDTO.getAutorizador().getNombreCompleto());
                }
				String emailColaborador = StringUtils.trimToEmpty(solicitudDTO.getColaborador().getCorreoElectronico());
				String emailRegistrador = StringUtils.trimToEmpty(solicitudDTO.getRegistrador().getCorreoElectronico());
				String emailAutorizador = ViaticoConstantes.CADENA_VACIA;
				if(solicitudDTO.getAutorizador() != null){
                	if(StringUtils.isNotEmpty(solicitudDTO.getAutorizador().getCorreoElectronico()))
                		emailAutorizador = StringUtils.trimToEmpty(solicitudDTO.getAutorizador().getCorreoElectronico());
                }			
				
				String motivo = solicitudDTO.getPlanViajeBean().getObservacionAnulacion();
				String bodyMessage = obtenerMensajeNotificacionAnulacionSolicitud(codPlanilla, fechaSalida, fechaRetorno, nombreColaborador, nombreRegistrador, nombreAutorizador,motivo);
				Long numberMessage = createMessage(MensajeriaConstantes.CODIGO_NOTIFICACION_ANULACION_SOLICITUD, MensajeriaConstantes.ASUNTO_NOTIFICACION_ANULACION_SOLICITUD, bodyMessage);
				
				boolean validaDestino = false;
				//Siempre envía al comisionado
				if(StringUtils.isNotEmpty((emailColaborador)) && StringUtils.isNotEmpty((nombreColaborador))){
                	addAddresSee(numberMessage, emailColaborador, nombreColaborador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
		    		validaDestino = true;
		    	}
				
			    //Se envía al registrador, solo si él lo ingresó
				if(!solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
                	if(StringUtils.isNotEmpty((emailRegistrador)) && StringUtils.isNotEmpty((nombreRegistrador)))	
                		{addAddresSee(numberMessage, emailRegistrador, nombreRegistrador, MensajeriaConstantes.TIPO_MENSAJE_CC);
                		validaDestino = true;}               	  
                }                           
				
			    if(solicitudDTO.getAutorizador() != null){
			    	if(StringUtils.isNotEmpty((emailAutorizador)) && StringUtils.isNotEmpty((nombreAutorizador)))
			    		{addAddresSee(numberMessage, emailAutorizador, nombreAutorizador, MensajeriaConstantes.TIPO_MENSAJE_CC);
			    		validaDestino = true;}   	
			    }
			    
			    if(validaDestino)
			    	sendMessage(numberMessage);
			} else {
				throw new Exception();
			}

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	/**
	 * Metodo que permite obtener el mensaje de la notificacion, cuando se anula una solicitud.(ANEXO 04)
	 * @author Rocio Paz.
	 * @param  codPlanilla :codigo de planilla.
	 * @param  fechaSalida :fecha salida.
	 * @param  fechaRetorno :fecha retorno.
	 * @param  nombreColaborador :nombre del colaborador.
	 * @param  nombreRegistrador :nombre del registrador.
	 * @param  nombreAutorizador :nombre del autorizador.
	 * @return Mensaje de la notificacion.
	 * @see    String
	 */
	private String obtenerMensajeNotificacionAnulacionSolicitud(String codPlanilla, String fechaSalida, String fechaRetorno, 
			String nombreColaborador, String nombreRegistrador, String nombreAutorizador, String motivo) {
		String nombre = ViaticoConstantes.CADENA_VACIA;
		
		if(StringUtils.isNotEmpty(nombreColaborador)){
			nombre =  nombreColaborador;
		}else{
			nombre = nombreRegistrador;
		}
		
			
		String tituloMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_ANULACION_TITULO);
		String cuerpoMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_ANULACION_CUERPO, codPlanilla, motivo, fechaSalida, fechaRetorno, nombre, nombreAutorizador);
		StringBuilder mensaje = new StringBuilder();
		mensaje.append(ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_CUERPO_1, tituloMensaje, cuerpoMensaje));
		
		return mensaje.toString();
	}
	
	/**
	 * Metodo que permite enviar notificacion cuando se observa una solicitud.(ANEXO 05)
	 * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo. 
	 * @throws Exception	
	 */
	public void enviarNotificacionObservacionSolicitud(SolicitudDTO solicitudDTO) {

		try {
			if (solicitudDTO != null && solicitudDTO.getPlanViajeBean() != null && solicitudDTO.getColaborador() != null && solicitudDTO.getRegistrador() != null) {
				String codPlanilla = solicitudDTO.getPlanViajeBean().getCodPlanilla();
				String fechaSalida = solicitudDTO.getPlanViajeBean().getFecSalidaFormateada();
				String fechaRetorno = solicitudDTO.getPlanViajeBean().getFecRetornoFormateada();
				String motivoObservacion = solicitudDTO.getPlanViajeBean().getObservacionAutorizador();
				String nombreColaborador = FormatoUtil.getUppperCaseText(solicitudDTO.getColaborador().getNombreCompleto());
				String nombreRegistrador = FormatoUtil.getUppperCaseText(solicitudDTO.getRegistrador().getNombreCompleto());
				String nombreAutorizador = ViaticoConstantes.CADENA_VACIA;
				if(solicitudDTO.getAutorizador() != null){
                	if(StringUtils.isNotEmpty(solicitudDTO.getAutorizador().getNombreCompleto()))
                		nombreAutorizador = FormatoUtil.getUppperCaseText(solicitudDTO.getAutorizador().getNombreCompleto());
                }
				String emailColaborador = StringUtils.trimToEmpty(solicitudDTO.getColaborador().getCorreoElectronico());
				String emailRegistrador = StringUtils.trimToEmpty(solicitudDTO.getRegistrador().getCorreoElectronico());
				String emailAutorizador = ViaticoConstantes.CADENA_VACIA;
				if(solicitudDTO.getAutorizador() != null){
                	if(StringUtils.isNotEmpty(solicitudDTO.getAutorizador().getCorreoElectronico()))
                		 emailAutorizador = StringUtils.trimToEmpty(solicitudDTO.getAutorizador().getCorreoElectronico());
				}
				
				
				String bodyMessage = obtenerMensajeNotificacionObservacionSolicitud(codPlanilla, fechaSalida, fechaRetorno, motivoObservacion, nombreColaborador, nombreRegistrador, nombreAutorizador);
				Long numberMessage = createMessage(MensajeriaConstantes.CODIGO_NOTIFICACION_OBSERVACION_SOLICITUD, MensajeriaConstantes.ASUNTO_NOTIFICACION_OBSERVACION_SOLICITUD, bodyMessage);
				
				boolean validaDestino = false;
				
				//siempre al comisionado...
				if(StringUtils.isNotEmpty(emailColaborador) && StringUtils.isNotEmpty(nombreColaborador)) {
             	   log.debug("colaborador SI");
             	   addAddresSee(numberMessage, emailColaborador, nombreColaborador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
             	   validaDestino = true;
                }
				
			    //Si es que fue ingresado por un registrador, se le copia.
				if(!solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
                   if(StringUtils.isNotEmpty(emailRegistrador) && StringUtils.isNotEmpty(nombreRegistrador)){
                	   log.debug("registrador SI");
                	   addAddresSee(numberMessage, emailRegistrador, nombreRegistrador, MensajeriaConstantes.TIPO_MENSAJE_CC);
                	   validaDestino = true;
                   }
                }       
			    
			    if(solicitudDTO.getAutorizador() != null){
			    	log.debug("autorizador SI");
			    	if(StringUtils.isNotEmpty(emailAutorizador) && StringUtils.isNotEmpty(nombreAutorizador)){
			    	  addAddresSee(numberMessage, emailAutorizador, nombreAutorizador, MensajeriaConstantes.TIPO_MENSAJE_CC);
			    	  validaDestino = true;
			    	}		    	
			    }
			    
			    if(validaDestino)
			    	sendMessage(numberMessage);
				}

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	/**
	 * Metodo que permite obtener el mensaje de la notificacion, cuando se observa una solicitud.(ANEXO 05)
	 * @author Rocio Paz.
	 * @param  codPlanilla :codigo de planilla.
	 * @param  fechaSalida :fecha salida.
	 * @param  fechaRetorno :fecha retorno.
	 * @param  motivoObservacion :motivo de observacion.
	 * @param  nombreColaborador :nombre del colaborador.
	 * @param  nombreRegistrador :nombre del registrador.
	 * @param  nombreAutorizador :nombre del autorizador.
	 * @return Mensaje de la notificacion.
	 * @see    String
	 */
	private String obtenerMensajeNotificacionObservacionSolicitud(String codPlanilla, String fechaSalida, String fechaRetorno, String motivoObservacion, String nombreColaborador, String nombreRegistrador, String nombreAutorizador) {
		String nombre = ViaticoConstantes.CADENA_VACIA;
		if(StringUtils.isNotEmpty(nombreColaborador)){
			nombre = nombreColaborador;
		}else{
			nombre = nombreRegistrador;
		}
		
		String tituloMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_OBSERVACION_TITULO);
		String cuerpoMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_OBSERVACION_CUERPO, codPlanilla,nombre , fechaSalida, fechaRetorno, motivoObservacion, nombre,  nombreAutorizador);
		StringBuilder mensaje = new StringBuilder();
		mensaje.append(ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_CUERPO_1, tituloMensaje, cuerpoMensaje));
		
		return mensaje.toString();
	}

	/**
	 * Metodo que permite enviar correo al observar solicitud reembolso(ANEXO 06)
     * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo. 
	 * @throws Exception	
	 */
	
	public void enviarObservacionSolicitudReembolso(SolicitudDTO solicitudDTO) {

		try {
			if (solicitudDTO != null && solicitudDTO.getPlanViajeBean() != null && solicitudDTO.getColaborador() != null && solicitudDTO.getRegistrador() != null) {
				String codPlanilla = solicitudDTO.getPlanViajeBean().getCodPlanilla();
				String fechaSalida = solicitudDTO.getPlanViajeBean().getFecSalidaFormateada();
				String fechaRetorno = solicitudDTO.getPlanViajeBean().getFecRetornoFormateada();
				String motivoObservacion = solicitudDTO.getPlanViajeBean().getObservacionAutorizador();
				String nombreColaborador = FormatoUtil.getUppperCaseText(solicitudDTO.getColaborador().getNombreCompleto());
				String nombreRegistrador = FormatoUtil.getUppperCaseText(solicitudDTO.getRegistrador().getNombreCompleto());
			
				String emailColaborador = StringUtils.trimToEmpty(solicitudDTO.getColaborador().getCorreoElectronico());
				String emailRegistrador = StringUtils.trimToEmpty(solicitudDTO.getRegistrador().getCorreoElectronico());
		
				
				if(solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
					nombreRegistrador = ViaticoConstantes.CADENA_VACIA;
				}else if(!solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
					nombreColaborador = ViaticoConstantes.CADENA_VACIA;
				}
				
				String bodyMessage =  obtenerObservacionSolicitudReembolso(codPlanilla, fechaSalida, fechaRetorno, motivoObservacion, nombreColaborador, nombreRegistrador);
				Long numberMessage = createMessage(MensajeriaConstantes.CODIGO_OBSERVACION_SOLCITUD_PLANILLA_REEMBOLSO, MensajeriaConstantes.ASUNTO_OBSERVACION_SOLCITUD_PLANILLA_REEMBOLSO, bodyMessage);
				
				boolean validaDestino = false;
			    if(solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
                    if(StringUtils.isNotEmpty(emailColaborador) && StringUtils.isNotEmpty(nombreColaborador))
			    		{addAddresSee(numberMessage, emailColaborador, nombreColaborador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
			    		validaDestino = true;}
                    
                }else if(!solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
                	if(StringUtils.isNotEmpty(emailRegistrador) && StringUtils.isNotEmpty(nombreRegistrador))	
                		{addAddresSee(numberMessage, emailRegistrador, nombreRegistrador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
                		validaDestino = true;}
                }                           
               
              if(validaDestino)
               sendMessage(numberMessage);
				}

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}
	/**
	 * Metodo que permite obtener el mensaje de la notificacion, cuando se observa una solicitud.(ANEXO 06)
	 * @author Rocio Paz.
	 * @param  codPlanilla :codigo de planilla.
	 * @param  fechaSalida :fecha salida.
	 * @param  fechaRetorno :fecha retorno.
	 * @param  motivoObservacion :motivo de observacion.
	 * @param  nombreColaborador :nombre del colaborador.
	 * @param  nombreRegistrador :nombre del registrador.
	 * @return Mensaje de la notificacion.
	 * @see    String
	 */
	private String obtenerObservacionSolicitudReembolso(String codPlanilla, String fechaSalida, String fechaRetorno, String motivoObservacion, String nombreColaborador, String nombreRegistrador) {

		String tituloMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_OBSERVACION_SOLCITUD_PLANILLA_REEMBOLSO_TITULO);
		String cuerpoMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_OBSERVACION_SOLCITUD_PLANILLA_REEMBOLSO_CUERPO, codPlanilla,  fechaSalida, fechaRetorno, motivoObservacion);
		StringBuilder mensaje = new StringBuilder();
		mensaje.append(ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_CUERPO_1, tituloMensaje, cuerpoMensaje));
		
		return mensaje.toString();
	}
	

	/**
	 * Metodo que permite enviar correo de Notificacion por no presentar rendicion de cuenta - primera notificacion (ANEXO 07)
	 * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo. 
	 * @throws Exception	
	 */
	
	public void enviarNotificacionRendicion(SolicitudDTO solicitudDTO) {

		try {
			if (solicitudDTO != null && solicitudDTO.getPlanViajeBean() != null && solicitudDTO.getColaborador() != null && solicitudDTO.getRegistrador() != null) {
				String codPlanilla = solicitudDTO.getPlanViajeBean().getCodPlanilla();
				String FecMaxRendFormateada = solicitudDTO.getPlanViajeBean().getFecMaxRendFormateada();				
				String nombreColaborador = FormatoUtil.getUppperCaseText(solicitudDTO.getColaborador().getNombreCompleto());
				String nombreRegistrador = FormatoUtil.getUppperCaseText(solicitudDTO.getRegistrador().getNombreCompleto());
				
				String nombreAutorizador = ViaticoConstantes.CADENA_VACIA;
				if(solicitudDTO.getAutorizador() != null)
					if(StringUtils.isNotEmpty(solicitudDTO.getAutorizador().getNombreCompleto()))
						nombreAutorizador = FormatoUtil.getUppperCaseText(solicitudDTO.getAutorizador().getNombreCompleto());    
				
				String emailColaborador = StringUtils.trimToEmpty(solicitudDTO.getColaborador().getCorreoElectronico());
				 String emailAutorizador = ViaticoConstantes.CADENA_VACIA;
				if(solicitudDTO.getAutorizador() != null)
					if(StringUtils.isNotEmpty(solicitudDTO.getAutorizador().getCorreoElectronico()))
						emailAutorizador = StringUtils.trimToEmpty(solicitudDTO.getAutorizador().getCorreoElectronico());

				String emailRegistrador = StringUtils.trimToEmpty(solicitudDTO.getRegistrador().getCorreoElectronico());				
		
				if(solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
					nombreRegistrador = ViaticoConstantes.CADENA_VACIA;
				}else if(!solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
					nombreColaborador = ViaticoConstantes.CADENA_VACIA;
				}
				
				String bodyMessage =  obtenerNotificacionRendicion(codPlanilla, FecMaxRendFormateada, nombreColaborador, nombreRegistrador, nombreAutorizador);
				Long numberMessage = createMessage(MensajeriaConstantes.CODIGO_NOTIFICACION_RENDICION_PRIMERA_NOTIFICACION, MensajeriaConstantes.ASUNTO_NOTIFICACION_RENDICION_PRIMERA_NOTIFICACION, bodyMessage);
				
				boolean validaDestino = false;
			    if(solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
			    	if(StringUtils.isNotEmpty(emailColaborador) && StringUtils.isNotEmpty(nombreColaborador)){
			    		addAddresSee(numberMessage, emailColaborador, nombreColaborador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
			    		validaDestino = true;}
                    
                }else if(!solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
                 	
               	   if(StringUtils.isNotEmpty(emailRegistrador) && StringUtils.isNotEmpty(nombreRegistrador))
               	   { addAddresSee(numberMessage, emailRegistrador, nombreRegistrador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
               	   		validaDestino = true;}
               	  /* if(StringUtils.isNotEmpty(emailColaborador) && StringUtils.isNotEmpty(nombreColaborador))
               		   {addAddresSee(numberMessage, emailColaborador, nombreColaborador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
               		   validaDestino = true;}*/
               	  
                }                           
			    if(solicitudDTO.getAutorizador() != null){
			    	if(StringUtils.isNotEmpty(emailAutorizador) && StringUtils.isNotEmpty(nombreAutorizador))
			    		{addAddresSee(numberMessage, emailAutorizador, nombreAutorizador, MensajeriaConstantes.TIPO_MENSAJE_CC);
			    		validaDestino = true;}			    		
			    }
			    if(validaDestino)
			    	sendMessage(numberMessage);
			    	
			} 

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}
	/**
	 * Metodo que permite obtener el mensaje de la notificacion, cuando se envia una solicitud.(ANEXO 07)
	 * @author Rocio Paz.
	 * @param  codPlanilla :codigo de planilla.
	 * @param  FecMaxRendFormateada :fecha maxima de rendición.	 
	 * @param  nombreColaborador :nombre del colaborador.
	 * @param  nombreRegistrador :nombre del registrador.
	 * @param  nombreAutorizador :nombre del autorizador.
	 * @return Mensaje de la notificacion.
	 * @see    String
	 */
	private String obtenerNotificacionRendicion(String codPlanilla, String FecMaxRendFormateada, String nombreColaborador, String nombreRegistrador, String nombreAutorizador) {

		String tituloMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_RENDICION_PRIMERA_NOTIFICACION_TITULO);
		String cuerpoMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_RENDICION_PRIMERA_NOTIFICACION_CUERPO, codPlanilla, FecMaxRendFormateada, nombreAutorizador);
		StringBuilder mensaje = new StringBuilder();
		mensaje.append(ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_CUERPO_1, tituloMensaje, cuerpoMensaje));
		
		return mensaje.toString();
	}
		
	
	
	/**
	 * Metodo que permite enviar correo al confirmar al Notificar por no presentar rendicion de cuenta - segunda notificacion(ANEXO 08)
	 * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo.
	 * @throws Exception
	 */
	public void enviarNotificacioSegundaNotificacion(SolicitudDTO solicitudDTO) throws Exception {
		
		if (solicitudDTO != null && solicitudDTO.getPlanViajeBean() != null && solicitudDTO.getColaborador() != null && solicitudDTO.getRegistrador() != null) {
			String codPlanilla = solicitudDTO.getPlanViajeBean().getCodPlanilla();
			String FecMaxRendFormateada = solicitudDTO.getPlanViajeBean().getFecMaxRendFormateada();	
			String FecNotificacionFormateada = solicitudDTO.getPlanViajeBean().getFecNotificacionFormateada();				
			String nombreColaborador = FormatoUtil.getUppperCaseText(solicitudDTO.getColaborador().getNombreCompleto());
			String nombreRegistrador = FormatoUtil.getUppperCaseText(solicitudDTO.getRegistrador().getNombreCompleto());	
			String nombreAutorizador = ViaticoConstantes.CADENA_VACIA;    
			String emailColaborador = StringUtils.trimToEmpty(solicitudDTO.getColaborador().getCorreoElectronico());				           
			String emailAutorizador = ViaticoConstantes.CADENA_VACIA; 
			String emailRegistrador = StringUtils.trimToEmpty(solicitudDTO.getRegistrador().getCorreoElectronico());				
			
			if(solicitudDTO.getAutorizador() != null){
				nombreAutorizador = FormatoUtil.getUppperCaseText(solicitudDTO.getAutorizador().getNombreCompleto());
				emailAutorizador = StringUtils.trimToEmpty(solicitudDTO.getAutorizador().getCorreoElectronico());
			}
			
			String bodyMessage =  obtenerNotificacioSegundaNotificacion( FecMaxRendFormateada,codPlanilla,FecNotificacionFormateada, nombreColaborador, nombreRegistrador, nombreAutorizador);
			Long numberMessage = createMessage(MensajeriaConstantes.CODIGO_SEGUNDA_NOTIFICACION, MensajeriaConstantes.ASUNTO_SEGUNDA_NOTIFICACION, bodyMessage);
			
			boolean validaDestino = false;
			if(StringUtils.isNotEmpty(emailColaborador) && StringUtils.isNotEmpty(nombreColaborador)){
				addAddresSee(numberMessage, emailColaborador, nombreColaborador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
				validaDestino = true;
			}
			
			//Si es que la solicitud ha sido ingresada por un registrador le copiamos la notificación.
			if (!solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())) {
				if(StringUtils.isNotEmpty(emailRegistrador) && StringUtils.isNotEmpty(nombreRegistrador)){
					addAddresSee(numberMessage, emailRegistrador, nombreRegistrador, MensajeriaConstantes.TIPO_MENSAJE_CC);
					validaDestino = true;
				}
			}
			
			if(StringUtils.isNotEmpty(emailAutorizador) && StringUtils.isNotEmpty(nombreAutorizador)){
				addAddresSee(numberMessage, emailAutorizador, nombreAutorizador, MensajeriaConstantes.TIPO_MENSAJE_CC);
				validaDestino = true;
			}
				
			if(validaDestino)	
				sendMessage(numberMessage);
		}
	}
	
	/**
	 * Metodo que permite obtener el mensaje de la notificacion, cuando se observa una solicitud.(ANEXO 08)
	 * @author Rocio Paz.
	 * @param  FecMaxRendFormateada :fecha maxima de rendición.	 
	 * @param  codPlanilla :codigo de planilla.
	 * @param  FecNotificacionFormateada : fecha de notificacion.
	 * @param  nombreColaborador :nombre del colaborador.
	 * @param  nombreRegistrador :nombre del registrador.
	 * @param  nombreAutorizador :nombre del autorizador.
	 * @return Mensaje de la notificacion.
	 * @see    String
	 */

	private String obtenerNotificacioSegundaNotificacion( String FecMaxRendFormateada,String codPlanilla, String FecNotificacionFormateada, String nombreColaborador, String nombreRegistrador, String nombreAutorizador) {

		log.debug("nombreColaboradorMensaje: "  + nombreColaborador + " nombreRegistrador: " + nombreRegistrador);
		String nombre = ViaticoConstantes.CADENA_VACIA;
		if(StringUtils.isNotEmpty(nombreColaborador)){
			nombre =  nombreColaborador;
		}else if(StringUtils.isNotEmpty(nombreRegistrador)){
			nombre =  nombreRegistrador;
		}
		log.debug("nombreMensaje: "  + nombre );
			
		String tituloMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_SEGUNDA_NOTIFICACION_TITULO);
		String cuerpoMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_SEGUNDA_NOTIFICACION_CUERPO, FecNotificacionFormateada, codPlanilla, FecMaxRendFormateada,nombre, nombreAutorizador);
		StringBuilder mensaje = new StringBuilder();
		mensaje.append(ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_CUERPO_1, tituloMensaje, cuerpoMensaje));
		
		return mensaje.toString();
	}
	
	
	/**
	 * Metodo que permite enviar correo de Notificacion Planilla de Viaticos que no han sido remitidas para la gestion de Pago(ANEXO 09)
	 * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo. 
	 * @throws Exception	
	 */
	public void enviarnotificacionPlanillaVaiticosNoRemitidas(List<SolicitudDTO> solicitudDTOList) throws Exception {

	 if(CollectionUtils.isNotEmpty(solicitudDTOList)){
		for(SolicitudDTO solicitudDTO : solicitudDTOList){ 
			if ( solicitudDTO.getColaborador() != null && solicitudDTO.getRegistrador() != null ) {
								
					String nombreColaborador = FormatoUtil.getUppperCaseText(solicitudDTO.getColaborador().getNombreCompleto());
					String nombreRegistrador = FormatoUtil.getUppperCaseText(solicitudDTO.getRegistrador().getNombreCompleto());	    
					String emailColaborador = StringUtils.trimToEmpty(solicitudDTO.getColaborador().getCorreoElectronico());				           
					String emailRegistrador = StringUtils.trimToEmpty(solicitudDTO.getRegistrador().getCorreoElectronico());
					StringBuilder codigosPlanilla = new StringBuilder();
					codigosPlanilla.append(ViaticoConstantes.UL_INICIO);
					if(CollectionUtils.isNotEmpty(solicitudDTO.getPlanViajeList())){
						for(PlanViajeBean planViaje : solicitudDTO.getPlanViajeList()){
							codigosPlanilla.append( ViaticoConstantes.LI_INICIO);
							codigosPlanilla.append(ViaticoConstantes.TEXTO_PLANILLA + planViaje.getCodPlanilla());
							codigosPlanilla.append( ViaticoConstantes.LI_FIN);
						}
					}
					codigosPlanilla.append(ViaticoConstantes.UL_FIN);
					
					String bodyMessage =  obtenernotificacionPlanillaVaiticosNoRemitidas(codigosPlanilla);
					Long numberMessage = createMessage(MensajeriaConstantes.CODIGO_NOTIFICACION_PLANILLA_VIATICOS_NO_REMITIDAS, MensajeriaConstantes.ASUNTO_NOTIFICACION_PLANILLA_VIATICOS_NO_REMITIDAS, bodyMessage);
					 boolean validaDestino = false; 
						if(solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){		
							if(StringUtils.isNotEmpty(emailColaborador) && StringUtils.isNotEmpty(nombreColaborador)){
								addAddresSee(numberMessage, emailColaborador, nombreColaborador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
								validaDestino = true;
							}				 
						}else if(!solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
							if(StringUtils.isNotEmpty(emailRegistrador) && StringUtils.isNotEmpty(nombreRegistrador)){
								addAddresSee(numberMessage, emailRegistrador, nombreRegistrador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
								validaDestino = true;}
						}
						if(validaDestino){
							sendMessage(numberMessage);}
		}else{
			//log.debug(""solicitudDTO.getNumPlanilla());
		}
			
	  	}
	 }
	 
}
	/**
	 * Metodo que permite obtener el mensaje de la notificacion, cuando se observa una solicitud.(ANEXO 09)
	 * @author Rocio Paz.	
	 * @param  codPlanilla :codigo de planilla.	
	 * @return Mensaje de la notificacion.
	 * @see    String
	 */
	private String obtenernotificacionPlanillaVaiticosNoRemitidas(StringBuilder codigosPlanilla){
		String tituloMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_PLANILLA_VIATICOS_NO_REMITIDAS_TITULO);
		String cuerpoMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_PLANILLA_VIATICOS_NO_REMITIDAS_CUERPO, codigosPlanilla);
		StringBuilder mensaje = new StringBuilder();
		mensaje.append(ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_CUERPO_1, tituloMensaje, cuerpoMensaje));
		
		return mensaje.toString();
	}
	
	/**
	 * Metodo que permite enviar correo de notificacion al registrador para que revise su bandeja de Notificaciones(ANEXO 10)
	 * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo. 
	 * @throws Exception	
	 */
	
		
	
	public void enviarNotificacioAlRegistrador(SolicitudDTO solicitudDTO) {

		try {
			if (solicitudDTO != null && solicitudDTO.getPlanViajeBean() != null && solicitudDTO.getRegistrador() != null ) {
				
				String nombreRegistrador = FormatoUtil.getUppperCaseText(solicitudDTO.getRegistrador().getNombreCompleto());     
              
				String emailRegistrador = StringUtils.trimToEmpty(solicitudDTO.getRegistrador().getCorreoElectronico());				
				String bodyMessage =  obtenerNotificacioAlRegistrador( nombreRegistrador);
				Long numberMessage = createMessage(MensajeriaConstantes.CODIGO_NOTIFICACION_AL_REGISTRADOR, MensajeriaConstantes.ASUNTO_NOTIFICACION_AL_REGISTRADOR, bodyMessage);
				boolean validaDestino = false;
				if(StringUtils.isNotEmpty(emailRegistrador) && StringUtils.isNotEmpty(nombreRegistrador) ){ 
					addAddresSee(numberMessage, emailRegistrador, nombreRegistrador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
					validaDestino = true;
				}				
				if(validaDestino)
					sendMessage(numberMessage);
					
			} 

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}
	/**
	 * Metodo que permite obtener el mensaje de la notificacion, cuando se observa una solicitud.(ANEXO 10)
	 * @author Rocio Paz.	 
	 * @param  nombreRegistrador :nombre del registrador.
	 * @return Mensaje de la notificacion.
	 * @see    String
	 */
	private String obtenerNotificacioAlRegistrador( String nombreRegistrador) {

		String tituloMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_AL_REGISTRADOR_TITULO);
		String cuerpoMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_AL_REGISTRADOR_CUERPO);
		StringBuilder mensaje = new StringBuilder();
		mensaje.append(ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_CUERPO_1, tituloMensaje, cuerpoMensaje));
		
		return mensaje.toString();
	}
	
	
	
	/**
	 * Metodo que permite enviar correo de Notificacion de Cierre de Rendicion al confirmar cerrar (ANEXO 11) 
     * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo. 
	 * @throws Exception	
	 */
	
	public void enviarNotificacionCierreRendicion(SolicitudDTO solicitudDTO) {
		
		try {
			if (solicitudDTO != null && solicitudDTO.getPlanViajeBean() != null && solicitudDTO.getColaborador()!= null && solicitudDTO.getRegistrador() != null) {
				String codPlanilla = solicitudDTO.getPlanViajeBean().getCodPlanilla();
				String nombreColaborador = FormatoUtil.getUppperCaseText(solicitudDTO.getColaborador().getNombreCompleto());     
              
				String emailRegistrador= StringUtils.trimToEmpty(solicitudDTO.getRegistrador().getCorreoElectronico());
				
				String nombreRegistrador = FormatoUtil.getUppperCaseText(solicitudDTO.getRegistrador().getNombreCompleto());     
	              
				String emailColaborador = StringUtils.trimToEmpty(solicitudDTO.getRegistrador().getCorreoElectronico());	
				String bodyMessage =  obtenerNotificacionCierreRendicion( nombreColaborador, codPlanilla, nombreRegistrador);
				Long numberMessage = createMessage(MensajeriaConstantes.CODIGO_NOTIFICACION_DE_CIERRE_RENDICION, MensajeriaConstantes.ASUNTO_NOTIFICACION_DE_CIERRE_RENDICION, bodyMessage);
				boolean validaDestino = false;
				 if(solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
	                    {addAddresSee(numberMessage, emailColaborador, nombreColaborador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
	                    validaDestino = true;}
	                    
	                }else if(!solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
	               	  if(StringUtils.isNotEmpty(emailRegistrador) && StringUtils.isNotEmpty(nombreRegistrador))	
	                	{addAddresSee(numberMessage, emailRegistrador, nombreRegistrador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
	                	validaDestino = true;}               	  
	                }    
				if(validaDestino)
				sendMessage(numberMessage);
			}

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}
	/**
	 * Metodo que permite obtener el mensaje de la notificacion, cuando se observa una solicitud.(ANEXO 11)
   	 * @param  nombreColaborador :nombre del colaborador.
	 * @param  codPlanilla :codigo de planilla.
	 * @param  nombreRegistrador :nombre del registrador.	
	 * @see    String
	 */
	private String obtenerNotificacionCierreRendicion( String nombreColaborador, String codPlanilla, String nombreRegistrador) {

		String tituloMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_DE_CIERRE_RENDICION_TITULO);
		String cuerpoMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_DE_CIERRE_RENDICION_CUERPO,nombreColaborador,codPlanilla);
		StringBuilder mensaje = new StringBuilder();
		mensaje.append(ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_CUERPO_1, tituloMensaje, cuerpoMensaje));
		
		return mensaje.toString();
	}
	
	
	
	/**
	 * Metodo que permite enviar correo de Notificacion de rechazo de la planilla (ANEXO 12) 
     * @author Rocio Paz.
	 * @param solicitudDTO : objeto que tiene los datos para el envio de correo. 
	 * @throws Exception	
	 */
	
	public void enviarNotificacionRechazoPlanilla(SolicitudDTO solicitudDTO) {
		
		try {
			if (solicitudDTO != null && solicitudDTO.getPlanViajeBean() != null && solicitudDTO.getColaborador()!= null && solicitudDTO.getRegistrador() != null) {
				String nombreColaborador = FormatoUtil.getUppperCaseText(solicitudDTO.getColaborador().getNombreCompleto());              
				String emailRegistrador= StringUtils.trimToEmpty(solicitudDTO.getRegistrador().getCorreoElectronico());			
				String nombreRegistrador = FormatoUtil.getUppperCaseText(solicitudDTO.getRegistrador().getNombreCompleto());	              
				String emailColaborador = StringUtils.trimToEmpty(solicitudDTO.getRegistrador().getCorreoElectronico());	
				
				String codigoPlanilla = solicitudDTO.getPlanViajeBean().getCodPlanilla();
				
				String nombre = nombreColaborador;//Siempre va al comisionado. 
				
				StringBuilder planillaA = new StringBuilder();
				StringBuilder planillaB = new StringBuilder();
				
				planillaA.append("<li>Planilla N°: "+solicitudDTO.getPlanViajeBean().getCodPlanilla()+"</li>");
				planillaA.append("<li>Comisionado: "+solicitudDTO.getColaborador().getNombreCompleto()+"</li>");
				planillaA.append("<li>UUOO: "+solicitudDTO.getDependencia().getUuoo()+"</li>");
				planillaA.append("<li>Tipo de viático: "+(ViaticoConstantes.TIPO_COMISION_NACIONAL.equals(solicitudDTO.getPlanViajeBean().getTipoDestino())?"NACIONAL":"INTERNACIONAL")+"</li>");
				planillaA.append("<li>Fecha de Salida o fecha de inicio evento: "+solicitudDTO.getPlanViajeBean().getFecSalidaFormateada()+"</li>");
				planillaA.append("<li>Fecha de Retorno o fecha de fin evento: "+solicitudDTO.getPlanViajeBean().getFecRetornoFormateada()+"</li>");
				planillaA.append("<li>Días comisión: "+solicitudDTO.getPlanViajeBean().getNumeroDias()+"</li>");
				planillaA.append("<li>Motivo de comisión: "+solicitudDTO.getPlanViajeBean().getSolicitanteViaje()+"</li>");
				
				log.info("buscando traslapes de: planilla:"+codigoPlanilla+", empleado:"+solicitudDTO.getColaborador().getCodigoEmpleado()+
						", fecha salida:"+solicitudDTO.getPlanViajeBean().getFecSalida()+", fecha de retorno:"+solicitudDTO.getPlanViajeBean().getFecRetorno());
				List<PlanViajeBean> traslapes = consultaSolicitudService.buscarTraslapeFechas(solicitudDTO.getColaborador().getCodigoEmpleado(), 
						solicitudDTO.getPlanViajeBean().getFecSalida(), solicitudDTO.getPlanViajeBean().getFecRetorno(), codigoPlanilla);
				if(!CollectionUtils.isEmpty(traslapes)){
					log.info("cantidad de traslapes encontrados:"+traslapes.size());
					List<PlanViajeBean> traslapesFiltro = new ArrayList<PlanViajeBean>();
					for (PlanViajeBean traslape : traslapes) {
						if (traslape == null) continue;
						traslapesFiltro.add(traslape);
					}
					traslapes = traslapesFiltro;
				}
				
				PlanViajeBean planillaBTraslape =  null;
				if(!CollectionUtils.isEmpty(traslapes)){
					log.info("cantidad de traslapes encontrados not null:"+traslapes.size());
					planillaBTraslape = traslapes.get(0);
					log.info("planilla traslapada:"+planillaBTraslape.getCodPlanilla());
					
					SolicitudDTO solicitudDTOT = viaticoConsultaService.obtenerPlanViajeToNotificacion(planillaBTraslape.getCodPlanViaje());
					log.info("SolicitudDTO para traslape:"+solicitudDTOT);
					
					planillaB.append("<li>Planilla N°: "+solicitudDTOT.getPlanViajeBean().getCodPlanilla()+"</li>");
					planillaB.append("<li>Comisionado: "+solicitudDTOT.getColaborador().getNombreCompleto()+"</li>");
					planillaB.append("<li>UUOO: "+solicitudDTOT.getDependencia().getUuoo()+"</li>");
					planillaB.append("<li>Tipo de viático: "+(ViaticoConstantes.TIPO_COMISION_NACIONAL.equals(solicitudDTOT.getPlanViajeBean().getTipoDestino())?"NACIONAL":"INTERNACIONAL")+"</li>");
					planillaB.append("<li>Fecha de Salida o fecha de inicio evento: "+solicitudDTOT.getPlanViajeBean().getFecSalidaFormateada()+"</li>");
					planillaB.append("<li>Fecha de Retorno o fecha de fin evento: "+solicitudDTOT.getPlanViajeBean().getFecRetornoFormateada()+"</li>");
					planillaB.append("<li>Días comisión: "+solicitudDTOT.getPlanViajeBean().getNumeroDias()+"</li>");
					planillaB.append("<li>Motivo de comisión: "+solicitudDTOT.getPlanViajeBean().getSolicitanteViaje()+"</li>");
				}
				
				String bodyMessage =  obtenerNotificacionRechazoPlanilla(nombre , codigoPlanilla, planillaA.toString(),planillaB.toString());
				
				Long numberMessage = createMessage(MensajeriaConstantes.CODIGO_NOTIFICACION_RECHAZO_GENERACION_PLANILLA_VIATICOS, 
						MensajeriaConstantes.ASUNTO_NOTIFICACION_RECHAZO_GENERACION_PLANILLA_VIATICOS, bodyMessage);
				boolean validaDestino = false;
				
				//Siempre enviamos al comisionado...
				if(StringUtils.isNotEmpty(emailColaborador) && StringUtils.isNotEmpty(nombreColaborador)){
					addAddresSee(numberMessage, emailColaborador, nombreColaborador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
					validaDestino = true;
				}
				
				//Si es que la solicitud fue ingresada por un registrador lo notificamos.
				if(!solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
	            	 if(StringUtils.isNotEmpty(emailRegistrador) && StringUtils.isNotEmpty(nombreRegistrador))
	            	 	{addAddresSee(numberMessage, emailRegistrador, nombreRegistrador, MensajeriaConstantes.TIPO_MENSAJE_CC);
	            	 	validaDestino = true;}
	            }
				
				if(validaDestino)
				 sendMessage(numberMessage);
			} else {
				throw new Exception();
			}

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}
	/**
	 * Metodo que permite obtener el mensaje de la notificacion, cuando se observa una solicitud.(ANEXO 12)
   	 * @param  nombreColaborador :nombre del colaborador.
	 * @param  codPlanilla :codigo de planilla.
	 * @param  nombreRegistrador :nombre del registrador.	
	 * @see    String
	 */
	private String obtenerNotificacionRechazoPlanilla(String nombre, String codPlanilla, String planillaA, String planillaB) {

		String tituloMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_RECHAZO_GENERACION_PLANILLA_VIATICOS_TITULO);
		
		String cuerpoMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_RECHAZO_GENERACION_PLANILLA_VIATICOS_CUERPO, nombre ,
				codPlanilla,planillaA, planillaB);
		
		StringBuilder mensaje = new StringBuilder();
		mensaje.append(ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_CUERPO_1, tituloMensaje, cuerpoMensaje));
		
		return mensaje.toString();
	}
	
	
	
	
	/**
	 * Metodo que permite enviar correo  Notificacion  al Autorizar Solicitud De Reembolso(ANEXO 13)
     * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo. 
	 * @throws Exception	
	 */
	
	
	
	
public void enviarNotificacionAutorizacionDeSolicitudDeReembolso(SolicitudDTO solicitudDTO) {
		
		try {
			if (solicitudDTO != null && solicitudDTO.getPlanViajeBean() != null && solicitudDTO.getColaborador()!= null && solicitudDTO.getRegistrador()!= null) {
				String codPlanilla = solicitudDTO.getPlanViajeBean().getCodPlanilla();
				String nombreColaborador = FormatoUtil.getUppperCaseText(solicitudDTO.getColaborador().getNombreCompleto());
				String nombreRegistrador = FormatoUtil.getUppperCaseText(solicitudDTO.getRegistrador().getNombreCompleto());				
				String emailColaborador = StringUtils.trimToEmpty(solicitudDTO.getColaborador().getCorreoElectronico());              
				String emailRegistrador = StringUtils.trimToEmpty(solicitudDTO.getRegistrador().getCorreoElectronico());				
				
				
				if(solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
					nombreRegistrador = ViaticoConstantes.CADENA_VACIA;
				}else if(!solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
					nombreColaborador = ViaticoConstantes.CADENA_VACIA;
				}
				boolean validaDestino = false;
				String bodyMessage =  obtenerNotificacionAutorizacionDeSolicitudDeReembolso(nombreColaborador, codPlanilla, nombreRegistrador);
				Long numberMessage = createMessage(MensajeriaConstantes.CODIGO_NOTIFICACION_DE_AUTORIZACION_SOLICITUD_REEMBOLSO, MensajeriaConstantes.ASUNTO_NOTIFICACION_DE_AUTORIZACION_SOLICITUD_REEMBOLSO, bodyMessage);
				
			    if(solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
                  if(StringUtils.isNotEmpty(emailColaborador) && StringUtils.isNotEmpty(nombreColaborador))  
			    	{addAddresSee(numberMessage, emailColaborador, nombreColaborador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
			    	validaDestino = true;}
                    
                }else if(!solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
                  if(StringUtils.isNotEmpty(emailRegistrador) && StringUtils.isNotEmpty(nombreRegistrador))
                	{addAddresSee(numberMessage, emailRegistrador, nombreRegistrador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
                	validaDestino = true;}
                }     
			    if(validaDestino)
			    	sendMessage(numberMessage);
			} 

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}
/**
 * Metodo que permite obtener el mensaje de la notificacion, cuando se observa una solicitud.(ANEXO 13)
 * @author Rocio Paz.
 *  * @param  nombreColaborador :nombre del colaborador.
 * @param  codPlanilla :codigo de planilla.
 * @param  nombreRegistrador :nombre del registrador.
 * @return Mensaje de la notificacion.
 * @see    String
 */
	private String obtenerNotificacionAutorizacionDeSolicitudDeReembolso( String nombreColaborador, String codPlanilla, String nombreRegistrador) {

		String nombre = ViaticoConstantes.CADENA_VACIA;
		
		if(StringUtils.isNotEmpty(nombreColaborador)){
			nombre = nombreColaborador;
		}else{
			nombre = nombreRegistrador;
		}
		
		String tituloMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_DE_AUTORIZACION_SOLICITUD_REEMBOLSO_TITULO);
		String cuerpoMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_DE_AUTORIZACION_SOLICITUD_REEMBOLSO_CUERPO,nombre,codPlanilla);
		StringBuilder mensaje = new StringBuilder();
		mensaje.append(ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_CUERPO_1, tituloMensaje, cuerpoMensaje));
	
		return mensaje.toString();
	}
	
	
	/**
	 * Metodo que permite enviar correo de notificacion al anular solicitud de reembolso - Autorizador de Gasto(ANEXO 14)
	 * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo. 
	 * @throws Exception	
	 */
	
	
public void enviarNotificacionAnulacionDeSolicitudDeReembolso(SolicitudDTO solicitudDTO) {
		
		try {
			if (solicitudDTO != null && solicitudDTO.getPlanViajeBean() != null && solicitudDTO.getColaborador()!= null && solicitudDTO.getRegistrador()!= null) {
				String codPlanilla = solicitudDTO.getPlanViajeBean().getCodPlanilla();
				String ObsAnulacion = solicitudDTO.getPlanViajeBean().getObservacionAnulacion();
				String nombreColaborador = FormatoUtil.getUppperCaseText(solicitudDTO.getColaborador().getNombreCompleto());
				String nombreRegistrador = FormatoUtil.getUppperCaseText(solicitudDTO.getRegistrador().getNombreCompleto());				
				String emailColaborador = StringUtils.trimToEmpty(solicitudDTO.getColaborador().getCorreoElectronico());              
				String emailRegistrador = StringUtils.trimToEmpty(solicitudDTO.getRegistrador().getCorreoElectronico());				
				
				if(solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
					nombreRegistrador = ViaticoConstantes.CADENA_VACIA;
				}else if(!solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
					nombreColaborador = ViaticoConstantes.CADENA_VACIA;
				}
				String bodyMessage = ViaticoConstantes.CADENA_VACIA;
				if(solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
				 bodyMessage =  obtenerNotificacionAnulacionDeSolicitudDeReembolso( nombreColaborador,ViaticoConstantes.CADENA_VACIA, codPlanilla,ObsAnulacion);
				} else if(!solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
				 bodyMessage =  obtenerNotificacionAnulacionDeSolicitudDeReembolso( ViaticoConstantes.CADENA_VACIA, nombreRegistrador, codPlanilla,ObsAnulacion);
				}
				
				Long numberMessage = createMessage(MensajeriaConstantes.CODIGO_NOTIFICACION_DE_ANULACION_SOLICITUD_REEMBOLSO, MensajeriaConstantes.ASUNTO_NOTIFICACION_DE_ANULACION_SOLICITUD_REEMBOLSO, bodyMessage);	
				boolean validaDestino = false;
			    if(solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
                  if(StringUtils.isNotEmpty(emailColaborador) && StringUtils.isNotEmpty(nombreColaborador))  
			    	{addAddresSee(numberMessage, emailColaborador, nombreColaborador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
			    	validaDestino = true;}
                    
                }else if(!solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
                   if(StringUtils.isNotEmpty(emailRegistrador) && StringUtils.isNotEmpty(nombreRegistrador))
                	{addAddresSee(numberMessage, emailRegistrador, nombreRegistrador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
                	validaDestino = true;}               	 
                }    
			    
			    if(validaDestino)
			    sendMessage(numberMessage);
			}

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}
	

/**
 * Metodo que permite obtener el mensaje de la notificacion, cuando se observa una solicitud.(ANEXO 14)
 * @author Rocio Paz.
 * @param  nombreColaborador :nombre del colaborador.
 * @param  nombreRegistrador :nombre del registrador.
 * @param  codPlanilla :codigo de planilla.
 * @param  ObsAnulacion : observación de la anulación.
 * @return Mensaje de la notificacion.
 * @see    String
 */
	private String obtenerNotificacionAnulacionDeSolicitudDeReembolso( String nombreColaborador, String nombreRegistrador, String codPlanilla, String ObsAnulacion) {

		String nombre = ViaticoConstantes.CADENA_VACIA;
		
		if(StringUtils.isNotEmpty(nombreColaborador)){
			nombre = nombreColaborador;
		}else{
			nombre = nombreRegistrador;
		}
		
		String tituloMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_DE_ANULACION_SOLICITUD_REEMBOLSO_TITULO);
		
		String cuerpoMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_DE_ANULACION_SOLICITUD_REEMBOLSO_CUERPO,nombre,codPlanilla, ObsAnulacion, nombreRegistrador,nombreColaborador);
		
		StringBuilder mensaje = new StringBuilder();
		mensaje.append(ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_CUERPO_1, tituloMensaje, cuerpoMensaje));
		
		return mensaje.toString();
	}
	

	
	/**
	 * Metodo que permite enviar correo de  Notificacion al registrador universal comunicado que un comisionado tiene comisiones consecutivas por lo cual no puede rendir en el plazo(ANEXO 15)
	 * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo. 
	 * @throws Exception	
	 */
	/*public void enviarNotificacionAnulacionSolcitudReembolsoAutorizador(SolicitudDTO solicitudDTO) {
		
		try {
			if (solicitudDTO != null && solicitudDTO.getPlanViajeBean() != null && solicitudDTO.getColaborador() != null && solicitudDTO.getRegistrador() != null && CollectionUtils.isNotEmpty(solicitudDTO.getRegistradorUniversal())) {
							
				for(ColaboradorViaticoBean  codigoRegistroUniversalList : solicitudDTO.getRegistradorUniversal()){

					String nombreRegistrador = FormatoUtil.getUppperCaseText(solicitudDTO.getRegistrador().getNombreCompleto());	
					//String emailRegistrador = StringUtils.trimToEmpty(solicitudDTO.getRegistrador().getCorreoElectronico());
					StringBuilder codigosPlanilla = new StringBuilder();
				
					String trInicio = "<tr><td style='border: black 1px solid; padding: 5px;'>";
					String trMedio = "</td><td style='border: black 1px solid; padding: 5px;'>";
					String trFin = "</td></tr>";
					log.debug("incio for : " + nombreRegistrador);
					for(PlanViajeBean planViaje : solicitudDTO.getPlanViajeList()){
						codigosPlanilla.append(trInicio + planViaje.getNomColaborador() );
						codigosPlanilla.append(trMedio + planViaje.getCodPlanilla() + trFin);					
					}
					log.debug("fin for: " + nombreRegistrador);
					
					
					String bodyMessage =  obtenerNotificacionAnulacionSolcitudReembolsoAutorizador(nombreRegistrador, codigosPlanilla);
					Long numberMessage = createMessage(MensajeriaConstantes.CODIGO_NOTIFICACION_DE_ANULACION_SOLICITUD_DE_REEMBOLSO_AUTORIZADOR_DE_GASTO, MensajeriaConstantes.ASUNTO_NOTIFICACION_DE_AUTORIZACION_SOLICITUD_REEMBOLSO, bodyMessage);
					 if(codigoRegistroUniversalList != null){
						 String email =  StringUtils.trimToEmpty(codigoRegistroUniversalList.getCorreoElectronico());
						 if(StringUtils.isNotEmpty(email))
						 	addAddresSee(numberMessage, email, codigoRegistroUniversalList.getNombreCompleto(), MensajeriaConstantes.TIPO_MENSAJE_PARA);
	
						 sendMessage(numberMessage);
					}
				
				}
					
			} else {
				throw new Exception();
			}

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}*/
	
	
	/**
	 * Metodo que permite enviar correo de  Notificacion al registrador universal comunicado que un comisionado tiene comisiones consecutivas por lo cual no puede rendir en el plazo(ANEXO 15)
	 * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo. 
	 * @throws Exception	
	 */
	public void enviarNotificacionAnulacionSolcitudReembolsoAutorizador(SolicitudDTO solicitudDTO) {
		
		try {
			if (solicitudDTO != null && solicitudDTO.getPlanViajeBean() != null && solicitudDTO.getColaborador() != null && solicitudDTO.getRegistrador() != null ) {
							

				String nombreRegistrador = FormatoUtil.getUppperCaseText(solicitudDTO.getRegistrador().getNombreCompleto());	
				String emailRegistrador = StringUtils.trimToEmpty(solicitudDTO.getRegistrador().getCorreoElectronico());
				StringBuilder codigosPlanilla = new StringBuilder();
			
				String trInicio = "<tr><td style='border: black 1px solid; padding: 5px;'>";
				String trMedio = "</td><td style='border: black 1px solid; padding: 5px;'>";
				String trFin = "</td></tr>";
				log.debug("incio for : " + nombreRegistrador);
				for(PlanViajeBean planViaje : solicitudDTO.getPlanViajeList()){
					codigosPlanilla.append(trInicio + planViaje.getNomColaborador() );
					codigosPlanilla.append(trMedio + planViaje.getCodPlanilla() + trFin);					
				}
				log.debug("fin for: " + nombreRegistrador);
				
				boolean validaDestino = false;
				String bodyMessage =  obtenerNotificacionAnulacionSolcitudReembolsoAutorizador(nombreRegistrador, codigosPlanilla);
				Long numberMessage = createMessage(MensajeriaConstantes.CODIGO_NOTIFICACION_DE_ANULACION_SOLICITUD_DE_REEMBOLSO_AUTORIZADOR_DE_GASTO, MensajeriaConstantes.ASUNTO_NOTIFICACION_DE_AUTORIZACION_SOLICITUD_REEMBOLSO, bodyMessage);
				 if(StringUtils.isNotEmpty(emailRegistrador) && StringUtils.isNotEmpty(nombreRegistrador))
				 { addAddresSee(numberMessage, emailRegistrador, nombreRegistrador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
				 validaDestino = true;}
				 if(validaDestino)
				 	sendMessage(numberMessage);
			} 

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}
	
	
	
	
	
	/**
	 *Metodo  que permite obtener el mensaje de la notificacion, cuando se observa una solicitud.(ANEXO 15)
	 * @author Rocio Paz.
	 * @param  nombreRegistrador :nombre del registrador.
	 * @param  codPlanilla :codigo de planilla.
	 * @return Mensaje de la notificacion.
	 * @see    String
	 */
	private String obtenerNotificacionAnulacionSolcitudReembolsoAutorizador(String nombreRegistrador , StringBuilder codigosPlanilla){
		String tituloMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_DE_ANULACION_SOLICITUD_DE_REEMBOLSO_AUTORIZADOR_DE_GASTO_TITULO);
		String cuerpoMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_DE_ANULACION_SOLICITUD_DE_REEMBOLSO_AUTORIZADOR_DE_GASTO_CUERPO, nombreRegistrador, codigosPlanilla);
		StringBuilder mensaje = new StringBuilder();
		mensaje.append(ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_CUERPO_1, tituloMensaje, cuerpoMensaje));
		
		return mensaje.toString();
	}
	
	
	
	
	
	
	/**
	 * Metodo que permite enviar correo de Notificacion de Reprogramacion de fecha de Rendicion(ANEXO 16)
     * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo. 
	 * @throws Exception	
	 */
		
	
public void enviarNotificacionDeReprogramacionDeFechaDeRendicion(SolicitudDTO solicitudDTO) {
		
		try {
			if (solicitudDTO != null && solicitudDTO.getPlanViajeBean() != null && solicitudDTO.getColaborador()!= null && solicitudDTO.getRegistrador()!= null && solicitudDTO.getAutorizador() != null) {
				String nombre = ViaticoConstantes.CADENA_VACIA;
								
				String FecMaxRendFormateada = solicitudDTO.getPlanViajeBean().getFecMaxRendFormateada();
				String nombreAutorizador = FormatoUtil.getUppperCaseText(solicitudDTO.getAutorizador().getNombreCompleto());    				           
                String emailAutorizador = StringUtils.trimToEmpty(solicitudDTO.getAutorizador().getCorreoElectronico());
				String nombreColaborador = FormatoUtil.getUppperCaseText(solicitudDTO.getColaborador().getNombreCompleto());
				String nombreRegistrador = FormatoUtil.getUppperCaseText(solicitudDTO.getRegistrador().getNombreCompleto());				
				String emailColaborador = StringUtils.trimToEmpty(solicitudDTO.getColaborador().getCorreoElectronico());              
				String emailRegistrador = StringUtils.trimToEmpty(solicitudDTO.getRegistrador().getCorreoElectronico());				
				String codPlanilla = solicitudDTO.getPlanViajeBean().getCodPlanilla();
				
				if(solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
					nombre = solicitudDTO.getColaborador().getNombreCompleto();
				}else if(!solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
					nombre = solicitudDTO.getRegistrador().getNombreCompleto();
				}
				Date fecha = new Date();
				String fechaTexto = FechaUtil.fechaActualWithTexto(fecha);
				
				String  bodyMessage =  obtenerNotificacionDeReprogramacionDeFechaDeRendicion( nombre, nombreAutorizador, FecMaxRendFormateada, fechaTexto,codPlanilla);
				 
				
				Long numberMessage = createMessage(MensajeriaConstantes.CODIGO_NOTIFICACION_DE_REPROGRAMACION_DE_FECHA_DE_SOLICITUD_RENDICION, MensajeriaConstantes.ASUNTO_NOTIFICACION_DE_REPROGRAMACION_DE_FECHA_DE_SOLICITUD_RENDICION, bodyMessage);	
				boolean validaDestino = false;
			    if(solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
                    if(StringUtils.isNotEmpty(emailColaborador) && StringUtils.isNotEmpty(nombreColaborador))
			    		{addAddresSee(numberMessage, emailColaborador, nombreColaborador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
			    		validaDestino = true;}
                    
                }else if(!solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
                	if(StringUtils.isNotEmpty(emailColaborador) && StringUtils.isNotEmpty(nombreColaborador))
                		{addAddresSee(numberMessage, emailRegistrador, nombreRegistrador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
                		validaDestino = true;}               	 
                }
			    if(StringUtils.isNotEmpty(emailAutorizador) && StringUtils.isNotEmpty(nombreAutorizador))
			    	{addAddresSee(numberMessage, emailAutorizador, nombreAutorizador, MensajeriaConstantes.TIPO_MENSAJE_CC);
			    	validaDestino = true;}
			    
			    if(validaDestino)
			    	sendMessage(numberMessage);
			} 

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

/**
 *Metodo que permite obtener el mensaje de la notificacion, cuando se observa una solicitud.(ANEXO 16)
 * @author Rocio Paz.
 * @param  nombre :nombre del registrador, nombre registrador.
 * @param  nombreAutorizador :nombre autorizador.
 * @param  FecMaxRendFormateada: fecha maxima formateada.
 * @param  fechaTexto : fecha actual.
 * @return Mensaje de la notificacion.
 * @see    String
 */
	
	private String obtenerNotificacionDeReprogramacionDeFechaDeRendicion( String nombre, String nombreAutorizador,String FecMaxRendFormateada, String fechaTexto, String planilla) {

		String tituloMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_DE_REPROGRAMACION_DE_FECHA_DE_SOLICITUD_RENDICION_TITULO);
		
		String cuerpoMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_DE_REPROGRAMACION_DE_FECHA_DE_SOLICITUD_RENDICION_CUERPO, nombre + ViaticoConstantes.COMA+ViaticoConstantes.BR + nombreAutorizador, FecMaxRendFormateada, fechaTexto,planilla);
		
		StringBuilder mensaje = new StringBuilder();
		mensaje.append(ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_CUERPO_1, tituloMensaje, cuerpoMensaje));
		
		return mensaje.toString();
	}
	
	
	
	/**
	 * Metodo  que permite enviar correo de notificacion de anulacion de Planilla(ANEXO 17)
	  * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo. 
	 * @throws Exception	
	 */
	
	 public void enviarNotificacionDeAnulacionDePlanilla(SolicitudDTO solicitudDTO) {
			
			try {
				if (solicitudDTO != null && solicitudDTO.getPlanViajeBean() != null && solicitudDTO.getColaborador()!= null && solicitudDTO.getRegistrador()!= null) {
					String nombre = ViaticoConstantes.CADENA_VACIA;
					String nombreAutorizador = ViaticoConstantes.CADENA_VACIA;
					String emailAutorizador = ViaticoConstantes.CADENA_VACIA;
					String codPlanilla = solicitudDTO.getPlanViajeBean().getCodPlanilla();	
					if(solicitudDTO.getAutorizador() != null){
						 nombreAutorizador = FormatoUtil.getUppperCaseText(solicitudDTO.getAutorizador().getNombreCompleto());    				           
						 emailAutorizador = StringUtils.trimToEmpty(solicitudDTO.getAutorizador().getCorreoElectronico());
					}
	                String nombreColaborador = FormatoUtil.getUppperCaseText(solicitudDTO.getColaborador().getNombreCompleto());
					String nombreRegistrador = FormatoUtil.getUppperCaseText(solicitudDTO.getRegistrador().getNombreCompleto());				
					String emailColaborador = StringUtils.trimToEmpty(solicitudDTO.getColaborador().getCorreoElectronico());              
					String emailRegistrador = StringUtils.trimToEmpty(solicitudDTO.getRegistrador().getCorreoElectronico());				
				
					
					if(solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
						nombre = solicitudDTO.getColaborador().getNombreCompleto();
					}else if(!solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
						nombre = solicitudDTO.getRegistrador().getNombreCompleto();
					}
					Date fecha = new Date();
					String fechaTexto = FechaUtil.fechaActualWithTexto(fecha);
					
					String  bodyMessage =  obtenerNotificacionDeAnulacionDePlanilla( nombre, nombreAutorizador, codPlanilla, fechaTexto);
					 
					
					Long numberMessage = createMessage(MensajeriaConstantes.CODIGO_NOTIFICACION_DE_ANULACION_DE_PLANILLA, MensajeriaConstantes.ASUNTO_NOTIFICACION_DE_ANULACION_DE_PLANILLA, bodyMessage);	
					boolean validaDestino = false;
					
				    if(solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
				    	if(StringUtils.isNotEmpty(emailColaborador) && StringUtils.isNotEmpty(nombreColaborador)){
				    		addAddresSee(numberMessage, emailColaborador, nombreColaborador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
				    		validaDestino = true;}	                    
	                }else if(!solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
	                	if(StringUtils.isNotEmpty(emailRegistrador) && StringUtils.isNotEmpty(nombreRegistrador)){
	                		addAddresSee(numberMessage, emailRegistrador, nombreRegistrador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
	                		validaDestino = true;}	               	 
	                }
				    if(StringUtils.isNotEmpty(emailAutorizador) && StringUtils.isNotEmpty(nombreAutorizador)){
				    	addAddresSee(numberMessage, emailAutorizador, nombreAutorizador, MensajeriaConstantes.TIPO_MENSAJE_CC);
				    	validaDestino = true;}
				    if(validaDestino)
				    	sendMessage(numberMessage);
				}

			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}
		}
		
	 /**
	  * Metodo que permite obtener el mensaje de la notificacion, cuando se observa una solicitud.(ANEXO 17)
	  * @author Rocio Paz.
	  * @param  nombre :nombre del registrador, nombre registrador.
	  * @param  nombreAutorizador :nombre autorizador.
	  * @param  FecMaxRendFormateada: fecha maxima formateada.
	  * @param  fechaTexto : fecha actual.
	  * @return Mensaje de la notificacion.
	  * @see    String
	  */
		private String obtenerNotificacionDeAnulacionDePlanilla( String nombre, String nombreAutorizador,String FecMaxRendFormateada, String fechaTexto) {

			String tituloMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_DE_ANULACION_DE_PLANILLA_TITULO);
			
			String cuerpoMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_DE_ANULACION_DE_PLANILLA_CUERPO, nombre + ViaticoConstantes.COMA+ViaticoConstantes.BR + nombreAutorizador, FecMaxRendFormateada, fechaTexto);
			
			StringBuilder mensaje = new StringBuilder();
			mensaje.append(ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_CUERPO_1, tituloMensaje, cuerpoMensaje));
		
			return mensaje.toString();
		}
		
	
	
	/**
	 * Metodo que permite enviar notificacion cuando se reprograma la fecha de rendicion.
	 * @author Jorge Ponce.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo.
	 */
	public void enviarNotificacionReprogramacionFechaRendicion(SolicitudDTO solicitudDTO) {
		
		try {
			if (solicitudDTO != null && solicitudDTO.getPlanViajeBean() != null && solicitudDTO.getColaborador() != null && solicitudDTO.getRegistrador() != null && solicitudDTO.getAutorizador() != null) {
				String fecMaxRend = solicitudDTO.getPlanViajeBean().getFecReprogramaRendFormateada();
				String nombreColaborador = FormatoUtil.getUppperCaseText(solicitudDTO.getColaborador().getNombreCompleto());
				String nombreRegistrador = FormatoUtil.getUppperCaseText(solicitudDTO.getRegistrador().getNombreCompleto());
				String nombreAutorizador = FormatoUtil.getUppperCaseText(solicitudDTO.getAutorizador().getNombreCompleto());
				String emailColaborador = StringUtils.trimToEmpty(solicitudDTO.getColaborador().getCorreoElectronico());
				String emailRegistrador = StringUtils.trimToEmpty(solicitudDTO.getRegistrador().getCorreoElectronico());
				String emailAutorizador = StringUtils.trimToEmpty(solicitudDTO.getAutorizador().getCorreoElectronico());
				String bodyMessage = obtenerMensajeNotificacionReprogramacionFechaRendicion(fecMaxRend, nombreColaborador, 
						nombreRegistrador, nombreAutorizador,solicitudDTO.getPlanViajeBean().getCodPlanilla());
				
				Long numberMessage = createMessage(MensajeriaConstantes.CODIGO_NOTIFICACION_REPROGRAMACION_FECHA_RENDICION, 
						MensajeriaConstantes.ASUNTO_NOTIFICACION_REPROGRAMACION_FECHA_RENDICION, bodyMessage);
				addAddresSee(numberMessage, emailColaborador, nombreColaborador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
				
				if(!solicitudDTO.getColaborador().getCodigoEmpleado().equals(solicitudDTO.getRegistrador().getCodigoEmpleado())){
					if(StringUtils.isNotEmpty(emailRegistrador) && StringUtils.isNotEmpty(nombreRegistrador)){
						addAddresSee(numberMessage, emailRegistrador, nombreRegistrador, MensajeriaConstantes.TIPO_MENSAJE_PARA);
            		}	               	 
				}
				
				addAddresSee(numberMessage, emailAutorizador, nombreAutorizador, MensajeriaConstantes.TIPO_MENSAJE_CC);
				sendMessage(numberMessage);
			}
			else {
				throw new Exception();
			}
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}
	
	/**
	 * Metodo que permite obtener el mensaje de la notificacion, cuando se reprograma la fecha de rendicion.
	 * @author Jorge Ponce.
	 * @param  fecMaxRend :fecha maxima de rendicion.
	 * @param  nombreColaborador :nombre del colaborador.
	 * @param  nombreRegistrador :nombre del registrador.
	 * @param  nombreAutorizador :nombre del autorizador.
	 * @return Mensaje de la notificacion.
	 * @see    String
	 */
	private String obtenerMensajeNotificacionReprogramacionFechaRendicion(String fecMaxRend, String nombreColaborador, 
			String nombreRegistrador, String nombreAutorizador, String codPlanilla) {
		
		String tituloMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_REPROGRAMACION_TITULO);
		String cuerpoMensaje = ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_REPROGRAMACION_CUERPO, nombreColaborador, nombreRegistrador, nombreAutorizador, fecMaxRend, FechaUtil.obtenerFechaText(new Date()), codPlanilla);
		StringBuilder mensaje = new StringBuilder();
		mensaje.append(ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_CUERPO_1, tituloMensaje, cuerpoMensaje));
		//mensaje.append(ResourceBundleUtil.getMessageCorreo(MensajeriaConstantes.NOTIFICACION_CUERPO_2, MensajeriaConstantes.CODIGO_NOTIFICACION_REPROGRAMACION_FECHA_RENDICION));
		return mensaje.toString();
	}

	/**
	 * Metodo que permite crear/registrar el correo.
	 * @author Jorge Ponce.
	 * @param  codigoMessage :codigo del correo.
	 * @param  subjectMessage :asunto del correo.
	 * @param  bodyMessage :mensaje o cuerpo del correo.
	 * @return Numero del correo(numberMessage).
	 * @see    String
	 */
	private Long createMessage(String codigoMessage, String subjectMessage, String bodyMessage) throws Exception {

		SysMensajeriaBean mensaje = new SysMensajeriaBean();
		mensaje.setCodigoMensaje(codigoMessage);
		mensaje.setAsunto(subjectMessage);
		mensaje.setMensaje(bodyMessage);
		mensaje.setRemitenteEmail(ViaticoConstantes.CADENA_VACIA);
		mensaje.setRemitenteFirma(ViaticoConstantes.CADENA_VACIA);
		mensaje.setRemitenteNombre(ViaticoConstantes.CADENA_VACIA);
		Long numberMessage = registroMensajeriaService.crearMensaje(mensaje);
		return numberMessage;
	}

	/**
	 * Metodo que permite agregar destinatario al correo.
	 * @author Jorge Ponce.
	 * @param  numberMessage :numero del correo.
	 * @param  email :correo del destinatario.
	 * @param  nombreColaborador :nombre del destinatario o colaborador.
	 * @param  tipoMessage :tipo mensaje (PARA - CC - BCC).
	 */
	private void addAddresSee(Long numberMessage, String email, String nombreColaborador, String tipoMessage) throws Exception {

		SysMensajeriaDestinosBean destino = new SysMensajeriaDestinosBean();
		destino.setNroMensaje(numberMessage);
		destino.setDestinoEmail(email);
		destino.setDestinoNombre(nombreColaborador);
		destino.setTipoDestino(tipoMessage);
		registroMensajeriaService.addDestino(destino);
	}

	/**
	 * Metodo que permite enviar el correo.
	 * @author Jorge Ponce.
	 * @param  numberMessage :numero del correo.
	 */
	private void sendMessage(Long numberMessage) throws Exception {
		registroMensajeriaService.sendMensaje(numberMessage);
	}

	public ConsultaSolicitudService getConsultaSolicitudService() {
		return consultaSolicitudService;
	}

	public void setConsultaSolicitudService(
			ConsultaSolicitudService consultaSolicitudService) {
		this.consultaSolicitudService = consultaSolicitudService;
	}

	public ViaticoConsultaService getViaticoConsultaService() {
		return viaticoConsultaService;
	}

	public void setViaticoConsultaService(
			ViaticoConsultaService viaticoConsultaService) {
		this.viaticoConsultaService = viaticoConsultaService;
	}

}
