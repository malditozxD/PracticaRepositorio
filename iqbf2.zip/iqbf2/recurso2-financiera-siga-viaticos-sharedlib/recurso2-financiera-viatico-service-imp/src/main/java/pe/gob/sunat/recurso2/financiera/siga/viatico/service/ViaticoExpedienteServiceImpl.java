package pe.gob.sunat.recurso2.financiera.siga.viatico.service;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.recurso2.administracion.siga.expediente.model.bean.ExpedienteAccionBean;
import pe.gob.sunat.recurso2.administracion.siga.expediente.model.bean.ExpedienteProcesoBean;
import pe.gob.sunat.recurso2.administracion.siga.expediente.service.RegistroExpedienteService;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroGeneralServiceImpl;
import pe.gob.sunat.recurso2.administracion.siga.util.FechaUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ResourceBundleUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;

public class ViaticoExpedienteServiceImpl implements ViaticoExpedienteService {

	private RegistroExpedienteService registroExpedienteService;

	public RegistroExpedienteService getRegistroExpedienteService() {
		return registroExpedienteService;
	}

	public void setRegistroExpedienteService(RegistroExpedienteService registroExpedienteService) {
		this.registroExpedienteService = registroExpedienteService;
	}

	private static final Log log = LogFactory.getLog(RegistroGeneralServiceImpl.class);

	/**
	 * Metodo que permite crear un accion en un expediente dado
	 * 
	 * @author Juan Saccatoma
	 * @param codigoProceso codigo de proceso
	 * @param numeroPlanilla numero de planilla
	 * @param codigoColaborador codigo de colaborador
	 * @param codigoSede codigo de sede
	 * @return codigo de expediente
	 * @throws ServiceException
	 */
	public String crearExpediente(String codigoProceso, String numeroPlanilla, String codigoColaborador, String codigoSede) throws ServiceException {

		log.debug("Inicio - ViaticoExpedienteServiceImpl.crearExpediente");

		String codigoExpediente = StringUtils.EMPTY;

		try {

			ExpedienteProcesoBean proceso = new ExpedienteProcesoBean();

			proceso.setAnioProceso(FechaUtil.obtenerAnioActual());
			proceso.setCodigoDocumentoOrigen(numeroPlanilla);
			proceso.setCodigoProceso(codigoProceso); // Enviado como ExpedienteConstantes.CODIGO_PROCESO_VIATICO_SOLICITUD o ExpedienteConstantes.CODIGO_PROCESO_VIATICO_REEMBOLSO
			proceso.setCodigoResponsable(codigoColaborador);
			proceso.setCodigoSede(codigoSede);

			codigoExpediente = registroExpedienteService.crearExpediente(proceso);

			codigoExpediente = StringUtils.trimToEmpty(codigoExpediente);

		} catch (Exception e) {
			log.error("Error en ViaticoExpedienteServiceImpl.crearExpediente: " + e.getMessage(), e);
			throw new ServiceException(this, ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO));

		} finally {
			log.debug("Fin - ViaticoExpedienteServiceImpl.crearExpediente");
		}

		return codigoExpediente;
	}

	/**
	 * Metodo que permite crear un accion en un expediente dado
	 * 
	 * @author Juan Saccatoma
	 * @param codigoProceso codigo proceso
	 * @param numeroExpediente numero expediente
	 * @param codigoAccion codigo de accion
	 * @param codigoEstado codigo de estado
	 * @param codigoColaborador codigo del colaborador
	 * @param observacion observacion
	 * @param codigoSede codigo de sede
	 * @throws ServiceException
	 */
	public void crearAccion(String codigoProceso, String numeroExpediente, String codigoAccion, String codigoEstado, String codigoColaborador, String observacion, String codigoSede) throws ServiceException {

		log.debug("Inicio - ViaticoExpedienteServiceImpl.crearAccion");

		try {

			ExpedienteAccionBean accion = new ExpedienteAccionBean();

			accion.setCodigoAccion(codigoAccion);
			accion.setCodigoExpedienteOrigen(numeroExpediente);
			accion.setCodigoResponsable(codigoColaborador);
			accion.setCodigoSede(codigoSede);
			accion.setExpedienteEstado(codigoEstado);
			accion.setExpedienteObservacion(observacion);
			accion.setCodigoProceso(codigoProceso); // Enviado como ExpedienteConstantes.CODIGO_PROCESO_VIATICO_SOLICITUD o ExpedienteConstantes.CODIGO_PROCESO_VIATICO_REEMBOLSO

			registroExpedienteService.crearAccion(accion);

		} catch (Exception e) {
			log.error("Error en ViaticoExpedienteServiceImpl.crearAccion: " + e.getMessage(), e);
			throw new ServiceException(this, ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_GENERICO));
		} finally {
			log.debug("Fin - ViaticoExpedienteServiceImpl.crearAccion");
		}
	}

}
