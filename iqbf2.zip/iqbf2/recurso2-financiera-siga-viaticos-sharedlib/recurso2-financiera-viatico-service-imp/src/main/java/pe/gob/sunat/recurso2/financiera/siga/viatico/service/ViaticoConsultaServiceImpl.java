package pe.gob.sunat.recurso2.financiera.siga.viatico.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.T01ParametroBean;
import pe.gob.sunat.recurso2.administracion.siga.parametro.model.dao.T01ParametroDAO;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.DependenciaBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroContratistasBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroDependenciasService;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.administracion.siga.util.FechaUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.FormatoUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.NumeroUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ConceptoPlanillaViaticosBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeConceptoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeDestinoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeInformeDistribBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeRendicionBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.SolicitudDTO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.SysGlobalParametrosBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.TipoDocumentoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeDestinoDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeInformeDistribDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeRendicionDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.SysGlobalParametrosDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dto.DocumentoSustentarioDTO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dto.ViaticoValidate;
import pe.gob.sunat.recurso2.financiera.siga.viatico.rendicion.service.ConsultaRendicionService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.service.ConsultaSolicitudService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.MaestroPersonalUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.RendicionConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ResourceBundleUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.SolicitudConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoUtil;

public class ViaticoConsultaServiceImpl implements ViaticoConsultaService {

	protected final Log log = LogFactory.getLog(getClass());
	private RegistroPersonalService registroPersonalService;
	private ViaticoGeneralService viaticoGeneralService;
	private ConsultaRendicionService consultaRendicionService;
	private ConsultaSolicitudService consultaSolicitudService;
	private RegistroDependenciasService registroDependenciasService;
	private ViaticoService viaticoService;
	private PlanViajeRendicionDAO planViajeRendicionDAO;
	private PlanViajeInformeDistribDAO planViajeInformeDistribDAO;
	private SysGlobalParametrosDAO sysGlobalParametrosDAO;
	private PlanViajeDAO planViajeDAO;
	private PlanViajeDestinoDAO planViajeDestinoDAO;
	private T01ParametroDAO t01ParametroDAO;
	
	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}

	public ViaticoGeneralService getViaticoGeneralService() {
		return viaticoGeneralService;
	}

	public void setViaticoGeneralService(ViaticoGeneralService viaticoGeneralService) {
		this.viaticoGeneralService = viaticoGeneralService;
	}

	public ConsultaRendicionService getConsultaRendicionService() {
		return consultaRendicionService;
	}

	public void setConsultaRendicionService(ConsultaRendicionService consultaRendicionService) {
		this.consultaRendicionService = consultaRendicionService;
	}

	public ConsultaSolicitudService getConsultaSolicitudService() {
		return consultaSolicitudService;
	}

	public void setConsultaSolicitudService(ConsultaSolicitudService consultaSolicitudService) {
		this.consultaSolicitudService = consultaSolicitudService;
	}

	public RegistroDependenciasService getRegistroDependenciasService() {
		return registroDependenciasService;
	}

	public void setRegistroDependenciasService(RegistroDependenciasService registroDependenciasService) {
		this.registroDependenciasService = registroDependenciasService;
	}

	public ViaticoService getViaticoService() {
		return viaticoService;
	}

	public void setViaticoService(ViaticoService viaticoService) {
		this.viaticoService = viaticoService;
	}

	public PlanViajeRendicionDAO getPlanViajeRendicionDAO() {
		return planViajeRendicionDAO;
	}

	public void setPlanViajeRendicionDAO(PlanViajeRendicionDAO planViajeRendicionDAO) {
		this.planViajeRendicionDAO = planViajeRendicionDAO;
	}

	public PlanViajeInformeDistribDAO getPlanViajeInformeDistribDAO() {
		return planViajeInformeDistribDAO;
	}

	public void setPlanViajeInformeDistribDAO(PlanViajeInformeDistribDAO planViajeInformeDistribDAO) {
		this.planViajeInformeDistribDAO = planViajeInformeDistribDAO;
	}

	public SysGlobalParametrosDAO getSysGlobalParametrosDAO() {
		return sysGlobalParametrosDAO;
	}

	public void setSysGlobalParametrosDAO(SysGlobalParametrosDAO sysGlobalParametrosDAO) {
		this.sysGlobalParametrosDAO = sysGlobalParametrosDAO;
	}

	public PlanViajeDAO getPlanViajeDAO() {
		return planViajeDAO;
	}

	public void setPlanViajeDAO(PlanViajeDAO planViajeDAO) {
		this.planViajeDAO = planViajeDAO;
	}

	public PlanViajeDestinoDAO getPlanViajeDestinoDAO() {
		return planViajeDestinoDAO;
	}

	public void setPlanViajeDestinoDAO(PlanViajeDestinoDAO planViajeDestinoDAO) {
		this.planViajeDestinoDAO = planViajeDestinoDAO;
	}

	public T01ParametroDAO getT01ParametroDAO() {
		return t01ParametroDAO;
	}

	public void setT01ParametroDAO(T01ParametroDAO t01ParametroDAO) {
		this.t01ParametroDAO = t01ParametroDAO;
	}

	/**
	 * Metodo que permite determinar si existe en BD un codigo de planilla.
	 * @author Juan Farro
	 * @param codPlanilla codigo de planilla
	 * @return true si codigo de planilla existe en BD
	 * @throws Exception
	 */
	public boolean existePlanilla(String codPlanilla) throws Exception {
		return planViajeDAO.existePlanilla(codPlanilla);
	}
	
	/**
	 * Metodo que permite obtener los datos de plan viaje para el envio de notificacion.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @return Objeto PlanViajeBean.
	 * @see    SolicitudDTO
	 * @throws Exception
	 */
	public SolicitudDTO obtenerPlanViajeToNotificacion(String codPlanViaje) {
		
		SolicitudDTO solicitudDTO = new SolicitudDTO();
		
		PlanViajeBean planViajeBean = planViajeDAO.obtenerPlanViajeToNotificacion(codPlanViaje);
		if (planViajeBean != null) {
			planViajeBean.setFecSalidaFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecSalida()));
			planViajeBean.setFecRetornoFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecRetorno()));
			planViajeBean.setFecNotificacionFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFechaNotificacion()));			
			planViajeBean.setFecMaxRendFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecMaxRend()));
			planViajeBean.setObservacionAutorizador(FormatoUtil.getUppperCaseText(planViajeBean.getObservacionAutorizador()));
			planViajeBean.setObservacionAnulacion(FormatoUtil.getUppperCaseText(planViajeBean.getObservacionAnulacion()));
			planViajeBean.setObservacionAnulacion(FormatoUtil.getUppperCaseText(planViajeBean.getObservacionAnulacion()));
			planViajeBean.setFechaRegistroFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFechaRegistro()));
			planViajeBean.setFecReprogramaRendFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecReprogramaRend()));//Fecha de reprogramación
		}
		solicitudDTO.setPlanViajeBean(planViajeBean);
		
		String codigoColaborador = planViajeBean.getCodTrabajador();
		if (codigoColaborador != null && !SolicitudConstantes.CADENA_VACIA.equals(codigoColaborador)) {
			MaestroPersonalBean colaborador = registroPersonalService.obtenerPersonaxCodigo(codigoColaborador);
			solicitudDTO.setColaborador(MaestroPersonalUtil.parseViatico(colaborador));
		}
		
		String codigoRegistrador = planViajeBean.getCodigoRegistrador();
		if (codigoRegistrador != null && !SolicitudConstantes.CADENA_VACIA.equals(codigoRegistrador)) {
			MaestroPersonalBean registrador = registroPersonalService.obtenerPersonaxCodigo(codigoRegistrador);
			solicitudDTO.setRegistrador(MaestroPersonalUtil.parseViatico(registrador));
		}
		
		String codigoDependecia = planViajeBean.getCodigoDependencia();
		if(!StringUtils.isEmpty(codigoDependecia) ){
			DependenciaBean dependencia = registroDependenciasService.obtenerDependenciaXcod(codigoDependecia);
			solicitudDTO.setDependencia(dependencia);
		}		
		
		String codigoAutorizador = planViajeBean.getCodPerAutoriza();		
		
		if (!StringUtils.isEmpty(codigoAutorizador)) {
			MaestroPersonalBean autorizador = registroPersonalService.obtenerPersonaxCodigo(codigoAutorizador);
			solicitudDTO.setAutorizador(MaestroPersonalUtil.parseViatico(autorizador));
		}
		
		return solicitudDTO;
	}
	
	
	/**
	 * Metodo que permite obtener los datos de plan viaje para el envio de notificacion.
	 * @author Sanmuel Dionisio.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @return Objeto PlanViajeBean.
	 * @see    SolicitudDTO
	 * @throws Exception
	 */
public SolicitudDTO obtenerPlanViajeToNotificacion(String codPlanViaje, List<PlanViajeBean> planViajeList){
		
		SolicitudDTO solicitudDTO = new SolicitudDTO();
		
		PlanViajeBean planViajeBean = planViajeDAO.obtenerPlanViajeToNotificacion(codPlanViaje);
		if (planViajeBean != null) {
			planViajeBean.setFecSalidaFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecSalida()));
			planViajeBean.setFecRetornoFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecRetorno()));
			planViajeBean.setFecNotificacionFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFechaNotificacion()));
			planViajeBean.setFecMaxRendFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecMaxRend()));
			planViajeBean.setObservacionAutorizador(FormatoUtil.getUppperCaseText(planViajeBean.getObservacionAutorizador()));
			planViajeBean.setObservacionAnulacion(FormatoUtil.getUppperCaseText(planViajeBean.getObservacionAnulacion()));
		}
		solicitudDTO.setPlanViajeBean(planViajeBean);
		
		String codigoColaborador = planViajeBean.getCodTrabajador();
		if (codigoColaborador != null && !SolicitudConstantes.CADENA_VACIA.equals(codigoColaborador)) {
			MaestroPersonalBean colaborador = registroPersonalService.obtenerPersonaxCodigo(codigoColaborador);
			solicitudDTO.setColaborador(MaestroPersonalUtil.parseViatico(colaborador));
		}
		
		String codigoRegistrador = planViajeBean.getCodigoRegistrador();
		if (codigoRegistrador != null && !SolicitudConstantes.CADENA_VACIA.equals(codigoRegistrador)) {
			MaestroPersonalBean registrador = registroPersonalService.obtenerPersonaxCodigo(codigoRegistrador);
			solicitudDTO.setRegistrador(MaestroPersonalUtil.parseViatico(registrador));
		}
		
		String codigoAutorizador = planViajeBean.getCodPerAutoriza();
		if (!StringUtils.isEmpty(codigoAutorizador)) {
			MaestroPersonalBean autorizador = registroPersonalService.obtenerPersonaxCodigo(codigoAutorizador);
			solicitudDTO.setAutorizador(MaestroPersonalUtil.parseViatico(autorizador));
		}
		/***para univesal****/
		/*try{			
			List<String> codigoRegistroUniversal = viaticoGeneralService.registradorUniversal();
			List<ColaboradorViaticoBean> registradorUniversalList = new ArrayList<ColaboradorViaticoBean>();
			if(CollectionUtils.isNotEmpty(codigoRegistroUniversal)){
				for(int i = 0; i < codigoRegistroUniversal.size(); i++){					
					String codigoRegistradoUniversal = codigoRegistroUniversal.get(i);				
						MaestroPersonalBean registradorUniversalB = registroPersonalService.obtenerPersonaxCodigo(codigoRegistradoUniversal);
						ColaboradorViaticoBean colaboradorViatico = MaestroPersonalUtil.parseViatico(registradorUniversalB);							
						registradorUniversalList.add(colaboradorViatico);
				}				
				solicitudDTO.setRegistradorUniversal(registradorUniversalList);
			}
			
		}catch(Exception e){
			log.error("Error de viaticoGeneralService.registradorUniversal()", e);
		}*/
			
		
		
		List<PlanViajeBean> listaPlanViaje = new ArrayList<PlanViajeBean>();
		for(PlanViajeBean planViaje : planViajeList){
			PlanViajeBean planViajeB = new PlanViajeBean();
			planViajeB = planViajeDAO.buscarPlanViaje(planViaje.getCodPlanViaje());
			codigoColaborador = planViajeB.getCodTrabajador();
			if (codigoColaborador != null && !SolicitudConstantes.CADENA_VACIA.equals(codigoColaborador)) {
				MaestroPersonalBean colaborador = registroPersonalService.obtenerPersonaxCodigo(codigoColaborador);
				solicitudDTO.setColaborador(MaestroPersonalUtil.parseViatico(colaborador));
				planViajeB.setNomColaborador(colaborador.getNombre_completo());
			}
			
			listaPlanViaje.add(planViajeB);
		}
		solicitudDTO.setPlanViajeList(listaPlanViaje);
		
		return solicitudDTO;
	}

/**
 * Metodo que permite obtener los datos de plan viaje para el envio de notificacion.
 * @author Sanmuel Dionisio.
 * @param  planViajeList :lista codigo plan viaje.
 * @return Objeto PlanViajeBean.
 * @see    List<SolicitudDTO>
 * @throws Exception
 */
public List<SolicitudDTO> obtenerPlanViajeToNotificacionList(List<PlanViajeBean> planViajeList){
	log.debug("obtenerPlanViajeToNotificacionList INICIO");
	List<PlanViajeBean> listaPlanViaje = new ArrayList<PlanViajeBean>();
	for(PlanViajeBean planViaje : planViajeList){
		PlanViajeBean planViajeB = new PlanViajeBean();
		planViajeB = planViajeDAO.buscarPlanViaje(planViaje.getCodPlanViaje());
		listaPlanViaje.add(planViajeB);
	}
	log.debug("NUMERO DE REGISTOR planViajeList "+planViajeList.size());
	List<SolicitudDTO> solicitudDTOList = new ArrayList<SolicitudDTO>();
	//List<PlanViajeBean> listaPlanViajeF = new ArrayList<PlanViajeBean>();
	
	
	if(CollectionUtils.isNotEmpty(listaPlanViaje)){		
		String codTrabajadorInicial = ViaticoConstantes.CADENA_VACIA;
		//String codPlanViajeInicio = listaPlanViaje.get(0).getCodTrabajador();
		//String codPlanViajeFin = listaPlanViaje.get(listaPlanViaje.size()-1).getCodTrabajador();
		SolicitudDTO solicitudDTO = null;
		  
		List<PlanViajeBean> listaPlanViajeN = null;
		int contador = 0;
		for (PlanViajeBean planViajeBeanN : listaPlanViaje) {
			log.debug("getCodTrabajador "+planViajeBeanN.getCodTrabajador());
			log.debug("Contador:" + contador); 
			  if(StringUtils.isNotEmpty(planViajeBeanN.getCodTrabajador())){
				  
				if(codTrabajadorInicial.equals(planViajeBeanN.getCodTrabajador())){
					listaPlanViajeN.add(planViajeBeanN);
					if (contador == listaPlanViaje.size() - 1) {
						solicitudDTO.setPlanViajeList(listaPlanViajeN);
						solicitudDTOList.add(solicitudDTO);
					}
				}else {
					log.debug("agregar nuevo planilla");
					if (contador == 0) {
					//primero
						
						solicitudDTO = new SolicitudDTO();
						solicitudDTO=setColaborador(planViajeBeanN, solicitudDTO);
						listaPlanViajeN = new ArrayList<PlanViajeBean>();
						if (contador == listaPlanViaje.size() - 1) {
							log.debug("Primero Y Ultimo");
							listaPlanViajeN.add(planViajeBeanN);
							solicitudDTO.setPlanViajeList(listaPlanViajeN);
							solicitudDTOList.add(solicitudDTO);
						}else{
							log.debug("Primero");
							listaPlanViajeN.add(planViajeBeanN);
							
						}
						
						
					}else 	 if (contador != 0) {
						//ultimo
						log.debug("otro");
						//seteando el penultimo
						solicitudDTO.setPlanViajeList(listaPlanViajeN);
						solicitudDTOList.add(solicitudDTO);
						
						
						solicitudDTO = new SolicitudDTO();
						solicitudDTO=setColaborador(planViajeBeanN, solicitudDTO);
						listaPlanViajeN = new ArrayList<PlanViajeBean>();
						listaPlanViajeN.add(planViajeBeanN);
						if (contador == listaPlanViaje.size() - 1) {
							log.debug("Ultimo");
							//seteando el ultimo
							solicitudDTO.setPlanViajeList(listaPlanViajeN);
							solicitudDTOList.add(solicitudDTO);
						}
					}
					codTrabajadorInicial=planViajeBeanN.getCodTrabajador();
					
					
				}
				  contador++;
			  }
		  }
		
		
		 
	}
	
		
	return solicitudDTOList;
}

private SolicitudDTO setColaborador(PlanViajeBean planViajeBeanN, SolicitudDTO solicitudDTO ){
	String codTrabajadorInicial = planViajeBeanN.getCodTrabajador();
	MaestroPersonalBean colaborador = registroPersonalService.obtenerPersonaxCodigo(codTrabajadorInicial);
	
	if(StringUtils.isNotEmpty(planViajeBeanN.getCodigoRegistrador())){
		MaestroPersonalBean registrador = registroPersonalService.obtenerPersonaxCodigo(planViajeBeanN.getCodigoRegistrador());
		solicitudDTO.setRegistrador(MaestroPersonalUtil.parseViatico(registrador));
	}
	
	if(StringUtils.isNotEmpty(planViajeBeanN.getPersonaAutorizacionVigente())){
		MaestroPersonalBean autorizador = registroPersonalService.obtenerPersonaxCodigo(planViajeBeanN.getPersonaAutorizacionVigente());
		solicitudDTO.setAutorizador(MaestroPersonalUtil.parseViatico(autorizador));}
	
	solicitudDTO.setColaborador(MaestroPersonalUtil.parseViatico(colaborador));
	
	return solicitudDTO;
}


/**
 * Metodo que permite obtener los datos de plan viaje para el envio de notificacion al registrador universal
 * @author Sanmuel Dionisio.
 * @param  codPlanViaje :codigo plan viaje.
 * @return Objeto PlanViajeBean.
 * @see    SolicitudDTO
 * @throws Exception
 */
public SolicitudDTO obtenerPlanViajeToNotificacionRegistradorUniversal(String codPlanViaje, List<PlanViajeBean> planViajeList){
	
	SolicitudDTO solicitudDTO = new SolicitudDTO();
	
	PlanViajeBean planViajeBean = planViajeDAO.obtenerPlanViajeToNotificacion(codPlanViaje);
	if (planViajeBean != null) {
		planViajeBean.setFecSalidaFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecSalida()));
		planViajeBean.setFecRetornoFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecRetorno()));
		planViajeBean.setFecNotificacionFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFechaNotificacion()));
		planViajeBean.setFecMaxRendFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecMaxRend()));
		planViajeBean.setObservacionAutorizador(FormatoUtil.getUppperCaseText(planViajeBean.getObservacionAutorizador()));
		planViajeBean.setObservacionAnulacion(FormatoUtil.getUppperCaseText(planViajeBean.getObservacionAnulacion()));
	}
	solicitudDTO.setPlanViajeBean(planViajeBean);
	
	String codigoColaborador = planViajeBean.getCodTrabajador();
	if (codigoColaborador != null && !SolicitudConstantes.CADENA_VACIA.equals(codigoColaborador)) {
		MaestroPersonalBean colaborador = registroPersonalService.obtenerPersonaxCodigo(codigoColaborador);
		solicitudDTO.setColaborador(MaestroPersonalUtil.parseViatico(colaborador));
	}
	
	String codigoRegistrador = planViajeBean.getCodigoRegistrador();
	if (codigoRegistrador != null && !SolicitudConstantes.CADENA_VACIA.equals(codigoRegistrador)) {
		MaestroPersonalBean registrador = registroPersonalService.obtenerPersonaxCodigo(codigoRegistrador);
		solicitudDTO.setRegistrador(MaestroPersonalUtil.parseViatico(registrador));
	}
	
	String codigoAutorizador = planViajeBean.getCodPerAutoriza();
	if (!StringUtils.isEmpty(codigoAutorizador)) {
		MaestroPersonalBean autorizador = registroPersonalService.obtenerPersonaxCodigo(codigoAutorizador);
		solicitudDTO.setAutorizador(MaestroPersonalUtil.parseViatico(autorizador));
	}
	
	List<PlanViajeBean> listaPlanViaje = new ArrayList<PlanViajeBean>();
	for(PlanViajeBean planViaje : planViajeList){
		PlanViajeBean planViajeB = new PlanViajeBean();
		planViajeB = planViajeDAO.buscarPlanViaje(planViaje.getCodPlanViaje());
		codigoColaborador = planViajeB.getCodTrabajador();
		if (codigoColaborador != null && !SolicitudConstantes.CADENA_VACIA.equals(codigoColaborador)) {
			MaestroPersonalBean colaborador = registroPersonalService.obtenerPersonaxCodigo(codigoColaborador);
			solicitudDTO.setColaborador(MaestroPersonalUtil.parseViatico(colaborador));
			planViajeB.setNomColaborador(colaborador.getNombre_completo());
		}
		
		listaPlanViaje.add(planViajeB);
	}
	solicitudDTO.setPlanViajeList(listaPlanViaje);
	
	return solicitudDTO;
}


/**
 * Metodo que obtiene listas, clases para la informacion del documento sustentario.
 * 
 * @author Samuel Donisio.
 * @param codPlanViaje : String.
 * @param secuencia : String.
 * @return mensaje de error o exito.
 * @see DocumentoSustentarioDTO
 * @throws Exception
 */

public DocumentoSustentarioDTO obtenerDocumentoSustentario(String codPlanViaje, String secuencia) {
	log.debug(getClass().getName() + " Inicio del metodo documentoSustentario");
	int tamanio = RendicionConstantes.NUMERO_CERO;
	DocumentoSustentarioDTO documentoSustentarioDto = new DocumentoSustentarioDTO();
	String moneda = RendicionConstantes.CADENA_VACIA;
	boolean estadoDocumentoSustentario = false;
	Map<String, Object> param = new HashMap<String, Object>();
	Double montoTotalInformeDistribucion = 0D;
	try {
		List<PlanViajeRendicionBean> listaPlanViajeRendicion = planViajeRendicionDAO.obtenerListaPlanViajeRendicion(codPlanViaje);
		SysGlobalParametrosBean sysGlobalParametros = sysGlobalParametrosDAO.obtenerIgv();
		PlanViajeBean planViaje = consultaSolicitudService.buscarPlanViaje(codPlanViaje);
			
		tamanio = listaPlanViajeRendicion.size();
		if (tamanio >= RendicionConstantes.NUMERO_UNO && !StringUtils.isEmpty(secuencia)) {
			log.debug("<<<<<<<<<<<<<<< Editar >>>>>>>>>>>>>>" );
			listaPlanViajeRendicion = planViajeRendicionDAO.obtenerDocumentoSustentario(codPlanViaje, secuencia);
			planViaje = consultaSolicitudService.buscarPlanViaje(codPlanViaje);
			Map<String, Object> parametro =  new HashMap<String, Object>();
			parametro.put("ruc", listaPlanViajeRendicion.get(0).getRuc());
			montoTotalInformeDistribucion = listaPlanViajeRendicion.get(0).getMontoRendicion();
			List<PlanViajeInformeDistribBean> listaPlanViajeInformeDistrib = planViajeInformeDistribDAO.obtenerListaPlanViajeInformeDistrib(codPlanViaje, secuencia);
			param.put("cod_par",  ViaticoConstantes.EXONERACION_CODIGO_PARAMETRO);
			param.put("cod_tipo", ViaticoConstantes.EXONERACION_CODIGO_TIPO);
			@SuppressWarnings("unchecked")
			List<T01ParametroBean> listaExoneracion = (List<T01ParametroBean>) t01ParametroDAO.recuperarParametroLista(param);
			if (planViaje != null) moneda = planViaje.getMoneda();
			else
				moneda = RendicionConstantes.CADENA_VACIA;
			documentoSustentarioDto.setMoneda(moneda);
			estadoDocumentoSustentario = true;
			documentoSustentarioDto.setEstadoDocumentoSustentario(estadoDocumentoSustentario);
			documentoSustentarioDto.setListaExoneracion(listaExoneracion);
			documentoSustentarioDto.setPlanViajeBean(planViaje);
			if (!CollectionUtils.isEmpty(listaPlanViajeInformeDistrib)) {
				List<PlanViajeInformeDistribBean> listacalculoInformeDistrib = calculoInformeDistrib(listaPlanViajeInformeDistrib, planViaje);
				documentoSustentarioDto.setListaPlanViajeInformeDistrib(listacalculoInformeDistrib);
			}
			documentoSustentarioDto.setEstadoDocumento(ViaticoConstantes.UNO_INT);
		} else if (tamanio == RendicionConstantes.NUMERO_CERO || (tamanio >= RendicionConstantes.NUMERO_UNO && StringUtils.isEmpty(secuencia))) {
			log.debug("<<<<<<<<<<<<<<< Nuevo >>>>>>>>>>>>>>" );
			montoTotalInformeDistribucion = 0D;
			planViaje = consultaSolicitudService.buscarPlanViaje(codPlanViaje);
			param.put("cod_par", ViaticoConstantes.EXONERACION_CODIGO_PARAMETRO);
			param.put("cod_tipo", ViaticoConstantes.EXONERACION_CODIGO_TIPO);
			@SuppressWarnings("unchecked")
			List<T01ParametroBean> listaExoneracion = (List<T01ParametroBean>) t01ParametroDAO.recuperarParametroLista(param);
			List<PlanViajeInformeDistribBean> listaPlanViajeInformeDistrib = planViajeInformeDistribDAO.obtenerListaPlanViajeInformeDistrib(codPlanViaje, secuencia);
			if (planViaje != null) moneda = planViaje.getMoneda();
			else
				moneda = RendicionConstantes.CADENA_VACIA;
			documentoSustentarioDto.setMoneda(moneda);
			estadoDocumentoSustentario = false;
			documentoSustentarioDto.setEstadoDocumentoSustentario(estadoDocumentoSustentario);
			documentoSustentarioDto.setListaExoneracion(listaExoneracion);
			documentoSustentarioDto.setPlanViajeBean(planViaje);
			if (!CollectionUtils.isEmpty(listaPlanViajeInformeDistrib)) {
				List<PlanViajeInformeDistribBean> listacalculoInformeDistrib = calculoInformeDistrib(listaPlanViajeInformeDistrib, planViaje);
				documentoSustentarioDto.setListaPlanViajeInformeDistrib(listacalculoInformeDistrib);
			}
			documentoSustentarioDto.setEstadoDocumento(ViaticoConstantes.CERO_INT);
		}
		Double igv = sysGlobalParametros.getValoNumePar();
		
		igv = igv/ViaticoConstantes.CIEN;
		documentoSustentarioDto.setIgv(igv);
		documentoSustentarioDto.setListaPlanViajeRendicion(listaPlanViajeRendicion);
		documentoSustentarioDto.setMontoTotalRendicion(montoTotalInformeDistribucion);

		
		List<TipoDocumentoBean> tipoDocumentoList = new ArrayList<TipoDocumentoBean>();
		List<TipoDocumentoBean> tipoDocumentoListAux = new ArrayList<TipoDocumentoBean>();
		ArrayList<PlanViajeConceptoBean> planViajeConceptoList = new ArrayList<PlanViajeConceptoBean>(); 
		Integer inicio = ViaticoConstantes.CERO_INT;
		tipoDocumentoList = viaticoGeneralService.obtenerTipoDocumentoToComprobante();
		if(planViaje != null){
			for(inicio = 0; inicio < tipoDocumentoList.size() ;inicio++){
				if(ViaticoConstantes.TIPO_COMISION_NACIONAL.equals(planViaje.getTipoDestino())){
					if(!ViaticoConstantes.TIPO_DOCUMENTO_COMPROBANTE_EXTERIOR.equals(tipoDocumentoList.get(inicio).getCodigoTipoDocumento()))
							tipoDocumentoListAux.add(tipoDocumentoList.get(inicio));
				
				}else if(ViaticoConstantes.TIPO_COMISION_INTERNACIONAL.equals(planViaje.getTipoDestino())){
					if(ViaticoConstantes.TIPO_DOCUMENTO_COMPROBANTE_EXTERIOR.equals(tipoDocumentoList.get(inicio).getCodigoTipoDocumento())
							|| ViaticoConstantes.TIPO_DOCUMENTO_DECLARACION_COMPROBANTE_PAGO.equals(tipoDocumentoList.get(inicio).getCodigoTipoDocumento())
							|| ViaticoConstantes.TIPO_DOCUMENTO_DECLARACION_VIATICO.equals(tipoDocumentoList.get(inicio).getCodigoTipoDocumento()))
						tipoDocumentoListAux.add(tipoDocumentoList.get(inicio));
				}
			}	
				planViajeConceptoList = consultaRendicionService.obtenerPlanViajeConcepto(planViaje.getCodPlanViaje(),ViaticoConstantes.CADENA_VACIA);
				if(CollectionUtils.isNotEmpty(planViajeConceptoList))
					planViajeConceptoList.remove(planViajeConceptoList.size()-1);
				
				ArrayList<PlanViajeConceptoBean> planViajeConceptoFijoList = new ArrayList<PlanViajeConceptoBean>();
				if(ViaticoConstantes.TIPO_ORIGEN_REEMBOLSO.equals(planViaje.getOrigen()) && ViaticoConstantes.TIPO_TRASLADO_VIATICOS.equals(planViaje.getCodigoTipoTraslado())){
					ArrayList<PlanViajeConceptoBean> planViajeConceptoLista = new ArrayList<PlanViajeConceptoBean>(); 
					planViajeConceptoFijoList.add(planViajeConceptoList.get(0));
					if(ViaticoConstantes.TIPO_COMISION_NACIONAL.equals(planViaje.getTipoDestino())){
						 List<ConceptoPlanillaViaticosBean>  conceptoPlanillaViaticoList = viaticoService.obtenerConceptosViaticoNacional();
						 if(CollectionUtils.isNotEmpty(conceptoPlanillaViaticoList)){
							 for(ConceptoPlanillaViaticosBean conceptoPlanillaViaticosB : conceptoPlanillaViaticoList){
								 PlanViajeConceptoBean planViajeConceptoB = new PlanViajeConceptoBean();
								 planViajeConceptoB.setClasificadorGasto(conceptoPlanillaViaticosB.getClasificadorGasto());
								 planViajeConceptoB.setDescripcionConcepto(conceptoPlanillaViaticosB.getDescripcionConcepto());
								 planViajeConceptoB.setConceptoID(conceptoPlanillaViaticosB.getCodigoConcepto());
								 planViajeConceptoLista.add(planViajeConceptoB);
							}
						 }
					}else if(ViaticoConstantes.TIPO_COMISION_INTERNACIONAL.equals(planViaje.getTipoDestino())){
						 List<ConceptoPlanillaViaticosBean>  conceptoPlanillaViaticoList = viaticoService.obtenerConceptosViaticoInternacional();
						 if(CollectionUtils.isNotEmpty(conceptoPlanillaViaticoList)){
							 for(ConceptoPlanillaViaticosBean conceptoPlanillaViaticosB : conceptoPlanillaViaticoList){
								 PlanViajeConceptoBean planViajeConceptoB = new PlanViajeConceptoBean();
								 planViajeConceptoB.setClasificadorGasto(conceptoPlanillaViaticosB.getClasificadorGasto());
								 planViajeConceptoB.setConceptoID(conceptoPlanillaViaticosB.getCodigoConcepto());
								 planViajeConceptoB.setDescripcionConcepto(conceptoPlanillaViaticosB.getDescripcionConcepto());
								 planViajeConceptoLista.add(planViajeConceptoB);
							}
						 }
					}
					planViajeConceptoFijoList.addAll(planViajeConceptoLista);
					planViajeConceptoList = planViajeConceptoFijoList;
				}
				
				String porcentajeDeclaracion = ViaticoConstantes.CADENA_VACIA;
				if(ViaticoConstantes.TIPO_COMISION_NACIONAL.equals(planViaje.getTipoDestino())){
					Map<String, Object> parametro = new HashMap<String, Object>();
					parametro.put("cod_par", ViaticoConstantes.CODIGO_PARAMETRO_PORCENTAJE_DDJJ);
					parametro.put("cod_mod", ViaticoConstantes.CODIGO_MODULO);
					parametro.put("cod_tipo", ViaticoConstantes.CODIGO_TIPO);
					parametro.put("cod_arg", ViaticoConstantes.CODIGO_ARGUMENTO_NACIONAL_MAYOR_4);
					T01ParametroBean porcetajeNacional = t01ParametroDAO.recuperarParametro(parametro);
					if(porcetajeNacional != null){
					  if(StringUtils.isNotEmpty(porcetajeNacional.getDesc_abrv()))	
						  porcentajeDeclaracion = porcetajeNacional.getDesc_abrv();
					}
				}
				else{
					Map<String, Object> parametro = new HashMap<String, Object>();
					parametro.put("cod_par", ViaticoConstantes.CODIGO_PARAMETRO_PORCENTAJE_DDJJ);
					parametro.put("cod_mod", ViaticoConstantes.CODIGO_MODULO);
					parametro.put("cod_tipo", ViaticoConstantes.CODIGO_TIPO);
					parametro.put("cod_arg", ViaticoConstantes.CODIGO_ARGUMENTO_INTERNACIONAL);
					T01ParametroBean porcetajeIntenacional = t01ParametroDAO.recuperarParametro(parametro);
					if(porcetajeIntenacional != null){
						  if(StringUtils.isNotEmpty(porcetajeIntenacional.getDesc_abrv()))	
							  porcentajeDeclaracion = porcetajeIntenacional.getDesc_abrv();
						}
				}
				documentoSustentarioDto.setPorcentajeDeclaracion(porcentajeDeclaracion);
		}
		else {
			tipoDocumentoListAux =  null;
		}
			
		documentoSustentarioDto.setTipoDocumentoList(tipoDocumentoListAux);
		documentoSustentarioDto.setPlanViajeConceptoList(planViajeConceptoList);
		
		documentoSustentarioDto =  calculoMontoFechaDestino(documentoSustentarioDto);
		
	} catch (Exception e) {
		log.error("Error obtenerDocumentoSustentario" + e.getMessage(), e);

	} finally {
		log.debug(getClass().getName() + " Fin del metodo documentoSustentario");
	}

	return documentoSustentarioDto;
}

/**
 * Metodo que permite calcula la lista para colocar todas las columnas en filas de la tabla de plan viaje informe distribucion.
 * 
 * @author Samuel Donisio.
 * @param listaPlanViajeInformeDistrib : List.
 * @return mensaje de error o exito.
 * @see PlanViajeInformeDistribBean
 * @throws Exception
 */

private List<PlanViajeInformeDistribBean> calculoInformeDistrib(List<PlanViajeInformeDistribBean> listaPlanViajeInformeDistrib, PlanViajeBean planViaje) {
	log.debug(getClass().getName() + " Inicio del metodo calculoInformeDistrib");
	List<PlanViajeInformeDistribBean> listaPlanViajeInforme = new ArrayList<PlanViajeInformeDistribBean>();
	int inicio = ViaticoConstantes.CERO_INT;
	Date fechaViaticoData = new Date();
	PlanViajeInformeDistribBean planViajeDistrib = new PlanViajeInformeDistribBean();
	fechaViaticoData = listaPlanViajeInformeDistrib.get(0).getFecViatico();
	int tamanio = listaPlanViajeInformeDistrib.size();
	for (inicio = ViaticoConstantes.CERO_INT; inicio < tamanio; inicio++) {

		if (fechaViaticoData.equals(listaPlanViajeInformeDistrib.get(inicio).getFecViatico())) {
			if (ViaticoConstantes.CONCEPTOS_VIATICOS_ALIMENTACION.equals(listaPlanViajeInformeDistrib.get(inicio).getIndItinerario())) {
				planViajeDistrib.setMontoDocumentoAlimentacion(listaPlanViajeInformeDistrib.get(inicio).getMtoDocumento());
			} else if (ViaticoConstantes.CONCEPTOS_VIATICOS_HOSPEDAJE.equals(listaPlanViajeInformeDistrib.get(inicio).getIndItinerario())) {
				planViajeDistrib.setMontoDocumentoHospedaje(listaPlanViajeInformeDistrib.get(inicio).getMtoDocumento());
			} else if (ViaticoConstantes.CONCEPTOS_VIATICOS_MOVILIDAD_LOCAL.equals(listaPlanViajeInformeDistrib.get(inicio).getIndItinerario())) {
				planViajeDistrib.setMontoDocumentoMovilidad(listaPlanViajeInformeDistrib.get(inicio).getMtoDocumento());
			} else if (ViaticoConstantes.CONCEPTOS_VIATICOS_TRASLADOS_AL_DEL.equals(listaPlanViajeInformeDistrib.get(inicio).getIndItinerario())) {
				planViajeDistrib.setMontoDocumentoTranslado(listaPlanViajeInformeDistrib.get(inicio).getMtoDocumento());
			}
			planViajeDistrib.setFecViatico(fechaViaticoData);

			if (fechaViaticoData.equals(listaPlanViajeInformeDistrib.get(tamanio - 1).getFecViatico()) && inicio == (tamanio - 1)) {
				listaPlanViajeInforme.add(planViajeDistrib);
			}
		} else {
			listaPlanViajeInforme.add(planViajeDistrib);
			fechaViaticoData = listaPlanViajeInformeDistrib.get(inicio).getFecViatico();
			inicio = inicio - 1;
			planViajeDistrib = new PlanViajeInformeDistribBean();
		}
	}

	log.debug(getClass().getName() + " Fin del metodo calculoInformeDistrib");

	return listaPlanViajeInforme;
}

private DocumentoSustentarioDTO calculoMontoFechaDestino(DocumentoSustentarioDTO documentoSustentarioDto) {
	log.debug(getClass().getName() + " Inicio del metodo calculoMontoFechaDestino");
	List<PlanViajeInformeDistribBean> listaPlanViajeInforme = new ArrayList<PlanViajeInformeDistribBean>();// documentoSustentarioDto.getListaPlanViajeInformeDistrib();
	
	int inicio = ViaticoConstantes.CERO_INT;
	int inicioEdicion = ViaticoConstantes.CERO_INT;
	int diferenciaDias = ViaticoConstantes.CERO_INT;	
	boolean estadoDocumentoSustentario = documentoSustentarioDto.isEstadoDocumentoSustentario();
	List<PlanViajeInformeDistribBean> listaPlanViajeInformeDitribucion = new ArrayList<PlanViajeInformeDistribBean>();
	PlanViajeInformeDistribBean planViajeInformeDistribucion = new PlanViajeInformeDistribBean();
	if(estadoDocumentoSustentario){
		log.debug("Editar Documento sustentario.");	
		
		if (ViaticoConstantes.TIPO_COMISION_NACIONAL.equals(documentoSustentarioDto.getPlanViajeBean().getTipoDestino())) {
			log.debug("Viatico Nacional.");
			if (ViaticoConstantes.DURACION_COMISION_MENOR_IGUAL_4H.equals(documentoSustentarioDto.getPlanViajeBean().getIndicadorHoras())) {
				log.debug("Viatico Nacional  menor o igual a 4 horas");		
							
				Date fecViatico = documentoSustentarioDto.getPlanViajeBean().getFechaHoraProgSalidaDDMMYYYY();
				listaPlanViajeInformeDitribucion = documentoSustentarioDto.getListaPlanViajeInformeDistrib();
				listaPlanViajeInformeDitribucion.get(0).setFecViatico(fecViatico);
				
			} else {

				log.debug("Viatico Nacional  mayor a 4 horas");
				//int diferenciaDiasNacional = ViaticoUtil.restarDias(documentoSustentarioDto.getPlanViajeBean().getFechaHoraProgRetorno(), documentoSustentarioDto.getPlanViajeBean().getFechaHoraProgSalida());
				int diferenciaDiasNacional = ViaticoUtil.restarDias(documentoSustentarioDto.getPlanViajeBean().getFechaHoraEjeRetorno(), documentoSustentarioDto.getPlanViajeBean().getFechaHoraEjeSalida());
				diferenciaDias = diferenciaDiasNacional;
				for (inicio = ViaticoConstantes.CERO_INT; inicio <= diferenciaDias; inicio++) {
					planViajeInformeDistribucion = new PlanViajeInformeDistribBean();
					Date fecViatico = ViaticoUtil.addDiasToDate(documentoSustentarioDto.getPlanViajeBean().getFechaHoraEjeSalida(), inicio);
					planViajeInformeDistribucion.setFecViatico(fecViatico);
					listaPlanViajeInformeDitribucion.add(planViajeInformeDistribucion);
				}

				if (!CollectionUtils.isEmpty(documentoSustentarioDto.getListaPlanViajeInformeDistrib())) {
					for (inicio = ViaticoConstantes.CERO_INT; inicio < listaPlanViajeInformeDitribucion.size(); inicio++) {
						for (inicioEdicion = ViaticoConstantes.CERO_INT; inicioEdicion < documentoSustentarioDto.getListaPlanViajeInformeDistrib().size(); inicioEdicion++) {
							if (listaPlanViajeInformeDitribucion.get(inicio).getFecViatico().equals(documentoSustentarioDto.getListaPlanViajeInformeDistrib().get(inicioEdicion).getFecViatico())) {
								log.debug("fecha: " + documentoSustentarioDto.getListaPlanViajeInformeDistrib().get(inicioEdicion).getFecViatico() + "montoTope: " + documentoSustentarioDto.getListaPlanViajeInformeDistrib().get(inicioEdicion).getMontoDestionFecha());
								listaPlanViajeInformeDitribucion.set(inicio, documentoSustentarioDto.getListaPlanViajeInformeDistrib().get(inicioEdicion));
							}
						}
					}
				}											
			}							
			
		}else if (ViaticoConstantes.TIPO_COMISION_INTERNACIONAL.equals(documentoSustentarioDto.getPlanViajeBean().getTipoDestino())) {
			log.debug("Viatico Internacional");
			int diferenciaDiasInternacional = ViaticoUtil.restarDias(documentoSustentarioDto.getPlanViajeBean().getFechaHoraEjeRetorno(), documentoSustentarioDto.getPlanViajeBean().getFechaHoraEjeSalida());
			diferenciaDias = diferenciaDiasInternacional;
			log.debug("diferenciaDias: " + diferenciaDias);
			for (inicio = ViaticoConstantes.CERO_INT; inicio <= diferenciaDias; inicio++) {
				planViajeInformeDistribucion = new PlanViajeInformeDistribBean();
				Date fecViatico = ViaticoUtil.addDiasToDate(documentoSustentarioDto.getPlanViajeBean().getFechaHoraEjeSalida(), inicio);
				log.debug("fecViatico: " + fecViatico);
				planViajeInformeDistribucion.setFecViatico(fecViatico);
				listaPlanViajeInformeDitribucion.add(planViajeInformeDistribucion);
			}

			if (!CollectionUtils.isEmpty(documentoSustentarioDto.getListaPlanViajeInformeDistrib())) {
				for (inicio = ViaticoConstantes.CERO_INT; inicio < listaPlanViajeInformeDitribucion.size(); inicio++) {

					for (inicioEdicion = ViaticoConstantes.CERO_INT; inicioEdicion < documentoSustentarioDto.getListaPlanViajeInformeDistrib().size(); inicioEdicion++) {
						if (listaPlanViajeInformeDitribucion.get(inicio).getFecViatico().equals(documentoSustentarioDto.getListaPlanViajeInformeDistrib().get(inicioEdicion).getFecViatico())) {
							listaPlanViajeInformeDitribucion.set(inicio, documentoSustentarioDto.getListaPlanViajeInformeDistrib().get(inicioEdicion));
						}
					}
				}			
			}
		}
		listaPlanViajeInforme = listaPlanViajeInformeDitribucion;		
		
	}else{
		List<PlanViajeInformeDistribBean> listaPlanViajeInformeDitrib = new ArrayList<PlanViajeInformeDistribBean>();
		PlanViajeInformeDistribBean planViajeInformeDistrib = new PlanViajeInformeDistribBean();

		if (ViaticoConstantes.TIPO_COMISION_NACIONAL.equals(documentoSustentarioDto.getPlanViajeBean().getTipoDestino())) {
			log.debug("Viatico Nacional.");
			if (ViaticoConstantes.DURACION_COMISION_MENOR_IGUAL_4H.equals(documentoSustentarioDto.getPlanViajeBean().getIndicadorHoras())) {
				log.debug("Viatico Nacional  menor o igual a 4 horas");
				Date fecViatico = documentoSustentarioDto.getPlanViajeBean().getFechaHoraProgSalidaDDMMYYYY();
				planViajeInformeDistrib.setFecViatico(fecViatico);
				listaPlanViajeInformeDitrib.add(planViajeInformeDistrib);
			} else {
				log.debug("Viatico Nacional  mayor a 4 horas");
				//int diferenciaDiasNacional = ViaticoUtil.restarDias(documentoSustentarioDto.getPlanViajeBean().getFechaHoraProgRetorno(), documentoSustentarioDto.getPlanViajeBean().getFechaHoraProgSalida());
				int diferenciaDiasNacional = ViaticoUtil.restarDias(documentoSustentarioDto.getPlanViajeBean().getFechaHoraEjeRetorno(), documentoSustentarioDto.getPlanViajeBean().getFechaHoraEjeSalida());
				diferenciaDias = diferenciaDiasNacional;
				for (inicio = ViaticoConstantes.CERO_INT; inicio <= diferenciaDias; inicio++) {
					planViajeInformeDistrib = new PlanViajeInformeDistribBean();
					Date fecViatico = ViaticoUtil.addDiasToDate(documentoSustentarioDto.getPlanViajeBean().getFechaHoraEjeSalida(), inicio);
					planViajeInformeDistrib.setFecViatico(fecViatico);
					listaPlanViajeInformeDitrib.add(planViajeInformeDistrib);
				}
			}

		} else if (ViaticoConstantes.TIPO_COMISION_INTERNACIONAL.equals(documentoSustentarioDto.getPlanViajeBean().getTipoDestino())) {
			log.debug("Viatico Internacional");
			int diferenciaDiasInternacional = ViaticoUtil.restarDias(documentoSustentarioDto.getPlanViajeBean().getFechaHoraEjeRetorno(), documentoSustentarioDto.getPlanViajeBean().getFechaHoraEjeSalida());
			diferenciaDias = diferenciaDiasInternacional;
			log.debug("diferenciaDias: " + diferenciaDias);
			for (inicio = ViaticoConstantes.CERO_INT; inicio <= diferenciaDias; inicio++) {
				planViajeInformeDistrib = new PlanViajeInformeDistribBean();
				Date fecViatico = ViaticoUtil.addDiasToDate(documentoSustentarioDto.getPlanViajeBean().getFechaHoraEjeSalida(), inicio);
				log.debug("fecViatico: " + fecViatico);
				planViajeInformeDistrib.setFecViatico(fecViatico);				
				listaPlanViajeInformeDitrib.add(planViajeInformeDistrib);
			}
		}		
		listaPlanViajeInforme = listaPlanViajeInformeDitrib;
	}		
	
	PlanViajeBean planViaje = documentoSustentarioDto.getPlanViajeBean();
	Map<Object, PlanViajeDestinoBean> fechas = new TreeMap<Object, PlanViajeDestinoBean>();
	List<Map<Object, PlanViajeDestinoBean>> fechasList = new ArrayList<Map<Object,PlanViajeDestinoBean>>();
	
	List<PlanViajeDestinoBean> planViajeDestinoDiasAndHorasList =  new ArrayList<PlanViajeDestinoBean>();
	if (ViaticoConstantes.DURACION_COMISION_MENOR_IGUAL_4H.equals(documentoSustentarioDto.getPlanViajeBean().getIndicadorHoras())){
		planViajeDestinoDiasAndHorasList = planViajeDestinoDAO.buscarPlanViajeDestinos(planViaje.getCodPlanViaje());	
		Double sumaTope = 0D; 
		for(PlanViajeDestinoBean planViajeDestinoB : planViajeDestinoDiasAndHorasList){
			sumaTope = sumaTope + (planViajeDestinoB.getMontoDiarioTope() * planViajeDestinoB.getDias());			
		}
		List<PlanViajeDestinoBean> planViajeDestinoDiasAndHorasListAux =  new ArrayList<PlanViajeDestinoBean>();
		PlanViajeDestinoBean planViajeDestinoAux = new PlanViajeDestinoBean(); 

		planViajeDestinoAux.setMontoDiarioTope(sumaTope);
		planViajeDestinoAux.setFechaSalida(planViajeDestinoDiasAndHorasList.get(0).getFechaSalida());
		planViajeDestinoDiasAndHorasListAux.add(planViajeDestinoAux);
		fechas.put(0, planViajeDestinoDiasAndHorasListAux.get(0));		
		fechasList.add(fechas);
	}else{
		planViajeDestinoDiasAndHorasList =  planViajeDestinoDAO.buscarPlanViajeDestinos(planViaje.getCodPlanViaje());
		if(ViaticoConstantes.TIPO_ORIGEN_REEMBOLSO.equals(documentoSustentarioDto.getPlanViajeBean().getOrigen()) && 
				ViaticoConstantes.TIPO_TRASLADO_VIATICOS.equals(planViaje.getCodigoTipoTraslado()) && 
				ViaticoConstantes.TIPO_COMISION_INTERNACIONAL.equals(planViaje.getTipoDestino())){		
			Date fechaInit = null;
			for(int i=0; i < planViajeDestinoDiasAndHorasList.size(); i++){
				PlanViajeDestinoBean planViajeDestinoDiasAux = new PlanViajeDestinoBean();
				planViajeDestinoDiasAux = planViajeDestinoDiasAndHorasList.get(i);
				if(i == ViaticoConstantes.CERO_INT){
					planViajeDestinoDiasAux.setFechaSalida(ViaticoUtil.addDiasToDate(planViajeDestinoDiasAux.getFechaSalida(), planViajeDestinoDiasAux.getDiasExtra()));
					//fechaInit = planViajeDestinoDiasAux.getFechaSalida();
				}
				else if(i >= ViaticoConstantes.CERO_INT){
					planViajeDestinoDiasAux.setFechaSalida(ViaticoUtil.addDiasToDate(fechaInit, planViajeDestinoDiasAndHorasList.get(i).getDiasExtra() + planViajeDestinoDiasAndHorasList.get(i).getDias().intValue()));
				}
				fechaInit = planViajeDestinoDiasAux.getFechaSalida();
				fechas.put(i, planViajeDestinoDiasAux);		
				fechasList.add(fechas);
			}
		}else{
			for(int i=0; i < planViajeDestinoDiasAndHorasList.size(); i++){
				fechas.put(i, planViajeDestinoDiasAndHorasList.get(i));		
				fechasList.add(fechas);
			}
		}
			
	}	

	if(CollectionUtils.isNotEmpty(planViajeDestinoDiasAndHorasList)){	
		log.debug("tamanio listaPlanViajeInforme: " + listaPlanViajeInforme.size());		
		for(int pvid=0; pvid < listaPlanViajeInforme.size(); pvid++){
			log.debug("fechaViaticos: " +listaPlanViajeInforme.get(pvid).getFecViatico());
			if(listaPlanViajeInforme.get(pvid).getFecViatico().before(fechasList.get(0).get(0).getFechaSalida()) || 
					listaPlanViajeInforme.get(pvid).getFecViatico().equals((fechasList.get(0).get(0).getFechaSalida())) ){
				log.debug("**************** paso 1 proceso ********************");
				listaPlanViajeInforme.get(pvid).setMontoDestionFecha(fechasList.get(0).get(0).getMontoDiarioTope());
			}
			for(int i = 0; i < fechasList.size()-1; i++){
				log.debug("**************** paso 2 proceso ********************");
				if(listaPlanViajeInforme.get(pvid).getFecViatico().after(fechasList.get(i).get(i).getFechaSalida()) &&					
					(listaPlanViajeInforme.get(pvid).getFecViatico().before(fechasList.get(i+1).get(i+1).getFechaSalida())||
					fechasList.get(i+1).get(i+1).getFechaSalida().equals(listaPlanViajeInforme.get(pvid).getFecViatico()))					
				){
					listaPlanViajeInforme.get(pvid).setMontoDestionFecha(fechasList.get(i+1).get(i+1).getMontoDiarioTope());				
				}
			}
			if(listaPlanViajeInforme.get(pvid).getFecViatico().after(fechasList.get(fechasList.size()-1).get(fechasList.size()-1).getFechaSalida())){
				log.debug("**************** paso 3 proceso ********************");
				listaPlanViajeInforme.get(pvid).setMontoDestionFecha(fechasList.get(fechasList.size()-1).get(fechasList.size()-1).getMontoDiarioTope());
			}			
		}
		
		List<PlanViajeInformeDistribBean> listaPlanViajeInformeSumaMontoTope = new ArrayList<PlanViajeInformeDistribBean>();	
		if (ViaticoConstantes.TIPO_COMISION_NACIONAL.equals(documentoSustentarioDto.getPlanViajeBean().getTipoDestino())) {
			listaPlanViajeInformeSumaMontoTope = planViajeInformeDistribDAO.obtenerSumaMontoRendido(planViaje.getCodPlanViaje(), ViaticoConstantes.CONCEPTO_VIATICO_CODI_CONC_PVI_FIJO_NACIONAL);
		}else{
			listaPlanViajeInformeSumaMontoTope = planViajeInformeDistribDAO.obtenerSumaMontoRendido(planViaje.getCodPlanViaje(), ViaticoConstantes.CONCEPTO_VIATICO_CODI_CONC_PVI_FIJO_INTERNACIONAL);
		}
		
		for(PlanViajeInformeDistribBean planViajeInforme : listaPlanViajeInforme){
			
			for(PlanViajeInformeDistribBean planViajeInformeDistribSumaMontoTope : listaPlanViajeInformeSumaMontoTope){
				if(planViajeInforme.getFecViatico().equals(planViajeInformeDistribSumaMontoTope.getFecViatico())){
					double sumaMonto = planViajeInforme.getMontoDestionFecha() - planViajeInformeDistribSumaMontoTope.getSumaMontoRendido();
					planViajeInforme.setMontoDestionFecha(sumaMonto);
				}
				log.debug("fecha: " +planViajeInforme.getFecViatico() + " monto: " +  planViajeInforme.getMontoDestionFecha() + " fecha:2 " +planViajeInformeDistribSumaMontoTope.getFecViatico());
			}
			
		}
			
		
		documentoSustentarioDto.setListaPlanViajeInformeDistrib(listaPlanViajeInforme);
	}
	log.debug(getClass().getName() + " Fin del metodo calculoMontoFechaDestino");
	return documentoSustentarioDto;
}

	/**
	 * Metodo que permite obtener los datos de plan de viaje para el seguimiento.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @return Plan de viaje.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	public PlanViajeBean obtenerPlanViajeToSeguimiento(String codPlanViaje) throws Exception {
		return planViajeDAO.obtenerPlanViajeToSeguimiento(codPlanViaje);
	}
	
	/**
	 * Metodo que permite obtener el listado de plan viaje rendicion que se muestran en el registro de rendicion de la solicitud y reembolso (sustento de gasto).
	 * @author Jorge Ponce.
	 * @param  planViajeId :codigo plan viaje.
	 * @return Listado de plan viaje rendicion.
	 * @see    PlanViajeRendicionBean
	 * @throws Exception
	 */
	public ArrayList<PlanViajeRendicionBean> obtenerPlanViajeRendicionToRegistroRendicion(String planViajeId, String simboloMoneda) throws Exception {
		
		ArrayList<PlanViajeRendicionBean> planViajeRendicionList = planViajeRendicionDAO.obtenerPlanViajeRendicionToRegistroRendicion(planViajeId);
		ArrayList<PlanViajeRendicionBean> planViajeRendicionAuxList = null;
		ArrayList<TipoDocumentoBean> tipoDocumentoDeclaracionList = viaticoGeneralService.obtenerTipoDocumentoDeclaracion();
		if (planViajeRendicionList != null && !planViajeRendicionList.isEmpty()) {
			planViajeRendicionAuxList = new ArrayList<PlanViajeRendicionBean>();
			BigDecimal montoDocumentoTotal = BigDecimal.ZERO;
			BigDecimal montoReconocidoTotal = BigDecimal.ZERO;
			BigDecimal montoDeclaracionTotal = BigDecimal.ZERO;
			BigDecimal montoDeclaracionViatico = BigDecimal.ZERO;
			int numeroDeclaracionViatico = 0;
			String flagDeclaracion = ViaticoConstantes.CERO;
			for (PlanViajeRendicionBean planViajeRendicionBean : planViajeRendicionList) {
				planViajeRendicionBean.setFechaDocumentoFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeRendicionBean.getFechaDocumento()));
				BigDecimal montoTotal = BigDecimal.ZERO;
				BigDecimal montoReconocido = BigDecimal.ZERO;
				String montoTotalFormateado = ViaticoConstantes.CADENA_VACIA;
				if (planViajeRendicionBean.getMontoDocumento() != null) {
					montoTotal = montoTotal.add(new BigDecimal(planViajeRendicionBean.getMontoDocumento()));
				}
				//Validar si considerar montoIgv, mtoOtrosGastos
				/*
				if (planViajeRendicionBean.getMontoIgv() != null) {
					montoTotal = montoTotal.add(new BigDecimal(planViajeRendicionBean.getMontoIgv()));
				}
				if (planViajeRendicionBean.getMtoOtrosGastos() != null) {
					montoTotal = montoTotal.add(new BigDecimal(planViajeRendicionBean.getMtoOtrosGastos()));
				}
				*/
				 if(StringUtils.isNotEmpty(planViajeRendicionBean.getRuc())){
					Map<String, Object> param = new HashMap<String, Object>();
					param.put("num_ruc", planViajeRendicionBean.getRuc());
					MaestroContratistasBean maestroContratista = registroPersonalService.recuperarContratista(param);
					planViajeRendicionBean.setNombreRazonSocial(maestroContratista.getRaz_social());
				 }
				montoTotalFormateado = NumeroUtil.formatearMonedaMontoToDecimal(null, 2, montoTotal);
				planViajeRendicionBean.setMontoTotal(new Double(montoTotalFormateado));
				planViajeRendicionBean.setMontoTotalFormateado(NumeroUtil.formatearMonto(null, montoTotal, 2));
				montoDocumentoTotal = montoDocumentoTotal.add(montoTotal);
				if (planViajeRendicionBean.getMtoReconocido() != null) {
					montoReconocido = new BigDecimal(planViajeRendicionBean.getMtoReconocido());
					planViajeRendicionBean.setMtoReconocidoFormateado(NumeroUtil.formatearMonto(null, montoReconocido, 2));
					montoReconocidoTotal = montoReconocidoTotal.add(montoReconocido);
				}
				else {
					if (planViajeRendicionBean.getMontoDocumento() != null) {
						montoReconocido = new BigDecimal(planViajeRendicionBean.getMontoDocumento());
						planViajeRendicionBean.setMtoReconocido(NumeroUtil.formatearMonedaMontoToDecimal(null, 2, montoReconocido));
						planViajeRendicionBean.setMtoReconocidoFormateado(NumeroUtil.formatearMonto(null, montoReconocido, 2));
						montoReconocidoTotal = montoReconocidoTotal.add(montoReconocido);
					}
				}
				if (tipoDocumentoDeclaracionList != null && !tipoDocumentoDeclaracionList.isEmpty()) {
					for (TipoDocumentoBean tipoDocumentoBean : tipoDocumentoDeclaracionList) {
						if (tipoDocumentoBean.getCodigoTipoDocumento().equals(planViajeRendicionBean.getTipoDocumento())) {
							flagDeclaracion = ViaticoConstantes.UNO;
							montoDeclaracionTotal = montoDeclaracionTotal.add(montoReconocido);
							if (ViaticoConstantes.TIPO_DOCUMENTO_DECLARACION_VIATICO.equals(planViajeRendicionBean.getTipoDocumento())) {
								numeroDeclaracionViatico++;
								montoDeclaracionViatico = montoDeclaracionViatico.add(montoReconocido);
							}
						}
					}
				}
				planViajeRendicionBean.setFlagRendicionTotal(ViaticoConstantes.CERO);
				planViajeRendicionAuxList.add(planViajeRendicionBean);
			}
			PlanViajeRendicionBean planViajeRendicionBean = new PlanViajeRendicionBean();
			//planViajeRendicionBean.setNombreRazonSocial(ViaticoConstantes.TOTAL);
			planViajeRendicionBean.setMontoTotal(new Double(montoDocumentoTotal.toString()));
			planViajeRendicionBean.setMontoTotalFormateado(NumeroUtil.formatearMonto(simboloMoneda, montoDocumentoTotal, 2));
			planViajeRendicionBean.setMtoReconocido(NumeroUtil.formatearMonedaMontoToDecimal(null, 2, montoReconocidoTotal));
			planViajeRendicionBean.setMtoReconocidoFormateado(NumeroUtil.formatearMonto(simboloMoneda, montoReconocidoTotal, 2));
			planViajeRendicionBean.setMontoDeclaracion(new Double(montoDeclaracionTotal.toString()));
			planViajeRendicionBean.setMontoDeclaracionFormateado(NumeroUtil.formatearMonto(simboloMoneda, montoDeclaracionTotal, 2));
			planViajeRendicionBean.setMontoDeclaracionViatico(new Double(montoDeclaracionViatico.toString()));
			planViajeRendicionBean.setMontoDeclaracionViaticoFormateado(NumeroUtil.formatearMonto(simboloMoneda, montoDeclaracionViatico, 2));
			planViajeRendicionBean.setNumeroDeclaracionViatico(numeroDeclaracionViatico);
			planViajeRendicionBean.setFlagDeclaracion(flagDeclaracion);
			planViajeRendicionBean.setFlagRendicionTotal(ViaticoConstantes.UNO);
			planViajeRendicionAuxList.add(planViajeRendicionBean);
		}
		return planViajeRendicionAuxList;
	}
	
	/**
	 * Metodo que permite obtener el listado de asignacion/gasto viatico.
	 * @author Jorge Ponce.
	 * @param  planViajeId :codigo plan viaje.
	 * @param  secuencial :secuencial del comprobante de pago.
	 * @param  simboloMoneda :simbolo de la moneda.
	 * @return Listado de asignacion de viatico.
	 * @see    PlanViajeInformeDistribBean
	 * @throws Exception
	 */
	public ArrayList<PlanViajeInformeDistribBean> obtenerAsignacionGastoViatico(String planViajeId, Integer secuencial, String simboloMoneda) throws Exception {
		ArrayList<PlanViajeInformeDistribBean> asignacionViaticoList = planViajeInformeDistribDAO.obtenerAsignacionGastoViatico(planViajeId, secuencial);
		ArrayList<PlanViajeInformeDistribBean> fechaAsignacionViaticoList = obtenerFechaGastoDetalle(asignacionViaticoList);
		ArrayList<PlanViajeInformeDistribBean> asignacionViaticoAuxList = obtenerAsignacionViatico(fechaAsignacionViaticoList, asignacionViaticoList, simboloMoneda);
		return asignacionViaticoAuxList;
	}
	
	/**
	 * Metodo que permite obtener el listado de pasaje y tasa embarque.
	 * @author Jorge Ponce.
	 * @param  planViajeId :codigo plan viaje.
	 * @param  secuencial :secuencial del comprobante de pago.
	 * @param  simboloMoneda :simbolo de la moneda.
	 * @return Listado de pasaje y tasa embarque.
	 * @see    PlanViajeInformeDistribBean
	 * @throws Exception
	 */
	public ArrayList<PlanViajeInformeDistribBean> obtenerPasajeTasaEmbarque(String planViajeId, Integer secuencial, String simboloMoneda) throws Exception {
		ArrayList<PlanViajeInformeDistribBean> pasajeTasaEmbarqueList = planViajeInformeDistribDAO.obtenerPasajeTasaEmbarque(planViajeId, secuencial);
		ArrayList<PlanViajeInformeDistribBean> fechaPasajeTasaEmbarqueList = obtenerFechaGastoDetalle(pasajeTasaEmbarqueList);
		ArrayList<PlanViajeInformeDistribBean> pasajeTasaEmbarqueAuxList = obtenerPasajeTasaEmbarque(fechaPasajeTasaEmbarqueList, pasajeTasaEmbarqueList, simboloMoneda);
		return pasajeTasaEmbarqueAuxList;
	}
	
	/**
	 * Metodo que permite obtener el listado de las diferentes fechas que existe en el gasto detalle.
	 * @author Jorge Ponce.
	 * @param  planViajeInformeDistribList :listado de plan viaje informe.
	 * @return Listado de fechas.
	 * @see    PlanViajeInformeDistribBean
	 * @throws Exception
	 */
	private ArrayList<PlanViajeInformeDistribBean> obtenerFechaGastoDetalle(ArrayList<PlanViajeInformeDistribBean> planViajeInformeDistribList) {
		
		ArrayList<PlanViajeInformeDistribBean> planViajeInformeDistribAuxList = null;
		if (planViajeInformeDistribList != null && !planViajeInformeDistribList.isEmpty()) {
			planViajeInformeDistribAuxList = new ArrayList<PlanViajeInformeDistribBean>();
			Date fecViatico = planViajeInformeDistribList.get(0).getFecViatico();
			String fecViaticoFormateada = FechaUtil.formatDateToDateDDMMYYYY(fecViatico);
			String fecha = fecViaticoFormateada;
			PlanViajeInformeDistribBean planViajeInformeDistribBeanAux = new PlanViajeInformeDistribBean();
			planViajeInformeDistribBeanAux.setFecViatico(fecViatico);
			planViajeInformeDistribBeanAux.setFecViaticoFormateada(fecViaticoFormateada);
			planViajeInformeDistribAuxList.add(planViajeInformeDistribBeanAux);
			for (PlanViajeInformeDistribBean planViajeInformeDistribBean : planViajeInformeDistribList) {
				fecViatico = planViajeInformeDistribBean.getFecViatico();
				fecViaticoFormateada = FechaUtil.formatDateToDateDDMMYYYY(fecViatico);
				if (!fecha.equals(fecViaticoFormateada)) {
					fecha = fecViaticoFormateada;
					planViajeInformeDistribBeanAux = new PlanViajeInformeDistribBean();
					planViajeInformeDistribBeanAux.setFecViatico(fecViatico);
					planViajeInformeDistribBeanAux.setFecViaticoFormateada(fecViaticoFormateada);
					planViajeInformeDistribAuxList.add(planViajeInformeDistribBeanAux);
				}
			}
		}
		return planViajeInformeDistribAuxList;
	}
	
	/**
	 * Metodo que permite obtener el listado de asignacion de viatico (formateado y ordenado).
	 * @author Jorge Ponce.
	 * @param  fechaAsignacionViaticoList :listado de las diferentes fechas que existe en asignacion de viatico.
	 * @param  asignacionViaticoList :listado de asignacion de viatico.
	 * @param  simboloMoneda :simbolo de la moneda.
	 * @return Listado de asignacion de viatico.
	 * @see    PlanViajeInformeDistribBean
	 * @throws Exception
	 */
	private ArrayList<PlanViajeInformeDistribBean> obtenerAsignacionViatico(ArrayList<PlanViajeInformeDistribBean> fechaAsignacionViaticoList, ArrayList<PlanViajeInformeDistribBean> asignacionViaticoList, String simboloMoneda) {
		
		ArrayList<PlanViajeInformeDistribBean> planViajeInformeDistribList = null;
		if (fechaAsignacionViaticoList != null && !fechaAsignacionViaticoList.isEmpty() && asignacionViaticoList != null && !asignacionViaticoList.isEmpty()) {
			planViajeInformeDistribList = new ArrayList<PlanViajeInformeDistribBean>();
			BigDecimal montoAlimentacionTotal = BigDecimal.ZERO;
			BigDecimal montoHospedajeTotal = BigDecimal.ZERO;
			BigDecimal montoMovilidadTotal = BigDecimal.ZERO;
			BigDecimal montoTrasladoTotal = BigDecimal.ZERO;
			BigDecimal montoTotalTotal = BigDecimal.ZERO;
			for (PlanViajeInformeDistribBean fechaAsignacionViaticoBean : fechaAsignacionViaticoList) {
				String fecViaticoFormateada = fechaAsignacionViaticoBean.getFecViaticoFormateada();
				BigDecimal montoAlimentacion = BigDecimal.ZERO;
				BigDecimal montoHospedaje = BigDecimal.ZERO;
				BigDecimal montoMovilidad = BigDecimal.ZERO;
				BigDecimal montoTraslado = BigDecimal.ZERO;
				BigDecimal montoTotal = BigDecimal.ZERO;
				for (PlanViajeInformeDistribBean asignacionViaticoBean : asignacionViaticoList) {
					String fecViaticoAsignacionFormateada = FechaUtil.formatDateToDateDDMMYYYY(asignacionViaticoBean.getFecViatico());
					if (fecViaticoFormateada.equals(fecViaticoAsignacionFormateada)) {
						if (ViaticoConstantes.CONCEPTO_INDICADOR_ALIMENTACION.equals(asignacionViaticoBean.getIndItinerario())) {
							if (asignacionViaticoBean.getMontoTotal() != null) {
								montoAlimentacion = montoAlimentacion.add(asignacionViaticoBean.getMontoTotal());
							}
						}
						else if (ViaticoConstantes.CONCEPTO_INDICADOR_HOSPEDAJE.equals(asignacionViaticoBean.getIndItinerario())) {
							if (asignacionViaticoBean.getMontoTotal() != null) {
								montoHospedaje = montoHospedaje.add(asignacionViaticoBean.getMontoTotal());
							}
						}
						else if (ViaticoConstantes.CONCEPTO_INDICADOR_MOVILIDAD.equals(asignacionViaticoBean.getIndItinerario())) {
							if (asignacionViaticoBean.getMontoTotal() != null) {
								montoMovilidad = montoMovilidad.add(asignacionViaticoBean.getMontoTotal());
							}
						}
						else if (ViaticoConstantes.CONCEPTO_INDICADOR_TRASLADO.equals(asignacionViaticoBean.getIndItinerario())) {
							if (asignacionViaticoBean.getMontoTotal() != null) {
								montoTraslado = montoTraslado.add(asignacionViaticoBean.getMontoTotal());
							}
						}
					}
				}
				montoTotal = montoTotal.add(montoAlimentacion).add(montoHospedaje).add(montoMovilidad).add(montoTraslado);
				montoAlimentacionTotal = montoAlimentacionTotal.add(montoAlimentacion);
				montoHospedajeTotal = montoHospedajeTotal.add(montoHospedaje);
				montoMovilidadTotal = montoMovilidadTotal.add(montoMovilidad);
				montoTrasladoTotal = montoTrasladoTotal.add(montoTraslado);
				PlanViajeInformeDistribBean planViajeInformeDistribBean = new PlanViajeInformeDistribBean();
				planViajeInformeDistribBean.setFecViaticoFormateada(fecViaticoFormateada);
				planViajeInformeDistribBean.setMontoAlimentacion(montoAlimentacion);
				planViajeInformeDistribBean.setMontoAlimentacionFormateado(NumeroUtil.formatearMonto(null, montoAlimentacion, 2));
				planViajeInformeDistribBean.setMontoHospedaje(montoHospedaje);
				planViajeInformeDistribBean.setMontoHospedajeFormateado(NumeroUtil.formatearMonto(null, montoHospedaje, 2));
				planViajeInformeDistribBean.setMontoMovilidad(montoMovilidad);
				planViajeInformeDistribBean.setMontoMovilidadFormateado(NumeroUtil.formatearMonto(null, montoMovilidad, 2));
				planViajeInformeDistribBean.setMontoTraslado(montoTraslado);
				planViajeInformeDistribBean.setMontoTrasladoFormateado(NumeroUtil.formatearMonto(null, montoTraslado, 2));
				planViajeInformeDistribBean.setMontoTotal(montoTotal);
				planViajeInformeDistribBean.setMontoTotalFormateado(NumeroUtil.formatearMonto(null, montoTotal, 2));
				planViajeInformeDistribBean.setFlagPlanViajeInformeDistribTotal(ViaticoConstantes.CERO);
				planViajeInformeDistribList.add(planViajeInformeDistribBean);
			}
			montoTotalTotal = montoTotalTotal.add(montoAlimentacionTotal).add(montoHospedajeTotal).add(montoMovilidadTotal).add(montoTrasladoTotal);
			PlanViajeInformeDistribBean planViajeInformeDistribTotalBean = new PlanViajeInformeDistribBean();
			planViajeInformeDistribTotalBean.setFecViaticoFormateada(ViaticoConstantes.TOTAL + ViaticoConstantes.ESPACIO + simboloMoneda);
			planViajeInformeDistribTotalBean.setMontoAlimentacion(montoAlimentacionTotal);
			planViajeInformeDistribTotalBean.setMontoAlimentacionFormateado(NumeroUtil.formatearMonto(null, montoAlimentacionTotal, 2));
			planViajeInformeDistribTotalBean.setMontoHospedaje(montoHospedajeTotal);
			planViajeInformeDistribTotalBean.setMontoHospedajeFormateado(NumeroUtil.formatearMonto(null, montoHospedajeTotal, 2));
			planViajeInformeDistribTotalBean.setMontoMovilidad(montoMovilidadTotal);
			planViajeInformeDistribTotalBean.setMontoMovilidadFormateado(NumeroUtil.formatearMonto(null, montoMovilidadTotal, 2));
			planViajeInformeDistribTotalBean.setMontoTraslado(montoTrasladoTotal);
			planViajeInformeDistribTotalBean.setMontoTrasladoFormateado(NumeroUtil.formatearMonto(null, montoTrasladoTotal, 2));
			planViajeInformeDistribTotalBean.setMontoTotal(montoTotalTotal);
			planViajeInformeDistribTotalBean.setMontoTotalFormateado(NumeroUtil.formatearMonto(null, montoTotalTotal, 2));
			planViajeInformeDistribTotalBean.setFlagPlanViajeInformeDistribTotal(ViaticoConstantes.UNO);
			planViajeInformeDistribList.add(planViajeInformeDistribTotalBean);
		}
		return planViajeInformeDistribList;
	}
	
	/**
	 * Metodo que permite obtener el listado de pasaje y tasa embarque (formateado y ordenado).
	 * @author Jorge Ponce.
	 * @param  fechaPasajeTasaEmbarqueList :listado de las diferentes fechas que existe en pasaje y tasa embarque.
	 * @param  pasajeTasaEmbarqueList :listado de pasaje y tasa embarque.
	 * @param  simboloMoneda :simbolo de la moneda.
	 * @return Listado de pasaje y tasa embarque.
	 * @see    PlanViajeInformeDistribBean
	 * @throws Exception
	 */
	private ArrayList<PlanViajeInformeDistribBean> obtenerPasajeTasaEmbarque(ArrayList<PlanViajeInformeDistribBean> fechaPasajeTasaEmbarqueList, ArrayList<PlanViajeInformeDistribBean> pasajeTasaEmbarqueList, String simboloMoneda) {
		
		ArrayList<PlanViajeInformeDistribBean> planViajeInformeDistribList = null;
		if (fechaPasajeTasaEmbarqueList != null && !fechaPasajeTasaEmbarqueList.isEmpty() && pasajeTasaEmbarqueList != null && !pasajeTasaEmbarqueList.isEmpty()) {
			planViajeInformeDistribList = new ArrayList<PlanViajeInformeDistribBean>();
			BigDecimal montoPasajeTotal = BigDecimal.ZERO;
			BigDecimal montoTUUATotal = BigDecimal.ZERO;
			BigDecimal montoTotalTotal = BigDecimal.ZERO;
			for (PlanViajeInformeDistribBean fechaPasajeTasaEmbarqueBean : fechaPasajeTasaEmbarqueList) {
				String fecViaticoFormateada = fechaPasajeTasaEmbarqueBean.getFecViaticoFormateada();
				BigDecimal montoPasaje = BigDecimal.ZERO;
				BigDecimal montoTUUA = BigDecimal.ZERO;
				BigDecimal montoTotal = BigDecimal.ZERO;
				for (PlanViajeInformeDistribBean pasajeTasaEmbarqueBean : pasajeTasaEmbarqueList) {
					String fecViaticoAsignacionFormateada = FechaUtil.formatDateToDateDDMMYYYY(pasajeTasaEmbarqueBean.getFecViatico());
					if (fecViaticoFormateada.equals(fecViaticoAsignacionFormateada)) {
						if (ViaticoConstantes.CONCEPTO_INDICADOR_PASAJE.equals(pasajeTasaEmbarqueBean.getIndTipo())) {
							if (pasajeTasaEmbarqueBean.getMontoTotal() != null) {
								montoPasaje = montoPasaje.add(pasajeTasaEmbarqueBean.getMontoTotal());
							}
						}
						else if (ViaticoConstantes.CONCEPTO_INDICADOR_TUUA.equals(pasajeTasaEmbarqueBean.getIndTipo())) {
							if (pasajeTasaEmbarqueBean.getMontoTotal() != null) {
								montoTUUA = montoTUUA.add(pasajeTasaEmbarqueBean.getMontoTotal());
							}
						}
					}
				}
				montoTotal = montoTotal.add(montoPasaje).add(montoTUUA);
				montoPasajeTotal = montoPasajeTotal.add(montoPasaje);
				montoTUUATotal = montoTUUATotal.add(montoTUUA);
				PlanViajeInformeDistribBean planViajeInformeDistribBean = new PlanViajeInformeDistribBean();
				planViajeInformeDistribBean.setFecViaticoFormateada(fecViaticoFormateada);
				planViajeInformeDistribBean.setMontoPasaje(montoPasaje);
				planViajeInformeDistribBean.setMontoPasajeFormateado(NumeroUtil.formatearMonto(null, montoPasaje, 2));
				planViajeInformeDistribBean.setMontoTUUA(montoTUUA);
				planViajeInformeDistribBean.setMontoTUUAFormateado(NumeroUtil.formatearMonto(null, montoTUUA, 2));
				planViajeInformeDistribBean.setMontoTotal(montoTotal);
				planViajeInformeDistribBean.setMontoTotalFormateado(NumeroUtil.formatearMonto(null, montoTotal, 2));
				planViajeInformeDistribBean.setFlagPlanViajeInformeDistribTotal(ViaticoConstantes.CERO);
				planViajeInformeDistribList.add(planViajeInformeDistribBean);
			}
			montoTotalTotal = montoTotalTotal.add(montoPasajeTotal).add(montoTUUATotal);
			PlanViajeInformeDistribBean planViajeInformeDistribTotalBean = new PlanViajeInformeDistribBean();
			planViajeInformeDistribTotalBean.setFecViaticoFormateada(ViaticoConstantes.TOTAL + ViaticoConstantes.ESPACIO + simboloMoneda);
			planViajeInformeDistribTotalBean.setMontoPasaje(montoPasajeTotal);
			planViajeInformeDistribTotalBean.setMontoPasajeFormateado(NumeroUtil.formatearMonto(null, montoPasajeTotal, 2));
			planViajeInformeDistribTotalBean.setMontoTUUA(montoTUUATotal);
			planViajeInformeDistribTotalBean.setMontoTUUAFormateado(NumeroUtil.formatearMonto(null, montoTUUATotal, 2));
			planViajeInformeDistribTotalBean.setMontoTotal(montoTotalTotal);
			planViajeInformeDistribTotalBean.setMontoTotalFormateado(NumeroUtil.formatearMonto(null, montoTotalTotal, 2));
			planViajeInformeDistribTotalBean.setFlagPlanViajeInformeDistribTotal(ViaticoConstantes.UNO);
			planViajeInformeDistribList.add(planViajeInformeDistribTotalBean);
		}
		return planViajeInformeDistribList;
	}
	
	/**
	 * Metodo que permite validar el monto rendido diario.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @param  tipoDestino :tipo destino.
	 * @param  flagMenorIgual4Horas :flag menor igual 4 horas.
	 * @param  simboloMoneda :simbolo de la moneda.
	 * @return Viatico validate.
	 * @see    ViaticoValidate
	 * @throws Exception
	 */
	public ViaticoValidate validarMontoRendidoDiario(String codPlanViaje, String tipoDestino, String flagMenorIgual4Horas, String simboloMoneda) throws Exception {
		
		ViaticoValidate viaticoValidate = new ViaticoValidate();
		boolean flagRendicionCorrecta = true;
		String errorMessage = ViaticoConstantes.CADENA_VACIA;
		BigDecimal montoTopeDiario = BigDecimal.ZERO;
		ArrayList<PlanViajeInformeDistribBean> planViajeInformeDistribList = planViajeInformeDistribDAO.obtenerMontoRendidoDiario(codPlanViaje);
		if (planViajeInformeDistribList != null && !planViajeInformeDistribList.isEmpty()) {
			ArrayList<PlanViajeDestinoBean> planViajeDestinoList = obtenerFechaMontoTopeDiario(codPlanViaje, tipoDestino, flagMenorIgual4Horas);
			if (planViajeDestinoList != null && !planViajeDestinoList.isEmpty()) {
				int sizePlanViajeDestinoList = planViajeDestinoList.size();
				montoTopeDiario = new BigDecimal(planViajeDestinoList.get(0).getMontoDiarioTope());
				
				loopPrincipal:
				for (PlanViajeInformeDistribBean planViajeInformeDistribBean : planViajeInformeDistribList) {
					
					BigDecimal montoRendidoDiario = planViajeInformeDistribBean.getMontoTotal();
					String fecha = FechaUtil.formatDateToDateDDMMYYYY(planViajeInformeDistribBean.getFecViatico());
					if (sizePlanViajeDestinoList == 1) {
						int resultado = montoRendidoDiario.compareTo(montoTopeDiario);
						if (resultado == 1) {
							flagRendicionCorrecta = false;
							String montoTopeDiarioFormateado =  NumeroUtil.formatearMonedaMontoToDecimal(simboloMoneda, 2, montoTopeDiario);
							errorMessage = ResourceBundleUtil.getMessageRendicion(RendicionConstantes.MENSAJE_MONTO_DIARIO_MAYOR_TOPE_DIARIO, fecha, montoTopeDiarioFormateado);
							break;
						}
					}
					else {
						for (int i = 0; i < sizePlanViajeDestinoList; i++) {
							montoTopeDiario = new BigDecimal(planViajeDestinoList.get(i).getMontoDiarioTope());
							String fechaInicioDestino = planViajeDestinoList.get(i).getFechaInicioFormateada();
							String fechaFinDestino = planViajeDestinoList.get(i).getFechaSalidaFormateada();
							boolean flagValidarMontos = false;
							if (i == 0) {
								if (FechaUtil.esFechaMenorIgual(fecha, fechaFinDestino)) {
									flagValidarMontos = true;
								}
							}
							else if (i == (sizePlanViajeDestinoList - 1)) {
								if (FechaUtil.esFechaMayorIgual(fecha, fechaInicioDestino)) {
									flagValidarMontos = true;
								}
							}
							else {
								if (FechaUtil.esFechaMayorIgual(fecha, fechaInicioDestino) && FechaUtil.esFechaMenorIgual(fecha, fechaFinDestino)) {
									flagValidarMontos = true;
								}
							}
							
							if (flagValidarMontos) {
								int resultado = montoRendidoDiario.compareTo(montoTopeDiario);
								if (resultado == 1) {
									flagRendicionCorrecta = false;
									String montoTopeDiarioFormateado =  NumeroUtil.formatearMonedaMontoToDecimal(simboloMoneda, 2, montoTopeDiario);
									errorMessage = ResourceBundleUtil.getMessageRendicion(RendicionConstantes.MENSAJE_MONTO_DIARIO_MAYOR_TOPE_DIARIO, fecha, montoTopeDiarioFormateado);
									break loopPrincipal;
								}
							}
						}
					}
				}
				
				int i = 0;
				for (PlanViajeDestinoBean planViajeDestinoBean : planViajeDestinoList) {
					i++;
					log.debug("registrarRendicion.montoTopeDiario." + i + ": " + planViajeDestinoBean.getFechaInicioFormateada() + " - " + planViajeDestinoBean.getFechaSalidaFormateada() + " - " +  planViajeDestinoBean.getMontoDiarioTope().toString());
				}
			}
		}
		viaticoValidate.setFlagValidacion(flagRendicionCorrecta);
		viaticoValidate.setErrorMessage(errorMessage);
		return viaticoValidate;
	}
	
	/**
	 * Metodo que permite obtener el listado de monto tope diario en las diferentes fechas.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @param  tipoDestino :tipo destino.
	 * @param  flagMenorIgual4Horas :flag menor igual 4 horas.
	 * @return Listado de monto tope diario en la diferentes fechas.
	 * @see    PlanViajeDestinoBean
	 * @throws Exception
	 */
	private ArrayList<PlanViajeDestinoBean> obtenerFechaMontoTopeDiario(String codPlanViaje, String tipoDestino, String flagMenorIgual4Horas) {
		
		ArrayList<PlanViajeDestinoBean> planViajeDestinoList = planViajeDestinoDAO.obtenerMontoTopeDia(codPlanViaje);
		ArrayList<PlanViajeDestinoBean> planViajeDestinoAuxList = null;
		if (planViajeDestinoList != null && !planViajeDestinoList.isEmpty()) {
			planViajeDestinoAuxList = new ArrayList<PlanViajeDestinoBean>();
			int size = planViajeDestinoList.size();
			if (size == 1) {
				PlanViajeDestinoBean planViajeDestinoBean = new PlanViajeDestinoBean();
				if (RendicionConstantes.TIPO_DESTINO_NACIONAL.equals(tipoDestino) && RendicionConstantes.UNO.equals(flagMenorIgual4Horas)) {
					BigDecimal montoTopeDiario = BigDecimal.ZERO;
					BigDecimal montoDiarioTope = BigDecimal.ZERO;
					BigDecimal numeroHoras = BigDecimal.ZERO;
					BigDecimal numeroHorasDia = new BigDecimal(1);
					if (planViajeDestinoList.get(0).getMontoDiarioTope() != null && planViajeDestinoList.get(0).getDias() != null) {
						montoDiarioTope = new BigDecimal(planViajeDestinoList.get(0).getMontoDiarioTope());
						numeroHoras = new BigDecimal(planViajeDestinoList.get(0).getDias());
						montoTopeDiario = montoTopeDiario.add(montoDiarioTope.multiply(numeroHoras).divide(numeroHorasDia, 2, RoundingMode.HALF_UP));
					}
					planViajeDestinoBean.setMontoDiarioTope(new Double(NumeroUtil.formatearMonedaMontoToDecimal(null, 2, montoTopeDiario)));
				}
				else {
					planViajeDestinoBean.setMontoDiarioTope(planViajeDestinoList.get(0).getMontoDiarioTope());
				}
				planViajeDestinoBean.setFechaInicioFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeDestinoList.get(0).getFechaSalida()));
				planViajeDestinoBean.setFechaSalidaFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeDestinoList.get(0).getFechaSalida()));
				planViajeDestinoAuxList.add(planViajeDestinoBean);
			}
			else {
				if (RendicionConstantes.TIPO_DESTINO_NACIONAL.equals(tipoDestino) && RendicionConstantes.UNO.equals(flagMenorIgual4Horas)) {
					PlanViajeDestinoBean planViajeDestinoBean = new PlanViajeDestinoBean();
					BigDecimal montoTopeDiario = BigDecimal.ZERO;
					planViajeDestinoBean.setFechaInicioFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeDestinoList.get(0).getFechaSalida()));
					planViajeDestinoBean.setFechaSalidaFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeDestinoList.get(0).getFechaSalida()));
					for (PlanViajeDestinoBean planViajeDestinoBeanAux : planViajeDestinoList) {
						BigDecimal montoDiarioTope = BigDecimal.ZERO;
						BigDecimal numeroHoras = BigDecimal.ZERO;
						BigDecimal numeroHorasDia = new BigDecimal(1);
						if (planViajeDestinoBeanAux.getMontoDiarioTope() != null && planViajeDestinoBeanAux.getDias() != null) {
							montoDiarioTope = new BigDecimal(planViajeDestinoBeanAux.getMontoDiarioTope());
							numeroHoras = new BigDecimal(planViajeDestinoBeanAux.getDias());
							montoTopeDiario = montoTopeDiario.add(montoDiarioTope.multiply(numeroHoras).divide(numeroHorasDia, 2, RoundingMode.HALF_UP));
						}
					}
					planViajeDestinoBean.setMontoDiarioTope(new Double(NumeroUtil.formatearMonedaMontoToDecimal(null, 2, montoTopeDiario)));
					planViajeDestinoAuxList.add(planViajeDestinoBean);
				}
				else {
					for (PlanViajeDestinoBean planViajeDestinoBean : planViajeDestinoList) {
						planViajeDestinoBean.setFechaInicioFormateada(FechaUtil.formatDateToDateDDMMYYYY(FechaUtil.sumarRestarDiasFecha(planViajeDestinoBean.getFechaSalida(), 1 - planViajeDestinoBean.getDias().intValue())));
						planViajeDestinoBean.setFechaSalidaFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeDestinoBean.getFechaSalida()));
						planViajeDestinoAuxList.add(planViajeDestinoBean);
					}
				}
			}
		}
		return planViajeDestinoAuxList;
	}
	
	/**
	 * Metodo que permite obtener el el flag para verificar que una rendicion/sustento es menor o igual a 4 horas.
	 * @author Jorge Ponce.
	 * @param  indicadorHoras :indicador de horas.
	 * @param  numeroHoras :numero de horas.
	 * @return Flag MenorIgual4Horas.
	 * @see    String
	 */
	public String obtenerFlagMenorIgual4Horas(String indicadorHoras, Double numeroHoras) {
		
		String flagMenorIgual4Horas = RendicionConstantes.CERO;
		if (RendicionConstantes.INDICADOR_HORAS.equals(indicadorHoras)) {
			if (numeroHoras != null) {
				BigDecimal cuatroHoras = new BigDecimal(4);
				BigDecimal numeroHorasAux = new BigDecimal(numeroHoras);
				int resultado = numeroHorasAux.compareTo(cuatroHoras);
				if (resultado == -1 || resultado == 0) {
					flagMenorIgual4Horas = RendicionConstantes.UNO;
				}
			}
		}
		return flagMenorIgual4Horas;
	}

	@Override
	public ArrayList<PlanViajeRendicionBean> obtenerListadoDocumentosPlanViaje(
			String planViajeId) {
		return planViajeRendicionDAO.obtenerPlanViajeRendicionToRegistroRendicion(planViajeId);
	}
	
	

	/*if(StringUtils.isNotEmpty(codPlanViajeInicio) && StringUtils.isNotEmpty(codPlanViajeFin)){
		
		 for(int i = 0; i < listaPlanViaje.size() ; i++){
			 SolicitudDTO solicitudDTO = new SolicitudDTO();
			 	if(codPlanViajeInicio.equals(listaPlanViaje.get(i).getCodPlanViaje())){
			 		listaPlanViajeF.add(listaPlanViaje.get(i));
					
					if(StringUtils.isNotEmpty(listaPlanViaje.get(i).getCodTrabajador())){
						MaestroPersonalBean colaborador = registroPersonalService.obtenerPersonaxCodigo(listaPlanViaje.get(i).getCodTrabajador());
						solicitudDTO.setColaborador(MaestroPersonalUtil.parseViatico(colaborador));
					}
					
					if(StringUtils.isNotEmpty(listaPlanViaje.get(i).getCodigoRegistrador())){
						MaestroPersonalBean registrador = registroPersonalService.obtenerPersonaxCodigo(listaPlanViaje.get(i).getCodigoRegistrador());
						solicitudDTO.setRegistrador(MaestroPersonalUtil.parseViatico(registrador));
					}
					
					if(StringUtils.isNotEmpty(listaPlanViaje.get(i).getPersonaAutorizacionVigente())){
						MaestroPersonalBean autorizador = registroPersonalService.obtenerPersonaxCodigo(listaPlanViaje.get(i).getPersonaAutorizacionVigente());
						solicitudDTO.setAutorizador(MaestroPersonalUtil.parseViatico(autorizador));}
					
					solicitudDTO.setPlanViajeList(listaPlanViajeF);
					solicitudDTOList.add(solicitudDTO);
			 	}
			 
			 
			 	if(codPlanViajeInicio.equals(listaPlanViaje.get(i).getCodPlanViaje())){
					listaPlanViajeF.add(listaPlanViaje.get(i));
										
					if(StringUtils.isNotEmpty(listaPlanViaje.get(i).getCodTrabajador())){
						MaestroPersonalBean colaborador = registroPersonalService.obtenerPersonaxCodigo(listaPlanViaje.get(i).getCodTrabajador());
						solicitudDTO.setColaborador(MaestroPersonalUtil.parseViatico(colaborador));
					}
					
					if(StringUtils.isNotEmpty(listaPlanViaje.get(i).getCodigoRegistrador())){
						MaestroPersonalBean registrador = registroPersonalService.obtenerPersonaxCodigo(listaPlanViaje.get(i).getCodigoRegistrador());
						solicitudDTO.setRegistrador(MaestroPersonalUtil.parseViatico(registrador));
					}
					
					if(StringUtils.isNotEmpty(listaPlanViaje.get(i).getPersonaAutorizacionVigente())){
						MaestroPersonalBean autorizador = registroPersonalService.obtenerPersonaxCodigo(listaPlanViaje.get(i).getPersonaAutorizacionVigente());
						solicitudDTO.setAutorizador(MaestroPersonalUtil.parseViatico(autorizador));}
					
					solicitudDTO.setPlanViajeList(listaPlanViajeF);
					solicitudDTOList.add(solicitudDTO);
				}
				
				if(!codPlanViajeInicio.equals(listaPlanViaje.get(i).getCodPlanViaje()) && !codPlanViajeFin.equals(listaPlanViaje.get(i).getCodPlanViaje())){
					if(StringUtils.isNotEmpty(listaPlanViaje.get(i).getCodTrabajador())){
						MaestroPersonalBean colaborador = registroPersonalService.obtenerPersonaxCodigo(listaPlanViaje.get(i).getCodTrabajador());
						solicitudDTO.setColaborador(MaestroPersonalUtil.parseViatico(colaborador));
					}
					
					if(StringUtils.isNotEmpty(listaPlanViaje.get(i).getCodigoRegistrador())){
						MaestroPersonalBean registrador = registroPersonalService.obtenerPersonaxCodigo(listaPlanViaje.get(i).getCodigoRegistrador());
						solicitudDTO.setRegistrador(MaestroPersonalUtil.parseViatico(registrador));
					}
					
					if(StringUtils.isNotEmpty(listaPlanViaje.get(i).getPersonaAutorizacionVigente())){
						MaestroPersonalBean autorizador = registroPersonalService.obtenerPersonaxCodigo(listaPlanViaje.get(i).getPersonaAutorizacionVigente());
						solicitudDTO.setAutorizador(MaestroPersonalUtil.parseViatico(autorizador));}
					solicitudDTO.setPlanViajeList(listaPlanViajeF);
					solicitudDTOList.add(solicitudDTO);
				}					
				
				if(StringUtils.isNotEmpty(codPlanViajeFin)){					
					if(codPlanViajeFin.equals(listaPlanViaje.get(i).getCodPlanViaje())){
						listaPlanViajeF.add(listaPlanViaje.get(i));
						
						if(StringUtils.isNotEmpty(listaPlanViaje.get(i).getCodTrabajador())){
							MaestroPersonalBean colaborador = registroPersonalService.obtenerPersonaxCodigo(listaPlanViaje.get(i).getCodTrabajador());
							solicitudDTO.setColaborador(MaestroPersonalUtil.parseViatico(colaborador));
						}	
						
						if(StringUtils.isNotEmpty(listaPlanViaje.get(i).getCodigoRegistrador())){
							MaestroPersonalBean registrador = registroPersonalService.obtenerPersonaxCodigo(listaPlanViaje.get(i).getCodigoRegistrador());
							solicitudDTO.setRegistrador(MaestroPersonalUtil.parseViatico(registrador));
						}
						
						if(StringUtils.isNotEmpty(listaPlanViaje.get(i).getPersonaAutorizacionVigente())){
							MaestroPersonalBean autorizador = registroPersonalService.obtenerPersonaxCodigo(listaPlanViaje.get(i).getPersonaAutorizacionVigente());
							solicitudDTO.setAutorizador(MaestroPersonalUtil.parseViatico(autorizador));}
						
						solicitudDTO.setPlanViajeList(listaPlanViajeF);
						solicitudDTOList.add(solicitudDTO);
					}
				}
			}
		
	 }*/
	
}
