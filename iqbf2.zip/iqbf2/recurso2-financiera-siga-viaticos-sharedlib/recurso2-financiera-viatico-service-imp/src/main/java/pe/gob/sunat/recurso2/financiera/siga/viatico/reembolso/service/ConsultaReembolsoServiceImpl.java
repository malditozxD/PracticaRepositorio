package pe.gob.sunat.recurso2.financiera.siga.viatico.reembolso.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.SysEstadosBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroGeneralService;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.administracion.siga.util.FechaUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.FormatoUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.NumeroUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ClaveValorBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.NivelBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeConceptoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeInformeDistribBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeRendicionBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ReembolsoDTO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.CuentaCorrienteDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.NivelDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeConceptoDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeDestinoDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeRendicionDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoConsultaService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.MaestroPersonalUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ReembolsoConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.RendicionConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoUtil;

/**
 * La clase ConsultaReembolsoServiceImpl realiza consultas de solicitudes de viatico por reembolso
 * 
 * @author Juan Farro
 */
public class ConsultaReembolsoServiceImpl implements ConsultaReembolsoService {

	/** Declaracion del log para realizar los debug, info, error, etc. */
	protected final Log log = LogFactory.getLog(getClass());
	
	/** Declaracion del servicio registroPersonalService. */
	private RegistroPersonalService registroPersonalService;
	
	/** Declaracion del servicio registroGeneralService. */
	private RegistroGeneralService registroGeneralService;

	/** Declaracion del servicio viaticoService. */
	private ViaticoService viaticoService;
	
	private ViaticoConsultaService viaticoConsultaService;
	
	private ConsultaReembolsoService consultaReembolsoService;
	
	/** Declaracion del DAO planViajeDAO. */
	private PlanViajeDAO planViajeDAO;
	
	/** Declaracion del DAO planViajeRendicionDAO. */
	private PlanViajeRendicionDAO planViajeRendicionDAO;
	
	/** Declaracion del DAO planViajeDestinoDAO. */
	private PlanViajeDestinoDAO planViajeDestinoDAO;

	/** Declaracion del DAO planViajeConceptoDAO. */
	private PlanViajeConceptoDAO planViajeConceptoDAO;

	/** Declaracion del DAO nivelDAO. */
	private NivelDAO nivelDAO;

	/** Declaracion del DAO cuentaCorrienteDAO. */
	private CuentaCorrienteDAO cuentaCorrienteDAO;
	
	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}

	public ViaticoService getViaticoService() {
		return viaticoService;
	}

	public void setViaticoService(ViaticoService viaticoService) {
		this.viaticoService = viaticoService;
	}

	public PlanViajeDAO getPlanViajeDAO() {
		return planViajeDAO;
	}

	public void setPlanViajeDAO(PlanViajeDAO planViajeDAO) {
		this.planViajeDAO = planViajeDAO;
	}

	public PlanViajeRendicionDAO getPlanViajeRendicionDAO() {
		return planViajeRendicionDAO;
	}

	public void setPlanViajeRendicionDAO(PlanViajeRendicionDAO planViajeRendicionDAO) {
		this.planViajeRendicionDAO = planViajeRendicionDAO;
	}

	public PlanViajeDestinoDAO getPlanViajeDestinoDAO() {
		return planViajeDestinoDAO;
	}

	public void setPlanViajeDestinoDAO(PlanViajeDestinoDAO planViajeDestinoDAO) {
		this.planViajeDestinoDAO = planViajeDestinoDAO;
	}

	public PlanViajeConceptoDAO getPlanViajeConceptoDAO() {
		return planViajeConceptoDAO;
	}

	public void setPlanViajeConceptoDAO(PlanViajeConceptoDAO planViajeConceptoDAO) {
		this.planViajeConceptoDAO = planViajeConceptoDAO;
	}

	public NivelDAO getNivelDAO() {
		return nivelDAO;
	}

	public void setNivelDAO(NivelDAO nivelDAO) {
		this.nivelDAO = nivelDAO;
	}

	public CuentaCorrienteDAO getCuentaCorrienteDAO() {
		return cuentaCorrienteDAO;
	}

	public void setCuentaCorrienteDAO(CuentaCorrienteDAO cuentaCorrienteDAO) {
		this.cuentaCorrienteDAO = cuentaCorrienteDAO;
	}
	
	public RegistroGeneralService getRegistroGeneralService() {
		return registroGeneralService;
	}

	public void setRegistroGeneralService(
			RegistroGeneralService registroGeneralService) {
		this.registroGeneralService = registroGeneralService;
	}
	
	public ViaticoConsultaService getViaticoConsultaService() {
		return viaticoConsultaService;
	}

	public void setViaticoConsultaService(
			ViaticoConsultaService viaticoConsultaService) {
		this.viaticoConsultaService = viaticoConsultaService;
	}

	public ConsultaReembolsoService getConsultaReembolsoService() {
		return consultaReembolsoService;
	}

	public void setConsultaReembolsoService(
			ConsultaReembolsoService consultaReembolsoService) {
		this.consultaReembolsoService = consultaReembolsoService;
	}

	/**
	 * Metodo que permite obtener las planillas de viatico asociadas a un colaborador.
	 * 
	 * @author Juan Farro
	 * @param colaborador codigo de colaborador
	 * @param tipoDestino tipo destino (nacional, internacional)
	 * @param indicadorHoras indicador de horas (mayor a 4 horas, menor o igual a 4 horas)
	 * @return lista de planillas asociadas en formato clave-valor-JSON
	 * @throws Exception
	 * @see ClaveValorBean
	 */
	@Override
	public List<ClaveValorBean> obtenerPlanillasAsociadas(String colaborador, String tipoDestino, String indicadorHoras) throws Exception {

		// lista resultado
		List<ClaveValorBean> planillasJSON = new ArrayList<ClaveValorBean>();

		// trae las planillas asociadas
		List<PlanViajeBean> planillas = planViajeDAO.obtenerPlanillasAsociadasParaReembolso(colaborador, tipoDestino, indicadorHoras);

		if (CollectionUtils.isNotEmpty(planillas)) {

			for (PlanViajeBean planViaje : planillas) {

				if (planViaje == null) continue;

				// seteamos la data adicional JSON (planilla, asociada, importe y fechas)
				Map<String, String> dataJSON = obtenerDatosPlanillaAsociada(planViaje);

				// seteamos clave/valor del combo, mas la data adicional en JSON
				ClaveValorBean itemJSON = new ClaveValorBean();

				itemJSON.setCodigo(planViaje.getCodPlanViaje());
				itemJSON.setDescripcion(planViaje.getCodPlanilla());
				itemJSON.setDataJSON(SojoUtil.toJson(dataJSON));

				planillasJSON.add(itemJSON);
			}

		}

		return planillasJSON;
	}

	/**
	 * Metodo que permite obtener una solicitud de viatico.
	 * 
	 * @author Juan Farro
	 * @param planViaje plan viaje
	 * @return mapa con los datos principales de la planilla asociada
	 * @throws Exception
	 */
	@Override
	public Map<String, String> obtenerDatosPlanillaAsociada(PlanViajeBean planViaje) throws Exception {

		// seteamos la data adicional (planilla, asociada, importe y fechas)
		Map<String, String> result = new HashMap<String, String>();

		if (planViaje == null) return result;

		boolean esNacional = StringUtils.equals(planViaje.getTipoDestino(), ViaticoConstantes.TIPO_COMISION_NACIONAL);
		boolean esInternacional = StringUtils.equals(planViaje.getTipoDestino(), ViaticoConstantes.TIPO_COMISION_INTERNACIONAL);
		boolean esMenorIgual4h = StringUtils.equals(planViaje.getIndicadorHoras(), ViaticoConstantes.INDICADOR_HORAS_HORAS); // INDICADOR_HORAS_HORAS 1:horas, 0:dias
		boolean esMayor4h = !StringUtils.equals(planViaje.getIndicadorHoras(), ViaticoConstantes.INDICADOR_HORAS_HORAS); // INDICADOR_HORAS_HORAS 1:horas, 0:dias

		result.put("codPlanViaje", planViaje.getCodPlanViaje());
		result.put("codPlanilla", planViaje.getCodPlanilla());

		result.put("importe", StringUtils.EMPTY);
		if (planViaje.getMontoTotal() != null) {
			result.put("importe", ViaticoUtil.formatearNumeros(ViaticoConstantes.NRO_DECIMALES_ROUND, planViaje.getMontoTotal()));
		}

		// indicadores tipo de viatico
		result.put("esNacional", esNacional ? ViaticoConstantes.SI : ViaticoConstantes.NO);
		result.put("esInternacional", esInternacional ? ViaticoConstantes.SI : ViaticoConstantes.NO);
		result.put("esMenorIgual4h", esMenorIgual4h ? ViaticoConstantes.SI : ViaticoConstantes.NO);
		result.put("esMayor4h", esMayor4h ? ViaticoConstantes.SI : ViaticoConstantes.NO);

		// seteando los campos fecha y hora (y todo lo que se necesite) segun tipo de viatico y duracion de comision
		if (esNacional) {

			if (esMayor4h) {

				Date fechaSalida = planViaje.getFechaHoraProgSalida();
				Date fechaRetorno = planViaje.getFechaHoraProgRetorno(); // este puede ser null

				result.put("fechaSalida", FechaUtil.formatDateToDateDDMMYYYY(fechaSalida));
				result.put("fechaRetorno", FechaUtil.formatDateToDateDDMMYYYY(fechaRetorno));
				
				// fecha para sugerir la fecha de salida de la siguiente comision
				Date fechaRetornoMas1 = fechaRetorno == null? null : ViaticoUtil.addDiasToDate(fechaRetorno, 1);
				result.put("fechaRetornoMas1", FechaUtil.formatDateToDateDDMMYYYY(fechaRetornoMas1));

				result.put("numeroDias", StringUtils.EMPTY);
				result.put("numeroDiasHabiles", StringUtils.EMPTY);

				if (fechaSalida != null && fechaRetorno != null) {

					if (planViaje.getNumeroDias() != null) {
						result.put("numeroDias", String.valueOf(planViaje.getNumeroDias().intValue()));
					}

					result.put("numeroDiasHabiles", String.valueOf(String.valueOf(viaticoService.calcularDiasHabiles(fechaSalida, fechaRetorno))));
				}

			} else if (esMenorIgual4h) {
				
				Date fecha = planViaje.getFechaHoraProgSalida();

				result.put("fecha", FechaUtil.formatDateToDateDDMMYYYY(fecha));

				// fecha para sugerir la fecha de salida de la siguiente comision
				Date fechaMas1 =  fecha == null? null : ViaticoUtil.addDiasToDate(fecha, 1);
				result.put("fechaMas1", FechaUtil.formatDateToDateDDMMYYYY(fechaMas1));				
				
				// horas y minutos de salida
				result.put("horaSalida", StringUtils.EMPTY);

				if (planViaje.getFechaHoraProgSalida() != null) {

					int horasSalida = ViaticoUtil.extraerHoras24H(planViaje.getFechaHoraProgSalida());
					int minutosSalida = ViaticoUtil.extraerMinutos(planViaje.getFechaHoraProgSalida());

					result.put("horaSalida", ViaticoUtil.formatearHorasMinutos(horasSalida, minutosSalida));
				}

				// horas y minutos de retorno
				result.put("horaRetorno", StringUtils.EMPTY);

				if (planViaje.getFechaHoraProgRetorno() != null) {

					int horasRetorno = ViaticoUtil.extraerHoras24H(planViaje.getFechaHoraProgRetorno());
					int minutosRetorno = ViaticoUtil.extraerMinutos(planViaje.getFechaHoraProgRetorno());

					result.put("horaRetorno", ViaticoUtil.formatearHorasMinutos(horasRetorno, minutosRetorno));
				}

				result.put("numeroHoras", StringUtils.EMPTY);

				if (planViaje.getNumeroHoras() != null) {

					result.put("numeroHoras", ViaticoUtil.formatearNumeros(ViaticoConstantes.UNO_INT, planViaje.getNumeroHoras()));
				}

			}

		} else if (esInternacional) {

			Date fechaEventoInicio = planViaje.getFechaHoraProgSalida();
			Date fechaEventoFin = planViaje.getFechaHoraProgRetorno();			
			
			result.put("fechaEventoInicio", FechaUtil.formatDateToDateDDMMYYYY(fechaEventoInicio));
			result.put("fechaEventoFin", FechaUtil.formatDateToDateDDMMYYYY(fechaEventoFin));

			// fecha para sugerir la fecha de salida de la siguiente comision
			Date fechaEventoFinMas1 =  fechaEventoFin == null? null : ViaticoUtil.addDiasToDate(fechaEventoFin, 1);
			result.put("fechaEventoFinMas1", FechaUtil.formatDateToDateDDMMYYYY(fechaEventoFinMas1));				
			
			result.put("numeroDias", StringUtils.EMPTY);
			if (planViaje.getNumeroDias() != null) {

				result.put("numeroDias", String.valueOf(planViaje.getNumeroDias().intValue()));
			}

		}

		return result;
	}

	/**
	 * Metodo que permite obtener los datos para generar el reporte de reembolso.
	 *
	 * @author Juan Farro
	 * @param codPlanViaje codigo de solicutud de viatico
	 * @return DTO de reembolso
	 * @throws Exception
	 * @see ReembolsoDTO
	 */
	@Override
	public ReembolsoDTO obtenerDatosReporteReembolso(String codPlanViaje) throws Exception {

		ReembolsoDTO reembolsoDTO = new ReembolsoDTO();

		if (StringUtils.isNotEmpty(codPlanViaje)) {
			BigDecimal montoComprobanteTotal = BigDecimal.ZERO;
			PlanViajeBean planViaje = planViajeDAO.obtenerPlanViajeToReembolso(codPlanViaje);
			String simboloMoneda = planViaje.getMoneda();
			if (planViaje != null) {

				reembolsoDTO.setPlanViajeBean(planViaje);

				String codigoColaborador = planViaje.getCodTrabajador();
				if (StringUtils.isNotBlank(codigoColaborador)) {
					MaestroPersonalBean colaborador = registroPersonalService.obtenerPersonaxCodigo(codigoColaborador);
					reembolsoDTO.setColaborador(MaestroPersonalUtil.parseViatico(colaborador));
				}

				String codigoRegistrador = planViaje.getCodigoRegistrador();
				if (StringUtils.isNotBlank(codigoRegistrador)) {
					MaestroPersonalBean registrador = registroPersonalService.obtenerPersonaxCodigo(codigoRegistrador);
					reembolsoDTO.setRegistrador(MaestroPersonalUtil.parseViatico(registrador));
				}

				String codigoAutorizador = planViaje.getCodPerAutoriza();
				if (StringUtils.isNotBlank(codigoRegistrador)) {
					MaestroPersonalBean autorizador = registroPersonalService.obtenerPersonaxCodigo(codigoAutorizador);
					reembolsoDTO.setAutorizador(MaestroPersonalUtil.parseViatico(autorizador));
				}

				String codigoNivelColaborador = reembolsoDTO.getColaborador().getCodigoNivel();
				if (StringUtils.isNotBlank(codigoNivelColaborador)) {
					NivelBean nivel = nivelDAO.buscarNivelViatico(codigoNivelColaborador);
					reembolsoDTO.setNivelColaborador(nivel);
				}

				String codigoNivelAutorizador = reembolsoDTO.getAutorizador().getCodigoNivel();
				if (!StringUtils.isEmpty(codigoNivelAutorizador)) {
					NivelBean nivel = nivelDAO.buscarNivelViatico(codigoNivelAutorizador);
					reembolsoDTO.setNivelAutorizador(nivel);
				}
/*
				Map<String, Object> conceptoMap = new HashMap<String, Object>();
				List<Map<String, Object>> conceptoList = new ArrayList<Map<String, Object>>();*/

				
				ArrayList<PlanViajeRendicionBean> planViajeRendicionList = viaticoConsultaService.obtenerPlanViajeRendicionToRegistroRendicion(codPlanViaje, simboloMoneda);
				if (CollectionUtils.isNotEmpty(planViajeRendicionList)) {
					int sizeList = planViajeRendicionList.size();
					montoComprobanteTotal = new BigDecimal(planViajeRendicionList.get(sizeList - 1).getMtoReconocido());
					planViajeRendicionList.remove(sizeList - 1);
					reembolsoDTO.setPlanViajeRendicionList(planViajeRendicionList);
				}
				
				reembolsoDTO.setImporteComprobanteTotal(NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, montoComprobanteTotal, 2));
				
				BigDecimal montoGasto = BigDecimal.ZERO;
				ArrayList<PlanViajeInformeDistribBean> gastoViaticoList = viaticoConsultaService.obtenerAsignacionGastoViatico(codPlanViaje, null, simboloMoneda);
				ArrayList<PlanViajeInformeDistribBean> pasajeTasaEmbarqueList = viaticoConsultaService.obtenerPasajeTasaEmbarque(codPlanViaje, null, simboloMoneda);
				ArrayList<PlanViajeConceptoBean> planViajeConceptoList = consultaReembolsoService.obtenerPlanViajeConcepto(codPlanViaje, simboloMoneda);
				if(CollectionUtils.isNotEmpty(gastoViaticoList)){
					PlanViajeInformeDistribBean gastoViatico = gastoViaticoList.get(gastoViaticoList.size()-1);			
					reembolsoDTO.setImporteAlimentacionTotal(simboloMoneda + ViaticoConstantes.ESPACIO + gastoViatico.getMontoAlimentacionFormateado());
					reembolsoDTO.setImporteAlojamientoTotal(simboloMoneda + ViaticoConstantes.ESPACIO +gastoViatico.getMontoHospedajeFormateado());
					reembolsoDTO.setImporteMovilidadTotal(simboloMoneda + ViaticoConstantes.ESPACIO + gastoViatico.getMontoMovilidadFormateado());
					reembolsoDTO.setImporteTrasladoTotal(simboloMoneda + ViaticoConstantes.ESPACIO + gastoViatico.getMontoTrasladoFormateado());
					reembolsoDTO.setImporteTotalViatico(simboloMoneda + ViaticoConstantes.ESPACIO + gastoViatico.getMontoTotalFormateado());
				}
				
				if(CollectionUtils.isNotEmpty(pasajeTasaEmbarqueList)){
					PlanViajeInformeDistribBean pasajeTasaEmbarque = pasajeTasaEmbarqueList.get(pasajeTasaEmbarqueList.size()-1);
					
					if(StringUtils.isNotEmpty(pasajeTasaEmbarque.getMontoPasajeFormateado())){
						reembolsoDTO.setImportePasajeTotal(simboloMoneda + ViaticoConstantes.ESPACIO +pasajeTasaEmbarque.getMontoPasajeFormateado());
					}else{
						reembolsoDTO.setImportePasajeTotal(simboloMoneda + ViaticoConstantes.ESPACIO + ViaticoConstantes.CERO_INT);
					}
				
					if(StringUtils.isNotEmpty(pasajeTasaEmbarque.getMontoPasajeFormateado())){
						reembolsoDTO.setImporteTasaEmbarqueTotal(simboloMoneda + ViaticoConstantes.ESPACIO +pasajeTasaEmbarque.getMontoTUUAFormateado());
					}else{
						reembolsoDTO.setImporteTasaEmbarqueTotal(simboloMoneda + ViaticoConstantes.ESPACIO + ViaticoConstantes.CERO_INT);
					}
					montoGasto = pasajeTasaEmbarque.getMontoPasaje().add(pasajeTasaEmbarque.getMontoTUUA());
				}else{
					reembolsoDTO.setImporteTasaEmbarqueTotal(NumeroUtil.formatearMonto(simboloMoneda,0.00, 2));
					reembolsoDTO.setImportePasajeTotal(NumeroUtil.formatearMonto(simboloMoneda,0.00, 2));
				}
				
				if(CollectionUtils.isNotEmpty(planViajeConceptoList)){
					PlanViajeConceptoBean planViajeConcepto = planViajeConceptoList.get(planViajeConceptoList.size()-1);
					reembolsoDTO.setImporteOtrasAsignacionesTotal(simboloMoneda + ViaticoConstantes.ESPACIO +planViajeConcepto.getMontoFormateado());
					montoGasto = montoGasto.add(BigDecimal.valueOf(planViajeConcepto.getMonto()));
				}else{
					reembolsoDTO.setImporteOtrasAsignacionesTotal(NumeroUtil.formatearMonto(simboloMoneda,0.00, 2));
				}
				reembolsoDTO.setFechaActual(FechaUtil.formatDateToDateDDMMYYYY(new Date()));
				reembolsoDTO.setHoraActual(FechaUtil.formatDateToHourHHMM(new Date()));
				reembolsoDTO.setImporteMontoTotalGasto(NumeroUtil.formatearMonto(simboloMoneda, montoGasto, 2));
			/*	
				List<PlanViajeConceptoBean> listaPlanViajeConcepto = planViajeConceptoDAO.buscarPlanViajeConceptos(codPlanViaje);
				Double montoTotalConcepto = 0D;

				if (CollectionUtils.isNotEmpty(listaPlanViajeConcepto)) {

					if (planViaje.getTipoDestino().equals(ViaticoConstantes.TIPO_COMISION_NACIONAL)) {

						List<CuentaCorrienteBean> cuentas = cuentaCorrienteDAO.obtenerCuentasCorriente(ViaticoConstantes.MONEDA_SOLES);
						if (CollectionUtils.isNotEmpty(cuentas)) {
							reembolsoDTO.setCuenta(cuentas.get(0));
						}

						for (PlanViajeConceptoBean planViajeConcepto : listaPlanViajeConcepto) {

							ConceptoPlanillaViaticosBean conceptoPlanillaViatico = viaticoService.obtenerConceptoViatico(StringUtils.trimToEmpty(planViajeConcepto.getConceptoID()));
							boolean esConceptoPlanillaTipoVariable = ViaticoConstantes.CONCEPTO_VIATICO_TIPO_FIJ_PVI_VARIABLE.equals(conceptoPlanillaViatico.getTipoFijoPVI());

							if (esConceptoPlanillaTipoVariable) {

								Double asignacionDiaria = planViajeConcepto.getMonto();
								if (asignacionDiaria != null) {
									conceptoMap = new HashMap<String, Object>();
									String campoNumeroDia = ReporteConstantes.CAMPO_VACIO;
									Double numeroDia = planViajeConcepto.getCantidad();
									double montoImporte = asignacionDiaria * numeroDia;

									conceptoMap.put("concepto", conceptoPlanillaViatico.getDescripcionConcepto());
									conceptoMap.put("numDia", campoNumeroDia);
									conceptoMap.put("asignacionDiaria", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(asignacionDiaria), 2));
									conceptoMap.put("mtoImporte", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(montoImporte), 2));
									montoTotalConcepto += montoImporte;
									conceptoList.add(conceptoMap);
								}

							} else {

								Double asignacionDiaria = planViajeConcepto.getMonto();
								conceptoMap = new HashMap<String, Object>();
								Double numeroDia = planViajeConcepto.getCantidad();
								double montoImporte = asignacionDiaria * numeroDia;
								conceptoMap.put("concepto", ViaticoConstantes.MODULO_VIATICOS);
								if (planViaje.getIndicadorHoras().equals(ViaticoConstantes.INDICADOR_HORAS_DIAS)) {
									conceptoMap.put("numDia", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(planViaje.getNumDias()), 0));
								} else {
									conceptoMap.put("numDia", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(planViaje.getNumeroHoras()), 0));
								}
								conceptoMap.put("asignacionDiaria", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(asignacionDiaria), 2));
								conceptoMap.put("mtoImporte", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(montoImporte), 2));
								montoTotalConcepto += montoImporte;
								conceptoList.add(conceptoMap);
							}
						}

					} else if (planViaje.getTipoDestino().equals(ViaticoConstantes.TIPO_COMISION_INTERNACIONAL)) {

						List<PlanViajeDestinoBean> listaPlanViajeDestino = planViajeDestinoDAO.buscarPlanViajeDestinos(codPlanViaje);

						List<CuentaCorrienteBean> cuentas = cuentaCorrienteDAO.obtenerCuentasCorriente(ViaticoConstantes.MONEDA_DOLARES);

						if (CollectionUtils.isNotEmpty(cuentas)) {
							reembolsoDTO.setCuenta(cuentas.get(0));
						}

						if (CollectionUtils.isNotEmpty(listaPlanViajeDestino)) {

							// viaticos
							Double diaViatico = 0D;
							Double montoViaticoTotal = 0D;
							Double diaViaticoTotal = 0D;

							for (PlanViajeDestinoBean planViajeDestino : listaPlanViajeDestino) {
								diaViatico = planViajeDestino.getDias();
								montoViaticoTotal += planViajeDestino.getMontoDiario() * diaViatico;
								diaViaticoTotal += diaViatico;
							}

							conceptoMap = new HashMap<String, Object>();
							conceptoMap.put("concepto", ViaticoConstantes.MODULO_VIATICOS);
							conceptoMap.put("numDia", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(diaViaticoTotal), 0));
							conceptoMap.put("asignacionDiaria", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(montoViaticoTotal / diaViaticoTotal), 2));
							conceptoMap.put("mtoImporte", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(montoViaticoTotal), 2));
							conceptoList.add(conceptoMap);

							montoTotalConcepto = montoTotalConcepto + montoViaticoTotal;

							// gasto instalacion
							Integer diaTraslado = 0;
							Double montoTrasladoTotal = 0D;
							Double diaTrasladoTotal = 0D;

							for (PlanViajeDestinoBean planViajeDestino : listaPlanViajeDestino) {
								diaTraslado = planViajeDestino.getDiasExtra();
								montoTrasladoTotal += planViajeDestino.getMontoTraslado() * diaTraslado;
								diaTrasladoTotal += diaTraslado;
							}

							conceptoMap = new HashMap<String, Object>();
							conceptoMap.put("concepto", ViaticoConstantes.GASTO_INSTACION_TRASLADO);
							conceptoMap.put("numDia", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(diaTrasladoTotal), 0));
							conceptoMap.put("asignacionDiaria", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(montoTrasladoTotal / diaTrasladoTotal), 2));
							conceptoMap.put("mtoImporte", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(montoTrasladoTotal), 2));
							montoTotalConcepto = montoTotalConcepto + montoTrasladoTotal;
							conceptoList.add(conceptoMap);
						}

						// sobra
						for (PlanViajeConceptoBean planViajeConcepto : listaPlanViajeConcepto) {

							ConceptoPlanillaViaticosBean conceptoPlanillaViatico = viaticoService.obtenerConceptoViatico(StringUtils.trimToEmpty(planViajeConcepto.getConceptoID()));

							boolean esConceptoPlanillaTipoVariable = ViaticoConstantes.CONCEPTO_VIATICO_TIPO_FIJ_PVI_VARIABLE.equals(conceptoPlanillaViatico.getTipoFijoPVI());

							if (esConceptoPlanillaTipoVariable) {
								Double asignacionDiaria = planViajeConcepto.getMonto();
								if (asignacionDiaria != null) {
									conceptoMap = new HashMap<String, Object>();
									String campoNumeroDia = ReporteConstantes.CAMPO_VACIO;
									Double numeroDia = planViajeConcepto.getCantidad();
									double montoImporte = asignacionDiaria * numeroDia;

									conceptoMap.put("concepto", conceptoPlanillaViatico.getDescripcionConcepto());
									conceptoMap.put("numDia", campoNumeroDia);
									conceptoMap.put("asignacionDiaria", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(asignacionDiaria), 2));
									conceptoMap.put("mtoImporte", NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(montoImporte), 2));
									montoTotalConcepto += montoImporte;
									conceptoList.add(conceptoMap);
								}
							}

						}

					}
				}

				reembolsoDTO.setMontoTotalConcepto(NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, new BigDecimal(montoTotalConcepto), 2));
				reembolsoDTO.setConceptoList(conceptoList);
*/
				// seteando datos de la planilla asociada
				boolean esMotivoAmpliacion = StringUtils.equals(planViaje.getCodigoTipoMotReembolso(), ViaticoConstantes.MOTIVO_AMPLIACION_AMPLIACION_COMISION);

				if (esMotivoAmpliacion) {

					PlanViajeBean planViajeAsociada = planViajeDAO.buscarPlanViaje(planViaje.getCodigoPlanillaAsc());

					if (planViajeAsociada != null) {
						reembolsoDTO.setPlanillaAsociada(planViajeAsociada);
					}

				}

			}

		}

		return reembolsoDTO;
	}
	
	/**
	 * Metodo que permite obtener los datos para realizar el sustento de gasto reembolso.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @return Objeto PlanViajeBean.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	public PlanViajeBean obtenerPlanViajeToSustentoGastoReembolso(String codPlanViaje) throws Exception {
		return planViajeDAO.obtenerPlanViajeToSustentoGastoReembolso(codPlanViaje);
	}
	
	/**
	 * Metodo que permite obtener el listado de plan viaje concepto asociados a un reembolso.
	 * @author Jorge Ponce.
	 * @param  planViajeID :codigo plan viaje.
	 * @param  simboloMoneda :simbolo de la moneda.
	 * @return Listado de plan de viaje concepto.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	public ArrayList<PlanViajeConceptoBean> obtenerPlanViajeConcepto(String planViajeID, String simboloMoneda) throws Exception {
		
		ArrayList<PlanViajeConceptoBean> planViajeConceptoList = planViajeConceptoDAO.obtenerPlanViajeConceptoToRendicion(planViajeID);
		ArrayList<PlanViajeConceptoBean> planViajeConceptoAuxList = null;
		if (planViajeConceptoList != null && !planViajeConceptoList.isEmpty()) {
			BigDecimal montoTotal = BigDecimal.ZERO;
			planViajeConceptoAuxList = new ArrayList<PlanViajeConceptoBean>();
			for (PlanViajeConceptoBean planViajeConceptoBean : planViajeConceptoList) {
				BigDecimal cantidad = BigDecimal.ZERO;
				BigDecimal montoAsignado = BigDecimal.ZERO;
				BigDecimal monto = BigDecimal.ZERO;
				String montoFormateado = ReembolsoConstantes.CADENA_VACIA;
				if (planViajeConceptoBean.getCantidad() != null) {
					cantidad = cantidad.add(new BigDecimal(planViajeConceptoBean.getCantidad()));
				}
				if (planViajeConceptoBean.getMonto() != null) {
					montoAsignado = montoAsignado.add(new BigDecimal(planViajeConceptoBean.getMonto()));
				}
				monto = cantidad.multiply(montoAsignado);
				montoFormateado = NumeroUtil.formatearMonedaMontoToDecimal(null, 2, monto);
				montoTotal = montoTotal.add(monto);
				planViajeConceptoBean.setMonto(new Double(montoFormateado));
				planViajeConceptoBean.setMontoFormateado(NumeroUtil.formatearMonto(null, monto, 2));
				planViajeConceptoBean.setFlagPlanViajeConceptoTotal(RendicionConstantes.CERO);
				planViajeConceptoAuxList.add(planViajeConceptoBean);
			}
			PlanViajeConceptoBean planViajeConceptoBean = new PlanViajeConceptoBean();
			planViajeConceptoBean.setDescripcionConcepto(RendicionConstantes.TOTAL + RendicionConstantes.ESPACIO + simboloMoneda);
			planViajeConceptoBean.setMonto(new Double(NumeroUtil.formatearMonedaMontoToDecimal(null, 2, montoTotal)));
			planViajeConceptoBean.setMontoFormateado(NumeroUtil.formatearMonto(null, montoTotal, 2));
			planViajeConceptoBean.setFlagPlanViajeConceptoTotal(RendicionConstantes.UNO);
			planViajeConceptoAuxList.add(planViajeConceptoBean);
		}
		return planViajeConceptoAuxList;
	}
	
	/**
	 * Metodo que permite obtener el listado de detalle de los planes de viaje que se muestran la bandeja de reembolso.
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @param codigoDependencia :codigo de dependencia.
	 * @param codPlanilla :codigo de planilla.
	 * @param codTrabajador :codigo del colaborador.
	 * @param codEstadoSolic :codigo de estado de la solicitud.
	 * @param fechaDesde :fecha desde.
	 * @param fechaHasta :fecha hasta.
	 * @param codigoAutorizador :codigo del autorizador.
	 * @return Objeto PlanViajeBean.
	 * @see PlanViajeBean
	 * @throws Exception
	 */
	public ArrayList<PlanViajeBean> obtenerPlanViajeDetalleToBandejaReembolso(String codPlanViaje, String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoSolic, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws Exception {
		
		ArrayList<PlanViajeBean> planViajeList = planViajeDAO.obtenerPlanViajeDetalleToBandejaReembolso(codPlanViaje, codigoDependencia, codPlanilla, codTrabajador, codEstadoSolic, fechaDesde, fechaHasta, codigoAutorizador);
		ArrayList<PlanViajeBean> planViajeListAux = null;
		if (planViajeList != null && !planViajeList.isEmpty()) {
			planViajeListAux = new ArrayList<PlanViajeBean>();
			for (PlanViajeBean planViajeBean : planViajeList) {
				PlanViajeBean planViajeBeanAux = new PlanViajeBean();
				planViajeBeanAux.setCodPlanViaje(planViajeBean.getCodPlanViaje());
				planViajeBeanAux.setCodPlanilla(planViajeBean.getCodPlanilla());
				planViajeBeanAux.setCodigoPlanillaAsc(planViajeBean.getCodigoPlanillaAsc());
				planViajeBeanAux.setNomUuOoCom(FormatoUtil.getUppperCaseText(planViajeBean.getNomUuOoCom()));
				planViajeBeanAux.setItinerario(planViajeBean.getItinerario());
				planViajeBeanAux.setFecSalidaFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecSalida()));
				planViajeBeanAux.setFecRetornoFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecRetorno()));
				planViajeBeanAux.setMotivoComis(FormatoUtil.getUppperCaseText(planViajeBean.getMotivoComis()));
				planViajeBeanAux.setObservacionAnulacion(FormatoUtil.getUppperCaseText(planViajeBean.getObservacionAnulacion()));
				planViajeBeanAux.setNomColaborador(FormatoUtil.getUppperCaseText(planViajeBean.getNomColaborador()));
				planViajeBeanAux.setNomRegistrador(FormatoUtil.getUppperCaseText(planViajeBean.getNomRegistrador()));
				planViajeBeanAux.setInternacionalNroResolucion(FormatoUtil.getUppperCaseText(planViajeBean.getInternacionalNroResolucion()));
				planViajeBeanAux.setImpGastoAlojFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getImpGastoAloj(), 2));
				planViajeBeanAux.setImpGastoAlimFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getImpGastoAlim(), 2));
				planViajeBeanAux.setImpGastoMovLocalFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getImpGastoMovLocal(), 2));
				planViajeBeanAux.setImpGastoTrasladoFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getImpGastoTraslado(), 2));
				planViajeBeanAux.setImpGastoPasajesFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getImpGastoPasajes(), 2));
				planViajeBeanAux.setImpGastoTUUAFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getImpGastoTUUA(), 2));
				planViajeBeanAux.setMedioPago(planViajeBean.getMedioPago());
				planViajeListAux.add(planViajeBeanAux);
			}
		}
		return planViajeListAux;
	}
	
	
	/**
	 * Metodo que permite obtener solicitudes de viatico para la bandeja de consulta, revision y alta (CUS10, CUS09 y CUS13).
	 * 
	 * @author Samuel Dionisio
	 * @param parmSearch parametros de busqueda
	 * @return lista de solicitudes de reembolsos
	 * @throws Exception
	 * @see PlanViajeBean
	 */
	@Override
	public List<PlanViajeBean> obtenerReembolsosBandejaConsultaRevision(Map<String, Object> parmSearch) throws Exception {

		List<PlanViajeBean> listaSolicitudes = (List<PlanViajeBean>) planViajeDAO.getReembolsosBandejaConsultaRevision(parmSearch);

		return listaSolicitudes;
	}
	
	/**
	 * Metodo que permite buscar los estados de una solicitud de viatico (t01parametro).
	 * 
	 * @author Samuel Dionisio
	 * @return lista de estados de solicitud de viatico
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<SysEstadosBean> obtenerListaEstadosReembolsoViatico() throws Exception {

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("nom_tabla", ViaticoConstantes.ESTADO_REEMBOLSO_NOMBRE_TABLA);

		List<SysEstadosBean> listaEstados = (List<SysEstadosBean>) registroGeneralService.listarEstados(params);

		return listaEstados;
	}
	
	/**
	 * Metodo que permite obtener el monto total de comprobantes de gasto.
	 * @author Juan Farro
	 * @param  planViajeId :codigo plan viaje.
	 * @return Monto total depositado.
	 * @throws Exception
	 */
	@Override
	public BigDecimal obtenerMontoComprobanteGasto(String planViajeId) throws Exception {

		BigDecimal montoComprobanteGasto = planViajeRendicionDAO.obtenerMontoComprobanteGasto(planViajeId);
		
		return montoComprobanteGasto;
	}		
	
	/**
	 * Metodo que permite obtener las solicitudes de viatico para exportar en la bandeja.
	 * 
	 * @author Samuel Dionisio
	 * @param parmSearch parametros de busqueda
	 * @return lista de reembolsos
	 * @throws Exception
	 * @see PlanViajeBean
	 */
	@Override
	public List<PlanViajeBean> obtenerReembolsoBandejaExportar(Map<String, Object> parmSearch) throws Exception {
		return (List<PlanViajeBean>) planViajeDAO.getSolicitudesBandejaExportar(parmSearch);
	}
}