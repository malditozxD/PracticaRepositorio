package pe.gob.sunat.recurso2.financiera.siga.viatico.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.recurso2.administracion.siga.util.FechaUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ConceptoPlanillaViaticosBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.ConceptoPlanillaViaticosDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoUtil;

/**
 * Clase ViaticoService.
 * 
 * @author Juan Saccatoma
 */
public class ViaticoServiceImpl implements ViaticoService {

	/** Declaracion del log para realizar los debug, info, error, etc. */
	protected final Log log = LogFactory.getLog(getClass());

	/** Declaracion del DAO planViajeDAO. */
	private PlanViajeDAO planViajeDAO;

	/** Declaracion del DAO conceptoPlanillaViaticosDAO. */
	private ConceptoPlanillaViaticosDAO conceptoPlanillaViaticosDAO;

	public ConceptoPlanillaViaticosDAO getConceptoPlanillaViaticosDAO() {
		return conceptoPlanillaViaticosDAO;
	}

	public void setConceptoPlanillaViaticosDAO(ConceptoPlanillaViaticosDAO conceptoPlanillaViaticosDAO) {
		this.conceptoPlanillaViaticosDAO = conceptoPlanillaViaticosDAO;
	}

	public PlanViajeDAO getPlanViajeDAO() {
		return planViajeDAO;
	}

	public void setPlanViajeDAO(PlanViajeDAO planViajeDAO) {
		this.planViajeDAO = planViajeDAO;
	}

	/**
	 * Metodo que permite obtener conceptos viatico.
	 * 
	 * @author Juan Saccatoma
	 * 
	 * @param codigo codigo del concepto de viatico
	 * @param descripcion descripcion del concepto de viatico
	 * @return lista de conceptos de viatico
	 * @throws Exception
	 */
	@Override
	public List<ConceptoPlanillaViaticosBean> obtenerConceptosViatico(String codigo, String descripcion) throws Exception {

		Map<String, Object> parmSearch = new HashMap<String, Object>();

		parmSearch.put("codigo", codigo);
		parmSearch.put("descripcion", descripcion);

		return conceptoPlanillaViaticosDAO.obtenerConceptosViatico(parmSearch);
	}

	/**
	 * Metodo que permite obtener conceptos viatico nacional.
	 * 
	 * @author Juan Farro
	 * @param codigo codigo del concepto de viatico
	 * @param descripcion descripcion del concepto de viatico
	 * @return lista de conceptos de viatico
	 * @throws Exception
	 */
	@Override
	public List<ConceptoPlanillaViaticosBean> obtenerConceptosViaticoNacional(String codigo, String descripcion) throws Exception {

		Map<String, Object> parmSearch = new HashMap<String, Object>();

		parmSearch.put("codigo", codigo);
		parmSearch.put("descripcion", descripcion);

		// para nacional se requieren estos parametros adicionales
		parmSearch.put("combinacion1", ViaticoConstantes.CONCEPTO_VIATICO_COMBINACION_NACIONAL);
		parmSearch.put("tipoFijoPVI", ViaticoConstantes.CONCEPTO_VIATICO_TIPO_FIJ_PVI_VARIABLE);
		parmSearch.put("indicadorSolicitud", ViaticoConstantes.UNO);
		parmSearch.put("anioClasificador", FechaUtil.obtenerAnioActual());

		return conceptoPlanillaViaticosDAO.obtenerConceptosViatico(parmSearch);
	}

	/**
	 * Metodo que permite obtener conceptos viatico nacional.
	 * 
	 * @author Juan Farro
	 * @return lista de conceptos de viatico
	 * @throws Exception
	 */
	@Override
	public List<ConceptoPlanillaViaticosBean> obtenerConceptosViaticoNacional() throws Exception {

		Map<String, Object> parmSearch = new HashMap<String, Object>();

		// para nacional se requieren estos parametros adicionales
		parmSearch.put("combinacion1", ViaticoConstantes.CONCEPTO_VIATICO_COMBINACION_NACIONAL);
		parmSearch.put("tipoFijoPVI", ViaticoConstantes.CONCEPTO_VIATICO_TIPO_FIJ_PVI_VARIABLE);
		parmSearch.put("indicadorSolicitud", ViaticoConstantes.UNO);
		parmSearch.put("anioClasificador", FechaUtil.obtenerAnioActual());

		return conceptoPlanillaViaticosDAO.obtenerConceptosViatico(parmSearch);
	}

	/**
	 * Metodo que permite obtener conceptos viatico internacional.
	 * 
	 * @author Juan Farro
	 * @param codigo codigo del concepto de viatico
	 * @param descripcion descripcion del concepto de viatico
	 * @return lista de conceptos de viatico
	 * @throws Exception
	 */
	@Override
	public List<ConceptoPlanillaViaticosBean> obtenerConceptosViaticoInternacional(String codigo, String descripcion) throws Exception {

		Map<String, Object> parmSearch = new HashMap<String, Object>();

		parmSearch.put("codigo", codigo);
		parmSearch.put("descripcion", descripcion);

		// para nacional se requieren estos parametros adicionales
		parmSearch.put("combinacion2", ViaticoConstantes.CONCEPTO_VIATICO_COMBINACION_INTERNACIONAL);
		parmSearch.put("tipoFijoPVI", ViaticoConstantes.CONCEPTO_VIATICO_TIPO_FIJ_PVI_VARIABLE);
		parmSearch.put("indicadorSolicitud", ViaticoConstantes.UNO);
		parmSearch.put("anioClasificador", FechaUtil.obtenerAnioActual());

		return conceptoPlanillaViaticosDAO.obtenerConceptosViatico(parmSearch);
	}

	/**
	 * Metodo que permite obtener conceptos viatico internacional.
	 * 
	 * @author Juan Farro
	 * @return lista de conceptos de viatico
	 * @throws Exception
	 */
	@Override
	public List<ConceptoPlanillaViaticosBean> obtenerConceptosViaticoInternacional() throws Exception {

		Map<String, Object> parmSearch = new HashMap<String, Object>();

		// para nacional se requieren estos parametros adicionales
		parmSearch.put("combinacion2", ViaticoConstantes.CONCEPTO_VIATICO_COMBINACION_INTERNACIONAL);
		parmSearch.put("tipoFijoPVI", ViaticoConstantes.CONCEPTO_VIATICO_TIPO_FIJ_PVI_VARIABLE);
		parmSearch.put("indicadorSolicitud", ViaticoConstantes.UNO);
		parmSearch.put("anioClasificador", FechaUtil.obtenerAnioActual());

		return conceptoPlanillaViaticosDAO.obtenerConceptosViatico(parmSearch);
	}

	@Override
	public ArrayList<ConceptoPlanillaViaticosBean> obtenerConceptoPlanillaViaticosToComprobante(String idPlanViaje) throws Exception {
		return conceptoPlanillaViaticosDAO.obtenerConceptoPlanillaViaticosToComprobante(idPlanViaje);
	}

	/**
	 * Metodo que permite obtener el importe diario nacional.
	 * 
	 * @author Juan Farro
	 * @param anioClasificador anio clasificador
	 * @param codigoDepartamento codigo de departamento
	 * @param codigoProvincia codigo de provincia
	 * @param nivelViatico nivel viatico
	 * @return concepto de viatico
	 * @throws Exception
	 */
	@Override
	public ConceptoPlanillaViaticosBean obtenerImporteDiarioNacional(String anioClasificador, String codigoDepartamento, String codigoProvincia, String nivelViatico) throws Exception {
		Map<String, Object> params = new HashMap<String, Object>();

		params.put("ANN_CLASIFICADOR", anioClasificador);
		params.put("CODI_CONC_PVI", ViaticoConstantes.CONCEPTO_VIATICO_CODI_CONC_PVI_FIJO_NACIONAL);
		params.put("COD_DEPARTAMENTO", codigoDepartamento);
		params.put("COD_PROVINCIA", codigoProvincia);
		params.put("COD_DISTRITO", StringUtils.EMPTY);
		params.put("NIVE_VIAT_NVI", StringUtils.trimToNull(nivelViatico));
		// params.put("ESTA_ESC_VIAT", ViaticoConstantes.ESCALA_VIATICO_ESTA_ESC_VIAT_SI);

		List<ConceptoPlanillaViaticosBean> listaConceptos = conceptoPlanillaViaticosDAO.obtenerImporteDiario(params);
		if (CollectionUtils.isNotEmpty(listaConceptos)) {
			return listaConceptos.get(0);
		}

		return null;
	}

	/**
	 * Metodo que permite obtener el importe diario internacional.
	 * 
	 * @author Juan Farro
	 * @param anioClasificador anio clasificador
	 * @param codigoUbigeo codigo de ubigeo
	 * @param nivelViatico nivel de viatico
	 * @return concepto de viatico
	 * @throws Exception
	 */
	@Override
	public ConceptoPlanillaViaticosBean obtenerImporteDiarioInternacional(String anioClasificador, String codigoUbigeo, String nivelViatico) throws Exception {
		Map<String, Object> params = new HashMap<String, Object>();

		params.put("ANN_CLASIFICADOR", anioClasificador);
		params.put("CODI_CONC_PVI", ViaticoConstantes.CONCEPTO_VIATICO_CODI_CONC_PVI_FIJO_INTERNACIONAL);
		params.put("COD_DEPARTAMENTO", ViaticoConstantes.CODIGO_00);
		params.put("COD_PROVINCIA", ViaticoConstantes.CODIGO_00);
		params.put("COD_DISTRITO", StringUtils.substring(StringUtils.trimToEmpty(codigoUbigeo), 4));
		params.put("NIVE_VIAT_NVI", StringUtils.trimToNull(nivelViatico));
		params.put("ESTA_ESC_VIAT", ViaticoConstantes.ESCALA_VIATICO_ESTA_ESC_VIAT_SI);

		List<ConceptoPlanillaViaticosBean> listaConceptos = conceptoPlanillaViaticosDAO.obtenerImporteDiario(params);
		if (CollectionUtils.isNotEmpty(listaConceptos)) {
			return listaConceptos.get(0);
		}

		return null;
	}

	/**
	 * Metodo que permite obtener los conceptos de viatico fijos nacionales.
	 * 
	 * @author Juan Farro
	 * @return lista de conceptos de viatico
	 * @throws Exception
	 */
	@Override
	public List<ConceptoPlanillaViaticosBean> obtenerConceptosViaticoFijosNacionalAsignacion() throws Exception {

		Map<String, Object> parmSearch = new HashMap<String, Object>();

		parmSearch.put("combinacion1", ViaticoConstantes.CONCEPTO_VIATICO_COMBINACION_NACIONAL);
		parmSearch.put("tipoFijoPVI", ViaticoConstantes.CONCEPTO_VIATICO_TIPO_FIJ_PVI_FIJO); // FIJO
		parmSearch.put("indicadorSolicitud", ViaticoConstantes.UNO);
		parmSearch.put("anioClasificador", FechaUtil.obtenerAnioActual());

		return conceptoPlanillaViaticosDAO.obtenerConceptosViatico(parmSearch);
	}

	/**
	 * Metodo que permite obtener los conceptos de viatico fijos internacionales.
	 * 
	 * @author Juan Farro
	 * @return lista de conceptos de viatico
	 * @throws Exception
	 */
	@Override
	public List<ConceptoPlanillaViaticosBean> obtenerConceptosViaticoFijosInternacionalAsignacion() throws Exception {

		Map<String, Object> parmSearch = new HashMap<String, Object>();

		// para nacional se requieren estos parametros adicionales
		parmSearch.put("combinacion2", ViaticoConstantes.CONCEPTO_VIATICO_COMBINACION_INTERNACIONAL);
		parmSearch.put("tipoFijoPVI", ViaticoConstantes.CONCEPTO_VIATICO_TIPO_FIJ_PVI_FIJO); // FIJO
		parmSearch.put("indicadorSolicitud", ViaticoConstantes.UNO);
		parmSearch.put("anioClasificador", FechaUtil.obtenerAnioActual());

		return conceptoPlanillaViaticosDAO.obtenerConceptosViatico(parmSearch);
	}

	/**
	 * Metodo que permite obtener los dias habiles entre dos fechas.
	 * 
	 * @author Juan Farro
	 * @param fechaInicial fecha inicial
	 * @param fechaFinal fecha final
	 * @return numero de dias habiles
	 * @throws Exception
	 */
	@Override
	public int calcularDiasHabiles(Date fechaInicial, Date fechaFinal) throws Exception {

		// PRE: fechaFinal >= fechaInicial
		if (fechaInicial == null || fechaFinal == null) throw new IllegalArgumentException("Parametros no pueden ser null");
		// if (fechaFinal.getTime() < fechaInicial.getTime()) throw new IllegalArgumentException("calcularDiasHabiles: fechaFinal no puede ser menor a fechaInicial");
		if (fechaFinal.getTime() < fechaInicial.getTime()) return 0;

		// caso particular, si son iguales retornar 1
		if (ViaticoUtil.restarDias(fechaFinal, fechaInicial) == 0) return 1;

		Date fechaInicialHabil = planViajeDAO.fechaDiasHabiles(fechaInicial, 1);
		Date fechaFinalHabil = planViajeDAO.fechaDiasHabiles(fechaFinal, -1);

		int nroDiasHabiles = 0;
		Date fechaIter = fechaInicialHabil;

		do {

			nroDiasHabiles++;
			fechaIter = sumarDiasHabiles(fechaIter, 1);

		} while (fechaIter.getTime() < fechaFinalHabil.getTime());

		return nroDiasHabiles + 1;
	}

	/**
	 * Metodo que permite obtener el siguiente dia habil al sumarle dias a fecha.
	 * 
	 * @author Juan Farro
	 * @param fecha fecha inicial
	 * @param dias numero de dias a sumar
	 * @return fecha resultante
	 * @throws Exception
	 */
	@Override
	public Date sumarDiasHabiles(Date fecha, int dias) throws Exception {

		if (fecha == null) throw new IllegalArgumentException("fecha no puede ser null");

		// retorna el siguiente dia habil al sumarle "dias" a "fecha"
		Date sgteDiaHabil = planViajeDAO.fechaDiasHabiles(ViaticoUtil.addDiasToDate(fecha, 1), dias);

		return sgteDiaHabil;
	}

	/**
	 * Metodo que permite determinar si una fecha es dia habil.
	 * 
	 * @author Juan Farro
	 * @param fecha fecha a evaluar
	 * @return true, si es dia habil
	 * @throws Exception
	 */
	@Override
	public boolean esDiaHabil(Date fecha) throws Exception {

		if (fecha == null) return false;

		// si es sabado, domingo o feriado, bota el siguiente dia habil -> la diferencia de dias es != 0
		Date resultDia = planViajeDAO.fechaDiasHabiles(fecha, 1);

		return ViaticoUtil.restarDias(resultDia, fecha) != 0;
	}

	/**
	 * Metodo que permite buscar un concepto de viatico a partir de su codigo.
	 * 
	 * @author Juan Farro
	 * @param codigo del concepto de viatico
	 * @return concepto de viatico
	 * @throws Exception
	 */
	@Override
	public ConceptoPlanillaViaticosBean obtenerConceptoViatico(String codigo) throws Exception {

		return conceptoPlanillaViaticosDAO.obtenerConceptoViatico(codigo);
	}
	
	@Override
	public String obtenerExistenciaPlanillasConsecutivas(String codiEmplPer, Date fecInicio, Date fecFin, String origen) throws Exception {
		
		return planViajeDAO.obtenerExistenciaPlanillasConsecutivas(codiEmplPer, fecInicio, fecFin, origen);
	}

}