package pe.gob.sunat.recurso2.financiera.siga.viatico.rendicion.service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;

import pe.gob.sunat.recurso2.administracion.siga.archivo.service.RegistroArchivosService;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.administracion.siga.util.FechaUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.FormatoUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.NumeroUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.CabeceraMovBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ComprobanteIngresoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ConceptoPlanillaViaticosBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.NivelBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PapeletaDepositoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeConceptoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeInformeDistribBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeRendicionBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.RendicionDTO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.CabeceraMovDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.ComprobanteIngresoDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.NivelDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PapeletaDepositoDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeConceptoDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeInformeDistribDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeRendicionDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoConsultaService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.MaestroPersonalUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.RendicionConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;

/**
 * Implementacion de la interface ConsultaRendicionService, contiene los metodos para la consulta de rendicion.
 * @author Juan Saccatoma.
 */
public class ConsultaRendicionServiceImpl implements ConsultaRendicionService {
	
	protected final Log log = LogFactory.getLog(getClass());
	private ViaticoConsultaService viaticoConsultaService;
	private RegistroPersonalService registroPersonalService;
	private ViaticoService viaticoService;
	private RegistroArchivosService registroArchivosService;
	private PlanViajeDAO planViajeDAO;
	private PlanViajeRendicionDAO planViajeRendicionDAO;
	private PlanViajeInformeDistribDAO planViajeInformeDistribDAO;
	private PlanViajeConceptoDAO planViajeConceptoDAO;
	private PapeletaDepositoDAO papeletaDepositoDAO;
	private ComprobanteIngresoDAO comprobanteIngresoDAO;
	private NivelDAO nivelDAO;
	private CabeceraMovDAO cabeceraMovDAO;
	
	public ViaticoConsultaService getViaticoConsultaService() {
		return viaticoConsultaService;
	}

	public void setViaticoConsultaService(ViaticoConsultaService viaticoConsultaService) {
		this.viaticoConsultaService = viaticoConsultaService;
	}

	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}

	public ViaticoService getViaticoService() {
		return viaticoService;
	}

	public void setViaticoService(ViaticoService viaticoService) {
		this.viaticoService = viaticoService;
	}

	public RegistroArchivosService getRegistroArchivosService() {
		return registroArchivosService;
	}

	public void setRegistroArchivosService(RegistroArchivosService registroArchivosService) {
		this.registroArchivosService = registroArchivosService;
	}

	public PlanViajeDAO getPlanViajeDAO() {
		return planViajeDAO;
	}

	public void setPlanViajeDAO(PlanViajeDAO planViajeDAO) {
		this.planViajeDAO = planViajeDAO;
	}

	public PlanViajeRendicionDAO getPlanViajeRendicionDAO() {
		return planViajeRendicionDAO;
	}

	public void setPlanViajeRendicionDAO(PlanViajeRendicionDAO planViajeRendicionDAO) {
		this.planViajeRendicionDAO = planViajeRendicionDAO;
	}

	public PlanViajeInformeDistribDAO getPlanViajeInformeDistribDAO() {
		return planViajeInformeDistribDAO;
	}

	public void setPlanViajeInformeDistribDAO(PlanViajeInformeDistribDAO planViajeInformeDistribDAO) {
		this.planViajeInformeDistribDAO = planViajeInformeDistribDAO;
	}

	public PlanViajeConceptoDAO getPlanViajeConceptoDAO() {
		return planViajeConceptoDAO;
	}

	public void setPlanViajeConceptoDAO(PlanViajeConceptoDAO planViajeConceptoDAO) {
		this.planViajeConceptoDAO = planViajeConceptoDAO;
	}

	public PapeletaDepositoDAO getPapeletaDepositoDAO() {
		return papeletaDepositoDAO;
	}

	public void setPapeletaDepositoDAO(PapeletaDepositoDAO papeletaDepositoDAO) {
		this.papeletaDepositoDAO = papeletaDepositoDAO;
	}

	public ComprobanteIngresoDAO getComprobanteIngresoDAO() {
		return comprobanteIngresoDAO;
	}

	public void setComprobanteIngresoDAO(ComprobanteIngresoDAO comprobanteIngresoDAO) {
		this.comprobanteIngresoDAO = comprobanteIngresoDAO;
	}

	public NivelDAO getNivelDAO() {
		return nivelDAO;
	}

	public void setNivelDAO(NivelDAO nivelDAO) {
		this.nivelDAO = nivelDAO;
	}

	public CabeceraMovDAO getCabeceraMovDAO() {
		return cabeceraMovDAO;
	}

	public void setCabeceraMovDAO(CabeceraMovDAO cabeceraMovDAO) {
		this.cabeceraMovDAO = cabeceraMovDAO;
	}

	/**
	 * Metodo que permite obtener el listado de rendiciones.
	 * @author Juan Saccatoma.
	 * @param  parmSearch :objeto que tiene los parametros de la busqueda.
	 * @return Lista de rendiciones.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	public List<PlanViajeBean> obtenerRendicionesBandeja(Map<String, Object> parmSearch) throws Exception {
		List<PlanViajeBean> lista = (List<PlanViajeBean>) planViajeDAO.getRendicionesBandeja(parmSearch);
		return lista;
	}
	
	/**
	 * Metodo que permite obtener el detalle de una rendicion.
	 * @author Juan Saccatoma.
	 * @param  parmSearch :objeto que tiene los parametros de la busqueda.
	 * @return Objeto PlanViajeBean.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	public List<PlanViajeBean> obtenerRendicionDetalle(Map<String, Object> parmSearch) throws Exception {
		List<PlanViajeBean> lista = (List<PlanViajeBean>) planViajeDAO.getRendicionDetalle(parmSearch);
		return lista;
	}
	
	/**
	 * Metodo que permite obtener el listado de rendiciones que se van a exportar.
	 * @author Juan Saccatoma.
	 * @param  parmSearch :objeto que tiene los parametros de la busqueda.
	 * @return Lista de rendiciones.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	public List<PlanViajeBean> obtenerRendicionesBandejaExportar(Map<String, Object> parmSearch) throws Exception {
		List<PlanViajeBean> lista = (List<PlanViajeBean>) planViajeDAO.getRendicionesBandejaExportar(parmSearch);
		return lista;
	}
	
	/**
	 * Metodo que permite obtener el listado con los datos completos de planes de viaje que se van a mostrar en la bandeja de consulta de rendicion.
	 * @author Jorge Ponce.
	 * @param  codigoDependencia :codigo de dependencia.
	 * @param  codPlanilla :codigo de planilla.
	 * @param  codTrabajador :codigo del colaborador.
	 * @param  codEstadoRend :codigo de estado de la rendicion.
	 * @param  indicadorCanalAtencion :indicador canal de atencion.
	 * @param  fechaDesde :fecha desde.
	 * @param  fechaHasta :fecha hasta.
	 * @return Objeto PlanViajeBean.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	public ArrayList<PlanViajeBean> obtenerPlanViajeCompletoToBandejaConsultaRendicion(String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoRend, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta) throws Exception {
		
		ArrayList<PlanViajeBean> planViajeList = obtenerPlanViajeToBandejaConsultaRendicion(codigoDependencia, codPlanilla, codTrabajador, codEstadoRend, indicadorCanalAtencion, fechaDesde, fechaHasta);
		ArrayList<PlanViajeBean> planViajeDetalleList = obtenerPlanViajeDetalleToBandejaConsultaRendicion(null, codigoDependencia, codPlanilla, codTrabajador, codEstadoRend, indicadorCanalAtencion, fechaDesde, fechaHasta);
		ArrayList<PlanViajeBean> planViajeCompletoList = null;
		if (planViajeList != null && !planViajeList.isEmpty() && planViajeDetalleList != null && !planViajeDetalleList.isEmpty()) {
			int sizePlanViajeList = planViajeList.size();
			int sizePlanViajeDetalleList = planViajeDetalleList.size();
			if (sizePlanViajeList == sizePlanViajeDetalleList) {
				planViajeCompletoList = new ArrayList<PlanViajeBean>();
				for (int i = 0; i < sizePlanViajeList; i++) {
					PlanViajeBean planViaje = planViajeList.get(i);
					PlanViajeBean planViajeDetalle = planViajeDetalleList.get(i);
					planViaje.setNomRegistrador(planViajeDetalle.getNomRegistrador());
					planViaje.setNomUuOoCom(planViajeDetalle.getNomUuOoCom());
					planViaje.setFecSalidaFormateada(planViajeDetalle.getFecSalidaFormateada());
					planViaje.setFecRetornoFormateada(planViajeDetalle.getFecRetornoFormateada());
					planViaje.setItinerario(planViajeDetalle.getItinerario());
					planViaje.setCanalAtencion(planViajeDetalle.getCanalAtencion());
					planViaje.setNumDias(planViajeDetalle.getNumDias());
					planViaje.setNumeroHoras(planViajeDetalle.getNumeroHoras());
					planViaje.setMotivoComis(planViajeDetalle.getMotivoComis());
					planViaje.setImpTotalOtorgadoFormateado(planViajeDetalle.getImpTotalOtorgadoFormateado());
					planViaje.setImpAsigPasajesFormateado(planViajeDetalle.getImpAsigPasajesFormateado());
					planViaje.setImpOtrosFormateado(planViajeDetalle.getImpOtrosFormateado());
					planViaje.setImpGastoAlojFormateado(planViajeDetalle.getImpGastoAlojFormateado());
					planViaje.setImpGastoAlimFormateado(planViajeDetalle.getImpGastoAlimFormateado());
					planViaje.setImpGastoMovLocalFormateado(planViajeDetalle.getImpGastoMovLocalFormateado());
					planViaje.setImpGastoTrasladoFormateado(planViajeDetalle.getImpGastoTrasladoFormateado());
					planViaje.setImpGastoPasajesFormateado(planViajeDetalle.getImpGastoPasajesFormateado());
					planViaje.setImpGastoFormateado(planViajeDetalle.getImpGastoFormateado());
					planViaje.setImpDevueltoFormateado(planViajeDetalle.getImpDevueltoFormateado());
					planViaje.setImpDevolMenorFormateado(planViajeDetalle.getImpDevolMenorFormateado());
					planViaje.setNumReciboProv(planViajeDetalle.getNumReciboProv());
					planViaje.setFecPagoCajaChFormateado(planViajeDetalle.getFecPagoCajaChFormateado());
					planViajeCompletoList.add(planViaje);
				}
			}
		}
		return planViajeCompletoList;
	}
	
	/**
	 * Metodo que permite obtener el listado de planes de viaje que se van a mostrar en la bandeja de consulta de rendicion.
	 * @author Jorge Ponce.
	 * @param  codigoDependencia :codigo de dependencia.
	 * @param  codPlanilla :codigo de planilla.
	 * @param  codTrabajador :codigo del colaborador.
	 * @param  codEstadoRend :codigo de estado de la rendicion.
	 * @param  indicadorCanalAtencion :indicador canal de atencion.
	 * @param  fechaDesde :fecha desde.
	 * @param  fechaHasta :fecha hasta.
	 * @return Objeto PlanViajeBean.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	public ArrayList<PlanViajeBean> obtenerPlanViajeToBandejaConsultaRendicion(String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoRend, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta) throws Exception {
		
		ArrayList<PlanViajeBean> planViajeList = planViajeDAO.obtenerPlanViajeToBandejaConsultaRendicion(codigoDependencia, codPlanilla, codTrabajador, ViaticoConstantes.ESTADO_VIATICO_PAGADO, codEstadoRend, indicadorCanalAtencion, fechaDesde, fechaHasta);
		//ArrayList<PlanViajeBean> planViajeList = planViajeDAO.obtenerPlanViajeToBandejaConsultaRendicion(codigoDependencia, codPlanilla, codTrabajador, null, codEstadoRend, indicadorCanalAtencion, fechaDesde, fechaHasta);
		ArrayList<PlanViajeBean> planViajeListAux = null;
		if (planViajeList != null && !planViajeList.isEmpty()) {
			planViajeListAux = new ArrayList<PlanViajeBean>();
			for (PlanViajeBean planViajeBean : planViajeList) {
				planViajeBean.setFechaRegistroRendicionFormateda(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFechaRegistroRendicion()));
				planViajeBean.setFecMaxRendFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecMaxRend()));
				planViajeBean.setNomTipoViatico(obtenerDescripcionTipoDestino(planViajeBean.getTipoDestino()));
				planViajeBean.setMtoTotalFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getMtoTotal(), 2));
				planViajeBean.setNomEstRend(FormatoUtil.getUppperCaseText(planViajeBean.getNomEstRend()));
				planViajeBean.setObsRendicion(FormatoUtil.getUppperCaseText(planViajeBean.getObsRendicion()));
				planViajeBean.setMotivoComis(FormatoUtil.getUppperCaseText(planViajeBean.getMotivoComis()));
				planViajeBean.setFecSalidaFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecSalida()));
				planViajeBean.setFecRetornoFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecRetorno()));
				planViajeBean.setHoraSalidaFormateada(FechaUtil.formatDateToHourHHMM(planViajeBean.getFecSalida()));
				planViajeBean.setHoraRetornoFormateada(FechaUtil.formatDateToHourHHMM(planViajeBean.getFecRetorno()));
				
				//JMCR-ME Fecha Reprogramacion
				try {
					planViajeBean.setFecReprogFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecReprog()));
				}
				catch (Exception e) {
					planViajeBean.setFecReprogFormateada("");
				}
				//JMCR-ME Fecha Reprogramacion
				
				planViajeListAux.add(planViajeBean);
			}
		}
		return planViajeListAux;
	}
	
	/**
	 * Metodo que permite obtener el listado de detalle de los planes de viaje que se muestran la bandeja de consulta de rendicion.
	 * @author Jorge Ponce.
	 * @param  codigoDependencia :codigo de dependencia.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @param  codPlanilla :codigo de planilla.
	 * @param  codTrabajador :codigo del colaborador.
	 * @param  codEstadoRend :codigo de estado de la rendicion.
	 * @param  indicadorCanalAtencion :indicador canal de atencion.
	 * @param  fechaDesde :fecha desde.
	 * @param  fechaHasta :fecha hasta.
	 * @return Objeto PlanViajeBean.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	public ArrayList<PlanViajeBean> obtenerPlanViajeDetalleToBandejaConsultaRendicion(String codPlanViaje, String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoRend, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta) throws Exception {
		
		ArrayList<PlanViajeBean> planViajeList = planViajeDAO.obtenerPlanViajeDetalleToBandejaConsultaRendicion(codPlanViaje, codigoDependencia, codPlanilla, codTrabajador, ViaticoConstantes.ESTADO_VIATICO_PAGADO, codEstadoRend, indicadorCanalAtencion, fechaDesde, fechaHasta);
		//ArrayList<PlanViajeBean> planViajeList = planViajeDAO.obtenerPlanViajeDetalleToBandejaConsultaRendicion(codPlanViaje, codigoDependencia, codPlanilla, codTrabajador, null, codEstadoRend, indicadorCanalAtencion, fechaDesde, fechaHasta);
		ArrayList<PlanViajeBean> planViajeListAux = null;
		if (planViajeList != null && !planViajeList.isEmpty()) {
			planViajeListAux = new ArrayList<PlanViajeBean>();
			for (PlanViajeBean planViajeBean : planViajeList) {
				BigDecimal montoAsignadoPasajes = BigDecimal.ZERO;
				BigDecimal montoOtros = BigDecimal.ZERO;
				BigDecimal montoOtorgadoTotal = BigDecimal.ZERO;
				PlanViajeBean planViajeBeanAux = new PlanViajeBean();
				planViajeBeanAux.setCodPlanViaje(planViajeBean.getCodPlanViaje());
				planViajeBeanAux.setCodPlanilla(planViajeBean.getCodPlanilla());
				planViajeBeanAux.setNomColaborador(FormatoUtil.getUppperCaseText(planViajeBean.getNomColaborador()));
				planViajeBeanAux.setNomUuOoCom(FormatoUtil.getUppperCaseText(planViajeBean.getNomUuOoCom()));
				planViajeBeanAux.setFecSalidaFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecSalida()));
				planViajeBeanAux.setFecRetornoFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecRetorno()));
				planViajeBeanAux.setItinerario(planViajeBean.getItinerario());
				planViajeBeanAux.setCanalAtencion(FormatoUtil.getUppperCaseText(planViajeBean.getCanalAtencion()));
				planViajeBeanAux.setNumDias(planViajeBean.getNumDias());
				planViajeBeanAux.setNumeroHoras(planViajeBean.getNumeroHoras());
				planViajeBeanAux.setMotivoComis(FormatoUtil.getUppperCaseText(planViajeBean.getMotivoComis()));
				planViajeBeanAux.setImpAsigPasajesFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getImpAsigPasajes(), 2));
				planViajeBeanAux.setImpTotalOtorgadoFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getImpTotalOtorgado(), 2));
				if (planViajeBean.getImpAsigPasajes() != null) {
					montoAsignadoPasajes = new BigDecimal(planViajeBean.getImpAsigPasajes());
				}
				if (planViajeBean.getImpTotalOtorgado() != null) {
					montoOtorgadoTotal = new BigDecimal(planViajeBean.getImpTotalOtorgado());
				}
				if(planViajeBean.getImpOtros() != null){
					montoOtros = new BigDecimal(planViajeBean.getImpOtros()).subtract(montoAsignadoPasajes) ;
				}
				
				planViajeBeanAux.setImpOtrosFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), montoOtros, 2));
				planViajeBeanAux.setNomRegistrador(FormatoUtil.getUppperCaseText(planViajeBean.getNomRegistrador()));
				planViajeBeanAux.setImpGastoAlojFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getImpGastoAloj(), 2));
				planViajeBeanAux.setImpGastoAlimFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getImpGastoAlim(), 2));
				planViajeBeanAux.setImpGastoMovLocalFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getImpGastoMovLocal(), 2));
				planViajeBeanAux.setImpGastoTrasladoFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getImpGastoTraslado(), 2));
				planViajeBeanAux.setImpGastoPasajesFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getImpGastoPasajes(), 2));
				planViajeBeanAux.setImpGastoTUUAFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getImpGastoTUUA(), 2));
				planViajeBeanAux.setImpGastoFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), obtenerImporteGastoTotal(planViajeBean.getImpGastoAloj(), planViajeBean.getImpGastoAlim(), planViajeBean.getImpGastoMovLocal(), planViajeBean.getImpGastoTraslado(), planViajeBean.getImpGastoPasajes()), 2));
				planViajeBeanAux.setImpGastoFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getImpGasto(), 2));
				planViajeBeanAux.setImpDevueltoFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getImpDevuelto(), 2));
				planViajeBeanAux.setImpDevolMenorFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getImpDevolMenor(), 2));
				planViajeBeanAux.setNumReciboProv(FormatoUtil.getUppperCaseText(planViajeBean.getNumReciboProv()));
				planViajeBeanAux.setFecPagoCajaChFormateado(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecPagoCajaCh()));
				planViajeListAux.add(planViajeBeanAux);
			}
		}
		return planViajeListAux;
	}
	
	/**
	 * Metodo que permite obtener el gasto total, para el detalle del gasto.
	 * @author Jorge Ponce.
	 * @param  impGastoAloj :gasto de alojamiento.
	 * @param  impGastoAlim :gasto de alimentacion.
	 * @param  impGastoMovLocal :gasto de movilidad.
	 * @param  impGastoTraslado :gasto de traslado.
	 * @param  impGastoPasajes :gasto de pasajes.
	 * @return Gasto total.
	 * @see    String
	 * @throws Exception
	 */
	private String obtenerImporteGastoTotal(String impGastoAloj, String impGastoAlim, String impGastoMovLocal, String impGastoTraslado, String impGastoPasajes) throws Exception {
		
		BigDecimal importeGastoTotal = BigDecimal.ZERO;
		String importeGastoTotalString = null;
		boolean flagGastoNoNulo = false;
		
		if (impGastoAloj != null) {
			flagGastoNoNulo = true;
			importeGastoTotal = importeGastoTotal.add(new BigDecimal(impGastoAloj));
		}
		
		if (impGastoAlim != null) {
			flagGastoNoNulo = true;
			importeGastoTotal = importeGastoTotal.add(new BigDecimal(impGastoAlim));
		}
		
		if (impGastoMovLocal != null) {
			flagGastoNoNulo = true;
			importeGastoTotal = importeGastoTotal.add(new BigDecimal(impGastoMovLocal));
		}
		
		if (impGastoTraslado != null) {
			flagGastoNoNulo = true;
			importeGastoTotal = importeGastoTotal.add(new BigDecimal(impGastoTraslado));
		}
		
		if (impGastoPasajes != null) {
			flagGastoNoNulo = true;
			importeGastoTotal = importeGastoTotal.add(new BigDecimal(impGastoPasajes));
		}
		
		if (flagGastoNoNulo) {
			importeGastoTotalString = importeGastoTotal.toString();
		}
		
		return importeGastoTotalString;
	}
	
	/**
	 * Metodo que permite obtener la descripcion del tipo de destino.
	 * @author Jorge Ponce.
	 * @param  tipoDestino :codigo tipo destino.
	 * @return Objeto PlanViajeBean.
	 * @see    String
	 * @throws Exception
	 */
	private String obtenerDescripcionTipoDestino(String tipoDestino) {
		
		String descripcionTipoDestino = FormatoUtil.getUppperCaseText(tipoDestino);
		if (RendicionConstantes.TIPO_DESTINO_NACIONAL.equals(tipoDestino)) {
			descripcionTipoDestino = RendicionConstantes.DESCRIPCION_TIPO_DESTINO_NACIONAL;
		}
		else if (RendicionConstantes.TIPO_DESTINO_INTERNACIONAL.equals(tipoDestino)) {
			descripcionTipoDestino = RendicionConstantes.DESCRIPCION_TIPO_DESTINO_INTERNACIONAL;
		}
		
		return descripcionTipoDestino;
	}
	
	/**
	 * Metodo que permite obtener los datos para realizar una rendicion del plan viaje.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @return Objeto PlanViajeBean.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	public PlanViajeBean obtenerPlanViaje(String codPlanViaje) throws Exception {
		return planViajeDAO.obtenerPlanViajeToRendicion(codPlanViaje);
	}
	
	/**
	 * Metodo que permite obtener el listado de plan viaje concepto asociados a una solicitud.
	 * @author Jorge Ponce.
	 * @param  planViajeID :codigo plan viaje.
	 * @param  simboloMoneda :simbolo de la moneda.
	 * @return Listado de plan de viaje concepto.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	public ArrayList<PlanViajeConceptoBean> obtenerPlanViajeConcepto(String planViajeID, String simboloMoneda) throws Exception {
		
		ArrayList<PlanViajeConceptoBean> planViajeConceptoList = planViajeConceptoDAO.obtenerPlanViajeConceptoToRendicion(planViajeID);
		ArrayList<PlanViajeConceptoBean> planViajeConceptoAuxList = null;
		if (planViajeConceptoList != null && !planViajeConceptoList.isEmpty()) {
			planViajeConceptoAuxList = new ArrayList<PlanViajeConceptoBean>();
			BigDecimal montoEntregadoTotal = BigDecimal.ZERO;
			BigDecimal montoRendidoTotal = BigDecimal.ZERO;
			BigDecimal montoDevueltoVoucherRICTotal = BigDecimal.ZERO;
			BigDecimal montoDevolverTotal = BigDecimal.ZERO;
			String flagMontoDevolverNegativoTotal = RendicionConstantes.CERO;
			int resultadoMontoDevolverTotal;
			for (PlanViajeConceptoBean planViajeConceptoBean : planViajeConceptoList) {
				BigDecimal montoEntregado = BigDecimal.ZERO;
				BigDecimal montoRendido = BigDecimal.ZERO;
				BigDecimal montoDevueltoVoucherRIC = BigDecimal.ZERO;
				BigDecimal montoDevolver = BigDecimal.ZERO;
				String flagMontoDevolverNegativo = RendicionConstantes.CERO;
				int resultadoMontoDevolver;
				if (planViajeConceptoBean.getMonto() != null) {
					planViajeConceptoBean.setMontoFormateado(NumeroUtil.formatearMonto(null, planViajeConceptoBean.getMonto(), 2));
					montoEntregado = montoEntregado.add(new BigDecimal(planViajeConceptoBean.getMonto()));
				}
				
				if (planViajeConceptoBean.getMontoRendido() != null) {
					planViajeConceptoBean.setMontoRendidoFormateado(NumeroUtil.formatearMonto(null, planViajeConceptoBean.getMontoRendido(), 2));
					montoRendido = montoRendido.add(new BigDecimal(planViajeConceptoBean.getMontoRendido()));
				}
				
				if (planViajeConceptoBean.getMontoDevuelto() != null) {
					montoDevueltoVoucherRIC = montoDevueltoVoucherRIC.add(new BigDecimal(planViajeConceptoBean.getMontoDevuelto()));
				}
				
				if (planViajeConceptoBean.getMontoRic() != null) {
					montoDevueltoVoucherRIC = montoDevueltoVoucherRIC.add(new BigDecimal(planViajeConceptoBean.getMontoRic()));
				}
				/*
				if (RendicionConstantes.CODIGO_ASIGNACION_VIATICO_NACIONAL.equals(planViajeConceptoBean.getConceptoID()) || RendicionConstantes.CODIGO_ASIGNACION_VIATICO_INTERNACIONAL.equals(planViajeConceptoBean.getConceptoID())) {
					planViajeConceptoBean.setMontoDevueltoVoucherRICFormateado(NumeroUtil.formatearMonedaMontoToDecimal(null, 2, montoDevueltoVoucherRIC));
				}
				*/
				montoDevolver = montoDevolver.add(montoEntregado).subtract(montoRendido).subtract(montoDevueltoVoucherRIC);
				resultadoMontoDevolver = montoDevolver.compareTo(BigDecimal.ZERO);
				if (resultadoMontoDevolver == -1) {
					flagMontoDevolverNegativo = RendicionConstantes.UNO;
				}
				montoEntregadoTotal = montoEntregadoTotal.add(montoEntregado);
				montoRendidoTotal = montoRendidoTotal.add(montoRendido);
				montoDevueltoVoucherRICTotal = montoDevueltoVoucherRICTotal.add(montoDevueltoVoucherRIC);
				montoDevolverTotal = montoDevolverTotal.add(montoDevolver);
				planViajeConceptoBean.setMontoDevueltoVoucherRICFormateado(NumeroUtil.formatearMonto(null, montoDevueltoVoucherRIC, 2));
				planViajeConceptoBean.setMontoDevolver(montoDevolver);
				planViajeConceptoBean.setMontoDevolverFormateado(NumeroUtil.formatearMonto(null, montoDevolver, 2));
				planViajeConceptoBean.setFlagMontoDevolverNegativo(flagMontoDevolverNegativo);
				planViajeConceptoBean.setFlagPlanViajeConceptoTotal(RendicionConstantes.CERO);
				planViajeConceptoAuxList.add(planViajeConceptoBean);
			}
			PlanViajeConceptoBean planViajeConceptoBean = new PlanViajeConceptoBean();
			planViajeConceptoBean.setDescripcionConcepto(RendicionConstantes.TOTAL);
			planViajeConceptoBean.setMontoFormateado(NumeroUtil.formatearMonto(simboloMoneda, montoEntregadoTotal, 2));
			planViajeConceptoBean.setMontoRendidoFormateado(NumeroUtil.formatearMonto(simboloMoneda, montoRendidoTotal, 2));
			planViajeConceptoBean.setMontoDevueltoVoucherRICFormateado(NumeroUtil.formatearMonto(simboloMoneda, montoDevueltoVoucherRICTotal, 2));
			planViajeConceptoBean.setMontoDevolver(montoDevolverTotal);
			planViajeConceptoBean.setMontoDevolverFormateado(NumeroUtil.formatearMonto(simboloMoneda, montoDevolverTotal, 2));
			resultadoMontoDevolverTotal = montoDevolverTotal.compareTo(BigDecimal.ZERO);
			if (resultadoMontoDevolverTotal == -1) {
				flagMontoDevolverNegativoTotal = RendicionConstantes.UNO;
			}
			planViajeConceptoBean.setFlagMontoDevolverNegativo(flagMontoDevolverNegativoTotal);
			planViajeConceptoBean.setFlagPlanViajeConceptoTotal(RendicionConstantes.UNO);
			planViajeConceptoAuxList.add(planViajeConceptoBean);
		}
		return planViajeConceptoAuxList;
	}
	
	/**
	 * Metodo que permite obtener el listado de papeletas de deposito asociados a un plan viaje.
	 * @author Jorge Ponce.
	 * @param  codigoPlanViaje :codigo plan viaje.
	 * @return Listado de papeletas deposito.
	 * @see    PapeletaDepositoBean
	 * @throws Exception
	 */
	public ArrayList<PapeletaDepositoBean> obtenerPapeletasDeposito(String codigoPlanViaje) throws Exception {
		ArrayList<PapeletaDepositoBean> papeletaDepositoList = papeletaDepositoDAO.obtenerPapeletasDeposito(codigoPlanViaje);
		ArrayList<PapeletaDepositoBean> papeletaDepositoAuxList = null;
		if (papeletaDepositoList != null && !papeletaDepositoList.isEmpty()) {
			papeletaDepositoAuxList = new ArrayList<PapeletaDepositoBean>();
			String simboloMoneda = RendicionConstantes.CADENA_VACIA;
			BigDecimal montoTotal = BigDecimal.ZERO;
			String numeroSerieFormulario;
			String numeroComprobanteIngreso;
			for (PapeletaDepositoBean papeletaDepositoBean : papeletaDepositoList) {
				simboloMoneda = papeletaDepositoBean.getSimboloMoneda();
				papeletaDepositoBean.setFechaVoucherFormateada(FechaUtil.formatDateToDateDDMMYYYY(papeletaDepositoBean.getFechaVoucher()));
				if (papeletaDepositoBean.getValorTipoCambio() != null) {
					papeletaDepositoBean.setValorTipoCambioFormateado(NumeroUtil.formatearMontoToDecimal(2, papeletaDepositoBean.getValorTipoCambio()));
				}
				else {
					papeletaDepositoBean.setValorTipoCambioFormateado(RendicionConstantes.CADENA_VACIA);
				}
				if (papeletaDepositoBean.getMontoDeposito() != null) {
					papeletaDepositoBean.setMontoDepositoFormateado(NumeroUtil.formatearMonto(simboloMoneda, papeletaDepositoBean.getMontoDeposito(), 2));
					montoTotal = montoTotal.add(papeletaDepositoBean.getMontoDeposito());
				}
				numeroSerieFormulario = papeletaDepositoBean.getNumeroSerieFormulario();
				numeroComprobanteIngreso = papeletaDepositoBean.getNumeroComprobanteIngreso();
				if (FormatoUtil.validarStringDifferentNullAndEmpty(numeroSerieFormulario) && FormatoUtil.validarStringDifferentNullAndEmpty(numeroComprobanteIngreso)) {
					papeletaDepositoBean.setReciboIngresoCajaAsosiado(numeroSerieFormulario + RendicionConstantes.GUION + numeroComprobanteIngreso);
					papeletaDepositoBean.setFlagAsociadoRIC(RendicionConstantes.UNO);
				}
				else {
					papeletaDepositoBean.setReciboIngresoCajaAsosiado(RendicionConstantes.CADENA_VACIA);
					papeletaDepositoBean.setFlagAsociadoRIC(RendicionConstantes.CERO);
				}
				papeletaDepositoBean.setFlagPapeletaTotal(RendicionConstantes.CERO);
				papeletaDepositoAuxList.add(papeletaDepositoBean);
			}
			PapeletaDepositoBean papeletaDepositoBean = new PapeletaDepositoBean();
			papeletaDepositoBean.setNombreBanco(RendicionConstantes.CADENA_VACIA);
			papeletaDepositoBean.setCodigoCuentaBanco(RendicionConstantes.CADENA_VACIA);
			papeletaDepositoBean.setFechaVoucherFormateada(RendicionConstantes.CADENA_VACIA);
			papeletaDepositoBean.setNumeroOperacion(RendicionConstantes.CADENA_VACIA);
			papeletaDepositoBean.setSimboloMoneda(simboloMoneda);
			papeletaDepositoBean.setValorTipoCambioFormateado(RendicionConstantes.TOTAL);
			papeletaDepositoBean.setMontoDeposito(montoTotal);
			papeletaDepositoBean.setMontoDepositoFormateado(NumeroUtil.formatearMonto(simboloMoneda, montoTotal, 2));
			papeletaDepositoBean.setReciboIngresoCajaAsosiado(RendicionConstantes.CADENA_VACIA);
			papeletaDepositoBean.setFlagAsociadoRIC(RendicionConstantes.CERO);
			papeletaDepositoBean.setFlagPapeletaTotal(RendicionConstantes.UNO);
			papeletaDepositoAuxList.add(papeletaDepositoBean);
		}
		return papeletaDepositoAuxList;
	}
	
	/**
	 * Metodo que permite obtener el listado de recibos de ingreso caja (RICs) asociados a un plan viaje.
	 * @author Jorge Ponce.
	 * @param  numeroRendicion :numero de rendicion/codigo plan viaje.
	 * @return Listado de recibos de ingreso caja.
	 * @see    ComprobanteIngresoBean
	 * @throws Exception
	 */
	public ArrayList<ComprobanteIngresoBean> obtenerRecibosIngresoCaja(String numeroRendicion) throws Exception {
		ArrayList<ComprobanteIngresoBean> comprobanteIngresoList = comprobanteIngresoDAO.obtenerRecibosIngresoCaja(numeroRendicion);
		ArrayList<ComprobanteIngresoBean> comprobanteIngresoAuxList = null;
		if (comprobanteIngresoList != null && !comprobanteIngresoList.isEmpty()) {
			comprobanteIngresoAuxList = new ArrayList<ComprobanteIngresoBean>();
			BigDecimal montoTotal = BigDecimal.ZERO;
			String moneda = RendicionConstantes.CADENA_VACIA;
			for (ComprobanteIngresoBean comprobanteIngresoBean : comprobanteIngresoList) {
				moneda = comprobanteIngresoBean.getTipoMoneda();
				comprobanteIngresoBean.setMoneda(moneda);
				comprobanteIngresoBean.setFechaGeneracionFormateada(FechaUtil.formatDateToDateDDMMYYYY(comprobanteIngresoBean.getFechaGeneracion()));
				if (comprobanteIngresoBean.getMonto() != null) {
					montoTotal = montoTotal.add(comprobanteIngresoBean.getMonto());
					comprobanteIngresoBean.setMontoFormateado(NumeroUtil.formatearMonto(moneda, comprobanteIngresoBean.getMonto(), 2));
				}
				comprobanteIngresoBean.setFlagComprobanteTotal(RendicionConstantes.CERO);
				comprobanteIngresoAuxList.add(comprobanteIngresoBean);
			}
			ComprobanteIngresoBean comprobanteIngresoBean = new ComprobanteIngresoBean();
			comprobanteIngresoBean.setNumeroRendicion(numeroRendicion);
			comprobanteIngresoBean.setNumeroDocumento(RendicionConstantes.CADENA_VACIA);
			comprobanteIngresoBean.setFechaGeneracionFormateada(RendicionConstantes.TOTAL);
			comprobanteIngresoBean.setMoneda(moneda);
			comprobanteIngresoBean.setMonto(montoTotal);
			comprobanteIngresoBean.setMontoFormateado(NumeroUtil.formatearMonto(moneda, montoTotal, 2));
			comprobanteIngresoBean.setClasificador(RendicionConstantes.CADENA_VACIA);
			comprobanteIngresoBean.setFlagComprobanteTotal(RendicionConstantes.UNO);
			comprobanteIngresoAuxList.add(comprobanteIngresoBean);
		}
		return comprobanteIngresoAuxList;
	}
	
	/**
	 * Metodo que permite obtener la moneda de acuerdo al tipo de cambio.
	 * @author Jorge Ponce.
	 * @param  tipoCambio :tipo de cambio.
	 * @return Moneda.
	 * @see    String
	 * @throws Exception
	 */
	private String obtenerMoneda(String tipoCambio) {
		String moneda =  RendicionConstantes.MONEDA_DOLARES;
		if (RendicionConstantes.TIPO_CAMBIO_SOLES.equals(tipoCambio)) {
			moneda = RendicionConstantes.MONEDA_SOLES;
		}
		return moneda;
	}
	
	/**
	 * Metodo que permite obtener el monto a devolver en una rendicion.
	 * @author Jorge Ponce.
	 * @param  montoRendirTotal :monto total que se debe rendir.
	 * @param  montoComprobanteTotal :monto total de los comprobantes.
	 * @param  montoDepositoTotal :monto total de las papeletas deposito.
	 * @param  montoRICTotal :monto total de los recibos ingreso caja.
	 * @return Saldo a devolver.
	 * @see    BigDecimal
	 */
	public BigDecimal obtenerMontoDevolver(BigDecimal montoRendirTotal, BigDecimal montoComprobanteTotal, BigDecimal montoDepositoTotal, BigDecimal montoRICTotal) {
		
		BigDecimal montoDevolver = BigDecimal.ZERO;
		
		if (montoRendirTotal != null) {
			montoDevolver = montoDevolver.add(montoRendirTotal);
		}
		
		if (montoComprobanteTotal != null) {
			montoDevolver = montoDevolver.subtract(montoComprobanteTotal);
		}
		
		if (montoDepositoTotal != null) {
			montoDevolver = montoDevolver.subtract(montoDepositoTotal);
		}
		
		if (montoRICTotal != null) {
			montoDevolver = montoDevolver.subtract(montoRICTotal);
		}
		
		return montoDevolver;
	}
	
	/**
	 * Metodo que permite obtener el flag para habilitar el boton cerrar rendicion.
	 * @author Jorge Ponce.
	 * @param mtoTotal: monto asignado.
	 * @param montoDevuelto: monto devuelto por comprobantes.
	 * @param montoDevol: monto devuelto por voucher y/o rics.
	 * @param indicadorMenorGasto: indicador de menor gasto.
	 * @return Flag habilitar cerrar rendicion.
	 * @see String
	 */
	public String obtenerFlagHabilitarCerrarRendicion(String mtoTotal, Double montoDevuelto, Double montoDevol, String indicadorMenorGasto) {
		
		BigDecimal montoAsignadoTotal = BigDecimal.ZERO;
		BigDecimal montoDevueltoComprobanteTotal = BigDecimal.ZERO;
		BigDecimal montoDevueltoVoucherRICTotal = BigDecimal.ZERO;
		
		if (mtoTotal != null && !RendicionConstantes.CADENA_VACIA.equals(mtoTotal)) {
			montoAsignadoTotal = new BigDecimal(mtoTotal.toString());
		}
		
		if (montoDevuelto != null) {
			montoDevueltoComprobanteTotal = new BigDecimal(montoDevuelto.toString());
		}

		if (montoDevol != null) {
			montoDevueltoVoucherRICTotal = new BigDecimal(montoDevol.toString());
		}
		
		return obtenerFlagHabilitarCerrarRendicion(montoAsignadoTotal, montoDevueltoComprobanteTotal, montoDevueltoVoucherRICTotal, indicadorMenorGasto);
	}
	
	/**
	 * Metodo que permite obtener el flag para habilitar el boton cerrar rendicion.
	 * @author Jorge Ponce.
	 * @param montoAsignadoTotal: monto asignado.
	 * @param montoDevueltoComprobanteTotal: monto devuelto por comprobantes.
	 * @param montoDevueltoVoucherRICTotal: monto devuelto por voucher y/o rics.
	 * @param indicadorMenorGasto: indicador de menor gasto.
	 * @return Flag habilitar cerrar rendicion.
	 * @see String
	 */
	public String obtenerFlagHabilitarCerrarRendicion(BigDecimal montoAsignadoTotal, BigDecimal montoDevueltoComprobanteTotal, BigDecimal montoDevueltoVoucherRICTotal, String indicadorMenorGasto) {
		log.info("obtenerFlagHabilitarCerrarRendicion..., montoAsignadoTotal:"+montoAsignadoTotal+", montoDevueltoComprobanteTotal:"+
	montoDevueltoComprobanteTotal+", montoDevueltoVoucherRICTotal:"+montoDevueltoVoucherRICTotal+", indicadorMenorGasto:"+indicadorMenorGasto);
		String flagHabilitarCerrarRendicion = RendicionConstantes.CERO;
		if(RendicionConstantes.INDICADOR_MEN_GAST_SI.equals(indicadorMenorGasto)) {
			flagHabilitarCerrarRendicion = RendicionConstantes.UNO;
		}
		else {
			BigDecimal montoDevueltoTotal = montoDevueltoComprobanteTotal.add(montoDevueltoVoucherRICTotal);
			log.info("montoDevueltoTotal:"+montoDevueltoTotal);
			int resultado = montoDevueltoTotal.compareTo(montoAsignadoTotal);
			log.info("resultado de la comparación:"+resultado);
			if (resultado == 0 || resultado == 1) {
				flagHabilitarCerrarRendicion = RendicionConstantes.UNO;
			}
		}
		
		log.info("1. devolviento --> flagHabilitarCerrarRendicion:"+flagHabilitarCerrarRendicion);
		
		return flagHabilitarCerrarRendicion;
	}
	
	/**
	 * Metodo que permite obtener la papeleta segun el codigo de boleta
	 * @author Samuel Dionisio.
	 * @param  papeletaDepositoBean :PapeletaDepositoBean.
	 * @return Bean papeleta.
	 * @see    PapeletaDepositoBean
	 * @throws Exception
	 */
	public PapeletaDepositoBean obtenerPapeletaDeposito(String codigoBoletaDeposito) throws Exception {
		PapeletaDepositoBean papeletaDeposito = papeletaDepositoDAO.obtenerPapeletaDeposito(codigoBoletaDeposito);
		return papeletaDeposito;
	}
	
	/**
	 * Metodo que permite obtener los datos necesarios para el reporte rendicion.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @return Rendicion DTO.
	 * @see    RendicionDTO
	 */
	public RendicionDTO obtenerDatosReporteRendicion(String codPlanViaje) throws Exception {
		
		RendicionDTO rendicionDTO = new RendicionDTO();
		PlanViajeBean planViaje = obtenerPlanViaje(codPlanViaje);
		if (planViaje != null) {
			String simboloMoneda = planViaje.getMoneda();
			BigDecimal montoRendirTotal = BigDecimal.ZERO;
			BigDecimal montoComprobanteTotal = BigDecimal.ZERO;
			BigDecimal montoDepositoTotal = BigDecimal.ZERO;
			BigDecimal montoRICTotal = BigDecimal.ZERO;
			BigDecimal montoDevueltoTotal = BigDecimal.ZERO;
			BigDecimal montoNoUtilizadoTotal = BigDecimal.ZERO;
			BigDecimal montoDiferenciaTotal = BigDecimal.ZERO;
			
			if (planViaje.getMtoTotal() != null) {
				montoRendirTotal = new BigDecimal(planViaje.getMtoTotal());
			}
			
			ArrayList<PlanViajeRendicionBean> planViajeRendicionList = viaticoConsultaService.obtenerPlanViajeRendicionToRegistroRendicion(codPlanViaje, simboloMoneda);
			if (planViajeRendicionList != null && !planViajeRendicionList.isEmpty()) {
				int sizeList = planViajeRendicionList.size();
				montoComprobanteTotal = new BigDecimal(planViajeRendicionList.get(sizeList - 1).getMtoReconocido());
				planViajeRendicionList.remove(sizeList - 1);
				rendicionDTO.setPlanViajeRendicionList(planViajeRendicionList);
			}
			
			ArrayList<PapeletaDepositoBean> papeletaDepositoList = obtenerPapeletasDeposito(codPlanViaje);
			if (papeletaDepositoList != null && !papeletaDepositoList.isEmpty()) {
				int sizeList = papeletaDepositoList.size();
				montoDepositoTotal = papeletaDepositoList.get(sizeList - 1).getMontoDeposito();
				papeletaDepositoList.remove(sizeList - 1);
				rendicionDTO.setPapeletaDepositoList(papeletaDepositoList);
			}
			
			ArrayList<ComprobanteIngresoBean> comprobanteIngresoList = obtenerRecibosIngresoCaja(codPlanViaje);
			if (comprobanteIngresoList != null && !comprobanteIngresoList.isEmpty()) {
				int sizeList = comprobanteIngresoList.size();
				montoRICTotal = comprobanteIngresoList.get(sizeList - 1).getMonto();
				comprobanteIngresoList.remove(sizeList - 1);
				rendicionDTO.setComprobanteIngresoList(comprobanteIngresoList);
			}
			montoDevueltoTotal = montoDevueltoTotal.add(montoDepositoTotal).add(montoRICTotal);
			montoNoUtilizadoTotal = montoNoUtilizadoTotal.add(montoRendirTotal).subtract(montoComprobanteTotal);
			montoDiferenciaTotal = montoDiferenciaTotal.add(montoNoUtilizadoTotal).subtract(montoDevueltoTotal);
			rendicionDTO.setMontoRendirTotal(NumeroUtil.formatearMonto(simboloMoneda, montoRendirTotal, 2));
			rendicionDTO.setMontoComprobanteTotal(NumeroUtil.formatearMonto(simboloMoneda, montoComprobanteTotal, 2));
			rendicionDTO.setMontoDepositoTotal(NumeroUtil.formatearMonto(simboloMoneda, montoDepositoTotal, 2));
			rendicionDTO.setMontoRICTotal(NumeroUtil.formatearMonto(simboloMoneda,montoRICTotal, 2));
			rendicionDTO.setMontoDevueltoTotal(NumeroUtil.formatearMonto(simboloMoneda, montoDevueltoTotal, 2));
			rendicionDTO.setMontoNoUtilizadoTotal(NumeroUtil.formatearMonto(simboloMoneda, montoNoUtilizadoTotal, 2));
			rendicionDTO.setMontoDiferenciaTotal(NumeroUtil.formatearMonto(simboloMoneda, montoDiferenciaTotal, 2));
			rendicionDTO.setImporteComprobanteTotal(NumeroUtil.formatearMonto(ViaticoConstantes.CADENA_VACIA, montoComprobanteTotal, 2));
			rendicionDTO.setFechaActual(FechaUtil.formatDateToDateDDMMYYYY(new Date()));
			rendicionDTO.setHoraActual(FechaUtil.formatDateToHourHHMM(new Date()));
			
			String codigoColaborador = planViaje.getCodTrabajador();
			if (!StringUtils.isEmpty(codigoColaborador)) {
				MaestroPersonalBean colaborador = registroPersonalService.obtenerPersonaxCodigo(codigoColaborador);
				rendicionDTO.setColaborador(MaestroPersonalUtil.parseViatico(colaborador));
			}
			
			String codigoRegistrador = planViaje.getCodigoRegistrador();
			if (!StringUtils.isEmpty(codigoRegistrador)) {
				MaestroPersonalBean registrador = registroPersonalService.obtenerPersonaxCodigo(codigoRegistrador);
				rendicionDTO.setRegistrador(MaestroPersonalUtil.parseViatico(registrador));
			}
			
			String codigoNivel = rendicionDTO.getColaborador().getCodigoNivel();
			if (!StringUtils.isEmpty(codigoNivel)) {
				NivelBean nivel = nivelDAO.buscarNivelViatico(codigoNivel);
				rendicionDTO.setNivel(nivel);
			}			
			
			String codigoNivelRegistrador = rendicionDTO.getRegistrador().getCodigoNivel();
			if (StringUtils.isNotBlank(codigoNivelRegistrador)) {
				NivelBean nivel = nivelDAO.buscarNivelViatico(codigoNivelRegistrador);
				rendicionDTO.setNivelRegistrador(nivel);
			}
			
			String numeroRegistroCab = planViaje.getNumeroRegiCab();			
			if (!StringUtils.isEmpty(numeroRegistroCab)) {
				CabeceraMovBean cabeceraMov = cabeceraMovDAO.obtenerCabeceraMov(numeroRegistroCab);
				rendicionDTO.setCabeceraMov(cabeceraMov);
			}
			ArrayList<PlanViajeRendicionBean> listaPlanViajeRendicion = new ArrayList<PlanViajeRendicionBean>();
			if(CollectionUtils.isNotEmpty(rendicionDTO.getPlanViajeRendicionList())){
				for(PlanViajeRendicionBean planViajeRendicion : rendicionDTO.getPlanViajeRendicionList()){
					ConceptoPlanillaViaticosBean conceptoViatico = viaticoService.obtenerConceptoViatico(StringUtils.trimToEmpty(planViajeRendicion.getConceptoId()));
					planViajeRendicion.setNombreConceptoGasto(conceptoViatico.getDescripcionConcepto());
					listaPlanViajeRendicion.add(planViajeRendicion);
				}
				rendicionDTO.setPlanViajeRendicionList(listaPlanViajeRendicion);
			}
			String planViajeId = planViaje.getCodPlanViaje();
			ArrayList<PlanViajeInformeDistribBean> planViajeInformeDistrib = new ArrayList<PlanViajeInformeDistribBean>();
			if(StringUtils.isNotEmpty(planViajeId)){
				//Lista utilizada para la generación del reporte de declaración de viáticos.
				planViajeInformeDistrib  =  planViajeInformeDistribDAO.obtenerDetalleGastoReporte(planViajeId,ViaticoConstantes.TIPO_DOCUMENTO_DECLARACION_VIATICO);
				Double sumador = 0D;
				if(CollectionUtils.isNotEmpty(planViajeInformeDistrib)){ 
					for(PlanViajeInformeDistribBean  planViajeInforme : planViajeInformeDistrib){
						sumador = sumador + planViajeInforme.getMtoDocumento();
					}
				}
				rendicionDTO.setMontoDetalleComprobanteTotal(NumeroUtil.formatearMonto(simboloMoneda, BigDecimal.valueOf(sumador),2));
				rendicionDTO.setPlanViajeInformeList(planViajeInformeDistrib);
			}
		}		
		rendicionDTO.setPlanViaje(planViaje);
		return rendicionDTO;
	}
	
	/**
	 * Metodo que permite obtener los datos necesarios para el reporte declaracion.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @return Rendicion DTO.
	 * @see    RendicionDTO
	 */
	public RendicionDTO obtenerDatosReporteDeclaracion(String codPlanViaje) throws Exception {
		RendicionDTO rendicionDTO = new RendicionDTO();
		PlanViajeBean planViaje = obtenerPlanViaje(codPlanViaje);
		rendicionDTO.setPlanViaje(planViaje);
		return rendicionDTO;
	}
	
	/**
	 * Metodo que permite validar si una papeleta deposito tiene voucher adjuntado.
	 * @author Jorge Ponce.
	 * @param  codigoPapeletaDeposito :codigo papeleta deposito.
	 * @return Flag papeleta deposito adjuntado.
	 * @see String
	 */
	public String obtenerFlagPapeletaDepositoAdjuntado(String codigoPapeletaDeposito) throws Exception {
		
		String flagPapeletaDepositoAdjuntado = RendicionConstantes.CERO;
		String numeroRegistroArchivo = papeletaDepositoDAO.obtenerNumeroRegistroArchivo(codigoPapeletaDeposito);
		if (!RendicionConstantes.CADENA_VACIA.equals(numeroRegistroArchivo)) {
			boolean flagArchivoRegistrado = registroArchivosService.validarArchivoRegistrado(ViaticoConstantes.APLICACION_SERVICIOS, ViaticoConstantes.MODULO_VIATICOS, ViaticoConstantes.TIPO_ARCHIVO_BOLETA_DEPOSITO, numeroRegistroArchivo);
			if (flagArchivoRegistrado) {
				flagPapeletaDepositoAdjuntado = RendicionConstantes.UNO;
			}
		}
		
		return flagPapeletaDepositoAdjuntado;
	}
	
	/**
	 * Metodo que permite obtener las rendiciones en rango de fechas.
	 *
	 * @author Juan Farro.
	 * @param planViajeID codigo de plan de viaje
	 * @param fechaDesdeEvento fecha de inicio de evento
	 * @param fechaHastaEvento fecha de fin de evento
	 * @param fechaDesdeItinerario fecha de inicio de itinerario
	 * @param fechaHastaItinerario fecha de fin de itinerario
	 * @return Listado de rendiciones
	 * @throws DataAccessException
	 * @see    PlanViajeRendicionBean
	 */
	@Override
	public List<PlanViajeRendicionBean> listarRendicionesFechaDocumento(String planViajeID, Date fechaDesdeEvento, Date fechaHastaEvento, Date fechaDesdeItinerario, Date fechaHastaItinerario) throws DataAccessException {

		List<PlanViajeRendicionBean> listaRendiciones = (List<PlanViajeRendicionBean>) planViajeRendicionDAO.listarRendicionesFechaDocumento(planViajeID, fechaDesdeEvento, fechaHastaEvento, fechaDesdeItinerario, fechaHastaItinerario);

		return listaRendiciones;
	}
		
	
}
