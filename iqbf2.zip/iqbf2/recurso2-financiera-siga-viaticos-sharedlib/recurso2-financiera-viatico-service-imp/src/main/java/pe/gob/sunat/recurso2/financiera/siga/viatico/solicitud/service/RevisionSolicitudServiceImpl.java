package pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.recurso2.administracion.siga.expediente.util.ExpedienteConstantes;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.administracion.siga.util.FechaUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.FormatoUtil;
import pe.gob.sunat.recurso2.administracion.siga.util.NumeroUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.service.ViaticoExpedienteService;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.RendicionConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ResourceBundleUtil;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.SolicitudConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;

/**
 * Implementacion de la interface RevisionSolicitudService, contiene los metodos para la revision de la solicitud.
 * @author Jorge Ponce.
 */
public class RevisionSolicitudServiceImpl implements RevisionSolicitudService {
	
	protected final Log log = LogFactory.getLog(getClass());
	private ConsultaSolicitudService consultaSolicitudService;
	private ViaticoExpedienteService viaticoExpedienteService;
	private PlanViajeDAO planViajeDAO;
	
	public ConsultaSolicitudService getConsultaSolicitudService() {
		return consultaSolicitudService;
	}

	public void setConsultaSolicitudService(ConsultaSolicitudService consultaSolicitudService) {
		this.consultaSolicitudService = consultaSolicitudService;
	}

	public ViaticoExpedienteService getViaticoExpedienteService() {
		return viaticoExpedienteService;
	}

	public void setViaticoExpedienteService(ViaticoExpedienteService viaticoExpedienteService) {
		this.viaticoExpedienteService = viaticoExpedienteService;
	}

	public PlanViajeDAO getPlanViajeDAO() {
		return planViajeDAO;
	}

	public void setPlanViajeDAO(PlanViajeDAO planViajeDAO) {
		this.planViajeDAO = planViajeDAO;
	}

	/**
	 * Metodo que permite obtener el listado de planes de viaje que se van a mostrar en la bandeja de autorizacion de solicitud.
	 * @author Jorge Ponce.
	 * @param  codigoDependencia :codigo de dependencia.
	 * @param  codPlanilla :codigo de planilla.
	 * @param  codTrabajador :codigo del colaborador.
	 * @param  codEstadoSolic :codigo de estado de la solicitud.
	 * @param  indicadorCanalAtencion :indicador canal de atencion.
	 * @param  fechaDesde :fecha desde.
	 * @param  fechaHasta :fecha hasta.
	 * @param  codigoAutorizador :codigo del autorizador.
	 * @return Objeto PlanViajeBean.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	//JMCR-ME BANDEJA AUTORIZADOR se cambia el estado de la solicitud por una lista de estados  a enviar con "IN"
	public ArrayList<PlanViajeBean> obtenerPlanViajeCompletoToBandejaAutorizacionSolicitud(String codigoDependencia, String codPlanilla, String codTrabajador, List<String> listCodEstadoSolic, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws Exception {
		
		log.debug("CODIGO DE AUTORIZADOR EN obtenerPlanViajeCompletoToBandejaAutorizacionSolicitud del service: " + codigoAutorizador);
		ArrayList<PlanViajeBean> planViajeList = obtenerPlanViajeToBandejaAutorizacionSolicitud(codigoDependencia, codPlanilla, codTrabajador, listCodEstadoSolic, indicadorCanalAtencion, fechaDesde, fechaHasta, codigoAutorizador);
		ArrayList<PlanViajeBean> planViajeDetalleList = consultaSolicitudService.obtenerPlanViajeDetalleToBandejaSolicitudMiltiplesEstados(null, codigoDependencia, codPlanilla, codTrabajador, listCodEstadoSolic, indicadorCanalAtencion, fechaDesde, fechaHasta, codigoAutorizador);
		ArrayList<PlanViajeBean> planViajeCompletoList = null;
		planViajeCompletoList = new ArrayList<PlanViajeBean>();
		
		if (planViajeList != null && !planViajeList.isEmpty()) {
			int sizePlanViajeList = planViajeList.size();
			
			for (int i = 0; i < sizePlanViajeList; i++) {	
				PlanViajeBean planViaje = planViajeList.get(i);
				
				planViaje.setFechaRegistroFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViaje.getFechaRegistro()));
				planViaje.setNomTipoViatico(obtenerDescripcionTipoDestino(planViaje.getTipoDestino()));
				planViaje.setMtoTotalFormateado(NumeroUtil.formatearMonto(planViaje.getMoneda(), planViaje.getMtoTotal(), 2));
				planViaje.setCanalAtencion(FormatoUtil.getUppperCaseText(planViaje.getCanalAtencion()));
				planViaje.setFecMaxRendFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViaje.getFecMaxRend()));
				planViaje.setNomEstSolic(FormatoUtil.getUppperCaseText(planViaje.getNomEstSolic()));
				planViaje.setNomUuOoCom(FormatoUtil.getUppperCaseText(planViaje.getNomUuOoCom()));
				
				planViaje.setItinerario("");
				planViaje.setFecSalidaFormateada("");
				planViaje.setFecRetornoFormateada("");
				planViaje.setNumDias(0);
				planViaje.setMotivoComis("");
				planViaje.setNomAutorizador("");
				planViaje.setNomRegistrador("");
				planViaje.setImpAsigViaticoFormateado("");
				planViaje.setImpAsigPasajesFormateado("");
				planViaje.setImpOtrosFormateado("");
				planViaje.setImpTotalOtorgadoFormateado("");
				planViaje.setMedioPago("");
				planViaje.setNumReciboProv("");
				planViaje.setFecPagoCajaChFormateado("");
				
				if (planViajeDetalleList != null && !planViajeDetalleList.isEmpty()) {
					int sizePlanViajeDetalleList = planViajeDetalleList.size();
					
					for (int j = 0; j < sizePlanViajeDetalleList; j++) {
						PlanViajeBean planViajeDetalle = planViajeDetalleList.get(j);
						
						if (planViaje.getCodPlanilla() .equals(planViajeDetalle.getCodPlanilla())) {
							//planViaje.setNomUuOoCom(planViajeDetalle.getNomUuOoCom());
							planViaje.setItinerario(planViajeDetalle.getItinerario());
							planViaje.setFecSalidaFormateada(planViajeDetalle.getFecSalidaFormateada());
							planViaje.setFecRetornoFormateada(planViajeDetalle.getFecRetornoFormateada());
							planViaje.setNumDias(planViajeDetalle.getNumDias());
							planViaje.setNumeroHoras(planViajeDetalle.getNumeroHoras());
							planViaje.setMotivoComis(planViajeDetalle.getMotivoComis());
							planViaje.setNomAutorizador(planViajeDetalle.getNomAutorizador());
							planViaje.setNomRegistrador(planViajeDetalle.getNomRegistrador());
							planViaje.setImpAsigViaticoFormateado(planViajeDetalle.getImpAsigViaticoFormateado());
							planViaje.setImpAsigPasajesFormateado(planViajeDetalle.getImpAsigPasajesFormateado());
							planViaje.setImpOtrosFormateado(planViajeDetalle.getImpOtrosFormateado());
							planViaje.setImpTotalOtorgadoFormateado(planViajeDetalle.getImpTotalOtorgadoFormateado());
							planViaje.setMedioPago(planViajeDetalle.getMedioPago());
							planViaje.setNumReciboProv(planViajeDetalle.getNumReciboProv());
							planViaje.setFecPagoCajaChFormateado(planViajeDetalle.getFecPagoCajaChFormateado());
							break;
						}
					}
				}
				planViajeCompletoList.add(planViaje);
			}			
		}
		
		
		/*if (planViajeList != null && !planViajeList.isEmpty() && planViajeDetalleList != null && !planViajeDetalleList.isEmpty()) {
			int sizePlanViajeList = planViajeList.size();
			int sizePlanViajeDetalleList = planViajeDetalleList.size();
			if (sizePlanViajeList == sizePlanViajeDetalleList) {
				planViajeCompletoList = new ArrayList<PlanViajeBean>();
				for (int i = 0; i < sizePlanViajeList; i++) {
					PlanViajeBean planViaje = planViajeList.get(i);
					PlanViajeBean planViajeDetalle = planViajeDetalleList.get(i);
					planViaje.setNomUuOoCom(planViajeDetalle.getNomUuOoCom());
					planViaje.setItinerario(planViajeDetalle.getItinerario());
					planViaje.setFecSalidaFormateada(planViajeDetalle.getFecSalidaFormateada());
					planViaje.setFecRetornoFormateada(planViajeDetalle.getFecRetornoFormateada());
					planViaje.setNumDias(planViajeDetalle.getNumDias());
					planViaje.setMotivoComis(planViajeDetalle.getMotivoComis());
					planViaje.setNomAutorizador(planViajeDetalle.getNomAutorizador());
					planViaje.setNomRegistrador(planViajeDetalle.getNomRegistrador());
					planViaje.setImpAsigViaticoFormateado(planViajeDetalle.getImpAsigViaticoFormateado());
					planViaje.setImpAsigPasajesFormateado(planViajeDetalle.getImpAsigPasajesFormateado());
					planViaje.setImpOtrosFormateado(planViajeDetalle.getImpOtrosFormateado());
					planViaje.setImpTotalOtorgadoFormateado(planViajeDetalle.getImpTotalOtorgadoFormateado());
					planViaje.setMedioPago(planViajeDetalle.getMedioPago());
					planViaje.setNumReciboProv(planViajeDetalle.getNumReciboProv());
					planViaje.setFecPagoCajaChFormateado(planViajeDetalle.getFecPagoCajaChFormateado());
					planViajeCompletoList.add(planViaje);
				}
			}
		}*/
		return planViajeCompletoList;
	}
	
	/**
	 * Metodo que permite obtener el listado de planes de viaje que se van a mostrar en la bandeja de autorizacion de solicitud.
	 * @author Jorge Ponce.
	 * @param  codigoDependencia :codigo de dependencia.
	 * @param  codPlanilla :codigo de planilla.
	 * @param  codTrabajador :codigo del colaborador.
	 * @param  codEstadoSolic :codigo de estado de la solicitud.
	 * @param  indicadorCanalAtencion :indicador canal de atencion.
	 * @param  fechaDesde :fecha desde.
	 * @param  fechaHasta :fecha hasta.
	 * @param  codigoAutorizador :codigo del autorizador.
	 * @return Objeto PlanViajeBean.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	//JMCR-ME BANDEJA AUTORIZADOR se cambia el estado de la solicitud por una lista de estados  a enviar con "IN"
	public ArrayList<PlanViajeBean> obtenerPlanViajeToBandejaAutorizacionSolicitud(String codigoDependencia, String codPlanilla, String codTrabajador, List<String> listCodEstadoSolic, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws Exception {
		
		ArrayList<PlanViajeBean> planViajeList = planViajeDAO.obtenerPlanViajeToBandejaAutorizacionSolicitudMultiplesEstados(codigoDependencia, codPlanilla, codTrabajador, listCodEstadoSolic, indicadorCanalAtencion, fechaDesde, fechaHasta, codigoAutorizador);
		ArrayList<PlanViajeBean> planViajeListAux = null;
		if (planViajeList != null && !planViajeList.isEmpty()) {
			planViajeListAux = new ArrayList<PlanViajeBean>();
			for (PlanViajeBean planViajeBean : planViajeList) {
				planViajeBean.setFechaRegistroFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFechaRegistro()));
				planViajeBean.setNomTipoViatico(obtenerDescripcionTipoDestino(planViajeBean.getTipoDestino()));
				planViajeBean.setMtoTotalFormateado(NumeroUtil.formatearMonto(planViajeBean.getMoneda(), planViajeBean.getMtoTotal(), 2));
				planViajeBean.setCanalAtencion(FormatoUtil.getUppperCaseText(planViajeBean.getCanalAtencion()));
				planViajeBean.setFecMaxRendFormateada(FechaUtil.formatDateToDateDDMMYYYY(planViajeBean.getFecMaxRend()));
				planViajeBean.setNomEstSolic(FormatoUtil.getUppperCaseText(planViajeBean.getNomEstSolic()));
				planViajeBean.setNomUuOoCom(FormatoUtil.getUppperCaseText(planViajeBean.getNomUuOoCom()));
				planViajeListAux.add(planViajeBean);
			}
		}
		return planViajeListAux;
	}
	
	/**
	 * Metodo que permite autorizar una solicitud.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @param  codPerAutoriza :codigo del autorizador.
	 * @param  codigoDependenciaAutorizador :codigo dependencia del autorizador.
	 * @param  codigoSedeAutorizador :codigo de sede del autorizador.
	 * @param  codigoNivelAutorizador :codigo nivel del autorizador.
	 * @param  expedientePlanViaje :expediente plan de viaje.
	 * @return Codigo de operacion: Exito(00) - Error(01).
	 * @see    String
	 * @throws ServiceException, Exception
	 */
	public String autorizarSolicitud(String codPlanViaje, String codPerAutoriza, String codigoDependenciaAutorizador, String codigoSedeAutorizador, 
			String codigoNivelAutorizador, String expedientePlanViaje, String numArchivoPdfFirmado) throws ServiceException, Exception {
		
		String codigoOperacion = SolicitudConstantes.ERROR_OPERACION;
		String errorMessage = RendicionConstantes.CADENA_VACIA;
		PlanViajeBean planViajeBean = new PlanViajeBean();
		planViajeBean.setCodPlanViaje(codPlanViaje);
		planViajeBean.setCodEstadoSolic(ViaticoConstantes.ESTADO_VIATICO_AUTORIZADO);
		planViajeBean.setCodPerAutoriza(codPerAutoriza);
		planViajeBean.setCodigoNivAutor(codigoNivelAutorizador);
		planViajeBean.setCodigoDepAutor(codigoDependenciaAutorizador);
		planViajeBean.setNumeroRegistroArchivo(numArchivoPdfFirmado);
		
		PlanViajeBean planViajeBD = planViajeDAO.obtenerPlanViajeToSolicitud(codPlanViaje);
		
		boolean esNacional = StringUtils.equals(planViajeBD.getTipoDestino(), ViaticoConstantes.TIPO_COMISION_NACIONAL);
		
		String codEstadoAccion = null;
		
		if(ViaticoConstantes.CANAL_ATENCION_CAJACHICA.equals(planViajeBD.getIndicadorCanalAtencion())){
			//Si es caja chica
			planViajeBean.setCodEstadoSolic(ViaticoConstantes.ESTADO_VIATICO_ENVIADO_CAJACHICA);
			codEstadoAccion = ExpedienteConstantes.ACCION_VIATICO_SOLIC_AUTORIZADA_AUTORIZADOR;
		}else{
			//Canal de atención abono en cuenta:
			planViajeBean.setCodEstadoSolic(ViaticoConstantes.ESTADO_VIATICO_ENVIADO_FINANCIERA);
			
			if(!esNacional){
				codEstadoAccion = "007";//Código de estado enviado a financiera...	
			}
		}
		
		
		if(esNacional && ViaticoConstantes.CANAL_ATENCION_REEMBOLSO.equals(planViajeBD.getIndicadorCanalAtencion())){
			PlanViajeBean planViajeBeanFirma = new PlanViajeBean();
			planViajeBeanFirma.setCodPlanViaje(codPlanViaje);
			planViajeBeanFirma.setNumeroRegistroArchivo(numArchivoPdfFirmado);
			planViajeDAO.autorizarSolicitudByAutorizadorSoloFirma(planViajeBeanFirma);
			
			String codigoGeneracionCCP = planViajeDAO.obtenerCodigoCCP(ViaticoConstantes.CCP_SISTEMA_VIATICOS, codPlanViaje);
			if (codigoGeneracionCCP != null && !SolicitudConstantes.UNO.equals(codigoGeneracionCCP)) {
				errorMessage = ResourceBundleUtil.getMessage(ViaticoConstantes.MENSAJE_ERROR_SIN_CCP_CAS);
				throw new ServiceException(this, errorMessage);
			}	
			
		}else{
			planViajeDAO.autorizarSolicitudByAutorizador(planViajeBean);	
		}
		
		/*Seguimiento*/
		if(codEstadoAccion!=null){
			String observacion = ViaticoConstantes.EXPEDIENTE_AUTORIZACION_SOLICITUD_MENSAJE;
			viaticoExpedienteService.crearAccion(ExpedienteConstantes.CODIGO_PROCESO_VIATICO_SOLICITUD, expedientePlanViaje, 
					ExpedienteConstantes.ESTADO_ACCION_003_CONFORME, codEstadoAccion, codPerAutoriza, observacion, codigoSedeAutorizador);
		}
		
		codigoOperacion = SolicitudConstantes.EXITO_OPERACION;
		
		return codigoOperacion;
	}
	
	/**
	 * Metodo que permite observar una solicitud.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @param  observacionAutorizador :motivo de observacion.
	 * @param  codPerAutoriza :codigo del autorizador.
	 * @param  codigoSedeAutorizador :codigo de sede del autorizador.
	 * @param  expedientePlanViaje :expediente plan de viaje.
	 * @return Codigo de operacion: Exito(00) - Error(01).
	 * @see    String
	 * @throws Exception
	 */
	public String observarSolicitud(String codPlanViaje, String observacionAutorizador, String codPerAutoriza, String codigoSedeAutorizador, String expedientePlanViaje) throws Exception {
		
		String codigoOperacion = SolicitudConstantes.ERROR_OPERACION;
		PlanViajeBean planViajeBean = new PlanViajeBean();
		planViajeBean.setCodPlanViaje(codPlanViaje);
		planViajeBean.setCodEstadoSolic(ViaticoConstantes.ESTADO_VIATICO_OBSERVADO);
		planViajeBean.setObservacionAutorizador(observacionAutorizador);
		planViajeDAO.observarSolicitudByAutorizador(planViajeBean);
		/*Seguimiento*/
		
		String observacion = ViaticoConstantes.EXPEDIENTE_OBSERVACION_SOLICITUD_MENSAJE;
		int tamanioSubstring = 0;
		if (observacionAutorizador != null) {
			tamanioSubstring = observacionAutorizador.length();
			if (tamanioSubstring > (200 - (observacion.length() + 20))) {
				tamanioSubstring = 200 - (observacion.length() + 20);
			}
			observacion = observacion.trim() + " : " + observacionAutorizador.substring(0, tamanioSubstring); 
		}
		
		
		viaticoExpedienteService.crearAccion(ExpedienteConstantes.CODIGO_PROCESO_VIATICO_SOLICITUD, expedientePlanViaje, ExpedienteConstantes.ESTADO_ACCION_003_CONFORME, 
				"009", codPerAutoriza, observacion, codigoSedeAutorizador);//Observado por autorizador de gasto...
		codigoOperacion = SolicitudConstantes.EXITO_OPERACION;
		return codigoOperacion;
	}
	
	/**
	 * Metodo que permite anular una solicitud.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @param  observacionAnulacion :motivo de anulacion.
	 * @param  codPerAutoriza :codigo del autorizador.
	 * @param  codigoSedeAutorizador :codigo de sede del autorizador.
	 * @param  expedientePlanViaje :expediente plan de viaje.
	 * @return Codigo de operacion: Exito(00) - Error(01).
	 * @see    String
	 * @throws Exception
	 */
	public String anularSolicitud(String codPlanViaje, String observacionAnulacion, String codPerAutoriza, String codigoSedeAutorizador, String expedientePlanViaje) throws Exception {
		
		String codigoOperacion = SolicitudConstantes.ERROR_OPERACION;
		PlanViajeBean planViajeBean = new PlanViajeBean();
		planViajeBean.setCodPlanViaje(codPlanViaje);
		planViajeBean.setCodEstadoSolic(ViaticoConstantes.ESTADO_VIATICO_ANULADO);
		planViajeBean.setObservacionAnulacion(observacionAnulacion);
		planViajeDAO.anularSolicitudByAutorizador(planViajeBean);
		/*Seguimiento*/
		
		String observacion = ViaticoConstantes.EXPEDIENTE_ANULACION_SOLICITUD_MENSAJE;
		int tamanioSubstring = 0;
		if (observacionAnulacion != null) {
			tamanioSubstring = observacionAnulacion.length();
			if (tamanioSubstring > (200 - (observacion.length() + 20))) {
				tamanioSubstring = 200 - (observacion.length() + 20);
			}
			observacion = observacion.trim() + " : " + observacionAnulacion.substring(0, tamanioSubstring); 
		}
		
		viaticoExpedienteService.crearAccion(ExpedienteConstantes.CODIGO_PROCESO_VIATICO_SOLICITUD, expedientePlanViaje, ExpedienteConstantes.ESTADO_ACCION_003_CONFORME, ExpedienteConstantes.ACCION_VIATICO_SOLIC_ANULADA_AUTORIZADOR, codPerAutoriza, observacion, codigoSedeAutorizador);
		codigoOperacion = SolicitudConstantes.EXITO_OPERACION;
		return codigoOperacion;
	}
	
	/**
	 * Metodo que permite obtener la descripcion del tipo de destino.
	 * @author Jorge Ponce.
	 * @param  tipoDestino :codigo tipo destino.
	 * @return Objeto PlanViajeBean.
	 * @see    String
	 * @throws Exception
	 */
	private String obtenerDescripcionTipoDestino(String tipoDestino) {
		
		String descripcionTipoDestino = FormatoUtil.getUppperCaseText(tipoDestino);
		if (SolicitudConstantes.TIPO_DESTINO_NACIONAL.equals(tipoDestino)) {
			descripcionTipoDestino = SolicitudConstantes.DESCRIPCION_TIPO_DESTINO_NACIONAL;
		}
		else if (SolicitudConstantes.TIPO_DESTINO_INTERNACIONAL.equals(tipoDestino)) {
			descripcionTipoDestino = SolicitudConstantes.DESCRIPCION_TIPO_DESTINO_INTERNACIONAL;
		}
		
		return descripcionTipoDestino;
	}

	@Override
	public Map<String,String> reevaluarUUOOsAutorizadoras(String codAutorizador)
			throws Exception {
		log.info("Iniciando reevaluación de uuoos autorizadoras con código de personal:"+codAutorizador);
		Map<String,String> resultado = planViajeDAO.reevaluarUUOOsAutorizadoras(codAutorizador);
		log.info("Código de error de reevaluación:"+resultado.get("codEjecucion"));
		log.info("Mensaje de ejecución:"+resultado.get("msgEjecucion"));
		return resultado;
	}
 
	@Override
	public String derivarSolicitud(String codPlanViaje, String codigoDependenciaAutorizador, String expedientePlanViaje, 
			String indicadorCanalAtencion,MaestroPersonalBean autorizador, 
			String codigoSedeAutorizador,String nombreNuevoAutorizador) throws ServiceException, Exception {
		
		String codigoOperacion = SolicitudConstantes.ERROR_OPERACION;
		
		PlanViajeBean planViajeUpdate = new PlanViajeBean();
		planViajeUpdate.setCodPlanViaje(codPlanViaje);
		planViajeUpdate.setCodigoDepAutor(codigoDependenciaAutorizador);
		
		planViajeDAO.derivarSolicitudByAutorizador(planViajeUpdate);
		
		String observacion = "SE DERIVÓ PARA AUTORIZACION A : ".concat(nombreNuevoAutorizador);
		
		/*Seguimiento*/
		viaticoExpedienteService.crearAccion(ExpedienteConstantes.CODIGO_PROCESO_VIATICO_SOLICITUD, expedientePlanViaje, 
				ExpedienteConstantes.ESTADO_ACCION_003_CONFORME, "005", 
				autorizador.getCodigoEmpleado(), observacion, codigoSedeAutorizador);
		
		codigoOperacion = SolicitudConstantes.EXITO_OPERACION;
		return codigoOperacion;
	}
	
}


