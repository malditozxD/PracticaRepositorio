package pe.gob.sunat.recurso2.financiera.siga.viatico.util;

import java.io.Serializable;
import java.text.MessageFormat;
import java.util.ResourceBundle;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ResourceBundleUtil implements Serializable {

	private static final long serialVersionUID = -8867485255949572950L;
	protected static Log log = LogFactory.getLog(ResourceBundleUtil.class);

	public static String getMessage(String key) {
		try {
			return ResourceBundle.getBundle(ViaticoConstantes.RESOURCE_BUNDLE_VIATICO).getString(key);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return "No se Encuentra el bundle";
		}
	}
	
	public static String getMessage(String keyProperty, Object... params) {
		String message = ViaticoConstantes.CADENA_VACIA;
		try {
			message = MessageFormat.format(ResourceBundle.getBundle(ViaticoConstantes.RESOURCE_BUNDLE_VIATICO).getString(keyProperty), params);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return message;
	}

	public static String getMessageSolicitud(String keyProperty) {
		String message = ViaticoConstantes.CADENA_VACIA;
		try {
			message = ResourceBundle.getBundle(ViaticoConstantes.RESOURCE_BUNDLE_VIATICO_SOLICITUD).getString(keyProperty);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return message;
	}

	public static String getMessageSolicitud(String keyProperty, Object... params) {
		String message = ViaticoConstantes.CADENA_VACIA;
		try {
			message = MessageFormat.format(ResourceBundle.getBundle(ViaticoConstantes.RESOURCE_BUNDLE_VIATICO_SOLICITUD).getString(keyProperty), params);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return message;
	}

	public static String getMessageRendicion(String keyProperty) {
		String message = ViaticoConstantes.CADENA_VACIA;
		try {
			message = ResourceBundle.getBundle(ViaticoConstantes.RESOURCE_BUNDLE_VIATICO_RENDICION).getString(keyProperty);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return message;
	}
	
	public static String getMessageRendicion(String keyProperty, Object... params) {
		String message = ViaticoConstantes.CADENA_VACIA;
		try {
			message = MessageFormat.format(ResourceBundle.getBundle(ViaticoConstantes.RESOURCE_BUNDLE_VIATICO_RENDICION).getString(keyProperty), params);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return message;
	}
	
	public static String getMessageReembolso(String keyProperty) {
		String message = ViaticoConstantes.CADENA_VACIA;
		try {
			message = ResourceBundle.getBundle(ViaticoConstantes.RESOURCE_BUNDLE_VIATICO_REEMBOLSO).getString(keyProperty);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return message;
	}
	
	public static String getMessageReembolso(String keyProperty, Object... params) {
		String message = ViaticoConstantes.CADENA_VACIA;
		try {
			message = MessageFormat.format(ResourceBundle.getBundle(ViaticoConstantes.RESOURCE_BUNDLE_VIATICO_REEMBOLSO).getString(keyProperty), params);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return message;
	}
	
	public static String getMessageCorreo(String keyProperty) {
		String message = ViaticoConstantes.CADENA_VACIA;
		try {
			message = ResourceBundle.getBundle(ViaticoConstantes.RESOURCE_BUNDLE_VIATICO_CORREO).getString(keyProperty);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return message;
	}

	public static String getMessageCorreo(String keyProperty, Object... params) {
		String message = ViaticoConstantes.CADENA_VACIA;
		try {
			message = MessageFormat.format(ResourceBundle.getBundle(ViaticoConstantes.RESOURCE_BUNDLE_VIATICO_CORREO).getString(keyProperty), params);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return message;
	}
	
}
