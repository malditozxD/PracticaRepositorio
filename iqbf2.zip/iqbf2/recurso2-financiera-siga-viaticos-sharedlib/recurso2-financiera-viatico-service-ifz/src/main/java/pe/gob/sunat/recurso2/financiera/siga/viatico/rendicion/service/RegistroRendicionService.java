package pe.gob.sunat.recurso2.financiera.siga.viatico.rendicion.service;

import java.math.BigDecimal;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PapeletaDepositoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;

/**
 * Interface RegistroRendicionService, contiene los metodos para el registro de rendicion.
 * @author Jorge Ponce.
 */
public interface RegistroRendicionService {
	
	/**
	 * Metodo que permite registrar la rendicion.
	 * @author Jorge Ponce.
	 * @param  planViajeBean :objeto que tiene los datos para registrar.
	 * @param  codigoRegistrador :codigo del registrador.
	 * @param  codigoSedeRegistrador :codigo sede del registrador.
	 * @return Codigo de operacion: Exito(00), Error(02).
	 * @see    String
	 * @throws ServiceException, Exception
	 */
	String registrarRendicion(PlanViajeBean planViajeBean, String codigoRegistrador, String codigoSedeRegistrador) throws ServiceException, Exception;
	
	/**
	 * Metodo que permite cerrar la rendicion.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @param  flagHabilitarCerrarRendicion :flag habilitar cerrar rendicion.
	 * @param  flagCVRHabilitarCerrarRendicion :flag cvr habilitar cerrar rendicion.
	 * @param  flagRegistroComprobante :flag registro de comprobante.
	 * @param  flagRegistroVoucher :flag registro de voucher.
	 * @param  flagRegistroRIC :flag registro de RIC.
	 * @param  montoDevueltoComprobanteTotal :monto total devuelto por comprobante.
	 * @param  montoDevueltoVoucherRICTotal :monto total devuelto por voucher y ric.
	 * @param  codigoRegistrador :codigo del registrador.
	 * @param  codigoSedeRegistrador :codigo sede del registrador.
	 * @param  procesoViatico :proceso viatico - manual 01 - automatico 02.
	 * @return Codigo de operacion: Exito(00), Error(02).
	 * @see    String
	 * @throws ServiceException, Exception
	 */
	String cerrarRendicion(String codPlanViaje, String flagHabilitarCerrarRendicion, String flagCVRHabilitarCerrarRendicion, String flagRegistroComprobante, 
			String flagRegistroVoucher, String flagRegistroRIC, BigDecimal montoDevueltoComprobanteTotal, BigDecimal montoDevueltoVoucherRICTotal, 
			String codigoRegistrador, String codigoSedeRegistrador, String procesoViatico, String codDerivacionRendicion, String codOsa) throws ServiceException, Exception;
	
	/**
	 * Metodo que permite registrar una papeleta deposito y asociarlo a un plan viaje.
	 * @author Jorge Ponce.
	 * @param  papeletaDeposito :objeto que tiene los datos para registrar.
	 * @param  tipoDestino :tipo destino.
	 * @return Codigo de boleta deposito.
	 * @see    String
	 * @throws Exception
	 */
	String registrarPapeletaDeposito(PapeletaDepositoBean papeletaDeposito, String tipoDestino) throws Exception;
	
	/**
	 * Metodo que permite desasociar una papeleta deposito a un plan viaje.
	 * @author Jorge Ponce.
	 * @param  codigoBoletaDeposito :codigo boleta deposito.
	 * @param  codigoPlanViaje :codigo plan viaje.
	 * @param  montoDeposito :monto del deposito.
	 * @param  tipoDestino :tipo destino.
	 * @return Codigo de operacion: Exito(00), Error(02).
	 * @see    String
	 * @throws Exception
	 */
	String desasociarPapeletaDeposito(String codigoBoletaDeposito, String codigoPlanViaje, BigDecimal montoDeposito, String tipoDestino) throws Exception;
	
	/**
	 * Metodo que permite actualizar el numero archivo de la papeleta deposito.
	 * @author Samuel Dionisio.
	 * @param  papeletaDeposito : PapeletaDepositoBean.
	 * @return Codigo de boleta deposito.
	 * @see    String
	 * @throws Exception
	 */
	String actualizarNumeroArchivoPapeletaDeposito(PapeletaDepositoBean papeletaDeposito) throws Exception;
	
	PlanViajeBean obtenerPlanViajeToRendicion(String codPlanViaje);
	
	boolean operacionExiste(PapeletaDepositoBean papeletaDeposito);
	
}
