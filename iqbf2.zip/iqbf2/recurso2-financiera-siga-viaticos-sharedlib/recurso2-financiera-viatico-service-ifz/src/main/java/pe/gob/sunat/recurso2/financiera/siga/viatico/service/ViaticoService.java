package pe.gob.sunat.recurso2.financiera.siga.viatico.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ConceptoPlanillaViaticosBean;

/**
 * Interfaz ViaticoService.
 * 
 * @author Juan Saccatoma
 */
public interface ViaticoService {

	/**
	 * Metodo que permite obtener conceptos viatico.
	 * 
	 * @author Juan Saccatoma
	 * 
	 * @param codigo codigo del concepto de viatico
	 * @param descripcion descripcion del concepto de viatico
	 * @return lista de conceptos de viatico
	 * @throws Exception
	 */
	List<ConceptoPlanillaViaticosBean> obtenerConceptosViatico(String codigo, String descripcion) throws Exception;

	/**
	 * Metodo que permite obtener conceptos viatico nacional.
	 * 
	 * @author Juan Farro
	 * @param codigo codigo del concepto de viatico
	 * @param descripcion descripcion del concepto de viatico
	 * @return lista de conceptos de viatico
	 * @throws Exception
	 */
	List<ConceptoPlanillaViaticosBean> obtenerConceptosViaticoNacional(String codigo, String descripcion) throws Exception;

	/**
	 * Metodo que permite obtener conceptos viatico internacional.
	 * 
	 * @author Juan Farro
	 * @param codigo codigo del concepto de viatico
	 * @param descripcion descripcion del concepto de viatico
	 * @return lista de conceptos de viatico
	 * @throws Exception
	 */
	List<ConceptoPlanillaViaticosBean> obtenerConceptosViaticoInternacional(String codigo, String descripcion) throws Exception;

	/**
	 * Metodo que permite obtener conceptos viatico internacional.
	 *
	 * @author Juan Farro
	 * @return lista de conceptos de viatico
	 * @throws Exception
	 */
	List<ConceptoPlanillaViaticosBean> obtenerConceptosViaticoInternacional() throws Exception;	
	
	ArrayList<ConceptoPlanillaViaticosBean> obtenerConceptoPlanillaViaticosToComprobante(String idPlanViaje) throws Exception;

	/**
	 * Metodo que permite obtener el importe diario nacional.
	 * 
	 * @author Juan Farro
	 * @param anioClasificador anio clasificador
	 * @param codigoDepartamento codigo de departamento
	 * @param codigoProvincia codigo de provincia
	 * @param nivelViatico nivel viatico
	 * @return concepto de viatico
	 * @throws Exception
	 */
	ConceptoPlanillaViaticosBean obtenerImporteDiarioNacional(String anioClasificador, String codigoDepartamento, String codigoProvincia, String nivelViatico) throws Exception;

	/**
	 * Metodo que permite obtener conceptos viatico nacional.
	 *
	 * @author Juan Farro
	 * @return lista de conceptos de viatico
	 * @throws Exception
	 */
	List<ConceptoPlanillaViaticosBean> obtenerConceptosViaticoNacional() throws Exception;	
	
	/**
	 * Metodo que permite obtener el importe diario internacional.
	 * 
	 * @author Juan Farro
	 * @param anioClasificador anio clasificador
	 * @param codigoUbigeo codigo de ubigeo
	 * @param nivelViatico nivel de viatico
	 * @return concepto de viatico
	 * @throws Exception
	 */
	ConceptoPlanillaViaticosBean obtenerImporteDiarioInternacional(String anioClasificador, String codigoUbigeo, String nivelViatico) throws Exception;

	
	
	/**
	 * Metodo que permite obtener los conceptos de viatico fijos nacionales.
	 * 
	 * @author Juan Farro
	 * @return lista de conceptos de viatico
	 * @throws Exception
	 */
	List<ConceptoPlanillaViaticosBean> obtenerConceptosViaticoFijosNacionalAsignacion() throws Exception;

	/**
	 * Metodo que permite obtener los conceptos de viatico fijos internacionales.
	 * 
	 * @author Juan Farro
	 * @return lista de conceptos de viatico
	 * @throws Exception
	 */
	List<ConceptoPlanillaViaticosBean> obtenerConceptosViaticoFijosInternacionalAsignacion() throws Exception;

	/**
	 * Metodo que permite obtener los dias habiles entre dos fechas.
	 * 
	 * @author Juan Farro
	 * @param fechaInicial fecha inicial
	 * @param fechaFinal fecha final
	 * @return numero de dias habiles
	 * @throws Exception
	 */
	int calcularDiasHabiles(Date fechaInicial, Date fechaFinal) throws Exception;

	/**
	 * Metodo que permite obtener el siguiente dia habil al sumarle dias a fecha.
	 * 
	 * @author Juan Farro
	 * @param fecha fecha inicial
	 * @param dias numero de dias a sumar
	 * @return fecha resultante
	 * @throws Exception
	 */
	Date sumarDiasHabiles(Date fecha, int dias) throws Exception;

	/**
	 * Metodo que permite determinar si una fecha es dia habil.
	 * 
	 * @author Juan Farro
	 * @param fecha fecha a evaluar
	 * @return true, si es dia habil
	 * @throws Exception
	 */
	boolean esDiaHabil(Date fecha) throws Exception;

	/**
	 * Metodo que permite buscar un concepto de viatico a partir de su codigo.
	 * 
	 * @author Juan Farro
	 * @param codigo del concepto de viatico
	 * @return concepto de viatico
	 * @throws Exception
	 */
	ConceptoPlanillaViaticosBean obtenerConceptoViatico(String codigo) throws Exception;
	
	String obtenerExistenciaPlanillasConsecutivas(String codiEmplPer, Date fecInicio, Date fecFin, String origen) throws Exception;
}