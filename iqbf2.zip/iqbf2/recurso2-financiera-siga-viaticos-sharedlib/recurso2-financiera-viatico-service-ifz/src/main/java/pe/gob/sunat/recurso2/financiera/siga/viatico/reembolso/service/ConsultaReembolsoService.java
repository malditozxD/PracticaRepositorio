package pe.gob.sunat.recurso2.financiera.siga.viatico.reembolso.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.SysEstadosBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ClaveValorBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeConceptoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ReembolsoDTO;

public interface ConsultaReembolsoService {

	/**
	 * Metodo que permite obtener las planillas de viatico asociadas a un colaborador.
	 * 
	 * @author Juan Farro
	 * @param colaborador codigo de colaborador
	 * @param tipoDestino tipo destino (nacional, internacional)
	 * @param indicadorHoras indicador de horas (mayor a 4 horas, menor o igual a 4 horas) 
	 * @return lista de planillas asociadas en formato clave-valor-JSON
	 * @throws Exception
	 * @see ClaveValorBean
	 */
	List<ClaveValorBean> obtenerPlanillasAsociadas(String colaborador, String tipoDestino, String indicadorHoras) throws Exception;

	/**
	 * Metodo que permite obtener una solicitud de viatico.
	 * 
	 * @author Juan Farro
	 * @param planViaje plan viaje
	 * @return mapa con los datos principales de la planilla asociada
	 * @throws Exception
	 */
	Map<String, String> obtenerDatosPlanillaAsociada(PlanViajeBean planViaje) throws Exception;

	/**
	 * Metodo que permite obtener los datos para generar el reporte de reembolso.
	 *
	 * @author Juan Farro
	 * @param codPlanViaje codigo de solicitud de viatico
	 * @return DTO de reembolso
	 * @throws Exception
	 * @see ReembolsoDTO
	 */
	ReembolsoDTO obtenerDatosReporteReembolso(String codPlanViaje) throws Exception;
	
	/**
	 * Metodo que permite obtener los datos para realizar el sustento de gasto reembolso.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @return Objeto PlanViajeBean.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	PlanViajeBean obtenerPlanViajeToSustentoGastoReembolso(String codPlanViaje) throws Exception;
	
	/**
	 * Metodo que permite obtener el listado de plan viaje concepto asociados a un reembolso.
	 * @author Jorge Ponce.
	 * @param  planViajeID :codigo plan viaje.
	 * @param  simboloMoneda :simbolo de la moneda.
	 * @return Listado de plan de viaje concepto.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	ArrayList<PlanViajeConceptoBean> obtenerPlanViajeConcepto(String planViajeID, String simboloMoneda) throws Exception;
	
	/**
	 * Metodo que permite obtener el listado de detalle de los planes de viaje que se muestran la bandeja de reembolso.
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @param codigoDependencia :codigo de dependencia.
	 * @param codPlanilla :codigo de planilla.
	 * @param codTrabajador :codigo del colaborador.
	 * @param codEstadoSolic :codigo de estado de la solicitud.
	 * @param fechaDesde :fecha desde.
	 * @param fechaHasta :fecha hasta.
	 * @param codigoAutorizador :codigo del autorizador.
	 * @return Objeto PlanViajeBean.
	 * @see PlanViajeBean
	 * @throws Exception
	 */
	ArrayList<PlanViajeBean> obtenerPlanViajeDetalleToBandejaReembolso(String codPlanViaje, String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoSolic, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws Exception;
	
	
	
	/**
	 * Metodo que permite obtener solicitudes de reembolsos para la bandeja de consulta, revision y alta (CUS10, CUS09 y CUS13).
	 * 
	 * @author Samuel Dionisio
	 * @param parmSearch parametros de busqueda
	 * @return lista de solicitudes
	 * @throws Exception
	 * @see PlanViajeBean
	 */

	List<PlanViajeBean> obtenerReembolsosBandejaConsultaRevision(Map<String, Object> parmSearch) throws Exception;
	
	/**
	 * Metodo que permite buscar los estados de una solicitud de viatico (t01parametro).
	 * 
	 * @author Samuel Dionisio
	 * @return lista de estados de solicitud de viatico
	 * @throws Exception
	 */
	List<SysEstadosBean> obtenerListaEstadosReembolsoViatico() throws Exception;
	
	/**
	 * Metodo que permite obtener el monto total de comprobantes de gasto.
	 * @author Juan Farro.
	 * @param  planViajeId :codigo plan viaje.
	 * @return Monto total depositado.
	 * @throws Exception
	 */
	BigDecimal obtenerMontoComprobanteGasto(String planViajeId) throws Exception;
	
	/**
	 * Metodo que permite obtener las solicitudes de viatico para exportar en la bandeja.
	 * 
	 * @author Samuel Dionisio
	 * @param parmSearch parametros de busqueda
	 * @return lista de reembolsos
	 * @throws Exception
	 * @see PlanViajeBean
	 */
	List<PlanViajeBean> obtenerReembolsoBandejaExportar(Map<String, Object> parmSearch) throws Exception;
}
