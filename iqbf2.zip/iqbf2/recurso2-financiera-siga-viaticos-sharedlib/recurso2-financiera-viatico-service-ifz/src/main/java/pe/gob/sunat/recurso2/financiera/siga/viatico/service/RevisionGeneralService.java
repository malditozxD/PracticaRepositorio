package pe.gob.sunat.recurso2.financiera.siga.viatico.service;


public interface RevisionGeneralService {
	

}
