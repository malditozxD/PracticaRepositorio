package pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.service;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeConceptoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeDestinoBean;

/**
 * Interfaz RegistroSolicitudService.
 * 
 * @author Juan Saccatoma
 */
public interface RegistroSolicitudService {

	/**
	 * Metodo que permite anular una solicitud de viatico.
	 * 
	 * @author Juan Saccatoma
	 * @param codPlanViaje codigo de solicitud de viatico
	 * @param motivoAnulacion motivo de anulacion
	 * @param expedientePlanViaje expediente plan de viaje
	 * @param codigoAnulador codigo de empleado de la que realiza la anulacion
	 * @return codigo resultado de operacion
	 * @throws Exceptiono
	 */
	 String anularSolicitud(String codPlanViaje, String motivoAnulacion, String expedientePlanViaje, String codigoAnulador) throws Exception;

	/**
	 * Metodo que permite rechazar una solicitud de traslape.
	 * 
	 * @author Juan Farro
	 * @param codPlanilla codigo planilla
	 * @param motivoRechazo motivo
	 * @param codigoRechazador codigo de empleado de la que realiza el rechazo
	 * @throws Exception
	 */
	void rechazarSolicitud(String codPlanilla, String motivoRechazo, String codigoRechazador) throws Exception;

	/**
	 * Metodo que permite dar de alta una solicitud de traslape.
	 * 
	 * @author Juan Farro
	 * @param codPlanilla codigo planilla
	 * @param codigoRegistrador codigo de empleado de la que realiza el alta
	 * @throws Exception
	 */
	void darAltaSolicitud(String codPlanilla, String codigoRegistrador) throws Exception;

	/**
	 * Metodo que permite autorizar una solicitud de viatico.
	 * 
	 * @author Juan Saccatoma
	 * @param parmSearch parametos de autorizacion
	 * @return true, si operacion fue exitosa
	 * @throws Exception
	 */
	boolean autorizarSolicitud(Map<String, Object> parmSearch) throws Exception;

	/**
	 * Metodo que permite registrar una solicitud viatico.
	 * 
	 * @author Juan Farro
	 * @param anioActual anio actual
	 * @param uuoo uuoo
	 * @param planViajeBean solicitud de viatico
	 * @param planViajeDestinos plan viaje destinos
	 * @param planViajeConceptos plan viaje conceptos
	 * @throws Exception
	 */
	PlanViajeBean registrarSolicitudViatico(String anioActual, String uuoo, PlanViajeBean planViajeBean, List<PlanViajeDestinoBean> planViajeDestinos, List<PlanViajeConceptoBean> planViajeConceptos) throws Exception;

	/**
	 * Metodo que permite modificar una solicitud viatico.
	 * 
	 * @author Juan Farro
	 * @param planViajeBean solicitud de viatico
	 * @param planViajeDestinos plan viaje destinos
	 * @param planViajeConceptos plan viaje conceptos
	 * @throws Exception
	 */
	void actualizarSolicitudViatico(PlanViajeBean planViajeBean, List<PlanViajeDestinoBean> planViajeDestinos, List<PlanViajeConceptoBean> planViajeConceptos) throws Exception;

	/**
	 * Metodo que permite enviar una solicitud viatico (estado por autorizar).
	 *
	 * @author Juan Farro
	 * @param codPlanViaje codigo de plan de viaje a enviar
	 * @param codigoEnviador codigo de empleado que realiza el envio
	 * @param tipoConfiguracion tipo de configuracion
	 * @return true, si tiene exito
	 * @throws Exception
	 */
	boolean enviarSolicitudViatico(String codPlanViaje, String codigoColaboradorEnviador, String tipoConfiguracion, String numeroRegistroArchivo) throws Exception;

	/**
	 * Buscar un nivel de viatico por su codigo.
	 * 
	 * @author Juan Farro
	 * @param codPlanViaje codigo de solicitud de viatico
	 * @param nuevoEstado nuevo estado
	 * @throws Exception
	 */
	void actualizarEstadoViatico(String codPlanViaje, String nuevoEstado) throws Exception;

	void actualizarNumeroArchivoPlanViaje(PlanViajeBean planViaje) throws Exception;
	
	void anularFirmaDocumento(Long codDocaut, String numArchivo, String nomArchivo) throws Exception;

}