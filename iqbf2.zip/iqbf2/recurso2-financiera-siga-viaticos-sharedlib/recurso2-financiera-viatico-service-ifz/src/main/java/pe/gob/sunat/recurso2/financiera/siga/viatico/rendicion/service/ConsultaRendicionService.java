package pe.gob.sunat.recurso2.financiera.siga.viatico.rendicion.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ComprobanteIngresoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PapeletaDepositoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeConceptoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeRendicionBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.RendicionDTO;

/**
 * Interface ConsultaRendicionService, contiene los metodos para la consulta de rendicion.
 * @author Juan Saccatoma.
 */
public interface ConsultaRendicionService {
	
	/**
	 * Metodo que permite obtener el listado de rendiciones.
	 * @author Juan Saccatoma.
	 * @param  parmSearch :objeto que tiene los parametros de la busqueda.
	 * @return Lista de rendiciones.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	List<PlanViajeBean> obtenerRendicionesBandeja(Map<String, Object> parmSearch) throws Exception;
	
	/**
	 * Metodo que permite obtener el detalle de una rendicion.
	 * @author Juan Saccatoma.
	 * @param  parmSearch :objeto que tiene los parametros de la busqueda.
	 * @return Objeto PlanViajeBean.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	List<PlanViajeBean> obtenerRendicionDetalle(Map<String, Object> parmSearch) throws Exception;
	
	/**
	 * Metodo que permite obtener el listado de rendiciones que se van a exportar.
	 * @author Juan Saccatoma.
	 * @param  parmSearch :objeto que tiene los parametros de la busqueda.
	 * @return Lista de rendiciones.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	List<PlanViajeBean> obtenerRendicionesBandejaExportar(Map<String, Object> parmSearch) throws Exception;
	
	/**
	 * Metodo que permite obtener el listado con los datos completos de planes de viaje que se van a mostrar en la bandeja de consulta de rendicion.
	 * @author Jorge Ponce.
	 * @param  codigoDependencia :codigo de dependencia.
	 * @param  codPlanilla :codigo de planilla.
	 * @param  codTrabajador :codigo del colaborador.
	 * @param  codEstadoRend :codigo de estado de la rendicion.
	 * @param  indicadorCanalAtencion :indicador canal de atencion.
	 * @param  fechaDesde :fecha desde.
	 * @param  fechaHasta :fecha hasta.
	 * @return Objeto PlanViajeBean.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	ArrayList<PlanViajeBean> obtenerPlanViajeCompletoToBandejaConsultaRendicion(String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoRend, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta) throws Exception;
	
	/**
	 * Metodo que permite obtener el listado de planes de viaje que se van a mostrar en la bandeja de consulta de rendicion.
	 * @author Jorge Ponce.
	 * @param  codigoDependencia :codigo de dependencia.
	 * @param  codPlanilla :codigo de planilla.
	 * @param  codTrabajador :codigo del colaborador.
	 * @param  codEstadoRend :codigo de estado de la rendicion.
	 * @param  indicadorCanalAtencion :indicador canal de atencion.
	 * @param  fechaDesde :fecha desde.
	 * @param  fechaHasta :fecha hasta.
	 * @return Objeto PlanViajeBean.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	ArrayList<PlanViajeBean> obtenerPlanViajeToBandejaConsultaRendicion(String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoRend, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta) throws Exception;
	
	/**
	 * Metodo que permite obtener el listado de detalle de los planes de viaje que se muestran la bandeja de consulta de rendicion.
	 * @author Jorge Ponce.
	 * @param  codigoDependencia :codigo de dependencia.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @param  codPlanilla :codigo de planilla.
	 * @param  codTrabajador :codigo del colaborador.
	 * @param  codEstadoRend :codigo de estado de la rendicion.
	 * @param  indicadorCanalAtencion :indicador canal de atencion.
	 * @param  fechaDesde :fecha desde.
	 * @param  fechaHasta :fecha hasta.
	 * @return Objeto PlanViajeBean.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	ArrayList<PlanViajeBean> obtenerPlanViajeDetalleToBandejaConsultaRendicion(String codPlanViaje, String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoRend, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta) throws Exception;
	
	/**
	 * Metodo que permite obtener los datos para realizar una rendicion del plan viaje.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @return Objeto PlanViajeBean.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	PlanViajeBean obtenerPlanViaje(String codPlanViaje) throws Exception;
	
	/**
	 * Metodo que permite obtener el listado de plan viaje concepto asociados a una solicitud.
	 * @author Jorge Ponce.
	 * @param  planViajeID :codigo plan viaje.
	 * @param  simboloMoneda :simbolo de la moneda.
	 * @return Listado de plan de viaje concepto.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	ArrayList<PlanViajeConceptoBean> obtenerPlanViajeConcepto(String planViajeID, String simboloMoneda) throws Exception;
	
	/**
	 * Metodo que permite obtener el listado de papeletas de deposito asociados a un plan viaje.
	 * @author Jorge Ponce.
	 * @param  codigoPlanViaje :codigo plan viaje.
	 * @return Listado de papeletas deposito.
	 * @see    PapeletaDepositoBean
	 * @throws Exception
	 */
	ArrayList<PapeletaDepositoBean> obtenerPapeletasDeposito(String codigoPlanViaje) throws Exception;
	
	/**
	 * Metodo que permite obtener el listado de recibos de ingreso caja (RICs) asociados a un plan viaje.
	 * @author Jorge Ponce.
	 * @param  numeroRendicion :numero de rendicion/codigo plan viaje.
	 * @return Listado de recibos de ingreso caja.
	 * @see    ComprobanteIngresoBean
	 * @throws Exception
	 */
	ArrayList<ComprobanteIngresoBean> obtenerRecibosIngresoCaja(String numeroRendicion) throws Exception;
	
	/**
	 * Metodo que permite obtener el monto a devolver en una rendicion.
	 * @author Jorge Ponce.
	 * @param  montoRendirTotal :monto total que se debe rendir.
	 * @param  montoComprobanteTotal :monto total de los comprobantes.
	 * @param  montoDepositoTotal :monto total de las papeletas deposito.
	 * @param  montoRICTotal :monto total de los recibos ingreso caja.
	 * @return Saldo a devolver.
	 * @see    BigDecimal
	 */
	BigDecimal obtenerMontoDevolver(BigDecimal montoRendirTotal, BigDecimal montoComprobanteTotal, BigDecimal montoDepositoTotal, BigDecimal montoRICTotal);
	
	/**
	 * Metodo que permite obtener el flag para habilitar el boton cerrar rendicion.
	 * @author Jorge Ponce.
	 * @param mtoTotal: monto asignado.
	 * @param montoDevuelto: monto devuelto por comprobantes.
	 * @param montoDevol: monto devuelto por voucher y/o rics.
	 * @param indicadorMenorGasto: indicador de menor gasto.
	 * @return Flag habilitar cerrar rendicion.
	 * @see String
	 */
	String obtenerFlagHabilitarCerrarRendicion(String mtoTotal, Double montoDevuelto, Double montoDevol, String indicadorMenorGasto);
	
	/**
	 * Metodo que permite obtener el flag para habilitar el boton cerrar rendicion.
	 * @author Jorge Ponce.
	 * @param montoAsignadoTotal: monto asignado.
	 * @param montoDevueltoComprobanteTotal: monto devuelto por comprobantes.
	 * @param montoDevueltoVoucherRICTotal: monto devuelto por voucher y/o rics.
	 * @param indicadorMenorGasto: indicador de menor gasto.
	 * @return Flag habilitar cerrar rendicion.
	 * @see String
	 */
	String obtenerFlagHabilitarCerrarRendicion(BigDecimal montoAsignadoTotal, BigDecimal montoDevueltoComprobanteTotal, BigDecimal montoDevueltoVoucherRICTotal, String indicadorMenorGasto);
	
	/**
	 * Metodo que permite obtener la papeleta segun el codigo de boleta
	 * @author Samuel Dionisio.
	 * @param  papeletaDepositoBean :PapeletaDepositoBean.
	 * @return Bean papeleta.
	 * @see    PapeletaDepositoBean
	 * @throws Exception
	 */
	PapeletaDepositoBean obtenerPapeletaDeposito(String codigoBoletaDeposito) throws Exception;
	
	/**
	 * Metodo que permite obtener los datos necesarios para el reporte rendicion.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @return Rendicion DTO.
	 * @see    RendicionDTO
	 */
	RendicionDTO obtenerDatosReporteRendicion(String codPlanViaje) throws Exception;
	
	/**
	 * Metodo que permite obtener los datos necesarios para el reporte declaracion.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @return Rendicion DTO.
	 * @see    RendicionDTO
	 */
	RendicionDTO obtenerDatosReporteDeclaracion(String codPlanViaje) throws Exception;
	
	/**
	 * Metodo que permite validar si una papeleta deposito tiene voucher adjuntado.
	 * @author Jorge Ponce.
	 * @param  codigoPapeletaDeposito :codigo papeleta deposito.
	 * @return Flag papeleta deposito adjuntado.
	 * @see String
	 */
	String obtenerFlagPapeletaDepositoAdjuntado(String codigoPapeletaDeposito) throws Exception;

	/**
	 * Metodo que permite obtener las rendiciones en rango de fechas.
	 *
	 * @author Juan Farro.
	 * @param planViajeID codigo de plan de viaje
	 * @param fechaDesdeEvento fecha de inicio de evento
	 * @param fechaHastaEvento fecha de fin de evento
	 * @param fechaDesdeItinerario fecha de inicio de itinerario
	 * @param fechaHastaItinerario fecha de fin de itinerario
	 * @return Listado de rendiciones
	 * @throws Exception
	 * @see    PlanViajeRendicionBean
	 */
	List<PlanViajeRendicionBean> listarRendicionesFechaDocumento(String planViajeID, Date fechaDesdeEvento, Date fechaHastaEvento, Date fechaDesdeItinerario, Date fechaHastaItinerario) throws Exception;	
}
