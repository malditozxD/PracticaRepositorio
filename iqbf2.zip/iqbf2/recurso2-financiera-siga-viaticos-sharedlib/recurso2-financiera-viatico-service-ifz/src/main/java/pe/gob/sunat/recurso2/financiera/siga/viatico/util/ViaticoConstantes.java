package pe.gob.sunat.recurso2.financiera.siga.viatico.util;

public class ViaticoConstantes {

	// GENERALES
	public static final String RESOURCE_BUNDLE_VIATICO = "iasiga-viatico-viatico";
	public static final String RESOURCE_BUNDLE_VIATICO_SOLICITUD = "iasiga-viatico-solicitud";
	public static final String RESOURCE_BUNDLE_VIATICO_RENDICION = "iasiga-viatico-rendicion";
	public static final String RESOURCE_BUNDLE_VIATICO_REEMBOLSO = "iasiga-viatico-reembolso";
	public static final String RESOURCE_BUNDLE_VIATICO_CORREO = "iasiga-viatico-correo";
	public static final String MENSAJE_ERROR_GENERICO = "error.mensaje.generico";
	public static final String MENSAJE_OPERACION_EXITOSA = "success.message.operacionExitosa";
	public static final String MENSAJE_ERROR_SIN_CCP_CAS = "error.mensaje.sinCcpCas";
	public static final String OPERACION_NO_REALIZADA = "Operación no realizada";
	public static final String DESPLAZAMIENTO_NO_VALIDO = "Desplazamiento no válido";

	public static final String BUSCAR_TODOS = "1";
	public static final String BUSCAR_FILTRO = "0";
	public static final String CODIGO_GRUPO_01_PARAMETRO = "01";
	public static final String CADENA_VACIA = "";
	public static final String TIPO_BUSQUEDA_NUM_REGISTRO = "01";
	public static final String TIPO_BUSQUEDA_NOMBRE = "02";
	public static final String TIPO_BUSQUEDA_UUOO = "03";
	public static final String SIGNO_MINUS = "-";
	public static final String REQUEST_AND = "&";
	public static final String IGUAL = "=";
	public static final String DATE_FORMAT_DDMMYYYYHHMM = "dd/MM/yyyy HH:mm";
	public static final String DATE_FORMAT_DDMMYYYYHHMM_AMPM = "dd/MM/yyyy HH:mm a";
	public static final String DATE_FORMAT_DDMMYYYY = "dd/MM/yyyy";
	public static final String DATE_FORMAT_YYYY = "yyyy";
	public static final String DATE_FORMAT_MM = "MM";
	public static final String DATE_FORMAT_DD = "dd";
	public static final String DATE_FORMAT_HHMM = "HH:mm";
	public static final String FECHA_INICIO_REFERENCIAL = "01/01/1800";
	public static final String DOS_PUNTOS = ":";
	public static final String ESPACIO = " ";
	public static final String MONEDA_SOLES = "S/.";
	public static final String MONEDA_DOLARES = "US$";
	public static final String CERO = "0";
	public static final String UNO = "1";
	public static final String SELECCIONE = "-- Seleccione --";
	public static final String CODIGO_0 = "0";
	public static final String CODIGO_00 = "00";
	public static final String SI = "si";
	public static final String NO = "no";
	public static final String OK = "ok";
	public static final String CODIGO_0000 = "0000";
	public static final int CIEN = 100;
	public static final int CERO_INT = 0;
	public static final int UNO_INT = 1;
	public static final double UNO_DOUBLE = 1.0;
	public static final double CERO_DOUBLE = 0.0;
	public static final double NRO_HORAS_EN_UN_DIA = 24.0;
	public static final String CUATRO = "4";
	public static final String BR = "<br>";
	public static final String UL_INICIO = "<ul>";
	public static final String UL_FIN = "</ul>";
	public static final String LI_INICIO = "<li>";
	public static final String LI_FIN = "</li>";
	public static final String TEXTO_PLANILLA = "Planilla ";
	public static final String COMA = ",";
	public static final String TOTAL = "TOTAL";
	
	// buscar concepto viatico
	public static final String BUSCAR_CONCEPTO_VIATICO_NOMBRE_CONCEPTO = "01";
	public static final String BUSCAR_CONCEPTO_VIATICO_CODIGO_CONCEPTO = "02";
	public static final String BUSCAR_CONCEPTO_VIATICO_INDIVIDUALMENTE = "0";
	public static final String BUSCAR_CONCEPTO_VIATICO_TODOS = "1";
	public static final String BUSCAR_CONCEPTO_VIATICO_FILTRO_NACIONAL = "nacional";
	public static final String BUSCAR_CONCEPTO_VIATICO_FILTRO_INTERNACIONAL = "internacional";

	public static final String CONCEPTO_VIATICO_COMBINACION_NACIONAL = "N01";
	public static final String CONCEPTO_VIATICO_COMBINACION_INTERNACIONAL = "I01";
	public static final String CONCEPTO_VIATICO_TIPO_FIJ_PVI_VARIABLE = "V";
	public static final String CONCEPTO_VIATICO_TIPO_FIJ_PVI_FIJO = "F";

	public static final String CONCEPTO_VIATICO_CODI_CONC_PVI_FIJO_NACIONAL = "01";
	public static final String CONCEPTO_VIATICO_CODI_CONC_PVI_FIJO_INTERNACIONAL = "12";

	// buscar destino
	public static final String CODIGO_TD_DEPARTAMENTO = "01";
	public static final String CODIGO_TD_PROVINCIA = "02";
	public static final String CODIGO_TD_DISTRITO = "03";
	public static final String CODIGO_TD_UBIGEO = "04";
	public static final String INDICADOR_BUSCAR_TD_INDIVIDUALMENTE = "0";
	public static final String INDICADOR_BUSCAR_TD_TODOS = "1";

	// TIPOS DE PAGINA
	public static final String TIPO_PAGINA_GENERAL = "01";
	public static final String TIPO_PAGINA_ESPECIFICO = "02";
	public static final String PORCENTAJE = "%";

	// NRO DECIMALES ROUND
	public static final int NRO_DECIMALES_ROUND = 2;

	// CONSULTA
	public static final String TIPO_VIATICO_NACIONAL = "NACIONAL";
	public static final String TIPO_VIATICO_INTERNACIONAL = "INTERNACIONAL";

	// EXPEDIENTES
	public static final String EXPEDIENTE_CREACION_SOLICITUD_MENSAJE = "Se creó la solicitud.";
	public static final String EXPEDIENTE_ANULACION_SOLICITUD_MENSAJE = "Se anuló la solicitud.";
	public static final String EXPEDIENTE_TRASLAPE_SOLICITUD_MENSAJE = "Se realizó traslape de solicitud";
	public static final String EXPEDIENTE_RECHAZO_SOLICITUD_MENSAJE = "Se rechazó alta de solicitud.";
	public static final String EXPEDIENTE_OTORGAR_ALTA_SOLICITUD_MENSAJE = "Se otorgó alta de solicitud.";
	public static final String EXPEDIENTE_ENVIO_SOLICITUD_MENSAJE = "Se envió la solicitud.";
	public static final String EXPEDIENTE_OBSERVACION_SOLICITUD_MENSAJE = "Se observó la solicitud.";
	public static final String EXPEDIENTE_AUTORIZACION_SOLICITUD_MENSAJE = "Se autorizó la solicitud.";
	
	public static final String EXPEDIENTE_REGISTRO_RENDICION_MENSAJE = "Se registró la rendición.";
	public static final String EXPEDIENTE_CIERRE_RENDICION_MENSAJE = "Se cerró la rendición.";
	public static final String EXPEDIENTE_ANULACION_RENDICION_MENSAJE = "Se revierte envío.";
	public static final String EXPEDIENTE_REPROGRAMACION_RENDICION_MENSAJE = "Se reprogramó la fecha de rendición.";
	public static final String EXPEDIENTE_SEGUNDA_NOTIFICACION_RENDICION = "Se realizo la segunda notificacion.";
	
	public static final String EXPEDIENTE_REEMBOLSO_SOLICITUD_MENSAJE = "Se creó la solicitud reembolso";
	public static final String EXPEDIENTE_ANULACION_REEMBOLSO_MENSAJE = "Se anuló la solicitud de reembolso.";
	public static final String EXPEDIENTE_OBSERVACION_REEMBOLSO_MENSAJE = "Se observó la solicitud de reembolso.";
	public static final String EXPEDIENTE_AUTORIZACION_REEMBOLSO_MENSAJE = "Se autorizó la solicitud de reembolso.";
	
	// BUSQUEDA DE METAS
	public static final String BUSQ_META_ORDENA_POR_DEFAULT = "SECU_FUNC";
	public static final String BUSQ_META_ORDENA_MAYOR_CODIGO = "CODIGO_PROY";
	public static final String BUSQ_META_DEFAULT_UUOO = "1";

	// DETALLE - CABECERAS
	public static final String DETALLE = "D";
	public static final String CABECERA = "C";

	// TIPO DE CONFIGURACION APLICATIVO (PARAMETRO 3200)
	public static final String TIPO_CONFIGURACION_CODIGO_PARAMETRO = "3200";
	public static final String TIPO_CONFIGURACION_MANUAL = "01";
	public static final String TIPO_CONFIGURACION_AUTOMATICA = "02";

	// TIPO DE TARIFARIO
	public static final String TIPO_TARIFARIO_CODIGO_PARAMETRO = "3210";
	public static final String TIPO_TARIFARIO_NACIONAL = "01";
	public static final String TIPO_TARIFARIO_REGIONAL = "02";

	// MENSAJE GENÉRICO PETICIÓN AJAX - LOS MENSAJES DE NEGOCIO PERSONALIZADOS SON OTROS 
	public static final String MSG_ERROR_OPERACION_NO_EFECTUADA = "Error de aplicación - Comuníquese con el Administrador del Sistema";

	// ACTIVO - INACTIVO
	public static final String ACTIVO = "1";
	public static final String INACTIVO = "0";

	// LUGARES DE DESPLAZAMIENTO (PARAMETRO 3056)
	public static final String LUGAR_DESPLAZ_LUGARES_PARAM = "3056";

	// MEDIO DE TRANSPORTE (PARAMETRO 3202)
	public static final String LUGAR_DESPLAZ_MEDIO_TRANSPORTE_PARAM = "3202";
	public static final String MEDIO_TRANSPORTE_AEREO = "01";
	public static final String MEDIO_TRANSPORTE_TERRESTRE = "02";
	public static final String MEDIO_TRANSPORTE_FLUVIAL = "03";
	public static final String MEDIO_TRANSPORTE_LACUESTRE = "04";

	// TARIFAS (PARAMETRO 3201)
	public static final String LUGAR_DESPLAZ_TARIFAS_PARAM = "3201";
	public static final String RUTA_TIPO_TARIFA_GENERAL = "01";
	public static final String RUTA_TIPO_TARIFA_CUBRE_ALOJAMIENTO = "02";
	public static final String RUTA_TIPO_TARIFA_CUBRE_ALIMENTACION = "03";
	public static final String RUTA_TIPO_TARIFA_CUBRE_ALOJAMIENTO_Y_ALIMENTACION = "04";
	public static final String RUTA_TIPO_TARIFA_OTROS = "05";

	// NIVELES VIATICOS:
	public static final String NIVEL_VIATICO_INTENDENTE = "002";
	public static final String NIVEL_VIATICO_OTROS = "003"; // aquellos que no son intendentes

	// ESTADOS VIATICO SOLICITUD (codigos)
	public static final String ESTADO_VIATICO_ELABORADO = "01";
	public static final String ESTADO_VIATICO_ENVIADO_CAJACHICA = "02";
	public static final String ESTADO_VIATICO_ANULADO = "03";
	public static final String ESTADO_VIATICO_POR_AUTORIZAR = "04";
	public static final String ESTADO_VIATICO_AUTORIZADO = "05";
	public static final String ESTADO_VIATICO_ENVIADO_CPP = "05";
	public static final String ESTADO_VIATICO_OBSERVADO = "06";
	public static final String ESTADO_VIATICO_OBSERVADO_CAJA_CHICA = "07";
	public static final String ESTADO_VIATICO_OBSERVADO_FINANCIERA = "08";
	public static final String ESTADO_VIATICO_ANULACION_AUTOMATICA = "09";
	public static final String ESTADO_VIATICO_PAGADO = "10";
	public static final String ESTADO_VIATICO_ENVIADO_FINANCIERA = "11";

	// ESTADOS VIATICO SOLICITUD (DESCRIPCIONES) SysEstado: PLAN_VIAJE_WEB
	public static final String ESTADO_VIATICO_NOMBRE_TABLA = "PLAN_VIAJE_WEB";
	
	// ESTADOS VIATICO REEMBOLSO (codigos)
	public static final String ESTADO_REEMBOLSO_ELABORADO = "01";
	public static final String ESTADO_REEMBOLSO_ANULADO = "03";
	public static final String ESTADO_REEMBOLSO_POR_AUTORIZAR = "04";
	public static final String ESTADO_REEMBOLSO_AUTORIZADO = "05";
	public static final String ESTADO_REEMBOLSO_OBSERVADO = "06";
	public static final String ESTADO_REEMBOLSO_OBSERVADO_FINANCIERA = "08";
	public static final String ESTADO_REEMBOLSO_ANULACION_AUTOMATICA = "09";
	public static final String ESTADO_REEMBOLSO_PAGADO = "10";	
	
	// ESTADOS VIATICO REEMBOLSO (DESCRIPCIONES) SysEstado: PLAN_VIAJE_WEB_REMB
	public static final String ESTADO_REEMBOLSO_NOMBRE_TABLA = "PLAN_VIAJE_WEB_REMB";
	
	// ESCALA DE VIATICOS
	public static final String ESCALA_VIATICO_ESTA_ESC_VIAT_NO = "N";
	public static final String ESCALA_VIATICO_ESTA_ESC_VIAT_SI = "S";

	// TIPO DE COMISIÓN/VIÁTICO (PARAMETRO 3204)
	public static final String TIPO_COMISION_CODIGO_PARAMETRO = "3204";
	public static final String TIPO_COMISION_NACIONAL = "01";
	public static final String TIPO_COMISION_INTERNACIONAL = "02";

	public static final String TIPO_COMISION_NACIONAL_DESCRIP = "NACIONAL";
	public static final String TIPO_COMISION_INTERNACIONAL_DESCRIP = "INTERNACIONAL";

	// DURACION DE COMISION NACIONAL (PARAMETRO 3203)
	public static final String DURACION_COMISION_CODIGO_PARAMETRO = "3203";
	public static final String DURACION_COMISION_MENOR_IGUAL_4H = "1";
	public static final String DURACION_COMISION_MAYOR_4H = "2";

	public static final String DURACION_COMISION_MENOR_IGUAL_4H_DESCRIP = "Menor igual 4 Horas";
	public static final String DURACION_COMISION_MAYOR_4H_DESCRIP = "Mayor a 4 horas";

	public static final Integer MAXIMO_NRO_DIAS_HABILES = 15;
	public static final Integer CANAL_ATENCION_NUMERO_DIAS_TOPE = 8;

	public static final Integer FECHA_MAXIMA_DIAS_NACIONAL_CAJACHICA = 3;
	public static final Integer FECHA_MAXIMA_DIAS_NACIONAL_ABONOCUENTA = 8;
	public static final Integer FECHA_MAXIMA_DIAS_INTERNACIONAL_CALENDARIO = 15;
	public static final Integer FECHA_MAXIMA_DIAS_INTERNACIONAL = 1;

	// CONSTANTES VISTA
	public static final String VISTA_TIPO_VIATICO_NACIONAL = "nacional";
	public static final String VISTA_TIPO_VIATICO_INTERNACIONAL = "internacional";
	public static final String VISTA_DURACION_COMISION_MAYOR4H = "may4h";
	public static final String VISTA_DURACION_COMISION_MENOR_IGUAL4h = "men4h";

	public static final String VISTA_REGISTRAR = "registrar";
	public static final String VISTA_MODIFICAR = "modificar";
	public static final String VISTA_CONSULTAR = "consultar";

	// TIPO ORIGEN
	public static final String TIPO_ORIGEN_SOLICITUD_VIATICO = "01";
	public static final String TIPO_ORIGEN_REEMBOLSO = "02";

	// TIPO DE TRASLADO
	public static final String TIPO_TRASLADO_VIATICOS = "01";
	public static final String TIPO_TRASLADO_TRASLADO = "02";

	// INDICADOR HORAS
	public static final String INDICADOR_HORAS_DIAS = "0";
	public static final String INDICADOR_HORAS_HORAS = "1";

	// INDICADOR AUTORIZACION (PARA AUTORIZAR TRASLAPES)
	public static final String INDICADOR_AUTORIZACION_SIN_AUTORIZAR = "0"; // ESTADO INICIAL
	public static final String INDICADOR_AUTORIZACION_AUTORIZADO = "1";
	public static final String INDICADOR_AUTORIZACION_RECHAZADO = "2";

	// INDICADOR DE TRASLAPE
	public static final String INDICADOR_TRASLAPE_SI = "1";
	public static final String INDICADOR_TRASLAPE_NO = "0";
	
	public static final String INDICADOR_EXTDDJJ_SI = "1";
	public static final String INDICADOR_EXTDDJJ_NO = "0";

	// INDICADOR MODO PAGO (PARAMETRO 3211)
	public static final String INDICADOR_MODO_PAGO_CODIGO_PARAMETRO = "3211";
	public static final String INDICADOR_MODO_PAGO_CAJA_CHICA = "1";
	public static final String INDICADOR_MODO_PAGO_ABONO_CUENTA = "2";
	public static final String INDICADOR_MODO_PAGO_CHEQUE = "3";

	// CANAL DE ATENCION (PARAMETRO 3230)
	public static final String CANAL_ATENCION_CODIGO_PARAMETRO = "3230";
	public static final String CANAL_ATENCION_CAJACHICA = "C";
	public static final String CANAL_ATENCION_REEMBOLSO = "R";

	// AMPLIACION COMISION (PARAMETRO 3208)
	public static final String MOTIVO_AMPLIACION_CODIGO_PARAMETRO = "3208";
	public static final String MOTIVO_AMPLIACION_AMPLIACION_COMISION = "01";
	public static final String MOTIVO_AMPLIACION_VIATICO_NO_COBRADO = "02";
	public static final String MOTIVO_AMPLIACION_OTROS = "03";

	public static final String CANAL_ATENCION_CAJACHICA_DESCRIP = "Caja Chica";
	public static final String CANAL_ATENCION_REEMBOLSO_DESCRIP = "Abono en cuenta";

	// CODIGO DE EXONERACION (PARAMETRO 3212)
	public static final String EXONERACION_CODIGO_PARAMETRO = "3212";
	public static final String EXONERACION_CODIGO_TIPO = "D";

	// CONCEPTOS VIATICOS
	
	//CONCEPTOS VIATICOS
/*	public static final String CONCEPTOS_VIATICOS_ALIMENTACION = "05"; 
	public static final String CONCEPTOS_VIATICOS_TRASLADOS_AL_DEL = "18";
	public static final String CONCEPTOS_VIATICOS_MOVILIDAD_LOCAL = "04";
	public static final String CONCEPTOS_VIATICOS_HOSPEDAJE = "07";*/
	
	public static final String CONCEPTOS_VIATICOS_ALIMENTACION = "VA"; 
	public static final String CONCEPTOS_VIATICOS_TRASLADOS_AL_DEL = "VT";
	public static final String CONCEPTOS_VIATICOS_MOVILIDAD_LOCAL = "VM";
	public static final String CONCEPTOS_VIATICOS_HOSPEDAJE = "VH";

	// TIPOS DOCUMENTOS
	public static final String TIPO_DOCUMENTO_DECLARACION_COMPROBANTE_PAGO = "906";
	public static final String TIPO_DOCUMENTO_DECLARACION_VIATICO = "907";
	public static final String TIPO_DOCUMENTO_COMPROBANTE_EXTERIOR = "916";
	public static final String TIPO_DOCUMENTO_BOLETO_VIAJE = "915";
	public static final String TIPO_DOCUMENTO_COBRANZA_AGENCIAS_VIAJES = "067";
	
	// TIPOS DOCUMENTOS - ABREVIATURA
	public static final String ABREVIATURA_TIPO_DOCUMENTO_DECLARACION = "D/J";

	// BANDEJA DE CONSULTAS - CUS10
	public static final Integer BANDEJA_NUMERO_ANIOS_RANGO = 5;
	public static final String BANDEJA_CONSULTA_MENSAJE_ERROR_PLANILLA_NO_EXISTE = "consultarSolicitudBandeja.messageError.numeroPlanillaNoExiste";
	public static final String BANDEJA_REVISION_MENSAJE_ERROR_PLANILLA_NO_EXISTE = "revisarSolicitudBandeja.messageError.numeroPlanillaNoExiste";
	public static final String BANDEJA_ALTA_MENSAJE_ERROR_PLANILLA_NO_EXISTE = "altaSolicitudBandeja.messageError.numeroPlanillaNoExiste";
	public static final String BANDEJA_REVISION_MENSAJE_ERROR_SOLICITUD_NO_EXISTE = "revisarReembolsoBandeja.messageError.numeroPlanillaNoExiste";
	public static final String BANDEJA_CONSULTA_MENSAJE_ERROR_SOLICITUD_NO_EXISTE = "consultarReembolsoBandeja.messageError.numeroPlanillaNoExiste";
	// FLAG BUSCAR COLABORADOR - UUOO
	public static final String BUSCAR_COLABORADOR = "00";
	public static final String BUSCAR_AUTORIZADOR = "01";
	public static final String BUSCAR_REGISTRADOR = "02";
	public static final String BUSCAR_REGISTRADOR_UNIVERSAL = "03";

	// CODIGO DE OPERACION - EXITO - ERROR
	public static final String EXITO_OPERACION = "00";
	public static final String ERROR_OPERACION = "01";

	// PAGE - CALLER
	public static final String PAGE_CALLER_BANDEJA_SOLICITUD_COLABORADOR = "01";
	public static final String PAGE_CALLER_BANDEJA_SOLICITUD_AUTORIZADOR = "02";
	public static final String PAGE_CALLER_BANDEJA_REEMBOLSO_COLABORADOR = "03";
	public static final String PAGE_CALLER_BANDEJA_REEMBOLSO_AUTORIZADOR = "04";
	
	//PAGE - CALLER
	public static final String PAGE_CALLER_REGISTRAR_RENDICION = "01";
	public static final String PAGE_CALLER_SUSTENTAR_GASTO = "02";

	// INDICADOR - REGISTRADOR
	public static final String INDICADOR_REGISTRADOR = "V";
	public static final String INDICADOR_REGISTRADOR_UNIVERSAL = "U";
	
	//PARAMETROS
	public static final String CODIGO_MODULO = "SIGA";
	public static final String CODIGO_TIPO = "D";
	
	//PARAMETROS - PORCENTAJE DDJJ
	public static final String CODIGO_PARAMETRO_PORCENTAJE_DDJJ = "3236";
	public static final String CODIGO_ARGUMENTO_NACIONAL_MAYOR_4 = "01";
	public static final String CODIGO_ARGUMENTO_NACIONAL_MENOR_4 = "02";
	public static final String CODIGO_ARGUMENTO_INTERNACIONAL = "03";
	
	//PARAMETROS - CONFIGURACION VIATICO GN
	public static final String CODIGO_PARAMETRO_CONFIGURACION_GN = "3237";
	public static final String CODIGO_ARGUMENTO_ADJUNTAR_SCANEADO = "01";
	public static final String CODIGO_ARGUMENTO_DDJJ_SIT_EMERGENCIA = "02";

	//http://api.sunat.peru/v1/contribuyente/registro/e/contribuyentes/20100238234/comprobantes
	//http://insi.sunat.gob.pe/cl-ti-iaconsultaruc-ws/contribuyentes/
	// URL RESTFULL
	public static final String URL_DESARROLLO_CONTRIBUYENTE = "http://api.sunat.peru/v1/contribuyente/registro/e/contribuyentes/";
	public static final String URL_DESARROLLO_COMPROBANTE = "http://api.sunat.peru/v1/contribuyente/registro/e/comprobantes?numRuc=";
	public static final String URL_PRODUCCION = "";

	public static final String RUTA_ARCHIVO_DATA0 = "/data0";
	public static final String RUTA__ARCHIVO_DATA0_TEM = "/data0/tempo";
	public static final String APLICACION_SERVICIOS = "VIATICOS WEB";
	public static final String MODULO_VIATICOS = "VIATICOS";
	public static final String GASTO_INSTACION_TRASLADO = "GASTOS DE INSTALACION POR TRASLADO";
	public static final String DESCRIPCION_ARCHIVO_VIATICOS = "Archivos Adjuntos de viaticos";
	public static final String DESCRIPCION_ARCHIVO_REEMBOLSOS = "Archivos Adjuntos de reembolsos";
	
	// TIPOS DE ARCHIVOS ADJUNTOS
	public static final String TIPO_ARCHIVO_SOLICITUD_VIATICO = "SOLICITUD DE VIATICO";
	public static final String TIPO_ARCHIVO_SOLICITUD_REEMBOLSO = "SOLICITUD DE REEMBOLSO";
	public static final String TIPO_ARCHIVO_AUTORIZACION_COMISION = "AUTORIZACION DE COMISION";
	public static final String TIPO_ARCHIVO_JUSTIFICACION_TRASLAPE_COMISION= "JUSTIFICACION TRASLAPE COMISION";
	public static final String TIPO_ARCHIVO_RESOLUCION_COMISION_INTERNACIONAL = "RESOLUCION COMISION INTERNACIONAL";
	public static final String TIPO_ARCHIVO_JUSTIFICACION_AMPLIACION_DIAS_COMISION = "JUSTIFICACION PARA REGISTRO DE COMISIONES >15 DIAS";
	public static final String TIPO_ARCHIVO_BOLETA_DEPOSITO = "BOLETA  DE DEPOSITO";
	public static final String TIPO_ARCHIVO_OTROS = "OTROS";
	
	public static final String DESC_TIPO_ARCHIVO_SOLICITUD_VIATICO = "SOLICITUD DE VIATICO";
	public static final String DESC_TIPO_ARCHIVO_SOLICITUD_REEMBOLSO = "SOLICITUD DE REEMBOLSO";
	public static final String DESC_TIPO_ARCHIVO_AUTORIZACION_COMISION = "AUTORIZACION DE COMISION";
	public static final String DESC_TIPO_ARCHIVO_JUSTIFICACION_TRASLAPE_COMISION= "JUSTIFICACION TRASLAPE COMISION";
	public static final String DESC_TIPO_ARCHIVO_RESOLUCION_COMISION_INTERNACIONAL = "RESOLUCION COMISION INTERNACIONAL";
	public static final String DESC_TIPO_ARCHIVO_JUSTIFICACION_AMPLIACION_DIAS_COMISION = "JUSTIFICACION PARA REGISTRO DE COMISIONES";
	public static final String DESC_TIPO_ARCHIVO_BOLETA_DEPOSITO = "BOLETA  DE DEPOSITO";
	public static final String DESC_TIPO_ARCHIVO_OTROS = "OTROS";
	
	public static final String PAGINA_PRINCIPAL = "PRINCIPAL";
	public static final String PAGINA_SECUNDARIA = "SECUNDARIA";
	
	//CODIGO DE CONSULTA - EXITO - ERROR
	public static final String EXITO_CONSULTA = "00";
	public static final String ERROR_CONSULTA = "01";
	public static final String ERROR_CONSULTA_SIN_SEGUIMIENTO = "02";
	
	//CONCEPTO - INDICADOR
	public static final String CONCEPTO_INDICADOR_ALIMENTACION = "VA";
	public static final String CONCEPTO_INDICADOR_HOSPEDAJE = "VH";
	public static final String CONCEPTO_INDICADOR_MOVILIDAD = "VM";
	public static final String CONCEPTO_INDICADOR_TRASLADO = "VT";
	public static final String CONCEPTO_INDICADOR_PASAJE = "P";
	public static final String CONCEPTO_INDICADOR_TUUA = "T";
	
	//PAGES
	public static final String REPORTE_ERROR_PAGE = "general/errorReportePage";

	// CCP
	public static final String CCP_SISTEMA_VIATICOS = "V";
	public static final String CCP_SISTEMA_VIATICOS_OK = "1";
	public static final String CCP_SISTEMA_VIATICOS_ERROR = "0";
	
	public static final String TIPO_DOCUMENTO_PLANILLA = "043";
	public static final String TIPO_DOCUMENTO_RENDICION = "048";
	public static final String TIPO_DOCUMENTO_DECLARACION_RENDICION = "907";
	
	public static final Integer ID_PLANTILLA_VIATICO_NACIONAL = 553;
	public static final Integer ID_PLANTILLA_VIATICO_INTERNACIONAL = 554;
	public static final Integer ID_PLANTILLA_VIATICO_RENDICION = 555;
	public static final Integer ID_PLANTILLA_VIATICO_DECLARACION_JURADA = 556;
	public static final Integer ID_PLANTILLA_VIATICO_DECLARACION_JURADA_PERMANENCIA = 557;
	
	public static final String CODIGO_DEPENDENCIA_NORMATIVA_VIATICOS = "4821";
	
	// TIPO DE CONFIGURACION APLICATIVO (PARAMETRO 3200)
	public static final String DIAS_SEGUNDA_NOTIFICACION_CODIGO_PARAMETRO = "3305";
	public static final String DIAS_SEGUNDA_NOTIFICACION = "01";
	
}









