package pe.gob.sunat.recurso2.financiera.siga.viatico.util;

public class RendicionConstantes {
	
	//PAGES
	public static final String CONSULTAR_BANDEJA_RENDICION_VIATICO_PAGE = "rendicion/consultarBandejaRendicion";
	public static final String REGISTRAR_MODIFICAR_RENDICION_VIATICO_PAGE = "rendicion/registrar/registrarModificarRendicion";
	public static final String CONSULTAR_RENDICION_BANDEJA_VIATICO_PAGE = "rendicion/consultar/consultarRendicionBandeja";
	public static final String REVISAR_RENDICION_BANDEJA_VIATICO_PAGE = "rendicion/revisar/revisarRendicionBandeja";
	public static final String CONSULTAR_RENDICION_VIATICO_PAGE = "rendicion/consultar/consultarRendicion";
	public static final String NOTIFICAR_RENDICION_BANDEJA_VIATICO_PAGE = "rendicion/revisar/notificarRendicionBandeja";
	
	//PARAMETROS
	public static final String NOMTABLA_ESTADOS_RENDICION = "PLAN_VIAJE_WEB_REN";

	//GENERALES
	public static final String BUSCAR_FILTRO = "0";
	public static final String PARAMETRO_CANAL_ATENCION = "3230";
	public static final String TIPO_CANAL_ATENCION = "D";
	public static final String APLICACION = "LOGISTICA";
	public static final String MODULO = "RQNP";

	//VARIABLES
	public static final String CADENA_VACIA = "";
	public static final String ESPACIO = " ";
	public static final String GUION = "-";
	public static final String CERO = "0";
	public static final String UNO = "1";
	public static final String DOS_PUNTOS = ":";
	public static final String CODIGO_00 = "00";
	public static final String DATE_FORMAT_DDMMYYYY = "dd/MM/yyyy";
	public static final String DATE_FORMAT_HHMM = "HH:mm";
	public static final Integer NUMERO_CERO = 0;
	public static final Integer NUMERO_UNO = 1;
	
	//ESTADO DEL EMPLEADO
	public static final String DESCRIPCION_ESTADO_ACTIVO = "ACTIVO";
	public static final String DESCRIPCION_ESTADO_INACTIVO = "INACTIVO";
	
	public static final String TIPO_CAMBIO_SOLES = "1";
	public static final String MONEDA_SOLES = "S/.";
	public static final String MONEDA_DOLARES = "US$";
	public static final String TOTAL = "TOTAL";
	
	public static final String INDICADOR_DIAS = "0";
	public static final String INDICADOR_HORAS = "1";
	public static final String FLAG_BOLETA_DEPOSITO_VIATICOS = "V";
	
	public static final String INDICADOR_EXT_DDJJ_NO = "0";
	public static final String INDICADOR_EXT_DDJJ_SI = "1";
	public static final String INDICADOR_MEN_GAST_NO = "N";
	public static final String INDICADOR_MEN_GAST_SI = "S";
	
	//CODIGO DE OPERACION - EXITO - ERROR
	public static final String EXITO_OPERACION = "00";
	public static final String ERROR_OPERACION_NO_EXISTE_ARCHIVO_ADJUNTO = "01";
	public static final String ERROR_OPERACION = "02";
	
	//CODIGO DE OPERACION - EXITO - ERROR
	public static final String EXITO_CONSULTA = "00";
	public static final String ERROR_CONSULTA = "01";
	public static final String ERROR_CONSULTA_NO_EXISTE_PLANILLA = "02";
	
	//ESTADOS DE RENDICION
	public static final String ESTADO_RENDICION_PENDIENTE = "01";
	public static final String ESTADO_RENDICION_CERRADO = "02";
	public static final String ESTADO_RENDICION_OBSERVADO = "03";
	
	public static final String ESTADO_RENDICION_ENVIADO_CAJACHICA = "02";//Se actualizó el estado
	public static final String ESTADO_RENDICION_ENVIADO_FINANCIERA = "05";
	public static final String ESTADO_RENDICION_ENVIADO_OSA = "06";
	
	//ESTADOS DE RENDICION - DESCRIPCION
	public static final String DESCRIPCION_ESTADO_RENDICION_CERRADO = "Cerrado";
	
	//TIPO DESTINO
	public static final String TIPO_DESTINO_NACIONAL = "01";
	public static final String TIPO_DESTINO_INTERNACIONAL = "02";
	
	//TIPO DESTINO
	public static final String DESCRIPCION_TIPO_DESTINO_NACIONAL = "NACIONAL";
	public static final String DESCRIPCION_TIPO_DESTINO_INTERNACIONAL = "INTERNACIONAL";
	
	//ASIGNACION VIATICO
	public static final String CODIGO_ASIGNACION_VIATICO_NACIONAL = "01";
	public static final String CODIGO_ASIGNACION_VIATICO_INTERNACIONAL = "12";
	
	//PERFIL
	public static final String PERFIL_REGISTRADOR = "registrador";
	
	//PAGE - CALLER
	public static final String PAGE_CALLER_BANDEJA_RENDICION_REVISION = "01";
	public static final String PAGE_CALLER_BANDEJA_RENDICION_CONSULTA = "02";
	public static final String PAGE_CALLER_BANDEJA_RENDICION_NOTIFICACION = "03";
	
	//PROCESO - VIATICO
	public static final String PROCESO_MANUAL = "01";
	public static final String PROCESO_AUTOMATICO = "02";
	
	//PROPERTIES
	public static final String MENSAJE_ERROR_GENERICO = "error.mensaje.generico";
	public static final String MENSAJE_ERROR_ACCESO = "error.mensaje.acceso";
	public static final String MENSAJE_ERROR_PLANILLA_NO_EXISTE = "error.mensaje.nroPlanillaNoExiste";
	public static final String MENSAJE_REGISTRO_RENDICION_EXITOSO = "registrarModificarRendicion.message.grabacionExitosa";
	public static final String MENSAJE_CIERRE_RENDICION_EXITOSO = "registrarModificarRendicion.message.cierreExitoso";
	public static final String MENSAJE_CIERRE_RENDICION_EXITOSO_CAJA = "registrarModificarRendicion.message.cierreExitosoCajaChica";
	public static final String MENSAJE_CIERRE_RENDICION_EXITOSO_FINANZAS = "registrarModificarRendicion.message.cierreExitosoFinanciera";
	
	public static final String MENSAJE_OPERACION_EXITOSA = "registrarModificarRendicion.message.operacionExitosa";
	public static final String MENSAJE_BOLETA_DEPOSITO_REGISTRO_EXITOSO = "registrarBoletaDeposito.message.registroVoucherExitoso";
	public static final String MENSAJE_BOLETA_DEPOSITO_COMPLETAR_CAMPOS = "registrarBoletaDeposito.messageError.completarCampos";
	public static final String MENSAJE_BOLETA_DEPOSITO_OPERACION_DUPLICADA = "registrarBoletaDeposito.messageError.operacionDuplicada";
	public static final String MENSAJE_ADJUNTAR_DOCUMENTO = "registrarModificarRendicion.messageError.adjuntarDocumentoRendicion";
	public static final String MENSAJE_ADJUNTAR_VOUCHER = "registrarModificarRendicion.messageError.adjuntarVoucherDeposito";
	public static final String MENSAJE_DDJJ_SUPERA_PORCENTAJE = "registrarModificarRendicion.messageError.ddjjSuperaPorcentaje";
	public static final String MENSAJE_DDJJ_VIATICO_UNICA = "registrarModificarRendicion.messageError.ddjjViaticoUnica";
	public static final String MENSAJE_RENDICION_INCOMPLETA = "registrarModificarRendicion.messageError.rendicionIncompleta";
	public static final String MENSAJE_REGISTRAR_DOCUMENTOS = "registrarModificarRendicion.messageError.registrarDocumentos";
	public static final String MENSAJE_MONTO_DIFERENTE = "registrarModificarRendicion.messageError.montoRegistradoDiferente";
	public static final String MENSAJE_MONTO_DIARIO_MAYOR_TOPE_DIARIO = "registrarModificarRendicion.messageError.montoRendidoDiarioMayorTopeDiario";
	
	//EXCEL
	public static final String ARCHIVO_EXCEL_PREFIJO = "Rendicion_";
	public static final String ARCHIVO_EXCEL_EXTENSION = ".xls";
	
	public static final String CODIGO_EJECUCION_DERIVA_OSA_OK = "00";
	public static final String CODIGO_ESTADO_DERIVA_OSA = "06";
	public static final String CODIGO_ESTADO_DERIVA_PRESUPUESTO = "05";
	
}