package pe.gob.sunat.recurso2.financiera.siga.viatico.rendicion.service;

import java.util.ArrayList;
import java.util.Date;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;

/**
 * Interface RevisionRendicionService, contiene los metodos para la revision de una rendicion.
 * @author Jorge Ponce.
 */
public interface RevisionRendicionService {
	
	/**
	 * Metodo que permite anular el envio de una solicitud.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @return Codigo de operacion: Exito(00) - Error(01).
	 * @see    String
	 * @throws Exception
	 */
	String anularEnvioPlanViaje(String codPlanViaje, String nroRegistro) throws Exception;
	
	/**
	 * Metodo que permite reprogramar la fecha de rendicion.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @param  fecMaxRend :fecha maxima de rendicion.
	 * @param  descripcionJustRep :justtificacion de la reprogramacion.
	 * @return Codigo de operacion: Exito(00) - Error(01).
	 * @see    String
	 * @throws Exception
	 */
	//JMCR-ME Fecha Reprogramacion
	String reprogramarFechaRendicion(String codPlanViaje, Date fecReprog, String descripcionJustRep, String codEmpReprog, String userModi, Date fechModi) throws Exception;
	//JMCR-ME Fecha Reprogramacion
	
	/**
	 * Metodo que permite obtener el listado de plan de viaje que se van a mostrar en la bandeja de notificacion de rendicion.
	 * @author Jorge Ponce.
	 * @param  codigoDependencia :codigo de dependencia.
	 * @param  indicadorCanalAtencion :indicador canal de atencion.
	 * @param  fechaHasta :fecha hasta.
	 * @return Listado de plan de viaje.
	 * @see    PlanViajeBean
	 * @throws DataAccessException
	 */
	ArrayList<PlanViajeBean> obtenerPlanViajeToBandejaNotificacionRendicion(String codigoDependencia, String indicadorCanalAtencion, Date fechaHasta) throws Exception;
	
	/**
	 * Metodo que permite enviar la segunda notificacion a un listado de rendiciones.
	 * @author Jorge Ponce.
	 * @param  planViajeList :Listado de plan viaje a ser notificadas.
	 * @return Codigo de operacion: Exito(00) - Error(01).
	 * @see    String
	 * @throws Exception
	 */
	String enviarSegundaNotificacionRendicion(ArrayList<PlanViajeBean> planViajeList, String codEmpNotif) throws Exception;
}
