package pe.gob.sunat.recurso2.financiera.siga.viatico.util;

public class SolicitudConstantes {

	// GENERALES
	public static final String BUSCAR_FILTRO = "0";
	public static final String PARAMETRO_CANAL_ATENCION = "3230";
	public static final String TIPO_CANAL_ATENCION = "D";
	public static final String APLICACION = "LOGISTICA";
	public static final String MODULO = "RQNP";

	// PAGE
	public static final String ALTA_SOLICITUD_BANDEJA_PAGE = "solicitud/altaSolicitudBandeja";
	public static final String REVISAR_SOLICITUD_BANDEJA_PAGE = "solicitud/revisarSolicitudBandeja";
	public static final String CONSULTAR_SOLICITUD_BANDEJA_PAGE = "solicitud/consultarSolicitudBandeja";
	public static final String AUTORIZAR_SOLICITUD_VIATICO_PAGE = "solicitud/autorizarBandejaSolicitud";
	public static final String REGISTRAR_SOLICITUD_VIATICO_PAGE = "solicitud/registrar/registrarModificarSolicitud";
	public static final String REVISAR_SOLICITUD_AUTORIZADOR_PAGE = "solicitud/revisar/revisarSolicitudAutorizador";
	public static final String VALIDACION_VIATICO_PAGE = "solicitud/validacionViatico";

	// VARIABLES
	public static final String CADENA_VACIA = "";
	public static final String CERO = "0";
	public static final String UNO = "1";
	public static final String DOS_PUNTOS = ":";
	public static final String DATE_FORMAT_HHMM = "HH:mm";
	public static final String CODIGO_00 = "00";
	public static final String DATE_FORMAT_DDMMYYYY = "dd/MM/yyyy";

	// ESTADO DEL EMPLEADO
	public static final String DESCRIPCION_ESTADO_ACTIVO = "ACTIVO";
	public static final String DESCRIPCION_ESTADO_INACTIVO = "INACTIVO";

	//CANAL ATENCION
	public static final String CANAL_ATENCION_CAJA_CHICA = "C";
	public static final String CANAL_ATENCION_ABONO_CUENTA = "R";
	
	//TIPO DESTINO
	public static final String TIPO_DESTINO_NACIONAL = "01";
	public static final String TIPO_DESTINO_INTERNACIONAL = "02";
	
	//TIPO DESTINO
	public static final String DESCRIPCION_TIPO_DESTINO_NACIONAL = "NACIONAL";
	public static final String DESCRIPCION_TIPO_DESTINO_INTERNACIONAL = "INTERNACIONAL";
	
	//CODIGO DE OPERACION - EXITO - ERROR
	public static final String EXITO_OPERACION = "00";
	public static final String ERROR_OPERACION = "01";
	public static final String ERROR_OPERACION_CODIGO_PLANILLA_NO_EXISTE = "03";
	public static final String ERROR_OPERACION_PLANILLA_NO_TIENE_EXPEDIENTE = "04";
	
	//CODIGO DE CONSULTA - EXITO - ERROR
	public static final String EXITO_CONSULTA = "00";
	public static final String ERROR_CONSULTA = "01";
	public static final String ERROR_CONSULTA_NO_EXISTE_PLANILLA = "02";
	
	//PERFIL
	public static final String PERFIL_AUTORIZADOR = "autorizador";
	
	//PROPERTIES
	public static final String MENSAJE_ERROR_GENERICO = "error.mensaje.generico";
	public static final String MENSAJE_ERROR_ACCESO = "error.mensaje.acceso";
	public static final String MENSAJE_ERROR_PLANILLA_NO_EXISTE = "error.mensaje.nroPlanillaNoExiste";
	
	public static final String MENSAJE_ERROR_ANULAR_DOCUMENTO_PLANILLA_NO_EXISTE = "anularDocumento.messageError.planillaNoExiste";
	public static final String MENSAJE_ERROR_ANULAR_DOCUMENTO_PLANILLA_NO_TIENE_EXPEDIENTE = "anularDocumento.messageError.planillaNoTieneExpediente";
	
	//EXCEL
	public static final String ARCHIVO_EXCEL_PREFIJO = "Solicitud_";
	public static final String ARCHIVO_EXCEL_EXTENSION = ".xls";
}