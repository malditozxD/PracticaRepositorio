package pe.gob.sunat.recurso2.financiera.siga.viatico.util;

public class ReembolsoConstantes {

	// PAGE
//	public static final String ALTA_SOLICITUD_BANDEJA_PAGE = "reembolso/altaSolicitudBandeja";
	public static final String REVISAR_REEMBOLSO_BANDEJA_PAGE = "reembolso/revisarReembolsoBandeja";
	public static final String CONSULTAR_REEMBOLSO_BANDEJA_PAGE = "reembolso/consultarReembolsoBandeja";
//	public static final String AUTORIZAR_SOLICITUD_VIATICO_PAGE = "reembolso/autorizarBandejaSolicitud";
	public static final String REGISTRAR_SOLICITUD_VIATICO_PAGE = "reembolso/registrar/registrarModificarReembolso";
	public static final String CONSULTAR_SOLICITUD_VIATICO_PAGE = "reembolso/consultar/consultarReembolso";
//	public static final String REVISAR_SOLICITUD_AUTORIZADOR_PAGE = "reembolso/revisar/revisarSolicitudAutorizador";
	public static final String SUSTENTAR_GASTO_REEMBOLSO_PAGE = "reembolso/registrar/sustentarGastoReembolso";
	public static final String CONSULTAR_GASTO_REEMBOLSO_PAGE = "reembolso/consultar/consultarGastoReembolso";
	public static final String REVISAR_REEMBOLSO_AUTORIZADOR_PAGE = "reembolso/revisar/revisarReembolsoAutorizador";
	
	// VARIABLES
	public static final String CADENA_VACIA = "";
	public static final String CERO = "0";
	public static final String UNO = "1";
	public static final String DOS_PUNTOS = ":";
	public static final String DATE_FORMAT_HHMM = "HH:mm";
	public static final String CODIGO_00 = "00";
	public static final String DATE_FORMAT_DDMMYYYY = "dd/MM/yyyy";
	public static final String MONEDA_SOLES = "S/.";
	public static final String MONEDA_DOLARES = "US$";
	public static final String TOTAL = "TOTAL";
	public static final String INDICADOR_EXT_DDJJ_NO = "0";
	public static final String INDICADOR_EXT_DDJJ_SI = "1";
	
	//CODIGO DE OPERACION - EXITO - ERROR
	public static final String EXITO_OPERACION = "00";
	public static final String ERROR_OPERACION = "01";
	
	//CODIGO DE CONSULTA - EXITO - ERROR
	public static final String EXITO_CONSULTA = "00";
	public static final String ERROR_CONSULTA = "01";
	public static final String ERROR_CONSULTA_NO_EXISTE_SOLICITUD = "02";
	
	//PERFIL
	public static final String PERFIL_AUTORIZADOR = "autorizador";
	
	//PROPERTIES
	public static final String MENSAJE_ERROR_GENERICO = "error.mensaje.generico";
	public static final String MENSAJE_ERROR_ACCESO = "error.mensaje.acceso";
	public static final String MENSAJE_ERROR_SOLICITUD_NO_EXISTE = "error.mensaje.nroSolicitudNoExiste";
	public static final String MENSAJE_REGISTRO_SUSTENTO_GASTO_EXITOSO = "sustentarGastoReembolso.message.grabacionExitosa";
	public static final String MENSAJE_MONTO_COMPROBANTE_GASTO_MAYOR_ASIGNADO = "sustentarGastoReembolso.messageError.montoComprobanteGastoMayorMontoAsignado";
	
	//EXCEL
	public static final String ARCHIVO_EXCEL_PREFIJO = "Reembolso_";
	public static final String ARCHIVO_EXCEL_EXTENSION = ".xls";

}