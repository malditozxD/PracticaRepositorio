package pe.gob.sunat.recurso2.financiera.siga.viatico.util;

import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ColaboradorViaticoBean;

public class MaestroPersonalUtil {

	public static ColaboradorViaticoBean parseViatico(MaestroPersonalBean maestro) {

		ColaboradorViaticoBean colaborador = new ColaboradorViaticoBean();
		if (maestro != null) {
			colaborador.setCodigoEmpleado(maestro.getCodigoEmpleado());
			colaborador.setNombreCompleto(maestro.getNombre_completo());
			colaborador.setNumeroRegistro(maestro.getNumero_registro());
			colaborador.setCorreoElectronico(maestro.getCorreo());
			colaborador.setCodigoDependencia(maestro.getCodigoDependencia());
			colaborador.setNombreDependencia(maestro.getDependencia());
			colaborador.setUuoo(maestro.getUuoo());
			colaborador.setCodigoSede(maestro.getCodigoSede());
			colaborador.setDni(maestro.getDni());
			colaborador.setCodigoNivel(maestro.getCodigoNivel());
		}
		return colaborador;
	}

}
