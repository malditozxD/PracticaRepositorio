package pe.gob.sunat.recurso2.financiera.siga.viatico.aop;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.AfterReturningAdvice;
import org.springframework.aop.MethodBeforeAdvice;
import org.springframework.aop.ThrowsAdvice;

import pe.gob.sunat.recurso2.administracion.siga.registro.model.dao.AccesoDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.AuditoriaUtil;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

public class AccesoAdvice implements MethodBeforeAdvice, AfterReturningAdvice, ThrowsAdvice {

	protected final Log log = LogFactory.getLog(getClass());

	private AccesoDAO accesoDAO;

	public AccesoDAO getAccesoDAO() {
		return accesoDAO;
	}

	public void setAccesoDAO(AccesoDAO accesoDAO) {
		this.accesoDAO = accesoDAO;
	}

	/**
	 * Aspecto ejecutado antes de la ejecucion del servicio de grabacion
	 * */
	public void before(Method metodoEjecutado, Object[] argumentos, Object instancia) throws Throwable {
		// TODO Auto-generated method stub
		UsuarioBean usuarioBean = AuditoriaUtil.get();
		log.info("Iniciando metodo AccesoAdvice.before(...) con usuario:" + usuarioBean.getLogin());

		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("codVariable", "USER");
		parametros.put("valVariable", usuarioBean.getLogin().toUpperCase());
		log.info("datos a enviar para setear entorno:" + parametros);
		accesoDAO.setearVariableEntorno(parametros);
		log.info("metodo AccesoAdvice.before(...) terminado.");
	}

	/**
	 * Aspecto ejecutado luego de la ejecucion del servicio de grabacion
	 * */
	public void afterReturning(Object retorno, Method metodo, Object[] argumentos, Object instancia) throws Throwable {
		log.info("Iniciando metodo AccesoAdvice.afterReturning(...) para limpiar la variable de sesion");
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("codVariable", "USER");
		accesoDAO.limpiarVariableEntorno(parametros);
		log.info("metodo AccesoAdvice.afterReturning(...) terminado.");
	}

	/**
	 * Aspecto ejecutado si el servicio de grabacion a retornado un
	 * */
	public void afterThrowing(Method metodo, Object[] argumentos, Object instancia, Exception exception) {
		log.info("Iniciando metodo AccesoAdvice.afterThrowing(...) para limpiar la variable de sesion");
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("codVariable", "USER");
		accesoDAO.limpiarVariableEntorno(parametros);
		log.info("metodo AccesoAdvice.afterThrowing(...) terminado.");
	}

}
