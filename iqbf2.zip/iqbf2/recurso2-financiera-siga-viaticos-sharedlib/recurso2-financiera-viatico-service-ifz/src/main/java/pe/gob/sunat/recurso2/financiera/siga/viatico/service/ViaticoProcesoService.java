package pe.gob.sunat.recurso2.financiera.siga.viatico.service;


public interface ViaticoProcesoService {

	/**
	 * Metodo que permite enviar notificacion electronica a comisionado, registrador y registrador Universal 
	 * @author Yoney Ayala.
	 * @throws Exception
	 */
	public void obtenerListaEstadosSolicitudPendienteViatico();
	
	/**
	 * Metodo que envia notificacion electronica a comisionados que no cumplan con presentar la rendición de Planillas de viaticos en el plazo establecido adicional 
	 * 
	 * @author Yoney Ayala
	 * @throws Exception
	 */	
	public void obtenerListaViaticoDiasAdicional();

	/**
	 * Metodo que envia notificacion electronica a al comisionado, registrador cuando las planillas de viaticos que no han sido remitidas para la gestion del pago en 30 dias calendarios
	 * 
	 * @author Yoney Ayala
	 * @throws Exception
	 */
	public void obtenerListaViaticoPlazoExcedido();

	/**
	 * Metodo que actualiza e envia notificaciones electronica al comisionado y registrado
	 * 
	 * @author Yoney Ayala
	 * @throws Exception
	 */	
	public void obtenerListaViaticoPlazoExcedidoGlobal();
		
}
