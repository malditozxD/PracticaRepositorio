package pe.gob.sunat.recurso2.financiera.siga.viatico.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.PrgAnnoBean;
import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.T01ParametroBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.CuentaCorrienteBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.LicenciaBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ClaveValorBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.MetasBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeRendicionBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.RutaTipoTarifaBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.TXXX8LugarUbigeoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.TipoDocumentoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.VacacionBean;

public interface ViaticoGeneralService {

	Long determinarRegistrador(String codEmp) throws Exception;
	Long determinarRegistradorUniversal(String codEmp) throws Exception;

	List<PrgAnnoBean> listarAnios() throws Exception;

	/**
	 * Metodo que permite buscar un lugar nacional a partir de su codigo.
	 * 
	 * @author Juan Farro
	 * @param codigoLugar codigo de lugar
	 * @return lugar
	 * @throws Exception
	 * @see TXXX8LugarUbigeoBean
	 */
	TXXX8LugarUbigeoBean obtenerLugarByCodigoLugarNacional(String codigoLugar) throws Exception;
	
	/**
	 * Metodo que permite buscar un lugar internacional a partir de su codigo.
	 * 
	 * @author Juan Farro
	 * @param codigoLugar codigo de lugar
	 * @return lugar
	 * @throws Exception
	 * @see TXXX8LugarUbigeoBean
	 */
	TXXX8LugarUbigeoBean obtenerLugarByCodigoLugarInternacional(String codigoLugar) throws Exception;	
	

	/**
	 * Metodo que permite buscar un lugares a partir del codigo de departamento y codigo de provincia
	 * 
	 * @author Juan Farro
	 * @param codigoDepartamento codigo departamento
	 * @param codigoProvincia codigo provincia
	 * @return lista de lugares
	 * @throws Exception
	 * @see TXXX8LugarUbigeoBean
	 */
	List<TXXX8LugarUbigeoBean> obtenerLugaresByCodigo(String codigoDepartamento, String codigoProvincia) throws Exception;

	/**
	 * Metodo que permite buscar un lugar a partir de su codigo.
	 * 
	 * @author Juan Farro
	 * @param descripcionDepartamento descripcion departamento
	 * @param descripcionProvincia descripcion provincia
	 * @param descripcionLugar descripcion lugar
	 * @return lista de lugares
	 * @throws Exception
	 * @see TXXX8LugarUbigeoBean
	 */
	List<TXXX8LugarUbigeoBean> obtenerLugaresByDescripcion(String descripcionDepartamento, String descripcionProvincia, String descripcionLugar) throws Exception;

	/**
	 * Metodo que permite listar las vacaciones de un colaborador.
	 * 
	 * @author Juan Farro
	 * @param codigoDependencia codigo de dependencia
	 * @param anioEjecucion anio de ejecucion
	 * @param ordenarPor indicador de ordenacion
	 * @return lista de metas
	 * @throws Exception
	 * @see MetasBean
	 */
	List<MetasBean> obtenerMetas(String codigoDependencia, String anioEjecucion, String ordenarPor) throws Exception;

	MetasBean obtenerMeta(String codigoDependencia, String anioEjecucion) throws Exception;

	/**
	 * Metodo que permite listar las vacaciones de un colaborador.
	 * 
	 * @author Juan Farro
	 * @param parametros de busqueda
	 * @return lista de vacaciones
	 * @throws Exception
	 * @see VacacionBean
	 */
	List<VacacionBean> listarVacaciones(Map<String, Object> params) throws Exception;

	/**
	 * Metodo que permite listar las licencias de un colaborador.
	 * 
	 * @author Juan Farro
	 * @param parametros de busqueda
	 * @return lista de licencias
	 * @throws Exception
	 * @see LicenciaBean
	 */
	List<LicenciaBean> listarLicencias(Map<String, Object> params) throws Exception;

	/**
	 * Metodo que permite listar las compensaciones de un colaborador.
	 * 
	 * @author Juan Farro
	 * @param parametros de busqueda
	 * @return lista de compensaciones
	 * @throws Exception
	 * @see LicenciaBean
	 */
	List<LicenciaBean> listarCompensacion(Map<String, Object> params) throws Exception;

	/**
	 * Metodo que permite obtener los lugares (lugar, dias de traslado, codigo de ubigo).
	 * 
	 * @author Juan Farro
	 * @return lista de lugares
	 * @throws Exception
	 * @see TXXX8LugarUbigeoBean
	 */
	List<TXXX8LugarUbigeoBean> obtenerRutasLugares() throws Exception;

	/**
	 * Metodo que permite obtener los tarifas (tarifario, porcentaje).
	 * 
	 * @author Juan Farro
	 * @return lista de tarifas
	 * @throws Exception
	 * @see RutaTipoTarifaBean
	 */
	List<RutaTipoTarifaBean> obtenerRutasTipoTarifas() throws Exception;

	/**
	 * Metodo que permite obtener los medios de transporte
	 * 
	 * @author Juan Farro
	 * @return lista de medios de transporte
	 * @throws Exception
	 * @see ClaveValorBean
	 */
	List<ClaveValorBean> obtenerMediosTransporte() throws Exception;

	/**
	 * Metodo que permite obtener un medio de transporte.
	 * 
	 * @author Juan Farro
	 * @param codMedioTransporte codigo medio de transporte
	 * @return medio de transporte
	 * @throws Exception
	 * @see ClaveValorBean
	 */
	ClaveValorBean obtenerMedioTransporte(String codMedioTransporte) throws Exception;

	/**
	 * Metodo que permite obtener los motivos de ampliacion de comision
	 * 
	 * @author Juan Farro
	 * @return lista de motivos ampliacion comision
	 * @throws Exception
	 * @see ClaveValorBean
	 */
	List<ClaveValorBean> obtenerMotivosAmpliacionComision() throws Exception;	
	
	ArrayList<CuentaCorrienteBean> obtenerCuentasCorriente(String tipoDestino) throws Exception;

	ArrayList<TipoDocumentoBean> obtenerTipoDocumentoToComprobante() throws Exception;
	
	/**
	 * Metodo que permite obtener el listado de tipo documento declaracion.
	 * @author Jorge Ponce.
	 * @return Listado de tipo documento.
	 * @see    TipoDocumentoBean
	 * @throws Exception
	 */
	ArrayList<TipoDocumentoBean> obtenerTipoDocumentoDeclaracion() throws Exception;

	
	/**
	 * Metodo que permite obtener verdadero / falso si se repite el tipo documento, serie y numero documento
	 * 
	 * @author Samuel Donisio.
	 * @param planViajeRendicion : PlanViajeRendicionBean para el envio de data.
	 * @return boolean.
	 * @see Boolean
	 * @throws Exception
	 */
	Boolean validarNumeroDocumento(PlanViajeRendicionBean planViajeRendicion) throws Exception;
	
	
	/**
	 * Recuperar Contratista .Padron
	 * 
	 * @author emarchena.
	 * @param String : RUC de proveedor
	 * @return String.
	 * @see String
	 * @throws Exception
	 */
	String validarPadronRUC(String ruc) throws Exception;
	
	/**
	 * Metodo que permite obtener un parametro de viaticos.
	 * @author Jorge Ponce.
	 * @param  codParametro :codigo parametro.
	 * @param  codArgumento :codigo argumento.
	 * @return Parametro de viaticos.
	 * @see    T01ParametroBean
	 * @throws Exception
	 */
	T01ParametroBean obtenerParametroViatico(String codParametro, String codArgumento) throws Exception;
	
	
	Boolean existeRendicion(PlanViajeRendicionBean planViajeRendicion) throws Exception;
}
