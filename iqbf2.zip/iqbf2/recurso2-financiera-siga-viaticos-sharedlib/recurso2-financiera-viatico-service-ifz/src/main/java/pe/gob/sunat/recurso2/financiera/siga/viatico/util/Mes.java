package pe.gob.sunat.recurso2.financiera.siga.viatico.util;

public class Mes {

	private String codigoMes;
	private String descripcionMes;

	public String getCodigoMes() {
		return codigoMes;
	}

	public void setCodigoMes(String codigoMes) {
		this.codigoMes = codigoMes;
	}

	public String getDescripcionMes() {
		return descripcionMes;
	}

	public void setDescripcionMes(String descripcionMes) {
		this.descripcionMes = descripcionMes;
	}

}
