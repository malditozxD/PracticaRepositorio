package pe.gob.sunat.recurso2.financiera.siga.viatico.service;

import java.util.ArrayList;
import java.util.List;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeInformeDistribBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeRendicionBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.SolicitudDTO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dto.DocumentoSustentarioDTO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dto.ViaticoValidate;

/**
 * @author Samuel Dionisio
 * */
public interface ViaticoConsultaService {
	
	/**
	 * Metodo que permite determinar si existe en BD un codigo de planilla.
	 * @author Juan Farro
	 * @param codPlanilla codigo de planilla
	 * @return true si codigo de planilla existe en BD
	 * @throws Exception
	 */
	boolean existePlanilla(String codPlanilla) throws Exception;
	
	/**
	 * Metodo que permite obtener los datos de plan viaje para el envio de notificacion.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @return Objeto PlanViajeBean.
	 * @see    SolicitudDTO
	 * @throws Exception
	 */
	SolicitudDTO obtenerPlanViajeToNotificacion(String codPlanViaje);
	
	/**
	 * Metodo que permite obtener los datos de plan viaje para el envio de notificacion.
	 * @author Samuel Dionisio.
	 * @param  codPlanViaje : codigo plan viaje.
	 * @return Objeto PlanViajeBean.
	 * @see    SolicitudDTO
	 * @throws Exception
	 */
	SolicitudDTO obtenerPlanViajeToNotificacion(String codPlanViaje, List<PlanViajeBean> planViajeList);
	
	/**
	 * Metodo que obtiene listas, clases para la informacion del documento sustentario.
	 * 
	 * @author Samuel Donisio.
	 * @param codPlanViaje : String.
	 * @param secuencia : String.
	 * @return mensaje de error o exito.
	 * @see DocumentoSustentarioDTO
	 * @throws Exception
	 */
	DocumentoSustentarioDTO obtenerDocumentoSustentario(String codPlanViaje, String secuencia);
	
	/**
	 * Metodo que permite obtener los datos de plan de viaje para el seguimiento.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @return Plan de viaje.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	PlanViajeBean obtenerPlanViajeToSeguimiento(String codPlanViaje) throws Exception;
	
	/**
	 * Metodo que permite obtener el listado de plan viaje rendicion que se muestran en el registro de rendicion de la solicitud y reembolso (sustento de gasto).
	 * @author Jorge Ponce.
	 * @param  planViajeId :codigo plan viaje.
	 * @param  simboloMoneda :simbolo de la moneda.
	 * @return Listado de plan viaje rendicion.
	 * @see    PlanViajeRendicionBean
	 * @throws Exception
	 */
	ArrayList<PlanViajeRendicionBean> obtenerPlanViajeRendicionToRegistroRendicion(String planViajeId, String simboloMoneda) throws Exception;
	
	/**
	 * Metodo que permite obtener el listado de asignacion/gasto viatico.
	 * @author Jorge Ponce.
	 * @param  planViajeId :codigo plan viaje.
	 * @param  secuencial :secuencial del comprobante de pago.
	 * @param  simboloMoneda :simbolo de la moneda.
	 * @return Listado de asignacion de viatico.
	 * @see    PlanViajeInformeDistribBean
	 * @throws Exception
	 */
	ArrayList<PlanViajeInformeDistribBean> obtenerAsignacionGastoViatico(String planViajeId, Integer secuencial, String simboloMoneda) throws Exception;
	
	/**
	 * Metodo que permite obtener el listado de pasaje y tasa embarque.
	 * @author Jorge Ponce.
	 * @param  planViajeId :codigo plan viaje.
	 * @param  secuencial :secuencial del comprobante de pago.
	 * @param  simboloMoneda :simbolo de la moneda.
	 * @return Listado de pasaje y tasa embarque.
	 * @see    PlanViajeInformeDistribBean
	 * @throws Exception
	 */
	ArrayList<PlanViajeInformeDistribBean> obtenerPasajeTasaEmbarque(String planViajeId, Integer secuencial, String simboloMoneda) throws Exception;
	
	/**
	 * Metodo que permite validar el monto rendido diario.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @param  tipoDestino :tipo destino.
	 * @param  flagMenorIgual4Horas :flag menor igual 4 horas.
	 * @param  simboloMoneda :simbolo de la moneda.
	 * @return Viatico validate.
	 * @see    ViaticoValidate
	 * @throws Exception
	 */
	ViaticoValidate validarMontoRendidoDiario(String codPlanViaje, String tipoDestino, String flagMenorIgual4Horas, String simboloMoneda) throws Exception;
	
	/**
	 * Metodo que permite obtener el el flag para verificar que una rendicion/sustento es menor o igual a 4 horas.
	 * @author Jorge Ponce.
	 * @param  indicadorHoras :indicador de horas.
	 * @param  numeroHoras :numero de horas.
	 * @return Flag MenorIgual4Horas.
	 * @see    String
	 * @throws Exception
	 */
	String obtenerFlagMenorIgual4Horas(String indicadorHoras, Double numeroHoras);
	
	/**
	 * Metodo que permite obtener los datos de plan viaje para el envio de notificacion.
	 * @author Samuel Dionisio.
	 * @param  planViajeList : lista plan viaje.
	 * @return Objeto PlanViajeBean.
	 * @see    List<SolicitudDTO>
	 * @throws Exception
	 */
	List<SolicitudDTO> obtenerPlanViajeToNotificacionList(List<PlanViajeBean> planViajeList);
	
	
	ArrayList<PlanViajeRendicionBean> obtenerListadoDocumentosPlanViaje(String planViajeId) ;
	
}
