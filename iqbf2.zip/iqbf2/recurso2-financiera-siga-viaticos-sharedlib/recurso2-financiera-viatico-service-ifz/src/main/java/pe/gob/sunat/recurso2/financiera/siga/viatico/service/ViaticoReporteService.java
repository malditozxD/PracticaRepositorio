package pe.gob.sunat.recurso2.financiera.siga.viatico.service;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import pe.gob.sunat.recurso2.administracion.siga.archivo.util.ReporteArchivoBean;
import pe.gob.sunat.recurso2.administracion.siga.archivo.util.ReporteJasperBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.NivelBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;

public interface ViaticoReporteService {



	/**
	 * Metodo que permite generar el excel para la bandeja autorizacion solicitud.
	 * @author Jorge Ponce.
	 * @param  outputStream :objeto donde se escribe los datos del excel.
	 * @param  planViajeList :listado de plan viaje.
	 * @throws Exception
	 */
	void generarExcelBandejaAutorizacionSolicitud(OutputStream outputStream, ArrayList<PlanViajeBean> planViajeList) throws Exception;
	
	/**
	 * Metodo que permite generar el excel para la bandeja rendicion.
	 * @author Jorge Ponce.
	 * @param  outputStream :objeto donde se escribe los datos del excel.
	 * @param  planViajeList :listado de plan viaje.
	 * @param  codigoPaginaCaller :codigo de pagina que llama al reporte.
	 * @throws Exception
	 */
	void generarExcelBandejaConsultaRendicion(OutputStream outputStream, ArrayList<PlanViajeBean> planViajeList, String codigoPaginaCaller) throws Exception;
	
	/**
	 * Metodo que permite generar el excel para la bandeja notificacion rendicion.
	 * @author Jorge Ponce.
	 * @param  outputStream :objeto donde se escribe los datos del excel.
	 * @param  planViajeList :listado de plan viaje.
	 * @throws Exception
	 */
	void generarExcelBandejaNotificacionRendicion(OutputStream outputStream, ArrayList<PlanViajeBean> planViajeList) throws Exception;
	
	/**
	 * Metodo que permite generar el excel para la bandeja autorizacion solicitud.
	 * @author Jorge Ponce.
	 * @param  outputStream :objeto donde se escribe los datos del excel.
	 * @param  planViajeList :listado de plan viaje.
	 * @throws Exception
	 */
	void generarExcelBandejaAutorizacionReembolso(OutputStream outputStream, ArrayList<PlanViajeBean> planViajeList) throws Exception;

	
	/**
	 * Metodo que permite generar el excel para la bandeja de solicitud de viaticos.
	 * @author Jorge Ponce.
	 * @param  outputStream :objeto donde se escribe los datos del excel.
	 * @param  planViajeList :listado de plan viaje.
	 * @param  tipoReporte :tipo de reporte
	 * @throws Exception
	 */
	void generarExcelBandejaSolicitudes(OutputStream outputStream, List<PlanViajeBean> listaSolicitudes, String tipoReporte) throws Exception;

	
	/**
	 * genera el reporte de solicitud de viaticos.
	 * @param codPlanViaje : String con el codigo de plan viaje
	 * @param modoProceso : String codigo de proceso 01 o 02
	 * @see ReporteArchivoBean
	 * @return lista de mapas para el cuerpo del reporte solicitud
	 * */
	ReporteJasperBean generarReporteSolicitudViatico(String codPlanViaje, String modoProceso) throws Exception;
	
	
	/**
	 * genera el reporte de rendicion.
	 * @param codPlanViaje : String con el codigo de plan viaje
	 * @param modoProceso : String codigo de proceso 01 o 02
	 * @see ReporteArchivoBean
	 * @return lista de mapas para el cuerpo del reporte rendicion
	 * */
	ReporteJasperBean generarReporteRendicionViatico(String codPlanViaje, String modoProceso) throws Exception;
	
	/**
	 * genera el reporte de declaracion.
	 * @param codPlanViaje : String con el codigo de plan viaje
	 * @param modoProceso : String codigo de proceso 01 o 02
	 * @see ReporteArchivoBean
	 * @return lista de mapas para el cuerpo del reporte declaracaion
	 * */
	ReporteJasperBean generarReporteRendicionDeclaracion(String codPlanViaje, String modoProceso) throws Exception;
	
	/**
	 * genera el reporte de declaracion de permanencia.
	 * @author Rocio Paz
	 * @param codPlanViaje : String con el codigo de plan viaje
	 * @param modoProceso : String codigo de proceso 01 o 02
	 * @see ReporteArchivoBean
	 * @return lista de mapas para el cuerpo del reporte declaracaion Permanencia
	 * */
	ReporteArchivoBean generarReporteRendicionDeclaracionPermanencia(String codPlanViaje, String modoProceso) throws Exception;
	
	/**
	 * genera el reporte de rendicion.
	 * @author Rocio Paz
	 * @param codPlanViaje : String con el codigo de plan viaje
	 * @param modoProceso : String codigo de proceso 01 o 02
	 * @see ReporteArchivoBean
	 * @return lista de mapas para el cuerpo del reporte rendicion
	 * */
	ReporteArchivoBean generarReporteReembolsoViatico(String codPlanViaje, String modoProceso) throws Exception;
	
	/**
	 * Metodo que permite generar el excel para la bandeja de solicitud de viaticos.
	 * @author Samuel Dionisio.
	 * @param  outputStream :objeto donde se escribe los datos del excel.
	 * @param  planViajeList :listado de plan viaje.
	 * @param  tipoReporte :tipo de reporte
	 * @throws Exception
	 */
	void generarExcelBandejaReembolsos(OutputStream outputStream, List<PlanViajeBean> listaReembolsos, String tipoReporte) throws Exception;
	
	NivelBean getNivel(String codNivel);
}
