package pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;

/**
 * Interface RevisionSolicitudService, contiene los metodos para la revision de la solicitud.
 * @author Jorge Ponce.
 */
public interface RevisionSolicitudService {
	
	/**
	 * Metodo que permite obtener el listado de planes de viaje que se van a mostrar en la bandeja de autorizacion de solicitud.
	 * @author Jorge Ponce.
	 * @param  codigoDependencia :codigo de dependencia.
	 * @param  codPlanilla :codigo de planilla.
	 * @param  codTrabajador :codigo del colaborador.
	 * @param  codEstadoSolic :codigo de estado de la solicitud.
	 * @param  indicadorCanalAtencion :indicador canal de atencion.
	 * @param  fechaDesde :fecha desde.
	 * @param  fechaHasta :fecha hasta.
	 * @param  codigoAutorizador :codigo del autorizador.
	 * @return Objeto PlanViajeBean.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	//JMCR-ME BANDEJA AUTORIZADOR se cambia el estado de la solicitud por una lista de estados  a enviar con "IN"
	ArrayList<PlanViajeBean> obtenerPlanViajeCompletoToBandejaAutorizacionSolicitud(String codigoDependencia, String codPlanilla, String codTrabajador, List<String> listCodEstadoSolic, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws Exception;
	//JMCR-ME BANDEJA AUTORIZADOR
	
	/**
	 * Metodo que permite obtener el listado de planes de viaje que se van a mostrar en la bandeja de autorizacion de solicitud.
	 * @author Jorge Ponce.
	 * @param  codigoDependencia :codigo de dependencia.
	 * @param  codPlanilla :codigo de planilla.
	 * @param  codTrabajador :codigo del colaborador.
	 * @param  codEstadoSolic :codigo de estado de la solicitud.
	 * @param  indicadorCanalAtencion :indicador canal de atencion.
	 * @param  fechaDesde :fecha desde.
	 * @param  fechaHasta :fecha hasta.
	 * @param  codigoAutorizador :codigo del autorizador.
	 * @return Objeto PlanViajeBean.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	//JMCR-ME BANDEJA AUTORIZADOR se cambia el estado de la solicitud por una lista de estados  a enviar con "IN"
	ArrayList<PlanViajeBean> obtenerPlanViajeToBandejaAutorizacionSolicitud(String codigoDependencia, String codPlanilla, String codTrabajador, List<String> listCodEstadoSolic, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws Exception;
	//JMCR-ME BANDEJA AUTORIZADOR se cambia el estado de la solicitud por una lista de estados  a enviar con "IN"
	
	/**
	 * Metodo que permite autorizar una solicitud.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @param  codPerAutoriza :codigo del autorizador.
	 * @param  codigoDependenciaAutorizador :codigo dependencia del autorizador.
	 * @param  codigoSedeAutorizador :codigo de sede del autorizador.
	 * @param  codigoNivelAutorizador :codigo nivel del autorizador.
	 * @param  expedientePlanViaje :expediente plan de viaje.
	 * @return Codigo de operacion: Exito(00) - Error(01).
	 * @see    String
	 * @throws ServiceException, Exception
	 */
	String autorizarSolicitud(String codPlanViaje, String codPerAutoriza, String codigoDependenciaAutorizador, String codigoSedeAutorizador, 
			String codigoNivelAutorizador, String expedientePlanViaje, String numArchivoPdfFirmado) throws ServiceException, Exception;
	
	/**
	 * Metodo que permite observar una solicitud.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @param  observacionAutorizador :motivo de observacion.
	 * @param  codPerAutoriza :codigo del autorizador.
	 * @param  codigoSedeAutorizador :codigo de sede del autorizador.
	 * @param  expedientePlanViaje :expediente plan de viaje.
	 * @return Codigo de operacion: Exito(00) - Error(01).
	 * @see    String
	 * @throws Exception
	 */
	String observarSolicitud(String codPlanViaje, String observacionAutorizador, String codPerAutoriza, String codigoSedeAutorizador, String expedientePlanViaje) throws Exception;
	
	/**
	 * Metodo que permite anular una solicitud.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @param  observacionAnulacion :motivo de anulacion.
	 * @param  codPerAutoriza :codigo del autorizador.
	 * @param  codigoSedeAutorizador :codigo de sede del autorizador.
	 * @param  expedientePlanViaje :expediente plan de viaje.
	 * @return Codigo de operacion: Exito(00) - Error(01).
	 * @see    String
	 * @throws Exception
	 */
	String anularSolicitud(String codPlanViaje, String observacionAnulacion, String codPerAutoriza, String codigoSedeAutorizador, String expedientePlanViaje) throws Exception;
	
	
	Map<String,String> reevaluarUUOOsAutorizadoras(String codAutorizador)throws Exception;
	
	
	String derivarSolicitud(String codPlanViaje, String codigoDependenciaAutorizador, String expedientePlanViaje, 
			String indicadorCanalAtencion,MaestroPersonalBean autorizador, String codigoSedeAutorizador, String nombreNuevoAutorizador) throws ServiceException, Exception;
	
}
