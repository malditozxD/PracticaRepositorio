package pe.gob.sunat.recurso2.financiera.siga.viatico.service;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;

public interface ViaticoExpedienteService {

	/**
	 * Metodo que permite crear un accion en un expediente dado
	 * 
	 * @author Juan Saccatoma
	 * @param codigoProceso codigo de proceso
	 * @param numeroPlanilla numero de planilla
	 * @param codigoColaborador codigo de colaborador
	 * @param codigoSede codigo de sede
	 * @return codigo de expediente
	 * @throws ServiceException
	 */
	String crearExpediente(String codigoProceso, String numeroPlanilla, String codigoColaborador, String codigoSede) throws Exception;

	/**
	 * Metodo que permite crear un accion en un expediente dado
	 * 
	 * @author Juan Saccatoma
	 * @param codigoProceso codigo proceso
	 * @param numeroExpediente numero expediente
	 * @param codigoAccion codigo de accion
	 * @param codigoEstado codigo de estado
	 * @param codigoColaborador codigo del colaborador
	 * @param observacion observacion
	 * @param codigoSede codigo de sede
	 * @throws ServiceException
	 */
	void crearAccion(String codigoProceso, String numeroExpediente, String codigoAccion, String codigoEstado, String codigoColaborador, String observacion, String codigoSede) throws Exception;
}
