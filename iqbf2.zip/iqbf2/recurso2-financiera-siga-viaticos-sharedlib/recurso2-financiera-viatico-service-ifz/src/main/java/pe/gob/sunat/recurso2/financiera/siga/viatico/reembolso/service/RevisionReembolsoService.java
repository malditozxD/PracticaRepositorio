package pe.gob.sunat.recurso2.financiera.siga.viatico.reembolso.service;

import java.util.ArrayList;
import java.util.Date;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;

/**
 * Interface RevisionReembolsoService, contiene los metodos para la revision del reembolso.
 * @author Jorge Ponce.
 */
public interface RevisionReembolsoService {
	
	/**
	 * Metodo que permite obtener el listado de planes de viaje que se van a mostrar en la bandeja de autorizacion de reembolso.
	 * @author Jorge Ponce.
	 * @param  codigoDependencia :codigo de dependencia.
	 * @param  codPlanilla :codigo de planilla.
	 * @param  codTrabajador :codigo del colaborador.
	 * @param  codEstadoSolic :codigo de estado de la solicitud.
	 * @param  fechaDesde :fecha desde.
	 * @param  fechaHasta :fecha hasta.
	 * @param  codigoAutorizador :codigo del autorizador.
	 * @return Objeto PlanViajeBean.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	ArrayList<PlanViajeBean> obtenerPlanViajeCompletoToBandejaAutorizacionReembolso(String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoSolic, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws Exception;
	
	/**
	 * Metodo que permite obtener el listado de plan de viaje que se van a mostrar en la bandeja de autorizacion de reembolso.
	 * @author Jorge Ponce.
	 * @param  codigoDependencia :codigo de dependencia.
	 * @param  codPlanilla :codigo de planilla.
	 * @param  codTrabajador :codigo del colaborador.
	 * @param  codEstadoSolic :codigo de estado de la solicitud.
	 * @param  fechaDesde :fecha desde.
	 * @param  fechaHasta :fecha hasta.
	 * @param  codigoAutorizador :codigo del autorizador.
	 * @return Listado de plan de viaje.
	 * @see    PlanViajeBean
	 * @throws Exception
	 */
	ArrayList<PlanViajeBean> obtenerPlanViajeToBandejaAutorizacionReembolso(String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoSolic, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws Exception;
	
	/**
	 * Metodo que permite autorizar un reembolso.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @param  codPerAutoriza :codigo del autorizador.
	 * @param  codigoSedeAutorizador :codigo de sede del autorizador.
	 * @param  codigoNivelAutorizador :codigo nivel del autorizador.
	 * @param  expedientePlanViaje :expediente plan de viaje.
	 * @return Codigo de operacion: Exito(00) - Error(01).
	 * @see    String
	 * @throws Exception
	 */
	String autorizarReembolso(String codPlanViaje, String codPerAutoriza, String codigoSedeAutorizador, String codigoNivelAutorizador, String expedientePlanViaje) throws Exception;
	
	/**
	 * Metodo que permite observar un reembolso.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @param  observacionAutorizador :motivo de observacion.
	 * @param  codPerAutoriza :codigo del autorizador.
	 * @param  codigoSedeAutorizador :codigo de sede del autorizador.
	 * @param  expedientePlanViaje :expediente plan de viaje.
	 * @return Codigo de operacion: Exito(00) - Error(01).
	 * @see    String
	 * @throws Exception
	 */
	String observarReembolso(String codPlanViaje, String observacionAutorizador, String codPerAutoriza, String codigoSedeAutorizador, String expedientePlanViaje) throws Exception;
	
	/**
	 * Metodo que permite anular un reembolso.
	 * @author Jorge Ponce.
	 * @param  codPlanViaje :codigo plan viaje.
	 * @param  observacionAnulacion :motivo de anulacion.
	 * @param  codPerAutoriza :codigo del autorizador.
	 * @param  codigoSedeAutorizador :codigo de sede del autorizador.
	 * @param  expedientePlanViaje :expediente plan de viaje.
	 * @return Codigo de operacion: Exito(00) - Error(01).
	 * @see    String
	 * @throws Exception
	 */
	String anularReembolso(String codPlanViaje, String observacionAnulacion, String codPerAutoriza, String codigoSedeAutorizador, String expedientePlanViaje) throws Exception;
}
