package pe.gob.sunat.recurso2.financiera.siga.viatico.service;

import java.math.BigDecimal;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeConceptoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dto.DocumentoSustentarioDTO;

public interface ViaticoRegistroService {

	
	/**
	 * Metodo que permite registrar o editar documento sustentario.
	 * 
	 * @author Samuel Donisio.
	 * @param documentoSustentarioDTO : DTO para transaccion.
	 * @return mensaje de error o exito.
	 * @see DocumentoSustentarioDTO
	 * @throws Exception
	 */
	public DocumentoSustentarioDTO registrarComprobantePago(DocumentoSustentarioDTO documentoSustentarioDTO);
	
	/**
	 * Metodo que permite eliminar comprobante de pago.
	 * @author Jorge Ponce.
	 * @param  planViajeId :codigo plan viaje.
	 * @param  secuencial :secuencial del comprobante de pago.
	 * @param  conceptoId :codigo del concepto.
	 * @param  mtoReconocido :monto reconocido/rendido.
	 * @param  codigoPaginaCaller :codigo de pagina que llama al metodo.
	 * @return Codigo de operacion: Exito(00), Error(01).
	 * @see    String
	 * @throws Exception
	 */
	String eliminarComprobante(String planViajeId, Integer secuencial, String conceptoId, BigDecimal mtoReconocido, String codigoPaginaCaller) throws Exception;
	
	/**
	 * Metodo que permite actualizar el monto devuelto por voucher una vez distribuido.
	 * @author Jorge Ponce.
	 * @param  codigoPlanViaje :codigo plan viaje.
	 * @param  montoDepositado :monto depositado.
	 * @return Listado plan viaje concepto.
	 * @see    PlanViajeConceptoBean
	 * @throws Exception
	 */
	void actualizarMontoDevueltoVoucher(String codigoPlanViaje, BigDecimal montoDepositado) throws Exception;
	
}
