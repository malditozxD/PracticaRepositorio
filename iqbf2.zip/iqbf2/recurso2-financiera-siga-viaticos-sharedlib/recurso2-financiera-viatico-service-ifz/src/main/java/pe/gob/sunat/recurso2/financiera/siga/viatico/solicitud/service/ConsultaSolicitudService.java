package pe.gob.sunat.recurso2.financiera.siga.viatico.solicitud.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.SysEstadosBean;
import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.T01ParametroBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.NivelBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeConceptoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeDestinoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.RendicionDTO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.SolicitudDTO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.TipoCambioBean;

/**
 * Interfaz ConsultaSolicitudService.
 * 
 * @author Juan Farro
 */
public interface ConsultaSolicitudService {

	/**
	 * Metodo que permite obtener una solicitud de viatico.
	 * 
	 * @author Juan Farro
	 * @see PlanViajeBean
	 * @param parmSearch parametros de busqueda
	 * @return solicitud de viatico
	 * @throws Exception
	 */
	PlanViajeBean obtenerSolicitud(Map<String, Object> parmSearch) throws Exception;

	/**
	 * Metodo que permite obtener solicitudes de viatico para la bandeja.
	 * 
	 * @author Juan Farro
	 * @see PlanViajeBean
	 * @param parmSearch parametros de busqueda
	 * @return lista de solicitudes
	 * @throws Exception
	 */
	List<PlanViajeBean> obtenerSolicitudesBandeja(Map<String, Object> parmSearch) throws Exception;

	/**
	 * Metodo que permite obtener solicitudes de viatico para la bandeja de consulta, revision y alta (CUS10, CUS09 y CUS13).
	 * 
	 * @author Juan Farro
	 * @see PlanViajeBean
	 * @param parmSearch parametros de busqueda
	 * @return lista de solicitudes
	 * @throws Exception
	 */
	List<PlanViajeBean> obtenerSolicitudesBandejaConsultaRevisionAlta(Map<String, Object> parmSearch) throws Exception;

	/**
	 * Metodo que permite obtener el detalle solicitudes de viatico.
	 * 
	 * @author Juan Farro
	 * @see PlanViajeBean
	 * @param parmSearch parametros de busqueda
	 * @return lista de solicitudes
	 * @throws Exception
	 */
	List<PlanViajeBean> obtenerSolicitudDetalle(Map<String, Object> parmSearch) throws Exception;

	/**
	 * Metodo que permite obtener las solicitudes de viatico para exportar en la bandeja.
	 * 
	 * @author Juan Farro
	 * @see PlanViajeBean
	 * @param parmSearch parametros de busqueda
	 * @return lista de solicitudes
	 * @throws Exception
	 */
	List<PlanViajeBean> obtenerSolicitudesBandejaExportar(Map<String, Object> parmSearch) throws Exception;

	/**
	 * Metodo que permite obtener un solicitud de viatico a partir de su codigo de solicitud
	 * 
	 * @author Juan Farro
	 * @see PlanViajeBean
	 * @param codPlanViaje codigo plan de viaje
	 * @return solicitud de viatico
	 * @throws Exception
	 */
	PlanViajeBean buscarPlanViaje(String codPlanViaje) throws Exception;

	/**
	 * Metodo que permite buscar los datos de un plan de viaje a partir de su codigo de planilla.
	 * 
	 * @author Juan Farro
	 * @param codPlanilla codigo de planilla
	 * @return solicitud de viatico
	 * @throws Exception
	 * @see PlanViajeBean
	 */
	PlanViajeBean buscarPlanViajePlanilla(String codPlanilla) throws Exception;

	/**
	 * Metodo que permite obtener los plan de viaje destino asociados al codigo de solicitud de viatico.
	 * 
	 * @author Juan Farro
	 * @see PlanViajeDestinoBean
	 * @param codPlanViaje codigo de solicitud de viatico
	 * @return lista de plan de viaje destino
	 * @throws Exception
	 */
	List<PlanViajeDestinoBean> buscarPlanViajeDestinos(String codPlanViaje) throws Exception;

	/**
	 * Metodo que permite buscar plan viaje conceptos asociados a una solicitud de viatico.
	 * 
	 * @author Juan Farro
	 * @see PlanViajeConceptoBean
	 * @param codPlanViaje codigo de solicitud de viatico
	 * @return lista de plan de viaje conceptos
	 * @throws Exception
	 */
	List<PlanViajeConceptoBean> buscarPlanViajeConceptos(String codPlanViaje) throws Exception;

	/**
	 * Metodo que permite buscar solicitudes de viaticos para un colaborador que se traslapen con las fechas especificadas en los parametros.
	 * 
	 * @author Juan Farro
	 * @see PlanViajeBean
	 * @param codColaborador codigo de colaborador
	 * @param fechaSalida fecha inicio para busqueda de traslape de fechas
	 * @param fechaRetorno fecha fin para la busqueda de traslape de fechas
	 * @return lista de solicitudes del colaborador que tienen fechas traslapadas
	 * @throws Exception
	 */
	List<PlanViajeBean> buscarTraslapeFechas(String codColaborador, Date fechaSalida, Date fechaRetorno) throws Exception;

	/**
	 * Metodo que permite buscar solicitudes de viaticos (diferente a la especificado en el parametro) para un colaborador que se traslapen con las fechas especificadas.
	 * 
	 * @author Juan Farro
	 * @see PlanViajeBean
	 * @param codColaborador codigo de colaborador
	 * @param fechaSalida fecha de inicio para la busqueda de traslape de fechas
	 * @param fechaRetorno fecha fin para la busqueda de traslape de fechas
	 * @param codPlanViaje codigo de plan de viaje a excluir en la busqueda
	 * @return lista de solicitudes del colaborador que tienen fechas traslapadas
	 * @throws Exception
	 */
	List<PlanViajeBean> buscarTraslapeFechas(String codColaborador, Date fechaSalida, Date fechaRetorno, String codPlanViaje) throws Exception;

	/**
	 * Metodo que permite buscar la descripcion de un parametro (t01parametro).
	 * 
	 * @author Juan Farro
	 * @param codigoParametro codigo de parametro
	 * @param codigoArgumento codigo de argumento
	 * @return descripcion del parametro
	 * @throws Exception
	 */
	String obtenerDescripcionParametro(String codigoParametro, String codigoArgumento) throws Exception;

	/**
	 * Metodo que permite buscar la descripcion de un estado (sys_estados).
	 * 
	 * @author Juan Farro
	 * @param nombreTabla nombre de tabla
	 * @param valorEstado valor estado
	 * @return descripcion del estado
	 * @throws Exception
	 */
	String obtenerDescripcionSysEstado(String nombreTabla, String valorEstado) throws Exception;


	/**
	 * Metodo que permite buscar los estados de una solicitud de viatico (t01parametro).
	 * 
	 * @author Juan Farro
	 * @return lista de estados de solicitud de viatico
	 * @throws Exception
	 */
	List<SysEstadosBean> obtenerListaEstadosSolicitudViatico() throws Exception;

	/**
	 * Metodo que permite buscar los canales de atencion de una solicitud de viatico (t01parametro).
	 * 
	 * @author Juan Farro
	 * @return canales de atencion
	 * @throws Exception
	 */
	List<T01ParametroBean> obtenerListaCanalesAtencionViatico() throws Exception;

	/**
	 * Metodo que permite buscar los tipos de comision de un viatico
	 * 
	 * @author Juan Farro
	 * @return tipos de comision de viatico
	 * @throws Exception
	 */
	List<T01ParametroBean> obtenerListaTiposComisionViatico() throws Exception;

	/**
	 * Metodo que permite obtener el listado de detalle de los planes de viaje que se muestran la bandeja de solicitud.
	 * 
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @param codigoDependencia :codigo de dependencia.
	 * @param codPlanilla :codigo de planilla.
	 * @param codTrabajador :codigo del colaborador.
	 * @param codEstadoSolic :codigo de estado de la solicitud.
	 * @param indicadorCanalAtencion :indicador canal de atencion.
	 * @param fechaDesde :fecha desde.
	 * @param fechaHasta :fecha hasta.
	 * @param codigoAutorizador :codigo del autorizador.
	 * @return Objeto PlanViajeBean.
	 * @see PlanViajeBean
	 * @throws Exception
	 */
	ArrayList<PlanViajeBean> obtenerPlanViajeDetalleToBandejaSolicitud(String codPlanViaje, String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoSolic, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws Exception;

	//JMCR-ME BANDEJA AUTORIZADOR se cambia el estado de la solicitud por una lista de estados  a enviar con "IN"
	ArrayList<PlanViajeBean> obtenerPlanViajeDetalleToBandejaSolicitudMiltiplesEstados(String codPlanViaje, String codigoDependencia, String codPlanilla, String codTrabajador, List<String> listCodEstadoSolic, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws Exception;	
	//JMCR-ME BANDEJA AUTORIZADOR se cambia el estado de la solicitud por una lista de estados  a enviar con "IN"

	/**
	 * Buscar un nivel de viatico por su codigo.
	 * 
	 * @author Juan Farro
	 * @param codigoNivel codigo nivel
	 * @return nivel
	 * @throws Exception
	 * @see NivelBean
	 */
	NivelBean buscarNivelViatico(String codigoNivel) throws Exception;

	/**
	 * Metodo que permite obtener el tipo de cambio (moneda dolares a soles) con la fecha actual.
	 * 
	 * @author Juan Farro
	 * @return tipo de cambio
	 * @throws Exception
	 * @see TipoCambioBean
	 */
	TipoCambioBean obtenerTipoCambioSimboloDolaresHoy() throws Exception;

	/**
	 * Metodo que permite obtener el tipo de cambio (moneda dolares a soles) con fecha mas reciente.
	 * 
	 * @author Juan Farro
	 * @return tipo de cambio
	 * @throws Exception
	 * @see TipoCambioBean
	 */
	TipoCambioBean obtenerTipoCambioSimboloDolaresMasReciente() throws Exception;

	/**
	 * Metodo que permite obtener los datos necesarios para el reporte solicitud.
	 * @author Samuel Dionisio
	 * @param  codPlanViaje :codigo plan viaje.
	 * @return Rendicion DTO.
	 * @see    RendicionDTO
	 */
	SolicitudDTO obtenerDatosReporteSolicitud(String codPlanViaje) throws Exception;
	
	
	Map<String,String> obtenerUUOOAutorizadora(String codDependencia, String codEmpleado, String indProceso)throws Exception;
	
	Map<String,String> validarRevisionPreviaOSA(String idPlanilla)throws Exception;
	

}
