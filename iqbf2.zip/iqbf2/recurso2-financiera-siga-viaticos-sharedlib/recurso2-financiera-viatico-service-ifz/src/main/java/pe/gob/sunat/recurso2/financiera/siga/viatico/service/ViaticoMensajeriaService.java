package pe.gob.sunat.recurso2.financiera.siga.viatico.service;

import java.util.List;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.SolicitudDTO;

public interface ViaticoMensajeriaService {

	/**
	 * Metodo que permite enviar correo de Notificacion de rechazo de la planilla (ANEXO 12)
	 * 
	 * @author Rocio Paz.
	 * @param solicitudDTO : objeto que tiene los datos para el envio de correo.
	 * @throws Exception
	 */

	public void enviarNotificacionRechazoPlanilla(SolicitudDTO solicitudDTO);
	
	/**
	 * Metodo que permite enviar notificacion cuando se reprograma la fecha de rendicion.
	 * @author Jorge Ponce.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo.
	 */
	void enviarNotificacionReprogramacionFechaRendicion(SolicitudDTO solicitudDTO);	
	
	
	/**
	 * Metodo que permite enviar correo: notificacion envio solicitud para registro de solicitud (ANEXO 01)
	 * 
	 * @author Rocio Paz
	 * @param  solicitudDTO : solicitudDTO datos de la solicitud de viatico
	 * @throws Exception
	 */
	public void enviarNotificacionRegistroSolicitud(SolicitudDTO solicitudDTO) ;
	

	/**
	 * Metodo que permite enviar correo: notificacion envio Anulacion de la solicitud(ANEXO 02)
	 * 
	 * @author Rocio Paz
	 * @param solicitudDTO datos para anulacion de la solicitud de viatico
     * @throws Exception	 
	 */	
	public void enviarAnulacionSolicitud(SolicitudDTO solicitudDTO);
	
	
	/**
	 * Metodo que permite enviar notificacion cuando se autoriza una solicitud de caja chica.(ANEXO 03)
	 * @author Jorge Ponce.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo.
	 */
	void enviarNotificacionAutorizacionSolicitudCajaChica(SolicitudDTO solicitudDTO);
	
	
	/**
	 * Metodo que permite enviar notificacion cuando se anula una solicitud.(ANEXO 04)
	 * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo.
	 * * @throws Exception	 
	 */
	void enviarNotificacionAnulacionSolicitud(SolicitudDTO solicitudDTO);
	
	
	/**
	 * Metodo que permite enviar notificacion cuando se observa una solicitud.(ANEXO 05)
	 * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo. 
	 * @throws Exception	
	 */
	void enviarNotificacionObservacionSolicitud(SolicitudDTO solicitudDTO);
	
	
	/**
	 * Metodo que permite enviar correo al observar solicitud reembolso(ANEXO 06)
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo. 
	 * @throws Exception	
	 */
	public void enviarObservacionSolicitudReembolso(SolicitudDTO solicitudDTO);
	
	
	/**
	 * Metodo que permite enviar correo de Notificacion por no presentar rendicion de cuenta - primera notificacion - sistema(ANEXO 07)
	 * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo. 
	 * @throws Exception	
	 */
	public void enviarNotificacionRendicion(SolicitudDTO solicitudDTO);
	
	/**
	 * Metodo que permite enviar correo de  Notificar por no presentar rendicion de cuenta - segunda notificacion(ANEXO 08)
	 * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo.
	 * @throws Exception
	 */
	public void enviarNotificacioSegundaNotificacion(SolicitudDTO solicitudDTO) throws Exception;
	
	/**
	 * Metodo que permite enviar correo de Notificacion Planilla de Viaticos que no han sido remitidas para la gestion de Pago(ANEXO 09)
	 * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo. 
	 * @throws Exception	
	 */
	public void enviarnotificacionPlanillaVaiticosNoRemitidas(List<SolicitudDTO> solicitudDTO) throws Exception;
	
	/**
	 * Metodo que permite enviar correo de notificacion al registrador para que revise su bandeja de Notificaciones(ANEXO 10)
	 * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo. 
	 * @throws Exception	
	 */
	public void enviarNotificacioAlRegistrador(SolicitudDTO solicitudDTO);
	
	/**
	 * Metodo que permite enviar correo de Notificacion de Cierre de Rendicion(ANEXO 11) 
     * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo. 
	 * @throws Exception	
	 */
	public void enviarNotificacionCierreRendicion(SolicitudDTO solicitudDTO);
	
	/**
	 * Metodo que permite enviar correo: De Notificacion Autorizacion De Solicitud De Reembolso(ANEXO 13)
     * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo. 
	 * @throws Exception	
	 */
	public void enviarNotificacionAutorizacionDeSolicitudDeReembolso(SolicitudDTO solicitudDTO);
	
	
	
	/**
	 * Metodo que permite enviar correo de Notificacion Anulacion De Solicitud De Reembolso - Autorizador de Gasto(ANEXO 14)
	 * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo. 
	 * @throws Exception	
	 */
	
	public void enviarNotificacionAnulacionDeSolicitudDeReembolso(SolicitudDTO solicitudDTO);
	
	/**
	 * Metodo que permite enviar correo de  Notificacion al registrador universal comunicado que un comisionado tiene comisiones consecutivas por lo cual no puede rendir ne le plazo(ANEXO 15)
	 * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo. 
	 * @throws Exception	
	 */
	public void enviarNotificacionAnulacionSolcitudReembolsoAutorizador(SolicitudDTO solicitudDTO);
	
	/**
	 * Metodo que permite enviar correo de Notificacion de Reprogramacion de fecha de Rendicion(ANEXO 16)
     * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo. 
	 * @throws Exception	
	 */
	
	public void enviarNotificacionDeReprogramacionDeFechaDeRendicion(SolicitudDTO solicitudDTO);
	
	/**
	 * Metodo que permite enviar correo: Notificacion de anulacion de Planilla(ANEXO 17)
	  * @author Rocio Paz.
	 * @param solicitudDTO :objeto que tiene los datos para el envio de correo. 
	 * @throws Exception	
	 */

	public void enviarNotificacionDeAnulacionDePlanilla(SolicitudDTO solicitudDTO);
	
}
