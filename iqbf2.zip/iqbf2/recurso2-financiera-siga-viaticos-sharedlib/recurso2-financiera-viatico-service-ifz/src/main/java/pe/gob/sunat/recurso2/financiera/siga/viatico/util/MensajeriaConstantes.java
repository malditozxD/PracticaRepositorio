package pe.gob.sunat.recurso2.financiera.siga.viatico.util;

import java.text.MessageFormat;

public class MensajeriaConstantes {
	
	//TIPO VIATICOS
	public static final String TIPO_MENSAJE_PARA = "PARA";
	public static final String TIPO_MENSAJE_CC = "CC";
	public static final String TIPO_MENSAJE_OCC = "BCC";
	
	//CODIGO MENSAJE
	public static final String CODIGO_REGISTRO_SOLICITUD = "VIAW00001";
	public static final String CODIGO_NOTIFICACION_ANULACION_SOLICITUD_REGISTRADOR_COLABORADOR = "VIAW00002";
	public static final String CODIGO_NOTIFICACION_AUTORIZACION_SOLICITUD_CAJA_CHICA = "VIAW00003";
	public static final String CODIGO_NOTIFICACION_ANULACION_SOLICITUD = "VIAW00004";
	public static final String CODIGO_NOTIFICACION_OBSERVACION_SOLICITUD = "VIAW00005";
	public static final String CODIGO_NOTIFICACION_REPROGRAMACION_FECHA_RENDICION = "VIAW00016";

	public static final String CODIGO_OBSERVACION_SOLCITUD_PLANILLA_REEMBOLSO = "VIAW00006";
	public static final String CODIGO_NOTIFICACION_RENDICION_PRIMERA_NOTIFICACION = "VIAW00007";
	public static final String CODIGO_SEGUNDA_NOTIFICACION= "VIAW00008";
	public static final String CODIGO_NOTIFICACION_PLANILLA_VIATICOS_NO_REMITIDAS= "VIAW00009";
	public static final String CODIGO_NOTIFICACION_AL_REGISTRADOR= "VIAW00010";
	public static final String CODIGO_NOTIFICACION_DE_CIERRE_RENDICION= "VIAW00011";
	public static final String CODIGO_NOTIFICACION_RECHAZO_GENERACION_PLANILLA_VIATICOS= "VIAW00012";
	public static final String CODIGO_NOTIFICACION_DE_AUTORIZACION_SOLICITUD_REEMBOLSO= "VIAW00013";
	public static final String CODIGO_NOTIFICACION_DE_ANULACION_SOLICITUD_REEMBOLSO= "VIAW00014";
	public static final String CODIGO_NOTIFICACION_DE_ANULACION_SOLICITUD_DE_REEMBOLSO_AUTORIZADOR_DE_GASTO = "VIAW00015";
	public static final String CODIGO_NOTIFICACION_DE_REPROGRAMACION_DE_FECHA_DE_SOLICITUD_RENDICION= "VIAW00016";
	public static final String CODIGO_NOTIFICACION_DE_ANULACION_DE_PLANILLA= "VIAW00017";
	
	




	//ASUNTO MENSAJE
	public static final String ASUNTO_REGISTRO_SOLICITUD = "NOTIFICACIÓN DE REGISTRO DE SOLICITUD DE VIATICOS";
	public static final String ASUNTO_NOTIFICACION_AUTORIZACION_SOLICITUD_CAJA_CHICA = "NOTIFICACIÓN DE AUTORIZACION DE PLANILLA DE VIATICOS - PAGO POR CAJA CHICA";
	public static final String ASUNTO_NOTIFICACION_ANULACION_SOLICITUD = "NOTIFICACIÓN DE ANULACIÓN DE PLANILLA DE VIATICOS - AUTORIZADOR";
	public static final String ASUNTO_NOTIFICACION_OBSERVACION_SOLICITUD = "NOTIFICACIÓN DE OBSERVACIÓN DE PLANILLA DE VIATICOS - AUTORIZADOR";
	public static final String ASUNTO_NOTIFICACION_REPROGRAMACION_FECHA_RENDICION = "NOTIFICACIÓN DE REPROGRAMACIÓN DE FECHA DE RENDICIÓN";
	public static final String ASUNTO_NOTIFICACION_REGISTRO_SOLICITUD= "NOTIFICACIÓN DE REGISTRO DE SOLICITUD DE VIATICOS";
	public static final String ASUNTO_NOTIFICACION_ANULACION_SOLICITUD_REGISTRADOR_COLABORADOR= "NOTIFICACIÓN DE ANULACIÓN DE SOLICITUD DE VIATICOS-REGISTRADOR COLABORADOR";
	public static final String ASUNTO_OBSERVACION_SOLCITUD_PLANILLA_REEMBOLSO= "NOTIFCACIÓN DE OBSERVACIÓN DE SOLICITUD DE REEMBOLSO - AUTORIZADOR DE GASTO";
	public static final String ASUNTO_NOTIFICACION_RENDICION_PRIMERA_NOTIFICACION = "NOTIFICACIÓN DE RENDICIÓN - PRIMERA NOTIFICACIÓN - SISTEMA";
	public static final String ASUNTO_SEGUNDA_NOTIFICACION = "NOTIFICACIÓN DE SEGUNDA NOTIFICACIÓN";
	public static final String ASUNTO_NOTIFICACION_PLANILLA_VIATICOS_NO_REMITIDAS = "NOTIFICACIÓN DE PLANILLA DE VIATICOS QUE NO HAN SIDO REMITIDAS PARA LA GESTION DEL PAGO";
	public static final String ASUNTO_NOTIFICACION_AL_REGISTRADOR = "NOTIFICACIÓN AL REGISTRADOR PARA QUE REVISE SU BANDEJA DE NOTIFICACIONES";
	public static final String ASUNTO_NOTIFICACION_DE_CIERRE_RENDICION = "NOTIFICACIÓN DE CIERRE DE RENDICIÓN";
	public static final String ASUNTO_NOTIFICACION_DE_AUTORIZACION_SOLICITUD_REEMBOLSO = "NOTIFICACIÓN DE AUTORIZACIÓN DE SOLICITUD DE REEMBOLSO";
	public static final String ASUNTO_NOTIFICACION_DE_ANULACION_SOLICITUD_REEMBOLSO = "NOTIFICACIÓN DE ANULACIÓN - SOLICITUD DE REEMBOLSO - AUTORIZADOR DE GASTO";
	public static final String ASUNTO_NOTIFICACION_DE_REPROGRAMACION_DE_FECHA_DE_SOLICITUD_RENDICION = "NOTIFICACIÓN DE REPROGRAMACIÓN DE FECHA DE RENDICIÓN";
	public static final String ASUNTO_NOTIFICACION_DE_ANULACION_DE_PLANILLA = "NOTIFICACIÓN DE ANULACIÓN DE PLANILLA";
	public static final String ASUNTO_NOTIFICACION_DE_ANULACION_SOLICITUD_DE_REEMBOLSO_AUTORIZADOR_DE_GASTO = "NOTIFICACIÓN DE ANULACIÓN - SOLICITUD DE REEMBOLSO - AUTORIZADOR DE GASTO";
	public static final String ASUNTO_NOTIFICACION_RECHAZO_GENERACION_PLANILLA_VIATICOS = "NOTIFICACIÓN RECHAZO DE GENERACIÓN DE PLANILLA DE VIATICOS";
	
	
	
  
	
	//CODIGO DE OPERACION - EXITO - ERROR
	public static final String EXITO_OPERACION = "00";
	public static final String ERROR_OPERACION = "01";
	
	//PROPERTIES CORREO
	public static final String NOTIFICACION_CUERPO_1 = "notificacion.cuerpo1";
	public static final String NOTIFICACION_CUERPO_2 = "notificacion.cuerpo2";
	public static final String NOTIFICACION_AUTORIZACION_TITULO = "notificacionAutorizacion.titulo";
	public static final String NOTIFICACION_AUTORIZACION_CUERPO = "notificacionAutorizacion.cuerpo";
	public static final String NOTIFICACION_OBSERVACION_TITULO = "notificacionObservacion.titulo";
	public static final String NOTIFICACION_OBSERVACION_CUERPO = "notificacionObservacion.cuerpo";
	public static final String NOTIFICACION_ANULACION_TITULO = "notificacionAnulacion.titulo";
	public static final String NOTIFICACION_ANULACION_CUERPO = "notificacionAnulacion.cuerpo";
	public static final String NOTIFICACION_REPROGRAMACION_TITULO = "notificacionReprogramacion.titulo";
	public static final String NOTIFICACION_REPROGRAMACION_CUERPO = "notificacionReprogramacion.cuerpo";
	public static final String NOTIFICACION_REGISTRO_SOLICITUD_TITULO = "notificacionRegsitroSolicitud.titulo";
	public static final String NOTIFICACION_REGISTRO_SOLICITUD_CUERPO = "notificacionRegsitroSolicitud.cuerpo";
	public static final String NOTIFICACION_ANULACION_SOLICITUD_REGISTRADOR_COLABORADOR_TITULO = "notificacionAnulacionSolicitud.titulo";
	public static final String NOTIFICACION_ANULACION_SOLICITUD_REGISTRADOR_COLABORADOR_CUERPO = "notificacionAnulacionSolicitud.cuerpo";
	public static final String NOTIFICACION_OBSERVACION_SOLCITUD_PLANILLA_REEMBOLSO_TITULO = "notificacionObservacionSolicitudPlanilla.titulo";
	public static final String NOTIFICACION_OBSERVACION_SOLCITUD_PLANILLA_REEMBOLSO_CUERPO = "notificacionObservacionSolicitudPlanilla.cuerpo";
	public static final String NOTIFICACION_RENDICION_PRIMERA_NOTIFICACION_TITULO = "notificacionRendicionPrimera.titulo";
	public static final String NOTIFICACION_RENDICION_PRIMERA_NOTIFICACION_CUERPO = "notificacionRendicionPrimera.cuerpo";
	public static final String NOTIFICACION_SEGUNDA_NOTIFICACION_TITULO = "notificacionSegundaNotificacion.titulo";
	public static final String NOTIFICACION_SEGUNDA_NOTIFICACION_CUERPO = "notificacionSegundaNotificacion.cuerpo";
	public static final String NOTIFICACION_PLANILLA_VIATICOS_NO_REMITIDAS_TITULO = "notificacionPlanillaViaticosNoRemitidas.titulo";
	public static final String NOTIFICACION_PLANILLA_VIATICOS_NO_REMITIDAS_CUERPO = "notificacionPlanillaViaticosNoRemitidas.cuerpo";
	public static final String NOTIFICACION_AL_REGISTRADOR_TITULO = "notificacionAlRegistrador.titulo";
	public static final String NOTIFICACION_AL_REGISTRADOR_CUERPO = "notificacionAlRegistrador.cuerpo";
	public static final String NOTIFICACION_DE_CIERRE_RENDICION_TITULO= "notificacionDeCierreRendicion.titulo";
	public static final String NOTIFICACION_DE_CIERRE_RENDICION_CUERPO= "notificacionDeCierreRendicion.cuerpo";
	public static final String NOTIFICACION_DE_AUTORIZACION_SOLICITUD_REEMBOLSO_TITULO= "notificacionDeAutorizaionSolicitudReembolso.titulo";
	public static final String NOTIFICACION_DE_AUTORIZACION_SOLICITUD_REEMBOLSO_CUERPO= "notificacionDeAutorizaionSolicitudReembolso.cuerpo";
	public static final String NOTIFICACION_DE_ANULACION_SOLICITUD_REEMBOLSO_TITULO= "notificacionDeAnualcionSolicitudReembolso.titulo";
	public static final String NOTIFICACION_DE_ANULACION_SOLICITUD_REEMBOLSO_CUERPO= "notificacionDeAnualcionSolicitudReembolso.cuerpo";
	public static final String NOTIFICACION_DE_REPROGRAMACION_DE_FECHA_DE_SOLICITUD_RENDICION_TITULO= "notificacionDeReprogramacionDeRetencion.titulo";
	public static final String NOTIFICACION_DE_REPROGRAMACION_DE_FECHA_DE_SOLICITUD_RENDICION_CUERPO= "notificacionDeReprogramacionDeRetencion.cuerpo";
	
	public static final String NOTIFICACION_DE_ANULACION_DE_PLANILLA_TITULO= "notificacionDeAnulacionDePlanilla.titulo";
	public static final String NOTIFICACION_DE_ANULACION_DE_PLANILLA_CUERPO= "notificacionDeAnulacionDePlanilla.cuerpo";
	public static final String NOTIFICACION_DE_ANULACION_SOLICITUD_DE_REEMBOLSO_AUTORIZADOR_DE_GASTO_TITULO = "notificacionAnulacionSolcitudReembolsoAutorizador.titulo";
	public static final String NOTIFICACION_DE_ANULACION_SOLICITUD_DE_REEMBOLSO_AUTORIZADOR_DE_GASTO_CUERPO = "notificacionAnulacionSolcitudReembolsoAutorizador.cuerpo";
	
	public static final String NOTIFICACION_RECHAZO_GENERACION_PLANILLA_VIATICOS_TITULO = "notificacionRechazoPlanilla.titulo";
	public static final String NOTIFICACION_RECHAZO_GENERACION_PLANILLA_VIATICOS_CUERPO = "notificacionRechazoPlanilla.cuerpo";
	
	public static void main(String[] aaa){
		int fileCount = 1273;
		 String diskName = "MyDisk";
		 Object[] testArgs = {new Long(fileCount), diskName,"argumento3","argumento4"};

		 MessageFormat form = new MessageFormat("The disk \"{2}\" contains {3} file(s).");
		 System.out.println(form.format(testArgs));
	}
}
