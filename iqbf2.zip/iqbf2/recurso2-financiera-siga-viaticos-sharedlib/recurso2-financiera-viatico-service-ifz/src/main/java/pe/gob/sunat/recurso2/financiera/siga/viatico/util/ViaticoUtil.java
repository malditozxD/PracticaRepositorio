package pe.gob.sunat.recurso2.financiera.siga.viatico.util;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;

import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.recurso2.administracion.siga.util.FechaConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;

@SuppressWarnings("rawtypes")
public class ViaticoUtil {

	public static String validarEmptyToNull(String parameterRequest) {
		String finalParameterRequest = parameterRequest;
		if (ViaticoConstantes.CADENA_VACIA.equals(parameterRequest)) {
			finalParameterRequest = null;
		}
		return finalParameterRequest;
	}

	public static String obtenerFlagViatico(boolean valueFlag) {
		String flag = ViaticoConstantes.CERO;
		if (valueFlag) {
			flag = ViaticoConstantes.UNO;
		}
		return flag;
	}
	
	public static String obtenerFlagRegistrador(Long numeroRegistros) {
		String flag = ViaticoConstantes.CERO;
		if (numeroRegistros != null && numeroRegistros > 0) {
			flag = ViaticoConstantes.UNO;
		}
		return flag;
	}
	
	public static String obtenerFlagRegistradorUniversal(Long numeroRegistros) {
		String flag = ViaticoConstantes.CERO;
		if (numeroRegistros != null && numeroRegistros > 0) {
			flag = ViaticoConstantes.UNO;
		}
		return flag;
	}
	
	public static String obtenerFlagBuscarColaborador(String flagRegistradorUniversal, String flagRegistrador) {
		String flag = ViaticoConstantes.BUSCAR_COLABORADOR;
		if (ViaticoConstantes.UNO.equals(flagRegistradorUniversal)) {
			flag = ViaticoConstantes.BUSCAR_REGISTRADOR_UNIVERSAL;
		}
		else {
			if (ViaticoConstantes.UNO.equals(flagRegistrador)) {
				flag = ViaticoConstantes.BUSCAR_REGISTRADOR;
			}
		}
		return flag;
	}
	
	public static String obtenerFlagBuscarUUOO(String flagRegistradorUniversal, String flagRegistrador) {
		String flag = ViaticoConstantes.BUSCAR_COLABORADOR;
		if (ViaticoConstantes.UNO.equals(flagRegistradorUniversal)) {
			flag = ViaticoConstantes.BUSCAR_REGISTRADOR_UNIVERSAL;
		}
		else {
			if (ViaticoConstantes.UNO.equals(flagRegistrador)) {
				flag = ViaticoConstantes.BUSCAR_REGISTRADOR;
			}
		}
		return flag;
	}
	
	public static String obtenerFlagMayor1UUOOAsociada(Long numeroRegistros) {
		String flag = ViaticoConstantes.CERO;
		if (numeroRegistros != null && numeroRegistros > 1) {
			flag = ViaticoConstantes.UNO;
		}
		return flag;
	}
	
	public static Date parseStringDateToDate(String stringDate) throws Exception {
		return parseStringDateToDate(stringDate, FechaBean.FORMATO_DEFAULT);
	}

	public static Date parseStringDateToDate(String stringDate, String formatDate) throws Exception {
		Date date = null;
		if (stringDate != null && !ViaticoConstantes.CADENA_VACIA.equals(stringDate) && formatDate != null && !ViaticoConstantes.CADENA_VACIA.equals(formatDate)) {
			date = new SimpleDateFormat(formatDate).parse(stringDate);
		}
		return date;
	}

	public static String formatDateToDateDDMMYYYYHHMM(Date date) {
		String formatDate = ViaticoConstantes.CADENA_VACIA;
		if (date != null) {
			SimpleDateFormat sdf = new SimpleDateFormat(ViaticoConstantes.DATE_FORMAT_DDMMYYYYHHMM, Locale.getDefault());
			formatDate = sdf.format(date);
		}
		return formatDate;
	}
	
	public static String formatDateToDateDDMMYYYYHHMM_AMPM(Date date) {
		String formatDate = ViaticoConstantes.CADENA_VACIA;
		if (date != null) {
			SimpleDateFormat sdf = new SimpleDateFormat(ViaticoConstantes.DATE_FORMAT_DDMMYYYYHHMM_AMPM, Locale.getDefault());
			formatDate = sdf.format(date);
		}
		return formatDate;
	}	

	public static String formatDateToDateDDMMYYYY(Date date) {
		String formatDate = ViaticoConstantes.CADENA_VACIA;
		if (date != null) {
			SimpleDateFormat sdf = new SimpleDateFormat(ViaticoConstantes.DATE_FORMAT_DDMMYYYY, Locale.getDefault());
			formatDate = sdf.format(date);
		}
		return formatDate;
	}

	public static String formatDateToDateYYYY(Date date) {
		String formatDate = ViaticoConstantes.CADENA_VACIA;
		if (date != null) {
			SimpleDateFormat sdf = new SimpleDateFormat(ViaticoConstantes.DATE_FORMAT_YYYY, Locale.getDefault());
			formatDate = sdf.format(date);
		}
		return formatDate;
	}

	public static String formatDateToDateMM(Date date) {
		String formatDate = ViaticoConstantes.CADENA_VACIA;
		if (date != null) {
			SimpleDateFormat sdf = new SimpleDateFormat(ViaticoConstantes.DATE_FORMAT_MM, Locale.getDefault());
			formatDate = sdf.format(date);
		}
		return formatDate;
	}

	public static String formatDateToHourHHMM(Date date) {
		String formatDate = ViaticoConstantes.CADENA_VACIA;
		if (date != null) {
			SimpleDateFormat sdf = new SimpleDateFormat(ViaticoConstantes.DATE_FORMAT_HHMM, Locale.getDefault());
			formatDate = sdf.format(date);
		}
		return formatDate;
	}

	public static String formatHourToHHMM(String hourString) {
		StringBuilder formatHour = new StringBuilder(ViaticoConstantes.CADENA_VACIA);
		if (hourString != null && hourString.contains(ViaticoConstantes.DOS_PUNTOS)) {
			String[] arrayHour = hourString.split(ViaticoConstantes.DOS_PUNTOS);
			if (arrayHour.length >= 2) {
				String hora = arrayHour[0];
				String minutos = arrayHour[1];
				formatHour.append(hora);
				formatHour.append(ViaticoConstantes.DOS_PUNTOS);
				formatHour.append(minutos);
			}
		}
		return formatHour.toString();
	}

	public static String addMinutosHourFormatHHMM(String hourString, int numMinutos) {

		StringBuilder hourFinal = new StringBuilder(ViaticoConstantes.CADENA_VACIA);
		if (hourString != null && hourString.contains(ViaticoConstantes.DOS_PUNTOS)) {
			String[] arrayHour = hourString.split(ViaticoConstantes.DOS_PUNTOS);
			if (arrayHour.length >= 2) {
				Integer hora = new Integer(arrayHour[0]);
				Integer minutos = new Integer(arrayHour[1]);
				minutos += numMinutos;

				int cocienteOperacion = minutos / 60;
				int restoOperacion = minutos % 60;

				if (cocienteOperacion == 0) {
					minutos = restoOperacion;
				} else {
					hora += cocienteOperacion;
					minutos = restoOperacion;
				}

				String horaString = hora.toString();
				String minutosString = minutos.toString();

				if (hora.intValue() < 10) {
					horaString = ViaticoConstantes.CERO + hora.toString();
				}

				if (minutos.intValue() < 10) {
					minutosString = ViaticoConstantes.CERO + minutos.toString();
				}

				hourFinal.append(horaString);
				hourFinal.append(ViaticoConstantes.DOS_PUNTOS);
				hourFinal.append(minutosString);
			}
		}
		return hourFinal.toString();
	}

	public static long numeroDiasBetweenTwoDates(String dateString1, String dateString2) throws Exception {

		long numeroDias = 0;
		if (dateString1 != null && !ViaticoConstantes.CADENA_VACIA.equals(dateString1) && dateString2 != null && !ViaticoConstantes.CADENA_VACIA.equals(dateString2)) {
			Date date1 = new SimpleDateFormat(ViaticoConstantes.DATE_FORMAT_DDMMYYYY).parse(dateString1);
			Date date2 = new SimpleDateFormat(ViaticoConstantes.DATE_FORMAT_DDMMYYYY).parse(dateString2);
			Calendar cal1 = Calendar.getInstance();
			Calendar cal2 = Calendar.getInstance();
			cal1.setTime(date1);
			cal2.setTime(date2);
			long milis1 = cal1.getTimeInMillis();
			long milis2 = cal2.getTimeInMillis();

			if (milis1 > milis2) {
				numeroDias = (milis1 - milis2) / (24 * 60 * 60 * 1000);
			} else {
				numeroDias = (milis2 - milis1) / (24 * 60 * 60 * 1000);
			}
		}
		return numeroDias;
	}

	public static long numeroDiasFechaMaxima(Date date1, Date date2) throws Exception {

		String date1t = formatDateToDateDDMMYYYY(date1);
		String date2t = formatDateToDateDDMMYYYY(date2);

		date1 = parseStringDateToDate(date1t, ViaticoConstantes.DATE_FORMAT_DDMMYYYY);
		date2 = parseStringDateToDate(date2t, ViaticoConstantes.DATE_FORMAT_DDMMYYYY);

		long numeroDias = 0;
		if (date1 != null && date2 != null) {

			Calendar cal1 = Calendar.getInstance();
			Calendar cal2 = Calendar.getInstance();
			cal1.setTime(date1);
			cal2.setTime(date2);
			long milis1 = cal1.getTimeInMillis();
			long milis2 = cal2.getTimeInMillis();

			if (milis1 < milis2) {
				numeroDias = (milis2 - milis1) / (24 * 60 * 60 * 1000);
			} else {
				numeroDias = 0;
			}
		}
		return numeroDias;
	}

	public static boolean esfechaMayor(String dateString1, String dateString2) throws Exception {

		boolean fechaMayor = false;
		if (dateString1 != null && !ViaticoConstantes.CADENA_VACIA.equals(dateString1) && dateString2 != null && !ViaticoConstantes.CADENA_VACIA.equals(dateString2)) {
			Date date1 = new SimpleDateFormat(ViaticoConstantes.DATE_FORMAT_DDMMYYYY).parse(dateString1);
			Date date2 = new SimpleDateFormat(ViaticoConstantes.DATE_FORMAT_DDMMYYYY).parse(dateString2);
			Calendar cal1 = Calendar.getInstance();
			Calendar cal2 = Calendar.getInstance();
			cal1.setTime(date1);
			cal2.setTime(date2);
			long milis1 = cal1.getTimeInMillis();
			long milis2 = cal2.getTimeInMillis();

			if (milis1 > milis2) {
				fechaMayor = true;
			}

		}
		return fechaMayor;
	}

	public static boolean esfechaMayor(Date date1, Date date2) {

		boolean fechaMayor = false;
		if (date1 != null && date2 != null) {

			Calendar cal1 = Calendar.getInstance();
			Calendar cal2 = Calendar.getInstance();
			cal1.setTime(date1);
			cal2.setTime(date2);
			long milis1 = cal1.getTimeInMillis();
			long milis2 = cal2.getTimeInMillis();

			if (milis1 > milis2) {
				fechaMayor = true;
			}

		}
		return fechaMayor;
	}

	public static String formatearNumeros(int numeroDecimales, BigDecimal numero) {
		String numeroFormateado = ViaticoConstantes.CADENA_VACIA;
		if (numero != null) {
			numeroFormateado += numero.setScale(numeroDecimales, BigDecimal.ROUND_HALF_UP);
		} else {
			numeroFormateado = formatearNumeros(numeroDecimales, new BigDecimal(0));
		}
		return numeroFormateado;
	}
	
	public static String formatearNumeros(int numeroDecimales, double numero) {
		
		String numeroFormateado = new BigDecimal(numero).setScale(numeroDecimales, BigDecimal.ROUND_HALF_UP).toString();
		
		return numeroFormateado;
	}	
	
	public static double redondear(int numeroDecimales, double numero) {
		
		double round = new BigDecimal(numero).setScale(numeroDecimales, BigDecimal.ROUND_HALF_UP).doubleValue();
		
		return round;
	}		

	public static String formatearMontos(String moneda, int numeroDecimales, BigDecimal monto) {
		String montoFormateado = ViaticoConstantes.CADENA_VACIA;
		if (monto != null) {
			montoFormateado += moneda + ViaticoConstantes.ESPACIO + monto.setScale(numeroDecimales, BigDecimal.ROUND_HALF_UP);
		} else {
			montoFormateado = formatearMontos(moneda, numeroDecimales, new BigDecimal(0));
		}
		return montoFormateado;
	}

	public static String formatearMontosSoles(BigDecimal monto) {
		String montoSoles = ViaticoConstantes.CADENA_VACIA;
		if (monto != null) {
			montoSoles += ViaticoConstantes.MONEDA_SOLES + ViaticoConstantes.ESPACIO + monto.setScale(2, BigDecimal.ROUND_HALF_UP);
		} else {
			montoSoles = formatearMontosSoles(new BigDecimal(0));
		}
		return montoSoles;
	}

	public static String extraerHorasMinutos(Date fecha) {

		if (fecha == null) throw new IllegalArgumentException("fecha no puede ser null");
		
		// extrae las horas y minutos
		int horas = ViaticoUtil.extraerHoras24H(fecha);
		int minutos = ViaticoUtil.extraerMinutos(fecha);

		// arma formato HH:MM
		return formatearHorasMinutos(horas, minutos);
	}
	
	public static String formatearHorasMinutos(int horas, int minutos) {
		
		// arma formato HH:MM
		
		StringBuilder sb = new StringBuilder();

		sb.append(StringUtils.leftPad(String.valueOf(horas), 2, '0'));
		sb.append(FechaConstantes.DOS_PUNTOS);
		sb.append(StringUtils.leftPad(String.valueOf(minutos), 2, '0'));

		return sb.toString();
	}

	public static String obtenerFechaActual() {
		return formatDateToDateDDMMYYYY(new Date());
	}
	
	public static String obtenerAnioActual() {
		return formatDateToDateYYYY(new Date());
	}

	public static String obtenerMesActual() {
		return formatDateToDateMM(new Date());
	}

	public static ArrayList<Mes> obtenerMesesAnio() {

		ArrayList<Mes> mesList = new ArrayList<Mes>();
		String[] mesArray = { "enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre" };
		Mes mes;
		for (int i = 0; i < mesArray.length; i++) {
			mes = new Mes();
			mes.setCodigoMes(formatNumeroToStringWithCerosLeft(2, (i + 1)));
			mes.setDescripcionMes(mesArray[i]);
			mesList.add(mes);
		}
		return mesList;
	}

	public static String formatNumeroToStringWithCerosLeft(int numeroDigitos, int numero) {

		int numeroValorAbsoluto = Math.abs(numero);
		StringBuffer sb = new StringBuffer(numeroDigitos);
		int zeros = numeroDigitos - (int) (Math.log(numeroValorAbsoluto) / Math.log(10)) - 1;
		if (numero < 0) {
			sb.append(ViaticoConstantes.SIGNO_MINUS);
		}
		for (int i = 0; i < zeros; i++) {
			sb.append(0);
		}
		sb.append(numeroValorAbsoluto);
		return sb.toString();
	}

	public static String validarEmptyParameterRequest(String parameterRequest) {
		String finalParameterRequest = parameterRequest;
		if (ViaticoConstantes.CADENA_VACIA.equals(parameterRequest)) {
			finalParameterRequest = null;
		}
		return finalParameterRequest;
	}

	public static String obtenerValueParameterRequest(String request, String parameter) {

		Map<String, String> map = new HashMap<String, String>();
		if (request != null) {
			String[] requestArray = request.split(ViaticoConstantes.REQUEST_AND);
			for (int i = 0; i < requestArray.length; i++) {
				if (requestArray[i] != null && requestArray[i].contains(ViaticoConstantes.IGUAL)) {
					String[] parameterArray = requestArray[i].split(ViaticoConstantes.IGUAL);
					if (parameterArray.length > 1) {
						map.put(parameterArray[0], parameterArray[1]);
					} else {
						map.put(parameterArray[0], ViaticoConstantes.CADENA_VACIA);
					}
				}
			}
		}

		String valueParameter = map.get(parameter);
		return valueParameter;
	}

	public static int restarDias(Date fechaFinal, Date fechaInicial) {

		long diferenciaMiliSegs = fechaFinal.getTime() - fechaInicial.getTime();
		int diferenciaDias = (int) (Math.round((diferenciaMiliSegs) / (60.0 * 60 * 24 * 1000)));

		return diferenciaDias;
	}

	public static Double getDoubleFromMap(Map map, String key) {

		return getDoubleFromMap(map, key, null);
	}

	public static Double getDoubleFromMap(Map map, String key, Double defaultValue) {

		String valueString = MapUtils.getString(map, key);

		// si el valor no existe, es null, empty, blank o no es numero retorna el valor por defecto
		if (StringUtils.isBlank(valueString) || !NumberUtils.isNumber(valueString)) return defaultValue;

		return Double.parseDouble(StringUtils.trimToEmpty(valueString));
	}

	public static Integer getIntegerFromMap(Map map, String key) {

		return getIntegerFromMap(map, key, null);
	}

	public static Integer getIntegerFromMap(Map map, String key, Integer defaultValue) {

		String valueString = MapUtils.getString(map, key);

		// si el valor no existe, es null, empty o blank retorna el valor por defecto
		if (StringUtils.isBlank(valueString)) return defaultValue;

		return Integer.parseInt(StringUtils.trimToEmpty(valueString));
	}

	public static String getStringFromMap(Map map, String key) {

		return getStringFromMap(map, key, null);
	}

	public static String getStringFromMap(Map map, String key, String defaultValue) {

		String valueString = MapUtils.getString(map, key);

		// si el valor no existe, es null, empty o blank retorna el valor por defecto
		if (StringUtils.isBlank(valueString)) return defaultValue;

		return StringUtils.trimToEmpty(valueString);
	}

	public static String toJSON(List lista) {
		// asegurar que las listas no sean null
		return SojoUtil.toJson(lista == null ? new ArrayList() : lista);
	}

	public static Date addDiasToDate(Date fecha, int nroDias) {

		if (fecha == null) throw new IllegalArgumentException("fecha no puede ser null");

		Calendar copia = Calendar.getInstance();
		copia.setTime(fecha);

		// agregar dias calendario
		copia.add(Calendar.DATE, nroDias);

		return new Date(copia.getTimeInMillis());
	}

	public static Date addHorasToDate(Date fecha, int nroHoras) {

		if (fecha == null) throw new IllegalArgumentException("fecha no puede ser null");

		Calendar copia = Calendar.getInstance();
		copia.setTime(fecha);

		// agregar horas
		copia.add(Calendar.HOUR_OF_DAY, nroHoras);

		return new Date(copia.getTimeInMillis());
	}

	public static Date addMinutosToDate(Date fecha, int nroMinutos) {

		if (fecha == null) throw new IllegalArgumentException("fecha no puede ser null");

		Calendar copia = Calendar.getInstance();
		copia.setTime(fecha);

		// agregar minutos
		copia.add(Calendar.MINUTE, nroMinutos);

		return new Date(copia.getTimeInMillis());
	}

	public static Date addSegundosToDate(Date fecha, int nroSegundos) {

		if (fecha == null) throw new IllegalArgumentException("fecha no puede ser null");

		Calendar copia = Calendar.getInstance();
		copia.setTime(fecha);

		// agregar minutos
		copia.add(Calendar.SECOND, nroSegundos);

		return new Date(copia.getTimeInMillis());
	}

	public static int extraerHoras24H(Date fecha) {

		if (fecha == null) throw new IllegalArgumentException("fecha no puede ser null");

		Calendar copia = Calendar.getInstance();
		copia.setTime(fecha);

		return copia.get(Calendar.HOUR_OF_DAY);

	}

	public static int extraerHoras12H(Date fecha) {

		if (fecha == null) throw new IllegalArgumentException("fecha no puede ser null");

		Calendar copia = Calendar.getInstance();
		copia.setTime(fecha);

		return copia.get(Calendar.HOUR);
	}

	public static int extraerMinutos(Date fecha) {

		if (fecha == null) throw new IllegalArgumentException("fecha no puede ser null");

		Calendar copia = Calendar.getInstance();
		copia.setTime(fecha);

		return copia.get(Calendar.MINUTE);
	}

	public static int extraerSegundos(Date fecha) {

		if (fecha == null) throw new IllegalArgumentException("fecha no puede ser null");

		Calendar copia = Calendar.getInstance();
		copia.setTime(fecha);

		return copia.get(Calendar.SECOND);
	}

	public static String trimUpperCase(String cadena) {
		return StringUtils.trimToNull(StringUtils.upperCase(cadena));
	}
	
	public static List<PlanViajeBean> listaSinRepeditos(List<PlanViajeBean> lista) {
		HashSet<PlanViajeBean> hs = new HashSet<PlanViajeBean>();
		hs.addAll(lista);
		lista.clear();
		lista.addAll(hs);
		return lista;
		}

}
