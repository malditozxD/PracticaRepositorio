package pe.gob.sunat.recurso2.financiera.siga.viatico.reembolso.service;

import java.util.List;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeConceptoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeDestinoBean;

/**
 * Interfaz RegistroReembolsoService.
 * 
 * @author Juan Farro
 */
public interface RegistroReembolsoService {

	/**
	 * Metodo que permite registrar una solicitud viatico/reembolso.
	 * 
	 * @author Juan Farro
	 * @param anioActual anio actual
	 * @param uuoo uuoo
	 * @param planViajeBean solicitud de viatico/reembolso
	 * @param planViajeDestinos plan viaje destinos
	 * @param planViajeConceptos plan viaje conceptos
	 * @throws Exception
	 */
	void registrarSolicitudReembolso(String anioActual, String uuoo, PlanViajeBean planViajeBean, List<PlanViajeDestinoBean> planViajeDestinos, List<PlanViajeConceptoBean> planViajeConceptos) throws Exception;

	/**
	 * Metodo que permite modificar una solicitud viatico/reembolso.
	 * 
	 * @author Juan Farro
	 * @param planViajeBean solicitud de viatico/reembolso
	 * @param planViajeDestinos plan viaje destinos
	 * @param planViajeConceptos plan viaje conceptos
	 * @throws Exception
	 */
	void actualizarSolicitudReembolso(PlanViajeBean planViajeBean, List<PlanViajeDestinoBean> planViajeDestinos, List<PlanViajeConceptoBean> planViajeConceptos) throws Exception;

	/**
	 * Metodo que permite enviar una solicitud viatico/reembolso.
	 *
	 * @author Juan Farro
	 * @param codPlanViaje codigo de plan de viaje a enviar
	 * @param codigoEnviador codigo de empleado que realiza el envio
	 * @param tipoConfiguracion tipo de configuracion
	 * @return true, si tiene exito
	 * @throws Exception
	 */
	boolean enviarSolicitudReembolso(String codPlanViaje, String codigoEnviador, String tipoConfiguracion) throws Exception;
	
	/**
	 * Metodo que permite registrar el sustento gasto.
	 * @author Jorge Ponce.
	 * @param  planViajeBean :objeto que tiene los datos para registrar.
	 * @return Codigo de operacion: Exito(00), Error(01).
	 * @see    String
	 * @throws Exception
	 */
	String registrarSustentoGasto(PlanViajeBean planViajeBean) throws ServiceException, Exception;
	
	/**
	 * Metodo que permite anular una solicitud de viatico.
	 *
	 * @author Samuel Dionisio
	 * @param codPlanViaje codigo de solicitud de reembolso
	 * @param motivoAnulacion motivo de anulacion
	 * @param expedientePlanViaje expediente plan de viaje
	 * @param codigoAnulador codigo de empleado de la que realiza la anulacion
	 * @return codigo resultado de operacion
	 * @throws Exception
	 */
	String anularReembolsoRevision(String codPlanViaje, String motivoAnulacion, String expedientePlanViaje, String codigoAnulador) throws Exception;

}