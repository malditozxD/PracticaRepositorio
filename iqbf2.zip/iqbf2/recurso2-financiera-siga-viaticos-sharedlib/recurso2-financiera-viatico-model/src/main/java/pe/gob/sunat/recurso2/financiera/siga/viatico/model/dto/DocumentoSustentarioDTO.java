package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dto;

import java.util.List;

import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.T01ParametroBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeConceptoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeInformeDistribBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeRendicionBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.TipoDocumentoBean;

public class DocumentoSustentarioDTO {

	private List<PlanViajeRendicionBean> listaPlanViajeRendicion;
	private List<T01ParametroBean> listaExoneracion;
	private PlanViajeBean planViajeBean;
	private String moneda; //tipo de moneda del viatico
	private boolean estadoDocumentoSustentario; //estado del documento sustentatorio nuevo(false/editar(true)
	private List<PlanViajeInformeDistribBean> listaPlanViajeInformeDistrib;
	private Integer mensajeOut;
	private PlanViajeRendicionBean planViajeRendicionBean;
	private PlanViajeInformeDistribBean PlanViajeInformeDistribBean;
	private Integer estadoDocumento; 
	private String codigoDependencia;
	private String codigoColaborador;
	private String planViajeId;
	private String secuencial;
	private Double igv;
	private Double montoTotalRendicion;
	private List<TipoDocumentoBean> tipoDocumentoList;
	private List<PlanViajeConceptoBean> planViajeConceptoList;
	private String porcentajeDeclaracion;
	private String indExtDDJJ;
	private String montoTotalTotales;	
	
	public List<PlanViajeRendicionBean> getListaPlanViajeRendicion() {
		return listaPlanViajeRendicion;
	}

	public void setListaPlanViajeRendicion(List<PlanViajeRendicionBean> listaPlanViajeRendicion) {
		this.listaPlanViajeRendicion = listaPlanViajeRendicion;
	}

	public String getMoneda() {
		return moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public boolean isEstadoDocumentoSustentario() {
		return estadoDocumentoSustentario;
	}

	public void setEstadoDocumentoSustentario(boolean estadoDocumentoSustentario) {
		this.estadoDocumentoSustentario = estadoDocumentoSustentario;
	}

	public void setListaExoneracion(List<T01ParametroBean> listaExoneracion) {
		this.listaExoneracion = listaExoneracion;
	}

	public List<T01ParametroBean> getListaExoneracion() {
		return listaExoneracion;
	}

	public void setPlanViajeBean(PlanViajeBean planViajeBean) {
		this.planViajeBean = planViajeBean;
	}

	public PlanViajeBean getPlanViajeBean() {
		return planViajeBean;
	}

	public List<PlanViajeInformeDistribBean> getListaPlanViajeInformeDistrib() {
		return listaPlanViajeInformeDistrib;
	}

	public void setListaPlanViajeInformeDistrib(
			List<PlanViajeInformeDistribBean> listaPlanViajeInformeDistrib) {
		this.listaPlanViajeInformeDistrib = listaPlanViajeInformeDistrib;
	}

	public Integer getMensajeOut() {
		return mensajeOut;
	}

	public void setMensajeOut(Integer mensajeOut) {
		this.mensajeOut = mensajeOut;
	}

	public PlanViajeRendicionBean getPlanViajeRendicionBean() {
		return planViajeRendicionBean;
	}

	public void setPlanViajeRendicionBean(
			PlanViajeRendicionBean planViajeRendicionBean) {
		this.planViajeRendicionBean = planViajeRendicionBean;
	}

	public PlanViajeInformeDistribBean getPlanViajeInformeDistribBean() {
		return PlanViajeInformeDistribBean;
	}

	public void setPlanViajeInformeDistribBean(
			PlanViajeInformeDistribBean planViajeInformeDistribBean) {
		PlanViajeInformeDistribBean = planViajeInformeDistribBean;
	}

	public Integer getEstadoDocumento() {
		return estadoDocumento;
	}

	public void setEstadoDocumento(Integer estadoDocumento) {
		this.estadoDocumento = estadoDocumento;
	}

	public String getCodigoColaborador() {
		return codigoColaborador;
	}

	public void setCodigoColaborador(String codigoColaborador) {
		this.codigoColaborador = codigoColaborador;
	}

	public void setPlanViajeId(String planViajeId) {
		this.planViajeId = planViajeId;
	}

	public String getPlanViajeId() {
		return planViajeId;
	}

	public void setCodigoDependencia(String codigoDependencia) {
		this.codigoDependencia = codigoDependencia;
	}

	public String getCodigoDependencia() {
		return codigoDependencia;
	}

	public void setSecuencial(String secuencial) {
		this.secuencial = secuencial;
	}

	public String getSecuencial() {
		return secuencial;
	}

	public void setIgv(Double igv) {
		this.igv = igv;
	}

	public Double getIgv() {
		return igv;
	}

	public void setMontoTotalRendicion(Double montoTotalRendicion) {
		this.montoTotalRendicion = montoTotalRendicion;
	}

	public Double getMontoTotalRendicion() {
		return montoTotalRendicion;
	}

	public void setTipoDocumentoList(List<TipoDocumentoBean> tipoDocumentoList) {
		this.tipoDocumentoList = tipoDocumentoList;
	}

	public List<TipoDocumentoBean> getTipoDocumentoList() {
		return tipoDocumentoList;
	}

	/**
	 * @param planViajeConceptoList the planViajeConceptoList to set
	 */
	public void setPlanViajeConceptoList(List<PlanViajeConceptoBean> planViajeConceptoList) {
		this.planViajeConceptoList = planViajeConceptoList;
	}

	/**
	 * @return the planViajeConceptoList
	 */
	public List<PlanViajeConceptoBean> getPlanViajeConceptoList() {
		return planViajeConceptoList;
	}

	/**
	 * @param porcentajeDeclaracion the porcentajeDeclaracion to set
	 */
	public void setPorcentajeDeclaracion(String porcentajeDeclaracion) {
		this.porcentajeDeclaracion = porcentajeDeclaracion;
	}

	/**
	 * @return the porcentajeDeclaracion
	 */
	public String getPorcentajeDeclaracion() {
		return porcentajeDeclaracion;
	}

	/**
	 * @param indExtDDJJ the indExtDDJJ to set
	 */
	public void setIndExtDDJJ(String indExtDDJJ) {
		this.indExtDDJJ = indExtDDJJ;
	}

	/**
	 * @return the indExtDDJJ
	 */
	public String getIndExtDDJJ() {
		return indExtDDJJ;
	}

	/**
	 * @param montoTotalTotales the montoTotalTotales to set
	 */
	public void setMontoTotalTotales(String montoTotalTotales) {
		this.montoTotalTotales = montoTotalTotales;
	}

	/**
	 * @return the montoTotalTotales
	 */
	public String getMontoTotalTotales() {
		return montoTotalTotales;
	}

	
	
}
