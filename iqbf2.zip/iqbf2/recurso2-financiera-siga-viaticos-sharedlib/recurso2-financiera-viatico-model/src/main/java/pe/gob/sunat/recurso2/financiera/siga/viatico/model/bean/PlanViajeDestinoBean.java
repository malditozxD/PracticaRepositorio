package pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean;

import java.io.Serializable;
import java.util.Date;

public class PlanViajeDestinoBean implements Serializable {

	private static final long serialVersionUID = -7497256518218917957L;
	
	private String planViajeID;                               // PLAN_VIAJE_ID			not null
    private Integer secuencial;                               // SECUENCIAL				not null
    private String medioTransporte;                           // MEDIO_TRANSPORTE		not null
    private String sedeDestino;                               // SEDE_DESTINO			not null
    private Double dias;                                      // DIAS
    private Date fechaSalida;                                 // FECHA_SALIDA
    private String provinciaDestino;                          // PROVINCIA_DESTINO
    private String distritoDestino;                           // DISTRITO_DESTINO
    private String usuarioCreacion;                           // USER_CREA
    private Date fechaCreacion;                               // FECH_CREA
    private String usuarioModificacion;                       // USER_MODI
    private Date fechaModificacion;                           // FECH_MODI
    private Double montoDiario;                               // MTO_DIARIO
    private Integer diasExtra;                                // DIAS_EXTRA
    private Double montoDiarioTope;                           // MTO_DIARIO_TOPE
    private Integer diasExtraTope;                            // DIAS_EXTRA_TOPE
    private Double montoTraslado;                             // MTO_TRASLADO
    
    private String codigoDepartamentoDestino;         		  // COD_DEPA_DES
    private String codigoTarifarioInternacional;         	  // COD_TAR_INTER
    private Double porcTarifarioInternacional; 		          // POR_TAR_INTER
    
	private String fechaInicioFormateada;
	private String fechaSalidaFormateada;

	public String getPlanViajeID() {
		return planViajeID;
	}

	public void setPlanViajeID(String planViajeID) {
		this.planViajeID = planViajeID;
	}

	public Integer getSecuencial() {
		return secuencial;
	}

	public void setSecuencial(Integer secuencial) {
		this.secuencial = secuencial;
	}

	public String getMedioTransporte() {
		return medioTransporte;
	}

	public void setMedioTransporte(String medioTransporte) {
		this.medioTransporte = medioTransporte;
	}

	public String getSedeDestino() {
		return sedeDestino;
	}

	public void setSedeDestino(String sedeDestino) {
		this.sedeDestino = sedeDestino;
	}

	public Double getDias() {
		return dias;
	}

	public void setDias(Double dias) {
		this.dias = dias;
	}

	public Date getFechaSalida() {
		return fechaSalida;
	}

	public void setFechaSalida(Date fechaSalida) {
		this.fechaSalida = fechaSalida;
	}

	public String getProvinciaDestino() {
		return provinciaDestino;
	}

	public void setProvinciaDestino(String provinciaDestino) {
		this.provinciaDestino = provinciaDestino;
	}

	public String getDistritoDestino() {
		return distritoDestino;
	}

	public void setDistritoDestino(String distritoDestino) {
		this.distritoDestino = distritoDestino;
	}

	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}

	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public String getUsuarioModificacion() {
		return usuarioModificacion;
	}

	public void setUsuarioModificacion(String usuarioModificacion) {
		this.usuarioModificacion = usuarioModificacion;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public Double getMontoDiario() {
		return montoDiario;
	}

	public void setMontoDiario(Double montoDiario) {
		this.montoDiario = montoDiario;
	}

	public Integer getDiasExtra() {
		return diasExtra;
	}

	public void setDiasExtra(Integer diasExtra) {
		this.diasExtra = diasExtra;
	}

	public Double getMontoDiarioTope() {
		return montoDiarioTope;
	}

	public void setMontoDiarioTope(Double montoDiarioTope) {
		this.montoDiarioTope = montoDiarioTope;
	}

	public Integer getDiasExtraTope() {
		return diasExtraTope;
	}

	public void setDiasExtraTope(Integer diasExtraTope) {
		this.diasExtraTope = diasExtraTope;
	}

	public Double getMontoTraslado() {
		return montoTraslado;
	}

	public void setMontoTraslado(Double montoTraslado) {
		this.montoTraslado = montoTraslado;
	}

	public String getCodigoDepartamentoDestino() {
		return codigoDepartamentoDestino;
	}

	public void setCodigoDepartamentoDestino(String codigoDepartamentoDestino) {
		this.codigoDepartamentoDestino = codigoDepartamentoDestino;
	}

	public String getCodigoTarifarioInternacional() {
		return codigoTarifarioInternacional;
	}

	public void setCodigoTarifarioInternacional(
			String codigoTarifarioInternacional) {
		this.codigoTarifarioInternacional = codigoTarifarioInternacional;
	}

	public Double getPorcTarifarioInternacional() {
		return porcTarifarioInternacional;
	}

	public void setPorcTarifarioInternacional(Double porcTarifarioInternacional) {
		this.porcTarifarioInternacional = porcTarifarioInternacional;
	}

	public String getFechaInicioFormateada() {
		return fechaInicioFormateada;
	}

	public void setFechaInicioFormateada(String fechaInicioFormateada) {
		this.fechaInicioFormateada = fechaInicioFormateada;
	}

	public String getFechaSalidaFormateada() {
		return fechaSalidaFormateada;
	}

	public void setFechaSalidaFormateada(String fechaSalidaFormateada) {
		this.fechaSalidaFormateada = fechaSalidaFormateada;
	}

}