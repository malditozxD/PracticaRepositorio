package pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

// codPlanViaje;       // PLAN_VIAJE_ID      (campo legado: se tomo del bean original) -> PRIMARY KEY DE LA TABLA
// codPlanilla;        // COD_PLANILLA_VIAJE (campo legado: se tomo del bean original) -> COD_PLANILLA_VIAJE: A?O VIGENTE + UUOO + CORRELATIVO 5 CARACTERES; 
// codigoPlanillaAsc;  // COD_PLANILLA_ASC   (secuencial codigo planilla asociada)

public class PlanViajeBean implements Serializable {

	private static final long serialVersionUID = -5478560212665494399L;

	// CAMPOS REGISTRO - TODOS LOS CAMPOS DE LA TABLA SIGUIENDO EL CONVENIO CORRECTO DE NOMBRES (SALVO CAMPOS LEGADOS QUE YA ESTABAN EN EL BEAN)
	private String codPlanViaje; // PLAN_VIAJE_ID (campo legado: se tomo del bean original)
	private String codTrabajador; // TRABAJADOR (campo legado: se tomo del bean original)
	private Date fechaRegistro; // FECHA_REGISTRO
	private Date fechaAprobacion; // FECHA_APROBACION
	private Date fechaHoraProgSalida; // FECHA_HORA_PROG_SALIDA
	private Date fechaHoraProgRetorno; // FECHA_HORA_PROG_RETORNO
	private Double numeroDias; // NUMERO_DIAS
	private String presupuestoAnno; // PRESUPUESTO_ANNO
	private String presupuestoMeta; // PRESUPUESTO_META
	private String presupuestoMes; // PRESUPUESTO_MES
	private String sedeOrigen; // SEDE_ORIGEN
	private Double montoTotal; // MONTO_TOTAL
	private String origen; // ORIGEN
	private String tipoDestino; // TIPO_DESTINO
	private String destinoExterior; // DESTINO_EXTERIOR
	private String internacionalNroResolucion; // INTERNACIONAL_NRO_RESOLUCION
	private Date internacionalFechaResolucion; // INTERNACIONAL_FECHA_RESOLUCION
	private Double internacionalMontoResolucion; // INTERNACIONAL_MONTO_RESOLUCION
	private Double tipoCambio; // TIPO_CAMBIO
	private String moneda; // MONEDA
	private String poaProgramado; // POA_PROGRAMADO
	private String solicitanteViaje; // SOLICITANTE_VIAJE
	private String documentosAntecedentes; // DOCUMENTOS_ANTECEDENTES
	private String instruccionesRecibidas; // INSTRUCCIONES_RECIBIDAS
	private String personaAutorizacionVigente; // PERSONA_AUTORIZACION_VIGENTE
	private String formaPago; // FORMA_PAGO
	private Date fechaHoraEjeSalida; // FECHA_HORA_EJE_SALIDA
	private Date fechaHoraEjeRetorno; // FECHA_HORA_EJE_RETORNO
	private Date fechaRendicion; // FECHA_RENDICION
	private String estadoPlanViaje; // ESTADO_PLAN_VIAJE
	private String estadoRendicion; // ESTADO_RENDICION
	private String numeroRegistroArchivo; // NUMERO_REGISTRO_ARCHIVO
	private String expedientePlanViaje; // EXPEDIENTE_PLAN_VIAJE
	private String expedienteRendicion; // EXPEDIENTE_RENDICION
	private String sedePlanViaje; // SEDE_PLAN_VIAJE
	private String medioTransporteRetorno; // MEDIO_TRANSPORTE_RETORNO
	private String trabajadorEncargado; // TRABAJADOR_ENCARGADO
	private String indicadorReciboProvisional; // INDICADOR_RECIBO_PROVISIONAL
	private String usoMovilidadEmpresa; // USO_MOVILIDAD_EMPRESA
	private Date fechaDepositoDevol; // FECHA_DEPOSITO_DEVOL
	private Double montoDevol; // MONTO_DEVOL
	private String tipoDevolucion; // TIPO_DEVOLUCION
	private String numeroPapeleta; // NUMERO_PAPELETA
	private String usuarioCreacion; // USER_CREA
	private Date fechaCreacion; // FECH_CREA
	private String usuarioModificacion; // USER_MODI
	private Date fechaModificacion; // FECH_MODI
	private String codPlanilla; // COD_PLANILLA_VIAJE (campo legado: se tomo del bean original)
	private Double montoDevuelto; // MTO_DEVUELTO
	private Date fechaInicioAccion; // FEC_INICIO_ACCION
	private String codigoBancBan; // CODI_BANC_BAN
	private Date fechaAnulacion; // FEC_ANULACION
	private Date fechaAutorizacion; // FEC_AUTORIZACION
	private Date fechaEnviofin; // FEC_ENVIOFIN
	private Date fechaEnvioPre; // FEC_ENVIO_PRE
	private Date fechaFinAccion; // FEC_FIN_ACCION
	private Date fechaMaxRendicion; // FEC_MAX_RENDICION
	private Date fechaNotificacion; // FEC_NOTIFICACION
	private Date fechaObservacion; // FEC_OBSERVACION
	private Date fechaObsTraslape; // FEC_OBS_TRASLAPE
	private Date fechaPago; // FEC_PAGO
	private Date fechaVerificacion; // FEC_VERIFICACION
	private Date fechaVizAsis; // FEC_VIZ_ASIS
	private String indicadorAutorizacion; // IND_AUTORIZACION
	private String indicadorExtDdjj; // IND_EXT_DDJJ
	private String indicadorHoras; // IND_HORAS
	private String indicadorMenGast; // IND_MEN_GAST
	private String indicadorModoPago; // IND_MODO_PAGO
	private String indicadorRuta; // IND_RUTA
	private String indicadorSegNotif; // IND_SEG_NOTIF
	private String indicadorTipoTraslado; // IND_TIPO_TRASLADO
	private String indicadorTraslape; // IND_TRASLAPE
	private String observacionAnulacion; // OBS_ANULACION
	private String observacionAutorizacion; // OBS_AUTORIZACION
	private String observacionAutorizador; // OBS_AUTORIZADOR
	private String observacionRendicion; // OBS_RENDICION
	private String observacionSolicitud; // OBS_SOLICITUD
	private String observacionTraslape; // OBS_TRASLAPE
	private String codigoDependencia; // COD_DEPENDENCIA (campo legado: se tomo del bean original)
	private String codigoDestExtranjero; // COD_DEST_EXTRANJERO
	private String codigoNivel; // COD_NIVEL
	private String codigoNivAutor; // COD_NIV_AUTOR
	private String codigoPlanillaAsc; // COD_PLANILLA_ASC
	private String codigoPlanViajeID; // COD_PLAN_VIAJE_ID
	private String codigoRegistrador; // COD_REGISTRADOR
	private String codigoTipoTraslado; // COD_TIPO_TRASLADO
	private String codigoUsurendicion; // COD_USURENDICION
	private String codigoUsuverificacion; // COD_USUVERIFICACION
	private String descripcionJustRep; // DES_JUST_REP
	private String codigoTipoMotReembolso; // COD_TIP_MOT_REEM (antes era TIP_MOT_REEM)
	private String codigoEstadoPago; // COD_ESTPAGO (antes era COD_ESPAGO)
	private Double montoTopeViaticoInternacional; // MTO_TOPE_VIAT_INTER
	private Double numeroHoras; // NRO_HORAS
	private String numeroResolRem; // NUM_RESOL_REM (antes era NRO_RESOL_REM)
	private Long numeroCasecid; // NUM_CASECID
	private Long numeroCcpsecid; // NUM_CCPSECID
	private String numeroRegistro; // NUM_REGISTRO
	private String numeroRegiCab; // NUM_REGI_CAB
	private String niveViatNvi; // NIVE_VIAT_NVI
	private String codigoDepAutor; // COD_DEP_AUTOR (nuevo campo 20160103)
	private String codigoCargoEmpleado; // COD_CARGO_EMP (nuevo campo 20160103)
	private Date fechaRegistroRendicion; // FEC_REG_RENDICION (nuevo campo 20160103)
	private Date fechaItinerarioSalida; // FEC_ITI_SALIDA (nuevo campo 20160602)
	private Date fechaItinerarioRetorno; // FEC_ITI_RETORNO (nuevo campo 20160602)
	private Date fechaHoraProgSalidaDDMMYYYY;
	private Date fechaHoraProgRetornoDDMMYYYY;
	// FIN CAMPOS REGISTRO

	// CAMPOS UTILIZADOS EN LAS BANDEJAS

	// CAMPOS USADOS EN CONSULTA
	private Date fecRend; // FECHA_HORA_PROG_RETORNO +1
	private String numeroRegistroAlterno;
	private String nomColaborador; // SIP_VIATICOS.FN_GET_COLABORADOR
	private String nomTipoViatico; // TIPO_VIATICO
	private String mtoTotal; // MONTO_TOTAL
	private String mtoTotalFormateado;
	private Integer cantDiasRend; // DIAS_RENDICION
	private String codEstadoRend; // CODIGO DE ESTADO DE RENDICION
	private String nomEstRend; // DESC. ESTADO RENDICION
	private String numExpRend; // NUMERO DE EXPEDIENTE DE RENDICION
	private String obsRendicion; // OBSERVACION DE RENDICION
	private String detalle; // DETALLE
	private String seguimiento; // SEGUIMIENTO
	private String ver; // VER
	private String numArchivo; // NUMERO_REGISTRO_ARCHIVO
	private Date fecPagoCajaCh; // FECHA DE PAGO CAJA CHICA
	private String fecPagoCajaChFormateado; // FECHA DE PAGO CAJA CHICA

	// CAMPOS USADOS EN CONSULTA PLANILLA VIATICO
	private String nomRegistrador; // NOMBRE_REGISTRADOR
	private String nomUuOoCom; // UUOO_COMISIONADO
	private Date fecSalida; // FECHA_SALIDA
	private Date fecRetorno; // FECHA_RETORNO
	private Date fecSalidaEjecutada; // FECHA_SALIDA_EJECUTADA
	private Date fecRetornoEjecutada; // FECHA_RETORNO_EJECUTADA
	private String fecSalidaFormateada;
	private String fecRetornoFormateada;
	private String fecNotificacionFormateada;
	private String horaSalidaFormateada;
	private String horaRetornoFormateada;
	private String fecSalidaEjecutadaFormateada;
	private String fecRetornoEjecutadaFormateada;
	private String itinerario; // ITINERARIO
	private String indicadorCanalAtencion; // CANAL_DE_ATENCION
	private String canalAtencion; // CANAL_DE_ATENCION
	private Integer numDias; // TOTAL_DIAS_COMISION
	private String motivoComis; // MOTIVO_COMISION
	private String impAsigPasajes; // ASIGNACION_PASAJES
	private String impOtros; // OTROS
	private String impTotalOtorgado;// TOTAL_OTORGADO
	private String impAsigPasajesFormateado;
	private String impOtrosFormateado;
	private String impTotalOtorgadoFormateado;
	private String indicadorExteriorDDJJ;
	private String indicadorMenorGasto;
	private String anioPresupuesto;
	private String metaPresupuesto;

	// CAMPOS USADOS EN CONSULTA DETALLE GASTO
	private String impGastoAloj; // IMPORTE GASTO ALOJAMIENTO
	private String impGastoAlim; // IMPORTE GASTO ALIMENTACION
	private String impGastoMovLocal;// IMPORTE GASTO MOVILIDAD LOCAL
	private String impGastoTraslado;// IMPORTE GASTO DE TRALADO
	private String impGastoPasajes; // IMPORTE GASTO DE PASAJES
	private String impGastoTUUA; // IMPORTE TUUA
	private String impGasto; // IMPORTE GASTO
	private String impDevuelto; // IMPORTE DEVUELTO
	private String impDevolMenor; // IMPORTE DEVOLUCION MENOR
	private String numReciboProv; // NUMERO DE RECIBO PROVISIONAL
	private String impGastoAlojFormateado;
	private String impGastoAlimFormateado;
	private String impGastoMovLocalFormateado;
	private String impGastoTrasladoFormateado;
	private String impGastoPasajesFormateado;
	private String impGastoTUUAFormateado;
	private String impGastoFormateado;
	private String impDevueltoFormateado;
	private String impDevolMenorFormateado;

	// CAMPOS USADOS EN CONSULTA SOLICITUD
	private Date fecRegistro; // FECHA_REGISTRO
	private String anular; // ANULAR
	private String numeroRegistroAutorizador;
	private String nomAutorizador; // NOMBRE_AUTORIZADOR
	private String impAsigViatico; // IMPORTE ASIGNADO VIATICO
	private String impPasaje; // IMPORTE DE PASAJE
	private String impAsigViaticoFormateado;
	private String medioPago; // MEDIO DE PAGO
	private String codEstadoSolic; // CODIGO DE ESTADO DE SOLICITUD
	private String nomEstSolic; // DESC. ESTADO SOLICITUD
	private String numExpSolic; // NUMERO DE EXPEDIENTE DE SOLICITUD
	private String obsSolicitud; // OBSERVACION DE SOLICITUD
	private String obsAnulacion; // OBSERVACION DE ANULACION DE SOLICITUD
	private String obsAutorizador; // OBSERVACION DEL AUTORIZADOR
	private String indTraslape; // INDICADOR DE TRASLAPE

	// OTROS
	private Date fecAprobacion; // FECHA_APROBACION
	private Date fecMaxRend; // FEC_MAX_RENDICION
	private String fecMaxRendFormateada;
	private String codPerAnula; // CODIGO COLABORADOR DE REGISTRADOR QUE ANULA (ANULA SOLICITUD)
	private String codPerObserva; // CODIGO COLABORADOR DE AUTORIZADOR QUE OBSERVA (OBSERVA SOLICITUD)
	private String codPerAutoriza; // CODIGO COLABORADOR DE AUTORIZADOR DEGASTO AUTORIZA (PERSONA_AUTORIZACION_VIGENTE) (AUTORIZA SOLICITUD)
	private String fechaRegistroFormateada;

	private String fechaRegistroRendicionFormateda;
	private String fechaNotificacionFormateada;
	private String flagMenorIgual4Horas;
	private String flagDeclaracion;
	private int numeroDeclaracionViatico;
	private BigDecimal montoMenorGasto;
	private BigDecimal montoAsignadoTotal;
	private BigDecimal montoAsignacionViatico;
	private BigDecimal montoDeclaracionTotal;
	private BigDecimal montoDeclaracionViatico;
	private String montoDevueltoFormateado;
	private String montoDevolFormateado;
	private String montoMenorGastoFormateado;
	private String observacionDCP;
	
	//JMCR-ME Fecha Reprogramacion
	
	private String codEmpReprog;
	private Date fecReprog;
	private String fecReprogFormateada;
	private String userModi;
	private Date fechModi;
	
	private Date fecReprogramaRend; // FEC_REPROG
	private String fecReprogramaRendFormateada;

	public String getFecReprogFormateada() {
		return fecReprogFormateada;
	}

	public void setFecReprogFormateada(String fecReprogFormateada) {
		this.fecReprogFormateada = fecReprogFormateada;
	}

	public String getUserModi() {
		return userModi;
	}

	public void setUserModi(String userModi) {
		this.userModi = userModi;
	}

	public Date getFechModi() {
		return fechModi;
	}

	public void setFechModi(Date fechModi) {
		this.fechModi = fechModi;
	}

	public String getCodEmpReprog() {
		return codEmpReprog;
	}

	public void setCodEmpReprog(String codEmpReprog) {
		this.codEmpReprog = codEmpReprog;
	}

	public Date getFecReprog() {
		return fecReprog;
	}

	public void setFecReprog(Date fecReprog) {
		this.fecReprog = fecReprog;
	}

	//JMCR-ME Fecha Reprogramacion
	
	
	private Date fechaHoraProgRetornoSiguiente; // FECHA_HORA_PROG_RETORNO DIA SIGUIENTE
	
	private String codOsa;

	public PlanViajeBean() {
	}

	
	public Date getFechaHoraProgRetornoSiguiente() {
		return fechaHoraProgRetornoSiguiente;
	}


	public void setFechaHoraProgRetornoSiguiente(Date fechaHoraProgRetornoSiguiente) {
		this.fechaHoraProgRetornoSiguiente = fechaHoraProgRetornoSiguiente;
	}


	public String getCodPlanViaje() {
		return codPlanViaje;
	}

	public void setCodPlanViaje(String codPlanViaje) {
		this.codPlanViaje = codPlanViaje;
	}

	public String getCodTrabajador() {
		return codTrabajador;
	}

	public void setCodTrabajador(String codTrabajador) {
		this.codTrabajador = codTrabajador;
	}

	public Date getFecAprobacion() {
		return fecAprobacion;
	}

	public void setFecAprobacion(Date fecAprobacion) {
		this.fecAprobacion = fecAprobacion;
	}

	public String getCodPlanilla() {
		return codPlanilla;
	}

	public void setCodPlanilla(String codPlanilla) {
		this.codPlanilla = codPlanilla;
	}

	public Date getFecMaxRend() {
		return fecMaxRend;
	}

	public void setFecMaxRend(Date fecMaxRend) {
		this.fecMaxRend = fecMaxRend;
	}

	public String getFecMaxRendFormateada() {
		return fecMaxRendFormateada;
	}

	public void setFecMaxRendFormateada(String fecMaxRendFormateada) {
		this.fecMaxRendFormateada = fecMaxRendFormateada;
	}

	public Date getFecRend() {
		return fecRend;
	}

	public void setFecRend(Date fecRend) {
		this.fecRend = fecRend;
	}

	public String getNumeroRegistroAlterno() {
		return numeroRegistroAlterno;
	}

	public void setNumeroRegistroAlterno(String numeroRegistroAlterno) {
		this.numeroRegistroAlterno = numeroRegistroAlterno;
	}

	public String getNomColaborador() {
		return nomColaborador;
	}

	public void setNomColaborador(String nomColaborador) {
		this.nomColaborador = nomColaborador;
	}

	public String getCodigoDependencia() {
		return codigoDependencia;
	}

	public void setCodigoDependencia(String codigoDependencia) {
		this.codigoDependencia = codigoDependencia;
	}

	public String getTipoDestino() {
		return tipoDestino;
	}

	public void setTipoDestino(String tipoDestino) {
		this.tipoDestino = tipoDestino;
	}

	public String getNomTipoViatico() {
		return nomTipoViatico;
	}

	public void setNomTipoViatico(String nomTipoViatico) {
		this.nomTipoViatico = nomTipoViatico;
	}

	public String getMoneda() {
		return moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public String getMtoTotal() {
		return mtoTotal;
	}

	public void setMtoTotal(String mtoTotal) {
		this.mtoTotal = mtoTotal;
	}

	public String getMtoTotalFormateado() {
		return mtoTotalFormateado;
	}

	public void setMtoTotalFormateado(String mtoTotalFormateado) {
		this.mtoTotalFormateado = mtoTotalFormateado;
	}

	public Integer getCantDiasRend() {
		return cantDiasRend;
	}

	public void setCantDiasRend(Integer cantDiasRend) {
		this.cantDiasRend = cantDiasRend;
	}

	public String getCodEstadoRend() {
		return codEstadoRend;
	}

	public void setCodEstadoRend(String codEstadoRend) {
		this.codEstadoRend = codEstadoRend;
	}

	public String getNomEstRend() {
		return nomEstRend;
	}

	public void setNomEstRend(String nomEstRend) {
		this.nomEstRend = nomEstRend;
	}

	public String getNumExpRend() {
		return numExpRend;
	}

	public void setNumExpRend(String numExpRend) {
		this.numExpRend = numExpRend;
	}

	public String getObsRendicion() {
		return obsRendicion;
	}

	public void setObsRendicion(String obsRendicion) {
		this.obsRendicion = obsRendicion;
	}

	public String getDetalle() {
		return detalle;
	}

	public void setDetalle(String detalle) {
		this.detalle = detalle;
	}

	public String getSeguimiento() {
		return seguimiento;
	}

	public void setSeguimiento(String seguimiento) {
		this.seguimiento = seguimiento;
	}

	public String getVer() {
		return ver;
	}

	public void setVer(String ver) {
		this.ver = ver;
	}

	public String getNumArchivo() {
		return numArchivo;
	}

	public void setNumArchivo(String numArchivo) {
		this.numArchivo = numArchivo;
	}

	public Date getFecPagoCajaCh() {
		return fecPagoCajaCh;
	}

	public void setFecPagoCajaCh(Date fecPagoCajaCh) {
		this.fecPagoCajaCh = fecPagoCajaCh;
	}

	public String getFecPagoCajaChFormateado() {
		return fecPagoCajaChFormateado;
	}

	public void setFecPagoCajaChFormateado(String fecPagoCajaChFormateado) {
		this.fecPagoCajaChFormateado = fecPagoCajaChFormateado;
	}

	public String getNomRegistrador() {
		return nomRegistrador;
	}

	public void setNomRegistrador(String nomRegistrador) {
		this.nomRegistrador = nomRegistrador;
	}

	public String getNomUuOoCom() {
		return nomUuOoCom;
	}

	public void setNomUuOoCom(String nomUuOoCom) {
		this.nomUuOoCom = nomUuOoCom;
	}

	public Date getFecSalida() {
		return fecSalida;
	}

	public void setFecSalida(Date fecSalida) {
		this.fecSalida = fecSalida;
	}

	public Date getFecRetorno() {
		return fecRetorno;
	}

	public void setFecRetorno(Date fecRetorno) {
		this.fecRetorno = fecRetorno;
	}

	public Date getFecSalidaEjecutada() {
		return fecSalidaEjecutada;
	}

	public void setFecSalidaEjecutada(Date fecSalidaEjecutada) {
		this.fecSalidaEjecutada = fecSalidaEjecutada;
	}

	public Date getFecRetornoEjecutada() {
		return fecRetornoEjecutada;
	}

	public void setFecRetornoEjecutada(Date fecRetornoEjecutada) {
		this.fecRetornoEjecutada = fecRetornoEjecutada;
	}

	public String getFecSalidaFormateada() {
		return fecSalidaFormateada;
	}

	public void setFecSalidaFormateada(String fecSalidaFormateada) {
		this.fecSalidaFormateada = fecSalidaFormateada;
	}

	public String getFecRetornoFormateada() {
		return fecRetornoFormateada;
	}

	public void setFecRetornoFormateada(String fecRetornoFormateada) {
		this.fecRetornoFormateada = fecRetornoFormateada;
	}

	public String getHoraSalidaFormateada() {
		return horaSalidaFormateada;
	}

	public void setHoraSalidaFormateada(String horaSalidaFormateada) {
		this.horaSalidaFormateada = horaSalidaFormateada;
	}

	public String getHoraRetornoFormateada() {
		return horaRetornoFormateada;
	}

	public void setHoraRetornoFormateada(String horaRetornoFormateada) {
		this.horaRetornoFormateada = horaRetornoFormateada;
	}

	public String getItinerario() {
		return itinerario;
	}

	public void setItinerario(String itinerario) {
		this.itinerario = itinerario;
	}

	public String getIndicadorCanalAtencion() {
		return indicadorCanalAtencion;
	}

	public void setIndicadorCanalAtencion(String indicadorCanalAtencion) {
		this.indicadorCanalAtencion = indicadorCanalAtencion;
	}

	public String getCanalAtencion() {
		return canalAtencion;
	}

	public void setCanalAtencion(String canalAtencion) {
		this.canalAtencion = canalAtencion;
	}

	public Integer getNumDias() {
		return numDias;
	}

	public void setNumDias(Integer numDias) {
		this.numDias = numDias;
	}

	public String getMotivoComis() {
		return motivoComis;
	}

	public void setMotivoComis(String motivoComis) {
		this.motivoComis = motivoComis;
	}

	public String getImpAsigPasajes() {
		return impAsigPasajes;
	}

	public void setImpAsigPasajes(String impAsigPasajes) {
		this.impAsigPasajes = impAsigPasajes;
	}

	public String getImpOtros() {
		return impOtros;
	}

	public void setImpOtros(String impOtros) {
		this.impOtros = impOtros;
	}

	public String getImpTotalOtorgado() {
		return impTotalOtorgado;
	}

	public void setImpTotalOtorgado(String impTotalOtorgado) {
		this.impTotalOtorgado = impTotalOtorgado;
	}

	public String getImpAsigPasajesFormateado() {
		return impAsigPasajesFormateado;
	}

	public void setImpAsigPasajesFormateado(String impAsigPasajesFormateado) {
		this.impAsigPasajesFormateado = impAsigPasajesFormateado;
	}

	public String getImpOtrosFormateado() {
		return impOtrosFormateado;
	}

	public void setImpOtrosFormateado(String impOtrosFormateado) {
		this.impOtrosFormateado = impOtrosFormateado;
	}

	public String getImpTotalOtorgadoFormateado() {
		return impTotalOtorgadoFormateado;
	}

	public void setImpTotalOtorgadoFormateado(String impTotalOtorgadoFormateado) {
		this.impTotalOtorgadoFormateado = impTotalOtorgadoFormateado;
	}

	public String getIndicadorExteriorDDJJ() {
		return indicadorExteriorDDJJ;
	}

	public void setIndicadorExteriorDDJJ(String indicadorExteriorDDJJ) {
		this.indicadorExteriorDDJJ = indicadorExteriorDDJJ;
	}

	public String getIndicadorMenorGasto() {
		return indicadorMenorGasto;
	}

	public void setIndicadorMenorGasto(String indicadorMenorGasto) {
		this.indicadorMenorGasto = indicadorMenorGasto;
	}

	public String getAnioPresupuesto() {
		return anioPresupuesto;
	}

	public void setAnioPresupuesto(String anioPresupuesto) {
		this.anioPresupuesto = anioPresupuesto;
	}

	public String getMetaPresupuesto() {
		return metaPresupuesto;
	}

	public void setMetaPresupuesto(String metaPresupuesto) {
		this.metaPresupuesto = metaPresupuesto;
	}

	public String getImpGastoAloj() {
		return impGastoAloj;
	}

	public void setImpGastoAloj(String impGastoAloj) {
		this.impGastoAloj = impGastoAloj;
	}

	public String getImpGastoAlim() {
		return impGastoAlim;
	}

	public void setImpGastoAlim(String impGastoAlim) {
		this.impGastoAlim = impGastoAlim;
	}

	public String getImpGastoMovLocal() {
		return impGastoMovLocal;
	}

	public void setImpGastoMovLocal(String impGastoMovLocal) {
		this.impGastoMovLocal = impGastoMovLocal;
	}

	public String getImpGastoTraslado() {
		return impGastoTraslado;
	}

	public void setImpGastoTraslado(String impGastoTraslado) {
		this.impGastoTraslado = impGastoTraslado;
	}

	public String getImpGastoPasajes() {
		return impGastoPasajes;
	}

	public void setImpGastoPasajes(String impGastoPasajes) {
		this.impGastoPasajes = impGastoPasajes;
	}
	
	public String getImpGastoTUUA() {
		return impGastoTUUA;
	}

	public void setImpGastoTUUA(String impGastoTUUA) {
		this.impGastoTUUA = impGastoTUUA;
	}

	public String getImpGasto() {
		return impGasto;
	}

	public void setImpGasto(String impGasto) {
		this.impGasto = impGasto;
	}

	public String getImpDevuelto() {
		return impDevuelto;
	}

	public void setImpDevuelto(String impDevuelto) {
		this.impDevuelto = impDevuelto;
	}

	public String getImpDevolMenor() {
		return impDevolMenor;
	}

	public void setImpDevolMenor(String impDevolMenor) {
		this.impDevolMenor = impDevolMenor;
	}

	public String getNumReciboProv() {
		return numReciboProv;
	}

	public void setNumReciboProv(String numReciboProv) {
		this.numReciboProv = numReciboProv;
	}

	public String getImpGastoAlojFormateado() {
		return impGastoAlojFormateado;
	}

	public void setImpGastoAlojFormateado(String impGastoAlojFormateado) {
		this.impGastoAlojFormateado = impGastoAlojFormateado;
	}

	public String getImpGastoAlimFormateado() {
		return impGastoAlimFormateado;
	}

	public void setImpGastoAlimFormateado(String impGastoAlimFormateado) {
		this.impGastoAlimFormateado = impGastoAlimFormateado;
	}

	public String getImpGastoMovLocalFormateado() {
		return impGastoMovLocalFormateado;
	}

	public void setImpGastoMovLocalFormateado(String impGastoMovLocalFormateado) {
		this.impGastoMovLocalFormateado = impGastoMovLocalFormateado;
	}

	public String getImpGastoTrasladoFormateado() {
		return impGastoTrasladoFormateado;
	}

	public void setImpGastoTrasladoFormateado(String impGastoTrasladoFormateado) {
		this.impGastoTrasladoFormateado = impGastoTrasladoFormateado;
	}

	public String getImpGastoPasajesFormateado() {
		return impGastoPasajesFormateado;
	}

	public void setImpGastoPasajesFormateado(String impGastoPasajesFormateado) {
		this.impGastoPasajesFormateado = impGastoPasajesFormateado;
	}

	public String getImpGastoTUUAFormateado() {
		return impGastoTUUAFormateado;
	}

	public void setImpGastoTUUAFormateado(String impGastoTUUAFormateado) {
		this.impGastoTUUAFormateado = impGastoTUUAFormateado;
	}

	public String getImpGastoFormateado() {
		return impGastoFormateado;
	}

	public void setImpGastoFormateado(String impGastoFormateado) {
		this.impGastoFormateado = impGastoFormateado;
	}

	public String getImpDevueltoFormateado() {
		return impDevueltoFormateado;
	}

	public void setImpDevueltoFormateado(String impDevueltoFormateado) {
		this.impDevueltoFormateado = impDevueltoFormateado;
	}

	public String getImpDevolMenorFormateado() {
		return impDevolMenorFormateado;
	}

	public void setImpDevolMenorFormateado(String impDevolMenorFormateado) {
		this.impDevolMenorFormateado = impDevolMenorFormateado;
	}

	public Date getFecRegistro() {
		return fecRegistro;
	}

	public void setFecRegistro(Date fecRegistro) {
		this.fecRegistro = fecRegistro;
	}

	public String getAnular() {
		return anular;
	}

	public void setAnular(String anular) {
		this.anular = anular;
	}

	public String getNumeroRegistroAutorizador() {
		return numeroRegistroAutorizador;
	}

	public void setNumeroRegistroAutorizador(String numeroRegistroAutorizador) {
		this.numeroRegistroAutorizador = numeroRegistroAutorizador;
	}

	public String getNomAutorizador() {
		return nomAutorizador;
	}

	public void setNomAutorizador(String nomAutorizador) {
		this.nomAutorizador = nomAutorizador;
	}

	public String getImpAsigViatico() {
		return impAsigViatico;
	}

	public void setImpAsigViatico(String impAsigViatico) {
		this.impAsigViatico = impAsigViatico;
	}

	public String getImpPasaje() {
		return impPasaje;
	}

	public void setImpPasaje(String impPasaje) {
		this.impPasaje = impPasaje;
	}

	public String getImpAsigViaticoFormateado() {
		return impAsigViaticoFormateado;
	}

	public void setImpAsigViaticoFormateado(String impAsigViaticoFormateado) {
		this.impAsigViaticoFormateado = impAsigViaticoFormateado;
	}

	public String getMedioPago() {
		return medioPago;
	}

	public void setMedioPago(String medioPago) {
		this.medioPago = medioPago;
	}

	public String getCodEstadoSolic() {
		return codEstadoSolic;
	}

	public void setCodEstadoSolic(String codEstadoSolic) {
		this.codEstadoSolic = codEstadoSolic;
	}

	public String getNomEstSolic() {
		return nomEstSolic;
	}

	public void setNomEstSolic(String nomEstSolic) {
		this.nomEstSolic = nomEstSolic;
	}

	public String getNumExpSolic() {
		return numExpSolic;
	}

	public void setNumExpSolic(String numExpSolic) {
		this.numExpSolic = numExpSolic;
	}

	public String getObsSolicitud() {
		return obsSolicitud;
	}

	public void setObsSolicitud(String obsSolicitud) {
		this.obsSolicitud = obsSolicitud;
	}

	public String getObsAnulacion() {
		return obsAnulacion;
	}

	public void setObsAnulacion(String obsAnulacion) {
		this.obsAnulacion = obsAnulacion;
	}

	public String getObsAutorizador() {
		return obsAutorizador;
	}

	public void setObsAutorizador(String obsAutorizador) {
		this.obsAutorizador = obsAutorizador;
	}

	public String getIndTraslape() {
		return indTraslape;
	}

	public void setIndTraslape(String indTraslape) {
		this.indTraslape = indTraslape;
	}

	public String getCodPerAnula() {
		return codPerAnula;
	}

	public void setCodPerAnula(String codPerAnula) {
		this.codPerAnula = codPerAnula;
	}

	public String getCodPerObserva() {
		return codPerObserva;
	}

	public void setCodPerObserva(String codPerObserva) {
		this.codPerObserva = codPerObserva;
	}

	public String getCodPerAutoriza() {
		return codPerAutoriza;
	}

	public void setCodPerAutoriza(String codPerAutoriza) {
		this.codPerAutoriza = codPerAutoriza;
	}

	public Date getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public Date getFechaAprobacion() {
		return fechaAprobacion;
	}

	public void setFechaAprobacion(Date fechaAprobacion) {
		this.fechaAprobacion = fechaAprobacion;
	}

	public Date getFechaHoraProgSalida() {
		return fechaHoraProgSalida;
	}

	public void setFechaHoraProgSalida(Date fechaHoraProgSalida) {
		this.fechaHoraProgSalida = fechaHoraProgSalida;
	}

	public Date getFechaHoraProgRetorno() {
		return fechaHoraProgRetorno;
	}

	public void setFechaHoraProgRetorno(Date fechaHoraProgRetorno) {
		this.fechaHoraProgRetorno = fechaHoraProgRetorno;
	}

	public String getFechaRegistroFormateada() {
		return fechaRegistroFormateada;
	}

	public void setFechaRegistroFormateada(String fechaRegistroFormateada) {
		this.fechaRegistroFormateada = fechaRegistroFormateada;
	}

	public Double getNumeroDias() {
		return numeroDias;
	}

	public void setNumeroDias(Double numeroDias) {
		this.numeroDias = numeroDias;
	}

	public String getPresupuestoAnno() {
		return presupuestoAnno;
	}

	public void setPresupuestoAnno(String presupuestoAnno) {
		this.presupuestoAnno = presupuestoAnno;
	}

	public String getPresupuestoMeta() {
		return presupuestoMeta;
	}

	public void setPresupuestoMeta(String presupuestoMeta) {
		this.presupuestoMeta = presupuestoMeta;
	}

	public String getPresupuestoMes() {
		return presupuestoMes;
	}

	public void setPresupuestoMes(String presupuestoMes) {
		this.presupuestoMes = presupuestoMes;
	}

	public String getSedeOrigen() {
		return sedeOrigen;
	}

	public void setSedeOrigen(String sedeOrigen) {
		this.sedeOrigen = sedeOrigen;
	}

	public Double getMontoTotal() {
		return montoTotal;
	}

	public void setMontoTotal(Double montoTotal) {
		this.montoTotal = montoTotal;
	}

	public String getOrigen() {
		return origen;
	}

	public void setOrigen(String origen) {
		this.origen = origen;
	}

	public String getDestinoExterior() {
		return destinoExterior;
	}

	public void setDestinoExterior(String destinoExterior) {
		this.destinoExterior = destinoExterior;
	}

	public String getInternacionalNroResolucion() {
		return internacionalNroResolucion;
	}

	public void setInternacionalNroResolucion(String internacionalNroResolucion) {
		this.internacionalNroResolucion = internacionalNroResolucion;
	}

	public Date getInternacionalFechaResolucion() {
		return internacionalFechaResolucion;
	}

	public void setInternacionalFechaResolucion(Date internacionalFechaResolucion) {
		this.internacionalFechaResolucion = internacionalFechaResolucion;
	}

	public Double getInternacionalMontoResolucion() {
		return internacionalMontoResolucion;
	}

	public void setInternacionalMontoResolucion(Double internacionalMontoResolucion) {
		this.internacionalMontoResolucion = internacionalMontoResolucion;
	}

	public Double getTipoCambio() {
		return tipoCambio;
	}

	public void setTipoCambio(Double tipoCambio) {
		this.tipoCambio = tipoCambio;
	}

	public String getPoaProgramado() {
		return poaProgramado;
	}

	public void setPoaProgramado(String poaProgramado) {
		this.poaProgramado = poaProgramado;
	}

	public String getSolicitanteViaje() {
		return solicitanteViaje;
	}

	public void setSolicitanteViaje(String solicitanteViaje) {
		this.solicitanteViaje = solicitanteViaje;
	}

	public String getDocumentosAntecedentes() {
		return documentosAntecedentes;
	}

	public void setDocumentosAntecedentes(String documentosAntecedentes) {
		this.documentosAntecedentes = documentosAntecedentes;
	}

	public String getInstruccionesRecibidas() {
		return instruccionesRecibidas;
	}

	public void setInstruccionesRecibidas(String instruccionesRecibidas) {
		this.instruccionesRecibidas = instruccionesRecibidas;
	}

	public String getPersonaAutorizacionVigente() {
		return personaAutorizacionVigente;
	}

	public void setPersonaAutorizacionVigente(String personaAutorizacionVigente) {
		this.personaAutorizacionVigente = personaAutorizacionVigente;
	}

	public String getFormaPago() {
		return formaPago;
	}

	public void setFormaPago(String formaPago) {
		this.formaPago = formaPago;
	}

	public Date getFechaHoraEjeSalida() {
		return fechaHoraEjeSalida;
	}

	public void setFechaHoraEjeSalida(Date fechaHoraEjeSalida) {
		this.fechaHoraEjeSalida = fechaHoraEjeSalida;
	}

	public Date getFechaHoraEjeRetorno() {
		return fechaHoraEjeRetorno;
	}

	public void setFechaHoraEjeRetorno(Date fechaHoraEjeRetorno) {
		this.fechaHoraEjeRetorno = fechaHoraEjeRetorno;
	}

	public Date getFechaRendicion() {
		return fechaRendicion;
	}

	public void setFechaRendicion(Date fechaRendicion) {
		this.fechaRendicion = fechaRendicion;
	}

	public Date getFechaRegistroRendicion() {
		return fechaRegistroRendicion;
	}

	public void setFechaRegistroRendicion(Date fechaRegistroRendicion) {
		this.fechaRegistroRendicion = fechaRegistroRendicion;
	}

	public String getFechaRegistroRendicionFormateda() {
		return fechaRegistroRendicionFormateda;
	}

	public void setFechaRegistroRendicionFormateda(String fechaRegistroRendicionFormateda) {
		this.fechaRegistroRendicionFormateda = fechaRegistroRendicionFormateda;
	}

	public String getFechaNotificacionFormateada() {
		return fechaNotificacionFormateada;
	}

	public void setFechaNotificacionFormateada(String fechaNotificacionFormateada) {
		this.fechaNotificacionFormateada = fechaNotificacionFormateada;
	}

	public String getEstadoPlanViaje() {
		return estadoPlanViaje;
	}

	public void setEstadoPlanViaje(String estadoPlanViaje) {
		this.estadoPlanViaje = estadoPlanViaje;
	}

	public String getEstadoRendicion() {
		return estadoRendicion;
	}

	public void setEstadoRendicion(String estadoRendicion) {
		this.estadoRendicion = estadoRendicion;
	}

	public String getNumeroRegistroArchivo() {
		return numeroRegistroArchivo;
	}

	public void setNumeroRegistroArchivo(String numeroRegistroArchivo) {
		this.numeroRegistroArchivo = numeroRegistroArchivo;
	}

	public String getExpedientePlanViaje() {
		return expedientePlanViaje;
	}

	public void setExpedientePlanViaje(String expedientePlanViaje) {
		this.expedientePlanViaje = expedientePlanViaje;
	}

	public String getExpedienteRendicion() {
		return expedienteRendicion;
	}

	public void setExpedienteRendicion(String expedienteRendicion) {
		this.expedienteRendicion = expedienteRendicion;
	}

	public String getSedePlanViaje() {
		return sedePlanViaje;
	}

	public void setSedePlanViaje(String sedePlanViaje) {
		this.sedePlanViaje = sedePlanViaje;
	}

	public String getMedioTransporteRetorno() {
		return medioTransporteRetorno;
	}

	public void setMedioTransporteRetorno(String medioTransporteRetorno) {
		this.medioTransporteRetorno = medioTransporteRetorno;
	}

	public String getTrabajadorEncargado() {
		return trabajadorEncargado;
	}

	public void setTrabajadorEncargado(String trabajadorEncargado) {
		this.trabajadorEncargado = trabajadorEncargado;
	}

	public String getIndicadorReciboProvisional() {
		return indicadorReciboProvisional;
	}

	public void setIndicadorReciboProvisional(String indicadorReciboProvisional) {
		this.indicadorReciboProvisional = indicadorReciboProvisional;
	}

	public String getUsoMovilidadEmpresa() {
		return usoMovilidadEmpresa;
	}

	public void setUsoMovilidadEmpresa(String usoMovilidadEmpresa) {
		this.usoMovilidadEmpresa = usoMovilidadEmpresa;
	}

	public Date getFechaDepositoDevol() {
		return fechaDepositoDevol;
	}

	public void setFechaDepositoDevol(Date fechaDepositoDevol) {
		this.fechaDepositoDevol = fechaDepositoDevol;
	}

	public Double getMontoDevol() {
		return montoDevol;
	}

	public void setMontoDevol(Double montoDevol) {
		this.montoDevol = montoDevol;
	}

	public String getTipoDevolucion() {
		return tipoDevolucion;
	}

	public void setTipoDevolucion(String tipoDevolucion) {
		this.tipoDevolucion = tipoDevolucion;
	}

	public String getNumeroPapeleta() {
		return numeroPapeleta;
	}

	public void setNumeroPapeleta(String numeroPapeleta) {
		this.numeroPapeleta = numeroPapeleta;
	}

	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}

	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public String getUsuarioModificacion() {
		return usuarioModificacion;
	}

	public void setUsuarioModificacion(String usuarioModificacion) {
		this.usuarioModificacion = usuarioModificacion;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public Double getMontoDevuelto() {
		return montoDevuelto;
	}

	public void setMontoDevuelto(Double montoDevuelto) {
		this.montoDevuelto = montoDevuelto;
	}

	public Date getFechaInicioAccion() {
		return fechaInicioAccion;
	}

	public void setFechaInicioAccion(Date fechaInicioAccion) {
		this.fechaInicioAccion = fechaInicioAccion;
	}

	public String getCodigoBancBan() {
		return codigoBancBan;
	}

	public void setCodigoBancBan(String codigoBancBan) {
		this.codigoBancBan = codigoBancBan;
	}

	public Date getFechaAnulacion() {
		return fechaAnulacion;
	}

	public void setFechaAnulacion(Date fechaAnulacion) {
		this.fechaAnulacion = fechaAnulacion;
	}

	public Date getFechaAutorizacion() {
		return fechaAutorizacion;
	}

	public void setFechaAutorizacion(Date fechaAutorizacion) {
		this.fechaAutorizacion = fechaAutorizacion;
	}

	public Date getFechaEnviofin() {
		return fechaEnviofin;
	}

	public void setFechaEnviofin(Date fechaEnviofin) {
		this.fechaEnviofin = fechaEnviofin;
	}

	public Date getFechaEnvioPre() {
		return fechaEnvioPre;
	}

	public void setFechaEnvioPre(Date fechaEnvioPre) {
		this.fechaEnvioPre = fechaEnvioPre;
	}

	public Date getFechaFinAccion() {
		return fechaFinAccion;
	}

	public void setFechaFinAccion(Date fechaFinAccion) {
		this.fechaFinAccion = fechaFinAccion;
	}

	public Date getFechaMaxRendicion() {
		return fechaMaxRendicion;
	}

	public void setFechaMaxRendicion(Date fechaMaxRendicion) {
		this.fechaMaxRendicion = fechaMaxRendicion;
	}

	public Date getFechaNotificacion() {
		return fechaNotificacion;
	}

	public void setFechaNotificacion(Date fechaNotificacion) {
		this.fechaNotificacion = fechaNotificacion;
	}

	public Date getFechaObservacion() {
		return fechaObservacion;
	}

	public void setFechaObservacion(Date fechaObservacion) {
		this.fechaObservacion = fechaObservacion;
	}

	public Date getFechaObsTraslape() {
		return fechaObsTraslape;
	}

	public void setFechaObsTraslape(Date fechaObsTraslape) {
		this.fechaObsTraslape = fechaObsTraslape;
	}

	public Date getFechaPago() {
		return fechaPago;
	}

	public void setFechaPago(Date fechaPago) {
		this.fechaPago = fechaPago;
	}

	public Date getFechaVerificacion() {
		return fechaVerificacion;
	}

	public void setFechaVerificacion(Date fechaVerificacion) {
		this.fechaVerificacion = fechaVerificacion;
	}

	public Date getFechaVizAsis() {
		return fechaVizAsis;
	}

	public void setFechaVizAsis(Date fechaVizAsis) {
		this.fechaVizAsis = fechaVizAsis;
	}

	public String getIndicadorAutorizacion() {
		return indicadorAutorizacion;
	}

	public void setIndicadorAutorizacion(String indicadorAutorizacion) {
		this.indicadorAutorizacion = indicadorAutorizacion;
	}

	public String getIndicadorExtDdjj() {
		return indicadorExtDdjj;
	}

	public void setIndicadorExtDdjj(String indicadorExtDdjj) {
		this.indicadorExtDdjj = indicadorExtDdjj;
	}

	public String getIndicadorHoras() {
		return indicadorHoras;
	}

	public void setIndicadorHoras(String indicadorHoras) {
		this.indicadorHoras = indicadorHoras;
	}

	public String getIndicadorMenGast() {
		return indicadorMenGast;
	}

	public void setIndicadorMenGast(String indicadorMenGast) {
		this.indicadorMenGast = indicadorMenGast;
	}

	public String getIndicadorModoPago() {
		return indicadorModoPago;
	}

	public void setIndicadorModoPago(String indicadorModoPago) {
		this.indicadorModoPago = indicadorModoPago;
	}

	public String getIndicadorRuta() {
		return indicadorRuta;
	}

	public void setIndicadorRuta(String indicadorRuta) {
		this.indicadorRuta = indicadorRuta;
	}

	public String getIndicadorSegNotif() {
		return indicadorSegNotif;
	}

	public void setIndicadorSegNotif(String indicadorSegNotif) {
		this.indicadorSegNotif = indicadorSegNotif;
	}

	public String getIndicadorTipoTraslado() {
		return indicadorTipoTraslado;
	}

	public void setIndicadorTipoTraslado(String indicadorTipoTraslado) {
		this.indicadorTipoTraslado = indicadorTipoTraslado;
	}

	public String getIndicadorTraslape() {
		return indicadorTraslape;
	}

	public void setIndicadorTraslape(String indicadorTraslape) {
		this.indicadorTraslape = indicadorTraslape;
	}

	public String getObservacionAnulacion() {
		return observacionAnulacion;
	}

	public void setObservacionAnulacion(String observacionAnulacion) {
		this.observacionAnulacion = observacionAnulacion;
	}

	public String getObservacionAutorizacion() {
		return observacionAutorizacion;
	}

	public void setObservacionAutorizacion(String observacionAutorizacion) {
		this.observacionAutorizacion = observacionAutorizacion;
	}

	public String getObservacionAutorizador() {
		return observacionAutorizador;
	}

	public void setObservacionAutorizador(String observacionAutorizador) {
		this.observacionAutorizador = observacionAutorizador;
	}

	public String getObservacionRendicion() {
		return observacionRendicion;
	}

	public void setObservacionRendicion(String observacionRendicion) {
		this.observacionRendicion = observacionRendicion;
	}

	public String getObservacionSolicitud() {
		return observacionSolicitud;
	}

	public void setObservacionSolicitud(String observacionSolicitud) {
		this.observacionSolicitud = observacionSolicitud;
	}

	public String getObservacionTraslape() {
		return observacionTraslape;
	}

	public void setObservacionTraslape(String observacionTraslape) {
		this.observacionTraslape = observacionTraslape;
	}

	public String getCodigoDestExtranjero() {
		return codigoDestExtranjero;
	}

	public void setCodigoDestExtranjero(String codigoDestExtranjero) {
		this.codigoDestExtranjero = codigoDestExtranjero;
	}

	public String getCodigoNivel() {
		return codigoNivel;
	}

	public void setCodigoNivel(String codigoNivel) {
		this.codigoNivel = codigoNivel;
	}

	public String getCodigoNivAutor() {
		return codigoNivAutor;
	}

	public void setCodigoNivAutor(String codigoNivAutor) {
		this.codigoNivAutor = codigoNivAutor;
	}

	public String getCodigoPlanillaAsc() {
		return codigoPlanillaAsc;
	}

	public void setCodigoPlanillaAsc(String codigoPlanillaAsc) {
		this.codigoPlanillaAsc = codigoPlanillaAsc;
	}

	public String getCodigoPlanViajeID() {
		return codigoPlanViajeID;
	}

	public void setCodigoPlanViajeID(String codigoPlanViajeID) {
		this.codigoPlanViajeID = codigoPlanViajeID;
	}

	public String getCodigoRegistrador() {
		return codigoRegistrador;
	}

	public void setCodigoRegistrador(String codigoRegistrador) {
		this.codigoRegistrador = codigoRegistrador;
	}

	public String getCodigoTipoTraslado() {
		return codigoTipoTraslado;
	}

	public void setCodigoTipoTraslado(String codigoTipoTraslado) {
		this.codigoTipoTraslado = codigoTipoTraslado;
	}

	public String getCodigoUsurendicion() {
		return codigoUsurendicion;
	}

	public void setCodigoUsurendicion(String codigoUsurendicion) {
		this.codigoUsurendicion = codigoUsurendicion;
	}

	public String getCodigoUsuverificacion() {
		return codigoUsuverificacion;
	}

	public void setCodigoUsuverificacion(String codigoUsuverificacion) {
		this.codigoUsuverificacion = codigoUsuverificacion;
	}

	public String getDescripcionJustRep() {
		return descripcionJustRep;
	}

	public void setDescripcionJustRep(String descripcionJustRep) {
		this.descripcionJustRep = descripcionJustRep;
	}

	public String getCodigoTipoMotReembolso() {
		return codigoTipoMotReembolso;
	}

	public void setCodigoTipoMotReembolso(String codigoTipoMotReembolso) {
		this.codigoTipoMotReembolso = codigoTipoMotReembolso;
	}

	public String getCodigoEstadoPago() {
		return codigoEstadoPago;
	}

	public void setCodigoEstadoPago(String codigoEstadoPago) {
		this.codigoEstadoPago = codigoEstadoPago;
	}

	public Double getMontoTopeViaticoInternacional() {
		return montoTopeViaticoInternacional;
	}

	public void setMontoTopeViaticoInternacional(Double montoTopeViaticoInternacional) {
		this.montoTopeViaticoInternacional = montoTopeViaticoInternacional;
	}

	public Double getNumeroHoras() {
		return numeroHoras;
	}

	public void setNumeroHoras(Double numeroHoras) {
		this.numeroHoras = numeroHoras;
	}

	public String getNumeroResolRem() {
		return numeroResolRem;
	}

	public void setNumeroResolRem(String numeroResolRem) {
		this.numeroResolRem = numeroResolRem;
	}

	public Long getNumeroCasecid() {
		return numeroCasecid;
	}

	public void setNumeroCasecid(Long numeroCasecid) {
		this.numeroCasecid = numeroCasecid;
	}

	public Long getNumeroCcpsecid() {
		return numeroCcpsecid;
	}

	public void setNumeroCcpsecid(Long numeroCcpsecid) {
		this.numeroCcpsecid = numeroCcpsecid;
	}

	public String getNumeroRegistro() {
		return numeroRegistro;
	}

	public void setNumeroRegistro(String numeroRegistro) {
		this.numeroRegistro = numeroRegistro;
	}

	public String getNumeroRegiCab() {
		return numeroRegiCab;
	}

	public void setNumeroRegiCab(String numeroRegiCab) {
		this.numeroRegiCab = numeroRegiCab;
	}

	public String getNiveViatNvi() {
		return niveViatNvi;
	}

	public void setNiveViatNvi(String niveViatNvi) {
		this.niveViatNvi = niveViatNvi;
	}

	public String getCodigoDepAutor() {
		return codigoDepAutor;
	}

	public void setCodigoDepAutor(String codigoDepAutor) {
		this.codigoDepAutor = codigoDepAutor;
	}

	public String getCodigoCargoEmpleado() {
		return codigoCargoEmpleado;
	}

	public void setCodigoCargoEmpleado(String codigoCargoEmpleado) {
		this.codigoCargoEmpleado = codigoCargoEmpleado;
	}

	public void setFecNotificacionFormateada(String fecNotificacionFormateada) {
		this.fecNotificacionFormateada = fecNotificacionFormateada;
	}

	public String getFecNotificacionFormateada() {
		return fecNotificacionFormateada;
	}

	public String getFlagMenorIgual4Horas() {
		return flagMenorIgual4Horas;
	}

	public void setFlagMenorIgual4Horas(String flagMenorIgual4Horas) {
		this.flagMenorIgual4Horas = flagMenorIgual4Horas;
	}

	public String getFlagDeclaracion() {
		return flagDeclaracion;
	}

	public void setFlagDeclaracion(String flagDeclaracion) {
		this.flagDeclaracion = flagDeclaracion;
	}

	public int getNumeroDeclaracionViatico() {
		return numeroDeclaracionViatico;
	}

	public void setNumeroDeclaracionViatico(int numeroDeclaracionViatico) {
		this.numeroDeclaracionViatico = numeroDeclaracionViatico;
	}

	public BigDecimal getMontoMenorGasto() {
		return montoMenorGasto;
	}

	public void setMontoMenorGasto(BigDecimal montoMenorGasto) {
		this.montoMenorGasto = montoMenorGasto;
	}

	public BigDecimal getMontoAsignadoTotal() {
		return montoAsignadoTotal;
	}

	public void setMontoAsignadoTotal(BigDecimal montoAsignadoTotal) {
		this.montoAsignadoTotal = montoAsignadoTotal;
	}

	public BigDecimal getMontoAsignacionViatico() {
		return montoAsignacionViatico;
	}

	public void setMontoAsignacionViatico(BigDecimal montoAsignacionViatico) {
		this.montoAsignacionViatico = montoAsignacionViatico;
	}

	public BigDecimal getMontoDeclaracionTotal() {
		return montoDeclaracionTotal;
	}

	public void setMontoDeclaracionTotal(BigDecimal montoDeclaracionTotal) {
		this.montoDeclaracionTotal = montoDeclaracionTotal;
	}

	public BigDecimal getMontoDeclaracionViatico() {
		return montoDeclaracionViatico;
	}

	public void setMontoDeclaracionViatico(BigDecimal montoDeclaracionViatico) {
		this.montoDeclaracionViatico = montoDeclaracionViatico;
	}

	public String getMontoDevueltoFormateado() {
		return montoDevueltoFormateado;
	}

	public void setMontoDevueltoFormateado(String montoDevueltoFormateado) {
		this.montoDevueltoFormateado = montoDevueltoFormateado;
	}

	public String getMontoMenorGastoFormateado() {
		return montoMenorGastoFormateado;
	}

	public void setMontoMenorGastoFormateado(String montoMenorGastoFormateado) {
		this.montoMenorGastoFormateado = montoMenorGastoFormateado;
	}

	public String getMontoDevolFormateado() {
		return montoDevolFormateado;
	}

	public void setMontoDevolFormateado(String montoDevolFormateado) {
		this.montoDevolFormateado = montoDevolFormateado;
	}

	public String getObservacionDCP() {
		return observacionDCP;
	}

	public void setObservacionDCP(String observacionDCP) {
		this.observacionDCP = observacionDCP;
	}

	public void setFecSalidaEjecutadaFormateada(String fecSalidaEjecutadaFormateada) {
		this.fecSalidaEjecutadaFormateada = fecSalidaEjecutadaFormateada;
	}

	public String getFecSalidaEjecutadaFormateada() {
		return fecSalidaEjecutadaFormateada;
	}

	public void setFecRetornoEjecutadaFormateada(String fecRetornoEjecutadaFormateada) {
		this.fecRetornoEjecutadaFormateada = fecRetornoEjecutadaFormateada;
	}

	public String getFecRetornoEjecutadaFormateada() {
		return fecRetornoEjecutadaFormateada;
	}

	public Date getFechaItinerarioSalida() {
		return fechaItinerarioSalida;
	}

	public void setFechaItinerarioSalida(Date fechaItinerarioSalida) {
		this.fechaItinerarioSalida = fechaItinerarioSalida;
	}

	public Date getFechaItinerarioRetorno() {
		return fechaItinerarioRetorno;
	}

	public void setFechaItinerarioRetorno(Date fechaItinerarioRetorno) {
		this.fechaItinerarioRetorno = fechaItinerarioRetorno;
	}

	/**
	 * @param fechaHoraProgSalidaDDMMYYYY the fechaHoraProgSalidaDDMMYYYY to set
	 */
	public void setFechaHoraProgSalidaDDMMYYYY(
			Date fechaHoraProgSalidaDDMMYYYY) {
		this.fechaHoraProgSalidaDDMMYYYY = fechaHoraProgSalidaDDMMYYYY;
	}

	/**
	 * @return the fechaHoraProgSalidaDDMMYYYY
	 */
	public Date getFechaHoraProgSalidaDDMMYYYY() {
		return fechaHoraProgSalidaDDMMYYYY;
	}

	/**
	 * @param fechaHoraProgRetornoDDMMYYYY the fechaHoraProgRetornoDDMMYYYY to set
	 */
	public void setFechaHoraProgRetornoDDMMYYYY(
			Date fechaHoraProgRetornoDDMMYYYY) {
		this.fechaHoraProgRetornoDDMMYYYY = fechaHoraProgRetornoDDMMYYYY;
	}

	/**
	 * @return the fechaHoraProgRetornoDDMMYYYY
	 */
	public Date getFechaHoraProgRetornoDDMMYYYY() {
		return fechaHoraProgRetornoDDMMYYYY;
	}


	public String getCodOsa() {
		return codOsa;
	}


	public void setCodOsa(String codOsa) {
		this.codOsa = codOsa;
	}

	public Date getFecReprogramaRend() {
		return fecReprogramaRend;
	}

	public void setFecReprogramaRend(Date fecReprogramaRend) {
		this.fecReprogramaRend = fecReprogramaRend;
	}

	public String getFecReprogramaRendFormateada() {
		return fecReprogramaRendFormateada;
	}

	public void setFecReprogramaRendFormateada(String fecReprogramaRendFormateada) {
		this.fecReprogramaRendFormateada = fecReprogramaRendFormateada;
	}

}