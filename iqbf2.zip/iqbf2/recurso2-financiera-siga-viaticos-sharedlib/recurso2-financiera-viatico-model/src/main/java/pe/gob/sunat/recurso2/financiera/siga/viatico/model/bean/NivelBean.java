package pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean;

import java.io.Serializable;

public class NivelBean implements Serializable {

	private static final long serialVersionUID = 6842360997162271417L;

	private String codigoNivel; // CODI_NIVE_NVL
	private String descripcionNivel; // DESC_NIVE_NVL
	private String nivelViatico; // NIVE_VIAT_NVI
	private String descripcionCorta; // DESC_CORT_NVL
	private String codigoMEF; // CODIGO_MEF

	public String getCodigoNivel() {
		return codigoNivel;
	}

	public void setCodigoNivel(String codigoNivel) {
		this.codigoNivel = codigoNivel;
	}

	public String getDescripcionNivel() {
		return descripcionNivel;
	}

	public void setDescripcionNivel(String descripcionNivel) {
		this.descripcionNivel = descripcionNivel;
	}

	public String getNivelViatico() {
		return nivelViatico;
	}

	public void setNivelViatico(String nivelViatico) {
		this.nivelViatico = nivelViatico;
	}

	public String getDescripcionCorta() {
		return descripcionCorta;
	}

	public void setDescripcionCorta(String descripcionCorta) {
		this.descripcionCorta = descripcionCorta;
	}

	public String getCodigoMEF() {
		return codigoMEF;
	}

	public void setCodigoMEF(String codigoMEF) {
		this.codigoMEF = codigoMEF;
	}

}