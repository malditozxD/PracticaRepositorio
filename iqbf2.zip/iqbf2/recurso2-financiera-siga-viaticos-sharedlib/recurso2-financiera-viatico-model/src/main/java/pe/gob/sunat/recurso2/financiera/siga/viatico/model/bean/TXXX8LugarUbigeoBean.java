package pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean;

import java.io.Serializable;
import java.util.Date;

public class TXXX8LugarUbigeoBean implements Serializable {

	private static final long serialVersionUID = 3588722214511013943L;
	
	private String codigoLugar;			// COD_LUGAR
	private String codigoUbigeo; 		// COD_UBIGEO
	private String nombreLugar;			// NOM_LUGAR
	private String descripcionLugar;	// DES_LUGAR
	private String usuarioCreacion;		// USER_CREA
	private Date fechaCreacion; 		// FECH_CREA
	private String usuarioModificacion; // USER_MODI
	private Date fechaModificacion; 	// FECH_MODI
	private String indDel; 				// IND_DEL

	// campos adicionales
	private String codigoDepartamento;
	private String descripcionDepartamento;
	private String codigoProvincia;
	private String descripcionProvincia;
	private Integer diasTraslado;

	public String getCodigoLugar() {
		return codigoLugar;
	}

	public void setCodigoLugar(String codigoLugar) {
		this.codigoLugar = codigoLugar;
	}

	public String getCodigoUbigeo() {
		return codigoUbigeo;
	}

	public void setCodigoUbigeo(String codigoUbigeo) {
		this.codigoUbigeo = codigoUbigeo;
	}

	public String getNombreLugar() {
		return nombreLugar;
	}

	public void setNombreLugar(String nombreLugar) {
		this.nombreLugar = nombreLugar;
	}

	public String getDescripcionLugar() {
		return descripcionLugar;
	}

	public void setDescripcionLugar(String descripcionLugar) {
		this.descripcionLugar = descripcionLugar;
	}

	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}

	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public String getUsuarioModificacion() {
		return usuarioModificacion;
	}

	public void setUsuarioModificacion(String usuarioModificacion) {
		this.usuarioModificacion = usuarioModificacion;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public String getIndDel() {
		return indDel;
	}

	public void setIndDel(String indDel) {
		this.indDel = indDel;
	}

	public String getCodigoDepartamento() {
		return codigoDepartamento;
	}

	public void setCodigoDepartamento(String codigoDepartamento) {
		this.codigoDepartamento = codigoDepartamento;
	}

	public String getDescripcionDepartamento() {
		return descripcionDepartamento;
	}

	public void setDescripcionDepartamento(String descripcionDepartamento) {
		this.descripcionDepartamento = descripcionDepartamento;
	}

	public String getCodigoProvincia() {
		return codigoProvincia;
	}

	public void setCodigoProvincia(String codigoProvincia) {
		this.codigoProvincia = codigoProvincia;
	}

	public String getDescripcionProvincia() {
		return descripcionProvincia;
	}

	public void setDescripcionProvincia(String descripcionProvincia) {
		this.descripcionProvincia = descripcionProvincia;
	}

	public Integer getDiasTraslado() {
		return diasTraslado;
	}

	public void setDiasTraslado(Integer diasTraslado) {
		this.diasTraslado = diasTraslado;
	}

}
