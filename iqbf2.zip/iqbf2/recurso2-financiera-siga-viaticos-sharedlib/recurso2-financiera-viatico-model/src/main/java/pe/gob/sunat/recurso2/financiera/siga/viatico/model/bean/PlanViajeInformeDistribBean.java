package pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class PlanViajeInformeDistribBean implements Serializable {

	private static final long serialVersionUID = 4184926401554621294L;
	private String planViajeId;
	private Integer secuencial;
	private String userCrea;
	private Date fechCrea;
	private String userModi;
	private Date fechModi;
	private String codConcepto;
	private Date fecViatico;
	private String fecViaticoFormateada;
	private Double mtoDocumento;
	private String codConceptoOri;
	private String mtoTope;
	private String annClasificador;
	private String clasGastGas;
	private String mtoDocumentoSoles;
	private Double montoDocumentoAlimentacion;
	private Double montoDocumentoHospedaje;
	private Double montoDocumentoMovilidad;
	private Double montoDocumentoTranslado;
	private String indItinerario;
	private String fechaViaticoEntrada;
	private String descripcionConceptoPVI;
	private String indTipo;
	private BigDecimal montoAlimentacion;
	private BigDecimal montoHospedaje;
	private BigDecimal montoMovilidad;
	private BigDecimal montoTraslado;
	private BigDecimal montoPasaje;
	private BigDecimal montoTUUA;
	private BigDecimal montoTotal;
	private String montoAlimentacionFormateado;
	private String montoHospedajeFormateado;
	private String montoMovilidadFormateado;
	private String montoTrasladoFormateado;
	private String montoPasajeFormateado;
	private String montoTUUAFormateado;
	private String montoTotalFormateado;
	private String flagPlanViajeInformeDistribTotal;
	private String moneda;
	private String detalleGasto;
	private Double montoDestionFecha;
	private Double sumaMontoRendido;
	
	public String getPlanViajeId() {
		return planViajeId;
	}

	public void setPlanViajeId(String planViajeId) {
		this.planViajeId = planViajeId;
	}

	public Integer getSecuencial() {
		return secuencial;
	}

	public void setSecuencial(Integer secuencial) {
		this.secuencial = secuencial;
	}

	public String getUserCrea() {
		return userCrea;
	}

	public void setUserCrea(String userCrea) {
		this.userCrea = userCrea;
	}

	public Date getFechCrea() {
		return fechCrea;
	}

	public void setFechCrea(Date fechCrea) {
		this.fechCrea = fechCrea;
	}

	public String getUserModi() {
		return userModi;
	}

	public void setUserModi(String userModi) {
		this.userModi = userModi;
	}

	public Date getFechModi() {
		return fechModi;
	}

	public void setFechModi(Date fechModi) {
		this.fechModi = fechModi;
	}

	public String getCodConcepto() {
		return codConcepto;
	}

	public void setCodConcepto(String codConcepto) {
		this.codConcepto = codConcepto;
	}

	public Date getFecViatico() {
		return fecViatico;
	}

	public void setFecViatico(Date fecViatico) {
		this.fecViatico = fecViatico;
	}

	public String getFecViaticoFormateada() {
		return fecViaticoFormateada;
	}

	public void setFecViaticoFormateada(String fecViaticoFormateada) {
		this.fecViaticoFormateada = fecViaticoFormateada;
	}

	public Double getMtoDocumento() {
		return mtoDocumento;
	}

	public void setMtoDocumento(Double mtoDocumento) {
		this.mtoDocumento = mtoDocumento;
	}

	public String getCodConceptoOri() {
		return codConceptoOri;
	}

	public void setCodConceptoOri(String codConceptoOri) {
		this.codConceptoOri = codConceptoOri;
	}

	public String getMtoTope() {
		return mtoTope;
	}

	public void setMtoTope(String mtoTope) {
		this.mtoTope = mtoTope;
	}

	public String getAnnClasificador() {
		return annClasificador;
	}

	public void setAnnClasificador(String annClasificador) {
		this.annClasificador = annClasificador;
	}

	public String getClasGastGas() {
		return clasGastGas;
	}

	public void setClasGastGas(String clasGastGas) {
		this.clasGastGas = clasGastGas;
	}

	public String getMtoDocumentoSoles() {
		return mtoDocumentoSoles;
	}

	public void setMtoDocumentoSoles(String mtoDocumentoSoles) {
		this.mtoDocumentoSoles = mtoDocumentoSoles;
	}

	public Double getMontoDocumentoAlimentacion() {
		return montoDocumentoAlimentacion;
	}

	public void setMontoDocumentoAlimentacion(Double montoDocumentoAlimentacion) {
		this.montoDocumentoAlimentacion = montoDocumentoAlimentacion;
	}

	public Double getMontoDocumentoHospedaje() {
		return montoDocumentoHospedaje;
	}

	public void setMontoDocumentoHospedaje(Double montoDocumentoHospedaje) {
		this.montoDocumentoHospedaje = montoDocumentoHospedaje;
	}

	public Double getMontoDocumentoMovilidad() {
		return montoDocumentoMovilidad;
	}

	public void setMontoDocumentoMovilidad(Double montoDocumentoMovilidad) {
		this.montoDocumentoMovilidad = montoDocumentoMovilidad;
	}

	public Double getMontoDocumentoTranslado() {
		return montoDocumentoTranslado;
	}

	public void setMontoDocumentoTranslado(Double montoDocumentoTranslado) {
		this.montoDocumentoTranslado = montoDocumentoTranslado;
	}

	public String getIndItinerario() {
		return indItinerario;
	}

	public void setIndItinerario(String indItinerario) {
		this.indItinerario = indItinerario;
	}

	public String getFechaViaticoEntrada() {
		return fechaViaticoEntrada;
	}

	public void setFechaViaticoEntrada(String fechaViaticoEntrada) {
		this.fechaViaticoEntrada = fechaViaticoEntrada;
	}

	public String getDescripcionConceptoPVI() {
		return descripcionConceptoPVI;
	}

	public void setDescripcionConceptoPVI(String descripcionConceptoPVI) {
		this.descripcionConceptoPVI = descripcionConceptoPVI;
	}

	public String getIndTipo() {
		return indTipo;
	}

	public void setIndTipo(String indTipo) {
		this.indTipo = indTipo;
	}

	public BigDecimal getMontoAlimentacion() {
		return montoAlimentacion;
	}

	public void setMontoAlimentacion(BigDecimal montoAlimentacion) {
		this.montoAlimentacion = montoAlimentacion;
	}

	public BigDecimal getMontoHospedaje() {
		return montoHospedaje;
	}

	public void setMontoHospedaje(BigDecimal montoHospedaje) {
		this.montoHospedaje = montoHospedaje;
	}

	public BigDecimal getMontoMovilidad() {
		return montoMovilidad;
	}

	public void setMontoMovilidad(BigDecimal montoMovilidad) {
		this.montoMovilidad = montoMovilidad;
	}

	public BigDecimal getMontoTraslado() {
		return montoTraslado;
	}

	public void setMontoTraslado(BigDecimal montoTraslado) {
		this.montoTraslado = montoTraslado;
	}

	public BigDecimal getMontoPasaje() {
		return montoPasaje;
	}

	public void setMontoPasaje(BigDecimal montoPasaje) {
		this.montoPasaje = montoPasaje;
	}

	public BigDecimal getMontoTUUA() {
		return montoTUUA;
	}

	public void setMontoTUUA(BigDecimal montoTUUA) {
		this.montoTUUA = montoTUUA;
	}

	public BigDecimal getMontoTotal() {
		return montoTotal;
	}

	public void setMontoTotal(BigDecimal montoTotal) {
		this.montoTotal = montoTotal;
	}

	public String getMontoAlimentacionFormateado() {
		return montoAlimentacionFormateado;
	}

	public void setMontoAlimentacionFormateado(
			String montoAlimentacionFormateado) {
		this.montoAlimentacionFormateado = montoAlimentacionFormateado;
	}

	public String getMontoHospedajeFormateado() {
		return montoHospedajeFormateado;
	}

	public void setMontoHospedajeFormateado(String montoHospedajeFormateado) {
		this.montoHospedajeFormateado = montoHospedajeFormateado;
	}

	public String getMontoMovilidadFormateado() {
		return montoMovilidadFormateado;
	}

	public void setMontoMovilidadFormateado(String montoMovilidadFormateado) {
		this.montoMovilidadFormateado = montoMovilidadFormateado;
	}

	public String getMontoTrasladoFormateado() {
		return montoTrasladoFormateado;
	}

	public void setMontoTrasladoFormateado(String montoTrasladoFormateado) {
		this.montoTrasladoFormateado = montoTrasladoFormateado;
	}

	public String getMontoPasajeFormateado() {
		return montoPasajeFormateado;
	}

	public void setMontoPasajeFormateado(String montoPasajeFormateado) {
		this.montoPasajeFormateado = montoPasajeFormateado;
	}

	public String getMontoTUUAFormateado() {
		return montoTUUAFormateado;
	}

	public void setMontoTUUAFormateado(String montoTUUAFormateado) {
		this.montoTUUAFormateado = montoTUUAFormateado;
	}

	public String getMontoTotalFormateado() {
		return montoTotalFormateado;
	}

	public void setMontoTotalFormateado(String montoTotalFormateado) {
		this.montoTotalFormateado = montoTotalFormateado;
	}

	public String getFlagPlanViajeInformeDistribTotal() {
		return flagPlanViajeInformeDistribTotal;
	}

	public void setFlagPlanViajeInformeDistribTotal(
			String flagPlanViajeInformeDistribTotal) {
		this.flagPlanViajeInformeDistribTotal = flagPlanViajeInformeDistribTotal;
	}

	/**
	 * @param moneda the moneda to set
	 */
	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	/**
	 * @return the moneda
	 */
	public String getMoneda() {
		return moneda;
	}

	/**
	 * @param detalleGasto the detalleGasto to set
	 */
	public void setDetalleGasto(String detalleGasto) {
		this.detalleGasto = detalleGasto;
	}

	/**
	 * @return the detalleGasto
	 */
	public String getDetalleGasto() {
		return detalleGasto;
	}

	/**
	 * @param montoDestionFecha the montoDestionFecha to set
	 */
	public void setMontoDestionFecha(Double montoDestionFecha) {
		this.montoDestionFecha = montoDestionFecha;
	}

	/**
	 * @return the montoDestionFecha
	 */
	public Double getMontoDestionFecha() {
		return montoDestionFecha;
	}

	/**
	 * @param sumaMontoRendido the sumaMontoRendido to set
	 */
	public void setSumaMontoRendido(Double sumaMontoRendido) {
		this.sumaMontoRendido = sumaMontoRendido;
	}

	/**
	 * @return the sumaMontoRendido
	 */
	public Double getSumaMontoRendido() {
		return sumaMontoRendido;
	}

}
