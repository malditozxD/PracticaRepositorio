package pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class ComprobanteIngresoBean implements Serializable {

	private static final long serialVersionUID = -4947304288987353877L;
	private String numeroRendicion;
	private String numeroDocumento;
	private Date fechaGeneracion;
	private String fechaGeneracionFormateada;
	private String tipoCambio;
	private String moneda;
	private BigDecimal monto;
	private String montoFormateado;
	private String clasificador;
	private String flagComprobanteTotal;
	private String observacion;
	private String tipoMoneda;

	public String getNumeroRendicion() {
		return numeroRendicion;
	}

	public void setNumeroRendicion(String numeroRendicion) {
		this.numeroRendicion = numeroRendicion;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public Date getFechaGeneracion() {
		return fechaGeneracion;
	}

	public void setFechaGeneracion(Date fechaGeneracion) {
		this.fechaGeneracion = fechaGeneracion;
	}

	public String getFechaGeneracionFormateada() {
		return fechaGeneracionFormateada;
	}

	public void setFechaGeneracionFormateada(String fechaGeneracionFormateada) {
		this.fechaGeneracionFormateada = fechaGeneracionFormateada;
	}

	public String getTipoCambio() {
		return tipoCambio;
	}

	public void setTipoCambio(String tipoCambio) {
		this.tipoCambio = tipoCambio;
	}

	public String getMoneda() {
		return moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public BigDecimal getMonto() {
		return monto;
	}

	public void setMonto(BigDecimal monto) {
		this.monto = monto;
	}

	public String getMontoFormateado() {
		return montoFormateado;
	}

	public void setMontoFormateado(String montoFormateado) {
		this.montoFormateado = montoFormateado;
	}

	public String getClasificador() {
		return clasificador;
	}

	public void setClasificador(String clasificador) {
		this.clasificador = clasificador;
	}

	public String getFlagComprobanteTotal() {
		return flagComprobanteTotal;
	}

	public void setFlagComprobanteTotal(String flagComprobanteTotal) {
		this.flagComprobanteTotal = flagComprobanteTotal;
	}

	public String getObservacion() {
		return observacion;
	}

	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	public String getTipoMoneda() {
		return tipoMoneda;
	}

	public void setTipoMoneda(String tipoMoneda) {
		this.tipoMoneda = tipoMoneda;
	}

}
