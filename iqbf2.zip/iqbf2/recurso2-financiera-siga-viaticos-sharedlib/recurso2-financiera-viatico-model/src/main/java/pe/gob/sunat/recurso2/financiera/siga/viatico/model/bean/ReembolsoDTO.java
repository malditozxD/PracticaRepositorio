package pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.DependenciaBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;

public class ReembolsoDTO implements Serializable {

	private static final long serialVersionUID = 4746767746088075686L;

	private String numPlanilla = "";
	private PlanViajeBean planViajeBean;
	private PlanViajeBean planillaAsociada;
	private List<PlanViajeBean> PlanViajeList;

	// datos de colaborador
	private String flagAuditor;

	// datos bean
	private ColaboradorViaticoBean colaborador;
	private ColaboradorViaticoBean registrador;
	private ColaboradorViaticoBean jefe;
	private ColaboradorViaticoBean autorizador;
	private DependenciaBean dependencia;
	// para el envio de la solicitud
	private String observacionExpediente = "";

	// PARA PROCESO//MANUAL -AUTOMATICO
	private String tipoProceso = "";

	// ESTADOS
	private String estadoAccion = "";
	private String estadoSolicitud = "";

	// VARIOS
	private String accionSolicitud; // R:Registro, M:modificacion;
	private boolean flagErrorFormaPago;
	private NivelBean nivelColaborador;
	private NivelBean nivelAutorizador;
	List<PlanViajeConceptoBean> planViajeConceptoList;
	private String montoTotalConcepto;
	private List<Map<String, Object>> conceptoList;
	private CuentaCorrienteBean cuenta;
	private List<PlanViajeRendicionBean> planViajeRendicionList;
	private String importeComprobanteTotal;
	private String importeAlimentacionTotal;
	private String importeTrasladoTotal;
	private String importeAlojamientoTotal;
	private String importeMovilidadTotal;
	private String importeTotalViatico;
	private String importePasajeTotal;
	private String importeTasaEmbarqueTotal;
	private String importeOtrasAsignacionesTotal;
	private String importeMontoTotalGasto;
	private String fechaActual;
	private String horaActual;
	
	public PlanViajeBean getPlanViajeBean() {
		return planViajeBean;
	}

	public boolean esMotivoAmpliacion() {

		if (planViajeBean != null) {

			boolean esMotivoAmpliacion = StringUtils.equals(planViajeBean.getCodigoTipoMotReembolso(), ViaticoConstantes.MOTIVO_AMPLIACION_AMPLIACION_COMISION);

			return esMotivoAmpliacion;
		}

		return false;
	}

	public boolean tienePlanillaAsociada() {
		
		return esMotivoAmpliacion() && planillaAsociada != null;
	}

	public void setPlanViajeBean(PlanViajeBean planViajeBean) {
		this.planViajeBean = planViajeBean;
	}

	public String getNumPlanilla() {
		return numPlanilla;
	}

	public void setNumPlanilla(String numPlanilla) {
		this.numPlanilla = numPlanilla;
	}

	public String getFlagAuditor() {
		return flagAuditor;
	}

	public void setFlagAuditor(String flagAuditor) {
		this.flagAuditor = flagAuditor;
	}

	public ColaboradorViaticoBean getColaborador() {
		return colaborador;
	}

	public void setColaborador(ColaboradorViaticoBean colaborador) {
		this.colaborador = colaborador;
	}

	public ColaboradorViaticoBean getRegistrador() {
		return registrador;
	}

	public void setRegistrador(ColaboradorViaticoBean registrador) {
		this.registrador = registrador;
	}

	public ColaboradorViaticoBean getJefe() {
		return jefe;
	}

	public void setJefe(ColaboradorViaticoBean jefe) {
		this.jefe = jefe;
	}

	public ColaboradorViaticoBean getAutorizador() {
		return autorizador;
	}

	public void setAutorizador(ColaboradorViaticoBean autorizador) {
		this.autorizador = autorizador;
	}

	public String getObservacionExpediente() {
		return observacionExpediente;
	}

	public void setObservacionExpediente(String observacionExpediente) {
		this.observacionExpediente = observacionExpediente;
	}

	public String getTipoProceso() {
		return tipoProceso;
	}

	public void setTipoProceso(String tipoProceso) {
		this.tipoProceso = tipoProceso;
	}

	public String getEstadoAccion() {
		return estadoAccion;
	}

	public void setEstadoAccion(String estadoAccion) {
		this.estadoAccion = estadoAccion;
	}

	public String getEstadoSolicitud() {
		return estadoSolicitud;
	}

	public void setEstadoSolicitud(String estadoSolicitud) {
		this.estadoSolicitud = estadoSolicitud;
	}

	public String getAccionSolicitud() {
		return accionSolicitud;
	}

	public void setAccionSolicitud(String accionSolicitud) {
		this.accionSolicitud = accionSolicitud;
	}

	public boolean isFlagErrorFormaPago() {
		return flagErrorFormaPago;
	}

	public void setFlagErrorFormaPago(boolean flagErrorFormaPago) {
		this.flagErrorFormaPago = flagErrorFormaPago;
	}

	public void setPlanViajeList(List<PlanViajeBean> planViajeList) {
		PlanViajeList = planViajeList;
	}

	public List<PlanViajeBean> getPlanViajeList() {
		return PlanViajeList;
	}

	public void setDependencia(DependenciaBean dependencia) {
		this.dependencia = dependencia;
	}

	public DependenciaBean getDependencia() {
		return dependencia;
	}

	/**
	 * @param nivelColaborador the nivelColaborador to set
	 */
	public void setNivelColaborador(NivelBean nivelColaborador) {
		this.nivelColaborador = nivelColaborador;
	}

	/**
	 * @return the nivelColaborador
	 */
	public NivelBean getNivelColaborador() {
		return nivelColaborador;
	}

	/**
	 * @param nivelAutorizador the nivelAutorizador to set
	 */
	public void setNivelAutorizador(NivelBean nivelAutorizador) {
		this.nivelAutorizador = nivelAutorizador;
	}

	/**
	 * @return the nivelAutorizador
	 */
	public NivelBean getNivelAutorizador() {
		return nivelAutorizador;
	}

	public List<PlanViajeConceptoBean> getPlanViajeConceptoList() {
		return planViajeConceptoList;
	}

	public void setPlanViajeConceptoList(List<PlanViajeConceptoBean> planViajeConceptoList) {
		this.planViajeConceptoList = planViajeConceptoList;
	}

	/**
	 * @param montoTotalConcepto the montoTotalConcepto to set
	 */
	public void setMontoTotalConcepto(String montoTotalConcepto) {
		this.montoTotalConcepto = montoTotalConcepto;
	}

	/**
	 * @return the montoTotalConcepto
	 */
	public String getMontoTotalConcepto() {
		return montoTotalConcepto;
	}

	/**
	 * @param conceptoList the conceptoList to set
	 */
	public void setConceptoList(List<Map<String, Object>> conceptoList) {
		this.conceptoList = conceptoList;
	}

	/**
	 * @return the conceptoList
	 */
	public List<Map<String, Object>> getConceptoList() {
		return conceptoList;
	}

	/**
	 * @param cuenta the cuenta to set
	 */
	public void setCuenta(CuentaCorrienteBean cuenta) {
		this.cuenta = cuenta;
	}

	/**
	 * @return the cuenta
	 */
	public CuentaCorrienteBean getCuenta() {
		return cuenta;
	}

	public PlanViajeBean getPlanillaAsociada() {
		return planillaAsociada;
	}

	public void setPlanillaAsociada(PlanViajeBean planillaAsociada) {
		this.planillaAsociada = planillaAsociada;
	}

	/**
	 * @param planViajeRendicionList the planViajeRendicionList to set
	 */
	public void setPlanViajeRendicionList(List<PlanViajeRendicionBean> planViajeRendicionList) {
		this.planViajeRendicionList = planViajeRendicionList;
	}

	/**
	 * @return the planViajeRendicionList
	 */
	public List<PlanViajeRendicionBean> getPlanViajeRendicionList() {
		return planViajeRendicionList;
	}

	/**
	 * @param importeComprobanteTotal the importeComprobanteTotal to set
	 */
	public void setImporteComprobanteTotal(String importeComprobanteTotal) {
		this.importeComprobanteTotal = importeComprobanteTotal;
	}

	/**
	 * @return the importeComprobanteTotal
	 */
	public String getImporteComprobanteTotal() {
		return importeComprobanteTotal;
	}

	public String getImporteAlimentacionTotal() {
		return importeAlimentacionTotal;
	}

	public void setImporteAlimentacionTotal(String importeAlimentacionTotal) {
		this.importeAlimentacionTotal = importeAlimentacionTotal;
	}

	public String getImporteTrasladoTotal() {
		return importeTrasladoTotal;
	}

	public void setImporteTrasladoTotal(String importeTrasladoTotal) {
		this.importeTrasladoTotal = importeTrasladoTotal;
	}

	public String getImporteAlojamientoTotal() {
		return importeAlojamientoTotal;
	}

	public void setImporteAlojamientoTotal(String importeAlojamientoTotal) {
		this.importeAlojamientoTotal = importeAlojamientoTotal;
	}

	public String getImporteMovilidadTotal() {
		return importeMovilidadTotal;
	}

	public void setImporteMovilidadTotal(String importeMovilidadTotal) {
		this.importeMovilidadTotal = importeMovilidadTotal;
	}

	/**
	 * @param importeTotalViatico the importeTotalViatico to set
	 */
	public void setImporteTotalViatico(String importeTotalViatico) {
		this.importeTotalViatico = importeTotalViatico;
	}

	/**
	 * @return the importeTotalViatico
	 */
	public String getImporteTotalViatico() {
		return importeTotalViatico;
	}

	/**
	 * @param importePasajeTotal the importePasajeTotal to set
	 */
	public void setImportePasajeTotal(String importePasajeTotal) {
		this.importePasajeTotal = importePasajeTotal;
	}

	/**
	 * @return the importePasajeTotal
	 */
	public String getImportePasajeTotal() {
		return importePasajeTotal;
	}

	/**
	 * @param importeTasaEmbarqueTotal the importeTasaEmbarqueTotal to set
	 */
	public void setImporteTasaEmbarqueTotal(String importeTasaEmbarqueTotal) {
		this.importeTasaEmbarqueTotal = importeTasaEmbarqueTotal;
	}

	/**
	 * @return the importeTasaEmbarqueTotal
	 */
	public String getImporteTasaEmbarqueTotal() {
		return importeTasaEmbarqueTotal;
	}

	/**
	 * @param importeOtrasAsignacionesTotal the importeOtrasAsignacionesTotal to set
	 */
	public void setImporteOtrasAsignacionesTotal(
			String importeOtrasAsignacionesTotal) {
		this.importeOtrasAsignacionesTotal = importeOtrasAsignacionesTotal;
	}

	/**
	 * @return the importeOtrasAsignacionesTotal
	 */
	public String getImporteOtrasAsignacionesTotal() {
		return importeOtrasAsignacionesTotal;
	}

	/**
	 * @param importeMontoTotalGasto the importeMontoTotalGasto to set
	 */
	public void setImporteMontoTotalGasto(String importeMontoTotalGasto) {
		this.importeMontoTotalGasto = importeMontoTotalGasto;
	}

	/**
	 * @return the importeMontoTotalGasto
	 */
	public String getImporteMontoTotalGasto() {
		return importeMontoTotalGasto;
	}

	/**
	 * @param fechaActual the fechaActual to set
	 */
	public void setFechaActual(String fechaActual) {
		this.fechaActual = fechaActual;
	}

	/**
	 * @return the fechaActual
	 */
	public String getFechaActual() {
		return fechaActual;
	}

	/**
	 * @param horaActual the horaActual to set
	 */
	public void setHoraActual(String horaActual) {
		this.horaActual = horaActual;
	}

	/**
	 * @return the horaActual
	 */
	public String getHoraActual() {
		return horaActual;
	}

}
