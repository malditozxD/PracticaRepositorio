package pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class PapeletaDepositoBean implements Serializable {

	private static final long serialVersionUID = -4548224302076797153L;
	private String codigoBoletaDeposito;
	private String codigoPlanViaje;
	private String codigoComprobanteIngreso;
	private String numeroComprobanteIngreso;
	private String numeroSerieFormulario;
	private String codigoBanco;
	private String codigoCuentaBanco;
	private String numeroCuentaBanco;
	private String nombreBanco;
	private String numeroOperacion;
	private Date fechaVoucher;
	private String fechaVoucherFormateada;
	private String flagBoletaDeposito;
	private String simboloMoneda;
	private BigDecimal montoUtilizado;
	private BigDecimal valorTipoCambio;
	private String valorTipoCambioFormateado;
	private BigDecimal montoDeposito;
	private String montoDepositoFormateado;
	private String reciboIngresoCajaAsosiado;
	private String codigoPersona;
	private String flagAsociadoRIC;
	private String flagPapeletaTotal;
	private String numeroRegistroArchivo;
	
	private String numeroOperacionWithoutZerosLeft;
	private String codigoSede;

	public String getCodigoBoletaDeposito() {
		return codigoBoletaDeposito;
	}

	public void setCodigoBoletaDeposito(String codigoBoletaDeposito) {
		this.codigoBoletaDeposito = codigoBoletaDeposito;
	}

	public String getCodigoPlanViaje() {
		return codigoPlanViaje;
	}

	public void setCodigoPlanViaje(String codigoPlanViaje) {
		this.codigoPlanViaje = codigoPlanViaje;
	}

	public String getCodigoComprobanteIngreso() {
		return codigoComprobanteIngreso;
	}

	public void setCodigoComprobanteIngreso(String codigoComprobanteIngreso) {
		this.codigoComprobanteIngreso = codigoComprobanteIngreso;
	}

	public String getNumeroComprobanteIngreso() {
		return numeroComprobanteIngreso;
	}

	public void setNumeroComprobanteIngreso(String numeroComprobanteIngreso) {
		this.numeroComprobanteIngreso = numeroComprobanteIngreso;
	}

	public String getNumeroSerieFormulario() {
		return numeroSerieFormulario;
	}

	public void setNumeroSerieFormulario(String numeroSerieFormulario) {
		this.numeroSerieFormulario = numeroSerieFormulario;
	}

	public String getCodigoBanco() {
		return codigoBanco;
	}

	public void setCodigoBanco(String codigoBanco) {
		this.codigoBanco = codigoBanco;
	}

	public String getCodigoCuentaBanco() {
		return codigoCuentaBanco;
	}

	public void setCodigoCuentaBanco(String codigoCuentaBanco) {
		this.codigoCuentaBanco = codigoCuentaBanco;
	}

	public String getNumeroCuentaBanco() {
		return numeroCuentaBanco;
	}

	public void setNumeroCuentaBanco(String numeroCuentaBanco) {
		this.numeroCuentaBanco = numeroCuentaBanco;
	}

	public String getNombreBanco() {
		return nombreBanco;
	}

	public void setNombreBanco(String nombreBanco) {
		this.nombreBanco = nombreBanco;
	}

	public String getNumeroOperacion() {
		return numeroOperacion;
	}

	public void setNumeroOperacion(String numeroOperacion) {
		this.numeroOperacion = numeroOperacion;
	}

	public Date getFechaVoucher() {
		return fechaVoucher;
	}

	public void setFechaVoucher(Date fechaVoucher) {
		this.fechaVoucher = fechaVoucher;
	}

	public String getFechaVoucherFormateada() {
		return fechaVoucherFormateada;
	}

	public void setFechaVoucherFormateada(String fechaVoucherFormateada) {
		this.fechaVoucherFormateada = fechaVoucherFormateada;
	}

	public String getFlagBoletaDeposito() {
		return flagBoletaDeposito;
	}

	public void setFlagBoletaDeposito(String flagBoletaDeposito) {
		this.flagBoletaDeposito = flagBoletaDeposito;
	}

	public String getSimboloMoneda() {
		return simboloMoneda;
	}

	public void setSimboloMoneda(String simboloMoneda) {
		this.simboloMoneda = simboloMoneda;
	}

	public BigDecimal getMontoUtilizado() {
		return montoUtilizado;
	}

	public void setMontoUtilizado(BigDecimal montoUtilizado) {
		this.montoUtilizado = montoUtilizado;
	}

	public BigDecimal getValorTipoCambio() {
		return valorTipoCambio;
	}

	public void setValorTipoCambio(BigDecimal valorTipoCambio) {
		this.valorTipoCambio = valorTipoCambio;
	}

	public String getValorTipoCambioFormateado() {
		return valorTipoCambioFormateado;
	}

	public void setValorTipoCambioFormateado(String valorTipoCambioFormateado) {
		this.valorTipoCambioFormateado = valorTipoCambioFormateado;
	}

	public BigDecimal getMontoDeposito() {
		return montoDeposito;
	}

	public void setMontoDeposito(BigDecimal montoDeposito) {
		this.montoDeposito = montoDeposito;
	}

	public String getMontoDepositoFormateado() {
		return montoDepositoFormateado;
	}

	public void setMontoDepositoFormateado(String montoDepositoFormateado) {
		this.montoDepositoFormateado = montoDepositoFormateado;
	}

	public String getReciboIngresoCajaAsosiado() {
		return reciboIngresoCajaAsosiado;
	}

	public void setReciboIngresoCajaAsosiado(String reciboIngresoCajaAsosiado) {
		this.reciboIngresoCajaAsosiado = reciboIngresoCajaAsosiado;
	}

	public String getCodigoPersona() {
		return codigoPersona;
	}

	public void setCodigoPersona(String codigoPersona) {
		this.codigoPersona = codigoPersona;
	}

	public String getFlagAsociadoRIC() {
		return flagAsociadoRIC;
	}

	public void setFlagAsociadoRIC(String flagAsociadoRIC) {
		this.flagAsociadoRIC = flagAsociadoRIC;
	}

	public String getFlagPapeletaTotal() {
		return flagPapeletaTotal;
	}

	public void setFlagPapeletaTotal(String flagPapeletaTotal) {
		this.flagPapeletaTotal = flagPapeletaTotal;
	}

	public void setNumeroRegistroArchivo(String numeroRegistroArchivo) {
		this.numeroRegistroArchivo = numeroRegistroArchivo;
	}

	public String getNumeroRegistroArchivo() {
		return numeroRegistroArchivo;
	}

	public String getNumeroOperacionWithoutZerosLeft() {
		return numeroOperacionWithoutZerosLeft;
	}

	public void setNumeroOperacionWithoutZerosLeft(
			String numeroOperacionWithoutZerosLeft) {
		this.numeroOperacionWithoutZerosLeft = numeroOperacionWithoutZerosLeft;
	}

	public String getCodigoSede() {
		return codigoSede;
	}

	public void setCodigoSede(String codigoSede) {
		this.codigoSede = codigoSede;
	}


}
