package pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean;

import java.io.Serializable;
import java.util.Date;

// TABLA: t1273licencia
public class LicenciaBean implements Serializable {

	private static final long serialVersionUID = 2397769441112830065L;
	
	// campos de la tabla
	private String periodo; 							// periodo char(6) NOT NULL,
	private String anno; 								// anno char(4),
	private String numero; 								// numero int NOT NULL,
	private String u_organ; 							// u_organ char(8),
	private Date fechaInicio;							// ffinicio datetime NOT NULL,
	private Date fechaFin;								// ffin datetime,
	private String numeroRegistro;						// cod_pers char(4) NOT NULL,
	private Double qdias; 								// qdias float,
	private String licencia; 							// licencia char(4) NOT NULL,
	private String anno_ref; 							// anno_ref char(4),
	private Integer numero_ref;							// numero_ref int,
	private String area_ref; 							// area_ref char(8),
	private String observ; 								// observ varchar(250),
	private Date fcreacion;								// fcreacion datetime,
	private String cuser_crea;							// cuser_crea char(15),
	private Date fmod; 									// fmod datetime,
	private String cuser_mod;							// cuser_mod char(15),
	private String ind_subsidio; 						// ind_subsidio char(1),
	private String ann_subsidio;						// ann_subsidio char(4),

	// campos adicionales
	private String concepto;
	private Integer diferenciaDias;

	public String getPeriodo() {
		return periodo;
	}

	public void setPeriodo(String periodo) {
		this.periodo = periodo;
	}

	public String getAnno() {
		return anno;
	}

	public void setAnno(String anno) {
		this.anno = anno;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getU_organ() {
		return u_organ;
	}

	public void setU_organ(String u_organ) {
		this.u_organ = u_organ;
	}

	public Date getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public Date getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(Date fechaFin) {
		this.fechaFin = fechaFin;
	}

	public Double getQdias() {
		return qdias;
	}

	public void setQdias(Double qdias) {
		this.qdias = qdias;
	}

	public String getLicencia() {
		return licencia;
	}

	public void setLicencia(String licencia) {
		this.licencia = licencia;
	}

	public String getAnno_ref() {
		return anno_ref;
	}

	public void setAnno_ref(String anno_ref) {
		this.anno_ref = anno_ref;
	}

	public Integer getNumero_ref() {
		return numero_ref;
	}

	public void setNumero_ref(Integer numero_ref) {
		this.numero_ref = numero_ref;
	}

	public String getArea_ref() {
		return area_ref;
	}

	public void setArea_ref(String area_ref) {
		this.area_ref = area_ref;
	}

	public String getObserv() {
		return observ;
	}

	public void setObserv(String observ) {
		this.observ = observ;
	}

	public Date getFcreacion() {
		return fcreacion;
	}

	public void setFcreacion(Date fcreacion) {
		this.fcreacion = fcreacion;
	}

	public String getCuser_crea() {
		return cuser_crea;
	}

	public void setCuser_crea(String cuser_crea) {
		this.cuser_crea = cuser_crea;
	}

	public Date getFmod() {
		return fmod;
	}

	public void setFmod(Date fmod) {
		this.fmod = fmod;
	}

	public String getCuser_mod() {
		return cuser_mod;
	}

	public void setCuser_mod(String cuser_mod) {
		this.cuser_mod = cuser_mod;
	}

	public String getInd_subsidio() {
		return ind_subsidio;
	}

	public void setInd_subsidio(String ind_subsidio) {
		this.ind_subsidio = ind_subsidio;
	}

	public String getAnn_subsidio() {
		return ann_subsidio;
	}

	public void setAnn_subsidio(String ann_subsidio) {
		this.ann_subsidio = ann_subsidio;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public Integer getDiferenciaDias() {
		return diferenciaDias;
	}

	public void setDiferenciaDias(Integer diferenciaDias) {
		this.diferenciaDias = diferenciaDias;
	}

	public String getNumeroRegistro() {
		return numeroRegistro;
	}

	public void setNumeroRegistro(String numeroRegistro) {
		this.numeroRegistro = numeroRegistro;
	}
	 
}
