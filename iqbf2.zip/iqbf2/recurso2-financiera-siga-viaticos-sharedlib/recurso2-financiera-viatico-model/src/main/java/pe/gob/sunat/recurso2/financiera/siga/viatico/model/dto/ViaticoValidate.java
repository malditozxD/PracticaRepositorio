package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dto;

import java.io.Serializable;

public class ViaticoValidate implements Serializable {

	private static final long serialVersionUID = -7898346772076766652L;
	private boolean flagValidacion;
	private String successMessage;
	private String errorMessage;

	public boolean isFlagValidacion() {
		return flagValidacion;
	}

	public void setFlagValidacion(boolean flagValidacion) {
		this.flagValidacion = flagValidacion;
	}

	public String getSuccessMessage() {
		return successMessage;
	}

	public void setSuccessMessage(String successMessage) {
		this.successMessage = successMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

}
