package pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class RendicionDTO implements Serializable {

	private static final long serialVersionUID = 1265845622826042494L;
	private PlanViajeBean planViaje;
	private String montoRendirTotal;
	private String montoComprobanteTotal;
	private String montoDepositoTotal;
	private String montoRICTotal;
	private String montoDevueltoTotal;
	private String montoNoUtilizadoTotal;
	private String montoDiferenciaTotal;
	private String fechaActual;
	private String horaActual;
	private ArrayList<PlanViajeRendicionBean> planViajeRendicionList;
	private ArrayList<PlanViajeConceptoBean> planViajeConceptoList;
	private ArrayList<PapeletaDepositoBean> papeletaDepositoList;
	private ArrayList<ComprobanteIngresoBean> comprobanteIngresoList;
	private ColaboradorViaticoBean colaborador; 
	private ColaboradorViaticoBean registrador;
	private NivelBean nivel;
	private CabeceraMovBean cabeceraMov;
	private List<PlanViajeInformeDistribBean> planViajeInformeList;
	private String montoDetalleComprobanteTotal;
	private String importeComprobanteTotal;
	private NivelBean nivelRegistrador;
	
	public PlanViajeBean getPlanViaje() {
		return planViaje;
	}

	public void setPlanViaje(PlanViajeBean planViaje) {
		this.planViaje = planViaje;
	}

	public String getMontoRendirTotal() {
		return montoRendirTotal;
	}

	public void setMontoRendirTotal(String montoRendirTotal) {
		this.montoRendirTotal = montoRendirTotal;
	}

	public String getMontoComprobanteTotal() {
		return montoComprobanteTotal;
	}

	public void setMontoComprobanteTotal(String montoComprobanteTotal) {
		this.montoComprobanteTotal = montoComprobanteTotal;
	}

	public String getMontoDepositoTotal() {
		return montoDepositoTotal;
	}

	public void setMontoDepositoTotal(String montoDepositoTotal) {
		this.montoDepositoTotal = montoDepositoTotal;
	}

	public String getMontoRICTotal() {
		return montoRICTotal;
	}

	public void setMontoRICTotal(String montoRICTotal) {
		this.montoRICTotal = montoRICTotal;
	}

	public String getMontoDevueltoTotal() {
		return montoDevueltoTotal;
	}

	public void setMontoDevueltoTotal(String montoDevueltoTotal) {
		this.montoDevueltoTotal = montoDevueltoTotal;
	}

	public String getMontoNoUtilizadoTotal() {
		return montoNoUtilizadoTotal;
	}

	public void setMontoNoUtilizadoTotal(String montoNoUtilizadoTotal) {
		this.montoNoUtilizadoTotal = montoNoUtilizadoTotal;
	}

	public String getMontoDiferenciaTotal() {
		return montoDiferenciaTotal;
	}

	public void setMontoDiferenciaTotal(String montoDiferenciaTotal) {
		this.montoDiferenciaTotal = montoDiferenciaTotal;
	}

	public String getFechaActual() {
		return fechaActual;
	}

	public void setFechaActual(String fechaActual) {
		this.fechaActual = fechaActual;
	}

	public String getHoraActual() {
		return horaActual;
	}

	public void setHoraActual(String horaActual) {
		this.horaActual = horaActual;
	}

	public ArrayList<PlanViajeRendicionBean> getPlanViajeRendicionList() {
		return planViajeRendicionList;
	}

	public void setPlanViajeRendicionList(
			ArrayList<PlanViajeRendicionBean> planViajeRendicionList) {
		this.planViajeRendicionList = planViajeRendicionList;
	}

	public ArrayList<PlanViajeConceptoBean> getPlanViajeConceptoList() {
		return planViajeConceptoList;
	}

	public void setPlanViajeConceptoList(
			ArrayList<PlanViajeConceptoBean> planViajeConceptoList) {
		this.planViajeConceptoList = planViajeConceptoList;
	}

	public ArrayList<PapeletaDepositoBean> getPapeletaDepositoList() {
		return papeletaDepositoList;
	}

	public void setPapeletaDepositoList(
			ArrayList<PapeletaDepositoBean> papeletaDepositoList) {
		this.papeletaDepositoList = papeletaDepositoList;
	}

	public ArrayList<ComprobanteIngresoBean> getComprobanteIngresoList() {
		return comprobanteIngresoList;
	}

	public void setComprobanteIngresoList(
			ArrayList<ComprobanteIngresoBean> comprobanteIngresoList) {
		this.comprobanteIngresoList = comprobanteIngresoList;
	}

	public void setColaborador(ColaboradorViaticoBean colaborador) {
		this.colaborador = colaborador;
	}

	public ColaboradorViaticoBean getColaborador() {
		return colaborador;
	}

	public void setRegistrador(ColaboradorViaticoBean registrador) {
		this.registrador = registrador;
	}

	public ColaboradorViaticoBean getRegistrador() {
		return registrador;
	}

	public void setNivel(NivelBean nivel) {
		this.nivel = nivel;
	}

	public NivelBean getNivel() {
		return nivel;
	}

	public void setCabeceraMov(CabeceraMovBean cabeceraMov) {
		this.cabeceraMov = cabeceraMov;
	}

	public CabeceraMovBean getCabeceraMov() {
		return cabeceraMov;
	}

	/**
	 * @param planViajeInformeList the planViajeInformeList to set
	 */
	public void setPlanViajeInformeList(List<PlanViajeInformeDistribBean> planViajeInformeList) {
		this.planViajeInformeList = planViajeInformeList;
	}

	/**
	 * @return the planViajeInformeList
	 */
	public List<PlanViajeInformeDistribBean> getPlanViajeInformeList() {
		return planViajeInformeList;
	}

	/**
	 * @param montoDetallaComprobanteTotal the montoDetallaComprobanteTotal to set
	 */
	public void setMontoDetalleComprobanteTotal(
			String montoDetalleComprobanteTotal) {
		this.montoDetalleComprobanteTotal = montoDetalleComprobanteTotal;
	}

	/**
	 * @return the montoDetallaComprobanteTotal
	 */
	public String getMontoDetalleComprobanteTotal() {
		return montoDetalleComprobanteTotal;
	}

	/**
	 * @param importeComprobanteTotal the importeComprobanteTotal to set
	 */
	public void setImporteComprobanteTotal(String importeComprobanteTotal) {
		this.importeComprobanteTotal = importeComprobanteTotal;
	}

	/**
	 * @return the importeComprobanteTotal
	 */
	public String getImporteComprobanteTotal() {
		return importeComprobanteTotal;
	}

	public NivelBean getNivelRegistrador() {
		return nivelRegistrador;
	}

	public void setNivelRegistrador(NivelBean nivelRegistrador) {
		this.nivelRegistrador = nivelRegistrador;
	}

}
