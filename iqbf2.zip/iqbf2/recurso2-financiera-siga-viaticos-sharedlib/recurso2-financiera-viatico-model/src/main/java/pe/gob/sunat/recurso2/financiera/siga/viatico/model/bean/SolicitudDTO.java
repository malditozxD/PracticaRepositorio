package pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.DependenciaBean;

public class SolicitudDTO implements Serializable {

	private static final long serialVersionUID = 4746767746088075686L;

	private String numPlanilla = "";
	private PlanViajeBean planViajeBean;
	private List<PlanViajeBean> PlanViajeList;
	
	// datos de colaborador
	private String flagAuditor;

	// datos bean
	private ColaboradorViaticoBean colaborador;
	private ColaboradorViaticoBean registrador;
	private ColaboradorViaticoBean jefe;
	private ColaboradorViaticoBean autorizador;
	private DependenciaBean dependencia;
	// para el envio de la solicitud
	private String observacionExpediente = "";

	// PARA PROCESO//MANUAL -AUTOMATICO
	private String tipoProceso = "";

	// ESTADOS
	private String estadoAccion = "";
	private String estadoSolicitud = "";

	// VARIOS
	private String accionSolicitud; // R:Registro, M:modificacion;
	private boolean flagErrorFormaPago;
	private NivelBean nivelColaborador;
	private NivelBean nivelAutorizador;
	private NivelBean nivelRegistrador;
	List<PlanViajeConceptoBean> planViajeConceptoList;
	private String montoTotalConcepto; 
	private List<Map<String, Object>> conceptoList;
	private CuentaCorrienteBean cuenta;
	
	
	public PlanViajeBean getPlanViajeBean() {
		return planViajeBean;
	}

	public void setPlanViajeBean(PlanViajeBean planViajeBean) {
		this.planViajeBean = planViajeBean;
	}

	public String getNumPlanilla() {
		return numPlanilla;
	}

	public void setNumPlanilla(String numPlanilla) {
		this.numPlanilla = numPlanilla;
	}

	public String getFlagAuditor() {
		return flagAuditor;
	}

	public void setFlagAuditor(String flagAuditor) {
		this.flagAuditor = flagAuditor;
	}

	public ColaboradorViaticoBean getColaborador() {
		return colaborador;
	}

	public void setColaborador(ColaboradorViaticoBean colaborador) {
		this.colaborador = colaborador;
	}

	public ColaboradorViaticoBean getRegistrador() {
		return registrador;
	}

	public void setRegistrador(ColaboradorViaticoBean registrador) {
		this.registrador = registrador;
	}

	public ColaboradorViaticoBean getJefe() {
		return jefe;
	}

	public void setJefe(ColaboradorViaticoBean jefe) {
		this.jefe = jefe;
	}

	public ColaboradorViaticoBean getAutorizador() {
		return autorizador;
	}

	public void setAutorizador(ColaboradorViaticoBean autorizador) {
		this.autorizador = autorizador;
	}

	public String getObservacionExpediente() {
		return observacionExpediente;
	}

	public void setObservacionExpediente(String observacionExpediente) {
		this.observacionExpediente = observacionExpediente;
	}

	public String getTipoProceso() {
		return tipoProceso;
	}

	public void setTipoProceso(String tipoProceso) {
		this.tipoProceso = tipoProceso;
	}

	public String getEstadoAccion() {
		return estadoAccion;
	}

	public void setEstadoAccion(String estadoAccion) {
		this.estadoAccion = estadoAccion;
	}

	public String getEstadoSolicitud() {
		return estadoSolicitud;
	}

	public void setEstadoSolicitud(String estadoSolicitud) {
		this.estadoSolicitud = estadoSolicitud;
	}

	public String getAccionSolicitud() {
		return accionSolicitud;
	}

	public void setAccionSolicitud(String accionSolicitud) {
		this.accionSolicitud = accionSolicitud;
	}

	public boolean isFlagErrorFormaPago() {
		return flagErrorFormaPago;
	}

	public void setFlagErrorFormaPago(boolean flagErrorFormaPago) {
		this.flagErrorFormaPago = flagErrorFormaPago;
	}

	public void setPlanViajeList(List<PlanViajeBean> planViajeList) {
		PlanViajeList = planViajeList;
	}

	public List<PlanViajeBean> getPlanViajeList() {
		return PlanViajeList;
	}

	public void setDependencia(DependenciaBean dependencia) {
		this.dependencia = dependencia;
	}

	public DependenciaBean getDependencia() {
		return dependencia;
	}

	/**
	 * @param nivelColaborador the nivelColaborador to set
	 */
	public void setNivelColaborador(NivelBean nivelColaborador) {
		this.nivelColaborador = nivelColaborador;
	}

	/**
	 * @return the nivelColaborador
	 */
	public NivelBean getNivelColaborador() {
		return nivelColaborador;
	}

	/**
	 * @param nivelAutorizador the nivelAutorizador to set
	 */
	public void setNivelAutorizador(NivelBean nivelAutorizador) {
		this.nivelAutorizador = nivelAutorizador;
	}

	/**
	 * @return the nivelAutorizador
	 */
	public NivelBean getNivelAutorizador() {
		return nivelAutorizador;
	}

	public List<PlanViajeConceptoBean> getPlanViajeConceptoList() {
		return planViajeConceptoList;
	}

	public void setPlanViajeConceptoList(
			List<PlanViajeConceptoBean> planViajeConceptoList) {
		this.planViajeConceptoList = planViajeConceptoList;
	}

	/**
	 * @param montoTotalConcepto the montoTotalConcepto to set
	 */
	public void setMontoTotalConcepto(String montoTotalConcepto) {
		this.montoTotalConcepto = montoTotalConcepto;
	}

	/**
	 * @return the montoTotalConcepto
	 */
	public String getMontoTotalConcepto() {
		return montoTotalConcepto;
	}

	/**
	 * @param conceptoList the conceptoList to set
	 */
	public void setConceptoList(List<Map<String, Object>> conceptoList) {
		this.conceptoList = conceptoList;
	}

	/**
	 * @return the conceptoList
	 */
	public List<Map<String, Object>> getConceptoList() {
		return conceptoList;
	}

	/**
	 * @param cuenta the cuenta to set
	 */
	public void setCuenta(CuentaCorrienteBean cuenta) {
		this.cuenta = cuenta;
	}

	/**
	 * @return the cuenta
	 */
	public CuentaCorrienteBean getCuenta() {
		return cuenta;
	}

	public NivelBean getNivelRegistrador() {
		return nivelRegistrador;
	}

	public void setNivelRegistrador(NivelBean nivelRegistrador) {
		this.nivelRegistrador = nivelRegistrador;
	}


		

}
