package pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean;

import java.util.Date;

public class SysGlobalParametrosBean {

	private Date fechInicPar; // FECH_INIC_PAR	
	private Double valoNumePar; //VALO_NUME_PAR
	
	
	public Date getFechInicPar() {
		return fechInicPar;
	}
	public void setFechInicPar(Date fechInicPar) {
		this.fechInicPar = fechInicPar;
	}
	public Double getValoNumePar() {
		return valoNumePar;
	}
	public void setValoNumePar(Double valoNumePar) {
		this.valoNumePar = valoNumePar;
	}
	
	
}
