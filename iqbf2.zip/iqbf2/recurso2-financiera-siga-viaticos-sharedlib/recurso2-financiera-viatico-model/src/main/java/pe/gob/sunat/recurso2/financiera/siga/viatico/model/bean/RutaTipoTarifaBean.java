package pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean;

import java.io.Serializable;

public class RutaTipoTarifaBean implements Serializable {

	private static final long serialVersionUID = -3756310987943806889L;

	private String codigo;
	private String descripcion;
	private Double porcentaje;

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Double getPorcentaje() {
		return porcentaje;
	}

	public void setPorcentaje(Double porcentaje) {
		this.porcentaje = porcentaje;
	}

}
