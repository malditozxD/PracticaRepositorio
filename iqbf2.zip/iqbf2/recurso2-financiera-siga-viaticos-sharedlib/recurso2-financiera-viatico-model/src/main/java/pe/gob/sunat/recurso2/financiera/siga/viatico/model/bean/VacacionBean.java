package pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean;

import java.io.Serializable;
import java.util.Date;

// TABLA: t1282vacaciones_d
public class VacacionBean implements Serializable {

	private static final long serialVersionUID = 3252203427765069429L;
	
	// campos de la tabla
	private String numeroRegistro; 						// cod_pers char(4) NOT NULL,
	private String periodo;								// periodo char(6) NOT NULL,
	private String licencia;							// licencia char(4),
	private Date fechaInicio;							// ffinicio datetime NOT NULL,
	private String anno_vac; 							// anno_vac char(4),
	private Date fechaFin; 								// ffin datetime,
	private Integer dias; 								// dias int,
	private String anno; 								// anno char(4),
	private String u_organ; 							// u_organ char(8),
	private String anno_ref;							// anno_ref char(4),
	private String area_ref; 							// area_ref char(8),
	private Integer numero_ref; 						// numero_ref int,
	private String observ; 								// observ varchar(250),
	private String est_id; 								// est_id char(1),
	private Date fcreacion; 							// fcreacion datetime,
	private String cuser_crea;							// cuser_crea char(15),
	private Date fmod;									// fmod datetime,
	private String cuser_mod; 							// cuser_mod char(15),
	private String ind_conv; 							// ind_conv char(1) DEFAULT 0,
	private String ind_matri; 							// ind_matri char(1)

	// campos adicionales
	private String concepto;
	private Integer diferenciaDias;
	
	public String getNumeroRegistro() {
		return numeroRegistro;
	}

	public void setNumeroRegistro(String numeroRegistro) {
		this.numeroRegistro = numeroRegistro;
	}

	public String getPeriodo() {
		return periodo;
	}

	public void setPeriodo(String periodo) {
		this.periodo = periodo;
	}

	public String getLicencia() {
		return licencia;
	}

	public void setLicencia(String licencia) {
		this.licencia = licencia;
	}

	public Date getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public String getAnno_vac() {
		return anno_vac;
	}

	public void setAnno_vac(String anno_vac) {
		this.anno_vac = anno_vac;
	}

	public Date getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(Date fechaFin) {
		this.fechaFin = fechaFin;
	}

	public Integer getDias() {
		return dias;
	}

	public void setDias(Integer dias) {
		this.dias = dias;
	}

	public String getAnno() {
		return anno;
	}

	public void setAnno(String anno) {
		this.anno = anno;
	}

	public String getU_organ() {
		return u_organ;
	}

	public void setU_organ(String u_organ) {
		this.u_organ = u_organ;
	}

	public String getAnno_ref() {
		return anno_ref;
	}

	public void setAnno_ref(String anno_ref) {
		this.anno_ref = anno_ref;
	}

	public String getArea_ref() {
		return area_ref;
	}

	public void setArea_ref(String area_ref) {
		this.area_ref = area_ref;
	}

	public Integer getNumero_ref() {
		return numero_ref;
	}

	public void setNumero_ref(Integer numero_ref) {
		this.numero_ref = numero_ref;
	}

	public String getObserv() {
		return observ;
	}

	public void setObserv(String observ) {
		this.observ = observ;
	}

	public String getEst_id() {
		return est_id;
	}

	public void setEst_id(String est_id) {
		this.est_id = est_id;
	}

	public Date getFcreacion() {
		return fcreacion;
	}

	public void setFcreacion(Date fcreacion) {
		this.fcreacion = fcreacion;
	}

	public String getCuser_crea() {
		return cuser_crea;
	}

	public void setCuser_crea(String cuser_crea) {
		this.cuser_crea = cuser_crea;
	}

	public Date getFmod() {
		return fmod;
	}

	public void setFmod(Date fmod) {
		this.fmod = fmod;
	}

	public String getCuser_mod() {
		return cuser_mod;
	}

	public void setCuser_mod(String cuser_mod) {
		this.cuser_mod = cuser_mod;
	}

	public String getInd_conv() {
		return ind_conv;
	}

	public void setInd_conv(String ind_conv) {
		this.ind_conv = ind_conv;
	}

	public String getInd_matri() {
		return ind_matri;
	}

	public void setInd_matri(String ind_matri) {
		this.ind_matri = ind_matri;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public Integer getDiferenciaDias() {
		return diferenciaDias;
	}

	public void setDiferenciaDias(Integer diferenciaDias) {
		this.diferenciaDias = diferenciaDias;
	}
 

}
