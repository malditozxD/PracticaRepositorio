package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dto;

import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.DependenciaBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ColaboradorViaticoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;

public class ReporteViaticoDTO {
	
	private PlanViajeBean planViaje;
	private ColaboradorViaticoBean colaborador;
	private ColaboradorViaticoBean registrador;
	private DependenciaBean dependencia;
	private ColaboradorViaticoBean autorizador;
	
	public void setPlanViaje(PlanViajeBean planViaje) {
		this.planViaje = planViaje;
	}

	public PlanViajeBean getPlanViaje() {
		return planViaje;
	}

	public ColaboradorViaticoBean getColaborador() {
		return colaborador;
	}

	public void setColaborador(ColaboradorViaticoBean colaborador) {
		this.colaborador = colaborador;
	}

	public ColaboradorViaticoBean getRegistrador() {
		return registrador;
	}

	public void setRegistrador(ColaboradorViaticoBean registrador) {
		this.registrador = registrador;
	}

	public void setDependencia(DependenciaBean dependencia) {
		this.dependencia = dependencia;
	}

	public DependenciaBean getDependencia() {
		return dependencia;
	}

	public void setAutorizador(ColaboradorViaticoBean autorizador) {
		this.autorizador = autorizador;
	}

	public ColaboradorViaticoBean getAutorizador() {
		return autorizador;
	}
	
	
}
