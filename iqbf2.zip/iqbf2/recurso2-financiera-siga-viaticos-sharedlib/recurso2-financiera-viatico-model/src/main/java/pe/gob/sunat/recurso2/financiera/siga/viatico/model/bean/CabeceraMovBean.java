package pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean;

import java.io.Serializable;


public class CabeceraMovBean implements Serializable {

	private static final long serialVersionUID = -2376024394770970674L;
	
	private String numeroRegistroCab;
	private String numeroNotaCab;
	private String numeroSiafCab;
	
	public String getNumeroRegistroCab() {
		return numeroRegistroCab;
	}
	public void setNumeroRegistroCab(String numeroRegistroCab) {
		this.numeroRegistroCab = numeroRegistroCab;
	}
	public String getNumeroNotaCab() {
		return numeroNotaCab;
	}
	public void setNumeroNotaCab(String numeroNotaCab) {
		this.numeroNotaCab = numeroNotaCab;
	}
	public String getNumeroSiafCab() {
		return numeroSiafCab;
	}
	public void setNumeroSiafCab(String numeroSiafCab) {
		this.numeroSiafCab = numeroSiafCab;
	}
	
}
