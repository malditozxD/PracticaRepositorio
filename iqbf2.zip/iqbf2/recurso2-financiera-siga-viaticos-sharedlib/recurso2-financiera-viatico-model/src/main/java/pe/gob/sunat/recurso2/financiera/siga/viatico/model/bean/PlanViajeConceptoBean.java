package pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class PlanViajeConceptoBean implements Serializable {

	private static final long serialVersionUID = 1707250015002673952L;
	
	private String planViajeID;             // PLAN_VIAJE_ID            not null
    private String conceptoID;              // CONCEPTO_ID				not null
    private String descripcionConcepto;
    private Double cantidad;                // CANTIDAD					not null
    private Double monto;                   // MONTO					not null
    private String clasificadorGasto;       // CLASIFICADOR_GASTO		not null
    private Double montoManual;             // MONTO_MANUAL
    private Double montoReal;               // MONTO_REAL
    private String usuarioCreacion;         // USER_CREA
    private Date fechaCreacion;             // FECH_CREA
    private String usuarioModificacion;     // USER_MODI
    private Date fechaModificacion;         // FECH_MODI
    private Double montoRendido;            // MTO_RENDIDO
    private Double montoDevuelto;           // MTO_DEVUELTO
    private Double montoRic;                // MTO_RIC
    private BigDecimal montoDevueltoVoucherRIC;
    private BigDecimal montoDevolver;
    private String montoFormateado;
    private String montoRendidoFormateado;
    private String montoDevueltoFormateado;
    private String montoRicFormateado;
	private String montoDevueltoVoucherRICFormateado;
	private String montoDevolverFormateado;
	private String flagMontoDevolverNegativo;
	private String flagPlanViajeConceptoTotal;

	public String getPlanViajeID() {
		return planViajeID;
	}

	public void setPlanViajeID(String planViajeID) {
		this.planViajeID = planViajeID;
	}

	public String getConceptoID() {
		return conceptoID;
	}

	public void setConceptoID(String conceptoID) {
		this.conceptoID = conceptoID;
	}

	public String getDescripcionConcepto() {
		return descripcionConcepto;
	}

	public void setDescripcionConcepto(String descripcionConcepto) {
		this.descripcionConcepto = descripcionConcepto;
	}

	public Double getCantidad() {
		return cantidad;
	}

	public void setCantidad(Double cantidad) {
		this.cantidad = cantidad;
	}

	public Double getMonto() {
		return monto;
	}

	public void setMonto(Double monto) {
		this.monto = monto;
	}

	public String getClasificadorGasto() {
		return clasificadorGasto;
	}

	public void setClasificadorGasto(String clasificadorGasto) {
		this.clasificadorGasto = clasificadorGasto;
	}

	public Double getMontoManual() {
		return montoManual;
	}

	public void setMontoManual(Double montoManual) {
		this.montoManual = montoManual;
	}

	public Double getMontoReal() {
		return montoReal;
	}

	public void setMontoReal(Double montoReal) {
		this.montoReal = montoReal;
	}

	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}

	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public String getUsuarioModificacion() {
		return usuarioModificacion;
	}

	public void setUsuarioModificacion(String usuarioModificacion) {
		this.usuarioModificacion = usuarioModificacion;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public Double getMontoRendido() {
		return montoRendido;
	}

	public void setMontoRendido(Double montoRendido) {
		this.montoRendido = montoRendido;
	}

	public Double getMontoDevuelto() {
		return montoDevuelto;
	}

	public void setMontoDevuelto(Double montoDevuelto) {
		this.montoDevuelto = montoDevuelto;
	}

	public Double getMontoRic() {
		return montoRic;
	}

	public void setMontoRic(Double montoRic) {
		this.montoRic = montoRic;
	}

	public BigDecimal getMontoDevueltoVoucherRIC() {
		return montoDevueltoVoucherRIC;
	}

	public void setMontoDevueltoVoucherRIC(BigDecimal montoDevueltoVoucherRIC) {
		this.montoDevueltoVoucherRIC = montoDevueltoVoucherRIC;
	}

	public BigDecimal getMontoDevolver() {
		return montoDevolver;
	}

	public void setMontoDevolver(BigDecimal montoDevolver) {
		this.montoDevolver = montoDevolver;
	}

	public String getMontoFormateado() {
		return montoFormateado;
	}

	public void setMontoFormateado(String montoFormateado) {
		this.montoFormateado = montoFormateado;
	}

	public String getMontoRendidoFormateado() {
		return montoRendidoFormateado;
	}

	public void setMontoRendidoFormateado(String montoRendidoFormateado) {
		this.montoRendidoFormateado = montoRendidoFormateado;
	}

	public String getMontoDevueltoFormateado() {
		return montoDevueltoFormateado;
	}

	public void setMontoDevueltoFormateado(String montoDevueltoFormateado) {
		this.montoDevueltoFormateado = montoDevueltoFormateado;
	}

	public String getMontoRicFormateado() {
		return montoRicFormateado;
	}

	public void setMontoRicFormateado(String montoRicFormateado) {
		this.montoRicFormateado = montoRicFormateado;
	}

	public String getMontoDevueltoVoucherRICFormateado() {
		return montoDevueltoVoucherRICFormateado;
	}

	public void setMontoDevueltoVoucherRICFormateado(
			String montoDevueltoVoucherRICFormateado) {
		this.montoDevueltoVoucherRICFormateado = montoDevueltoVoucherRICFormateado;
	}

	public String getMontoDevolverFormateado() {
		return montoDevolverFormateado;
	}

	public void setMontoDevolverFormateado(String montoDevolverFormateado) {
		this.montoDevolverFormateado = montoDevolverFormateado;
	}

	public String getFlagMontoDevolverNegativo() {
		return flagMontoDevolverNegativo;
	}

	public void setFlagMontoDevolverNegativo(String flagMontoDevolverNegativo) {
		this.flagMontoDevolverNegativo = flagMontoDevolverNegativo;
	}

	public String getFlagPlanViajeConceptoTotal() {
		return flagPlanViajeConceptoTotal;
	}

	public void setFlagPlanViajeConceptoTotal(String flagPlanViajeConceptoTotal) {
		this.flagPlanViajeConceptoTotal = flagPlanViajeConceptoTotal;
	}

}