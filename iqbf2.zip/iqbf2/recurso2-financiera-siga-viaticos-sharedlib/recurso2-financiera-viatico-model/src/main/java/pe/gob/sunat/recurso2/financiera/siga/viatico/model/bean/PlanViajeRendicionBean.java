package pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean;

import java.io.Serializable;
import java.util.Date;

public class PlanViajeRendicionBean implements Serializable {

	private static final long serialVersionUID = -1134615332317933703L;
	private String planViajeId;
	private Integer secuencial;
	private String tipoDocumento;
	private String descripcionTipoDocumento;
	private String serie;
	private String numeroDocumento;
	private Date fechaDocumento;
	private Date fechaIngreso;
	private String fechaDocumentoFormateada;
	private String ruc;
	private String trabajador;
	private String dependencia;
	private String conceptoId;
	private Double montoDocumento;
	private Double montoIgv;
	private String montoDocumentoFormateado;
	private String presupuestoAnno;
	private String presupuestoMeta;
	private String clasificadorGasto;
	private String cuentaContable;
	private String lugarGasto;
	private String userCrea;
	private String fechCrea;
	private String userModi;
	private Date fechModi;
	private Double mtoOtrosGastos;
	private String indAfectoIgv;
	private String personaId;
	private String mtoReconocido;
	private String mtoReconocidoFormateado;
	private Double montoDeclaracion;
	private String montoDeclaracionFormateado;
	private Double montoDeclaracionViatico;
	private String montoDeclaracionViaticoFormateado;
	private String numRegistro;
	private String nombProvExt;
	private Integer factorIgv;
	private String indValido;
	private String numPeriodo;
	private Integer numSecuencial;
	private Integer codLibro;
	private String razoSociPro;
	private String nombreRazonSocial;
	private String descDocuTpd;
	private String moneda;
	private Double valorVenta;
	private String anio;
	private Double montoTotal;
	private String montoTotalFormateado;
	private int numeroDeclaracionViatico;
	private String flagDeclaracion;
	private String flagRendicionTotal;
	private String nombreConceptoGasto;
	private Double montoRendicion;

	public String getPlanViajeId() {
		return planViajeId;
	}

	public void setPlanViajeId(String planViajeId) {
		this.planViajeId = planViajeId;
	}

	public Integer getSecuencial() {
		return secuencial;
	}

	public void setSecuencial(Integer secuencial) {
		this.secuencial = secuencial;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getDescripcionTipoDocumento() {
		return descripcionTipoDocumento;
	}

	public void setDescripcionTipoDocumento(String descripcionTipoDocumento) {
		this.descripcionTipoDocumento = descripcionTipoDocumento;
	}

	public String getSerie() {
		return serie;
	}

	public void setSerie(String serie) {
		this.serie = serie;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public Date getFechaDocumento() {
		return fechaDocumento;
	}

	public void setFechaDocumento(Date fechaDocumento) {
		this.fechaDocumento = fechaDocumento;
	}

	public Date getFechaIngreso() {
		return fechaIngreso;
	}

	public void setFechaIngreso(Date fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}

	public String getFechaDocumentoFormateada() {
		return fechaDocumentoFormateada;
	}

	public void setFechaDocumentoFormateada(String fechaDocumentoFormateada) {
		this.fechaDocumentoFormateada = fechaDocumentoFormateada;
	}

	public String getRuc() {
		return ruc;
	}

	public void setRuc(String ruc) {
		this.ruc = ruc;
	}

	public String getTrabajador() {
		return trabajador;
	}

	public void setTrabajador(String trabajador) {
		this.trabajador = trabajador;
	}

	public String getDependencia() {
		return dependencia;
	}

	public void setDependencia(String dependencia) {
		this.dependencia = dependencia;
	}

	public String getConceptoId() {
		return conceptoId;
	}

	public void setConceptoId(String conceptoId) {
		this.conceptoId = conceptoId;
	}

	public Double getMontoDocumento() {
		return montoDocumento;
	}

	public void setMontoDocumento(Double montoDocumento) {
		this.montoDocumento = montoDocumento;
	}

	public Double getMontoIgv() {
		return montoIgv;
	}

	public void setMontoIgv(Double montoIgv) {
		this.montoIgv = montoIgv;
	}

	public String getMontoDocumentoFormateado() {
		return montoDocumentoFormateado;
	}

	public void setMontoDocumentoFormateado(String montoDocumentoFormateado) {
		this.montoDocumentoFormateado = montoDocumentoFormateado;
	}

	public String getPresupuestoAnno() {
		return presupuestoAnno;
	}

	public void setPresupuestoAnno(String presupuestoAnno) {
		this.presupuestoAnno = presupuestoAnno;
	}

	public String getPresupuestoMeta() {
		return presupuestoMeta;
	}

	public void setPresupuestoMeta(String presupuestoMeta) {
		this.presupuestoMeta = presupuestoMeta;
	}

	public String getClasificadorGasto() {
		return clasificadorGasto;
	}

	public void setClasificadorGasto(String clasificadorGasto) {
		this.clasificadorGasto = clasificadorGasto;
	}

	public String getCuentaContable() {
		return cuentaContable;
	}

	public void setCuentaContable(String cuentaContable) {
		this.cuentaContable = cuentaContable;
	}

	public String getLugarGasto() {
		return lugarGasto;
	}

	public void setLugarGasto(String lugarGasto) {
		this.lugarGasto = lugarGasto;
	}

	public String getUserCrea() {
		return userCrea;
	}

	public void setUserCrea(String userCrea) {
		this.userCrea = userCrea;
	}

	public String getFechCrea() {
		return fechCrea;
	}

	public void setFechCrea(String fechCrea) {
		this.fechCrea = fechCrea;
	}

	public String getUserModi() {
		return userModi;
	}

	public void setUserModi(String userModi) {
		this.userModi = userModi;
	}

	public Date getFechModi() {
		return fechModi;
	}

	public void setFechModi(Date fechModi) {
		this.fechModi = fechModi;
	}

	public Double getMtoOtrosGastos() {
		return mtoOtrosGastos;
	}

	public void setMtoOtrosGastos(Double mtoOtrosGastos) {
		this.mtoOtrosGastos = mtoOtrosGastos;
	}

	public String getIndAfectoIgv() {
		return indAfectoIgv;
	}

	public void setIndAfectoIgv(String indAfectoIgv) {
		this.indAfectoIgv = indAfectoIgv;
	}

	public String getPersonaId() {
		return personaId;
	}

	public void setPersonaId(String personaId) {
		this.personaId = personaId;
	}

	public String getMtoReconocido() {
		return mtoReconocido;
	}

	public void setMtoReconocido(String mtoReconocido) {
		this.mtoReconocido = mtoReconocido;
	}

	public String getMtoReconocidoFormateado() {
		return mtoReconocidoFormateado;
	}

	public void setMtoReconocidoFormateado(String mtoReconocidoFormateado) {
		this.mtoReconocidoFormateado = mtoReconocidoFormateado;
	}

	public Double getMontoDeclaracion() {
		return montoDeclaracion;
	}

	public void setMontoDeclaracion(Double montoDeclaracion) {
		this.montoDeclaracion = montoDeclaracion;
	}

	public String getMontoDeclaracionFormateado() {
		return montoDeclaracionFormateado;
	}

	public void setMontoDeclaracionFormateado(String montoDeclaracionFormateado) {
		this.montoDeclaracionFormateado = montoDeclaracionFormateado;
	}

	public Double getMontoDeclaracionViatico() {
		return montoDeclaracionViatico;
	}

	public void setMontoDeclaracionViatico(Double montoDeclaracionViatico) {
		this.montoDeclaracionViatico = montoDeclaracionViatico;
	}

	public String getMontoDeclaracionViaticoFormateado() {
		return montoDeclaracionViaticoFormateado;
	}

	public void setMontoDeclaracionViaticoFormateado(
			String montoDeclaracionViaticoFormateado) {
		this.montoDeclaracionViaticoFormateado = montoDeclaracionViaticoFormateado;
	}

	public String getNumRegistro() {
		return numRegistro;
	}

	public void setNumRegistro(String numRegistro) {
		this.numRegistro = numRegistro;
	}

	public String getNombProvExt() {
		return nombProvExt;
	}

	public void setNombProvExt(String nombProvExt) {
		this.nombProvExt = nombProvExt;
	}

	public Integer getFactorIgv() {
		return factorIgv;
	}

	public void setFactorIgv(Integer factorIgv) {
		this.factorIgv = factorIgv;
	}

	public String getIndValido() {
		return indValido;
	}

	public void setIndValido(String indValido) {
		this.indValido = indValido;
	}

	public String getNumPeriodo() {
		return numPeriodo;
	}

	public void setNumPeriodo(String numPeriodo) {
		this.numPeriodo = numPeriodo;
	}

	public Integer getNumSecuencial() {
		return numSecuencial;
	}

	public void setNumSecuencial(Integer numSecuencial) {
		this.numSecuencial = numSecuencial;
	}

	public Integer getCodLibro() {
		return codLibro;
	}

	public void setCodLibro(Integer codLibro) {
		this.codLibro = codLibro;
	}

	public String getRazoSociPro() {
		return razoSociPro;
	}

	public void setRazoSociPro(String razoSociPro) {
		this.razoSociPro = razoSociPro;
	}

	public String getNombreRazonSocial() {
		return nombreRazonSocial;
	}

	public void setNombreRazonSocial(String nombreRazonSocial) {
		this.nombreRazonSocial = nombreRazonSocial;
	}

	public String getDescDocuTpd() {
		return descDocuTpd;
	}

	public void setDescDocuTpd(String descDocuTpd) {
		this.descDocuTpd = descDocuTpd;
	}

	public String getMoneda() {
		return moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public Double getValorVenta() {
		return valorVenta;
	}

	public void setValorVenta(Double valorVenta) {
		this.valorVenta = valorVenta;
	}

	public String getAnio() {
		return anio;
	}

	public void setAnio(String anio) {
		this.anio = anio;
	}

	public Double getMontoTotal() {
		return montoTotal;
	}

	public void setMontoTotal(Double montoTotal) {
		this.montoTotal = montoTotal;
	}

	public String getMontoTotalFormateado() {
		return montoTotalFormateado;
	}

	public void setMontoTotalFormateado(String montoTotalFormateado) {
		this.montoTotalFormateado = montoTotalFormateado;
	}

	public int getNumeroDeclaracionViatico() {
		return numeroDeclaracionViatico;
	}

	public void setNumeroDeclaracionViatico(int numeroDeclaracionViatico) {
		this.numeroDeclaracionViatico = numeroDeclaracionViatico;
	}

	public String getFlagDeclaracion() {
		return flagDeclaracion;
	}

	public void setFlagDeclaracion(String flagDeclaracion) {
		this.flagDeclaracion = flagDeclaracion;
	}

	public String getFlagRendicionTotal() {
		return flagRendicionTotal;
	}

	public void setFlagRendicionTotal(String flagRendicionTotal) {
		this.flagRendicionTotal = flagRendicionTotal;
	}

	public String getNombreConceptoGasto() {
		return nombreConceptoGasto;
	}

	public void setNombreConceptoGasto(String nombreConceptoGasto) {
		this.nombreConceptoGasto = nombreConceptoGasto;
	}

	public Double getMontoRendicion() {
		return montoRendicion;
	}

	public void setMontoRendicion(Double montoRendicion) {
		this.montoRendicion = montoRendicion;
	}

}
