package pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean;

import java.io.Serializable;

public class MetasBean implements Serializable {

	private static final long serialVersionUID = 7281404914136497098L;
	private String secuFuncSfu;
	private String codiDepeTde;
	private String anioEjecucion;
	private String codiProyPry;
	private String descProyPry; // Descripcion de la Actividad
	private String codiProdPrd;
	private String codiLargPrd;
	private String descProdPrd; // Descripcion del Producto
	private String codiMetaMet;
	private String codiLargMet;
	private String descLargMet; // Descripcion de la Meta
	private String indicadorMetaUUOO; // indicador por default

	public String getSecuFuncSfu() {
		return secuFuncSfu;
	}

	public void setSecuFuncSfu(String secuFuncSfu) {
		this.secuFuncSfu = secuFuncSfu;
	}

	public String getCodiDepeTde() {
		return codiDepeTde;
	}

	public void setCodiDepeTde(String codiDepeTde) {
		this.codiDepeTde = codiDepeTde;
	}

	public String getAnioEjecucion() {
		return anioEjecucion;
	}

	public void setAnioEjecucion(String anioEjecucion) {
		this.anioEjecucion = anioEjecucion;
	}

	public String getCodiProyPry() {
		return codiProyPry;
	}

	public void setCodiProyPry(String codiProyPry) {
		this.codiProyPry = codiProyPry;
	}

	public String getDescProyPry() {
		return descProyPry;
	}

	public void setDescProyPry(String descProyPry) {
		this.descProyPry = descProyPry;
	}

	public String getCodiProdPrd() {
		return codiProdPrd;
	}

	public void setCodiProdPrd(String codiProdPrd) {
		this.codiProdPrd = codiProdPrd;
	}

	public String getCodiLargPrd() {
		return codiLargPrd;
	}

	public void setCodiLargPrd(String codiLargPrd) {
		this.codiLargPrd = codiLargPrd;
	}

	public String getDescProdPrd() {
		return descProdPrd;
	}

	public void setDescProdPrd(String descProdPrd) {
		this.descProdPrd = descProdPrd;
	}

	public String getCodiMetaMet() {
		return codiMetaMet;
	}

	public void setCodiMetaMet(String codiMetaMet) {
		this.codiMetaMet = codiMetaMet;
	}

	public String getCodiLargMet() {
		return codiLargMet;
	}

	public void setCodiLargMet(String codiLargMet) {
		this.codiLargMet = codiLargMet;
	}

	public String getDescLargMet() {
		return descLargMet;
	}

	public void setDescLargMet(String descLargMet) {
		this.descLargMet = descLargMet;
	}

	public String getIndicadorMetaUUOO() {
		return indicadorMetaUUOO;
	}

	public void setIndicadorMetaUUOO(String indicadorMetaUUOO) {
		this.indicadorMetaUUOO = indicadorMetaUUOO;
	}

}