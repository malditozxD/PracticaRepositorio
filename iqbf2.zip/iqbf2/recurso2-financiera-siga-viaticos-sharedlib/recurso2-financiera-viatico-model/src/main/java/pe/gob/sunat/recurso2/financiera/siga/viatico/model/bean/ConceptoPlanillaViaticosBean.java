package pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean;

import java.io.Serializable;

public class ConceptoPlanillaViaticosBean implements Serializable {

	private static final long serialVersionUID = 8447752985157252189L;

   	private String codigoConcepto;			// CODI_CONC_PVI
	private String descripcionConcepto;		// DESC_CONC_PVI
	private String clasificadorGasto;		// CLAS_GAST_GAS
	private Double conceptoCantidadPVI;		// CONC_CANT_PVI
	private String tipoFijoPVI;				// TIPO_FIJ_PVI
	private String indItinerario;			// IND_ITINERARIO
	private String indTipo;			// IND_ITINERARIO
	
	// otros campos
	private String idPlanViaje;
	private Long monto;
	private Double importeDiario;

	public String getCodigoConcepto() {
		return codigoConcepto;
	}

	public void setCodigoConcepto(String codigoConcepto) {
		this.codigoConcepto = codigoConcepto;
	}

	public String getIdPlanViaje() {
		return idPlanViaje;
	}

	public void setIdPlanViaje(String idPlanViaje) {
		this.idPlanViaje = idPlanViaje;
	}

	public String getDescripcionConcepto() {
		return descripcionConcepto;
	}

	public void setDescripcionConcepto(String descripcionConcepto) {
		this.descripcionConcepto = descripcionConcepto;
	}

	public String getClasificadorGasto() {
		return clasificadorGasto;
	}

	public void setClasificadorGasto(String clasificadorGasto) {
		this.clasificadorGasto = clasificadorGasto;
	}

	public Long getMonto() {
		return monto;
	}

	public void setMonto(Long monto) {
		this.monto = monto;
	}

	public Double getConceptoCantidadPVI() {
		return conceptoCantidadPVI;
	}

	public void setConceptoCantidadPVI(Double conceptoCantidadPVI) {
		this.conceptoCantidadPVI = conceptoCantidadPVI;
	}

	public Double getImporteDiario() {
		return importeDiario;
	}

	public void setImporteDiario(Double importeDiario) {
		this.importeDiario = importeDiario;
	}

	public String getTipoFijoPVI() {
		return tipoFijoPVI;
	}

	public void setTipoFijoPVI(String tipoFijoPVI) {
		this.tipoFijoPVI = tipoFijoPVI;
	}

	public void setIndItinerario(String indItinerario) {
		this.indItinerario = indItinerario;
	}

	public String getIndItinerario() {
		return indItinerario;
	}

	public void setIndTipo(String indTipo) {
		this.indTipo = indTipo;
	}

	public String getIndTipo() {
		return indTipo;
	}

}
