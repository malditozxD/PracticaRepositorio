package pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean;

import java.io.Serializable;
import java.util.Date;

public class TipoCambioBean implements Serializable {

	private static final long serialVersionUID = 6842360997162271417L;

	private Date fechaCambioTipo; // FECH_CAMB_TIP
	private String simboloMoneda; // SIMB_MONE_MON
	private Double valorDolarTipo; // VALO_DOLA_TIP
	private Double valorSolesTipo; // VALO_SOLE_TIP
	private Double solesCompTipo; // SOLE_COMP_TIP

	public Date getFechaCambioTipo() {
		return fechaCambioTipo;
	}

	public void setFechaCambioTipo(Date fechaCambioTipo) {
		this.fechaCambioTipo = fechaCambioTipo;
	}

	public String getSimboloMoneda() {
		return simboloMoneda;
	}

	public void setSimboloMoneda(String simboloMoneda) {
		this.simboloMoneda = simboloMoneda;
	}

	public Double getValorDolarTipo() {
		return valorDolarTipo;
	}

	public void setValorDolarTipo(Double valorDolarTipo) {
		this.valorDolarTipo = valorDolarTipo;
	}

	public Double getValorSolesTipo() {
		return valorSolesTipo;
	}

	public void setValorSolesTipo(Double valorSolesTipo) {
		this.valorSolesTipo = valorSolesTipo;
	}

	public Double getSolesCompTipo() {
		return solesCompTipo;
	}

	public void setSolesCompTipo(Double solesCompTipo) {
		this.solesCompTipo = solesCompTipo;
	}

}