package pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean;

import java.io.Serializable;

public class ClaveValorBean implements Serializable {

	private static final long serialVersionUID = -5374561413714111235L;

	private String codigo;			// value del combo
	private String descripcion;		// descripcion del combo
	private String dataJSON;		// datos adicionales

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getDataJSON() {
		return dataJSON;
	}

	public void setDataJSON(String dataJSON) {
		this.dataJSON = dataJSON;
	}

}
