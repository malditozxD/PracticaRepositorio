package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.ibatis;

import java.util.HashMap;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.SysGlobalParametrosBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.SysGlobalParametrosDAO;


/**
 * Interfaz SqlMapSysGlobalParametrosDAOImpl.
 * 
 * @author Samuel Dionisio
 */
public class SqlMapSysGlobalParametrosDAOImpl extends SqlMapClientDaoSupport implements SysGlobalParametrosDAO {

	/**
	 * Metodo que permite obtener el IGV actual.
	 * 
	 * @author Samuel Dionisio
	 * @see SysGlobalParametrosBean
	 * @return obtiene el IGV actual.
	 * @throws DataAccessException
	 */
	@Override
	public SysGlobalParametrosBean obtenerIgv() throws DataAccessException {
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("nomVariPar", "n_val_igv");
		SysGlobalParametrosBean sysGlobalParametro =  (SysGlobalParametrosBean)getSqlMapClientTemplate().queryForObject("sysGlobalParametros.obtenerIgv", param);
		return sysGlobalParametro;
	}

}
