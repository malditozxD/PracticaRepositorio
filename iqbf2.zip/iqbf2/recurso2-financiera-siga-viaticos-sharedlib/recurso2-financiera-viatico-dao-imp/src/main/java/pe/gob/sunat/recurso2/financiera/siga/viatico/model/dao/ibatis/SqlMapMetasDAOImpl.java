package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.ibatis;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.MetasBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.MetasDAO;


/**
 * Clase SqlMapMetasDAOImpl.
 * 
 * @author Juan Saccatoma 
 */
@SuppressWarnings("unchecked")
public class SqlMapMetasDAOImpl extends SqlMapClientDaoSupport implements MetasDAO {
	
	/**
	 * Metodo que permite obtener metas.
	 * 
	 * @author Juan Saccatoma
	 * @see MetasBean
	 * @param secuFuncSfu secuFuncSfu
	 * @param codigoDependencia codigo de dependencia
	 * @param anioEjecucion anio de ejecucion
	 * @param ordenarPor campo por el cual ordenar
	 * @return lista de metas
	 * @throws DataAccessException
	 */
	@Override
	public List<MetasBean> obtenerMetas(String secuFuncSfu, String codigoDependencia, String anioEjecucion, String ordenarPor) throws DataAccessException {

		Map<String, Object> parmSearch = new HashMap<String, Object>();

		parmSearch.put("secuFuncSfu", secuFuncSfu);
		parmSearch.put("codiDepeTde", codigoDependencia);
		parmSearch.put("anioEjecucion", anioEjecucion);
		parmSearch.put("ordenarPor", StringUtils.trimToNull(ordenarPor)); // pone a null sino le envian nada

		List<MetasBean> listaMetas = (List<MetasBean>) getSqlMapClientTemplate().queryForList("metas.obtenerMetasBySecuFuncCodDependencia", parmSearch);

		return listaMetas;
	}

}
