package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.ibatis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeInformeDistribBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeInformeDistribDAO;

/**
 * Clase SqlMapPlanViajeInformeDistribDAOImpl.
 * 
 * @author Samuel Dionisio
 */
public class SqlMapPlanViajeInformeDistribDAOImpl extends SqlMapClientDaoSupport implements PlanViajeInformeDistribDAO {

	
	
	/**
	 * Metodo que permite obtener el documento sustentatorio.
	 * @author Samuel Dionisio.
	 * @param  planViajeId : String.
	 * @param  secuencial : String.
	 * @return Listado de plan viaje de informe distribucion.
	 * @see    PlanViajeInformeDistribBean
	 * @throws DataAccessException
	 */
	
	@SuppressWarnings("unchecked")
	@Override
	public List<PlanViajeInformeDistribBean> obtenerListaPlanViajeInformeDistrib(String planViajeId, String secuencial) throws DataAccessException {

		Map<String, Object> param =  new HashMap<String, Object>();
		param.put("planViajeId", planViajeId);
		param.put("secuencial", secuencial);
		List<PlanViajeInformeDistribBean> listaPlanViajeInformeDistrib = (List<PlanViajeInformeDistribBean>) getSqlMapClientTemplate().queryForList("planViajeInformeDistrib.listaPlanViajeInformeDistrib", param);
				
		return listaPlanViajeInformeDistrib;
	}
	/**
	 * Metodo que permite obtener el documento sustentatorio por concepto.
	 * @author Samuel Dionisio.
	 * @param  planViajeId : String.
	 * @param  secuencial : String.
	 * @return Listado de plan viaje de informe distribucion.
	 * @see    PlanViajeInformeDistribBean
	 * @throws DataAccessException
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<PlanViajeInformeDistribBean> obtenerListaPlanViajeInformeDistribToConcepto(String planViajeId, String codConceptoOri) throws DataAccessException {

		Map<String, Object> param =  new HashMap<String, Object>();
		param.put("planViajeId", planViajeId);
		param.put("codConceptoOri", codConceptoOri);
		List<PlanViajeInformeDistribBean> listaPlanViajeInformeDistrib = (List<PlanViajeInformeDistribBean>) getSqlMapClientTemplate().queryForList("planViajeInformeDistrib.listaPlanViajeInformeDistrib", param);
				
		return listaPlanViajeInformeDistrib;
	}
	
	/**
	 * Metodo que permite el registro de un nuevo plan viaje de informe distribucion.
	 * @author Samuel Dionisio.
	 * @param  planViajeInformeDistrib : PlanViajeInformeDistribBean.
	 * @return vacio
	 * @see    void
	 * @throws DataAccessException
	 */
	
	@Override
	public void registrarPlanViajeInformeDistrib(PlanViajeInformeDistribBean planViajeInformeDistrib)	throws DataAccessException {
		getSqlMapClientTemplate().insert("planViajeInformeDistrib.registrarPlanViajeInformeDistrib", planViajeInformeDistrib);	
	}

	/**
	 * Metodo que permite modifica el plan viaje de informe distribucion.
	 * @author Samuel Dionisio.
	 * @param  planViajeInformeDistrib : PlanViajeInformeDistribBean.
	 * @return vacio
	 * @see    void
	 * @throws DataAccessException
	 */
	
	@Override
	public void actualizarPlanViajeInformeDistrib(PlanViajeInformeDistribBean planViajeInformeDistrib) throws DataAccessException {
		getSqlMapClientTemplate().insert("planViajeInformeDistrib.actualizarPlanViajeInformeDistrib", planViajeInformeDistrib);			
	}

	/**
	 * Metodo que permite eliminar el plan viaje de informe distribucion.
	 * @author Samuel Dionisio.
	 * @param  planViajeInformeDistrib : PlanViajeInformeDistribBean.
	 * @return vacio
	 * @see    void
	 * @throws DataAccessException
	 */
	@Override
	public void eliminarPlanViajeInformeDistrib(PlanViajeInformeDistribBean planViajeInformeDistrib)throws DataAccessException {
		getSqlMapClientTemplate().delete("planViajeInformeDistrib.eliminarPlanViajeInformeDistrib", planViajeInformeDistrib);
		
	}
	
	/**
	 * Metodo que permite obtener el listado de asignacion/gasto viatico.
	 * @author Jorge Ponce.
	 * @param  planViajeId :codigo plan viaje.
	 * @param  secuencial :secuencial del comprobante de pago.
	 * @return Listado de asignacion de viatico.
	 * @see    PlanViajeInformeDistribBean
	 * @throws DataAccessException
	 */
	@SuppressWarnings("unchecked")
	public ArrayList<PlanViajeInformeDistribBean> obtenerAsignacionGastoViatico(String planViajeId, Integer secuencial) throws DataAccessException {
		
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("planViajeId", planViajeId);
		paramSearch.put("secuencial", secuencial);
		ArrayList<PlanViajeInformeDistribBean> planViajeInformeDistribList = (ArrayList<PlanViajeInformeDistribBean>) getSqlMapClientTemplate().queryForList("planViajeInformeDistrib.obtenerAsignacionGastoViatico", paramSearch);
		return planViajeInformeDistribList;
	}
	
	/**
	 * Metodo que permite obtener el listado de pasaje y tasa embarque.
	 * @author Jorge Ponce.
	 * @param  planViajeId :codigo plan viaje.
	 * @param  secuencial :secuencial del comprobante de pago.
	 * @return Listado de pasaje y tasa embarque.
	 * @see    PlanViajeInformeDistribBean
	 * @throws DataAccessException
	 */
	@SuppressWarnings("unchecked")
	public ArrayList<PlanViajeInformeDistribBean> obtenerPasajeTasaEmbarque(String planViajeId, Integer secuencial) throws DataAccessException {
		
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("planViajeId", planViajeId);
		paramSearch.put("secuencial", secuencial);
		ArrayList<PlanViajeInformeDistribBean> planViajeInformeDistribList = (ArrayList<PlanViajeInformeDistribBean>) getSqlMapClientTemplate().queryForList("planViajeInformeDistrib.obtenerPasajeTasaEmbarque", paramSearch);
		return planViajeInformeDistribList;
	}
	
	/**
	 * Metodo que permite obtener el listado de monto rendido diario.
	 * @author Jorge Ponce.
	 * @param  planViajeId :codigo plan viaje.
	 * @return Listado de monto rendido diario.
	 * @see    PlanViajeInformeDistribBean
	 * @throws DataAccessException
	 */
	@SuppressWarnings("unchecked")
	public ArrayList<PlanViajeInformeDistribBean> obtenerMontoRendidoDiario(String planViajeId) throws DataAccessException {
		
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("planViajeId", planViajeId);
		ArrayList<PlanViajeInformeDistribBean> planViajeInformeDistribList = (ArrayList<PlanViajeInformeDistribBean>) getSqlMapClientTemplate().queryForList("planViajeInformeDistrib.obtenerMontoRendidoDiario", paramSearch);
		return planViajeInformeDistribList;
	}
	
	/**
	 * Metodo que permite obtener el detalle de gasto.
	 * @author Samuel Dionisio.
	 * @param  planViajeId : codigo plan viaje.
	 * @return Listado de detalle de gasto.
	 * @see    PlanViajeInformeDistribBean
	 * @throws DataAccessException
	 */
	@Override
	@SuppressWarnings("unchecked")
	public ArrayList<PlanViajeInformeDistribBean> obtenerDetalleGastoReporte(String planViajeId, String tipoDocumento) throws DataAccessException {
		
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("planViajeId", planViajeId); 
		paramSearch.put("tipoDocumento", tipoDocumento);
		ArrayList<PlanViajeInformeDistribBean> planViajeInformeDistribList = (ArrayList<PlanViajeInformeDistribBean>) getSqlMapClientTemplate().queryForList("planViajeInformeDistrib.obtenerDetalleGastoReporte", paramSearch);
		return planViajeInformeDistribList;
	}
	
	/**
	 * Metodo que permite obtener la suma del monto rendido por fecha.
	 * @author Samuel Dionisio.
	 * @param  planViajeId : codigo plan viaje.
	 * @param  codConceptoGastoOrigen : codigo concepto gasto origen.
	 * @return Listado de la suma del monto rendido por fecha.
	 * @see    PlanViajeInformeDistribBean
	 * @throws DataAccessException
	 */
	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<PlanViajeInformeDistribBean> obtenerSumaMontoRendido(String planViajeId, String codConceptoGastoOrigen)throws DataAccessException {
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("planViajeId", planViajeId);
		paramSearch.put("codConceptoOri", codConceptoGastoOrigen);
		ArrayList<PlanViajeInformeDistribBean> planViajeInformeDistribList = (ArrayList<PlanViajeInformeDistribBean>) getSqlMapClientTemplate().queryForList("planViajeInformeDistrib.obtenerSumaMontoRendido", paramSearch);
		return planViajeInformeDistribList;
	}
	
}
