package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.ibatis;

import java.util.HashMap;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.CabeceraMovBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.CabeceraMovDAO;
/**
 * Interfaz SqlMapCabeceraMovDAOImpl.
 * 
 * @author Samuel Dionisio
 */
public class SqlMapCabeceraMovDAOImpl extends SqlMapClientDaoSupport implements CabeceraMovDAO{

	/**
	 * Metodo que permite obtener el expediente siaf y nota de compromiso.
	 * 
	 * @author Samuel Dionisio
	 * @see CabeceraMovBean
	 * @param numeroRegistroCab : String
	 * @return expediente siaf y nota de compromiso
	 * @throws DataAccessException
	 */
	@Override
	public CabeceraMovBean obtenerCabeceraMov(String numeroRegistroCab) {
		Map<String, Object> param =  new HashMap<String, Object>();
		param.put("numeroRegistroCab", numeroRegistroCab);
		CabeceraMovBean cabeceraMov = (CabeceraMovBean)getSqlMapClientTemplate().queryForObject("cabeceraMov.obtenerCabeceraMov", param);
		return cabeceraMov;
	}

	
}
