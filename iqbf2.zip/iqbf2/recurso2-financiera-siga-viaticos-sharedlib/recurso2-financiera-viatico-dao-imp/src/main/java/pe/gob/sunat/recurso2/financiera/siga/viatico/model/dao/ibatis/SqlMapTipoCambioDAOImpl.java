package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.ibatis;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.TipoCambioBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.TipoCambioDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;

/**
 * Clase SqlMapTipoCambioDAOImpl.
 * 
 * @author Juan Farro
 */
@SuppressWarnings("unchecked")
public class SqlMapTipoCambioDAOImpl extends SqlMapClientDaoSupport implements TipoCambioDAO {

	/**
	 * Metodo que permite obtener el tipo de cambio (moneda dolares a soles) con la fecha actual
	 * 
	 * @author Juan Farro
	 * @return tipo de cambio
	 * @throws DataAccessException
	 * @see TipoCambioBean
	 */
	@Override
	public TipoCambioBean obtenerTipoCambioSimboloDolaresHoy() throws DataAccessException {

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("simboloMoneda", ViaticoConstantes.MONEDA_DOLARES);

		List<TipoCambioBean> lista = (List<TipoCambioBean>) getSqlMapClientTemplate().queryForList("tipoCambio.obtenerTipoCambioSimboloDolaresHoy", params);

		if (CollectionUtils.isNotEmpty(lista)) {
			return lista.get(0);
		}

		return null;
	}

	/**
	 * Metodo que permite obtener el tipo de cambio (moneda dolares a soles) con fecha mas reciente
	 * 
	 * @author Juan Farro
	 * @return tipo de cambio
	 * @throws DataAccessException
	 * @see TipoCambioBean
	 */
	@Override
	public TipoCambioBean obtenerTipoCambioSimboloDolaresMasReciente() throws DataAccessException {

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("simboloMoneda", ViaticoConstantes.MONEDA_DOLARES);

		List<TipoCambioBean> lista = (List<TipoCambioBean>) getSqlMapClientTemplate().queryForList("tipoCambio.obtenerTipoCambioSimboloDolaresMasReciente", params);

		if (CollectionUtils.isNotEmpty(lista)) {
			return lista.get(0);
		}

		return null;
	}

}
