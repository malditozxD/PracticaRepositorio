package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.ibatis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ComprobanteIngresoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.ComprobanteIngresoDAO;

/**
 * Implementacion de la interface ComprobanteIngresoDAO, contiene los metodos para la consulta y transaccion de la tabla COMPROBANTES_INGRESO.
 * @author Jorge Ponce.
 */
public class SqlMapComprobanteIngresoDAOImpl extends SqlMapClientDaoSupport implements ComprobanteIngresoDAO {
	
	/**
	 * Metodo que permite obtener el listado de recibos de ingreso caja (RICs) asociados a un plan viaje.
	 * @author Jorge Ponce.
	 * @param  numeroRendicion :numero de rendicion/codigo plan viaje.
	 * @return Listado de recibos de ingreso caja.
	 * @see    ComprobanteIngresoBean
	 * @throws DataAccessException
	 */
	@SuppressWarnings("unchecked")
	public ArrayList<ComprobanteIngresoBean> obtenerRecibosIngresoCaja(String numeroRendicion) throws DataAccessException {
		
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("numeroRendicion", numeroRendicion);
		ArrayList<ComprobanteIngresoBean> comprobanteIngresoList = (ArrayList<ComprobanteIngresoBean>) getSqlMapClientTemplate().queryForList("comprobantesIngreso.obtenerRecibosIngresoCaja", paramSearch);
		return comprobanteIngresoList;
	}
	
}
