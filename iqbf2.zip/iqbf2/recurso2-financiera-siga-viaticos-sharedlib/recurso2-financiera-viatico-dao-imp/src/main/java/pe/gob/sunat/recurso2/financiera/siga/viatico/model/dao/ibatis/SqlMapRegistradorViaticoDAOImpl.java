package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.ibatis;

import java.util.HashMap;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.RegistradorViaticoDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;

/**
 * Clase que permite realizar operaciones sobre la tabla REGISTRADOR_MOVILIDAD
 * 
 * @author Juan Saccatoma
 */
public class SqlMapRegistradorViaticoDAOImpl extends SqlMapClientDaoSupport implements RegistradorViaticoDAO {

	/**
	 * Metodo que determinar si un colaborador es registrador
	 * 
	 * @author Juan Saccatoma
	 * @param codEmp codigo de empleado
	 * @return numero de uuoo en las que puede registrar
	 * @throws DataAccessException
	 */
	public Long determinaRegistrador(String codEmp) throws DataAccessException {

		Map<String, Object> paramSearch = new HashMap<String, Object>();
		
		paramSearch.put("codEmp", codEmp);
		paramSearch.put("indProc", ViaticoConstantes.INDICADOR_REGISTRADOR);
		
		Long resultado = (Long) getSqlMapClientTemplate().queryForObject("registradorViatico.select_registrador", paramSearch);
		
		return resultado;
	}

	/**
	 * Metodo que determinar si un colaborador es registrador universal
	 * 
	 * @author Juan Saccatoma
	 * @param codEmp codigo de empleado
	 * @return numero de uuoo en la que es registrador universal
	 * @throws DataAccessException
	 */
	public Long determinaRegistradorUniversal(String codEmp) throws DataAccessException {

		Map<String, Object> paramSearch = new HashMap<String, Object>();
		
		paramSearch.put("codEmp", codEmp);
		paramSearch.put("indProc", ViaticoConstantes.INDICADOR_REGISTRADOR_UNIVERSAL);
		
		Long resultado = (Long) getSqlMapClientTemplate().queryForObject("registradorViatico.select_registrador", paramSearch);
		
		return resultado;
	}

}
