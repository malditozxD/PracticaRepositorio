package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.ibatis;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.LicenciaBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.LicenciaDAO;

/**
 * Clase SqlMapLicenciaDAOImpl.
 * 
 * @author Juan Farro 
 */
@SuppressWarnings("unchecked")
public class SqlMapLicenciaDAOImpl extends SqlMapDAOBase implements LicenciaDAO {

	/**
	 * Metodo que permite obtener las licencias de un colaborador en un rango de fechas.
	 * 
	 * @author Juan Farro
	 * @see LicenciaBean
	 * @param params parametros de busqueda
	 * @return lista de licencias
	 * @throws DataAccessException
	 */
	@Override
	public List<LicenciaBean> listarLicencias(Map<String, Object> params) throws DataAccessException {

		List<LicenciaBean> listaLicencias = (List<LicenciaBean>) getSqlMapClientTemplate().queryForList("t1273licencia.listarLicencias", params);

		return listaLicencias;
	}

	/**
	 * Metodo que permite obtener las compensaciones de un colaborador en un rango de fechas.
	 * 
	 * @author Juan Farro
	 * @see LicenciaBean
	 * @param params parametros de busqueda
	 * @return lista de compensaciones
	 * @throws DataAccessException
	 */
	@Override
	public List<LicenciaBean> listarCompensacion(Map<String, Object> params) throws DataAccessException {

		List<LicenciaBean> listaLicencias = (List<LicenciaBean>) getSqlMapClientTemplate().queryForList("t1273licencia.listarCompensacion", params);

		return listaLicencias;
	}

}
