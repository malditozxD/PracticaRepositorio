package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.ibatis;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.RendicionConstantes;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;

/**
 * Clase PlanViajeDAO.
 * 
 * @author Juan Saccatoma
 */
@SuppressWarnings({ "unchecked" })
public class SqlMapPlanViajeDAOImpl extends SqlMapClientDaoSupport implements PlanViajeDAO { 

	/**
	 * Metodo que permite obtener la lista de solicitud de viaticos para la bandeja de rendiciones.
	 * 
	 * @author Juan Saccatoma
	 * @param parmSearch parametros de busqueda de la bandeja
	 * @return lista de solicitudes
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	@Override
	public List<PlanViajeBean> getRendicionesBandeja(Map<String, Object> parmSearch) {
		return (List<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.selectRendicionesBandeja", parmSearch);
	}

	/**
	 * Metodo que permite obtener el detalle de viaticos para la bandeja de rendiciones.
	 * 
	 * @author Juan Saccatoma
	 * @param parmSearch parametros de busqueda de la bandeja
	 * @return lista de solicitudes
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	@Override
	public List<PlanViajeBean> getRendicionDetalle(Map<String, Object> parmSearch) {
		return (List<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.selectRendicionDetalle", parmSearch);
	}

	/**
	 * Metodo que permite obtener la lista de solicitud de viaticos para la opcion de exportar en la bandeja de rendiciones.
	 * 
	 * @author Juan Saccatoma
	 * @param parmSearch parametros de busqueda de la bandeja
	 * @return lista de solicitudes
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	@Override
	public List<PlanViajeBean> getRendicionesBandejaExportar(Map<String, Object> parmSearch) {
		return (List<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.selectRendicionesBandejaExportar", parmSearch);
	}

	/**
	 * Metodo que permite obtener una solicitud de viatico.
	 * 
	 * @author Juan Saccatoma
	 * @param parmSearch parametros de busqueda
	 * @return solicitud de viatico
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	@Override
	public PlanViajeBean getSolicitud(Map<String, Object> parmSearch) {
		return (PlanViajeBean) getSqlMapClientTemplate().queryForObject("planViaje.selectSolicitudesBandeja", parmSearch);
	}

	/**
	 * Metodo que permite obtener solicitudes de viatico para la bandeja.
	 * 
	 * @author Juan Saccatoma
	 * @param parmSearch parametros de busqueda de la bandeja
	 * @return lista de solicitudes
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	@Override
	public List<PlanViajeBean> getSolicitudesBandeja(Map<String, Object> parmSearch) {
		return (List<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.selectSolicitudesBandeja", parmSearch);
	}

	/**
	 * Metodo que permite obtener solicitudes de viatico para la bandeja consulta, revision y alta (CUS10, CUS09 y CUS13).
	 * 
	 * @author Juan Saccatoma
	 * @param parmSearch parametros de busqueda de la bandeja
	 * @return lista de solicitudes
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	@Override
	public List<PlanViajeBean> getSolicitudesBandejaConsultaRevisionAlta(Map<String, Object> parmSearch) {

		List<PlanViajeBean> listaSolicitudes = (List<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.selectSolicitudesBandejaConsultaRevisionAlta", parmSearch);

		return listaSolicitudes;
	}

	
	
	/**
	 * Metodo que permite obtener solicitudes de reembolsos para la bandeja consulta, revision
	 * 
	 * @author Juan Saccatoma
	 * @param parmSearch parametros de busqueda de la bandeja
	 * @return lista de solicitudes
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	public List<PlanViajeBean> getReembolsosBandejaConsultaRevision(Map<String, Object> parmSearch)throws DataAccessException{
	List<PlanViajeBean> listaSolicitudes = (List<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.selectReembolsosBandejaConsultaRevision", parmSearch);

		return listaSolicitudes;
	}
	/**
	 * Metodo que permite obtener el detalle de una solicitud de viatico para la bandeja.
	 * 
	 * @author Juan Saccatoma
	 * @param parmSearch parametros de busqueda
	 * @return lista de solicitudes
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	@Override
	public List<PlanViajeBean> getSolicitudDetalle(Map<String, Object> parmSearch) {
		return (List<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.selectSolicitudDetalle", parmSearch);
	}

	/**
	 * Metodo que permite obtener la lista de solicitud de viaticos para la opcion de exportar en la bandeja.
	 * 
	 * @author Juan Saccatoma
	 * @param parmSearch parametros de busqueda de la bandeja
	 * @return lista de solicitudes
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	@Override
	public List<PlanViajeBean> getSolicitudesBandejaExportar(Map<String, Object> parmSearch) {
		return (List<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.selectSolicitudesBandejaConsultaRevisionAltaExportar", parmSearch);
	}

	/**
	 * Metodo que permite anular una solicitud de viatico.
	 * 
	 * @author Juan Farro
	 * @param planViajeBean solicitud de viatico
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	@Override
	public void actualizaAnulacion(PlanViajeBean planViajeBean) throws DataAccessException {
		getSqlMapClientTemplate().update("planViaje.actualizaAnulacion", planViajeBean);
	}

	/**
	 * Metodo que permite observar una solicitud de viatico.
	 * 
	 * @author Juan Farro
	 * @param planViajeBean solicitud de viatico
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	@Override
	public void actualizaObservacion(PlanViajeBean planViajeBean) throws DataAccessException {
		getSqlMapClientTemplate().update("planViaje.actualizaObservacion", planViajeBean);
	}

	/**
	 * Metodo que permite autorizar una solicitud de viatico.
	 * 
	 * @author Juan Farro
	 * @param planViajeBean solicitud de viatico
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	@Override
	public void actualizaAutorizacion(PlanViajeBean planViajeBean) throws DataAccessException {
		getSqlMapClientTemplate().update("planViaje.actualizaAutorizacion", planViajeBean);
	}

	/**
	 * Metodo que permite obtener el listado de plan de viaje que se van a mostrar en la bandeja de autorizacion de solicitud.
	 * 
	 * @author Jorge Ponce.
	 * @param codigoDependencia :codigo de dependencia.
	 * @param codPlanilla :codigo de planilla.
	 * @param codTrabajador :codigo del colaborador.
	 * @param codEstadoSolic :codigo de estado de la solicitud.
	 * @param indicadorCanalAtencion :indicador canal de atencion.
	 * @param fechaDesde :fecha desde.
	 * @param fechaHasta :fecha hasta.
	 * @param codigoAutorizador :codigo del autorizador.
	 * @return Listado de plan de viaje.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	public ArrayList<PlanViajeBean> obtenerPlanViajeToBandejaAutorizacionSolicitud(String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoSolic, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws DataAccessException {

		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("nombreTabla", ViaticoConstantes.ESTADO_VIATICO_NOMBRE_TABLA);
		paramSearch.put("codigoDependencia", codigoDependencia);
		paramSearch.put("codPlanilla", codPlanilla);
		paramSearch.put("codTrabajador", codTrabajador);
		paramSearch.put("codEstadoSolic", codEstadoSolic);
		paramSearch.put("indicadorCanalAtencion", indicadorCanalAtencion);
		paramSearch.put("fechaDesde", fechaDesde);
		paramSearch.put("fechaHasta", fechaHasta);
		paramSearch.put("codigoAutorizador", codigoAutorizador);
		ArrayList<PlanViajeBean> planViajeList = (ArrayList<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.obtenerPlanViajeToBandejaAutorizacionSolicitud", paramSearch);
		return planViajeList;
	}

	//JMCR-ME BANDEJA AUTORIZADOR se cambia el estado de la solicitud por una lista de estados  a enviar con "IN"
	public ArrayList<PlanViajeBean> obtenerPlanViajeToBandejaAutorizacionSolicitudMultiplesEstados(String codigoDependencia, String codPlanilla, String codTrabajador, List<String> listCodEstadoSolic, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws DataAccessException {

		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("nombreTabla", ViaticoConstantes.ESTADO_VIATICO_NOMBRE_TABLA);
		paramSearch.put("codigoDependencia", codigoDependencia);
		paramSearch.put("codPlanilla", codPlanilla);
		paramSearch.put("codTrabajador", codTrabajador);
		paramSearch.put("listCodEstadoSolic", listCodEstadoSolic);
		paramSearch.put("indicadorCanalAtencion", indicadorCanalAtencion);
		paramSearch.put("fechaDesde", fechaDesde);
		paramSearch.put("fechaHasta", fechaHasta);
		paramSearch.put("codigoAutorizador", codigoAutorizador);
		ArrayList<PlanViajeBean> planViajeList = (ArrayList<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.obtenerPlanViajeToBandejaAutorizacionSolicitud", paramSearch);
		return planViajeList;
	}
	
	/**
	 * Metodo que permite obtener el listado de detalle de los plan de viaje que se muestran la bandeja de solicitud.
	 * 
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @param codigoDependencia :codigo de dependencia.
	 * @param codPlanilla :codigo de planilla.
	 * @param codTrabajador :codigo del colaborador.
	 * @param codEstadoSolic :codigo de estado de la solicitud.
	 * @param indicadorCanalAtencion :indicador canal de atencion.
	 * @param fechaDesde :fecha desde.
	 * @param fechaHasta :fecha hasta.
	 * @param codigoAutorizador :codigo del autorizador.
	 * @return Listado de plan de viaje.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	public ArrayList<PlanViajeBean> obtenerPlanViajeDetalleToBandejaSolicitud(String codPlanViaje, String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoSolic, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws DataAccessException {
		
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("codPlanViaje", codPlanViaje);
		paramSearch.put("codigoDependencia", codigoDependencia);
		paramSearch.put("codPlanilla", codPlanilla);
		paramSearch.put("codTrabajador", codTrabajador);
		paramSearch.put("codEstadoSolic", codEstadoSolic);
		paramSearch.put("indicadorCanalAtencion", indicadorCanalAtencion);
		paramSearch.put("fechaDesde", fechaDesde);
		paramSearch.put("fechaHasta", fechaHasta);
		paramSearch.put("codigoAutorizador", codigoAutorizador);
		ArrayList<PlanViajeBean> planViajeList = (ArrayList<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.obtenerPlanViajeDetalleToBandejaSolicitud", paramSearch);
		return planViajeList;
	}
	
	//JMCR-ME BANDEJA AUTORIZADOR se cambia el estado de la solicitud por una lista de estados  a enviar con "IN"
	public ArrayList<PlanViajeBean> obtenerPlanViajeDetalleToBandejaSolicitudMultiplesEstados(String codPlanViaje, String codigoDependencia, String codPlanilla, String codTrabajador, List<String> listCodEstadoSolic, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws DataAccessException {
		
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("codPlanViaje", codPlanViaje);
		paramSearch.put("codigoDependencia", codigoDependencia);
		paramSearch.put("codPlanilla", codPlanilla);
		paramSearch.put("codTrabajador", codTrabajador);
		paramSearch.put("listCodEstadoSolic", listCodEstadoSolic);
		paramSearch.put("indicadorCanalAtencion", indicadorCanalAtencion);
		paramSearch.put("fechaDesde", fechaDesde);
		paramSearch.put("fechaHasta", fechaHasta);
		paramSearch.put("codigoAutorizador2", codigoAutorizador);//invocacion de SP para bandeja de autorizador
		ArrayList<PlanViajeBean> planViajeList = (ArrayList<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.obtenerPlanViajeDetalleToBandejaSolicitud", paramSearch);
		return planViajeList;
	}

	/**
	 * Metodo que permite obtener los datos de plan viaje para el envio de notificacion.
	 * 
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @return Objeto PlanViajeBean.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	public PlanViajeBean obtenerPlanViajeToNotificacion(String codPlanViaje) throws DataAccessException {

		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("codPlanViaje", codPlanViaje);
		PlanViajeBean planViajeBean = (PlanViajeBean) getSqlMapClientTemplate().queryForObject("planViaje.obtenerPlanViajeToNotificacion", paramSearch);
		return planViajeBean;
	}

	/**
	 * Metodo que permite autorizar una solicitud por un autorizador.
	 * 
	 * @author Jorge Ponce.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	public void autorizarSolicitudByAutorizador(PlanViajeBean planViajeBean) throws DataAccessException {
		getSqlMapClientTemplate().update("planViaje.autorizarSolicitudByAutorizador", planViajeBean);
	}

	/**
	 * Metodo que permite observar una solicitud por un autorizador.
	 * 
	 * @author Jorge Ponce.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	public void observarSolicitudByAutorizador(PlanViajeBean planViajeBean) throws DataAccessException {
		getSqlMapClientTemplate().update("planViaje.observarSolicitudByAutorizador", planViajeBean);
	}

	/**
	 * Metodo que permite anular una solicitud por un autorizador.
	 * 
	 * @author Jorge Ponce.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	public void anularSolicitudByAutorizador(PlanViajeBean planViajeBean) throws DataAccessException {
		getSqlMapClientTemplate().update("planViaje.anularSolicitudByAutorizador", planViajeBean);
	}

	/**
	 * Metodo que permite obtener el listado de plan de viaje que se van a mostrar en la bandeja de consulta de rendicion.
	 * 
	 * @author Jorge Ponce.
	 * @param codigoDependencia :codigo de dependencia.
	 * @param codPlanilla :codigo de planilla.
	 * @param codTrabajador :codigo del colaborador.
	 * @param codEstadoSolic :codigo de estado de la solicitud.
	 * @param codEstadoRend :codigo de estado de la rendicion.
	 * @param indicadorCanalAtencion :indicador canal de atencion.
	 * @param fechaDesde :fecha desde.
	 * @param fechaHasta :fecha hasta.
	 * @return Listado de plan de viaje.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	public ArrayList<PlanViajeBean> obtenerPlanViajeToBandejaConsultaRendicion(String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoSolic, String codEstadoRend, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta) throws DataAccessException {

		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("nombreTabla", RendicionConstantes.NOMTABLA_ESTADOS_RENDICION);
		paramSearch.put("codigoDependencia", codigoDependencia);
		paramSearch.put("codPlanilla", codPlanilla);
		paramSearch.put("codTrabajador", codTrabajador);
		paramSearch.put("codEstadoSolic", codEstadoSolic);
		paramSearch.put("codEstadoRend", codEstadoRend);
		paramSearch.put("indicadorCanalAtencion", indicadorCanalAtencion);
		paramSearch.put("fechaDesde", fechaDesde);
		paramSearch.put("fechaHasta", fechaHasta);
		ArrayList<PlanViajeBean> planViajeList = (ArrayList<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.obtenerPlanViajeToBandejaConsultaRendicion", paramSearch);
		return planViajeList;
	}

	/**
	 * Metodo que permite obtener el listado de detalle de los plan de viaje que se muestran la bandeja de consulta de rendicion.
	 * 
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @param codigoDependencia :codigo de dependencia.
	 * @param codPlanilla :codigo de planilla.
	 * @param codTrabajador :codigo del colaborador.
	 * @param codEstadoSolic :codigo de estado de la solicitud.
	 * @param codEstadoRend :codigo de estado de la rendicion.
	 * @param indicadorCanalAtencion :indicador canal de atencion.
	 * @param fechaDesde :fecha desde.
	 * @param fechaHasta :fecha hasta.
	 * @return Listado de plan de viaje.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	public ArrayList<PlanViajeBean> obtenerPlanViajeDetalleToBandejaConsultaRendicion(String codPlanViaje, String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoSolic, String codEstadoRend, String indicadorCanalAtencion, Date fechaDesde, Date fechaHasta) throws DataAccessException {
		
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("codPlanViaje", codPlanViaje);
		paramSearch.put("codigoDependencia", codigoDependencia);
		paramSearch.put("codPlanilla", codPlanilla);
		paramSearch.put("codTrabajador", codTrabajador);
		paramSearch.put("codEstadoSolic", codEstadoSolic);
		paramSearch.put("codEstadoRend", codEstadoRend);
		paramSearch.put("indicadorCanalAtencion", indicadorCanalAtencion);
		paramSearch.put("fechaDesde", fechaDesde);
		paramSearch.put("fechaHasta", fechaHasta);
		ArrayList<PlanViajeBean> planViajeList = (ArrayList<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.obtenerPlanViajeDetalleToBandejaConsultaRendicion", paramSearch);
		return planViajeList;
	}

	/**
	 * Metodo que permite obtener los datos para realizar una rendicion del plan viaje.
	 * 
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @return Objeto PlanViajeBean.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	public PlanViajeBean obtenerPlanViajeToRendicion(String codPlanViaje) throws DataAccessException {
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("codPlanViaje", codPlanViaje);
		paramSearch.put("nombreTabla", RendicionConstantes.NOMTABLA_ESTADOS_RENDICION);
		PlanViajeBean planViajeBean = (PlanViajeBean) getSqlMapClientTemplate().queryForObject("planViaje.obtenerPlanViajeToRendicion", paramSearch);
		return planViajeBean;
	}

	/**
	 * Metodo que permite obtener los numeros de expedientes del plan viaje.
	 * 
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @return Objeto PlanViajeBean.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	public PlanViajeBean obtenerNumeroExpediente(String codPlanViaje) throws DataAccessException {
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("codPlanViaje", codPlanViaje);
		PlanViajeBean planViajeBean = (PlanViajeBean) getSqlMapClientTemplate().queryForObject("planViaje.obtenerNumeroExpediente", paramSearch);
		return planViajeBean;
	}

	/**
	 * Metodo que permite obtener el numero de registro archivo del plan viaje.
	 * 
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @return Numero de registro archivo.
	 * @see String
	 * @throws DataAccessException
	 */
	public String obtenerNumeroRegistroArchivo(String codPlanViaje) throws DataAccessException {
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("codPlanViaje", codPlanViaje);
		String numeroRegistroArchivo = (String) getSqlMapClientTemplate().queryForObject("planViaje.obtenerNumeroRegistroArchivo", paramSearch);
		if (numeroRegistroArchivo == null) {
			numeroRegistroArchivo = ViaticoConstantes.CADENA_VACIA;
		}
		return numeroRegistroArchivo;
	}

	/**
	 * Metodo que permite obtener los monstos devueltos de una rendicion del plan viaje.
	 * 
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @return Objeto PlanViajeBean.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	public PlanViajeBean obtenerMontoDevueltoToRegistroRendicion(String codPlanViaje) throws DataAccessException {
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("codPlanViaje", codPlanViaje);
		PlanViajeBean planViajeBean = (PlanViajeBean) getSqlMapClientTemplate().queryForObject("planViaje.obtenerMontoDevueltoToRegistroRendicion", paramSearch);
		return planViajeBean;
	}

	/**
	 * Metodo que permite actualizar plan viaje cuando se registra la rendicion.
	 * 
	 * @author Jorge Ponce.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	public void actualizarPlanViajeToRegistroRendicion(PlanViajeBean planViajeBean) throws DataAccessException {
		getSqlMapClientTemplate().update("planViaje.actualizarPlanViajeToRegistroRendicion", planViajeBean);
	}

	/**
	 * Metodo que permite actualizar plan viaje cuando se cierra la rendicion.
	 * 
	 * @author Jorge Ponce.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	public void actualizarPlanViajeToCerrarRendicion(PlanViajeBean planViajeBean) throws DataAccessException {
		getSqlMapClientTemplate().update("planViaje.actualizarPlanViajeToCerrarRendicion", planViajeBean);
	}

	/**
	 * Metodo que permite actualizar el numero de expediente para el registro de rendicion.
	 * 
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @param expedienteRendicion :numero de expediente.
	 * @throws DataAccessException
	 */
	public void actualizarNumeroExpedienteToRegistroRendicion(String codPlanViaje, String expedienteRendicion) throws DataAccessException {
		Map<String, Object> paramUpdate = new HashMap<String, Object>();
		paramUpdate.put("codPlanViaje", codPlanViaje);
		paramUpdate.put("expedienteRendicion", expedienteRendicion);
		getSqlMapClientTemplate().update("planViaje.actualizarNumeroExpedienteToRegistroRendicion", paramUpdate);
	}

	/**
	 * Metodo que permite anular el envio de una solicitud.
	 * 
	 * @author Jorge Ponce.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	public void anularEnvioPlanViaje(PlanViajeBean planViajeBean) throws DataAccessException {
		getSqlMapClientTemplate().update("planViaje.anularEnvioPlanViaje", planViajeBean);
	}

	/**
	 * Metodo que permite reprogramar la fecha de rendicion.
	 * 
	 * @author Jorge Ponce.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	public void reprogramarFechaRendicion(PlanViajeBean planViajeBean) throws DataAccessException {
		getSqlMapClientTemplate().update("planViaje.reprogramarFechaRendicion", planViajeBean);
	}

	/**
	 * Metodo que permite obtener el listado de plan de viaje que se van a mostrar en la bandeja de notificacion de rendicion.
	 * 
	 * @author Jorge Ponce.
	 * @param codigoDependencia :codigo de dependencia.
	 * @param indicadorCanalAtencion :indicador canal de atencion.
	 * @param fechaHasta :fecha hasta.
	 * @return Listado de plan de viaje.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	public ArrayList<PlanViajeBean> obtenerPlanViajeToBandejaNotificacionRendicion(String codigoDependencia, String indicadorCanalAtencion, 
			Date fechaHasta, Integer diasHabilesSegundaNotificacion) throws DataAccessException {

		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("codigoDependencia", codigoDependencia);
		paramSearch.put("indicadorCanalAtencion", indicadorCanalAtencion);
		paramSearch.put("fechaHasta", fechaHasta);
		paramSearch.put("diasHabilesSegundaNotificacion", diasHabilesSegundaNotificacion);
		ArrayList<PlanViajeBean> planViajeList = (ArrayList<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.obtenerPlanViajeToBandejaNotificacionRendicion", paramSearch);
		return planViajeList;
	}

	/**
	 * Metodo que permite enviar la segunda notificacion a una rendicion.
	 * 
	 * @author Jorge Ponce.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	public void enviarSegundaNotificacionRendicion(PlanViajeBean planViajeBean) throws DataAccessException {
		getSqlMapClientTemplate().update("planViaje.enviarSegundaNotificacionRendicion", planViajeBean);
	}

	/**
	 * Metodo que permite obtener los datos para realizar el sustento de gasto del plan viaje.
	 * 
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @return Objeto PlanViajeBean.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	public PlanViajeBean obtenerPlanViajeToSustentoGastoReembolso(String codPlanViaje) throws DataAccessException {
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("codPlanViaje", codPlanViaje);
		paramSearch.put("nombreTabla", ViaticoConstantes.ESTADO_REEMBOLSO_NOMBRE_TABLA);
		PlanViajeBean planViajeBean = (PlanViajeBean) getSqlMapClientTemplate().queryForObject("planViaje.obtenerPlanViajeToSustentoGastoReembolso", paramSearch);
		return planViajeBean;
	}

	/**
	 * Metodo que permite actualizar plan viaje cuando se registra el sustento gasto de reembolso.
	 * 
	 * @author Jorge Ponce.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	public void actualizarPlanViajeToSustentoGastoReembolso(PlanViajeBean planViajeBean) throws DataAccessException {
		getSqlMapClientTemplate().update("planViaje.actualizarPlanViajeToSustentoGastoReembolso", planViajeBean);
	}

	/**
	 * Metodo que permite obtener el listado de plan de viaje que se van a mostrar en la bandeja de autorizacion de reembolso.
	 * 
	 * @author Jorge Ponce.
	 * @param codigoDependencia :codigo de dependencia.
	 * @param codPlanilla :codigo de planilla.
	 * @param codTrabajador :codigo del colaborador.
	 * @param codEstadoSolic :codigo de estado de la solicitud.
	 * @param fechaDesde :fecha desde.
	 * @param fechaHasta :fecha hasta.
	 * @param codigoAutorizador :codigo del autorizador.
	 * @return Listado de plan de viaje.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	public ArrayList<PlanViajeBean> obtenerPlanViajeToBandejaAutorizacionReembolso(String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoSolic, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws DataAccessException {

		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("nombreTabla", ViaticoConstantes.ESTADO_REEMBOLSO_NOMBRE_TABLA);
		paramSearch.put("codigoDependencia", codigoDependencia);
		paramSearch.put("codPlanilla", codPlanilla);
		paramSearch.put("codTrabajador", codTrabajador);
		paramSearch.put("codEstadoSolic", codEstadoSolic);
		paramSearch.put("fechaDesde", fechaDesde);
		paramSearch.put("fechaHasta", fechaHasta);
		paramSearch.put("codigoAutorizador", codigoAutorizador);
		ArrayList<PlanViajeBean> planViajeList = (ArrayList<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.obtenerPlanViajeToBandejaAutorizacionReembolso", paramSearch);
		return planViajeList;
	}

	/**
	 * Metodo que permite autorizar un reembolso por un autorizador.
	 * 
	 * @author Jorge Ponce.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	public void autorizarReembolsoByAutorizador(PlanViajeBean planViajeBean) throws DataAccessException {
		getSqlMapClientTemplate().update("planViaje.autorizarReembolsoByAutorizador", planViajeBean);
	}

	/**
	 * Metodo que permite observar un reembolso por un autorizador.
	 * 
	 * @author Jorge Ponce.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	public void observarReembolsoByAutorizador(PlanViajeBean planViajeBean) throws DataAccessException {
		getSqlMapClientTemplate().update("planViaje.observarReembolsoByAutorizador", planViajeBean);
	}

	/**
	 * Metodo que permite anular un reembolso por un autorizador.
	 * 
	 * @author Jorge Ponce.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	public void anularReembolsoByAutorizador(PlanViajeBean planViajeBean) throws DataAccessException {
		getSqlMapClientTemplate().update("planViaje.anularReembolsoByAutorizador", planViajeBean);
	}

	/**
	 * Metodo que permite obtener el listado de detalle de los plan de viaje que se muestran la bandeja de reembolso.
	 * 
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @param codigoDependencia :codigo de dependencia.
	 * @param codPlanilla :codigo de planilla.
	 * @param codTrabajador :codigo del colaborador.
	 * @param codEstadoSolic :codigo de estado de la solicitud.
	 * @param fechaDesde :fecha desde.
	 * @param fechaHasta :fecha hasta.
	 * @param codigoAutorizador :codigo del autorizador.
	 * @return Listado de plan de viaje.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	public ArrayList<PlanViajeBean> obtenerPlanViajeDetalleToBandejaReembolso(String codPlanViaje, String codigoDependencia, String codPlanilla, String codTrabajador, String codEstadoSolic, Date fechaDesde, Date fechaHasta, String codigoAutorizador) throws DataAccessException {
		
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("codPlanViaje", codPlanViaje);
		paramSearch.put("codigoDependencia", codigoDependencia);
		paramSearch.put("codPlanilla", codPlanilla);
		paramSearch.put("codTrabajador", codTrabajador);
		paramSearch.put("codEstadoSolic", codEstadoSolic);
		paramSearch.put("fechaDesde", fechaDesde);
		paramSearch.put("fechaHasta", fechaHasta);
		paramSearch.put("codigoAutorizador", codigoAutorizador);
		ArrayList<PlanViajeBean> planViajeList = (ArrayList<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.obtenerPlanViajeDetalleToBandejaReembolso", paramSearch);
		return planViajeList;
	}

	/**
	 * Metodo que permite obtener los datos de plan de viaje para el seguimiento.
	 * 
	 * @author Jorge Ponce.
	 * @param codPlanViaje :codigo plan viaje.
	 * @return Plan de viaje.
	 * @see PlanViajeBean
	 * @throws DataAccessException
	 */
	public PlanViajeBean obtenerPlanViajeToSeguimiento(String codPlanViaje) throws DataAccessException {
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("codPlanViaje", codPlanViaje);
		PlanViajeBean planViajeBean = (PlanViajeBean) getSqlMapClientTemplate().queryForObject("planViaje.obtenerPlanViajeToSeguimiento", paramSearch);
		return planViajeBean;
	}

	/**
	 * Metodo que permite registrar plan de viaje.
	 * 
	 * @author Juan Farro
	 * @param planViajeBean solicitud de viatico
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	@Override
	public void registrarPlanViaje(PlanViajeBean planViajeBean) throws DataAccessException {
		getSqlMapClientTemplate().insert("planViaje.registrarPlanViaje", planViajeBean);
	}

	/**
	 * Metodo que permite actualizar plan de viaje.
	 * 
	 * @author Juan Farro
	 * @param planViajeBean solicitud de viatico
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	@Override
	public void actualizarPlanViaje(PlanViajeBean planViajeBean) throws DataAccessException {
		getSqlMapClientTemplate().update("planViaje.actualizarPlanViaje", planViajeBean);
	}

	/**
	 * Metodo que permite actualizar plan de viaje (para la modificacion de solicitud de viatico).
	 * 
	 * @author Juan Farro
	 * @param planViajeBean solicitud de viatico
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	@Override
	public void actualizarPlanViajeToModificar(PlanViajeBean planViajeBean) throws DataAccessException {
		getSqlMapClientTemplate().update("planViaje.actualizarPlanViajeToModificar", planViajeBean);
	}

	/**
	 * Metodo que permite actualizar plan de viaje (para la modificacion de solicitud de reembolso).
	 * 
	 * @author Juan Farro
	 * @param planViajeBean solicitud de viatico/reembolso
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	@Override
	public void actualizarPlanViajeToModificarReembolso(PlanViajeBean planViajeBean) throws DataAccessException {
		getSqlMapClientTemplate().update("planViaje.actualizarPlanViajeToModificarReembolso", planViajeBean);
	}

	/**
	 * Metodo que permite calcular el siguiente dia habil a partir de una fecha y un numero de dias que se suma a esta.
	 * 
	 * @author Juan Farro
	 * @param fecha fecha inicial
	 * @param dias numero de dias a sumar a la fecha inicial
	 * @return siguiente dia habil despues de realizar la suma de dias a la fecha inicial
	 * @throws DataAccessException
	 */
	@Override
	public Date fechaDiasHabiles(Date fecha, int dias) throws DataAccessException {

		Map<String, Object> parmSearch = new HashMap<String, Object>();

		parmSearch.put("p_fecha", fecha);
		parmSearch.put("p_dias", dias);

		Date siguienteDiaHabil = (Date) getSqlMapClientTemplate().queryForObject("planViaje.f_dias_habiles", parmSearch);

		return siguienteDiaHabil;
	}

	/**
	 * Metodo que permite buscar los datos de un plan de viaje a partir de su identificador.
	 * 
	 * @author Juan Farro
	 * @param codPlanViaje codigo de solicitud de viatico
	 * @return solicitud de viatico
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	@Override
	public PlanViajeBean buscarPlanViaje(String codPlanViaje) throws DataAccessException {

		Map<String, Object> parmSearch = new HashMap<String, Object>();

		parmSearch.put("codPlanViaje", codPlanViaje);

		PlanViajeBean planViaje = (PlanViajeBean) getSqlMapClientTemplate().queryForObject("planViaje.buscarPlanViaje", parmSearch);

		return planViaje;
	}

	/**
	 * Metodo que permite generar la secuencia para el identificador de un plan de viaje.
	 * 
	 * @author Juan Farro
	 * @param sede sede
	 * @param anio anio
	 * @return secuencia generada
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	@Override
	public String getSecuenciaPlanViajeID(String sede, String anio) throws DataAccessException {

		if (StringUtils.isBlank(sede)) throw new IllegalArgumentException("sede no puede estar vacia");
		if (StringUtils.isBlank(anio)) throw new IllegalArgumentException("anio no puede estar vacia");

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("anio", anio);
		params.put("sede", sede);

		String planViajePrefijo = StringUtils.trimToEmpty((String) getSqlMapClientTemplate().queryForObject("planViaje.generar_plan_viaje_id", params));

		int secuencia = 1; // por default
		if (StringUtils.isNotBlank(planViajePrefijo) && StringUtils.isNumeric(planViajePrefijo)) {
			secuencia = Integer.parseInt(planViajePrefijo) + 1;
		}

		String generado = sede + anio + StringUtils.leftPad(secuencia + "", 5, '0');

		return generado;
	}

	/**
	 * Metodo que permite generar la secuencia para el codigo de planilla de un plan de viaje.
	 * 
	 * @author Juan Farro
	 * @param anio anio
	 * @param uuoo UUOO
	 * @param tipoViaticoReembolso tipo viatico (V) o reembolso (R)
	 * @return secuencia generada
	 * @throws DataAccessException
	 */
	@Override
	public String getSecuenciaCodPlanillaViaje(String anio, String uuoo, String tipoViaticoReembolso) throws DataAccessException {

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("anio", anio);
		params.put("uuoo", uuoo);
		params.put("tipoViaticoReembolso", tipoViaticoReembolso);

		String maxPrefijo = StringUtils.trimToEmpty((String) getSqlMapClientTemplate().queryForObject("planViaje.max_prefijo_cod_planilla_viaje", params));

		return StringUtils.leftPad(anio, 4, '0') + StringUtils.leftPad(uuoo, 6, '0') + tipoViaticoReembolso + StringUtils.leftPad(maxPrefijo, 4, '0');
	}

	/**
	 * Metodo que permite buscar los datos de un plan de viaje a partir de su codigo de planilla.
	 * 
	 * @author Juan Farro
	 * @param codPlanilla codigo de planilla de viatico
	 * @return solicitud de viatico
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	@Override
	public PlanViajeBean buscarPlanViajePlanilla(String codPlanilla) throws DataAccessException {

		Map<String, Object> parmSearch = new HashMap<String, Object>();

		parmSearch.put("codPlanilla", codPlanilla);

		PlanViajeBean planViaje = (PlanViajeBean) getSqlMapClientTemplate().queryForObject("planViaje.buscarPlanViaje", parmSearch);

		return planViaje;
	}

	/**
	 * Metodo que permite buscar solicitudes de viaticos para un colaborador que se traslapen con las fechas especificadas en los parametros.
	 * 
	 * @author Juan Farro
	 * @param codColaborador codigo de colaborador
	 * @param fechaSalida fecha inicio para busqueda de traslape de fechas
	 * @param fechaRetorno fecha fin para la busqueda de traslape de fechas
	 * @return lista de solicitudes que tienen fechas traslapadas
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	@Override
	public List<PlanViajeBean> buscarTraslapeFechas(String codColaborador, Date fechaSalida, Date fechaRetorno) throws DataAccessException {

		// buscar otros planes de viaje del codTrabajador en las fechas fechaSalida | fechaRetorno

		Map<String, Object> parmSearch = new HashMap<String, Object>();

		parmSearch.put("codTrabajador", codColaborador);
		parmSearch.put("fechaSalida", fechaSalida);
		parmSearch.put("fechaRetorno", fechaRetorno);

		List<PlanViajeBean> result = (List<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.buscarTraslapeFechas", parmSearch);

		return result;
	}

	/**
	 * Metodo que permite determinar si existe en BD un codigo de planilla.
	 * 
	 * @author Juan Farro
	 * @param codPlanilla codigo de planilla
	 * @return true si codigo de planilla existe en BD
	 * @throws DataAccessException
	 */
	@Override
	public boolean existePlanilla(String codPlanilla) throws DataAccessException {

		Map<String, Object> parmSearch = new HashMap<String, Object>();

		parmSearch.put("codPlanilla", codPlanilla);

		Long nroRegistros = (Long) getSqlMapClientTemplate().queryForObject("planViaje.existePlanilla", parmSearch);

		return nroRegistros != null && nroRegistros > 0;
	}

	/**
	 * Metodo que permite buscar solicitudes de viaticos (diferente a la especificado en el parametro) para un colaborador que se traslapen con las fechas especificadas.
	 * 
	 * @author Juan Farro
	 * @param codColaborador codigo de colaborador
	 * @param fechaSalida fecha de inicio para la busqueda de traslape de fechas
	 * @param fechaRetorno fecha fin para la busqueda de traslape de fechas
	 * @param codPlanViaje codigo de plan de viaje a excluir en la busqueda
	 * @return lista de solicitudes que tienen fechas traslapadas
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	@Override
	public List<PlanViajeBean> buscarTraslapeFechas(String codColaborador, Date fechaSalida, Date fechaRetorno, String codPlanViaje) throws DataAccessException {

		// buscar otros planes de viaje del codTrabajador en las fechas fechaSalida | fechaRetorno, diferente al plan viaje codPlanViaje

		Map<String, Object> parmSearch = new HashMap<String, Object>();

		parmSearch.put("codTrabajador", codColaborador);
		parmSearch.put("codPlanViaje", codPlanViaje);
		parmSearch.put("fechaSalida", fechaSalida);
		parmSearch.put("fechaRetorno", fechaRetorno);

		List<PlanViajeBean> listaPlanViaje = (List<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.buscarTraslapeFechas", parmSearch);

		return listaPlanViaje;
	}

	/**
	 * Buscar codigo empleado del autorizador de gasto
	 * 
	 * @author Juan Farro
	 * @param codColaborador codigo del colaborador
	 * @return codigo empleado del autorizador de gasto
	 * @throws DataAccessException
	 */
	@Override
	public String obtenerCodigoEmpleadoAutorizador(String codColaborador) throws DataAccessException {

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("codColaborador", codColaborador);

		Object codEmpleadoAutorizador = getSqlMapClientTemplate().queryForObject("planViaje.obtenerCodigoEmpleadoAutorizador", params);

		return codEmpleadoAutorizador == null ? null : String.valueOf(codEmpleadoAutorizador);
	}

	/**
	 * Busca plan viaje para el reporte.
	 * 
	 * @author Samuel Dionisio
	 * @param planViajeId : codigo plan viaje
	 * @return plan viaje
	 * @throws DataAccessException
	 */
	public PlanViajeBean obtenerPlanViajeToSolicitud(String planViajeId) throws DataAccessException {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("planViajeId", planViajeId);
		PlanViajeBean planViaje = (PlanViajeBean) getSqlMapClientTemplate().queryForObject("planViaje.obtenerPlanViajeToSolicitud", params);
		return planViaje;
	}

	/**
	 * Busca plan viaje para el reporte de reembolso
	 * 
	 * @author Juan Farro
	 * @param planViajeId : codigo plan viaje
	 * @return plan viaje
	 * @throws DataAccessException
	 */
	public PlanViajeBean obtenerPlanViajeToReembolso(String planViajeId) throws DataAccessException {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("planViajeId", planViajeId);
		PlanViajeBean planViaje = (PlanViajeBean) getSqlMapClientTemplate().queryForObject("planViaje.obtenerPlanViajeToReembolso", params);
		return planViaje;
	}

	/**
	 * Metodo que permite buscar las planillas de viatico asociadas a un colaborador para reembolso.
	 * 
	 * @author Juan Farro
	 * @param codColaborador codigo del colaborador
	 * @param tipoDestino tipo destino (nacional, internacional)
	 * @param indicadorHoras indicador de horas (mayor a 4 horas, menor o igual a 4 horas)
	 * @return lista de planillas asociadas para reembolso
	 * @throws DataAccessException
	 * @see PlanViajeBean
	 */
	@Override
	public List<PlanViajeBean> obtenerPlanillasAsociadasParaReembolso(String codColaborador, String tipoDestino, String indicadorHoras) throws DataAccessException {

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("codColaborador", codColaborador);
		params.put("tipoDestino", tipoDestino);
		params.put("indicadorHoras", indicadorHoras);

		List<PlanViajeBean> lista = (List<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.obtenerPlanillasAsociadasParaReembolso", params);

		return lista;
	}
	
	/**
	 * Metodo que permite buscar las planillas de viatico pendientes
	 * 
	 * @author Yoney Ayala
	 * @return lista de planillas pendientes
	 * @throws DataAccessException
	 */
	@Override
	public List<PlanViajeBean> obtenerListaEstadosSolicitudPendienteViatico() throws DataAccessException {	
		List<PlanViajeBean> lista = (List<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.obtenerListaEstadoSolicitudPendienteViatico");
		return lista;
	}
	
	/**
	 * Metodo que permite buscar las planillas de viatico asociadas vencidos dos dias
	 * 
	 * @author Yoney Ayala
	 * @return lista de planillas pendientes vencidos dos dias
	 * @throws DataAccessException
	 */
	@Override
	public List<PlanViajeBean> obtenerListaViaticoDiasAdicional() throws DataAccessException {	
		List<PlanViajeBean> lista = (List<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.obtenerListaViaticoDiasAdicional");
		return lista;
	}
	
	/**
	 * Metodo que permite buscar las planillas de viatico asociadas vencidos trienta dias
	 * 
	 * @author Yoney Ayala
	 * @return lista de planillas pendientes vencidos a trienta dias
	 * @throws DataAccessException
	 */
	@Override
	public List<PlanViajeBean> obtenerListaViaticoPlazoExcedido() throws DataAccessException {	
		List<PlanViajeBean> lista = (List<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.obtenerListaViaticoPlazoExcedido");
		return lista;
	}
	
	/**
	 * Metodo que permite buscar las planillas de viatico asociadas vencidos trienta dias y vencidos dos dias
	 * 
	 * @author Yoney Ayala
	 * @return lista de planillas pendientes vencidos a trienta dias y dos dias vencidos
	 * @throws DataAccessException
	 */
	@Override
	public List<PlanViajeBean> obtenerListaViaticoPlazoExcedidoGlobal() throws DataAccessException {
		List<PlanViajeBean> lista = (List<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.obtenerListaViaticoPlazoExcedidoGlobal");
		return lista;
	}
	
	/**
	 * Metodo que permite actualizar plan viaje aquellas planillas vencidos
	 * 
	 * @author Yoney Ayala.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	public void actualizarPlanViajeToCerrarAnulacion(PlanViajeBean planViajeBean) throws DataAccessException {
		getSqlMapClientTemplate().update("planViaje.actualizarPlanViajeToCerrarAnulacion", planViajeBean);
	}
	
	
	/**
	 * Metodo que permite actualizar Fecha de Primera Notificacion
	 * 
	 * @author emarchena.
	 * @param planViajeBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	public void actualizarPlanViajeToFechaNotificacion(PlanViajeBean planViajeBean) throws DataAccessException {
		getSqlMapClientTemplate().update("planViaje.actualizarPlanViajeToFechaNotificacion", planViajeBean);
	}

	/**
	 * Metodo que permite obtener el codigo CCP - CAS.
	 *
	 * @author Juan Farro
	 * @param tipoReq tipo de requerimiento
	 * @param codigoReq codigo de req
	 * @return codigo CCP
	 * @throws DataAccessException
	 */
	@Override
	public String obtenerCodigoCCP(String tipoReq, String codigoReq) throws DataAccessException {
		Map<String, Object> parmSearch = new HashMap<String, Object>();
		
		parmSearch.put("tipoReq", tipoReq);
		parmSearch.put("codigoReq", codigoReq);
		getSqlMapClientTemplate().queryForObject("planViaje.sp_procesoinicialCCP", parmSearch);
		
		return ((Long) parmSearch.get("codigoSalida")).toString();
	}
	
	/**
	 * Metodo que permite actualizar plan viaje aquellas planillas vencidos
	 * 
	 * @author Yoney Ayala.
	 * @param planViajeBean :objeto que tiene los parametros a actualizar
	 * @throws DataAccessException
	 */
	@Override
	public List<PlanViajeBean> obtenerListaViaticoConcecutivo(PlanViajeBean planViajeBean) throws DataAccessException{
		List<PlanViajeBean> lista = (List<PlanViajeBean>) getSqlMapClientTemplate().queryForList("planViaje.obtenerListaViaticoConcecutivo", planViajeBean);
		return lista;
	}

	
	@Override
	public Map<String, String> obtenerUUOOAutorizadora(String codDependencia, String codEmpleado, String indProceso) throws DataAccessException {
		Map<String, String> paramStore = new HashMap<String, String>();
		paramStore.put("codDependencia", codDependencia);
		paramStore.put("codEmpleado", codEmpleado);
		paramStore.put("indProceso", indProceso);
		getSqlMapClientTemplate().queryForObject("planViaje.sp_obtenerUUOOAutorizadora", paramStore);
		return paramStore;
	}

	@Override
	public Map<String, String> reevaluarUUOOsAutorizadoras(String codAutorizador)
			throws DataAccessException {
		Map<String, String> paramStore = new HashMap<String, String>();
		paramStore.put("codAutorizador", codAutorizador);
		getSqlMapClientTemplate().queryForObject("planViaje.sp_reevaluaUUOOPorAutorizar", paramStore);
		return paramStore;
	}

	@Override
	public void derivarSolicitudByAutorizador(PlanViajeBean planViajeBean)
			throws DataAccessException {
		getSqlMapClientTemplate().update("planViaje.derivarSolicitudByAutorizador", planViajeBean);
	}
	
	@Override
	public String obtenerExistenciaPlanillasConsecutivas(String codiEmplPer, Date fecInicio, Date fecFin, String origen) throws DataAccessException {

		String resultado = "";
		Map<String, Object> parmSearch = new HashMap<String, Object>();
		
		parmSearch.put("codiEmplPer", codiEmplPer);
		parmSearch.put("fecInicio", fecInicio);
		parmSearch.put("fecFin", fecFin);
		parmSearch.put("origen", origen);
		resultado = (String)getSqlMapClientTemplate().queryForObject("planViaje.fn_valida_planilla", parmSearch);
		
		return resultado;
	}

	@Override
	public Map<String, String> validarRevisionPreviaOSA(String idPlanilla)
			throws DataAccessException {
		// TODO Auto-generated method stub
		Map<String, String> paramStore = new HashMap<String, String>();
		paramStore.put("idPlanilla", idPlanilla);//SP_EVALUAOSARPV
		getSqlMapClientTemplate().queryForObject("planViaje.sp_evaluaOSARendicionPlanViaje", paramStore);
		return paramStore;
	}
	
	public void autorizarSolicitudByAutorizadorSoloFirma(PlanViajeBean planViajeBean) throws DataAccessException {
		getSqlMapClientTemplate().update("planViaje.autorizarSolicitudByAutorizadorSoloFirma", planViajeBean);
	}

		
}
