package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.ibatis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.ConceptoPlanillaViaticosBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.ConceptoPlanillaViaticosDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;

/**
 * Interfaz SqlMapConceptoPlanillaViaticosDAOImpl.
 * 
 * @author Juan Saccatoma
 */
@SuppressWarnings("unchecked")
public class SqlMapConceptoPlanillaViaticosDAOImpl extends SqlMapClientDaoSupport implements ConceptoPlanillaViaticosDAO {

	/**
	 * Metodo que permite obtener concepto planilla viaticos para comprobante.
	 * 
	 * @author Jorge Ponce
	 * @see ConceptoPlanillaViaticosBean
	 * @param idPlanViaje codigo de solicitud
	 * @return lista de conceptos
	 * @throws DataAccessException
	 */
	public ArrayList<ConceptoPlanillaViaticosBean> obtenerConceptoPlanillaViaticosToComprobante(String idPlanViaje) throws DataAccessException {

		Map<String, Object> parmSearch = new HashMap<String, Object>();

		parmSearch.put("idPlanViaje", idPlanViaje);

		ArrayList<ConceptoPlanillaViaticosBean> listaConceptos = (ArrayList<ConceptoPlanillaViaticosBean>) getSqlMapClientTemplate().queryForList("conceptoPlanillaViaticos.obtenerConceptoPlanillaViaticosToComprobante", parmSearch);

		return listaConceptos;
	}

	/**
	 * Metodo que permite obtener conceptos viatico.
	 * 
	 * @author Juan Saccatoma
	 * @see ConceptoPlanillaViaticosBean
	 * @param codigo codigo del concepto de viatico
	 * @param descripcion descripcion del concepto de viatico
	 * @return lista de conceptos
	 * @throws DataAccessException
	 */
	public List<ConceptoPlanillaViaticosBean> obtenerConceptosViatico(String codigo, String descripcion) throws DataAccessException {

		Map<String, Object> parmSearch = new HashMap<String, Object>();

		parmSearch.put("codigo", codigo);
		parmSearch.put("descripcion", descripcion);

		List<ConceptoPlanillaViaticosBean> listaConceptos = (List<ConceptoPlanillaViaticosBean>) getSqlMapClientTemplate().queryForList("conceptoPlanillaViaticos.obtenerConceptosViatico", parmSearch);

		return listaConceptos;
	}

	/**
	 * Metodo que permite obtener conceptos viatico a partir de su codigo y descripcion
	 * 
	 * @author Juan Farro
	 * @see ConceptoPlanillaViaticosBean
	 * @param params parametros de busqueda
	 * @return lista de conceptos
	 * @throws DataAccessException
	 */
	@Override
	public List<ConceptoPlanillaViaticosBean> obtenerConceptosViatico(Map<String, Object> params) throws DataAccessException {

		List<ConceptoPlanillaViaticosBean> listaConceptos = (List<ConceptoPlanillaViaticosBean>) getSqlMapClientTemplate().queryForList("conceptoPlanillaViaticos.obtenerConceptosViatico", params);

		return listaConceptos;
	}

	/**
	 * Metodo que permite obtener el importe diario.
	 * 
	 * @author Juan Farro
	 * @see ConceptoPlanillaViaticosBean
	 * @param params parametros de busqueda
	 * @return lista de conceptos
	 * @throws DataAccessException
	 */
	@Override
	public List<ConceptoPlanillaViaticosBean> obtenerImporteDiario(Map<String, Object> params) throws DataAccessException {

		List<ConceptoPlanillaViaticosBean> listaConceptos = (List<ConceptoPlanillaViaticosBean>) getSqlMapClientTemplate().queryForList("conceptoPlanillaViaticos.obtenerImporteDiario", params);

		return listaConceptos;
	}

	/**
	 * Metodo que permite obtener un concepto de viatico por su codigo
	 * 
	 * @author Juan Farro
	 * @param codigo codigo del concepto de viatico
	 * @return concepto de viatico
	 * @throws DataAccessException
	 * @see ConceptoPlanillaViaticosBean
	 */
	@Override
	public ConceptoPlanillaViaticosBean obtenerConceptoViatico(String codigo) throws DataAccessException {

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("codigoIgual", codigo);

		List<ConceptoPlanillaViaticosBean> listaConceptos = (List<ConceptoPlanillaViaticosBean>) getSqlMapClientTemplate().queryForList("conceptoPlanillaViaticos.obtenerConceptosViatico", params);
		if (CollectionUtils.isNotEmpty(listaConceptos)) {
			return listaConceptos.get(0);
		}

		return null;
	}

	/**
	 * Metodo que permite obtener un concepto de viatico por su indicador de itinerario
	 * 
	 * @author Samuel Dionisio
	 * @param codigo codigo del concepto de viatico
	 * @return concepto de viatico
	 * @throws DataAccessException
	 * @see ConceptoPlanillaViaticosBean
	 */
	@Override
	public ConceptoPlanillaViaticosBean obtenerConceptoViaticoIndItinerario(String indItinerario,String tipoDestino) throws DataAccessException {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("indItinerario", indItinerario);
		if(ViaticoConstantes.TIPO_COMISION_INTERNACIONAL.equals(tipoDestino)){
			params.put("tipoDestino", tipoDestino);	
		}
		ConceptoPlanillaViaticosBean concepto = (ConceptoPlanillaViaticosBean) getSqlMapClientTemplate().queryForObject("conceptoPlanillaViaticos.obtenerConceptosViatico", params);

		return concepto;
	}

}
