package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.ibatis;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PapeletaDepositoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PapeletaDepositoDAO;
import pe.gob.sunat.recurso2.financiera.siga.viatico.util.ViaticoConstantes;

/**
 * Implementacion de la interface PapeletaDepositoDAO, contiene los metodos para la consulta y transaccion de la tabla PAPELETAS_DEPOSITOS.
 * @author Jorge Ponce.
 */
public class SqlMapPapeletaDepositoDAOImpl extends SqlMapClientDaoSupport implements PapeletaDepositoDAO {
	
	/**
	 * Metodo que permite obtener el listado de papeletas de deposito asociados a un plan viaje.
	 * @author Jorge Ponce.
	 * @param  codigoPlanViaje :codigo plan viaje.
	 * @return Listado de papeletas deposito.
	 * @see    PapeletaDepositoBean
	 * @throws DataAccessException
	 */
	@SuppressWarnings("unchecked")
	public ArrayList<PapeletaDepositoBean> obtenerPapeletasDeposito(String codigoPlanViaje) throws DataAccessException {
		
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("codigoPlanViaje", codigoPlanViaje);
		ArrayList<PapeletaDepositoBean> papeletaDepositoList = (ArrayList<PapeletaDepositoBean>) getSqlMapClientTemplate().queryForList("papeletasDepositos.obtenerPapeletasDeposito", paramSearch);
		return papeletaDepositoList;
	}
	
	/**
	 * Metodo que permite obtener el secuencial (codigoBoletaDeposito) para la papeleta deposito a registrar.
	 * @author Jorge Ponce.
	 * @return Secuencial del codigo de boleta deposito.
	 * @see    String
	 * @throws DataAccessException
	 */
	public String obtenerSecuencialCodigoBoletaDeposito() throws DataAccessException {
		return (String) getSqlMapClientTemplate().queryForObject("papeletasDepositos.obtenerSecuencialCodigoBoletaDeposito");
	}
	
	/**
	 * Metodo que permite obtener el monto total que se deposito.
	 * @author Jorge Ponce.
	 * @param  codigoPlanViaje :codigo plan viaje.
	 * @return Monto total depositado.
	 * @see    PapeletaDepositoBean
	 * @throws DataAccessException
	 */
	public BigDecimal obtenerMontoDepositado(String codigoPlanViaje) throws DataAccessException {
		
		BigDecimal montoDepositado = BigDecimal.ZERO;
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("codigoPlanViaje", codigoPlanViaje);
		PapeletaDepositoBean papeletaDepositoBean = (PapeletaDepositoBean) getSqlMapClientTemplate().queryForObject("papeletasDepositos.obtenerMontoDepositado", paramSearch);
		if (papeletaDepositoBean != null) {
			montoDepositado = papeletaDepositoBean.getMontoDeposito();
		}
		return montoDepositado;
	}
	
	/**
	 * Metodo que permite obtener el numero de registro archivo de la papeleta deposito.
	 * @author Jorge Ponce.
	 * @param codigoPapeletaDeposito :codigo papeleta deposito.
	 * @return Numero de registro archivo.
	 * @see String
	 * @throws DataAccessException
	 */
	public String obtenerNumeroRegistroArchivo(String codigoPapeletaDeposito) throws DataAccessException {
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("codigoPapeletaDeposito", codigoPapeletaDeposito);
		String numeroRegistroArchivo = (String) getSqlMapClientTemplate().queryForObject("papeletasDepositos.obtenerNumeroRegistroArchivo", paramSearch);
		if (numeroRegistroArchivo == null) {
			numeroRegistroArchivo = ViaticoConstantes.CADENA_VACIA;
		}
		return numeroRegistroArchivo;
	}
	
	/**
	 * Metodo que permite registrar una papeleta deposito y asociarlo a un plan viaje.
	 * @author Jorge Ponce.
	 * @param  papeletaDeposito :objeto que tiene los datos para registrar.
	 * @throws DataAccessException
	 */
	public void insertarPapeletaDeposito(PapeletaDepositoBean papeletaDeposito) throws DataAccessException {
		getSqlMapClientTemplate().insert("papeletasDepositos.insertarPapeletaDeposito", papeletaDeposito);
	}
	
	/**
	 * Metodo que permite desasociar una papeleta deposito a un plan viaje.
	 * @author Jorge Ponce.
	 * @param  codigoPlanViaje :codigo plan viaje al cual se debe actualizar.
	 * @param  codigoBoletaDeposito :codigo boleta deposito.
	 * @param  codigoPlanViaje :codigo plan viaje.
	 * @throws DataAccessException
	 */
	public void actualizarCodigoPlanViaje(String codigoPlanViajeAux, String codigoBoletaDeposito, String codigoPlanViaje) throws DataAccessException {
		
		Map<String, Object> paramUpdate = new HashMap<String, Object>();
		paramUpdate.put("codigoPlanViajeAux", codigoPlanViajeAux);
		paramUpdate.put("codigoBoletaDeposito", codigoBoletaDeposito);
		paramUpdate.put("codigoPlanViaje", codigoPlanViaje);
		getSqlMapClientTemplate().update("papeletasDepositos.actualizarCodigoPlanViaje", paramUpdate);
	}

	/**
	 * Metodo que permite obtener papeleta de deposito.
	 * @author 
	 * @param  papeletaDepositoBean : PapeletaDepositoBean.
	 * @return Papeleta deposito.
	 * @see    PapeletaDepositoBean
	 * @throws DataAccessException
	 */
	@Override
	public PapeletaDepositoBean obtenerPapeletaDeposito(String codigoBoletaDeposito)	throws DataAccessException {
		Map<String, Object> param =  new HashMap<String, Object>();
		param.put("codigoBoletaDeposito",codigoBoletaDeposito);
		PapeletaDepositoBean papeletaDeposito = (PapeletaDepositoBean)getSqlMapClientTemplate().queryForObject("papeletasDepositos.obtenerPapeletaDeposito", param);
		return papeletaDeposito;
	}

	/**
	 * Metodo que permite asociar y desasociar una papeleta deposito.
	 * @author Samuel Dionisio.
	 * @param  papeletaDepositoBean : PapeletaDepositoBean.
	 * @see    void
	 * @throws Exception
	 */
	@Override
	public void actualizarNumeroArchivo(PapeletaDepositoBean papeletaDepositoBean)throws DataAccessException {
		getSqlMapClientTemplate().update("papeletasDepositos.actualizarNumeroArchivo", papeletaDepositoBean);
	}

	@Override
	public Integer countPapeletaDeposito(
			PapeletaDepositoBean papeletaDepositoBean)
			throws DataAccessException {
		Integer result = (Integer)getSqlMapClientTemplate().queryForObject("papeletasDepositos.countPapeletaDeposito", papeletaDepositoBean);
		return result;
	}

	@Override
	public void eliminarPapeletaDeposito(String codigoBoletaDeposito,
			String codigoPlanViaje) throws DataAccessException {
		Map<String, Object> paramDelete = new HashMap<String, Object>();
		paramDelete.put("codigoBoletaDeposito", codigoBoletaDeposito);
		paramDelete.put("codigoPlanViaje", codigoPlanViaje);
		getSqlMapClientTemplate().update("papeletasDepositos.eliminarPapeletaDeposito", paramDelete);
	}
}
