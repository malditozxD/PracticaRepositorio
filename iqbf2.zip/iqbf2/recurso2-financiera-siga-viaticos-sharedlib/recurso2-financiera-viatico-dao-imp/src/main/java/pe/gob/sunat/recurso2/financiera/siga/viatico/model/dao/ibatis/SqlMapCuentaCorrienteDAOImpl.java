package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.ibatis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.CuentaCorrienteBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.CuentaCorrienteDAO;

/**
 * Implementacion de la interface CuentaCorrienteDAO, contiene los metodos para la consulta y transaccion de la tabla CUENTA_CORRIENTE.
 * @author Jorge Ponce.
 */
public class SqlMapCuentaCorrienteDAOImpl extends SqlMapClientDaoSupport implements CuentaCorrienteDAO {
	
	/**
	 * Metodo que permite obtener el listado de cuentas corriente.
	 * @author Jorge Ponce.
	 * @param  simboloMoneda :simbolo de la moneda.
	 * @return Listado de cuentas corriente.
	 * @see    CuentaCorrienteBean
	 * @throws DataAccessException
	 */
	@SuppressWarnings("unchecked")
	public ArrayList<CuentaCorrienteBean> obtenerCuentasCorriente(String simboloMoneda) throws DataAccessException {
		
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("simboloMoneda", simboloMoneda);
		ArrayList<CuentaCorrienteBean> cuentaCorrienteList = (ArrayList<CuentaCorrienteBean>) getSqlMapClientTemplate().queryForList("cuentaCorriente.obtenerCuentaCorriente", paramSearch);
		return cuentaCorrienteList;
	}
}
