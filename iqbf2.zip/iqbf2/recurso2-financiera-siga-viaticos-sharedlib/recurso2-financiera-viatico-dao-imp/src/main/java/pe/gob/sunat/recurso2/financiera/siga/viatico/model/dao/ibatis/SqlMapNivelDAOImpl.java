package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.ibatis;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.NivelBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.NivelDAO;

/**
 * Clase SqlMapNivelDAOImpl.
 * 
 * @author Juan Farro
 */
@SuppressWarnings("unchecked")
public class SqlMapNivelDAOImpl extends SqlMapClientDaoSupport implements NivelDAO {

	/**
	 * Buscar un nivel de viatico por su codigo.
	 * 
	 * @author Juan Farro
	 * @param codigoNivel codigo nivel
	 * @return nivel
	 * @throws DataAccessException
	 * @see NivelBean
	 */
	@Override
	public NivelBean buscarNivelViatico(String codigoNivel) throws DataAccessException {

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("codigoNivel", codigoNivel);

		List<NivelBean> lista = (List<NivelBean>) getSqlMapClientTemplate().queryForList("nivelViatico.buscarNivelViatico", params);

		if (CollectionUtils.isNotEmpty(lista)) {
			return lista.get(0);
		}

		return null;
	}

}
