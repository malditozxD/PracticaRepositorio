package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.ibatis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.TipoDocumentoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.TipoDocumentoDAO;

public class SqlMapTipoDocumentoDAOImpl extends SqlMapClientDaoSupport implements TipoDocumentoDAO {
	
	
	/**
	 * Metodo que permite obtener el listado de tipo de comprobante de pago.
	 * @author Samuel Dionisio.
	 * @param  abreviaturaTipoDocumento :abreviatura tipo documento.
	 * @return Listado de tipo de comprobante de pago.
	 * @see    TipoDocumentoBean
	 * @throws DataAccessException
	 */
	
	@SuppressWarnings("unchecked")
	public ArrayList<TipoDocumentoBean> obtenerTipoDocumentoToComprobante(String abreviaturaTipoDocumento) throws DataAccessException {
		
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("abreviaturaTipoDocumento", abreviaturaTipoDocumento);
		ArrayList<TipoDocumentoBean> tipoDocumentoList = (ArrayList<TipoDocumentoBean>) getSqlMapClientTemplate().queryForList("tipoDocumento.obtenerTipoDocumentosToComprobante", paramSearch);
		return tipoDocumentoList;
	}
	
}
