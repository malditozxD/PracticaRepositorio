package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.ibatis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeDestinoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeDestinoDAO;

/**
 * Clase SqlMapPlanViajeDestinoDAOImpl
 * 
 * @author Juan Farro
 */
@SuppressWarnings("unchecked")
public class SqlMapPlanViajeDestinoDAOImpl extends SqlMapClientDaoSupport implements PlanViajeDestinoDAO {

	/**
	 * Metodo que permite registrar plan viaje destino.
	 * 
	 * @author Juan Farro
	 * @see PlanViajeDestinoBean
	 * @param planViajeDestino plan viaje destino
	 * @throws DataAccessException
	 */
	@Override
	public void registrarPlanViajeDestino(PlanViajeDestinoBean planViajeDestino) throws DataAccessException {
		getSqlMapClientTemplate().update("planViajeDestinos.registrarPlanViajeDestino", planViajeDestino);
	}

	/**
	 * Metodo que permite actualizar plan viaje destino.
	 * 
	 * @author Juan Farro
	 * @see PlanViajeDestinoBean
	 * @param planViajeDestino plan viaje destino
	 * @throws DataAccessException
	 */
	@Override
	public void actualizarPlanViajeDestino(PlanViajeDestinoBean planViajeDestino) throws DataAccessException {
		getSqlMapClientTemplate().update("planViajeDestinos.actualizarPlanViajeDestino", planViajeDestino);
	}

	/**
	 * Metodo que permite buscar los plan viaje destinos asociados a una solicitud de viatico.
	 * 
	 * @author Juan Farro
	 * @see PlanViajeDestinoBean
	 * @param codPlanViaje codigo de solicitud de viatico
	 * @return lista de destinos
	 * @throws DataAccessException
	 */
	@Override
	public List<PlanViajeDestinoBean> buscarPlanViajeDestinos(String codPlanViaje) throws DataAccessException {

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("planViajeID", codPlanViaje);

		List<PlanViajeDestinoBean> listaDestinos = (List<PlanViajeDestinoBean>) getSqlMapClientTemplate().queryForList("planViajeDestinos.buscarPlanViajeDestinos", params);

		return listaDestinos;
	}

	/**
	 * Metodo que permite eliminar los plan viaje destinos asociados a una solicitud de viatico.
	 * 
	 * @author Juan Farro
	 * @see PlanViajeDestinoBean
	 * @param codPlanViaje codigo de solicitud de viatico
	 * @throws DataAccessException
	 */
	@Override
	public void eliminarPlanViajeDestinos(String codPlanViaje) throws DataAccessException {

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("planViajeID", codPlanViaje);

		getSqlMapClientTemplate().delete("planViajeDestinos.eliminarPlanViajeDestinos", params);

	}
	
	/**
	 * Metodo que permite obtener el listado de monto tope diario de una rendicion.
	 * @author Jorge Ponce.
	 * @param  planViajeID :codigo plan viaje.
	 * @return Listado de monto tope diarios.
	 * @see    PlanViajeDestinoBean
	 * @throws DataAccessException
	 */
	public ArrayList<PlanViajeDestinoBean> obtenerMontoTopeDia(String planViajeID) throws DataAccessException {
		
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("planViajeID", planViajeID);
		ArrayList<PlanViajeDestinoBean> planViajeDestinoList = (ArrayList<PlanViajeDestinoBean>) getSqlMapClientTemplate().queryForList("planViajeDestinos.obtenerMontoTopeDia", paramSearch);
		return planViajeDestinoList;
	}
	
}
