package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.ibatis;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.VacacionBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.VacacionDAO;

/**
 * Interfaz SqlMapVacacionDAOImpl.
 * 
 * @author Juan Farro 
 */
@SuppressWarnings("unchecked")
public class SqlMapVacacionDAOImpl extends SqlMapDAOBase implements VacacionDAO {

	/**
	 * Metodo que permite obtener las vacaciones de un colaborador en un rango de fechas.
	 * 
	 * @author Juan Farro
	 * @see VacacionBean
	 * @param params parametros de busqueda
	 * @return lista de vacaciones
	 * @throws DataAccessException
	 * 
	 */
	@Override
	public List<VacacionBean> listarVacaciones(Map<String, Object> params) throws DataAccessException {

		List<VacacionBean> listaVacaciones = (List<VacacionBean>) getSqlMapClientTemplate().queryForList("t1282vacaciones_d.listarVacaciones", params);

		return listaVacaciones;
	}

}
