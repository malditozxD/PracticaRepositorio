package pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.ibatis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.bean.PlanViajeConceptoBean;
import pe.gob.sunat.recurso2.financiera.siga.viatico.model.dao.PlanViajeConceptoDAO;

/**
 * Clase SqlMapPlanViajeConceptoDAOImpl.
 * 
 * @author Juan Farro
 */
@SuppressWarnings("unchecked")
public class SqlMapPlanViajeConceptoDAOImpl extends SqlMapClientDaoSupport implements PlanViajeConceptoDAO {

	/**
	 * Metodo que permite registrar plan viaje concepto.
	 * 
	 * @author Juan Farro
	 * @see PlanViajeConceptoBean
	 * @param planViajeConcepto plan viaje concepto
	 * @throws DataAccessException
	 */
	@Override
	public void registrarPlanViajeConcepto(PlanViajeConceptoBean planViajeConcepto) throws DataAccessException {
		getSqlMapClientTemplate().insert("planViajeConceptos.registrarPlanViajeConcepto", planViajeConcepto);
	}

	/**
	 * Metodo que permite actualizar un plan viaje concepto.
	 * 
	 * @author Juan Farro
	 * @see PlanViajeConceptoBean
	 * @param planViajeConcepto plan viaje concepto
	 * @throws DataAccessException
	 */
	@Override
	public void actualizarPlanViajeConcepto(PlanViajeConceptoBean planViajeConcepto) throws DataAccessException {
		getSqlMapClientTemplate().update("planViajeConceptos.actualizarPlanViajeConcepto", planViajeConcepto);
	}

	/**
	 * Metodo que permite buscar los plan viaje concepto asociados a una solicitud de viatico.
	 * 
	 * @author Juan Farro
	 * @see PlanViajeConceptoBean
	 * @param codPlanViaje codigo de solicitud de viatico
	 * @return lista de plan de viaje conceptos
	 * @throws DataAccessException
	 */
	@Override
	public List<PlanViajeConceptoBean> buscarPlanViajeConceptos(String codPlanViaje) throws DataAccessException {

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("planViajeID", codPlanViaje);

		List<PlanViajeConceptoBean> listaConceptos = (List<PlanViajeConceptoBean>) getSqlMapClientTemplate().queryForList("planViajeConceptos.buscarPlanViajeConceptos", params);

		return listaConceptos;

	}
	
	/**
	 * Metodo que permite obtener el listado de plan viaje concepto asociados a una solicitud.
	 * @author Jorge Ponce.
	 * @param  planViajeID :codigo plan viaje.
	 * @return Listado de plan de viaje concepto.
	 * @see    PlanViajeBean
	 * @throws DataAccessException
	 */
	public ArrayList<PlanViajeConceptoBean> obtenerPlanViajeConceptoToRendicion(String planViajeID) throws DataAccessException {
		
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("planViajeID", planViajeID);
		ArrayList<PlanViajeConceptoBean> planViajeConceptoList = (ArrayList<PlanViajeConceptoBean>) getSqlMapClientTemplate().queryForList("planViajeConceptos.obtenerPlanViajeConceptoToRendicion", paramSearch);
		return planViajeConceptoList;
	}
	
	/**
	 * Metodo que permite actualizar el monto devuelto por voucher en el plan viaje concepto.
	 * @author Jorge Ponce.
	 * @param  planViajeConceptoBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	public void actualizarMontoDevueltoVoucher(PlanViajeConceptoBean planViajeConceptoBean) throws DataAccessException {
		getSqlMapClientTemplate().update("planViajeConceptos.actualizarMontoDevueltoVoucher", planViajeConceptoBean);
	}
	
	/**
	 * Metodo que permite actualizar el monto rendido por comprobante en el plan viaje concepto.
	 * @author Jorge Ponce.
	 * @param  planViajeConceptoBean :objeto que tiene los parametros de la busqueda y los datos a actualizar.
	 * @throws DataAccessException
	 */
	public void actualizarMontoRendidoComprobante(PlanViajeConceptoBean planViajeConceptoBean) throws DataAccessException {
		getSqlMapClientTemplate().update("planViajeConceptos.actualizarMontoRendidoComprobante", planViajeConceptoBean);
	}
	
	/**
	 * Metodo que permite obtener los montos de plan viaje concepto asociados a una solicitud.
	 * @author Jorge Ponce.
	 * @param  planViajeID :codigo plan viaje.
	 * @param  conceptoID :codigo concepto.
	 * @return Plan de viaje concepto.
	 * @see    PlanViajeBean
	 * @throws DataAccessException
	 */
	public PlanViajeConceptoBean obtenerPlanViajeConceptoMonto(String planViajeID, String conceptoID) throws DataAccessException {
		
		Map<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("planViajeID", planViajeID);
		paramSearch.put("conceptoID", conceptoID);
		PlanViajeConceptoBean planViajeConceptoBean = (PlanViajeConceptoBean) getSqlMapClientTemplate().queryForObject("planViajeConceptos.obtenerPlanViajeConceptoMonto", paramSearch);
		return planViajeConceptoBean;
	}

	/**
	 * Metodo que permite eliminar los plan viaje concepto asociados a una solicitud de viatico.
	 * 
	 * @author Juan Farro
	 * @param codPlanViaje codigo de solicitud de viatico
	 * @throws DataAccessException
	 */
	@Override
	public void eliminarPlanViajeConceptos(String codPlanViaje) throws DataAccessException {

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("planViajeID", codPlanViaje);

		getSqlMapClientTemplate().delete("planViajeConceptos.eliminarPlanViajeConceptos", params);

	}
	/**
	 * Metodo que permite eliminar los plan viaje concepto asociados a una solicitud de viatico.
	 * 
	 * @author Samuel Dionisio
	 * @param codPlanViaje : String codigo de solicitud de viatico
	 * @param conceptoId : String id de concepto
	 * @throws DataAccessException
	 */
	@Override
	public void eliminarPlanViajeConceptos(String codPlanViaje, String conceptoId) throws DataAccessException {

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("planViajeID", codPlanViaje);
		params.put("conceptoId", conceptoId);

		getSqlMapClientTemplate().delete("planViajeConceptos.eliminarPlanViajeConceptos", params);

	}

}
