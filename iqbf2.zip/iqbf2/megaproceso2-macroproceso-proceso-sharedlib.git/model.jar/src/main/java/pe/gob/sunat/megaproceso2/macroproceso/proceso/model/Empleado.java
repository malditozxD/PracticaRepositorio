package pe.gob.sunat.megaproceso2.macroproceso.proceso.model;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class Empleado {
	//Atributos
    private String nombre;
    private String cargo;
    private BigDecimal salario;
    
    //Comentario  2
    // linea adicional 1
    // linea adicional 2
    // linea adicional 3
    // linea adicional 4
    // linea adicional 5
    // linea adicional 6
    
    
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd'T'HH:mm:ssZ",timezone="GMT-05:00")
    private Date fechaIngreso;
    
    private String sede;
    private BigInteger anexo;
	
    //Getters and Setters
    public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCargo() {
		return cargo;
	}
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
	public BigDecimal getSalario() {
		return salario;
	}
	public void setSalario(BigDecimal salario) {
		this.salario = salario;
	}
	public Date getFechaIngreso() {
		return fechaIngreso;
	}
	public void setFechaIngreso(Date fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}
	public String getSede() {
		return sede;
	}
	public void setSede(String sede) {
		this.sede = sede;
	}
	public BigInteger getAnexo() {
		return anexo;
	}
	public void setAnexo(BigInteger anexo) {
		this.anexo = anexo;
	}

}
