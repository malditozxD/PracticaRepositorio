package pe.gob.sunat.megaproceso2.macroproceso.proceso.service;

import java.util.List;

import pe.gob.sunat.megaproceso2.macroproceso.proceso.model.Empleado;

public interface EmpleadoService {
	public List<Empleado> obtenerListaEmpleados();

}
