package pe.gob.sunat.megaproceso2.macroproceso.proceso.service;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.megaproceso2.macroproceso.proceso.model.DemoEntidad;

public interface DemoProcesoService {
		
	public List<DemoEntidad> listarDemoEntidad();

	public DemoEntidad obtenerDemoEntidadPorID(String codCatalogo,String codDatacat);

	public DemoEntidad actualizarDemoEntidad(DemoEntidad entidad);

	public List<DemoEntidad> listarDemoEntidadWithFilters(Map<String, String> query);

	public List<Map<String, String>> validarEntidad(DemoEntidad entidad);

}
