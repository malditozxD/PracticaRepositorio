package pe.gob.sunat.megaproceso2.macroproceso.proceso.service;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.megaproceso2.macroproceso.proceso.model.DemoEntidad;

public interface ProcesoValidacionService {
	public List<Map<String, String>> validarAlgunaCosa(DemoEntidad entidad); 
}
