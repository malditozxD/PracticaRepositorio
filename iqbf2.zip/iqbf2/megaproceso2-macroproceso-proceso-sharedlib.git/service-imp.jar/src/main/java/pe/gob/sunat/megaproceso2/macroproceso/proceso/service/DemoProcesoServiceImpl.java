package pe.gob.sunat.megaproceso2.macroproceso.proceso.service;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.megaproceso2.macroproceso.proceso.model.DemoEntidad;
import pe.gob.sunat.megaproceso2.macroproceso.proceso.model.dao.DemoEntidadDAO;

@Service("proceso.demoProcesoService")
public class DemoProcesoServiceImpl implements DemoProcesoService {

	@Autowired
	FabricaDeServicios serviceFactory;
	
	@Override
	public List<DemoEntidad> listarDemoEntidad() {
		List<DemoEntidad> listaDemoEntidades = new ArrayList<DemoEntidad>();
		DemoEntidadDAO demoEntidadDAO = serviceFactory.getService("proceso.demoEntidadDAOLectura") ;
		listaDemoEntidades = demoEntidadDAO.listarDemoEntidad();
		return listaDemoEntidades;
	}
	
	@Override
	public List<DemoEntidad> listarDemoEntidadWithFilters(Map<String,String> query) {
		//Mapa para parsear lo filtros
		Map<String,String> params = new HashMap<String, String>();
		params.putAll(query);
		
		//Invocar al DAO
		DemoEntidadDAO demoEntidadDAO = serviceFactory.getService("proceso.demoEntidadDAOLectura") ;
		List<DemoEntidad> listaDemoEntidades = demoEntidadDAO.listarDemoEntidadWithColumnFilter(params);
		return listaDemoEntidades;
	}

	@Override
	public DemoEntidad obtenerDemoEntidadPorID(String codCatalogo, String codDatacat) {
		DemoEntidadDAO demoEntidadDAO = serviceFactory.getService("proceso.demoEntidadDAOLectura") ;
		DemoEntidad entidad = demoEntidadDAO.obtenerDemoEntidadPorID(codCatalogo, codDatacat);
		return entidad;
	}
	
//	@Override
//	public DemoEntidad obtenerDemoEntidadPorIDConAtribFilter(String codCatalogo,
//															 String codDatacat,
//															 String commaDelimitedAtribs) {
//		//Parsear el Filtro
//		Map<String,String> atribParams = new HashMap<String, String>();
//		String[] atribs = commaDelimitedAtribs.split(",");
//		for(String atrib: atribs){
//			atribParams.put(atrib, atrib);
//		}		
//		//Invocar al DAO
//		DemoEntidadDAO demoEntidadDAO = serviceFactory.getService("proceso.demoEntidadDAOLectura") ;
//		DemoEntidad entidad = demoEntidadDAO.obtenerDemoEntidadPorID(codCatalogo, codDatacat);
//		return entidad;
//	}

	@Override
	@Transactional(rollbackFor=Exception.class,propagation=Propagation.REQUIRED)
	public DemoEntidad actualizarDemoEntidad(DemoEntidad entidad) {
		DemoEntidadDAO demoEntidadDAO = serviceFactory.getService("proceso.demoEntidadDAOEscritura");
		entidad = demoEntidadDAO.actualizarDemoEntidad(entidad);
		return entidad;
	}

	
	@Override
	public List<Map<String, String>> validarEntidad(DemoEntidad entidad) {
		List<Map<String, String>> listaErrores = new ArrayList<Map<String,String>>();
		Map<String, String> resp= new HashMap<String, String>();
		
		//Validar el RUC		
		resp.put("cod", "10004");
		resp.put("msg", "El RUC 123455676 es Invalido");
		listaErrores.add(resp);
		//Validar otro Dato
		resp.put("cod", "20004");
		resp.put("msg", "La fecha 21/02/2015 esta fuera del intervalo 01/01/2015 - 31/01/2015");
		listaErrores.add(resp);
		
		
		return listaErrores;
	}
	
	
}
