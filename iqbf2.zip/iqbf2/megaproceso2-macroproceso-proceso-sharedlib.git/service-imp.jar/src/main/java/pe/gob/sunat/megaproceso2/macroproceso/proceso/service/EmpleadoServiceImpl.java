package pe.gob.sunat.megaproceso2.macroproceso.proceso.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.megaproceso2.macroproceso.proceso.model.Empleado;
import pe.gob.sunat.megaproceso2.macroproceso.proceso.model.dao.EmpleadoDAO;

@Service("proceso.empleadoservice")
public class EmpleadoServiceImpl implements EmpleadoService {

	@Autowired
	FabricaDeServicios serviceFactory;
	
	@Override
	public List<Empleado> obtenerListaEmpleados() {
		
		EmpleadoDAO empleadoDAO = serviceFactory.getService("proceso.empleadodao");
		return empleadoDAO.obtenerListaEmpleados();
	}

}
