package pe.gob.sunat.megaproceso2.macroproceso.proceso.model.dao.ibatis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.ibatis.SqlMapClientFactoryBean;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import org.springframework.stereotype.Repository;

import com.ibatis.sqlmap.client.SqlMapClient;

import pe.gob.sunat.megaproceso2.macroproceso.proceso.model.DemoEntidad;
import pe.gob.sunat.megaproceso2.macroproceso.proceso.model.dao.DemoEntidadDAO;

public class SqlMapDemoEntidadDAO extends SqlMapClientDaoSupport implements DemoEntidadDAO   {

	public SqlMapDemoEntidadDAO() {

	}
	
	@Override
	public List<DemoEntidad> listarDemoEntidad() {
		List<DemoEntidad> lista = new ArrayList<DemoEntidad>();
		lista = getSqlMapClientTemplate().queryForList("demoproceso.listAll");
		return lista;
	}
	
	@Override
	public List<DemoEntidad> listarDemoEntidadWithColumnFilter(Map params) {
		List<DemoEntidad> lista = new ArrayList<DemoEntidad>();
		lista = getSqlMapClientTemplate().queryForList("demoproceso.listAllwithColumnFilter",params);
		return lista;
	}
	

	public DemoEntidad  obtenerDemoEntidadPorID(String codCatalogo,String codDatacat){
		DemoEntidad entidad = new DemoEntidad();
		entidad.setCodCatalogo(codCatalogo);
		entidad.setCodDatacat(codDatacat);
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("entidad", entidad);
		entidad = (DemoEntidad) getSqlMapClientTemplate().queryForObject("demoproceso.listByParameterMap",params);
		return entidad;
	}

	
	

	@Override
	public DemoEntidad registrarDemoEntidad(DemoEntidad entidad) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public DemoEntidad actualizarDemoEntidad(DemoEntidad entidad) {
		// TODO Auto-generated method stub
		return null;
	}

}
