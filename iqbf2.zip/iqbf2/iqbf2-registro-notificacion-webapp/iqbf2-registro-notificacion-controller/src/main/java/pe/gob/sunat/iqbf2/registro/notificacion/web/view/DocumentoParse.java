package pe.gob.sunat.iqbf2.registro.notificacion.web.view;


import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

public class DocumentoParse {
	
	public static DocumentoVO obtenerMaestroPersonalBeanView(UsuarioBean usuarioBean) {
		DocumentoVO documentoVO = null;
		if (usuarioBean != null ) {
			documentoVO = new DocumentoVO();
			documentoVO.setCodProyecta(usuarioBean.getNroRegistro());
			documentoVO.setNomProyecta(usuarioBean.getNombreCompleto());
			documentoVO.setRuc(usuarioBean.getNumRUC());
		}
		return documentoVO;
	}

}
