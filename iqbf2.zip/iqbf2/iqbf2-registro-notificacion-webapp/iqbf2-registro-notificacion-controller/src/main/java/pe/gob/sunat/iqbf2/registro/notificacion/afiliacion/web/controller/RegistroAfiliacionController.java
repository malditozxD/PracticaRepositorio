package pe.gob.sunat.iqbf2.registro.notificacion.afiliacion.web.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.lang.StringUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.iqbf2.registro.notificacion.afiliacion.service.RegistroAfiliacionService;
import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.RegistroAfiliacionBean;
import pe.gob.sunat.iqbf2.registro.notificacion.util.AfiliacionConstantes;
import pe.gob.sunat.iqbf2.registro.notificacion.util.NotificacionConstantes;
import pe.gob.sunat.iqbf2.registro.notificacion.util.ResourceBundleUtil;
import pe.gob.sunat.iqbf2.registro.notificacion.web.controller.BaseController;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

/**
 * La clase RegistroAfiliacionController realiza las validaciones y transacciones para la pagina de registro de afiliacion.
 * 
 * @author emarchena
 */
public class RegistroAfiliacionController extends BaseController{
	protected final Log log = LogFactory.getLog(getClass());
	RegistroAfiliacionService	registroAfiliacionService;
	
	



	public RegistroAfiliacionService getRegistroAfiliacionService() {
		return registroAfiliacionService;
	}


	public void setRegistroAfiliacionService(
			RegistroAfiliacionService registroAfiliacionService) {
		this.registroAfiliacionService = registroAfiliacionService;
	}


	/**
	 * Metodo que permite cargar la pagina de registro de Afiliacion a las notificaciones .
	 * 
	 * @author emarchena
	 * @see ModelAndView
	 * @param request
	 *            objeto peticion de la clase HttpServletRequest
	 * @param response
	 *            objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView mostrarRegistrarAfiliacion(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;

		boolean customMessage = false;
		String errorMessage = StringUtils.EMPTY;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		String ruc =StringUtils.EMPTY;
		try {

			log.debug(getClass().getName() + " Inicio del metodo mostrarRegistrarViatico");

			// view object con toda la informacion a mostrar en la pantalla de registro de una solicitud
			// usuario en session
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			// datos del colaborador que esta en session
			 ruc = StringUtils.trimToEmpty(usuarioBean.getNumRUC());
			Long nroRegistros = null;
			// buscar afectacion presupuesta / meta presupuestal ordenando por mayor codigo
			if (StringUtils.isNotBlank(ruc)) {

			}
			// para el registro la fecha de registro es igual a la fecha today
			Date today = new Date();
			respuesta.put("fechaToday",today);

		} catch (Exception e) {

			log.error(e.getMessage(), e);
			errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(NotificacionConstantes.MENSAJE_ERROR_GENERICO);

		} finally {

			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(AfiliacionConstantes.REGISTRAR_AFILIACION_PAGE, respuesta);

			log.debug(getClass().getName() + " Fin del metodo mostrarRegistrarViatico");
		}

		return modelAndView;
	}

	
	/**
	 * Metodo que permite registrar la Afiliacion a las notificaciones .
	 * 
	 * @author emarchena
	 * @see ModelAndView
	 * @param request
	 *            objeto peticion de la clase HttpServletRequest
	 * @param response
	 *            objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView registrarAfiliacion(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;

		boolean customMessage = false;
		String errorMessage = StringUtils.EMPTY;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		String ruc =StringUtils.EMPTY;
		try {

			log.debug(getClass().getName() + " Inicio del metodo mostrarRegistrarViatico");

			// view object con toda la informacion a mostrar en la pantalla de registro de una solicitud
			// usuario en session
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			// datos del colaborador que esta en session
			 ruc = StringUtils.trimToEmpty(usuarioBean.getNumRUC());
			Long nroRegistros = null;
			RegistroAfiliacionBean registroAfiliacionBean= new RegistroAfiliacionBean();
			String codRuc=null;
			// buscar afectacion presupuesta / meta presupuestal ordenando por mayor codigo
			if (StringUtils.isNotBlank(ruc)) {
				registroAfiliacionService.validarAfiliacion(codRuc);
				registroAfiliacionService.registrarAfiliacion(registroAfiliacionBean);
			}
			// para el registro la fecha de registro es igual a la fecha today
			Date today = new Date();
			respuesta.put("fechaToday",today);

		} catch (Exception e) {

			log.error(e.getMessage(), e);
			errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(NotificacionConstantes.MENSAJE_ERROR_GENERICO);

		} finally {

			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(AfiliacionConstantes.REGISTRAR_AFILIACION_PAGE, respuesta);

			log.debug(getClass().getName() + " Fin del metodo mostrarRegistrarViatico");
		}

		return modelAndView;
	}


}
