package pe.gob.sunat.iqbf2.registro.notificacion.documento.web.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.iqbf2.registro.notificacion.documento.service.DocumentoMasivoService;
import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.PaqueteBean;
import pe.gob.sunat.iqbf2.registro.notificacion.service.ContribuyenteService;
import pe.gob.sunat.iqbf2.registro.notificacion.util.DocumentoIndividualConstantes;
import pe.gob.sunat.iqbf2.registro.notificacion.util.NotificacionConstantes;
import pe.gob.sunat.iqbf2.registro.notificacion.util.ResourceBundleUtil;
import pe.gob.sunat.iqbf2.registro.notificacion.web.controller.BaseController;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

public class RegistroDocumentoMasivoController extends BaseController{
	protected final Log log = LogFactory.getLog(getClass());
	
	DocumentoMasivoService documentoMasivoService;
	
	
	/**
	 * Metodo que permite cargar la pagina de registro de documentos individuales .
	 * 
	 * @author emarchena
	 * @see ModelAndView
	 * @param request
	 *            objeto peticion de la clase HttpServletRequest
	 * @param response
	 *            objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView mostrarRegistrarDocumentoMasivo(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;
		boolean customMessage = false;
		String errorMessage = StringUtils.EMPTY;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		String ruc =StringUtils.EMPTY;
		try {

			log.debug(getClass().getName() + " Inicio del metodo mostrarRegistrarDocumentoIndividual");
			// view object con toda la informacion a mostrar en la pantalla de registro de una solicitud
			// usuario en session
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			// datos del colaborador que esta en session
			 ruc = StringUtils.trimToEmpty(usuarioBean.getNumRUC());
			Long nroRegistros = null;
			// buscar afectacion presupuesta / meta presupuestal ordenando por mayor codigo
			if (StringUtils.isNotBlank(ruc)) {

			}
			// para el registro la fecha de registro es igual a la fecha today
			Date today = new Date();
			respuesta.put("fechaToday",today);

		} catch (Exception e) {

			log.error(e.getMessage(), e);
			errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(NotificacionConstantes.MENSAJE_ERROR_GENERICO);

		} finally {

			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(DocumentoIndividualConstantes.REGISTRAR_DOCUMENTO_INDIVIDUAL_PAGE, respuesta);

			log.debug(getClass().getName() + " Fin del metodo mostrarRegistrarDocumentoIndividual");
		}

		return modelAndView;
	}
	

	/**
	 * Metodo que permite cargar la pagina de registro de documentos individuales .
	 * 
	 * @author emarchena
	 * @see ModelAndView
	 * @param request
	 *            objeto peticion de la clase HttpServletRequest
	 * @param response
	 *            objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView generarDocumentoMasivo(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;
		boolean customMessage = false;
		String errorMessage = StringUtils.EMPTY;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		String ruc =StringUtils.EMPTY;
		try {
			PaqueteBean paqueteBean = new PaqueteBean();
			log.debug(getClass().getName() + " Inicio del metodo mostrarRegistrarDocumentoIndividual");
			// view object con toda la informacion a mostrar en la pantalla de registro de una solicitud
			// usuario en session
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			// datos del colaborador que esta en session
			 ruc = StringUtils.trimToEmpty(usuarioBean.getNumRUC());
			Long nroRegistros = null;
			// buscar afectacion presupuesta / meta presupuestal ordenando por mayor codigo
			if (StringUtils.isNotBlank(ruc)) {
				
				documentoMasivoService.generarDocumentosMasivo(paqueteBean);
			}
			// para el registro la fecha de registro es igual a la fecha today
			Date today = new Date();
			respuesta.put("fechaToday",today);

		} catch (Exception e) {

			log.error(e.getMessage(), e);
			errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(NotificacionConstantes.MENSAJE_ERROR_GENERICO);

		} finally {

			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(DocumentoIndividualConstantes.REGISTRAR_DOCUMENTO_INDIVIDUAL_PAGE, respuesta);

			log.debug(getClass().getName() + " Fin del metodo mostrarRegistrarDocumentoIndividual");
		}

		return modelAndView;
	}
	
}
