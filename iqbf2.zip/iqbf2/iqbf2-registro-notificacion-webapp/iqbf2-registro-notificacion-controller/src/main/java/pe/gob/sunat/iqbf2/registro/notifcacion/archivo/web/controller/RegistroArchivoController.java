package pe.gob.sunat.iqbf2.registro.notifcacion.archivo.web.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.iqbf2.registro.notificacion.util.FormatoConstantes;
import pe.gob.sunat.iqbf2.registro.notificacion.util.ReporteConstantes;
import pe.gob.sunat.iqbf2.registro.notificacion.web.controller.BaseController;

import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;


public class RegistroArchivoController extends BaseController{
	protected final Log log = LogFactory.getLog(getClass());

	//RegistroArchivosService registroArchivosService;

	private String 	uploadDir;
	
	
	/**
	 * Descargar Archivos Adjuntos de los item
	 * @see ModelAndView
	 * @param request : de la clase HttpServletRequest
	 * @param response : de la clase HttpServletResponse
	 * @param sec_reg : obtenida del request.getParameter
	 * @return ModelAndView
	 **/
	public ModelAndView descargarArchivo(HttpServletRequest request, HttpServletResponse response) {
		if (log.isDebugEnabled()) {log.debug("debug Inicio - RegistroArchivosController.descargarArchivo");}
		Map<String, Object> params = new HashMap<String, Object>();

		try {
			String sec_reg 	= StringUtils.trim(request.getParameter("sec_reg"));
			log.debug("sec_reg "+sec_reg);
			params.put("sec_reg", sec_reg);
		//	RegistroArchivosFisicoBean archivo = registroArchivosService.recuperarArchivo(params);

			response.setContentType("application/octet-stream");
			//response.setHeader("Content-Disposition","attachment;filename="+archivo.getFile_name());

			OutputStream os = response.getOutputStream();

			//os.write(archivo.getData());

			os.flush();
			os.close();
			return null;
		}
		catch(ServiceException ex){
			log.error("Error en RegistroArchivosController.descargarArchivo: " + ex.getMessage());
			throw new ServiceException(this, ex);
		}
		catch(Exception ex){
			log.error("Error en RegistroArchivosController.descargarArchivo: " + ex.getMessage(), ex);
			throw new ServiceException(this, ex);
		}
		finally{
			if (log.isDebugEnabled()){ log.debug("Fin - RegistroArchivosController.descargarArchivo");}
		}

	}


	/**
	 * Carga el Archivo al Servidor y registra en el la BD(upload)
	 * @param request : de la clase HttpServletRequest
	 * @param response : de la clase HttpServletResponse
	 * @param hidNumeroRegitroArchivo : obtenida del request.getParameter
	 * @param SelCodTipoArchivo : obtenida del request.getParameter
	 * @param txtDescripcionArchivo : obtenida del request.getParameter
	 * @param registroDescripcion : obtenida del request.getParameter
	 * @param hidNumeroDocumento : obtenida del request.getParameter
	 * @param hidApliacion : obtenida del request.getParameter
	 * @param hidModulo : obtenida del request.getParameter
	 * @return  objeto view de la clase ModelAndView tipo Json con los datos menssaje, listArchivosAdj, codigoRegArchivo
	 **/
	public ModelAndView cargarArchivo(HttpServletRequest request, HttpServletResponse response){
		if (log.isDebugEnabled()){ log.debug("Inicio -  RegistroArchivosController.cargarArchivo");}

		Map<String, Object> respuesta = new HashMap<String, Object>();
		Map<String, Object> params 	= new HashMap<String, Object>();
		ModelAndView viewPage = null;


		long tamanio = 1048576;
		String numeroDocumentoOrigen		=FormatoConstantes.CADENA_VACIA;
		String registroDescripcion=FormatoConstantes.CADENA_VACIA;

		String tipoDocumento		=FormatoConstantes.CADENA_VACIA;
		String fileDescripcion		=FormatoConstantes.CADENA_VACIA;
		String numeroRegitroArchivo		=FormatoConstantes.CADENA_VACIA;

		try{

			File farchivo = new File(ReporteConstantes.RUTA_ARCHIVO_DATA0);
			File fupload = new File(ReporteConstantes.RUTA__ARCHIVO_DATA0_TEM );
			if (!farchivo.exists() ){
				farchivo.mkdir();
			}
			if (!fupload.exists() ){
				fupload.mkdir();
			}



			numeroRegitroArchivo	= StringUtils.trim(request.getParameter("hidNumeroRegitroArchivo"));

			tipoDocumento	= StringUtils.trim(request.getParameter("SelCodTipoArchivo"));;
			fileDescripcion	= StringUtils.trim(request.getParameter("txtDescripcionArchivo"));
			registroDescripcion = StringUtils.trim(request.getParameter("registroDescripcion"));

			numeroDocumentoOrigen	= StringUtils.trim(request.getParameter("hidNumeroDocumento"));

			
			log.debug("numeroRegitroArchivo: " + numeroRegitroArchivo);
			log.debug("tipoDocumento: " + tipoDocumento);
			log.debug("fileDescripcion: " + fileDescripcion);
			log.debug("numeroDocumentoOrigen: " + numeroDocumentoOrigen);
			


			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");


			MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
			MultipartFile multipartFile = multipartRequest.getFile("file");
			log.debug("size"+multipartFile.getSize());
			log.debug("tamanio"+tamanio);
			if(multipartFile.getSize() > 0 && multipartFile.getSize() <= tamanio ) {
				String nombre_archivo = multipartFile.getOriginalFilename();
				File file =new File(uploadDir, nombre_archivo.trim());
				FileOutputStream fileOutputStream = new FileOutputStream(file);
				fileOutputStream.close();
				multipartFile.transferTo(file);

				log.debug("file"+multipartFile);



				params.put("numeroDocumentoOrigen", numeroDocumentoOrigen);//CODIGO DE LA DDJJ O COMISION
				
				params.put("registroDescripcion", registroDescripcion); //Archivos Adjuntos de la Declaracion Jurada

				params.put("file", file);

				params.put("num_archivo", numeroRegitroArchivo);
				params.put("tipoDocumento", tipoDocumento);
				params.put("fileDescripcion", fileDescripcion);




				
			//	numeroRegitroArchivo=registroArchivosService.registrarArchivoGeneral(params);



			
				respuesta.put("menssaje", "OK");
		
				respuesta.put("codigoRegArchivo",numeroRegitroArchivo);

			}
			else{
				log.debug("El Archivo debe ser mayor a 0Mb y menor a 1Mb, el archivo pesa: "+multipartFile.getSize() +" y soporta hasta 1048576.");
				respuesta.put("menssaje", "El Archivo debe ser mayor a 0Mb y menor a 1Mb");
			}

		}catch(Throwable e){
			log.error("", e);
		} finally {
			if (log.isDebugEnabled()) {log.debug("Fin -  RqnpArchivoController.cargarArchivo");}
		}



		viewPage = new ModelAndView(getJsonView(), respuesta);

		return viewPage;
	}
}
