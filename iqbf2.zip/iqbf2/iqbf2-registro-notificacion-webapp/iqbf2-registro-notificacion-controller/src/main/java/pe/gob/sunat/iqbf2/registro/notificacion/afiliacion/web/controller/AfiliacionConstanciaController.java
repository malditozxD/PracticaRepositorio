package pe.gob.sunat.iqbf2.registro.notificacion.afiliacion.web.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.iqbf2.registro.notificacion.afiliacion.service.RegistroAfiliacionService;
import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.RegistroAfiliacionBean;
import pe.gob.sunat.iqbf2.registro.notificacion.service.NotificacionJasperService;
import pe.gob.sunat.iqbf2.registro.notificacion.tool.ArchivoBean;
import pe.gob.sunat.iqbf2.registro.notificacion.tool.JasperBean;
import pe.gob.sunat.iqbf2.registro.notificacion.tool.JasperTool;
import pe.gob.sunat.iqbf2.registro.notificacion.util.AfiliacionConstantes;
import pe.gob.sunat.iqbf2.registro.notificacion.util.NotificacionConstantes;
import pe.gob.sunat.iqbf2.registro.notificacion.util.ResourceBundleUtil;
import pe.gob.sunat.iqbf2.registro.notificacion.web.controller.BaseController;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;



public class AfiliacionConstanciaController   extends BaseController {

	/** Declaraci�n del log para realizar los debug, info, error, etc. */
	protected final Log log = LogFactory.getLog(getClass());

	/** Declaramos el servicio notificacionJasperService. */
	NotificacionJasperService notificacionJasperService;
	RegistroAfiliacionService	registroAfiliacionService;
	
	
	/**
	 * Metodo que permite cargar la pagina de registro de Afiliacion a las notificaciones .
	 * 
	 * @author emarchena
	 * @see ModelAndView
	 * @param request
	 *            objeto peticion de la clase HttpServletRequest
	 * @param response
	 *            objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView mostrarConstanciaAfiliacion(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;

		boolean customMessage = false;
		String errorMessage = StringUtils.EMPTY;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		String ruc =StringUtils.EMPTY;
		try {

			log.debug(getClass().getName() + " Inicio del metodo mostrarRegistrarViatico");

			// view object con toda la informacion a mostrar en la pantalla de registro de una solicitud
			// usuario en session
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			// datos del colaborador que esta en session
			 ruc = StringUtils.trimToEmpty(usuarioBean.getNumRUC());
			Long nroRegistros = null;
			// buscar afectacion presupuesta / meta presupuestal ordenando por mayor codigo
			if (StringUtils.isNotBlank(ruc)) {

			}
			// para el registro la fecha de registro es igual a la fecha today
			Date today = new Date();
			respuesta.put("fechaToday",today);

		} catch (Exception e) {

			log.error(e.getMessage(), e);
			errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(NotificacionConstantes.MENSAJE_ERROR_GENERICO);

		} finally {

			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(AfiliacionConstantes.REGISTRAR_AFILIACION_PAGE, respuesta);

			log.debug(getClass().getName() + " Fin del metodo mostrarRegistrarViatico");
		}

		return modelAndView;
	}
	
	/**
	 * Reporte declaracion PDF.
	 * @author emarchena
	 * @see ModelAndView
	 * @param request: de la clase HttpServletRequest
	 * @param response: de la clase  HttpServletResponse
	 * @param codDdJj: obtenida del request.getParameter
	 * @return retornar PDF.
	 */
	public ModelAndView constanciaAfiliacionpdf(HttpServletRequest request, HttpServletResponse response) {
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		String modoProceso="";
		byte[] byData=null;
		try {
			log.debug("Inicio AfiliacionConstanciaController  constanciaAfiliacionpdf");
			

			String ruc =  request.getParameter("ruc");

			RegistroAfiliacionBean registroAfiliacionBean = registroAfiliacionService.obtenerAfiliacion(ruc);
			
			JasperBean params = notificacionJasperService.generarConstanciaAfiliacionPDF(registroAfiliacionBean);
			
			ArchivoBean reporte = JasperTool.GenerarArchivoPDF(params);

			byData=reporte.getData();
			response.setContentType("application/pdf"); // response
			response.setHeader("Content-Disposition","attachment; filename=\"contanciaAfiliacion.pdf\";");
			response.setHeader("Cache-Control", "public");
			response.setHeader("Pragma", "public");
			response.setDateHeader("Expires", 0);
			response.setContentLength(byData.length);
			ServletOutputStream ouputStream = response.getOutputStream();
			ouputStream.write(byData, 0, byData.length);
			ouputStream.flush();
			ouputStream.close();

		}catch(ServiceException ex){
			log.error("Error en AfiliacionConstanciaController.constanciaAfiliacionpdf: " + ex.getMessage());
			respuesta.put("flagRegistroDeclaracion", "1");
			respuesta.put("messaje", ex.getMessage());
		}catch(Exception ex){
			log.error("Error en AfiliacionConstanciaController.constanciaAfiliacionpdf: " + ex.getMessage());
			respuesta.put("flagRegistroDeclaracion", "2");
//TODO mofificar			//respuesta.put("messaje",DeclaracionConstantes.MENSAJE_VALIDA_CANT_COMISION);
		}
		finally  {
		
			if (log.isDebugEnabled()){ log.debug("Fin - AfiliacionConstanciaController.constanciaAfiliacionpdf");}

			viewPage = null;
		}
		return viewPage;
	}


}
