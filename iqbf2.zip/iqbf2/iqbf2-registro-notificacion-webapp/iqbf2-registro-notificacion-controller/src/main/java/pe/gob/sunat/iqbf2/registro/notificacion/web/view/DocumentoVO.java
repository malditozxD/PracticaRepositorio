package pe.gob.sunat.iqbf2.registro.notificacion.web.view;

import java.io.Serializable;
import java.util.Date;

public class DocumentoVO  implements Serializable{

		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
		private String codDocumento ; 
		private String 	codTipoDoc;
		private String 	nomTipoDoc;
		private String 	codTipoProc;
		private String 	nomTipoProc;
		private String 	numDocumento;
		private String 	ruc;
		private String  razonSocial;
		private Integer codTipoFormato;
		private String  nomTipoFormato;
		
		private Date 	fechaProyectado;
		private String 	codProyecta;
		private String  registroProyecta;
		private String  nomProyecta;
		private String 	codUuoo;
		private String 	nomUuoo;
		
		private String 	codRevisa;
		private String 	registroRevisa;
		private String 	nomRevisa;
		private Date 	fechaRevisa;
		private String 	obsRevisa;
		
		private String 	codAprueba;
		private String 	registroAprueba;
		private String 	nomAprueba;
		private Date 	fechaAprueba;
		private String 	obsAprueba;
		
		private String 	codEstado;
		private String 	codPathFile;
		private String 	indOrigen;
		private String 	nomDepartamento;
		private String 	nomProvincia;
		private String 	nomDistrito;
		private String 	nomDireccion;
		private String 	mesInicio;
		private String 	mesFin;
		private String 	mensaje;
		private String 	numExpediente;
		private String 	flagDoAction;
		
		
		
		public String getCodDocumento() {
			return codDocumento;
		}
		public void setCodDocumento(String codDocumento) {
			this.codDocumento = codDocumento;
		}
		public String getCodTipoDoc() {
			return codTipoDoc;
		}
		public void setCodTipoDoc(String codTipoDoc) {
			this.codTipoDoc = codTipoDoc;
		}
		public String getNomTipoDoc() {
			return nomTipoDoc;
		}
		public void setNomTipoDoc(String nomTipoDoc) {
			this.nomTipoDoc = nomTipoDoc;
		}
		public String getCodTipoProc() {
			return codTipoProc;
		}
		public void setCodTipoProc(String codTipoProc) {
			this.codTipoProc = codTipoProc;
		}
		public String getNomTipoProc() {
			return nomTipoProc;
		}
		public void setNomTipoProc(String nomTipoProc) {
			this.nomTipoProc = nomTipoProc;
		}
		public String getNumDocumento() {
			return numDocumento;
		}
		public void setNumDocumento(String numDocumento) {
			this.numDocumento = numDocumento;
		}
		public String getRuc() {
			return ruc;
		}
		public void setRuc(String ruc) {
			this.ruc = ruc;
		}
		public String getRazonSocial() {
			return razonSocial;
		}
		public void setRazonSocial(String razonSocial) {
			this.razonSocial = razonSocial;
		}
		public Integer getCodTipoFormato() {
			return codTipoFormato;
		}
		public void setCodTipoFormato(Integer codTipoFormato) {
			this.codTipoFormato = codTipoFormato;
		}
		public String getNomTipoFormato() {
			return nomTipoFormato;
		}
		public void setNomTipoFormato(String nomTipoFormato) {
			this.nomTipoFormato = nomTipoFormato;
		}
		public Date getFechaProyectado() {
			return fechaProyectado;
		}
		public void setFechaProyectado(Date fechaProyectado) {
			this.fechaProyectado = fechaProyectado;
		}
		public String getCodProyecta() {
			return codProyecta;
		}
		public void setCodProyecta(String codProyecta) {
			this.codProyecta = codProyecta;
		}
		public String getRegistroProyecta() {
			return registroProyecta;
		}
		public void setRegistroProyecta(String registroProyecta) {
			this.registroProyecta = registroProyecta;
		}
		public String getNomProyecta() {
			return nomProyecta;
		}
		public void setNomProyecta(String nomProyecta) {
			this.nomProyecta = nomProyecta;
		}
		public String getCodUuoo() {
			return codUuoo;
		}
		public void setCodUuoo(String codUuoo) {
			this.codUuoo = codUuoo;
		}
		public String getNomUuoo() {
			return nomUuoo;
		}
		public void setNomUuoo(String nomUuoo) {
			this.nomUuoo = nomUuoo;
		}
		public String getCodRevisa() {
			return codRevisa;
		}
		public void setCodRevisa(String codRevisa) {
			this.codRevisa = codRevisa;
		}
		public String getRegistroRevisa() {
			return registroRevisa;
		}
		public void setRegistroRevisa(String registroRevisa) {
			this.registroRevisa = registroRevisa;
		}
		public String getNomRevisa() {
			return nomRevisa;
		}
		public void setNomRevisa(String nomRevisa) {
			this.nomRevisa = nomRevisa;
		}
		public Date getFechaRevisa() {
			return fechaRevisa;
		}
		public void setFechaRevisa(Date fechaRevisa) {
			this.fechaRevisa = fechaRevisa;
		}
		public String getObsRevisa() {
			return obsRevisa;
		}
		public void setObsRevisa(String obsRevisa) {
			this.obsRevisa = obsRevisa;
		}
		public String getCodAprueba() {
			return codAprueba;
		}
		public void setCodAprueba(String codAprueba) {
			this.codAprueba = codAprueba;
		}
		public String getRegistroAprueba() {
			return registroAprueba;
		}
		public void setRegistroAprueba(String registroAprueba) {
			this.registroAprueba = registroAprueba;
		}
		public String getNomAprueba() {
			return nomAprueba;
		}
		public void setNomAprueba(String nomAprueba) {
			this.nomAprueba = nomAprueba;
		}
		public Date getFechaAprueba() {
			return fechaAprueba;
		}
		public void setFechaAprueba(Date fechaAprueba) {
			this.fechaAprueba = fechaAprueba;
		}
		public String getObsAprueba() {
			return obsAprueba;
		}
		public void setObsAprueba(String obsAprueba) {
			this.obsAprueba = obsAprueba;
		}
		public String getCodEstado() {
			return codEstado;
		}
		public void setCodEstado(String codEstado) {
			this.codEstado = codEstado;
		}
		public String getCodPathFile() {
			return codPathFile;
		}
		public void setCodPathFile(String codPathFile) {
			this.codPathFile = codPathFile;
		}
		public String getIndOrigen() {
			return indOrigen;
		}
		public void setIndOrigen(String indOrigen) {
			this.indOrigen = indOrigen;
		}
		public String getNomDepartamento() {
			return nomDepartamento;
		}
		public void setNomDepartamento(String nomDepartamento) {
			this.nomDepartamento = nomDepartamento;
		}
		public String getNomProvincia() {
			return nomProvincia;
		}
		public void setNomProvincia(String nomProvincia) {
			this.nomProvincia = nomProvincia;
		}
		public String getNomDistrito() {
			return nomDistrito;
		}
		public void setNomDistrito(String nomDistrito) {
			this.nomDistrito = nomDistrito;
		}
		public String getNomDireccion() {
			return nomDireccion;
		}
		public void setNomDireccion(String nomDireccion) {
			this.nomDireccion = nomDireccion;
		}
		public String getMesInicio() {
			return mesInicio;
		}
		public void setMesInicio(String mesInicio) {
			this.mesInicio = mesInicio;
		}
		public String getMesFin() {
			return mesFin;
		}
		public void setMesFin(String mesFin) {
			this.mesFin = mesFin;
		}
		public String getMensaje() {
			return mensaje;
		}
		public void setMensaje(String mensaje) {
			this.mensaje = mensaje;
		}
		public String getNumExpediente() {
			return numExpediente;
		}
		public void setNumExpediente(String numExpediente) {
			this.numExpediente = numExpediente;
		}
		public String getFlagDoAction() {
			return flagDoAction;
		}
		public void setFlagDoAction(String flagDoAction) {
			this.flagDoAction = flagDoAction;
		}
		
		
		
		
		
}
