package pe.gob.sunat.iqbf2.registro.notificacion.documento.web.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;



import pe.gob.sunat.iqbf2.registro.notificacion.documento.service.DocumentoIndividualService;
import pe.gob.sunat.iqbf2.registro.notificacion.util.DocumentoIndividualConstantes;
import pe.gob.sunat.iqbf2.registro.notificacion.util.NotificacionConstantes;
import pe.gob.sunat.iqbf2.registro.notificacion.util.ResourceBundleUtil;
import pe.gob.sunat.iqbf2.registro.notificacion.web.controller.BaseController;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;


import pe.gob.sunat.iqbf2.registro.notificacion.model.bean.DocumentoIqbfBean;

public class BandejaDocumentoIndiviualController extends BaseController{
	protected final Log log = LogFactory.getLog(getClass());
	
	DocumentoIndividualService documentoIndividualService;

	/**
	 * Metodo que permite cargar la pagina de registro de Afiliacion a las notificaciones .
	 * 
	 * @author emarchena
	 * @see ModelAndView
	 * @param request
	 *            objeto peticion de la clase HttpServletRequest
	 * @param response
	 *            objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView mostrarBandejaDocumentoIndividual(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;

		boolean customMessage = false;
		String errorMessage = StringUtils.EMPTY;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		String ruc =StringUtils.EMPTY;
		try {

			log.debug(getClass().getName() + " Inicio del metodo mostrarConsultaDocumentoIndividual");

			// view object con toda la informacion a mostrar en la pantalla de registro de una solicitud
			// usuario en session
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			// datos del colaborador que esta en session
			 ruc = StringUtils.trimToEmpty(usuarioBean.getNumRUC());
			Long nroRegistros = null;
			// buscar afectacion presupuesta / meta presupuestal ordenando por mayor codigo
			if (StringUtils.isNotBlank(ruc)) {

			}
			// para el registro la fecha de registro es igual a la fecha today
			Date today = new Date();
			respuesta.put("fechaToday",today);

		} catch (Exception e) {

			log.error(e.getMessage(), e);
			errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(NotificacionConstantes.MENSAJE_ERROR_GENERICO);

		} finally {

			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(DocumentoIndividualConstantes.BANDEJA_DOCUMENTO_INDIVIDUAL_PAGE, respuesta);

			log.debug(getClass().getName() + " Fin del metodo mostrarConsultaDocumentoIndividual");
		}

		return modelAndView;
	}

	
	/**
	 * Metodo que permite cargar la pagina de registro de Afiliacion a las notificaciones .
	 * 
	 * @author emarchena
	 * @see ModelAndView
	 * @param request
	 *            objeto peticion de la clase HttpServletRequest
	 * @param response
	 *            objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView buscarDocumentos(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;

		boolean customMessage = false;
		String errorMessage = StringUtils.EMPTY;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		String ruc =StringUtils.EMPTY;
		Map<String, Object> parm = new HashMap<String, Object>();
		try {

			log.debug(getClass().getName() + " Inicio del metodo mostrarConsultaDocumentoIndividual");

			// view object con toda la informacion a mostrar en la pantalla de registro de una solicitud
			// usuario en session
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			// datos del colaborador que esta en session
			 ruc = StringUtils.trimToEmpty(usuarioBean.getNumRUC());
			Long nroRegistros = null;
			// buscar afectacion presupuesta / meta presupuestal ordenando por mayor codigo
			if (StringUtils.isNotBlank(ruc)) {
				List<DocumentoIqbfBean > listaDocumentos=(List<DocumentoIqbfBean>) documentoIndividualService.listarDocumentos(parm);
			}
			// para el registro la fecha de registro es igual a la fecha today
			Date today = new Date();
			respuesta.put("fechaToday",today);

		} catch (Exception e) {

			log.error(e.getMessage(), e);
			errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(NotificacionConstantes.MENSAJE_ERROR_GENERICO);

		} finally {

			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(DocumentoIndividualConstantes.BANDEJA_DOCUMENTO_INDIVIDUAL_PAGE, respuesta);

			log.debug(getClass().getName() + " Fin del metodo mostrarConsultaDocumentoIndividual");
		}

		return modelAndView;
	}
	
	/**
	 * Metodo que permite cargar la pagina de registro de Afiliacion a las notificaciones .
	 * 
	 * @author emarchena
	 * @see ModelAndView
	 * @param request
	 *            objeto peticion de la clase HttpServletRequest
	 * @param response
	 *            objeto respuesta de la clase HttpServletResponse
	 * @return el objeto ModelAndView con la respuesta de la peticion
	 */
	public ModelAndView darBajaDocumento(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelAndView = null;

		boolean customMessage = false;
		String errorMessage = StringUtils.EMPTY;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		String ruc =StringUtils.EMPTY;
		try {

			log.debug(getClass().getName() + " Inicio del metodo mostrarConsultaDocumentoIndividual");
			DocumentoIqbfBean documentoIqbfBean = new  DocumentoIqbfBean();
			// view object con toda la informacion a mostrar en la pantalla de registro de una solicitud
			// usuario en session
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			// datos del colaborador que esta en session
			 ruc = StringUtils.trimToEmpty(usuarioBean.getNumRUC());
			
			// buscar afectacion presupuesta / meta presupuestal ordenando por mayor codigo
			if (StringUtils.isNotBlank(ruc)) {
				documentoIndividualService.darBajaDocumento(documentoIqbfBean);
			}
			// para el registro la fecha de registro es igual a la fecha today
			Date today = new Date();
			respuesta.put("fechaToday",today);

		} catch (Exception e) {

			log.error(e.getMessage(), e);
			errorMessage = customMessage ? e.getMessage() : ResourceBundleUtil.getMessage(NotificacionConstantes.MENSAJE_ERROR_GENERICO);

		} finally {

			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(DocumentoIndividualConstantes.BANDEJA_DOCUMENTO_INDIVIDUAL_PAGE, respuesta);

			log.debug(getClass().getName() + " Fin del metodo mostrarConsultaDocumentoIndividual");
		}

		return modelAndView;
	}

}
