/*
 * Archivo que nos permite definir los metodos reutilizables - Interfaces.
 */
function BuscarUUOOInputService(dataParametros, buscarUUOOInputBeforeMethod, buscarUUOOInputAfterMethod) {

	if (typeof dataParametros != "undefined") {	
		
		this.idNumeroUUOO = dataParametros.idNumeroUUOO;
		this.idCodigoRegistrador = dataParametros.idCodigoRegistrador;
		this.idCodigoTipoUUOOViatico = dataParametros.idCodigoTipoUUOOViatico;
		this.idDivScreenBlock = dataParametros.idDivScreenBlock;
		this.idDivError = dataParametros.idDivError;
		this.idDivLoading = dataParametros.idDivLoading;
		this.idEtiquetaError = dataParametros.idEtiquetaError;
		this.errorMessage = dataParametros.errorMessage;
	}
	if (typeof buscarUUOOInputBeforeMethod != "undefined") {
		this.buscarUUOOBefore = buscarUUOOInputBeforeMethod;
	}
	if (typeof buscarUUOOInputAfterMethod != "undefined") {
		this.buscarUUOOAfter = buscarUUOOInputAfterMethod;
	}
}

function BuscarColaboradorInputService(dataParametros, buscarColaboradorInputBeforeMethod, buscarColaboradorInputAfterMethod) {
	
	if (typeof dataParametros != "undefined") {
		this.idNumeroRegistroColaborador = dataParametros.idNumeroRegistroColaborador;
		this.idCodigoRegistrador = dataParametros.idCodigoRegistrador;
		this.idNumeroRegistroRegistrador = dataParametros.idNumeroRegistroRegistrador;
		this.idCodigoTipoUsuarioViatico = dataParametros.idCodigoTipoUsuarioViatico;
		this.idDivLoading = dataParametros.idDivLoading;
		this.idDivError = dataParametros.idDivError;
		this.idEtiquetaError = dataParametros.idEtiquetaError;
		this.idDivScreenBlock = dataParametros.idDivScreenBlock;
		this.estadoLlamada = dataParametros.estadoLlamada;
		this.errorMessage = dataParametros.errorMessage;
	}
	if (typeof buscarColaboradorInputBeforeMethod != "undefined") {
		this.buscarColaboradorBefore = buscarColaboradorInputBeforeMethod;
	}
	if (typeof buscarColaboradorInputAfterMethod != "undefined") {
		this.buscarColaboradorAfter = buscarColaboradorInputAfterMethod;
	}
}

function BuscarColaboradorService(dataParametros, buscarColaboradorBeforeMethod, buscarColaboradorAfterMethod) {
	
	if (typeof dataParametros != "undefined") {
		this.idCodigoRegistrador = dataParametros.idCodigoRegistrador;
		this.idNumeroRegistroRegistrador = dataParametros.idNumeroRegistroRegistrador;
		this.idCodigoTipoUsuarioViatico = dataParametros.idCodigoTipoUsuarioViatico;
		this.idDivScreenBlock = dataParametros.idDivScreenBlock;
	}
	if (typeof buscarColaboradorBeforeMethod != "undefined") {
		this.buscarColaboradorBefore = buscarColaboradorBeforeMethod;
	}
	if (typeof buscarColaboradorAfterMethod != "undefined") {
		this.buscarColaboradorAfter = buscarColaboradorAfterMethod;
	}
}


function BuscarConceptoViaticoService(dataParam, eventosParam) {
	
	// atributos/propiedades
	if (typeof dataParam != "undefined" && dataParam != null) {
		this.data = dataParam;
	}
	
	// eventos/funciones
	if (typeof eventosParam != "undefined" && eventosParam != null) {
		this.eventos = eventosParam;
	} 
}

function BuscarCadenaPresupuestalService(dataParam, eventosParam) {
	
	// atributos/propiedades
	if (typeof dataParam != "undefined" && dataParam != null) {
		this.data = dataParam;
	}
	
	// eventos/funciones
	if (typeof eventosParam != "undefined" && eventosParam != null) {
		this.eventos = eventosParam;
	} 
}

function BuscarDestinoService(dataParam, eventosParam) {
	
	// atributos/propiedades
	if (typeof dataParam != "undefined" && dataParam != null) {
		this.data = dataParam;
	}
	
	// eventos/funciones
	if (typeof eventosParam != "undefined" && eventosParam != null) {
		this.eventos = eventosParam;
	} 
}

function BuscarUUOOService(dataParametros, buscarUUOOBeforeMethod, buscarUUOOAfterMethod) {
	
	if (typeof dataParametros != "undefined") {
		this.idCodigoRegistrador = dataParametros.idCodigoRegistrador;
		this.idCodigoTipoUUOOViatico = dataParametros.idCodigoTipoUUOOViatico;
		this.idDivScreenBlock = dataParametros.idDivScreenBlock;
	}
	if (typeof buscarUUOOBeforeMethod != "undefined") {
		this.buscarUUOOBefore = buscarUUOOBeforeMethod;
	}
	if (typeof buscarUUOOAfterMethod != "undefined") {
		this.buscarUUOOAfter = buscarUUOOAfterMethod;
	}
}

function ComprobantePagoService(comprobantePagoBeforeMethod, comprobantePagoAfterMethod) {
	
	if (typeof comprobantePagoBeforeMethod != "undefined") {
		this.comprobantePagoBefore = comprobantePagoBeforeMethod;
	}
	if (typeof comprobantePagoAfterMethod != "undefined") {
		this.comprobantePagoAfter = comprobantePagoAfterMethod;
	}
}

function AdjuntarDocumentoService(adjuntarDocumentoBeforeMethod, adjuntarDocumentoAfterMethod, adjuntarDocumentoCerrarAfterMethod) {
	
	if (typeof adjuntarDocumentoBeforeMethod != "undefined") {
		this.adjuntarDocumentoBefore = adjuntarDocumentoBeforeMethod;
	}
	if (typeof adjuntarDocumentoAfterMethod != "undefined") {
		this.adjuntarDocumentoAfter = adjuntarDocumentoAfterMethod;
	}
	if (typeof adjuntarDocumentoCerrarAfterMethod != "undefined") {
		this.adjuntarDocumentoCerrarAfter = adjuntarDocumentoCerrarAfterMethod;
	}
}

function AgregarArchivoService(agregarArchivoBeforeMethod, agregarArchivoAfterMethod) {
	
	if (typeof agregarArchivoBeforeMethod != "undefined") {
		this.agregarArchivoBefore = agregarArchivoBeforeMethod;
	}
	if (typeof agregarArchivoAfterMethod != "undefined") {
		this.agregarArchivoAfter = agregarArchivoAfterMethod;
	}
}
