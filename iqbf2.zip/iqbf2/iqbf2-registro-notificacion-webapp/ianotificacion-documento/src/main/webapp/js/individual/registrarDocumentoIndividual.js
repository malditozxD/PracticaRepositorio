function initElementsDocumentoIndividual() {
	
	var flagDoAction = getValueInputText("hidFlagDoAction");
	removeDuplicateComponents();
	setinitElementsDocumentoIndividual();
	if (flagDoAction == "01") {
		//Page Registrar
		setTituloPage("Registro de Documento Individual");
		setHtmlElement("divTituloPanelDocumentoIndividual", propertyMessageRegistrarDocumentoIndividual.registroTitulo);
		//setInitElementsRegistrarComision();
		//callObtenerDepartamento();
	}
	else if (flagDoAction == "02") {
		//Page Modificar
		setTituloPage("Modificacion de Documento Individual");
		setHtmlElement("divTituloPanelDocumentoIndividual", propertyMessageRegistrarDocumentoIndividual.modificacionTitulo);
		//setInitElementsModificarComision();
	}
	//setInitDesplazamientoTable(desplazamientoArray);
}
function setinitElementsDocumentoIndividual() {
	
}