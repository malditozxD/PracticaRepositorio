/// <reference path="./registrarModificarReembolso_init.js" />
/// <reference path="./registrarModificarReembolso_rest.js" />
/// <reference path="./registrarModificarReembolso_service.js" />
/// <reference path="./registrarModificarReembolso_validate.js" />
/// <reference path="../general/common.js" />
/// <reference path="../../WEB-INF/jsp/reembolso/registrar/registrarModificarReembolso.jsp" />
/// <reference path="D:\jcfr\data\ts-definitions\DefinitelyTyped-master\jquery\jquery.d.ts" />



// BUSCAR COLABORADOR
function clickBtnCambiarRegistro() {

	var dataParametrosBuscarColaborador = new Object();
	
	dataParametrosBuscarColaborador.idCodigoRegistrador = "hidCodigoRegistrador";
	dataParametrosBuscarColaborador.idNumeroRegistroRegistrador = "hidNumeroRegistroRegistrador";
	dataParametrosBuscarColaborador.idCodigoTipoUsuarioViatico = getTrimValue( '#hidCodigoTipoUsuarioViatico' );
	dataParametrosBuscarColaborador.idDivScreenBlock = "divScreenBlock";

	buscarColaboradorService = new BuscarColaboradorService( dataParametrosBuscarColaborador, buscarColaboradorBeforeMethod, buscarColaboradorAfterMethod );
	
	initElementsBuscarColaborador('tblDesplazamientoRSV');
	showModalElement("divBuscarColaborador");	
	triggerResizeEvent();

	setTimeout(function() {
		resizeTable( "tblColaborador" );
	}, 700);

	resizeGrillasBugIE();		
}

function buscarColaboradorBeforeMethod() {
	
}

function buscarColaboradorAfterMethod(rowData) {
	
	// setear datos del colaborador
	setValueInputText('txtNroRegistro', $.trim(rowData['numeroRegistro']));
	setValueInputText('hidCodigoColaborador', $.trim(rowData["codigoEmpleado"]));
	setValueInputText('txtNombreColaborador', $.trim(rowData["nombreCompleto"]));
	setValueInputText('txtEstadoColaborador',  $.trim(rowData["estadoDetalle"]));
	setValueInputText('hidCodigoEstadoColaborador',  $.trim(rowData["codigoEstado"]));	
	setValueInputText('hidCodigoSedeColaborador', $.trim(rowData['codigoSede']));
	setValueInputText('hidCodigoNivelColaborador', $.trim(rowData['codigoNivelNvl']));
	setValueInputText('hidCodigoNivelViaticoColaborador', $.trim(rowData['codigoViaticoNvi']));	
	
	// setear datos de la UUOO
	setValueInputText('txtUUOO', $.trim(rowData["uuoo"]));
	setValueInputText('txtUUOODetalle', $.trim(rowData["uuooDetalle"]));
	setValueInputText('hidCodigoDependencia', $.trim(rowData["codigoDependencia"]));
	
	// limpiar label y ocultar div de mensaje de error
	setHtmlElement('etiquetaErrorBuscarColaboradorInput', '');
	hideElement('divErrorBuscarColaboradorInput')	
	
	limpiarRegistro();
	
	// como cambio la UUOO, debe buscar nuevamente la meta ordenado por codigo de proyecto
	setTimeout(function() {
		callAjaxObtenerCadenaPresupuestal( $.trim(rowData["codigoDependencia"]) );
		callAjaxObtenerIntendencia( $.trim(rowData["uuoo"]) );
		updateComboPlanillasAsociadas();		
	}, 200);
	
}

// BUSCAR COLABORADOR INPUT
function initElementsBuscarColaboradorInputService( errorMessageBuscarColaboradorInput ) {

	var dataParametros = new Object();
	
	dataParametros.idCodigoDependencia = "hidCodigoDependencia";
	dataParametros.idNumeroRegistroColaborador = "txtNroRegistro";
	dataParametros.idCodigoRegistrador = "hidCodigoRegistrador";
	dataParametros.idNumeroRegistroRegistrador = "hidNumeroRegistroRegistrador";
	dataParametros.idCodigoTipoUsuarioViatico = getTrimValue( '#hidCodigoTipoUsuarioViatico' );
	dataParametros.idDivLoading = "divLoadingBuscarColaboradorInput";
	dataParametros.idDivError = "divErrorBuscarColaboradorInput";	
	dataParametros.idEtiquetaError = "etiquetaErrorBuscarColaboradorInput";
	dataParametros.idDivScreenBlock = "divScreenBlock";
	dataParametros.estadoLlamada = "R";
	dataParametros.errorMessage = errorMessageBuscarColaboradorInput;

	buscarColaboradorInputService = new BuscarColaboradorInputService( dataParametros, buscarColaboradorInputBeforeMethod, buscarColaboradorInputAfterMethod );
}

function buscarColaboradorInputBeforeMethod() {
	
	// limpiar datos del colaborador
	setValueInputText('hidCodigoColaborador', '');
	setValueInputText('txtNombreColaborador', '');
	setValueInputText('txtEstadoColaborador', '');
	setValueInputText('hidCodigoEstadoColaborador', '');
	setValueInputText('hidCodigoSedeColaborador', '');
	setValueInputText('hidCodigoNivelColaborador', '');
	setValueInputText('hidCodigoNivelViaticoColaborador', '');
	
	// limpiar datos de la UUOO
	setValueInputText('txtUUOO', '');
	setValueInputText('txtUUOODetalle', '');
	setValueInputText('hidCodigoDependencia', '');

	// limpiar meta presupuestal
	setValueInputText( 'txtMetaPresupuestal', '' );
	setValueInputText( 'txtCodigoMetaPresupuestal', '' );

	// limpiar label y ocultar div de mensaje de error
	setHtmlElement('etiquetaErrorBuscarColaboradorInput', '');
	hideElement('divErrorBuscarColaboradorInput');
	
	limpiarRegistro();	
}

function buscarColaboradorInputAfterMethod(colaboradorList) {
	
	if (colaboradorList != null && colaboradorList.length > 0) {
		
		for ( var i = 0; i < colaboradorList.length; i++ ) {
			
			var colaborador = colaboradorList[i];
			
			var datarow = {
				numeroRegistro: colaborador.numero_registro,
				nombreCompleto: colaborador.nombre_completo,
				uuoo: colaborador.uuoo,
				codigoDependencia: colaborador.codigoDependencia,
				uuooDetalle: colaborador.dependencia,
				codigoEmpleado: colaborador.codigoEmpleado,
				codigoEstado: colaborador.codigoEstado,
				estadoDetalle: colaborador.estado,
				codigoEncargado: colaborador.codigoEncargado,
				codigoCategoriaViatico: colaborador.codigoCategoriaViatico,
				codigoNivelNvl: colaborador.codigoNivelNvl,
				codigoViaticoNvi: colaborador.codigoViaticoNvi,
				codigoSede: colaborador.codigoSede
			};
			
			// setear datos del colaborador
			setValueInputText("hidCodigoColaborador", $.trim(datarow.codigoEmpleado));
			setValueInputText("txtNombreColaborador", $.trim(datarow.nombreCompleto));
			setValueInputText('txtEstadoColaborador', $.trim(datarow.estadoDetalle));
			setValueInputText("hidCodigoEstadoColaborador", $.trim(datarow.codigoEstado));
			setValueInputText('hidCodigoSedeColaborador', $.trim(datarow.codigoSede));
			setValueInputText('hidCodigoNivelColaborador', $.trim(datarow.codigoNivelNvl));
			setValueInputText('hidCodigoNivelViaticoColaborador', $.trim(datarow.codigoViaticoNvi));			
			
			// setear datos de la UUOO
			setValueInputText("txtUUOO", $.trim(datarow.uuoo));
			setValueInputText("txtUUOODetalle", $.trim(datarow.uuooDetalle));
			setValueInputText("hidCodigoDependencia", $.trim(datarow.codigoDependencia));
			
			limpiarRegistro();
			
			setTimeout(function() {
				callAjaxObtenerCadenaPresupuestal( $.trim(datarow.codigoDependencia) );
				callAjaxObtenerIntendencia( $.trim(datarow.uuoo) );
				updateComboPlanillasAsociadas();
			}, 200);
			
			// limpiar label y ocultar div de mensaje de error
			setHtmlElement('etiquetaErrorBuscarColaboradorInput', '');
			hideElement('divErrorBuscarColaboradorInput');			
			
			break;
		}
		
	} else {

		setHtmlElement('etiquetaErrorBuscarColaboradorInput', configRSV.mensajes.errorMessageBuscarColaboradorInput.sinRegistrosBusqueda);
		showElement("divErrorBuscarColaboradorInput");
	}
}


function clickBtnAfectacionPresupuestal() {

	// creamos y configuramos el servicio (datos, eventos)
	buscarCadenaPresupuestalService = new BuscarCadenaPresupuestalService( null, {
		'eventoAfter' : buscarCadenaPresupuestalAfter
	});

	var uuooValueText = $("#txtUUOO").val();
	var uuooDetalleValueText = $("#txtUUOODetalle").val();
	var codigoDependenciaValueText = $("#hidCodigoDependencia").val();

	initElementsBuscarCadenaPresupuestal("divDesplazamientoTableRSV", uuooValueText, uuooDetalleValueText, codigoDependenciaValueText);	
	showModalElement("divCadenaPresupuestal");
	triggerResizeEvent();

	setTimeout(function() {
		resizeTable( "tblCadenaPresupuestal" );
	}, 700);

	resizeGrillasBugIE();
}

function clickBtnConsultarAsistencia() {

	var fechaFinal = '';
	var fechaInicial = '';
	var numeroRegistroText = getTrimValue( '#txtNroRegistro' );
	var txtNombreColaborador = getTrimValue( '#txtNombreColaborador' );

	// validacion adicional
	if ( numeroRegistroText == '' ) {
		showMensaje( 'Por favor ingresar un colaborador', function() {
			darFoco( '#txtNroRegistro' );
		});
		return;
	}

	if ( esNacional() ) {

		if ( esMayor4h() ) {

			fechaInicial = getTrimValue( '#fechaSalidaNacMay4h' );
			fechaFinal = getTrimValue( '#fechaRetornoNacMay4h' );

		} else {	// si es menor o igual a 4 horas

			// la fecha inicial y final es el mismo dia
			fechaInicial = getTrimValue( '#fechaNacMen4h' );
			fechaFinal = getTrimValue( '#fechaNacMen4h' );
		}

	} else { // si es internacional

		// en primera instancia, toma las fechas de itinerario/ejecucion (así dicen el F2)
		if ( esFechaValida( getTrimValue( '#fechaItinerarioInicioInter' ) ) && esFechaValida( getTrimValue( '#fechaItinerarioFinInter' ) ) ) {

			fechaInicial = getTrimValue( '#fechaItinerarioInicioInter' );
			fechaFinal = getTrimValue( '#fechaItinerarioFinInter' );

		} else {
			
			// dado que son las fechas de itinetario/ejecución son opcionales.
			// en otro caso toma las fechas de programacion/evento

			fechaInicial = getTrimValue( '#fechaEventoInicioInter' );
			fechaFinal = getTrimValue( '#fechaEventoFinInter' );
		}

	}

	initElementsReportarAsistencia("divDesplazamientoTableRSV", numeroRegistroText, fechaInicial, fechaFinal, txtNombreColaborador);
	showModalElement("divReporteAsistencia");
	triggerResizeEvent();

	setTimeout(function() {
		resizeTable( "tblVacaciones" );
		resizeTable( "tblCompensaciones" );
		resizeTable( "tblLicencias" );
	}, 700);

	// actualizar el estado de visualizacion de consulta de asistencia
	configRSV.consultaAsistencia.visualizo = configRSV.constantes.SI;
	configRSV.consultaAsistencia.fecha = configRSV.fechaToday;
	configRSV.consultaAsistencia.hora = new Date().getHours() + ':' + new Date().getMinutes();

	resizeGrillasBugIE();
}

function clickBtnConsultarLugar() {

	// creamos y configuramos el servicio (datos, eventos)
	buscarDestinoService = new BuscarDestinoService(null, {
		'eventoAfter': buscarDestinoAfter
	});

	initElementsBuscarDestino("divDesplazamientoTableRSV");
	showModalElement("divBuscarDestino");
	triggerResizeEvent();

	setTimeout(function() {
		resizeTable( "tblDestino" );
	}, 700);

	resizeGrillasBugIE();	
}

function clickBtnGrabarViatico() {

	resizeGrillasBugIE();

	// confirmar
	showMensajeConfirm( configRSV.mensajes.estaSeguroGuardarCambios, function() {
		
		setTimeout(function() {
			
			// se separa por si en algún momento se desea personalizar el comportamiento (registrar/modificar)
			if ( esRegistrar() ) {
				
				// validación local antes de guardar
				var result = validarGuardarViatico();

				// examina el result e invoca al ajax de validar y guardar
				evaluarYContinuarGrabarModificar( result );				

			} else if ( esModificar() ) {

				// validación local antes de modificar
				var result = validarGuardarViatico();

				// examina el result e invoca al ajax de validar y modificar
				evaluarYContinuarGrabarModificar( result ); 		

			}
			
		}, 200);

	} );

}


// ADJUNTAR ARCHIVO
function clickBtnAdjuntarViatico() {
	
	var dataParametrosArchivo = new Object();
	
	dataParametrosArchivo.codigoBoleto = ''; 	  				// codigo vaucher 00000901
	dataParametrosArchivo.estadoOrigen = 'V';			  		// V: viatico
	dataParametrosArchivo.estadoLLamada = 'R'; 			   		// C: consulta, R: registro	
	dataParametrosArchivo.numeroRegistroColaborador = getTrimValue( '#txtNroRegistro' );
	dataParametrosArchivo.planViajeId = getTrimValue( '#hidCodPlanViaje' );
	dataParametrosArchivo.paginaOrigen = 'PRINCIPAL';			// PRINCIPAL O SECUNDARIA(VAUCHER) 
	
	adjuntarDocumentoService = new AdjuntarDocumentoService(adjuntarDocumnetoBeforeMethod, adjuntarDocumnetoAfterMethod);
	
	initElementsConsultarRegistrarEliminarArchivo(dataParametrosArchivo);
	$("#divAdjuntarDocumento").modal("show");
	triggerResizeEvent();

	resizeGrillasBugIE();
}

function adjuntarDocumnetoBeforeMethod() {

}

function adjuntarDocumnetoAfterMethod(archivos) {
	
	// actualizar la lista local de archivos con lo que se realizó en la ventana popup
	configRSV.archivosAdjuntos = estaDefinido( archivos ) ? archivos : [];
	
	/* ya no se habilita el boton enviar despues de adjuntar sustento de traslape
	// NOTA: siempre que envía primero debe grabar si ha realizado cambios, por tanto esta validación es segura
	if ( getTrimValue( '#hidIndicadorTraslapeAnterior' ) == '1' ) {
		if ( getTrimValue( '#hidIndicadorAutorizacionAnterior' ) == '0' ) {
			if ( tieneAdjuntoSustentoTraslape() ) {
				enabledElement( 'btnEnviarViatico' );
			} else {
				disabledElement( 'btnEnviarViatico' );
			}
		}
	}
	*/
}

function clickBtnImprimirViatico() {
	
	var formPost = $( '#formImprimirPost' );	
	formPost.find( 'input[name="action"]' ).val( 'imprimirReembolsoViatico' );
	formPost.find( 'input[name="codPlanilla"]' ).val( getTrimValue( '#txtCodPlanilla' ) );
	formPost.submit();	
}

function clickBtnEnviarViatico() {
	
	// validación local antes de enviar el viático
	var result = validarEnviarViatico();
	
	// si hay error
	if ( result.hayError ) {
		// si viene el mensaje de error
		if ( estaDefinido( result.msgError ) ) {
			// si viene el control para darle foco
			if ( estaDefinido( result.queryControlFocus ) ) {
				// muestra mensaje dejandole el foco al control despues de aceptar
				showMensaje( result.msgError, function() {
					darFoco( result.queryControlFocus );
				});
			} else {
				// solo muestra el mensaje sin dejar foco
				showMensaje( result.msgError );
			}
		}
		return;
	}
	
	var msg = configRSV.mensajes.estaSeguroRealizarEnvioSolicitudReembolso;	
	msg = msg.replace( /NRO_PLANILLA_REEMBOLSO/g, getTrimValue( '#txtCodPlanilla' ) );

	showMensajeConfirm( msg, function() {
		setTimeout( function() {
			callAjaxValidarEnviarSolicitudViatico();
		}, 200 );
	} );
	
}

// eventos de los combos
function changeSelTipoViatico() {
	
	var seIngresoAlgunDato = ingresoAlgunDatoSeccionIIDetalle() || ingresoAlgunDatoSeccionIIIPuntoPartida() || ingresoAlgunDatoSeccionIVDesplazamientos();
	
	if ( seIngresoAlgunDato ) { 

		showMensajeConfirm( configRSV.mensajes.estaSeguroCambiarTipoViaticoPerderanDatos, function() {
			
			// en caso SI, actualizar los campos normalmente
			updateSelTipoViatico();
			
		}, function() {
			
			// en caso NO, regresar al item que estaba seleccionado
			var selTipoViatico =  $( '#selTipoViatico' ).val();
			if ( selTipoViatico == 'nacional' ) {
				$( '#selTipoViatico' ).val( 'internacional' );
			} else if ( selTipoViatico == 'internacional' ) {
				$( '#selTipoViatico' ).val( 'nacional' );
			} 
			
		});
		
	} else {
		
		// actualizar los campos normalmente
		updateSelTipoViatico();
	}	
}

function changeSelDuracionComision() {

	var seIngresoAlgunDato = ingresoAlgunDatoSeccionIIDetalle() || ingresoAlgunDatoSeccionIIIPuntoPartida() || ingresoAlgunDatoSeccionIVDesplazamientos();
	
	if ( seIngresoAlgunDato ) { 

		showMensajeConfirm( configRSV.mensajes.estaSeguroCambiarDuracionComisionPerderanDatos, function() {
			
			// en caso SI, actualizar los campos normalmente
			updateSelDuracionComision();
			
		}, function() {
			
			// en caso NO, regresar al item que estaba seleccionado
			var selDuracionComision =  $( '#selDuracionComision' ).val();
			if ( selDuracionComision == 'may4h' ) {
				$( '#selDuracionComision' ).val( 'men4h' );
			} else if ( selDuracionComision == 'men4h' ) {
				$( '#selDuracionComision' ).val( 'may4h' );
			} 
			
		});
		
	} else {
		
		// actualizar los campos normalmente
		updateSelDuracionComision();
	}
}

function changeSelDepartamento() {

	setValueInputText( 'selProvincia', '00' );
	setValueInputText( 'hidCodigoPuntoPartida' , '' );

	disabledElement("selProvincia");

	updateBotonAgregarDesplazamiento();

	var selDepartamentoValue = $("#selDepartamento").val();
	if ( selDepartamentoValue != "00") {
		callAjaxObtenerProvincia( selDepartamentoValue, 'selProvincia' );
	}
}

function changeSelProvincia() {

	setValueInputText( 'hidCodigoPuntoPartida' , '' );

	var provinciaSel = $("#selProvincia");
	var departamentoSel = $("#selDepartamento");

	if ( provinciaSel.val() != "00" ) {
		callAjaxObtenerLugarByCodigo(departamentoSel.val(), provinciaSel.val());
	} else {
		updateBotonAgregarDesplazamiento();
	}
}

// eventos: manejo de before y after de los servicios
function buscarColaboradorAfter(rowData) {

	// setear datos del colaborador
	setValueInputText('txtNroRegistro', $.trim(rowData['numeroRegistro']));
	setValueInputText('hidCodigoColaborador', $.trim(rowData["codigoEmpleado"]));
	setValueInputText('txtNombreColaborador', $.trim(rowData["nombreCompleto"]));
	setValueInputText('txtEstadoColaborador',  $.trim(rowData["estadoDetalle"]));
	setValueInputText('hidCodigoEstadoColaborador',  $.trim(rowData["codigoEstado"]));
	setValueInputText('hidCodigoSedeColaborador', $.trim(rowData['codigoSede']));
	setValueInputText('hidCodigoNivelColaborador', $.trim(rowData['codigoNivelNvl']));
	setValueInputText('hidCodigoNivelViaticoColaborador', $.trim(rowData['codigoViaticoNvi']));

	// setear datos de la UUOO
	setValueInputText("txtUUOO", $.trim(rowData["uuoo"]));
	setValueInputText("	", $.trim(rowData["uuooDetalle"]));
	setValueInputText("hidCodigoDependencia", $.trim(rowData["codigoDependencia"]));

	// limpiar label y ocultar div de mensaje de error
	setHtmlElement('etiquetaErrorBuscarColaboradorInput', '');
	hideElement('divErrorBuscarColaboradorInput')

	limpiarRegistro();
	
	// como cambio la UUOO, debe buscar nuevamente la meta ordenado por codigo de proyecto
	setTimeout(function() {
		callAjaxObtenerCadenaPresupuestal( $.trim(rowData["codigoDependencia"]) );
		callAjaxObtenerIntendencia( $.trim(rowData["uuoo"]) );
		updateComboPlanillasAsociadas();
	}, 200);
	
}

function buscarCadenaPresupuestalAfter(rowData) {

	setValueInputText( 'txtCodigoMetaPresupuestal', rowData['secuFuncSfu']);
	setValueInputText( 'txtMetaPresupuestal', rowData['secuFuncSfu'] + ' - ' + rowData['metaPresupuestal']);
}

function buscarDestinoAfter(params) {

	// listas de departamentos y provincias
	var departamentoList = params.departamentoList;
	var provinciaList = params.provinciaList;

	// lo seleccionado en la ventana popup
	var codigoDepartamento = params.codigoDepartamento;
	var codigoProvincia = params.codigoProvincia;
	var codigoUbigeo = params.codigoUbigeo;
	var codigoLugar = params.codigoLugar;

	// llenando el combo de departamentos segun lo que se selecciono en la ventana popup
	var departamentoSel = $("#selDepartamento");
	departamentoSel.empty();
	for (var i = 0; i < departamentoList.length; i++) {
		var departamento = departamentoList[i];
		var optionSelect = $("<option></option>").attr("value", departamento.codiDepaDpt).text(departamento.nombDptoDpt);
		departamentoSel.append(optionSelect);
	}
	setValueInputText("selDepartamento", codigoDepartamento);
	enabledElement("selDepartamento");

	// llenando el combo de provincias segun lo que se selecciono en la ventanta popup
	var provinciaSel = $("#selProvincia");
	provinciaSel.empty();
	for (var i = 0; i < provinciaList.length; i++) {
		var provincia = provinciaList[i];
		var optionSelect = $("<option></option>").attr("value", provincia.codiProvTpr).text(provincia.nombProvTpr);
		provinciaSel.append(optionSelect);
	}
	setValueInputText("selProvincia", codigoProvincia);
	enabledElement("selProvincia");

	// guardar en un hidden el codigo de lugar
	setValueInputText("hidCodigoPuntoPartida", codigoLugar);

	// actualizar el boton de agregar desplazamiento
	updateBotonAgregarDesplazamiento();
}
 
function clickBtnAgregarDesplazamiento() {

	setTimeout(function() {

		// validacion adicional
		var result = validarAgregarDesplazamiento();

		// si hay error
		if ( result.hayError ) {
			// si viene el mensaje de error
			if ( estaDefinido( result.msgError ) ) {
				// si viene el control para darle foco
				if ( estaDefinido( result.queryControlFocus ) ) {

					resizeGrillasBugIE();

					// muestra mensaje dejandole el foco al control despues de aceptar
					showMensaje( result.msgError, function() {
						darFoco( result.queryControlFocus );
						resizeGrillasBugIE();
					});

				} else {

					resizeGrillasBugIE();

					// solo muestra el mensaje sin dejar foco
					showMensaje( result.msgError );

					resizeGrillasBugIE();
				}
			}
			return;
		}

		var nroDiasHorasRestantes = sugerirNroDiasHorasRestantes();
		initElementsCrearNuevaRuta( getTrimValue( '#selDepartamento' ), getTrimValue( '#selProvincia' ), getTrimValue( '#hidCodigoColaborador' ), nroDiasHorasRestantes );
		showModalElement("divCrearNuevaRuta");
	 
	}, 500);
	
}

function clickBtnSalirRetornarViatico() {

	if ( esRegistrar() ) {

		// ir a la bandeja (vía redirección)
		$(location).prop( 'href', 'reembolso.htm?action=generarBandejaRevisionReembolso' );

	} else {

		var formPost = $( '#formBandejaPost' );
		formPost.find( 'input[name="action"]' ).val( 'generarBandejaRevisionReembolso' );
		formPost.find( 'input[name="codPlanilla"]' ).val( getTrimValue( '#txtCodPlanilla' ) );
		formPost.find( 'input[name="codPlanViaje"]' ).val( getTrimValue( '#hidCodPlanViaje' ) );
		formPost.find( 'input[name="dataJSON"]' ).val( configRSV.dataJSON );
		formPost.submit();

	}
}

function clickCheckboxDesplazamientos(control) {
	// var rowJSON = control.value;
	// var rowData = $.parseJSON( rowJSON );
}

// eventos sobre las caja de texto
function blurMontoResolucionInter() {

	// recoge el valor ingresado, lo formatea
	var control = $( '#montoResolucionInter' );
	var controlValue = $.trim( control.val() );

	controlValue = controlValue.replace(/,/g , '');

	// blanquear si no es numero
	if ( !esNumero( controlValue ) ) {
		control.val( '' );
		return;
	}

	if ( controlValue != '' ) {

		// en bd es 10,2
		controlValue = recortarDigitosEnteros( controlValue, 8 );

		var controlValueSinComas = controlValue.replace(/,/g , '');
		control.val( roundComasMilesString( controlValueSinComas, 2 )  );
	}
}

function changeTxtMotivoComision() {
	updateBotonAgregarDesplazamiento();	
}

// desplazamientos: importe diario
function onBlurDesplazamientoImporteDiario( objRef ) {

	// recoge el valor ingresado, lo formatea y actualiza en el modelo
	var control = $( objRef );
	
	var importeDiario = control.val().replace(/,/g , '');
	
	// parche para evitar que ingresen cualquier cosa que no sea un número positivo o el cero
	if ( !esNumero( importeDiario ) || toNumero( importeDiario ) < 0.0 )  importeDiario = '0.00';
	
	// en bd es 8,2
	importeDiario = recortarDigitosEnteros( importeDiario, 6 );

	control.val( roundComasMilesString( importeDiario, 2 )  );

	// actualizar la grilla
	var desplazamientos = getDesplazamientosList();
	var desplazamiento = $.parseJSON( $( objRef ).attr( 'data-info' ) );

	var pos = indexOfDesplazamientos( desplazamientos, desplazamiento );
	if ( pos >= 0 ) {
		desplazamientos[pos]['importeDiario'] = roundString( importeDiario, 1 );
		recalcularImportesFila( desplazamientos[pos] );
	}

}

function onChangeDesplazamientoImporteDiario( nro, objRef ) {
	
	var control = $( objRef );
	var valorControl = $.trim( control.val() );	// valor recientemente ingresado

	
	// darle un tiempo a que ejecute el onblur (sino usar nro y valorControl en un metodo personalizado)
	setTimeout(function() {
		
		// No se debe exceder el monto tope diario
		var itemSuperaMontoDiario = buscarDesplazamientoQueSuperaImporteDiarioTope();
		if ( itemSuperaMontoDiario != null ) {

			var msg = configRSV.mensajes.montoDiarioNoDebeExcederTope;
			msg = msg.replace( /MONEDA_TOPE/g, configRSV.moneda );
			msg = msg.replace( /MONTO_TOPE/g, '' + itemSuperaMontoDiario.importeDiarioTope );

			showMensaje(msg, function() {
				darFoco( '#' + control.prop( 'id' ) );
			});
			
			return;
		}

		// No debe ingresar importe diario igual a cero
		if ( toNumero( valorControl ) <= 0 ) {
			
			showMensaje( 'El importe diario debe ser mayor a cero', function() {
				darFoco( '#' + control.prop( 'id' ) );
			});
			
			return;
		}		
		
	}, 200);

}

// desplazamientos: viaje extra gasto traslado
function onBlurDesplazamientoViajeExtGtoTras( objRef ) {

	// recoge el valor ingresado, lo formatea y actualiza en el modelo
	var control = $( objRef );
	
	var viajeExtGtoTras = control.val().replace(/,/g , '');
	
	// parche para evitar que ingresen cualquier cosa que no sea un número positivo o el cero
	if ( !esNumero( control.val() ) || toNumero( control.val() ) < 0.0 )  viajeExtGtoTras = '0.00';	
	
	// en bd es 8,2
	viajeExtGtoTras = recortarDigitosEnteros( viajeExtGtoTras, 6 );

	control.val( roundComasMilesString( viajeExtGtoTras, 2 )  );

	// actualizar la grilla
	var desplazamientos = getDesplazamientosList();
	var desplazamiento = $.parseJSON( $( objRef ).attr( 'data-info' ) );

	var pos = indexOfDesplazamientos( desplazamientos, desplazamiento );
	if ( pos >= 0 ) {
		desplazamientos[pos]['viajeExtGtoTras'] = roundString( viajeExtGtoTras, 2 );
		recalcularImportesFila( desplazamientos[pos] );
	}

}

function onChangeDesplazamientoViajeExtGtoTras( nro, objRef ) {

	var control = $( objRef );
	var valorControl = $.trim( control.val() );	// valor recientemente ingresado

	// darle un tiempo a que ejecute el onblur (sino usar nro y valorControl en un metodo personalizado)
	setTimeout(function() {

		// No se debe exceder el monto tope para gastos de instalación y traslado
		var itemSuperaViajeExtGtoTras = buscarDesplazamientoQueSuperaViajeExtGtoTrasTope();
		if ( itemSuperaViajeExtGtoTras != null ) {

			var msg = configRSV.mensajes.topeMaxAsigGastosInstTraslado;
			msg = msg.replace( /MONTO_TOPE/g, '' + itemSuperaViajeExtGtoTras.viajeExtGtoTrasTope );

			showMensaje(msg, function() {
				darFoco( '#' + control.prop( 'id' ) );
			});

			return;
		}
		
	}, 200);

}

// desplazamientos: días/horas de viático
function onBlurDesplazamientoDiasViatico( objRef ) {

	// recoge el valor ingresado
	var control = $( objRef );
	
	// parche para evitar que ingresen cualquier cosa que no sea un número positivo o el cero
	if ( !esNumero( control.val() ) || toNumero( control.val() ) < 0.0 )  control.val( '0' );	
	
	var dias = $.trim( control.val() );

	// actualizar la grilla
	var desplazamientos = getDesplazamientosList();
	var desplazamiento = $.parseJSON( $( objRef ).attr( 'data-info' ) );

	var pos = indexOfDesplazamientos( desplazamientos, desplazamiento );
	if ( pos >= 0 ) {
		desplazamientos[pos]['diasViatico'] = dias;
		recalcularImportesFila( desplazamientos[pos] );
	}

}

function onChangeDesplazamientoDiasViatico( nro, objRef ) {

	var control = $( objRef );
	var valorControl = $.trim( control.val() );	// valor recientemente ingresado


	// darle un tiempo a que ejecute el onblur (sino usar nro y valorControl en un metodo personalizado)
	setTimeout(function() {
		
		var diasHorasProg = obtenerNumeroDiasHorasComision();
		var diasHorasDesplazamiento = calcularDiasHorasDesplazamiento();
		
		if ( toNumero( diasHorasDesplazamiento ) != toNumero( diasHorasProg ) ) {

			var msg = configRSV.mensajes.numeroDiasViaticoNroTotalItinerario;
			msg = msg.replace( /DIAS_PROGRAMADOS/g, '' + diasHorasProg );
			msg = msg.replace( /SUMA_DIAS_DESPLAZAMIENTO/g, '' + diasHorasDesplazamiento );		
			
			showMensaje( msg, function() {
				darFoco( '#' + control.prop( 'id' ) );
			});
			
		}
		
	}, 200);

}

function onBlurDesplazamientoHorasViatico( objRef ) {

	// recoge el valor ingresado
	var control = $( objRef );
	
	// parche para evitar que ingresen cualquier cosa que no sea un número positivo o el cero
	if ( !esNumero( control.val() ) || toNumero( control.val() ) < 0.0 )  control.val( '0.0' );
	
	var horas = $.trim( control.val() );

	// solo por moneria, si tiene digito decimal formatear a 1  decimal
	if ( horas.indexOf( '.' ) >= 0 ) {
		control.val( roundString( horas, 1 )  );
	}

	// actualizar la grilla
	var desplazamientos = getDesplazamientosList();
	var desplazamiento = $.parseJSON( $( objRef ).attr( 'data-info' ) );

	var pos = indexOfDesplazamientos( desplazamientos, desplazamiento );
	if ( pos >= 0 ) {
		desplazamientos[pos]['horasViatico'] = roundString( horas, 1 );
		recalcularImportesFila( desplazamientos[pos] );
	}

}

function onChangeDesplazamientoHorasViatico( nro, objRef ) {

	var control = $( objRef );
	var valorControl = $.trim( control.val() );	// valor recientemente ingresado

	// darle un tiempo a que ejecute el onblur (sino usar nro y valorControl en un metodo personalizado)
	setTimeout(function() {
		
		var horasNacMen4h = getTrimValue( '#horasNacMen4h' );
		var nroHorasDesplazamiento = calcularDiasHorasDesplazamiento();
		
		// que el número de horas coincidan
		if ( toNumero( nroHorasDesplazamiento ) != toNumero( horasNacMen4h ) ) {

			var msg = configRSV.mensajes.numeroHorasViaticoNroTotalItinerario;
			msg = msg.replace( /HORAS_PROGRAMADAS/g, horasNacMen4h );
			msg = msg.replace( /SUMA_HORAS_DESPLAZAMIENTO/g, '' + nroHorasDesplazamiento );

			showMensaje(msg, function() {
				darFoco( '#' + control.prop( 'id' ) );
			});
			
			return;
		}				
		
	}, 200);
	
}

// desplazamientos: días de traslado 
function onBlurDesplazamientoDiasTraslado( objRef ) {
	
	// recoge el valor ingresado
	var control = $( objRef );
	
	// parche para evitar que ingresen cualquier cosa que no sea un número positivo o el cero
	if ( !esNumero( control.val() ) || toNumero( control.val() ) < 0.0 )  control.val( '0' );
	
	var dias = $.trim( control.val() );

	// actualizar la grilla
	var desplazamientos = getDesplazamientosList();
	var desplazamiento = $.parseJSON( $( objRef ).attr( 'data-info' ) );

	var pos = indexOfDesplazamientos( desplazamientos, desplazamiento );
	if ( pos >= 0 ) {
		desplazamientos[pos]['diasTraslado'] = dias;
		recalcularImportesFila( desplazamientos[pos] );
	}

}

function onChangeDesplazamientoDiasTraslado( nro, objRef ) {

	var control = $( objRef );
	var valorControl = $.trim( control.val() );	// valor recientemente ingresado

		
	// darle un tiempo a que ejecute el onblur (sino usar nro y valorControl en un metodo personalizado)
	setTimeout(function() {
		
		// No se debe exceder el traslado maximo
		var itemSuperaDiasTraslado = buscarDesplazamientoInternacionalQueSupereDiasTrasladoTope();
		if ( itemSuperaDiasTraslado != null ) {

			var msg = configRSV.mensajes.topeMaxAsigDiasTraslado;
			msg = msg.replace( /NRO_DIAS/g, itemSuperaDiasTraslado.diasTrasladoTope );

			showMensaje(msg, function() {
				darFoco( '#' + control.prop( 'id' ) );
			});

			return;
		}
		
	}, 200);
	
}

// validaciones de fechas
function changeDateFechaSalidaNacMay4hDiv() {
	consoleLog( 'changeDateFechaSalidaNacMay4hDiv' );

	grabarHistorial( 'fechaSalidaNacMay4h' );

	if ( esRegistrar() ) {

		// efectuar el evento change
		updateNroDiasNacionalMay4h();
		updateBotonConsultarAsistencia();
		updateBotonAgregarDesplazamiento();

		validarDateFechaSalidaNacMay4hDiv();

		obligarVisualizarConsultaAsistencia();
		
		// en registrar siempre borra las secciones de abajo
		limpiarSecciones345();
		updateBotonAgregarDesplazamiento();

	} else {

		if ( huboCambioHistorial( 'fechaSalidaNacMay4h' ) ) {

			var dataPost = armarDataPostCambiarFechaViatico(); 

			if ( dataPost.rangoValido ) {

				callAjaxValidarCambiarFechasViatico( dataPost, function( result ) {
					
					// efectuar el evento change
					updateNroDiasNacionalMay4h();
					updateBotonConsultarAsistencia();
					updateBotonAgregarDesplazamiento();

					validarDateFechaSalidaNacMay4hDiv();

					obligarVisualizarConsultaAsistencia();
					
				}, function( result ) {
					
					deshacerHistorial( 'fechaSalidaNacMay4h' );

					$( '#fechaSalidaNacMay4h' ).val( getHistorialValorActual( 'fechaSalidaNacMay4h'  )  );

					showMensaje( configRSV.mensajes.existenComprobantesGastoEnFechasViatico, function() {
						darFoco( '#fechaSalidaNacMay4h' );
					});
					
				} );

			}
		}
	}
}

function validarDateFechaSalidaNacMay4hDiv() {

	var fechaSalidaNacMay4h = $( '#fechaSalidaNacMay4h' ).val();

	hideMensajeLabelDetalleViatico();
	setValueInputText( 'hidFechaSalidaNacMay4hValido', configRSV.VALIDO_OK );

	// La fecha de salida debe ser  menor a la fecha de registro de la solicitud
	if ( esFechaValida( fechaSalidaNacMay4h ) && !esFechaMenor( fechaSalidaNacMay4h, configRSV.fechaRegistro ) ) {
		showMensajeLabelDetalleViatico( configRSV.mensajes.fechaSalidaMenorFechaRegistroSolicitud );
		setValueInputText( 'hidFechaSalidaNacMay4hValido', configRSV.VALIDO_ERROR );
		darFoco( '#fechaSalidaNacMay4h' );
		return;
	}
	
	// validacion de traslape de fechas (petición asíncrona) - por ser asíncrona debe ser la última validación
	var codColaborador = getTrimValue( '#hidCodigoColaborador' );
	var fechaSalida = getTrimValue( '#fechaSalidaNacMay4h' );
	var fechaRetorno = getTrimValue( '#fechaRetornoNacMay4h' );
	var codPlanViaje = getTrimValue( '#hidCodPlanViaje' );  // solo tiene valor cuando es modificación

	if ( esFechaValida( fechaSalida ) || esFechaValida( fechaRetorno ) ) {

		callAjaxValidarTraslapeFechas(true, codColaborador, fechaSalida, fechaRetorno, codPlanViaje).then( function(response) {

			if ( huboErrorAjax( response ) ) {
				
				handleErrorAjax( response );
				return;
				
			} else {
				
				if ( response.traslapeFechas == 'si' ) {

					var msg = configRSV.mensajes.existePlanillaNombreComisionadoEnRango;
					msg = msg.replace( /NRO_SOLICITUD/g, response.traslapeFechasNroSolicitud );
					msg = msg.replace( /FECHA_INICIO/g, response.traslapeFechasInicio );
					msg = msg.replace( /FECHA_FINAL/g, response.traslapeFechasFinal );
					msg = msg + ' ' + configRSV.mensajes.deSerFechasCorrectasDistintaComisionAdjuntarSust;

					showMensajeLabelDetalleViatico( msg );
					if ( esFechaValida( getTrimValue( '#fechaSalidaNacMay4h' ) ) ) {
						darFoco( '#fechaSalidaNacMay4h' );
					}

					return; // sale de la funcion dentro del then()
				}				
				
			}
			
			// validación adicional
			if ( getTrimValue( '#fechaSalidaNacMay4h' ) != '' ) {
				validarDateFechaRetornoNacMay4hDiv();	
			}

		}, function( error ) {

			handleError( error );
			return;
		});

	}	
	
}

function changeDateFechaRetornoNacMay4hDiv() {
	consoleLog( 'changeDateFechaRetornoNacMay4hDiv' );

	grabarHistorial( 'fechaRetornoNacMay4h' );

	if ( esRegistrar() ) {

		// efectuar el evento change
		updateNroDiasNacionalMay4h();
		updateBotonConsultarAsistencia();
		updateBotonAgregarDesplazamiento();

		validarDateFechaRetornoNacMay4hDiv();

		obligarVisualizarConsultaAsistencia();
		
		// en registrar siempre borra las secciones de abajo
		limpiarSecciones345();
		updateBotonAgregarDesplazamiento();

	} else {

		if ( huboCambioHistorial( 'fechaRetornoNacMay4h' ) ) {

			var dataPost = armarDataPostCambiarFechaViatico();

			if ( dataPost.rangoValido ) {

				callAjaxValidarCambiarFechasViatico( dataPost, function( result ) {
					
					// efectuar el evento change
					updateNroDiasNacionalMay4h();
					updateBotonConsultarAsistencia();
					updateBotonAgregarDesplazamiento();

					validarDateFechaRetornoNacMay4hDiv();

					obligarVisualizarConsultaAsistencia();
					
				}, function( result ) {
					
					deshacerHistorial( 'fechaRetornoNacMay4h' );

					$( '#fechaRetornoNacMay4h' ).val( getHistorialValorActual( 'fechaRetornoNacMay4h'  )  );

					showMensaje( configRSV.mensajes.existenComprobantesGastoEnFechasViatico, function() {
						darFoco( '#fechaRetornoNacMay4h' );
					});
					
				} );

			}
		}
	}
	
}

function validarDateFechaRetornoNacMay4hDiv() {

	var fechaSalidaNacMay4h = $('#fechaSalidaNacMay4h').val();
	var fechaRetornoNacMay4h = $('#fechaRetornoNacMay4h').val();

	hideMensajeLabelDetalleViatico();
	setValueInputText( 'hidFechaRetornoNacMay4hValido', configRSV.VALIDO_OK );

	// la fecha de retorno sea mayor a la fecha de salida
	if ( esFechaValida( fechaRetornoNacMay4h ) && esFechaValida( fechaSalidaNacMay4h ) ) {
		if ( !esFechaMayorIgual( fechaRetornoNacMay4h, fechaSalidaNacMay4h )  ) {
			showMensajeLabelDetalleViatico( configRSV.mensajes.fechaRetornoMayorIgualFechaSalida );
			setValueInputText( 'hidFechaRetornoNacMay4hValido', configRSV.VALIDO_ERROR );
			darFoco( '#fechaRetornoNacMay4h' );
			return;
		}
	}

	// validacion de traslape de fechas (petición síncrona)
	var codColaborador = getTrimValue( '#hidCodigoColaborador' );
	var fechaSalida = getTrimValue( '#fechaSalidaNacMay4h' );
	var fechaRetorno = getTrimValue( '#fechaRetornoNacMay4h' );
	var codPlanViaje = getTrimValue( '#hidCodPlanViaje' );  // solo tiene valor cuando es modificación

	if ( esFechaValida( fechaSalida ) || esFechaValida( fechaRetorno ) ) {

		var result = {
			'hayError': false,
			'msgError': null
		};

		callAjaxValidarTraslapeFechas(false, codColaborador, fechaSalida, fechaRetorno, codPlanViaje).then( function(response) {

			if ( huboErrorAjax( response ) ) {
				result.hayError = true;

				handleErrorAjax( response );
				return;
			}

			if ( response.traslapeFechas == 'si' ) {

				var msg = configRSV.mensajes.existePlanillaNombreComisionadoEnRango;
				msg = msg.replace( /NRO_SOLICITUD/g, response.traslapeFechasNroSolicitud );
				msg = msg.replace( /FECHA_INICIO/g, response.traslapeFechasInicio );
				msg = msg.replace( /FECHA_FINAL/g, response.traslapeFechasFinal );
				msg = msg + ' ' + configRSV.mensajes.deSerFechasCorrectasDistintaComisionAdjuntarSust;

				result.hayError = true;
				result.msgError = msg;

				return; // sale de la funcion dentro del then()
			}

		}, function( error ) {
			result.hayError = true;

			handleError( error );
			return;
		});

		// por la invocacion sincrona, revisar los nuevos valores de result
		if ( result.hayError ) {
			showMensajeLabelDetalleViatico( result.msgError );
			if ( esFechaValida( fechaRetorno ) ) {
				darFoco( '#fechaRetornoNacMay4h' );
			}
			return;
		}

	}

}

function changeDateFechaNacMen4hDiv() {
	consoleLog( 'changeDateFechaNacMen4hDiv' );

	grabarHistorial( 'fechaNacMen4h' );

	if ( esRegistrar() ) {

		// efectuar el evento change
		updateBotonConsultarAsistencia();
		updateBotonAgregarDesplazamiento();

		validarDateFechaNacMen4hDiv();

		obligarVisualizarConsultaAsistencia();
		
		// en registrar siempre borra las secciones de abajo
		limpiarSecciones345();
		updateBotonAgregarDesplazamiento();

	} else {

		if ( huboCambioHistorial( 'fechaNacMen4h' ) ) {

			var dataPost = armarDataPostCambiarFechaViatico();

			if ( dataPost.rangoValido ) {

				callAjaxValidarCambiarFechasViatico( dataPost, function( result ) {
					
					// efectuar el evento change
					updateBotonConsultarAsistencia();
					updateBotonAgregarDesplazamiento();

					validarDateFechaNacMen4hDiv();

					obligarVisualizarConsultaAsistencia();
					
				}, function( result ) {
					
					deshacerHistorial( 'fechaNacMen4h' );

					$( '#fechaNacMen4h' ).val( getHistorialValorActual( 'fechaNacMen4h'  )  );

					showMensaje( configRSV.mensajes.existenComprobantesGastoEnFechasViatico, function() {
						darFoco( '#fechaNacMen4h' );
					});
					
				} );

			}
		}

	}
	
}

function validarDateFechaNacMen4hDiv() {

	var fechaNacMen4h = $('#fechaNacMen4h').val();

	hideMensajeLabelDetalleViatico();
	setValueInputText( 'hidFechaNacMen4hValido', configRSV.VALIDO_OK );

	// valida que la fecha sea menor a la fecha de registro
	if ( esFechaValida( fechaNacMen4h ) && !esFechaMenor( fechaNacMen4h, configRSV.fechaRegistro ) ) {
		showMensajeLabelDetalleViatico( configRSV.mensajes.fechaViaticoMenorFechaRegistro );
		setValueInputText( 'hidFechaNacMen4hValido', configRSV.VALIDO_ERROR );
		darFoco( '#fechaNacMen4h' );
		return;
	}

	// validacion de traslape de fechas (petición asíncrona) - por ser asíncrona debe ser la última validación
	var codColaborador = getTrimValue( '#hidCodigoColaborador' );
	var fechaSalida = getTrimValue( '#fechaNacMen4h' );
	var fechaRetorno = getTrimValue( '#fechaNacMen4h' );
	var codPlanViaje = getTrimValue( '#hidCodPlanViaje' );  // solo tiene valor cuando es modificación

	if ( esFechaValida( fechaSalida ) || esFechaValida( fechaRetorno ) ) {
	
		callAjaxValidarTraslapeFechas(true, codColaborador, fechaSalida, fechaRetorno, codPlanViaje).then( function(response) {

			if ( huboErrorAjax( response ) ) {
				
				handleErrorAjax( response );
				return;
				
			} else {
				
				if ( response.traslapeFechas == 'si' ) {

					var msg = configRSV.mensajes.existePlanillaNombreComisionadoEnRango;
					msg = msg.replace( /NRO_SOLICITUD/g, response.traslapeFechasNroSolicitud );
					msg = msg.replace( /FECHA_INICIO/g, response.traslapeFechasInicio );
					msg = msg.replace( /FECHA_FINAL/g, response.traslapeFechasFinal );
					msg = msg + ' ' + configRSV.mensajes.deSerFechasCorrectasDistintaComisionAdjuntarSust;

					showMensajeLabelDetalleViatico( msg );
					darFoco( '#fechaNacMen4h' );

					return; // sale de la funcion dentro del then()
				}				
				
			}

		}, function( error ) {
			handleError( error );
			return;
		});
		
	}
	
}

function changeHoraSalidaNacMen4hDiv() {
	consoleLog( 'changeHoraSalidaNacMen4hDiv' );

	updateNroDiasNacionalMen4h();
	validarHoraSalidaNacMen4hDiv();
	updateBotonAgregarDesplazamiento();
	
}

function validarHoraSalidaNacMen4hDiv() {

	var salidaNacMen4h = getTrimValue( '#salidaNacMen4h' );

	hideMensajeLabelDetalleViatico();
	setValueInputText( 'hidSalidaNacMen4hValido', configRSV.VALIDO_OK );

	if ( esModificar() ) {
		if ( salidaNacMen4h == '' ) {
			showMensajeLabelDetalleViatico( configRSV.mensajes.seDebeSeleccionarLasHorasDeDeplazamiento );
			setValueInputText( 'hidSalidaNacMen4hValido', configRSV.VALIDO_ERROR );
			darFoco( '#salidaNacMen4h' );
			return;		
		}	
	}	

	// validación adicional
	if ( getTrimValue( '#retornoNacMen4h' ) != '' ) {
		validarHoraRetornoNacMen4hDiv();	
	}
	
}

function changeHoraRetornoNacMen4hDiv() {
	consoleLog( 'changeHoraRetornoNacMen4hDiv' );

	updateNroDiasNacionalMen4h();
	validarHoraRetornoNacMen4hDiv();
	updateBotonAgregarDesplazamiento();
	
}

function validarHoraRetornoNacMen4hDiv() {

	var salidaNacMen4h = getTrimValue( '#salidaNacMen4h' );
	var retornoNacMen4h = getTrimValue( '#retornoNacMen4h' );
	var horasNacMen4h = getTrimValue( '#horasNacMen4h' );

	hideMensajeLabelDetalleViatico();
	setValueInputText( 'hidRetornoNacMen4hValido', configRSV.VALIDO_OK );

	if ( esModificar() ) {
		if ( retornoNacMen4h == '' ) {
			showMensajeLabelDetalleViatico( configRSV.mensajes.seDebeSeleccionarLasHorasDeDeplazamiento );
			setValueInputText( 'hidRetornoNacMen4hValido', configRSV.VALIDO_ERROR );
			darFoco( '#retornoNacMen4h' );
			return;
		}		
	}	
	
	/* -1: err, 1: f1>f2, 2: f1<f2, 0: f1=f2 */
	var diferencia = compararHoras( retornoNacMen4h, salidaNacMen4h );

	// la hora de retorno sea mayor a la hora de salida
	if ( diferencia == 0 || diferencia == 2 ) {
		showMensajeLabelDetalleViatico( configRSV.mensajes.horaRetornoMayorHoraSalida );
		setValueInputText( 'hidRetornoNacMen4hValido', configRSV.VALIDO_ERROR );
		darFoco( '#retornoNacMen4h' );
		return;
	}

	// NOTA: no hay problema de retraso con el calculo de horasNacMen4h, dado que dicho calculo no es ajax
	if ( horasNacMen4h != '' && toNumero( horasNacMen4h ) > 4.0 ) {
		showMensajeLabelDetalleViatico( configRSV.mensajes.diferenciaHoraRetornoSalidaNoSupereHoras );
		setValueInputText( 'hidRetornoNacMen4hValido', configRSV.VALIDO_ERROR );
		darFoco( '#retornoNacMen4h' );
		return;
	}

}

function changeDateFechaItinerarioInicioInterDiv() {
	consoleLog( 'changeDateFechaItinerarioInicioInterDiv' );

	updateBotonConsultarAsistencia();
	updateBotonAgregarDesplazamiento();

	validarDateFechaItinerarioInicioInterDiv();
	
}

function validarDateFechaItinerarioInicioInterDiv() {

	var fechaItinerarioInicioInter = $('#fechaItinerarioInicioInter').val();
	var fechaItinerarioFinInter = $('#fechaItinerarioFinInter').val();
	var fechaEventoInicioInter = $('#fechaEventoInicioInter').val();

	hideMensajeLabelDetalleViatico();
	setValueInputText( 'hidFechaItinerarioInicioInterValido', configRSV.VALIDO_OK );

	// la fecha de ini. Itinerario sea menor a la fecha de registro de  la solicitud de viáticos (ok)
	if ( esFechaValida( fechaItinerarioInicioInter ) && !esFechaMenor( fechaItinerarioInicioInter, configRSV.fechaRegistro ) ) {
		showMensajeLabelDetalleViatico( configRSV.mensajes.fechaInicioItinerarioMenorFechaRegistro );
		setValueInputText( 'hidFechaItinerarioInicioInterValido', configRSV.VALIDO_ERROR );
		darFoco( '#fechaItinerarioInicioInter' );
		return;
	}

	// que La fecha de inicio de itinerario debe ser menor a la fecha de fin de itinerario
	if ( esFechaValida( fechaItinerarioInicioInter ) && esFechaValida( fechaItinerarioFinInter ) ) {
		if ( !esFechaMenor( fechaItinerarioInicioInter, fechaItinerarioFinInter )  ) {
			showMensajeLabelDetalleViatico( 'La fecha de inicio de itinerario debe ser menor a la fecha de fin de itinerario' );
			setValueInputText( 'hidFechaItinerarioInicioInterValido', configRSV.VALIDO_ERROR );
			darFoco( '#fechaItinerarioInicioInter' );
			return;
		}
	}
	
	// La fecha de inicio de itinerario debe ser menor o igual a la fecha de inicio del evento (ok)
	if ( esFechaValida( fechaEventoInicioInter ) && esFechaValida( fechaItinerarioInicioInter ) ) {
		if ( !esFechaMayorIgual( fechaEventoInicioInter, fechaItinerarioInicioInter ) ) {
			showMensajeLabelDetalleViatico( 'La fecha de inicio de itinerario debe ser menor o igual a la fecha de inicio del evento' );
			setValueInputText( 'hidFechaItinerarioInicioInterValido', configRSV.VALIDO_ERROR );
			darFoco( '#fechaItinerarioInicioInter' );
			return;
		}
	}
	
	// validacion adicional
	if ( getTrimValue( '#fechaItinerarioFinInter' ) != ''  ) {
		validarDateFechaItinerarioFinInterDiv();
	}
	
}

function changeDateFechaItinerarioFinInterDiv() {
	consoleLog( 'changeDateFechaItinerarioFinInterDiv' );

	updateBotonConsultarAsistencia();
	updateBotonAgregarDesplazamiento();

	validarDateFechaItinerarioFinInterDiv();
	
}

function validarDateFechaItinerarioFinInterDiv() {

	var fechaItinerarioInicioInter = $('#fechaItinerarioInicioInter').val();
	var fechaItinerarioFinInter = $('#fechaItinerarioFinInter').val();
	var fechaEventoFinInter = $('#fechaEventoFinInter').val();

	hideMensajeLabelDetalleViatico();
	setValueInputText( 'hidFechaItinerarioFinInterValido', configRSV.VALIDO_OK );

	// que la fecha fin del itinerario sea mayor a la fecha de ini. Itinerario (ok)
	if ( esFechaValida( fechaItinerarioFinInter ) && esFechaValida( fechaItinerarioInicioInter ) ) {
		if ( !esFechaMayorIgual( fechaItinerarioFinInter, fechaItinerarioInicioInter )  ) {
			showMensajeLabelDetalleViatico( configRSV.mensajes.fechaTerminoItinerarioDebeMayoFechaInicioItinerario );
			setValueInputText( 'hidFechaItinerarioFinInterValido', configRSV.VALIDO_ERROR );
			darFoco( '#fechaItinerarioFinInter' );
			return;
		}
	}

	// jcf-nuevo
	// las fechas de fin del itinerario, el sistema validara que este sea mayor o igual a la fecha de fin del evento (ok)
	if ( esFechaValida( fechaItinerarioFinInter ) && esFechaValida( fechaEventoFinInter ) ) {
		if ( !esFechaMayorIgual( fechaItinerarioFinInter, fechaEventoFinInter )  ) {
			showMensajeLabelDetalleViatico( configRSV.mensajes.fechaFinItinerarioMayorIgualFechaFinEvento );
			setValueInputText( 'hidFechaItinerarioFinInterValido', configRSV.VALIDO_ERROR );
			darFoco( '#fechaItinerarioFinInter' );
			return;
		}
	}

}

function changeDateFechaEventoInicioInterDiv() {
	consoleLog( 'changeDateFechaEventoInicioInterDiv' );

	grabarHistorial( 'fechaEventoInicioInter' );

	if ( esRegistrar() ) {

		// efectuar el evento change
		updateBotonConsultarAsistencia();
		updateBotonAgregarDesplazamiento();
		updateNroDiasInternacional();

		validarDateFechaEventoInicioInterDiv();

		obligarVisualizarConsultaAsistencia();
		
		// sólo en registrar borra las secciones de abajo
		limpiarSecciones345();
		updateBotonAgregarDesplazamiento();

	} else {

		if ( huboCambioHistorial( 'fechaEventoInicioInter' ) ) {

			var dataPost = armarDataPostCambiarFechaViatico();

			if ( dataPost.rangoValido ) {

				callAjaxValidarCambiarFechasViatico( dataPost, function( result ) {
	
					// efectuar el evento change
					updateBotonConsultarAsistencia();
					updateBotonAgregarDesplazamiento();
					updateNroDiasInternacional();

					validarDateFechaEventoInicioInterDiv();

					obligarVisualizarConsultaAsistencia();
					
				}, function( result ) {
					
					deshacerHistorial( 'fechaEventoInicioInter' );

					$( '#fechaEventoInicioInter' ).val( getHistorialValorActual( 'fechaEventoInicioInter'  )  );

					showMensaje( configRSV.mensajes.existenComprobantesGastoEnFechasViatico, function() {
						darFoco( '#fechaEventoInicioInter' );
					});
					
				} );

			}
		}

	}

}

function validarDateFechaEventoInicioInterDiv() {

	var fechaEventoFinInter = getTrimValue('#fechaEventoFinInter');
	var fechaEventoInicioInter = getTrimValue('#fechaEventoInicioInter');
	var fechaItinerarioInicioInter = getTrimValue('#fechaItinerarioInicioInter');

	hideMensajeLabelDetalleViatico();
	setValueInputText( 'hidFechaEventoInicioInterValido', configRSV.VALIDO_OK );

	// que la La fecha inicio del evento debe ser menor a la fecha de registro de la solicitud (ok)
	if ( esFechaValida( fechaEventoInicioInter ) && !esFechaMenor( fechaEventoInicioInter, configRSV.fechaRegistro ) ) {
		showMensajeLabelDetalleViatico( configRSV.mensajes.fechaInicioEventoMenorFechaRegistroSolicitud );
		setValueInputText( 'hidFechaEventoInicioInterValido', configRSV.VALIDO_ERROR );
		darFoco( '#fechaEventoInicioInter' );
		return;
	}

	// que La fecha de inicio del evento debe ser menor a la fecha de termino del evento
	if ( esFechaValida( fechaEventoInicioInter ) && esFechaValida( fechaEventoFinInter ) ) {
		if ( !esFechaMenor( fechaEventoInicioInter, fechaEventoFinInter ) ) {
			showMensajeLabelDetalleViatico( 'La fecha de inicio del evento debe ser menor a la fecha de t&eacute;rmino del evento' );
			setValueInputText( 'hidFechaEventoInicioInterValido', configRSV.VALIDO_ERROR );
			darFoco( '#fechaEventoInicioInter' );
			return;
		}
	}	

	// la fecha de ini. Evento sea mayor o igual a la fecha de inicio del Itinerario (ok)
	if ( esFechaValida( fechaEventoInicioInter ) && esFechaValida( fechaItinerarioInicioInter ) ) {
		if ( !esFechaMayorIgual( fechaEventoInicioInter, fechaItinerarioInicioInter ) ) {
			showMensajeLabelDetalleViatico( configRSV.mensajes.fechaInicioEventoMayorIgualFechaInicioItinerario );
			setValueInputText( 'hidFechaEventoInicioInterValido', configRSV.VALIDO_ERROR );
			darFoco( '#fechaEventoInicioInter' );
			return;
		}
	}
	
	// validacion de traslape de fechas (petición asíncrona) - por ser asíncrona debe ser la última validación
	var codColaborador = getTrimValue( '#hidCodigoColaborador' );
	var fechaSalida = getTrimValue( '#fechaEventoInicioInter' );
	var fechaRetorno = getTrimValue( '#fechaEventoFinInter' );
	var codPlanViaje = getTrimValue( '#hidCodPlanViaje' );	// solo tiene valor cuando es modificación

	if ( esFechaValida( fechaSalida ) || esFechaValida( fechaRetorno ) ) {

		callAjaxValidarTraslapeFechas(true, codColaborador, fechaSalida, fechaRetorno, codPlanViaje).then( function(response) {

			if ( huboErrorAjax( response ) ) {
				
				handleErrorAjax( response );
				return;
				
			} else {
				
				if ( response.traslapeFechas == 'si' ) {

					var msg = configRSV.mensajes.existePlanillaNombreComisionadoEnRango;
					msg = msg.replace( /NRO_SOLICITUD/g, response.traslapeFechasNroSolicitud );
					msg = msg.replace( /FECHA_INICIO/g, response.traslapeFechasInicio );
					msg = msg.replace( /FECHA_FINAL/g, response.traslapeFechasFinal );
					msg = msg + ' ' + configRSV.mensajes.deSerFechasCorrectasDistintaComisionAdjuntarSust;

					showMensajeLabelDetalleViatico( msg );
					if ( esFechaValida( getTrimValue( '#fechaEventoFinInter' ) ) ) {
						darFoco( '#fechaEventoInicioInter' );
					}	

					return; // sale de la funcion dentro del then()
				}
				
			}
			
			// validación adicional
			if ( getTrimValue('#fechaEventoFinInter') != '' ) {
				validarDateFechaEventoFinInterDiv();	
			}	

		}, function( error ) {
			handleError( error );
			return;
		});

	}	

}

function changeDateFechaEventoFinInterDiv() {
	consoleLog( 'changeDateFechaEventoFinInterDiv' );

	grabarHistorial( 'fechaEventoFinInter' );

	if ( esRegistrar() ) {
		
		// efectuar el evento change
		updateBotonConsultarAsistencia();
		updateBotonAgregarDesplazamiento();
		updateNroDiasInternacional();

		validarDateFechaEventoFinInterDiv();

		obligarVisualizarConsultaAsistencia();
		
		// sólo en registrar borra las secciones de abajo
		limpiarSecciones345();
		updateBotonAgregarDesplazamiento();
			
	} else {
		
		if ( huboCambioHistorial( 'fechaEventoFinInter' ) ) {

			var dataPost = armarDataPostCambiarFechaViatico();

			if ( dataPost.rangoValido ) {

				callAjaxValidarCambiarFechasViatico( dataPost, function( result ) {
					
					// efectuar el evento change
					updateBotonConsultarAsistencia();
					updateBotonAgregarDesplazamiento();
					updateNroDiasInternacional();

					validarDateFechaEventoFinInterDiv();

					obligarVisualizarConsultaAsistencia();
					
				}, function( result ) {
					
					deshacerHistorial( 'fechaEventoFinInter' );

					$( '#fechaEventoFinInter' ).val( getHistorialValorActual( 'fechaEventoFinInter'  )  );

					showMensaje(configRSV.mensajes.existenComprobantesGastoEnFechasViatico, function() {
						darFoco( '#fechaEventoFinInter' );
					});
					
				} );

			}
		}
	}
}

function validarDateFechaEventoFinInterDiv() {

	var fechaEventoFinInter = getTrimValue('#fechaEventoFinInter');
	var fechaEventoInicioInter = getTrimValue('#fechaEventoInicioInter');
	var fechaItinerarioFinInter = getTrimValue('#fechaItinerarioFinInter');

	hideMensajeLabelDetalleViatico();
	setValueInputText( 'hidFechaEventoFinInterValido', configRSV.VALIDO_OK );

	// La fecha término del evento sea mayor a la fecha de Inicio del evento (ok)
	if ( esFechaValida( fechaEventoFinInter ) && esFechaValida( fechaEventoInicioInter ) ) {
		if ( !esFechaMayor( fechaEventoFinInter, fechaEventoInicioInter )  ) {
			showMensajeLabelDetalleViatico( configRSV.mensajes.fechaInicioEventoMayorFechaInicioEvento );
			setValueInputText( 'hidFechaEventoFinInterValido', configRSV.VALIDO_ERROR );
			darFoco( '#fechaEventoFinInter' );
			return;
		}
	}

	// las fechas de fin del itinerario, el sistema validara que este sea mayor o igual a la fecha de fin del evento (ok)
	if ( esFechaValida( fechaEventoFinInter ) && esFechaValida( fechaItinerarioFinInter ) ) {
		if ( !esFechaMenorIgual( fechaEventoFinInter, fechaItinerarioFinInter )  ) {
			showMensajeLabelDetalleViatico( 'La fecha t&eacute;rmino del evento debe ser menor o igual a la fecha de fin del itinerario' );
			setValueInputText( 'hidFechaEventoFinInterValido', configRSV.VALIDO_ERROR );
			darFoco( '#fechaEventoFinInter' );
			return;
		}
	}

	// validacion de traslape de fechas (petición síncrona)
	var codColaborador = getTrimValue( '#hidCodigoColaborador' );
	var fechaSalida = getTrimValue( '#fechaEventoInicioInter' );
	var fechaRetorno = getTrimValue( '#fechaEventoFinInter' );
	var codPlanViaje = getTrimValue( '#hidCodPlanViaje' );	// solo tiene valor cuando es modificación

	if ( esFechaValida( fechaSalida ) || esFechaValida( fechaRetorno ) ) {

		var result = {
			'hayError': false,
			'msgError': null
		};

		callAjaxValidarTraslapeFechas(false, codColaborador, fechaSalida, fechaRetorno, codPlanViaje).then( function(response) {

			if ( huboErrorAjax( response ) ) {
				result.hayError = true;

				handleErrorAjax( response );
				return;
			}

			if ( response.traslapeFechas == 'si' ) {

				var msg = configRSV.mensajes.existePlanillaNombreComisionadoEnRango;
				msg = msg.replace( /NRO_SOLICITUD/g, response.traslapeFechasNroSolicitud );
				msg = msg.replace( /FECHA_INICIO/g, response.traslapeFechasInicio );
				msg = msg.replace( /FECHA_FINAL/g, response.traslapeFechasFinal );
				msg = msg + ' ' + configRSV.mensajes.deSerFechasCorrectasDistintaComisionAdjuntarSust;

				result.hayError = true;
				result.msgError = msg;

				return; // sale de la funcion dentro del then()
			}

		}, function( error ) {
			result.hayError = true;

			handleError( error );
			return;
		});

		// por la invocacion sincrona, revisar los nuevos valores de result
		if ( result.hayError ) {
			showMensajeLabelDetalleViatico( result.msgError );
			if ( esFechaValida( fechaRetorno ) ) {
				darFoco( '#fechaEventoFinInter' );
			}	
			return;
		}

	}
	
}

function changeDateFechaResolucionInterDiv() {
	consoleLog( 'changeDateFechaResolucionInterDiv' );

	validarDateFechaResolucionInterDiv();
	
}

function validarDateFechaResolucionInterDiv() {

	var fechaResolucionInter = getTrimValue( '#fechaResolucionInter' );
	var fechaEventoInicioInter = getTrimValue( '#fechaEventoInicioInter' );

	hideMensajeLabelDetalleViatico();
	setValueInputText( 'hidFechaResolucionInterValido', configRSV.VALIDO_OK );

	if ( esFechaValida( fechaResolucionInter ) ) {

		// la fecha de resolución sea menor a la fecha de registro (ok)
		if ( !esFechaMenor( fechaResolucionInter, configRSV.fechaRegistro ) ) {
			
			showMensajeLabelDetalleViatico( configRSV.mensajes.fechaResolucionMenorFecharegistroMenorProgEvento );
			setValueInputText( 'hidFechaResolucionInterValido', configRSV.VALIDO_ERROR );
			darFoco( '#fechaResolucionInter' );
			return;
		}
	}

	if ( esFechaValida( fechaResolucionInter ) && esFechaValida( fechaEventoInicioInter ) ) {

		// la fecha de resolución es menor a la fecha de registro y menor a la fecha de programación del evento (ok)
		if ( !esFechaMenor( fechaResolucionInter, fechaEventoInicioInter ) ) {
			
			showMensajeLabelDetalleViatico( configRSV.mensajes.fechaResolucionMenorFecharegistroMenorProgEvento );
			setValueInputText( 'hidFechaResolucionInterValido', configRSV.VALIDO_ERROR );
			darFoco( '#fechaResolucionInter' );
			return;
		}
	}

}

function sugerirNroDiasHorasRestantes() {
	
	var nroDiasHorasDesplazamiento = calcularDiasHorasDesplazamiento();
	var nroDiasHorasComision = obtenerNumeroDiasHorasComision();

	var sugerencia = '';

	if ( esNumero( nroDiasHorasComision ) ) {
		var diferencia = toNumero( nroDiasHorasComision ) - toNumero( nroDiasHorasDesplazamiento );

		diferencia = roundNumero( diferencia, 2 );

		if ( diferencia > 0 ) {
			sugerencia = String( diferencia );
		}

	}

	return sugerencia;
}

function changeSelMotivoAmpliacion() {
	
	updateSelMotivoAmpliacion();
	
	// si no es ampliacion limpia
	if ( !esMotivoAmpliacion() ) {
		
		$( '#selPlanillaAsociada' ).val( '' );
		updateSelPlanillaAsociada();
			
	} else {
		
		updateSelPlanillaAsociada();
		updateNroDiasNacionalMay4hConPlanillaAsociada();
	}
			
}

function changeSelPlanillaAsociada() {
	
	updateSelPlanillaAsociada();
	
	updateNroDiasNacionalMay4hConPlanillaAsociada();
}

function clickBtnSustentarGasto() {
	
	// validación adicional 
	// que primero grabe los cambios realizado (si los hubiesen)
	if ( huboModificaciones() ) {
		
		showMensaje(configRSV.mensajes.seHanEfectuadoCambiosGrabarPrimero, function() {
			darFoco( '#btnGrabarViatico' );
		});
		
		return;		
	}
	
	var formPost = $( '#formSustentoGastoPost' );	
	formPost.find( 'input[name="action"]' ).val( 'mostrarSustentarGastoReembolso' );
	formPost.find( 'input[name="codPlanViaje"]' ).val( getTrimValue( '#hidCodPlanViaje' ) );
	formPost.find( 'input[name="dataJSON"]' ).val( configRSV.dataJSON );
	formPost.submit();	
}

function resizeGrillasBugIE() {

	/*
	// por bug en IE que se descuadran las grillas al efectuarse un efecto
	if ( isBrowserInternetExplorer() ) {
		resizeTable("tblDesplazamientoRSV");
		resizeTable("tblAsignacionRSV");
		setTimeout( function() {
			triggerResizeEvent();
		}, 200 );
	}
	*/
}