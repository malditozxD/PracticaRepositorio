/// <reference path="./registrarModificarReembolso_event.js" />
/// <reference path="./registrarModificarReembolso_init.js" />
/// <reference path="./registrarModificarReembolso_rest.js" />
/// <reference path="./registrarModificarReembolso_validate.js" />
/// <reference path="../general/common.js" />
/// <reference path="../../WEB-INF/jsp/reembolso/registrar/registrarModificarReembolso.jsp" />
/// <reference path="D:\jcfr\data\ts-definitions\DefinitelyTyped-master\jquery\jquery.d.ts" />

function limpiarRegistro() { 

	limpiarSeccionIIDetalleViatico();
	limpiarSeccionIIIPuntoPartida();
	limpiarSeccionIVDesplazamientos();
	
	// limpiar los divs que muestran errores
	limpiarLabelsError();

	// actualizando estado botones
	updateBotonConsultarAsistencia();
	updateBotonAgregarDesplazamiento();
	updateEstadosPanelBotones();
	
	// limpiar controles de la planilla asociada
	limpiarControlesPlanillaAsociada();
	$( '#selPlanillaAsociada' ).val( '' );
	$( '#selPlanillaAsociada' ).trigger( 'change' );
	
	$( '#selMotivoAmpliacion' ).val( '' );
	$( '#selMotivoAmpliacion' ).trigger( 'change' );
	
	triggerChangeFechas();
}

function triggerChangeFechas() {

	if ( esNacional() ) {

		if ( esMayor4h() ) {
		
			$( '#fechaSalidaNacMay4h' ).trigger( 'change' );
			$( '#fechaRetornoNacMay4h' ).trigger( 'change' );

		} else {	// si es menor igual a 4h
		
			$( '#fechaNacMen4h' ).trigger( 'change' );
			$( '#salidaNacMen4h' ).trigger( 'change' );
			$( '#retornoNacMen4h' ).trigger( 'change' );			
		}	

	} else { // si es internacional
	
		$( '#fechaEventoInicioInter' ).trigger( 'change' );
		$( '#fechaEventoFinInter' ).trigger( 'change' );
		
		$( '#fechaItinerarioInicioInter' ).trigger( 'change' );
		$( '#fechaItinerarioFinInter' ).trigger( 'change' );
	}

}


function triggerTraslapeFechas() {
	
	// En la casuística que tiene traslape y se maneja la autorización del registrador universal, 
	// es informativo que se muestre el texto de la validación de traslape a modo de guía.
	
	// validacion de traslape de fechas (petición síncrona)
	var codColaborador = getTrimValue( '#hidCodigoColaborador' );
	var fechaSalida = getTrimValue( '#fechaEventoInicioInter' );
	var fechaRetorno = getTrimValue( '#fechaEventoFinInter' );
	var codPlanViaje = getTrimValue( '#hidCodPlanViaje' );	// solo tiene valor cuando es modificación	
	
	if ( esNacional() ) {

		if ( esMayor4h() ) {

			fechaSalida = getTrimValue( '#fechaSalidaNacMay4h' );
			fechaRetorno = getTrimValue( '#fechaRetornoNacMay4h' );
			
		} else {	// si es menor igual a 4h
		
			fechaSalida = getTrimValue( '#fechaNacMen4h' );
			fechaRetorno = getTrimValue( '#fechaNacMen4h' );
		}	

	} else { // si es internacional
	
		fechaSalida = getTrimValue( '#fechaEventoInicioInter' );
		fechaRetorno = getTrimValue( '#fechaItinerarioFinInter' );
	}

	// petición síncrona
	var msgValidacionTraslape = '';
	
	callAjaxValidarTraslapeFechas(false, codColaborador, fechaSalida, fechaRetorno, codPlanViaje).then( function(response) {

		if ( response.traslapeFechas == 'si' ) {

			var msg = configRSV.mensajes.existePlanillaNombreComisionadoEnRango;
			msg = msg.replace( /NRO_SOLICITUD/g, response.traslapeFechasNroSolicitud );
			msg = msg.replace( /FECHA_INICIO/g, response.traslapeFechasInicio );
			msg = msg.replace( /FECHA_FINAL/g, response.traslapeFechasFinal );
			msg = msg + ' ' + configRSV.mensajes.deSerFechasCorrectasDistintaComisionAdjuntarSust;

			msgValidacionTraslape = msg;

			return; 
		}

	} );
	
	if ( $.trim( msgValidacionTraslape ) != '' ) {
		showMensajeLabelDetalleViatico( msgValidacionTraslape );
	}	

}

function limpiarSecciones2345() {
	limpiarSeccionIIDetalleViatico();
	limpiarSeccionIIIPuntoPartida();
	limpiarSeccionIVDesplazamientos();
}

function limpiarSecciones345() {
	limpiarSeccionIIIPuntoPartida();
	limpiarSeccionIVDesplazamientos();
}


function limpiarSeccionIIDetalleViatico() {

	// limpiando campos nacional mayor a 4h
	setValueInputText( 'fechaSalidaNacMay4h', '' );
	setValueInputText( 'fechaRetornoNacMay4h', '' );
	setValueInputText( 'diasNacMay4h', '' );

	// limpiando campos nacional menor igual a 4h
	setValueInputText( 'fechaNacMen4h', '' );
	setValueInputText( 'salidaNacMen4h', '' );
	setValueInputText( 'retornoNacMen4h', '' );
	setValueInputText( 'horasNacMen4h', '' );

	// limpiando campos nacional (ambos)
	setValueInputText( 'txtMotivoComision', '' );
	setValueInputText( 'txtObservacion', '' );
	setValueInputText( 'txtCanalAtencion', '' );

	// limpiando campos internacional
	setValueInputText( 'fechaItinerarioInicioInter', '' );
	setValueInputText( 'fechaItinerarioFinInter', '' );
	setValueInputText( 'fechaEventoInicioInter', '' );
	setValueInputText( 'fechaEventoFinInter', '' );

	setValueInputText( 'fechaResolucionInter', '' );
	setValueInputText( 'nroResolucionInter', '' );
	setValueInputText( 'montoResolucionInter', '' );

	setValueInputText( 'txtMotivoComision', '' );
	setValueInputText( 'txtObservacion', '' );
	setValueInputText( 'txtCanalAtencion', '' );
	
	// limpiando campos planilla asociada	
	$( '#selPlanillaAsociada' ).val( '' );
	$( '#selMotivoAmpliacion' ).val( '' );
	$( '#selPlanillaAsociada' ).trigger( 'change' );
	$( '#selMotivoAmpliacion' ).trigger( 'change' );

	// reseteando el estado de consultar asistencia
	obligarVisualizarConsultaAsistencia();
}

function limpiarSeccionIIIPuntoPartida() {

	// ANTES:
	// setValueInputText( 'selDepartamento', '00' );
	// setValueInputText( 'selProvincia', '00' );
	// setValueInputText( 'hidCodigoPuntoPartida' , '' );
	
	// disabledElement("selProvincia");

	// AHORA:
	updateCombosPuntoPartida();
}

function limpiarSeccionIVDesplazamientos() {
	clearGridDesplazamientos();
	updateTotalDesplazamientos();
}

function limpiarLabelsError() {
	$( '#lblErrorMay4h' ).html( '' );
	$( '#divErrorMay4h' ).hide();
	$( '#lblErrorMen4h' ).html( '' );
	$( '#divErrorMen4h' ).hide();
	$( '#lblErrorInt' ).html( '' );
	$( '#divErrorInt' ).hide();
}

// actualiza la caja de texto con el total de desplazamiento
function updateTotalDesplazamientos() {

	var lista = getDesplazamientosList();

	if ( !estaDefinido( lista ) || lista.length == 0 ) {
		
		$('#txtTotalDesplazamientos').val('');
		
	} else {
		
		var total = calcularTotalDesplazamientos();
		$('#txtTotalDesplazamientos').val( roundComasMilesString( total, 2 ) );
	}
}

function calcularTotalDesplazamientos() {

	var acumulador = 0;
	var desplazamientos = getDesplazamientosList();

	$.each(desplazamientos, function(i, item) {

		if ( esNacional() ) {
			acumulador = toNumero( item.importeViatico ) + acumulador;
		} else { // si es internacional
			acumulador = toNumero( item.totalOtorgado ) + acumulador;
		}

	});

	return roundNumero( acumulador, 2 );
}

// habilita o deshabilita el botón consultar asistencia
function updateBotonConsultarAsistencia() {

	// activa/desactiva el boton agregar consultar asistencias de la seccion II
	var activar = false;

	if ( esNacional() ) {

		if ( esMayor4h() ) {

			activar = esFechaValida( getTrimValue( '#fechaSalidaNacMay4h' ) ) && esFechaValida( getTrimValue( '#fechaRetornoNacMay4h' ) );

		} else {	// si es menor o igual a 4 horas

			activar = esFechaValida( getTrimValue( '#fechaNacMen4h' ) );
		}

	} else { // si es internacional

		/*
		if ( esFechaValida( getTrimValue('#fechaItinerarioInicioInter') ) && esFechaValida( getTrimValue('#fechaItinerarioFinInter') ) ) {
			activar = true;
		}
		*/

		if ( esFechaValida( getTrimValue( '#fechaEventoInicioInter' ) ) && esFechaValida( getTrimValue( '#fechaEventoFinInter' ) ) ) {
			activar = true;
		}

	}

	$('#btnConsultarAsistenciaNacMay4h').prop( 'disabled', !activar );
	$('#btnConsultarAsistenciaNacMen4h').prop( 'disabled', !activar );
	$('#btnConsultarAsistenciaInt').prop( 'disabled', !activar );
}

// habilita o deshabilita el botón afectación presupuestal
function updateBotonAfectacionPresupuestal() {
	
	// Solo para modificar: activa/desactiva el boton afectación presupuestal (sección I - datos generales)
	if ( !esModificar() ) return; 

	var txtCodigoCanalAtencion = getTrimValue( '#txtCodigoCanalAtencion' );
	
	// solo visible si es abono en cuenta (reembolso)
	var visible = txtCodigoCanalAtencion == configRSV.constantes.CANAL_ATENCION_REEMBOLSO;
 
	if ( visible ) {
		$('#btnAfectacionPresupuestal').show();
	} else {
		$('#btnAfectacionPresupuestal').hide();
	}
}

// habilita o deshabilita el botón agregar desplazamiento
function updateBotonAgregarDesplazamiento() {

	// activa/desactiva el boton agregar desplazamiento de la seccion IV

	var selDepartamento = getTrimValue( '#selDepartamento' );
	var selProvincia = getTrimValue( '#selProvincia' );
	var hidCodigoPuntoPartida = getTrimValue( '#hidCodigoPuntoPartida' );

	// validar que ingresen fechas/horas y que estén ok
	var fechasHorasOK = false;

	if ( esNacional() ) {

		if ( esMayor4h() ) {
			fechasHorasOK = esFechaValida( getTrimValue( '#fechaSalidaNacMay4h' ) ) && esFechaValida( getTrimValue( '#fechaRetornoNacMay4h' ) );
		} else {
			fechasHorasOK = esFechaValida( getTrimValue( '#fechaNacMen4h' ) ) && isValidoFormatHour( getTrimValue( '#salidaNacMen4h' ) ) && isValidoFormatHour( getTrimValue( '#retornoNacMen4h' ) );
		}

	} else {
	
		fechasHorasOK = esFechaValida( getTrimValue( '#fechaEventoInicioInter' ) ) && esFechaValida( getTrimValue( '#fechaEventoFinInter' ) );
	}

	// validar que ingrese departamento y provincia
	var departamentoProvinciaOK = hidCodigoPuntoPartida != '' && selDepartamento != '00' && selProvincia != '00';
	
	// validar que ingrese motivo de comisión
	var motivoComisionOK = getTrimValue( '#txtMotivoComision' ) != '';
	
	// que departamento y provincia tengan un dato, y que ademas las fechas este ok
	var activar = departamentoProvinciaOK && fechasHorasOK && motivoComisionOK;

	$('#btnAgregarDesplazamiento').prop( 'disabled', !activar );
}

// actualiza el campo número de días cuando es tipo de viático nacional y duración de comisión es menor o igual a 4h
function updateNroDiasNacionalMen4h() {

	if ( esNacional() ) {

		if ( esMenorIgual4h() ) {

			var salidaNacMen4h = getTrimValue('#salidaNacMen4h');
			var retornoNacMen4h = getTrimValue('#retornoNacMen4h');

			if ( isValidoFormatHour( salidaNacMen4h ) && isValidoFormatHour( retornoNacMen4h ) ) {

				var diferencia = compararHoras( retornoNacMen4h, salidaNacMen4h );

				// si son igual o mayor
				if ( diferencia == 0 || diferencia == 1 ) {

					// convertir a horas y redondear a 1 digito
					var difHoras = roundDiferenciaHorasModulo60( retornoNacMen4h, salidaNacMen4h );

					$( '#horasNacMen4h' ).val( difHoras );

				} else {
					$('#horasNacMen4h').val( '' );
				}

			} else {
				$('#horasNacMen4h').val( '' );
			}

			updateCanalAtencion();
			updateBotonAfectacionPresupuestal();
		}
	}

}

// actualiza el campo número de días cuando es tipo de viático nacional y duración de comisión es mayor a 4h
function updateNroDiasNacionalMay4h() {

	if ( esNacional() ) {

		if ( esMayor4h() ) {

			var fechaSalidaNacMay4h = getTrimValue('#fechaSalidaNacMay4h');
			var fechaRetornoNacMay4h = getTrimValue('#fechaRetornoNacMay4h');

			if ( esFechaValida( fechaSalidaNacMay4h ) && esFechaValida( fechaRetornoNacMay4h ) ) {

				var diferencia = compararFechas( fechaRetornoNacMay4h, fechaSalidaNacMay4h  );

				// si son igual o mayor
				if ( diferencia == 0 || diferencia == 1 ) {

					callAjaxCalcularNroDiasHabiles( fechaSalidaNacMay4h, fechaRetornoNacMay4h, function( result ) {

						$( '#diasNacMay4h' ).val( $.trim( result.nroDias ) );
						$( '#diasNacMay4hHabiles' ).val( $.trim( result.nroDiasHabiles ) );

						updateCanalAtencion();
						updateBotonAfectacionPresupuestal();
						
						if ( esMotivoAmpliacion() ) {
							
							// ahora considera los días hábiles de la planilla asociada
							var dataInfo = obtenerDatosPlanillaAsociada();
							if ( dataInfo != null ) {
								
								// datos de la planilla asociada
								var codPlanillaAsoc = dataInfo.codPlanilla;
								var numeroDiasHabilesAsoc = dataInfo.numeroDiasHabiles;
								
								if ( toNumero( numeroDiasHabilesAsoc ) + toNumero( result.nroDiasHabiles ) > toNumero( configRSV.constantes.MAXIMO_NRO_DIAS_HABILES ) ) {

									var msg = configRSV.mensajes.laSumatoriaDiasPlanillaDiasReembolsoSuperan;
									msg = msg.replace( /NRO_PLANILLA/g, codPlanillaAsoc );
									msg = msg.replace( /NRO_DIAS/g, configRSV.constantes.MAXIMO_NRO_DIAS_HABILES );
									
									showMensajeConfirm( msg );
								}
								
							}
							
							
						} else {
							
							// como estaba antes							
							if ( toNumero( result.nroDiasHabiles ) > toNumero( configRSV.constantes.MAXIMO_NRO_DIAS_HABILES ) ) {

								var msg = configRSV.mensajes.cuentaAutorizacionRegViaPeriodoSuperior;
								var msgConfirm = msg.replace( /NRO_DIAS/g, configRSV.constantes.MAXIMO_NRO_DIAS_HABILES );

								showMensajeConfirm( msgConfirm );
							}
						}

					});

				} else {

					$( '#diasNacMay4h' ).val( '' );
					$( '#diasNacMay4hHabiles' ).val( '' );

					updateCanalAtencion();
					updateBotonAfectacionPresupuestal();
				}

			} else {

				$( '#diasNacMay4h' ).val( '' );
				$( '#diasNacMay4hHabiles' ).val( '' );

				updateCanalAtencion();
				updateBotonAfectacionPresupuestal();
			}

		}
	}

}

// actualiza el campo número de días cuando es tipo de viático internacional
function updateNroDiasInternacional() {

	if ( esInternacional() ) {

		var fechaEventoInicioInter = getTrimValue('#fechaEventoInicioInter');
		var fechaEventoFinInter = getTrimValue('#fechaEventoFinInter');

		if ( esFechaValida( fechaEventoInicioInter ) && esFechaValida( fechaEventoFinInter ) ) {

			var diferencia = compararFechas( fechaEventoFinInter, fechaEventoInicioInter  );

			// si son igual o mayor
			if ( diferencia == 0 || diferencia == 1 ) {

				callAjaxCalcularNroDiasHabiles( fechaEventoInicioInter, fechaEventoFinInter, function( result ) {

					$( '#diasInter' ).val( $.trim( result.nroDias ) );
					$( '#diasInterHabiles' ).val( $.trim( result.nroDiasHabiles ) );

					updateCanalAtencion();
					updateBotonAfectacionPresupuestal();

				} );

			} else {

				$( '#diasInter' ).val( '' );
				$( '#diasInterHabiles' ).val( '' );

				updateCanalAtencion();
				updateBotonAfectacionPresupuestal();
			}

		} else {

			$( '#diasInter' ).val( '' );
			$( '#diasInterHabiles' ).val( '' );

			updateCanalAtencion();
			updateBotonAfectacionPresupuestal();
		}

	}

}

function deleteDesplazamientosPregunta() {

	// salir si no hay checks seleccionados
	if ( $( "input[name='chkDesplazamientos']:checked" ).length <= 0 ) return;

	showMensajeConfirm( configRSV.mensajes.deseaEliminarDestino, function() {

 		deleteDesplazamientos();

	});

}

function deleteDesplazamientos() {

	var hayCambios = false;
	var desplazamientos = getDesplazamientosList();

	// busca todos los checks de desplazamientos seleccionados
	$( "input[name='chkDesplazamientos']:checked" ).each(function(i, obj) {

		var desplazamiento = $.parseJSON( obj.value );
		var pos = indexOfDesplazamientos( desplazamientos, desplazamiento );

		if ( pos >= 0 ) {

			// quita el desplazamiento de la lista
			desplazamientos.splice(pos, 1);

			hayCambios = true;
		}
	});

	if ( hayCambios ) {

		// actualizar lista de desplazamientos
		fillGrilla( '#tblDesplazamientoRSV', getDesplazamientosList() );
		updateTotalDesplazamientos();
	}

}

function obtenerBotonAsistenciaIDSegunCaso() {
	// por tema de visualizacion/maquetado se crearon tres botones de consultar asistencia,
	// este metodo retorna el boton segun el tipo de viatico y duracion de la comision
	if ( esNacional() ) {
		if ( esMayor4h() ) {
			return '#btnConsultarAsistenciaNacMay4h';
		} else {	// si es menor o igual a 4 horas
			return '#btnConsultarAsistenciaNacMen4h';
		}
	} else { // si es internacional
		return '#btnConsultarAsistenciaInt';
	}
}

function obligarVisualizarConsultaAsistencia() {
	// cambió alguna fecha y debe visualizar nuevamente sus asistencias
	configRSV.consultaAsistencia.visualizo = configRSV.constantes.NO;
	configRSV.consultaAsistencia.fecha = '';
	configRSV.consultaAsistencia.hora = '';
}
 
// buscar una desplazamiento en la lista de desplazamientos usando el campo nro como identificador
function indexOfDesplazamientos( lista, desplazamiento ) {

	var pos = -1;

	// que lista y desplazamiento esten definidos
	if ( !estaDefinido( lista ) || !estaDefinido( desplazamiento ) || lista.length == 0 ) return pos;

	$.each(lista, function(i, item) {

		// criterios de comparacion
		if ( item.nro == desplazamiento.nro ) {

			pos = i;
			return false; // break
		}

	});

	return pos;
}

function updateCanalAtencion() {

	$('#txtCodigoCanalAtencion').val( configRSV.constantes.CANAL_ATENCION_REEMBOLSO );
	$('#txtCanalAtencion') .val( configRSV.constantes.CANAL_ATENCION_REEMBOLSO_DESCRIP );
}

function updateEstadoTraslapePendienteAutorizar() {
	
	// la solicitud de viático tiene traslape y el registrador universal aún no autoriza el traslape
	
	// deshabilitamos todo y borramos sus eventos por seguridad
	$( '#formViatico' ).find( 'input, button, select' ).prop( 'disabled', true );
	$( '#formViatico' ).find( 'input, select' ).off();

	// por bug en IE que permite seleccionar el calendario
 	deshabilitarFechasHorasBugIE();

	// se habilitan
	$( '#btnSalirRetornarViatico' ).prop( 'disabled', false );
	$( '#btnAdjuntarViatico' ).prop( 'disabled', false );
	
	// si tiene traslape pendiente de autorizar, pero tiene documento de sustento igual debería mostrarle el enviar
	/* se quito para que se alinee al documento
	if ( tieneAdjuntoSustentoTraslape() ) {
		enabledElement( 'btnEnviarViatico' );
	} else {
		disabledElement( 'btnEnviarViatico' );
	}
	*/
}

function updateEstadoTraslapeAutorizado() {

	// la solicitud de viático tiene traslape y el registrador universal ya autorizó el traslape, 
	// por lo que no puede cambiar ni fechas, ni desplazamientos, nada. Sólo puede enviar e imprimir para que siga el flujo.
	
	// deshabilitamos todo y borramos sus eventos por seguridad
	$( '#formViatico' ).find( 'input, button, select' ).prop( 'disabled', true );
	$( '#formViatico' ).find( 'input, select' ).off();

	// por bug en IE que permite seleccionar el calendario
 	deshabilitarFechasHorasBugIE();

	// los botones que estan en el panel de botones se activan según reglas del negocio
	updateEstadosPanelBotones();
	
	// se deshabilitan
	$( '#btnGrabarViatico' ).prop( 'disabled', true ); 			// siempre se deshabilita
	$( '#btnAdjuntarViatico' ).prop( 'disabled', true ); 		// siempre se deshabilita (NOTA: puede darse el caso que le aceptan el traslape de fecha, pero aún debe adjuntar el sustento por más de 15días)
	
	// se habilitan
	if ( esConfiguracionManual() ) {
		$( '#btnImprimirViatico' ).prop( 'disabled', false );
	}
	$( '#btnEnviarViatico' ).prop( 'disabled', false );			// se deja según reglas del negocio
	$( '#btnSalirRetornarViatico' ).prop( 'disabled', false );	// siempre se habilita
	
}

function updateEstadosPanelBotones() {

	// habilita/deshabilita los botones grabar, adjuntar, imprimir, enviar
	
	var hayDesplazamientos = getDesplazamientosList().length > 0;
	
	var habilitarGrabar = false;
	var habilitarAdjuntar = false;
	var visibleImprimir = false;
	var habilitarSustentoGasto = false;
	var habilitarEnviar = false;
	
	if ( esRegistrar() ) {
	
		// si ingresó algo en desplazamientos
		habilitarGrabar = hayDesplazamientos;
		
		// en el registro, enviar e imprimir siempre están deshabilitados ya que requieren del número de planilla
		habilitarEnviar = false;
		visibleImprimir = false;
		
		habilitarSustentoGasto = false;
		
		// en el registro, siempre está deshabilitado ya que el adjuntar requiere del número de planilla
		habilitarAdjuntar = false;		
		
	} else { // si es modificar
		
		// si ingresó algo en desplazamientos
		habilitarGrabar = hayDesplazamientos;		
		
		// ahora el enviar se muestra siempre. sus validaciones se hacen en el clic
		habilitarEnviar = true;
		
		// solo si es manual (y siempre va tener numero de planilla cuando se modifica)
		visibleImprimir = esConfiguracionManual();
		
		habilitarSustentoGasto = true;		
		
		// siempre está habilitado
		habilitarAdjuntar = true;
	}
	
	// habilitar el botón grabar
	$('#btnGrabarViatico').prop( 'disabled', !habilitarGrabar );

	// habilitar el botón adjuntar
	$('#btnAdjuntarViatico').prop( 'disabled', !habilitarAdjuntar );

	// habilitar el botón enviar
	$('#btnEnviarViatico').prop( 'disabled', !habilitarEnviar );

	// habilitar el botón imprimir
	if ( visibleImprimir ) {

		$('#divImprimirViaticoWrapper').show();
		$('#divGrabarViaticoWrapper').removeClass( 'col-md-offset-1 noLeftPadding col-sm-offset-1 noLeftPadding' );
			
	} else {

		$('#divImprimirViaticoWrapper').hide();
		$('#divGrabarViaticoWrapper').addClass( 'col-md-offset-1 noLeftPadding col-sm-offset-1 noLeftPadding' );
	}
	
	// habilitar el botón sustentar gasto
	$('#btnSustentarGasto').prop( 'disabled', !habilitarSustentoGasto );	

}

function updateTitulo() {
	
	if ( esRegistrar() ) {
		setHtmlElement( 'divTituloPanelRegistrarModificarViatico', configRSV.mensajes.registroTitulo );	
	} else {
		setHtmlElement( 'divTituloPanelRegistrarModificarViatico', configRSV.mensajes.modificacionTitulo );	
	}
	
}

function huboModificaciones() {
	
	// hubieron cambios en la seccion I
	if ( getTrimValue( '#txtCodigoMetaPresupuestal' ) != getTrimValue( '#hidCodigoMetaPresupuestalAnterior' ) ) {
		return true;
	}
	
	// hubieron cambios en la seccion II
	if ( getTrimValue( '#txtMotivoComision' ) != getTrimValue( '#hidMotivoComisionAnterior' ) ) {
		return true;
	}
	
	if ( getTrimValue( '#txtObservacion' ) != getTrimValue( '#hidObservacionAnterior' ) ) {
		return true;
	}
	
	// hubieron cambios en las fechas
	if ( esNacional() ) {
		
		if ( esMayor4h() ) {

			if ( getTrimValue( '#fechaSalidaNacMay4h' ) != getTrimValue( '#hidFechaSalidaNacMay4hAnterior' ) || 
				 getTrimValue( '#fechaRetornoNacMay4h' ) != getTrimValue( '#hidFechaRetornoNacMay4hAnterior' ) ) {
				
				return true;
			}
			
		} else { // es menor igual a 4 horas
			
			if ( getTrimValue( '#fechaNacMen4h' ) != getTrimValue( '#hidFechaNacMen4hAnterior' ) ) {
				
				return true;
			}					
			
		}
		
	} else {  // si es internacional
		
		if ( getTrimValue( '#fechaEventoInicioInter' ) != getTrimValue( '#hidFechaEventoInicioInterAnterior' ) || 
			 getTrimValue( '#fechaEventoFinInter' ) != getTrimValue( '#hidFechaEventoFinInterAnterior' ) ) {
			
			return true;
		}		
		
	}	
	
	if ( getTrimValue( '#selMotivoAmpliacion' ) != getTrimValue( '#hidMotivoAmpliacionAnterior' ) ) {
		return true;
	}
	
	if ( esMotivoAmpliacion() ) {
		if ( getTrimValue( '#selPlanillaAsociada' ) != getTrimValue( '#hidPlanillaAsociadaAnterior' ) ) {
			return true;
		}
	}
	
	// hubieron cambios en la seccion III
	if ( getTrimValue( '#hidCodigoPuntoPartida' ) != getTrimValue( '#hidCodigoPuntoPartidaAnterior' ) ) {
		return true;
	}
	
	// hubieron cambios en los desplazamientos
	if ( estaDefinido( configRSV.desplazamientosCopia ) ) {
		if ( !sonIgualesList( configRSV.desplazamientosCopia, getDesplazamientosList() ) ) {
			return true;
		}
	}
	
	return false;
}

function crearCopiaDesplazamientos() {
	
	// creando y limpiando el array copia de desplazamientos
	configRSV.desplazamientosCopia = [];
	
	crearCopiaList( getDesplazamientosList(), configRSV.desplazamientosCopia );
	
} 

function crearCopiaObject( origen, copia ) {
	
	if ( !estaDefinido( origen ) || !estaDefinido( copia ) ) return;
	
	for( var property in origen ) {
		copia[property] = origen[property];
	}
}

function sonIgualesObject( objeto01, objeto02 ) {
	
	// PRE: objeto01 y objeto02 solo deben contener atributos simples (no listas)
	
	if ( !estaDefinido( objeto01 ) || !estaDefinido( objeto02 ) ) return false;
	
	for( var property in objeto01 ) {
		/*
		if ( $.trim( objeto01[property] ) != $.trim( objeto02[property] ) ) {
			return false;
		}
		*/
		
		if ( objeto01[property] != objeto02[property] ) {
			return false;
		}
	}	
	
	
	return true;	
}

function crearCopiaList( listaOrigen, listaCopia ) {
	
	if ( !estaDefinido( listaOrigen ) || !estaDefinido( listaCopia ) ) return;
	
	$.each( listaOrigen, function(i, item) {
		
		var copia = new Object();
		
		crearCopiaObject( item, copia );
		
		listaCopia.push( copia );
		
	});	
}

function sonIgualesList( lista01, lista02 ) {
	
	if ( !estaDefinido( lista01 ) || !estaDefinido( lista02 ) ) return false;
	
	if ( lista01.length != lista02.length ) {
		return false;
	}	
	
	for( var i = 0; i < lista01.length; i++ ) {
		if ( !sonIgualesObject( lista01[i], lista02[i]  ) ) {
			return false;
		}
	} 

	return true;
}


function recalcularImportesFila( desplazamiento ) {

	if ( !estaDefinido( desplazamiento ) ) return;

	// segun tipo recalcula los importes
	if ( esNacional() ) {

		if ( esMayor4h() ) {

			// importeViatico = diasViatico * importeDiario
			desplazamiento.importeViatico = roundString( toNumero(desplazamiento.diasViatico) * toNumero(desplazamiento.importeDiario), 2 );

		} else {	// si es menor o igual a 4 horas

			// importeViatico = diasViatico * importeDiario
			desplazamiento.importeViatico = roundString( toNumero(desplazamiento.horasViatico) * toNumero(desplazamiento.importeDiario), 2 );
		}

	} else { // si es internacional

 		// importeViatico = diasViatico * importeDiario
		desplazamiento.importeViatico = roundString( toNumero(desplazamiento.diasViatico) * toNumero(desplazamiento.importeDiario), 2 );

		var viajeExtraPorDiasTraslado = roundString( toNumero(desplazamiento.viajeExtGtoTras) * toNumero(desplazamiento.diasTraslado), 2 );

		// importeViatico + viajeExtGtoTras * diasTraslado
		desplazamiento.totalOtorgado = roundString( toNumero( desplazamiento.importeViatico ) + toNumero( viajeExtraPorDiasTraslado ), 2 );
	}

	// actualizar solo la fila con el nuevo modelo
	$("#tblDesplazamientoRSV").jqGrid('setRowData', desplazamiento.nro, desplazamiento);

	// recalcular el total
	updateTotalDesplazamientos();
}

function actualizarUnidadFila( desplazamiento, unidad ) {

	if ( !estaDefinido( desplazamiento ) ) return;

	// segun tipo recalcula los importes
	if ( esNacional() ) {

		if ( esMayor4h() ) { // si es mayor o igual a 4 horas
			desplazamiento.diasViatico = unidad;
		} else {	// si es menor o igual a 4 horas
			desplazamiento.horasViatico = unidad;
		}
	} else { // si es internacional
		desplazamiento.diasViatico = unidad;
	}

	// actualizar solo la fila con el nuevo modelo
	$("#tblDesplazamientoRSV").jqGrid('setRowData', desplazamiento.nro, desplazamiento);
}

function obtenerNumeroDiasHorasComision() {
	
	// nacional
	if ( esNacional() ) {
		
		if ( esMayor4h() ) {
		
			return getTrimValue( '#diasNacMay4h' );
			
		} else {
			
			return getTrimValue( '#horasNacMen4h' );
		}
		
	} else {	// internacional
		
		return getTrimValue('#diasInter');
	}
	
}

function calcularDiasHorasDesplazamiento() {
	
	// calcula el número de días u horas de desplazamiento según tipo de viático y duración de comisión.
	var lista = getDesplazamientosList();

	if ( esNacional() ) {

		if ( esMayor4h() ) {

			var sumaDias = 0;
			$.each(lista, function(i, item) {
				sumaDias = sumaDias + toNumero( item.diasViatico );
			});

			// todos son enteros
			return sumaDias;

		} else {	// si es menor o igual a 4 horas

 			var sumaHoras = 0;
			$.each(lista, function(i, item) {
				sumaHoras = sumaHoras + toNumero( item.horasViatico );
			});

			// pueden ser decimales a un digito de redondeo
			return roundNumero(sumaHoras, 1);
		}

	} else { // si es internacional

		var sumaDias = 0;

		$.each(lista, function(i, item) {
			sumaDias = sumaDias + toNumero( item.diasViatico );
		});

		// todos son enteros
		return sumaDias;
	}

}

function buscarDesplazamientoQueSuperaImporteDiarioTope() {

	var result = null;
	var desplazamientos = getDesplazamientosList();

	$.each(desplazamientos, function(i, item) {

		if ( toNumero( item.importeDiario ) > toNumero( item.importeDiarioTope ) ) {
			result = item;
			return false; // break
		}

	});

	return result;
}

function buscarDesplazamientoQueSuperaViajeExtGtoTrasTope() {

	var result = null;
	var desplazamientos = getDesplazamientosList();

	$.each(desplazamientos, function(i, item) {

		if ( toNumero( item.viajeExtGtoTras ) > toNumero( item.viajeExtGtoTrasTope ) ) {
			result = item;
			return false; // break
		}

	});

	return result;
}

function buscarDesplazamientoInternacionalQueSupereDiasTrasladoTope() {

	var desplazamientos = getDesplazamientosList();
	var result = null;

	$.each(desplazamientos, function(i, item) {

		if ( toNumero( item.diasTraslado ) > toNumero( item.diasTrasladoTope ) ) {
			result = item;
			return false; // break
		}

	});

	return result;
}

function buscarDesplazamientoConDiasHorasNoValidos() {

	var desplazamientos = getDesplazamientosList();
	var result = null;

	$.each(desplazamientos, function(i, item) {

		if ( esNacional() ) {

			if ( esMayor4h() ) {

				if ( toNumero( item.diasViatico ) <= 0 ) {
					result = item;
					return false; // break
				}

			} else {  // si es menor igual 4h

				if ( toNumero( item.horasViatico ) <= 0 ) {
					result = item;
					return false; // break
				}
			}

		} else { // si es internacional

			if ( toNumero( item.diasViatico ) <= 0 ) {
				result = item;
				return false; // break
			}
		}

	});

	return result;
}

function buscarDesplazamientoConImporteDiarioNoValido() {

	var desplazamientos = getDesplazamientosList();
	var result = null;

	$.each(desplazamientos, function(i, item) {

		if ( toNumero( item.importeDiario ) <= 0 ) {
			result = item;
			return false; // break
		}

	});

	return result;
}

function construirDataPost( incluirDesplazamientos ) {

	// recuperar el formulario (elementos enabled y disabled)
	var dataPost = formToObject( 'formViatico', true );

	// quitar las comas en algunos montos
	dataPost.totalDesplazamientos = dataPost.totalDesplazamientos.replace(/,/g , '');
	dataPost.montoResolucionInter = dataPost.montoResolucionInter.replace(/,/g , '');

	// otros campos
	dataPost.consultaAsistenciaVisualizo = $.trim( configRSV.consultaAsistencia.visualizo );
	dataPost.consultaAsistenciaFecha = $.trim( configRSV.consultaAsistencia.fecha );
	dataPost.consultaAsistenciaHora = $.trim( configRSV.consultaAsistencia.hora );
	
	// se agregan los desplazamientos
	if ( incluirDesplazamientos )  dataPost.desplazamientosJSON = JSON.stringify( getDesplazamientosList() );

	return dataPost;
}

// manejo de fechas
function hayFechasConError() {

	if ( esNacional() ) {

		if ( esMayor4h() ) {

			return getValueInputText( 'hidFechaSalidaNacMay4hValido' ) == configRSV.VALIDO_ERROR ||
				   getValueInputText( 'hidFechaRetornoNacMay4hValido' ) == configRSV.VALIDO_ERROR;

		} else {

			return getValueInputText( 'hidFechaNacMen4hValido' ) == configRSV.VALIDO_ERROR ||
				   getValueInputText( 'hidSalidaNacMen4hValido' ) == configRSV.VALIDO_ERROR ||
				   getValueInputText( 'hidRetornoNacMen4hValido' ) == configRSV.VALIDO_ERROR;
		}

	} else {

		return getValueInputText( 'hidFechaItinerarioInicioInterValido' ) == configRSV.VALIDO_ERROR ||
			   getValueInputText( 'hidFechaItinerarioFinInterValido' ) == configRSV.VALIDO_ERROR ||
			   getValueInputText( 'hidFechaEventoInicioInterValido' ) == configRSV.VALIDO_ERROR ||
			   getValueInputText( 'hidFechaEventoFinInterValido' ) == configRSV.VALIDO_ERROR ||
			   getValueInputText( 'hidFechaResolucionInterValido' ) == configRSV.VALIDO_ERROR;

	}

}

function revalidarSiHayFechasConError() {

	// buscar en los hidden de validacion, alguna fecha con error

	if ( esNacional() ) {
		if ( esMayor4h() ) {

			if ( getValueInputText( 'hidFechaSalidaNacMay4hValido' ) == configRSV.VALIDO_ERROR ) {
				validarDateFechaSalidaNacMay4hDiv();
				return;
			}
			if ( getValueInputText( 'hidFechaRetornoNacMay4hValido' ) == configRSV.VALIDO_ERROR ) {
				validarDateFechaRetornoNacMay4hDiv();
				return;
			}

		} else {	// si es menor o igual a 4 horas

			if ( getValueInputText( 'hidFechaNacMen4hValido' ) == configRSV.VALIDO_ERROR ) {
				validarDateFechaNacMen4hDiv();
				return;
			}
			if ( getValueInputText( 'hidSalidaNacMen4hValido' ) == configRSV.VALIDO_ERROR ) {
				// no hay evento change todavia
				return;
			}
			if ( getValueInputText( 'hidRetornoNacMen4hValido' ) == configRSV.VALIDO_ERROR ) {
				validarHoraRetornoNacMen4hDiv();
				return;
			}

		}
		
	} else { // si es internacional

		if ( getValueInputText( 'hidFechaItinerarioInicioInterValido' ) == configRSV.VALIDO_ERROR ) {
			validarDateFechaItinerarioInicioInterDiv();
			return;
		}

		if ( getValueInputText( 'hidFechaItinerarioFinInterValido' ) == configRSV.VALIDO_ERROR ) {
			validarDateFechaItinerarioFinInterDiv();
			return;
		}

		if ( getValueInputText( 'hidFechaEventoInicioInterValido' ) == configRSV.VALIDO_ERROR ) {
			validarDateFechaEventoInicioInterDiv();
			return;
		}

		if ( getValueInputText( 'hidFechaEventoFinInterValido' ) == configRSV.VALIDO_ERROR ) {
			validarDateFechaEventoFinInterDiv();
			return;
		}

		if ( getValueInputText( 'hidFechaResolucionInterValido' ) == configRSV.VALIDO_ERROR ) {
			validarDateFechaResolucionInterDiv();
			return;
		}

	}
}

function obtenerFechaConError() {

	// buscar en los hidden de validacion, alguna fecha con error

	if ( esNacional() ) {
		if ( esMayor4h() ) {

			if ( getValueInputText( 'hidFechaSalidaNacMay4hValido' ) == configRSV.VALIDO_ERROR ) return '#fechaSalidaNacMay4h';
			if ( getValueInputText( 'hidFechaRetornoNacMay4hValido' ) == configRSV.VALIDO_ERROR ) return '#fechaRetornoNacMay4h';

			return '#fechaSalidaNacMay4h';

		} else {	// si es menor o igual a 4 horas

			if ( getValueInputText( 'hidFechaNacMen4hValido' ) == configRSV.VALIDO_ERROR ) return '#fechaNacMen4h';
			if ( getValueInputText( 'hidSalidaNacMen4hValido' ) == configRSV.VALIDO_ERROR ) return '#salidaNacMen4h';
			if ( getValueInputText( 'hidRetornoNacMen4hValido' ) == configRSV.VALIDO_ERROR ) return '#retornoNacMen4h';

			return '#fechaNacMen4h';
		}
	} else { // si es internacional

		if ( getValueInputText( 'hidFechaItinerarioInicioInterValido' ) == configRSV.VALIDO_ERROR ) return '#fechaItinerarioInicioInter';
		if ( getValueInputText( 'hidFechaItinerarioFinInterValido' ) == configRSV.VALIDO_ERROR ) return '#fechaItinerarioFinInter';
		if ( getValueInputText( 'hidFechaEventoInicioInterValido' ) == configRSV.VALIDO_ERROR ) return '#fechaEventoInicioInter';
		if ( getValueInputText( 'hidFechaEventoFinInterValido' ) == configRSV.VALIDO_ERROR ) return '#fechaEventoFinInter';
		if ( getValueInputText( 'hidFechaResolucionInterValido' ) == configRSV.VALIDO_ERROR ) return '#fechaResolucionInter';

		return '#fechaItinerarioInicioInter';
	}
}

function bloquearScreen() {
	showModalElement( "divScreenBlock" );
}

function desbloquearScreen() {
	hideModalElement( "divScreenBlock" );
}


// llena una grilla
function fillGrilla( tableID, lista ) {

	// que tableID y lista esten definidos
	if ( !estaDefinido( tableID ) || !estaDefinido( lista ) ) return;

	var table = $( tableID );
	if ( table ) {

		table.clearGridData();

		if (lista != null && lista.length > 0) {

			for (var i = 0; i < lista.length; i++) {

				var datarow = lista[i];

				// agrega el campo nro con una secuencia
				datarow.nro = String(i + 1);

				table.jqGrid("addRowData", datarow.nro, datarow);
			}

			table.trigger("reloadGrid");

		}

	}

}

function updateSelTipoViatico() {
	
	// actualizar controles fechas según el caso
	updateDivsDetalleViatico();
	updateSelMotivoAmpliacion();

	// limpiar secciones
	limpiarSecciones2345();
	limpiarLabelsError();

	// actualizar botones
	updateBotonConsultarAsistencia();
	updateBotonAgregarDesplazamiento();
	updateEstadosPanelBotones();

	// actualizar dias/horas según el caso
	updateNroDiasInternacional();
	updateNroDiasNacionalMay4h();
	updateNroDiasNacionalMen4h();

	updateComboPlanillasAsociadas();
}

function updateCombosPuntoPartida() {

	if ( esInternacional() ) {

		// indicador que el valor por defecto en los combos de punto de partida es LIMA/LIMA
		configRSV.puntoPartida.usarLimaComoDefault = configRSV.constantes.SI;

		// setea departamento lima (15), provincia lima (01) 
		setValueInputText( 'selDepartamento', configRSV.constantes.UBIGEO_DEPARTAMENTO_LIMA );
		$('#selDepartamento').trigger( 'change' );

		setTimeout( function() {

			enabledElement( 'selProvincia' );

			setValueInputText( 'selProvincia', configRSV.constantes.UBIGEO_PROVINCIA_LIMA );
			$('#selProvincia').trigger( 'change' );		

		}, 300 );

	} else {

		// indicador que el valor por defecto en los combos de punto de partida es 00
		configRSV.puntoPartida.usarLimaComoDefault = configRSV.constantes.NO;

		setValueInputText( 'selDepartamento', '00' );
		setValueInputText( 'selProvincia', '00' );
		setValueInputText( 'hidCodigoPuntoPartida' , '' );
	
		disabledElement( 'selProvincia' );
	}
}

function updateSelDuracionComision() {
	
	// actualizar controles fechas según el caso
	updateDivsDetalleViatico();
	updateSelMotivoAmpliacion();

	// limpiar secciones
	limpiarSecciones2345();
	limpiarLabelsError();

	// actualizar botones
	updateBotonConsultarAsistencia();
	updateBotonAgregarDesplazamiento();
	updateEstadosPanelBotones();

	// actualizar dias/horas según el caso
	updateNroDiasNacionalMay4h();
	updateNroDiasNacionalMen4h();

	updateComboPlanillasAsociadas();	
}

//configura los campos en la grilla de desplazamientos (oculta y muestra campos según el tipo de viático y duración de comisión)
function updateEstructuraTablaDesplazamientos() {

	// actualiza la estructura de columnas de la tabla desplazamientos
	// segun el tipo de viatico (nacional, internacional) y duracion de comision (> 4horas, <= 4horas)
	var table = $('#tblDesplazamientoRSV');

	if ( esNacional() ) {

		// ocultar
		table.jqGrid("hideCol", "lugarDestino");
		table.jqGrid("hideCol", "diasTraslado");
		table.jqGrid("hideCol", "viajeExtGtoTras");
		table.jqGrid("hideCol", "totalOtorgado");

		// mostrar
		table.jqGrid("showCol", "departamento");
		table.jqGrid("showCol", "provincia");


		if ( esMayor4h() ) {

			table.jqGrid("hideCol", "horasViatico");
			table.jqGrid("showCol", "diasViatico");

		} else {	// si es menor o igual a 4 horas

			table.jqGrid("hideCol", "diasViatico");
			table.jqGrid("showCol", "horasViatico");
		}


	} else { // si es internacional

		// ocultar
		table.jqGrid("hideCol", "departamento");
		table.jqGrid("hideCol", "provincia");
		table.jqGrid("hideCol", "horasViatico");

		// mostrar
		table.jqGrid("showCol", "lugarDestino");
		table.jqGrid("showCol", "diasTraslado");
		table.jqGrid("showCol", "viajeExtGtoTras");
		table.jqGrid("showCol", "totalOtorgado");
		table.jqGrid("showCol", "diasViatico");

	}

	triggerResizeEvent();
}


//oculta y muestra controles según tipo de viático y duración de comisión
function updateDivsDetalleViatico() {

	// oculta o muestra los divs correspondientes a tipo de viatico nacional/internacional, y si es nacional mayor a 4horas o menor igual a 4horas
	if ( esNacional() ) {

		// cambia la moneda por defecto a soles
		configRSV.moneda = configRSV.constantes.MONEDA_SOLES;
		// $('.lblMoneda').html( configRSV.moneda );
		$('.lblMonedaDesplazamientos').html( 'S/.' );

		// ocultar/visualizar divs
		$('#divTipoDesplazamientoWrapper').show();
		$('#divNacionalWrapper').show();

		if ( esMayor4h() ) {

			// ocultar/visualizar divs
			$('#divInternacionalWrapper').hide();
			$('#divNacionalMayor4Wrapper').show();
			$('#divNacionalMenorIgual4Wrapper').hide();

		} else {	// si es menor o igual a 4 horas

			$('#divInternacionalWrapper').hide();
			$('#divNacionalMayor4Wrapper').hide();
			$('#divNacionalMenorIgual4Wrapper').show();
		}

	} else { // si es internacional

		// cambia la moneda por defecto a soles
		configRSV.moneda = configRSV.constantes.MONEDA_DOLARES;
		// $('.lblMoneda').html( configRSV.moneda );
		$('.lblMonedaDesplazamientos').html( '($)' );

		$('#divTipoDesplazamientoWrapper').hide();
		$('#divNacionalWrapper').hide();

		$('#divInternacionalWrapper').show();
		$('#divNacionalMayor4Wrapper').hide();
		$('#divNacionalMenorIgual4Wrapper').hide();

	}

	updateEstructuraTablaDesplazamientos();
}
 
function tieneAdjuntoSustentoTraslape() {
	
	var archivosAdjuntos = getArchivosAdjuntosList();

	var cuentaConSustentoTraslape = false;
	
	$.each(archivosAdjuntos, function(i, item) {
		
		// NOTA: en el modulo popup de adjuntar archivos, 
		//       los items de la lista que devuelve el after siempre debe tener el campo tipo_doc 
		if ( $.trim( item.tipo_doc ) == 'JUSTIFICACION TRASLAPE COMISION' ) {
			cuentaConSustentoTraslape = true;
			return false; // break
		}
		
	});	
	
	return cuentaConSustentoTraslape;
}

function roundDiferenciaHorasModulo60( horaMayorHHMM, horaMenorHHMM ) {
	// PRE: horaMayorHHMM > horaMenorHHMM (en formato HH:MM )

	// convertir a minutos
	var mayorMins = convertirEnMinutos( horaMayorHHMM );
	var menorMins = convertirEnMinutos( horaMenorHHMM );

	// convertir a horas y redondear a 1 digito
	var roundDifHoras = roundString( ( mayorMins - menorMins ) / 60.0, 1 );

	// cuando la diferencia es uno o dos minutos, el redondeo hace desaparecer el primer dígito decimal
	if ( mayorMins >= menorMins ) {
		
		// cuando el modulo 60 es 1 o 2, por el redondeo esta retornando el x.0.
		var modulo60 = ( mayorMins - menorMins ) % 60;
		if ( modulo60 == 1 || modulo60 == 2 ) {
			roundDifHoras = toNumero( roundDifHoras ) + 0.1; // agregarle 0.1 para visualizar la diferencia
			roundDifHoras = roundString( roundDifHoras, 1 ); 
		}
		
	}

	return roundDifHoras;
}

function initHistorial() {
    
    // se barre todos los controles seleccionados en la cadena queryControlesInit, y crear un [] para guardar los valores del historial
    $( configRSV.historial.queryControlesInit ).each( function(i, item) {
        
        var control = $( item );
        var controlName = $.trim( control.prop( 'name' ) );
        
        if ( controlName != '' ) {
            
            var controlValue = $.trim( control.val() );
            
			configRSV.historial.valores[controlName] = [];
			configRSV.historial.valores[controlName].push( controlValue );

        }
        
    });
}

function grabarHistorial( controlName ) {

	if ( !estaDefinido( controlName ) ) return;
    
	// graba un cambio en el control 'controlName'
    $( configRSV.historial.queryControlesInit ).each( function(i, item) {
        
        var control = $( item );
        
        if ( controlName == control.prop( 'name' ) ) {
            
            var controlValue = $.trim( control.val() );

			configRSV.historial.valores[controlName].push( controlValue );

			// NOTA: si no se desea tener tanta data adicional en el modelo del historial,
			//       se podria cortar el tamaño de la lista a un número fijo de elementos.
			// if ( configRSV.historial.valores[controlName].length > 3 ) {
			//    configRSV.historial.valores[controlName].shift()
			// }
        }
        
    });
}
 

function deshacerHistorial( controlName ) {
    
	if ( !estaDefinido( controlName ) ) return;

	// deshace el último grabado del control 'controlName'
    $( configRSV.historial.queryControlesInit ).each( function(i, item) {
        
        var control = $( item );
        
        if ( controlName == control.prop( 'name' ) ) {
            
			configRSV.historial.valores[controlName].pop();
        }
        
    });
}
 
function getHistorialValorActual( controlName ) {
    
	var valores = configRSV.historial.valores[controlName];

	// retorna el ultimo de la lista - el insertado mas reciente
    return getHistorialValor( controlName, valores.length - 1 );
}

function getHistorialValorAnterior( controlName ) {

	var valores = configRSV.historial.valores[controlName];

	// retorna el penultimo de la lista
    return getHistorialValor( controlName, valores.length - 2 );
}

function getHistorialValor( controlName, posicion ) {

	var valores = configRSV.historial.valores[controlName];

	if ( posicion >= 0 && posicion < valores.length ) {
		return valores[ posicion ];
	}

	return '';
}

function huboCambioHistorial( controlName ) {

    if ( !estaDefinido( controlName ) ) return false;
    
    var valorAnterior = getHistorialValorAnterior( controlName );
    var valorActual = getHistorialValorActual( controlName );
    
    return valorAnterior != valorActual;    
}

function armarRangoFechaValida( fechaInicio, fechaFin ) {

	// PRE: al menos uno de los parametros debe ser fecha valida
	var inicio = fechaInicio;
	var fin = fechaFin;

	// si la fecha de termino no es valida, se forma un rango [fechaInicio, fechaInicio]
	if ( !esFechaValida( fin ) ) {
		fin = fechaInicio;
	}

	// si la fecha de inicio no es valida, se forma un rango [fechaFin, fechaFin]	
	if ( !esFechaValida( inicio ) ) {
		inicio = fechaFin;
	}

	var rangoFechas = {
		'inicio': inicio,
		'fin': fin,
		'rangoValido': esFechaValida( fechaInicio ) || esFechaValida( fechaFin )
	};

	return rangoFechas;
}


function resetearSpanCalendarioIE( queryFechaDiv ) {

	var contenidoHTML = $( queryFechaDiv ).children().last().html();

	$( queryFechaDiv ).children().last().remove();
	$( queryFechaDiv ).append('<span class="input-group-addon input-sm add-on"><span class="glyphicon glyphicon-calendar"></span></span>');

}

function deshabilitarFechasHorasBugIE() {

	// por bug en IE que permite seleccionar el calendario
	if ( isBrowserInternetExplorer() ) {
		
		if ( esNacional() ) {

			if ( esMayor4h() ) {

				resetearSpanCalendarioIE( '#fechaSalidaNacMay4hDiv' );
				resetearSpanCalendarioIE( '#fechaRetornoNacMay4hDiv' );

			} else {	// si es menor o igual a 4h

				resetearSpanCalendarioIE( '#fechaNacMen4hDiv' );
				// en IE no se ve el calendario
				// resetearSpanCalendarioHora( '#salidaNacMen4hDiv' );
				// resetearSpanCalendarioHora( '#retornoNacMen4hDiv' );
			}

		} else { // si es internacional

			// disabled
			resetearSpanCalendarioIE( '#fechaItinerarioInicioInterDiv' );
			resetearSpanCalendarioIE( '#fechaItinerarioFinInterDiv' );
			resetearSpanCalendarioIE( '#fechaEventoInicioInterDiv' );
			resetearSpanCalendarioIE( '#fechaEventoFinInterDiv' );	
			resetearSpanCalendarioIE( '#fechaResolucionInterDiv' );
		}

	}
	
}

function limpiarControlesPlanillaAsociada() {
	
	$( '#txtAsociadaImporte' ).val( '' );
	
	// campos si es nacional mayor a 4h
	$( '#txtAsociadaFechaSalidaNacMay4h' ).val( '' );
	$( '#txtAsociadaFechaRetornoNacMay4h' ).val( '' );
	
	// campos si es nacional menor igual a 4h
	$( '#asociadaFechaNacMen4h' ).val( '' );
	$( '#asociadaSalidaNacMen4h' ).val( '' );
	$( '#asociadaRetornoNacMen4h' ).val( '' );		

 	// campos si es internacional
	$( '#asociadaFechaEventoInicioInter' ).val( '' );
	$( '#asociadaFechaEventoFinInter' ).val( '' );
			
}

function ocultarControlesPlanillaAsociada() {
	
	$( '#divPlanillaAsociadaMayor4Wrapper' ).hide();
	$( '#divPlanillaAsociadaMenorIgual4Wrapper' ).hide();
	$( '#divPlanillaAsociadaInternacionalWrapper' ).hide();
		
}

function updateControlesPlanillaAsociada( dataInfo ) {
	
	// dataInfo es un objeto JS con la data de las fechas, horas e importes a mostrar cuando cambiar una planilla asociada
	if ( !estaDefinido( dataInfo ) ) return null;
	
	var dataInfoEsNacional = $.trim( dataInfo.esNacional ) == configRSV.constantes.SI;
	var dataInfoEsMayor4h =  $.trim( dataInfo.esMayor4h ) == configRSV.constantes.SI;
		
	if ( dataInfoEsNacional ) {
		
		if ( dataInfoEsMayor4h ) {
			
			$('#divPlanillaAsociadaMayor4Wrapper').show();
			$('#divPlanillaAsociadaMenorIgual4Wrapper').hide();
			$('#divPlanillaAsociadaInternacionalWrapper').hide();
			
			// datos adicionales: dataInfo.codPlanViaje, dataInfo.codPlanilla, dataInfo.numeroDias
			$( '#txtAsociadaImporte' ).val( roundComasMilesString( dataInfo.importe, 2 ) );
			$( '#txtAsociadaFechaSalidaNacMay4h' ).val( dataInfo.fechaSalida );
			$( '#txtAsociadaFechaRetornoNacMay4h' ).val( dataInfo.fechaRetorno );

			// sugerir fecha de inicio (siguente al ultimo dia de la comision asociada)
			if ( esRegistrar() ) {

				$( '#fechaSalidaNacMay4h' ).val( dataInfo.fechaRetornoMas1 );
				$( '#fechaRetornoNacMay4h' ).val( '' );

				$( '#fechaSalidaNacMay4h' ).trigger( 'change' );
			}
					
			
		} else { // si es menor o igual a 4h
			
			$('#divPlanillaAsociadaMayor4Wrapper').hide();
			$('#divPlanillaAsociadaMenorIgual4Wrapper').show();
			$('#divPlanillaAsociadaInternacionalWrapper').hide();
			
			// datos adicionales: dataInfo.codPlanViaje, dataInfo.codPlanilla, dataInfo.numeroHoras
			$( '#txtAsociadaImporte' ).val( roundComasMilesString( dataInfo.importe, 2 ) );
			$( '#asociadaFechaNacMen4h' ).val( dataInfo.fecha );
			$( '#asociadaSalidaNacMen4h' ).val( dataInfo.horaSalida );
			$( '#asociadaRetornoNacMen4h' ).val( dataInfo.horaRetorno );			

			// sugerir fecha de inicio (siguente al ultimo dia de la comision asociada)
			if ( esRegistrar() ) {

				$( '#fechaNacMen4h' ).val( dataInfo.fechaMas1 );
				$( '#fechaNacMen4h' ).trigger( 'change' );
			} 

		}
		
	} else { // si es internacional
		
		$('#divPlanillaAsociadaMayor4Wrapper').hide();
		$('#divPlanillaAsociadaMenorIgual4Wrapper').hide();
		$('#divPlanillaAsociadaInternacionalWrapper').show();
		
		// datos adicionales: dataInfo.codPlanViaje, dataInfo.codPlanilla, dataInfo.numeroDias
		$( '#txtAsociadaImporte' ).val( roundComasMilesString( dataInfo.importe, 2 ) );
		$( '#asociadaFechaEventoInicioInter' ).val( dataInfo.fechaEventoInicio );
		$( '#asociadaFechaEventoFinInter' ).val( dataInfo.fechaEventoFin );		
		
		// sugerir fecha de inicio (siguente al ultimo dia de la comision asociada)
		if ( esRegistrar() ) {

			$( '#fechaEventoInicioInter' ).val( dataInfo.fechaEventoFinMas1 );
			$( '#fechaEventoFinInter' ).val( '' );

			$( '#fechaEventoInicioInter' ).trigger( 'change' );
		} 

	}
	
}


function validarFechasPlanillaAsociadas() {
	
	var result = {
		'hayError': false,
		'msgError': null,
		'queryControlFocus': null
	};

	var dataInfo = obtenerDatosPlanillaAsociada();

	if ( !estaDefinido( dataInfo ) ) {
		return result;
	} 
	
	var dataInfoEsNacional = $.trim( dataInfo.esNacional ) == configRSV.constantes.SI;
	var dataInfoEsMayor4h =  $.trim( dataInfo.esMayor4h ) == configRSV.constantes.SI;
		
	if ( dataInfoEsNacional ) {
		
		if ( dataInfoEsMayor4h ) {
			
			var fechaSalidaNacMay4h = getTrimValue( '#fechaSalidaNacMay4h' );

			if ( fechaSalidaNacMay4h == '' ) {

				result.hayError = true;
				result.msgError = 'Por favor ingresar fecha salida';
				result.queryControlFocus = '#fechaSalidaNacMay4h';

				return result;
			}

			if ( fechaSalidaNacMay4h != $.trim( dataInfo.fechaRetornoMas1 ) ) {

				result.hayError = true;
				result.msgError = 'Fecha de salida debe ser el día siguiente a la fecha de retorno de la planilla asociada';
				result.queryControlFocus = '#fechaSalidaNacMay4h';

				return result;
			}
			
		} else { // si es menor o igual a 4h
			
			var fechaNacMen4h = getTrimValue( '#fechaNacMen4h' );

			if ( fechaNacMen4h == '' ) {

				result.hayError = true;
				result.msgError = 'Por favor ingresar fecha';
				result.queryControlFocus = '#fechaNacMen4h';

				return result;
			}

			if ( fechaNacMen4h != $.trim( dataInfo.fechaMas1 ) ) {

				result.hayError = true;
				result.msgError = 'Fecha de salida debe ser el día siguiente a la fecha de retorno de la planilla asociada';
				result.queryControlFocus = '#fechaNacMen4h';

				return result;
			}

		}
		
	} else { // si es internacional

		// sugerir fecha de inicio (siguente al ultimo dia de la comision asociada)
		if ( esRegistrar() ) {

			var fechaEventoInicioInter = getTrimValue( '#fechaEventoInicioInter' );

			if ( fechaEventoInicioInter == '' ) {

				result.hayError = true;
				result.msgError = 'Por favor ingresar fecha salida';
				result.queryControlFocus = '#fechaEventoInicioInter';

				return result;
			}

			if ( fechaEventoInicioInter != $.trim( dataInfo.fechaEventoFinMas1 ) ) {

				result.hayError = true;
				result.msgError = 'Fecha de salida debe ser el día siguiente a la fecha de retorno de la planilla asociada';
				result.queryControlFocus = '#fechaEventoInicioInter';

				return result;
			}

		} 

	}

	return result;
}

function obtenerDatosPlanillaAsociada() {
	
	// que haya seleccionado algo en la planilla asociada
	if ( $( '#selPlanillaAsociada' ).val() != '' ) {
		
		// seleccionar el option (planilla) seleccionado
		var planillaSelected =  $( '#selPlanillaAsociada option:selected' );
		
		// recoger los datos adicionales del option (planilla) seleccionado
		var dataInfo = planillaSelected.data( 'info' );
		
		return dataInfo;
	}
	
	return null;
}

function updateSelMotivoAmpliacion() {
	
	if ( esMotivoAmpliacion() ) {
		$('#divPlanillaAsociada').show();
	} else {
		$('#divPlanillaAsociada').hide();
	}
	
}

function updateSelPlanillaAsociada() {
	
	limpiarControlesPlanillaAsociada();
	ocultarControlesPlanillaAsociada();
	updateLabelImportePlanillaAsociada();
	
	// que haya seleccionado algo en la planilla asociada
	if ( $( '#selPlanillaAsociada' ).val() != '' ) {
	
		// recoger los datos adicionales del option (planilla) seleccionado
		var dataInfo = obtenerDatosPlanillaAsociada();

		// actualizar controles con los datos adicionales de la planilla
	 	updateControlesPlanillaAsociada( dataInfo );
		
	} else {
		
		// si no escogio planilla asociada, muestra por default el bloque de viatico mayor 4 horas
		if ( esNacional() ) {

			$( '#divPlanillaAsociadaMayor4Wrapper' ).show();
			$( '#divPlanillaAsociadaMenorIgual4Wrapper' ).hide();
			$( '#divPlanillaAsociadaInternacionalWrapper' ).hide();

		} else {

			$( '#divPlanillaAsociadaMayor4Wrapper' ).hide();
			$( '#divPlanillaAsociadaMenorIgual4Wrapper' ).hide();
			$( '#divPlanillaAsociadaInternacionalWrapper' ).show();
		}

	}
	
}

function updateLabelImportePlanillaAsociada() {

	if ( esNacional() ) {
		$('#lblImportePlanillaAsociada').html( 'Importe S/.' );
	} else {
		$('#lblImportePlanillaAsociada').html( 'Importe $' );
	}

}

function updateNroDiasNacionalMay4hConPlanillaAsociada() {
	
	// vuelve a mostrar el mensaje si supera los 15 dias hábiles considerando los días de la planilla asociada.
	// no invoca al servicio que calcula el número de días hábiles, sino sólo compara con lo ya calculado en el hidden de días hábiles

	if ( esNacional() ) {

		if ( esMayor4h() ) {

			var diasNacMay4h = getTrimValue( '#diasNacMay4h' );
			var diasNacMay4hHabiles = getTrimValue( '#diasNacMay4hHabiles' );
			
			// que se haya calculado los días hábiles
			if ( !esNumero( diasNacMay4h ) || !esNumero( diasNacMay4hHabiles ) ) return;
			
			if ( esMotivoAmpliacion() ) {
						
				// ahora considera los días hábiles de la planilla asociada
				var dataInfo = obtenerDatosPlanillaAsociada();
				if ( dataInfo != null ) {
					
					// datos de la planilla asociada
					var codPlanillaAsoc = dataInfo.codPlanilla;
					var numeroDiasHabilesAsoc = dataInfo.numeroDiasHabiles;
					
					if ( toNumero( numeroDiasHabilesAsoc ) + toNumero( diasNacMay4hHabiles ) > toNumero( configRSV.constantes.MAXIMO_NRO_DIAS_HABILES ) ) {

						var msg = configRSV.mensajes.laSumatoriaDiasPlanillaDiasReembolsoSuperan;
						var msg = msg.replace( /NRO_PLANILLA/g, codPlanillaAsoc );
						var msg = msg.replace( /NRO_DIAS/g, configRSV.constantes.MAXIMO_NRO_DIAS_HABILES );

						showMensajeConfirm( msg );
					
					}
					
				}
				
			}  
			
		}

	}

}

function armarDataPostCambiarFechaViatico() {
	
	var dataPost = {
		'codPlanViaje': getTrimValue( '#hidCodPlanViaje' ),
		'fechaDesdeEvento': '',
		'fechaHastaEvento': '',
		'fechaDesdeItinerario': '',
		'fechaHastaItinerario': '',
		'rangoValido': false
	};

	var rangoFechas = null;

	if ( esNacional() ) {
		
		if ( esMayor4h() ) {

			rangoFechas = armarRangoFechaValida( getTrimValue( '#fechaSalidaNacMay4h' ), getTrimValue( '#fechaRetornoNacMay4h' ) );

		} else {	// si es menor o igual a 4 horas

			rangoFechas = armarRangoFechaValida( getTrimValue( '#fechaNacMen4h' ), getTrimValue( '#fechaNacMen4h' ) );
		}

	} else { // si es internacional

		rangoFechas = armarRangoFechaValida( getTrimValue( '#fechaEventoInicioInter' ), getTrimValue( '#fechaEventoFinInter' ) );

		// si es internacional, agrega las fechas itinerario
		dataPost.fechaDesdeItinerario = getTrimValue( '#fechaItinerarioInicioInter' );
		dataPost.fechaHastaItinerario = getTrimValue( '#fechaItinerarioFinInter' );
	}

	dataPost.fechaDesdeEvento = rangoFechas.inicio;
	dataPost.fechaHastaEvento = rangoFechas.fin;
	dataPost.rangoValido = rangoFechas.rangoValido;

	return dataPost;
}

function updateComboPlanillasAsociadas() {
	// PRE: en hidCodigoColaborador ya debe estar seteado el codigo del colaborador
	callAjaxObtenerPlanillasAsociadas( getTrimValue( '#hidCodigoColaborador' ), getTrimValue('#selTipoViatico'), getTrimValue('#selDuracionComision') );
}

 