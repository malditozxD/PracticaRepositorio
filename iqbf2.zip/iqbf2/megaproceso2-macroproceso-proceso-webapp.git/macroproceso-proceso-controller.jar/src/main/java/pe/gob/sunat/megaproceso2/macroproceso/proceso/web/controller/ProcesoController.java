package pe.gob.sunat.megaproceso2.macroproceso.proceso.web.controller;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.megaproceso2.macroproceso.proceso.model.Empleado;
import pe.gob.sunat.megaproceso2.macroproceso.proceso.service.EmpleadoService;

/**
 * Controller de Ejemplo.
 *
 * /proceso.htm?action=tarea1     //Mal, No use esta forma cuando se requiere devolver json, Spring se raya 
 * /proceso?action=tarea1         //Puede usar una variable action para identificar las tareas * NO RECOMENDADA *     
 * /proceso/tarea1 				  //Puede usar la URL para identificar las tareas	 * RECOMENDADA *
 */
@Controller
@RequestMapping(value="/proceso")
public class ProcesoController {
	
	@Autowired
	FabricaDeServicios serviceFactory;
	
	protected final Log log = LogFactory.getLog(getClass());
	
	//proceso?action=inicio
	@RequestMapping(params="action=inicio")
	public ModelAndView tarea1(@RequestParam Map<String, String> requestParams){
		if(log.isDebugEnabled()){
			log.debug("action="+requestParams.get("action"));
		}
		System.err.println(requestParams.toString());
		ModelAndView m = new ModelAndView();
		m.setViewName("home");
		//Retorna el home.jsp
		return m;
	}

	//proceso?action=obtenerdatos
	@RequestMapping(params="action=obtenerdatos", produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<Empleado> obtenerdatos(@RequestParam Map<String, String> requestParams){
		if(log.isDebugEnabled()){
			log.debug("action="+requestParams.get("action"));
		}
		EmpleadoService empleadoService = serviceFactory.getService("proceso.empleadoservice");

		return empleadoService.obtenerListaEmpleados();
	}

//	//Si no envia ningun parametro
//	@RequestMapping(value="/")
//	public String Error404(HttpServletRequest req, HttpServletResponse resp) throws Exception{
//		if(log.isDebugEnabled()){
//			log.debug(" sin parametros ");
//		}
//		resp.sendError(HttpStatus.NOT_FOUND.value()," Nada de Nada");
//		return null;
//		//throw new NoSuchRequestHandlingMethodException(req);
//	}

//	MensajeRespuesta msgrespuesta = new MensajeRespuesta();
//	//Verificar si es un exception lanzado por Spring y configurar el Response
//	configurarMensajeRespuestaFromException(msgrespuesta,request,response,exception);
//	//Devolver el mensaje de error en formato JSON
//    MappingJackson2JsonView mav = new MappingJackson2JsonView();
//    mav.getObjectMapper().setSerializationInclusion(Include.NON_NULL); //no incluir atributos nulos
//    mav.setContentType(MediaType.APPLICATION_JSON_VALUE);  //json
//    mav.setExtractValueFromSingleKeyModel(true); //el objetos se usara como body (no embebido)	
//    ModelAndView mv = new ModelAndView(mav); 
//    mv.addObject(msgrespuesta); //Se agrega el objeto en la vista
//    return mv;
}
